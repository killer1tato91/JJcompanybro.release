// JJ_AUTO_COMPILE_ON_START_V1 (2026-10-31)
// "Auto F5": when NinjaTrader starts and a NinjaScript file (.cs) under bin\Custom is NEWER
// than the compiled NinjaTrader.Custom.dll (a bot update was copied in), this add-on compiles
// automatically, the same way the NinjaScript Editor does when you press F5.
//  - Runs once per start, 20 s after NinjaTrader opens (before the bot is normally started).
//  - Nothing happens if there are no new/changed files.
//  - Uses NinjaTrader's own compiler (NinjaTrader.Code.Compiler.Compile), found by reflection,
//    so nothing breaks if a future NinjaTrader version renames it: it only shows a notice
//    telling the user to press F5 in the NinjaScript Editor.
//  - Errors: the old compiled version keeps working; the user gets a short message.
//  - Never compiles while any account has an open position (compiling reloads the bot).
// Needs to be compiled ONE time by hand (F5); after that every update compiles by itself.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJAutoCompileOnStart : AddOnBase
    {
        private static bool alreadyScheduled = false;
        private static readonly object scheduleLock = new object();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJAutoCompileOnStart";
                Description = "Compiles JJ bot updates automatically when NinjaTrader starts.";
            }
            else if (State == State.Active)
            {
                lock (scheduleLock)
                {
                    if (alreadyScheduled) return;
                    alreadyScheduled = true;
                }
                Task.Run(async () =>
                {
                    await Task.Delay(TimeSpan.FromSeconds(20));
                    RunAutoCompile();
                });
            }
        }

        private static void Log(string message)
        {
            try { NinjaTrader.Code.Output.Process("JJ AUTO-COMPILE: " + message, PrintTo.OutputTab1); }
            catch { }
        }

        // JJ_AUTO_COMPILE_APP_MESSAGE_V1 (2026-10-31): no Windows message box any more. The result is
        // written to JJBotData\auto_compile_result.json; the JJ app shows it (in the app language)
        // as a platform message and keeps it in the bell.
        private static void Report(string kind, string account, int errors, List<string> files)
        {
            try
            {
                string dir = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "JJBotData");
                Directory.CreateDirectory(dir);
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("{\"id\":\"").Append(DateTime.UtcNow.Ticks).Append("\",\"kind\":\"").Append(kind)
                  .Append("\",\"account\":\"").Append(Esc(account)).Append("\",\"errors\":").Append(errors)
                  .Append(",\"files\":[");
                if (files != null)
                    for (int i = 0; i < files.Count && i < 12; i++)
                    { if (i > 0) sb.Append(','); sb.Append('"').Append(Esc(Path.GetFileName(files[i]))).Append('"'); }
                sb.Append("],\"at\":\"").Append(DateTime.UtcNow.ToString("o")).Append("\"}");
                string target = Path.Combine(dir, "auto_compile_result.json");
                File.WriteAllText(target + ".tmp", sb.ToString(), System.Text.Encoding.UTF8);
                if (File.Exists(target)) File.Delete(target);
                File.Move(target + ".tmp", target);
            }
            catch { }
        }

        private static string Esc(string value)
        {
            return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        private static void RunAutoCompile()
        {
            try
            {
                string customDir = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "bin", "Custom");
                string dllPath = Path.Combine(customDir, "NinjaTrader.Custom.dll");
                if (!Directory.Exists(customDir) || !File.Exists(dllPath))
                    return; // NinjaTrader itself rebuilds a missing assembly at start

                DateTime dllTime = File.GetLastWriteTimeUtc(dllPath);
                List<string> changed = Directory
                    .EnumerateFiles(customDir, "*.cs", SearchOption.AllDirectories)
                    .Where(file =>
                        file.IndexOf(Path.DirectorySeparatorChar + "obj" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) < 0 &&
                        File.GetLastWriteTimeUtc(file) > dllTime.AddSeconds(2))
                    .ToList();

                if (changed.Count == 0)
                    return;

                // Compiling never touches broker connections, but it RELOADS every NinjaScript
                // (bot window, add-ons, indicators). Never do that with a position open.
                string openOn = null;
                lock (Account.All)
                {
                    foreach (Account account in Account.All)
                    {
                        if (account == null) continue;
                        foreach (Position position in account.Positions)
                        {
                            if (position != null && position.MarketPosition != MarketPosition.Flat)
                            { openOn = account.Name; break; }
                        }
                        if (openOn != null) break;
                    }
                }
                if (openOn != null)
                {
                    Log("hay una posicion abierta en " + openOn + "; NO se compila ahora (se recargaria el bot).");
                    Report("skipped_position", openOn, 0, changed);
                    return;
                }

                Log(changed.Count + " archivo(s) nuevo(s) o cambiado(s) desde la ultima compilacion: " +
                    string.Join(", ", changed.Take(8).Select(Path.GetFileName)) + (changed.Count > 8 ? " ..." : "") +
                    ". Compilando como F5...");

                Type compiler = typeof(NinjaTrader.Code.Output).Assembly.GetType("NinjaTrader.Code.Compiler");
                MethodInfo compile = compiler == null ? null : compiler.GetMethod(
                    "Compile",
                    BindingFlags.Public | BindingFlags.Static,
                    null,
                    new[] { typeof(bool), typeof(bool), typeof(IEnumerable<string>), typeof(IEnumerable<string>) },
                    null);

                if (compile == null)
                {
                    Log("no se encontro el compilador de NinjaTrader en esta version.");
                    Report("manual", "", 0, changed);
                    return;
                }

                // (checkCompileOnly = false, debugBuild = false, filesToIgnore = none, filesInTmp = none)
                object result = compile.Invoke(null, new object[] { false, false, new string[0], new string[0] });

                bool success = false;
                List<string> errors = new List<string>();
                if (result != null)
                {
                    PropertyInfo successProp = result.GetType().GetProperty("Success");
                    if (successProp != null) success = (bool)successProp.GetValue(result, null);

                    PropertyInfo diagProp = result.GetType().GetProperty("Diagnostics");
                    System.Collections.IEnumerable diags = diagProp == null ? null : diagProp.GetValue(result, null) as System.Collections.IEnumerable;
                    if (diags != null)
                    {
                        foreach (object diag in diags)
                        {
                            PropertyInfo sev = diag.GetType().GetProperty("Severity");
                            string severity = sev == null ? "" : Convert.ToString(sev.GetValue(diag, null));
                            if (severity == "Error") errors.Add(diag.ToString());
                        }
                    }
                }

                if (success)
                {
                    Log("compilacion OK - la actualizacion ya esta activa.");
                    Report("applied", "", 0, changed);
                }
                else
                {
                    foreach (string error in errors.Take(10)) Log("ERROR " + error);
                    Log("la compilacion fallo; sigue funcionando la version anterior.");
                    Report("failed", "", errors.Count, changed);
                }
            }
            catch (Exception ex)
            {
                Exception inner = ex is TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
                Log("no se pudo compilar automaticamente: " + inner.Message);
                Report("manual", "", 0, null);
            }
        }
    }
}

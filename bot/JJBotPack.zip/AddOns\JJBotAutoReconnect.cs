// JJBotAutoReconnect.cs (2026-10-31): renamed from JJAutoReconnect.cs so the bot update ships it to every user
// (the app updater only accepts JJBot*/JJCompanyBro*/JJTrade* file names). Code unchanged.
// NinjaTrader 8 - copy into bin/Custom/AddOns, then compile.
using System;
using System.Globalization;
#if !POLICY_ONLY
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
#endif

namespace NinjaTrader.NinjaScript.AddOns
{
    public static class JJReconnectPolicy
    {
        public static bool Due(DateTime eastern, int minutes, string lastDate)
        {
            if (eastern.DayOfWeek == DayOfWeek.Friday || eastern.DayOfWeek == DayOfWeek.Saturday)
                return false;
            double elapsed = eastern.TimeOfDay.TotalMinutes - minutes;
            return elapsed >= 0 && elapsed < 5 && lastDate != eastern.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }
        public static bool Busy(int positions, int orders) { return positions > 0 || orders > 0; }
        public static string Rearm(int previousMinutes, int newMinutes, string lastDate)
        { return previousMinutes == newMinutes ? lastDate : ""; }
    }
#if !POLICY_ONLY
    public class JJReconnectSettings
    {
        public bool Enabled;
        public int Minutes = 19 * 60;
        public string LastDate = "";
        public List<string> Names = new List<string>();
    }

    // V2 (2026-10-30) - remote control from the JJ app / APK through the desktop bridge.
    // The desktop writes remote.xml (this class); the AddOn writes status.json for the app.
    public class JJReconnectRemote
    {
        public string RequestId = "";
        public bool HasSettings;
        public bool Enabled;
        public int Minutes = 19 * 60;
        public List<string> Names = new List<string>();
        public List<string> ReconnectNow = new List<string>();
        // JJ_MANUAL_CONNECT_V1 (2026-10-31): the user turns connections off / on from the app
        public List<string> DisconnectNow = new List<string>();
        public List<string> ConnectNow = new List<string>();
    }

    public class JJAutoReconnect : AddOnBase
    {
        private NTMenuItem parentMenu, menu;
        private Window panel;
        private StackPanel connectionList;
        private TextBox timeBox, logBox;
        private CheckBox enabledBox;
        private TextBlock statusText;
        private DispatcherTimer timer;
        private JJReconnectSettings settings = new JJReconnectSettings();
        private readonly Dictionary<string, ConnectOptions> options = new Dictionary<string, ConnectOptions>();
        private readonly Queue<string> pending = new Queue<string>();
        private readonly List<string> messages = new List<string>();
        private Connection active;
        private ConnectOptions activeOptions;
        private string phase = "", activeName = "";
        private DateTime deadline;
        private int expectedAccounts;
        private bool stopping;
        private readonly TimeZoneInfo eastern = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        private string Folder { get { return Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "JJAutoReconnect"); } }
        private string ConfigPath { get { return Path.Combine(Folder, "settings.xml"); } }
        private string RemotePath { get { return Path.Combine(Folder, "remote.xml"); } }
        private string StatusPath { get { return Path.Combine(Folder, "status.json"); } }
        private string lastRemoteId = "";
        // JJ_RECONNECT_REMOTE_ONCE_V1 (2026-10-31): lastRemoteId lived only in memory, so every
        // NinjaScript compile / NinjaTrader restart re-applied the old remote.xml and its
        // "reconnect now" -> 1_lucyflex was disconnected+reconnected after each compile.
        // Now the applied id is saved to disk, and a "reconnect now" older than 3 min is ignored.
        private bool remoteIdLoaded;
        private string RemoteAppliedPath { get { return Path.Combine(Folder, "remote.applied.txt"); } }
        private DateTime nextRemoteCheckUtc = DateTime.MinValue, nextStatusWriteUtc = DateTime.MinValue;
        private readonly HashSet<string> manualNames = new HashSet<string>();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJAutoReconnect";
                Description = "Reconecta conexiones seleccionadas por horario de Nueva York.";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            ControlCenter center = window as ControlCenter;
            if (center == null || menu != null) return;
            parentMenu = center.FindFirst("ControlCenterMenuItemTools") as NTMenuItem;
            if (parentMenu == null) return;
            menu = new NTMenuItem { Header = "J&J Reconexion programada", Style = Application.Current.TryFindResource("MainMenuItem") as Style };
            menu.Click += OpenPanel;
            parentMenu.Items.Add(menu);
            Load();
            timer = new DispatcherTimer(DispatcherPriority.Background, center.Dispatcher);
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Tick;
            timer.Start();
            Log("Servicio iniciado. " + (settings.Enabled ? "Horario activo." : "Horario desactivado."));
        }

        protected override void OnWindowDestroyed(Window window)
        {
            if (!(window is ControlCenter)) return;
            stopping = true;
            if (timer != null) { timer.Stop(); timer.Tick -= Tick; }
            if (panel != null) panel.Close();
            if (menu != null) { menu.Click -= OpenPanel; parentMenu.Items.Remove(menu); menu = null; }
        }

        private void Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                    using (var stream = File.OpenRead(ConfigPath))
                        settings = (JJReconnectSettings)new XmlSerializer(typeof(JJReconnectSettings)).Deserialize(stream);
                if (settings.Names == null || settings.Minutes < 0 || settings.Minutes >= 1440)
                    throw new InvalidDataException("Configuracion invalida");
            }
            catch (Exception ex) { settings = new JJReconnectSettings(); Log("Configuracion desactivada: " + ex.Message); }
        }

        private void Persist()
        {
            Directory.CreateDirectory(Folder);
            string temp = ConfigPath + ".tmp";
            using (var stream = File.Create(temp)) new XmlSerializer(typeof(JJReconnectSettings)).Serialize(stream, settings);
            if (File.Exists(ConfigPath)) File.Replace(temp, ConfigPath, null);
            else File.Move(temp, ConfigPath);
        }

        private void Log(string text)
        {
            string line = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, eastern).ToString("yyyy-MM-dd HH:mm:ss") + " ET | " + text;
            messages.Add(line);
            if (messages.Count > 150) messages.RemoveAt(0);
            try { Directory.CreateDirectory(Folder); File.AppendAllText(Path.Combine(Folder, "reconnect.log"), line + Environment.NewLine); } catch { }
            if (logBox != null) { logBox.Text = string.Join(Environment.NewLine, messages); logBox.ScrollToEnd(); }
            if (statusText != null) statusText.Text = text;
        }

        private List<Connection> Connections()
        {
            lock (Connection.Connections) return Connection.Connections.ToList();
        }

        private void RefreshList()
        {
            options.Clear();
            lock (NinjaTrader.Core.Globals.ConnectOptions)
                foreach (ConnectOptions item in NinjaTrader.Core.Globals.ConnectOptions)
                    if (!string.IsNullOrEmpty(item.Name)) options[item.Name] = item;
            foreach (Connection connection in Connections())
                if (connection.Options != null && !string.IsNullOrEmpty(connection.Options.Name))
                    options[connection.Options.Name] = connection.Options;
            connectionList.Children.Clear();
            foreach (string name in options.Keys.Union(settings.Names).OrderBy(n => n))
                connectionList.Children.Add(new CheckBox { Content = name, Tag = name, IsChecked = settings.Names.Contains(name), Margin = new Thickness(4) });
        }

        private void OpenPanel(object sender, RoutedEventArgs e)
        {
            if (panel != null) { panel.Show(); panel.Activate(); return; }
            panel = new Window { Title = "J&J - Reconexion de cuentas", Width = 600, Height = 650, MinWidth = 470, MinHeight = 480 };
            var root = new DockPanel { Margin = new Thickness(16) };
            panel.Content = root;
            var top = new StackPanel();
            DockPanel.SetDock(top, Dock.Top); root.Children.Add(top);
            top.Children.Add(new TextBlock { Text = "Reconectar de domingo a jueves. Hora de Nueva York (ajusta horario de verano).", TextWrapping = TextWrapping.Wrap });
            enabledBox = new CheckBox { Content = "Activar reconexion automatica", IsChecked = settings.Enabled, Margin = new Thickness(0,12,0,8) };
            top.Children.Add(enabledBox);
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock { Text = "Hora (24 h): ", VerticalAlignment = VerticalAlignment.Center });
            timeBox = new TextBox { Text = string.Format("{0:00}:{1:00}", settings.Minutes / 60, settings.Minutes % 60), Width = 70 };
            row.Children.Add(timeBox); top.Children.Add(row);
            top.Children.Add(new TextBlock { Text = "Conexiones a reconectar:", Margin = new Thickness(0,12,0,4) });
            connectionList = new StackPanel();
            top.Children.Add(new ScrollViewer { Content = connectionList, Height = 140, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0,8,0,8) };
            var refresh = new Button { Content = "Actualizar lista", Padding = new Thickness(8), Margin = new Thickness(0,0,8,0) };
            refresh.Click += delegate { if (phase == "") RefreshList(); };
            var save = new Button { Content = "Guardar", Padding = new Thickness(8) };
            save.Click += SavePanel;
            buttons.Children.Add(refresh); buttons.Children.Add(save); top.Children.Add(buttons);
            top.Children.Add(new TextBlock { Text = "No cierra operaciones ni cancela ordenes. Si hay actividad, omite el ciclo. Cerrar esta ventana mantiene el servicio activo. No verifica el valor de drawdown del proveedor.", TextWrapping = TextWrapping.Wrap });
            statusText = new TextBlock { Text = "Esperando horario", Margin = new Thickness(0,10,0,8), TextWrapping = TextWrapping.Wrap };
            top.Children.Add(statusText);
            logBox = new TextBox { IsReadOnly = true, TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Text = string.Join(Environment.NewLine, messages) };
            root.Children.Add(logBox);
            panel.Closing += delegate(object s, System.ComponentModel.CancelEventArgs args) { if (!stopping) { args.Cancel = true; panel.Hide(); } };
            RefreshList(); panel.Show();
        }

        private void SavePanel(object sender, RoutedEventArgs e)
        {
            if (phase != "") { MessageBox.Show("Espera a que termine el ciclo actual."); return; }
            TimeSpan time;
            if (!TimeSpan.TryParseExact(timeBox.Text.Trim(), @"hh\:mm", CultureInfo.InvariantCulture, out time))
            { MessageBox.Show("Escribe una hora de 00:00 a 23:59, por ejemplo 19:00."); return; }
            var names = connectionList.Children.OfType<CheckBox>().Where(c => c.IsChecked == true).Select(c => (string)c.Tag).ToList();
            if (enabledBox.IsChecked == true && names.Count == 0) { MessageBox.Show("Selecciona al menos una conexion."); return; }
            var previous = settings;
            settings = new JJReconnectSettings { Enabled = enabledBox.IsChecked == true, Minutes = (int)time.TotalMinutes, Names = names, LastDate = JJReconnectPolicy.Rearm(previous.Minutes, (int)time.TotalMinutes, previous.LastDate) };
            try { Persist(); Log("Guardado: " + timeBox.Text + " ET. " + (settings.Enabled ? "ACTIVO" : "DESACTIVADO")); }
            catch (Exception ex) { settings = previous; Log("ERROR al guardar: " + ex.Message); }
        }

        private void RemoteTick()
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc >= nextRemoteCheckUtc)
            {
                nextRemoteCheckUtc = nowUtc.AddSeconds(2);
                if (!remoteIdLoaded)
                {
                    remoteIdLoaded = true;
                    try { if (File.Exists(RemoteAppliedPath)) lastRemoteId = (File.ReadAllText(RemoteAppliedPath) ?? "").Trim(); }
                    catch { }
                }
                if (File.Exists(RemotePath))
                {
                    JJReconnectRemote remote;
                    using (var stream = File.OpenRead(RemotePath))
                        remote = (JJReconnectRemote)new XmlSerializer(typeof(JJReconnectRemote)).Deserialize(stream);
                    if (remote != null && !string.IsNullOrEmpty(remote.RequestId) && remote.RequestId != lastRemoteId)
                    {
                        if ((nowUtc - File.GetLastWriteTimeUtc(RemotePath)).TotalMinutes > 3 &&
                            remote.ReconnectNow != null && remote.ReconnectNow.Count > 0)
                        {
                            Log("App: orden de reconectar ya vieja (mas de 3 min); ignorada.");
                            remote.ReconnectNow.Clear();
                        }
                        if ((nowUtc - File.GetLastWriteTimeUtc(RemotePath)).TotalMinutes > 3)
                        {
                            if (remote.DisconnectNow != null) remote.DisconnectNow.Clear();
                            if (remote.ConnectNow != null) remote.ConnectNow.Clear();
                        }
                        lastRemoteId = remote.RequestId;
                        ApplyRemote(remote);
                        if (lastRemoteId == remote.RequestId)
                        {
                            try { File.WriteAllText(RemoteAppliedPath, lastRemoteId); }
                            catch (Exception ex) { Log("Control remoto: no se pudo guardar el id aplicado: " + ex.Message); }
                        }
                    }
                }
            }
            if (nowUtc >= nextStatusWriteUtc)
            {
                nextStatusWriteUtc = nowUtc.AddSeconds(5);
                WriteStatus();
            }
        }

        private void ApplyRemote(JJReconnectRemote remote)
        {
            if (remote.HasSettings)
            {
                if (phase != "") { Log("App: ajustes recibidos durante un ciclo; se aplicaran al terminar."); lastRemoteId = ""; return; }
                if (remote.Minutes < 0 || remote.Minutes >= 1440) { Log("App: hora invalida, ignorada."); }
                else
                {
                    var previous = settings;
                    settings = new JJReconnectSettings
                    {
                        Enabled = remote.Enabled,
                        Minutes = remote.Minutes,
                        Names = (remote.Names ?? new List<string>()).Where(n => !string.IsNullOrWhiteSpace(n)).Distinct().ToList(),
                        LastDate = JJReconnectPolicy.Rearm(previous.Minutes, remote.Minutes, previous.LastDate)
                    };
                    try
                    {
                        Persist();
                        Log(string.Format("App: guardado {0:00}:{1:00} ET, {2}, {3} conexion(es).", settings.Minutes / 60, settings.Minutes % 60, settings.Enabled ? "ACTIVO" : "DESACTIVADO", settings.Names.Count));
                        if (connectionList != null) RefreshList();
                    }
                    catch (Exception ex) { settings = previous; Log("App: ERROR al guardar: " + ex.Message); }
                }
            }
            // JJ_MANUAL_CONNECT_V1: manual OFF (never with open positions/orders) and manual ON
            foreach (string name in (remote.DisconnectNow ?? new List<string>()).Where(n => !string.IsNullOrWhiteSpace(n)).Distinct())
            {
                Connection conn = Connections().FirstOrDefault(c => c.Options != null && c.Options.Name == name && c.Status != ConnectionStatus.Disconnected);
                if (conn == null) { Log("App: " + name + " ya estaba desconectada."); continue; }
                if (phase != "" && activeName == name) { Log("App: " + name + " esta en un ciclo de reconexion; intenta de nuevo al terminar."); continue; }
                if (!SafeToDisconnect(conn)) { Log("App: " + name + " NO se desconecto: tiene posiciones u ordenes abiertas."); continue; }
                Log("App: desconexion manual de " + name + ".");
                try { conn.Disconnect(); } catch (Exception ex) { Log("App: error al desconectar " + name + ": " + ex.Message); }
            }
            foreach (string name in (remote.ConnectNow ?? new List<string>()).Where(n => !string.IsNullOrWhiteSpace(n)).Distinct())
            {
                if (Connections().Any(c => c.Options != null && c.Options.Name == name && c.Status != ConnectionStatus.Disconnected))
                { Log("App: " + name + " ya estaba conectada."); continue; }
                ConnectOptions saved;
                lock (NinjaTrader.Core.Globals.ConnectOptions)
                    saved = NinjaTrader.Core.Globals.ConnectOptions.FirstOrDefault(o => o.Name == name);
                if (saved == null) { Log("App: " + name + " no existe en NinjaTrader."); continue; }
                Log("App: conexion manual de " + name + ".");
                try { Connection.Connect(saved); } catch (Exception ex) { Log("App: error al conectar " + name + ": " + ex.Message); }
            }

            var now = (remote.ReconnectNow ?? new List<string>()).Where(n => !string.IsNullOrWhiteSpace(n)).Distinct().ToList();
            if (now.Count > 0)
            {
                if (phase != "") { Log("App: reconexion manual pedida, pero hay un ciclo en curso. Intenta de nuevo al terminar."); return; }
                pending.Clear();
                foreach (string name in now) { pending.Enqueue(name); manualNames.Add(name); }
                Log("App: reconexion manual de " + string.Join(", ", now) + ".");
                Next();
            }
        }

        private static string J(string value)
        {
            if (value == null) return "";
            var sb = new System.Text.StringBuilder();
            foreach (char c in value)
            {
                if (c == '"' || c == '\\') { sb.Append('\\'); sb.Append(c); }
                else if (c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private void WriteStatus()
        {
            var names = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            lock (NinjaTrader.Core.Globals.ConnectOptions)
                foreach (ConnectOptions item in NinjaTrader.Core.Globals.ConnectOptions)
                    if (!string.IsNullOrEmpty(item.Name)) names.Add(item.Name);
            List<Connection> live = Connections();
            foreach (Connection c in live) if (c.Options != null && !string.IsNullOrEmpty(c.Options.Name)) names.Add(c.Options.Name);
            foreach (string n in settings.Names) names.Add(n);
            List<Account> accounts;
            lock (Account.All) accounts = Account.All.ToList();
            var sb = new System.Text.StringBuilder();
            sb.Append("{\"updatedAt\":\"").Append(DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture)).Append("\",");
            sb.Append("\"enabled\":").Append(settings.Enabled ? "true" : "false").Append(',');
            sb.Append("\"minutes\":").Append(settings.Minutes).Append(',');
            sb.Append("\"phase\":\"").Append(J(phase)).Append("\",\"activeName\":\"").Append(J(activeName)).Append("\",");
            sb.Append("\"lastRemoteId\":\"").Append(J(lastRemoteId)).Append("\",");
            sb.Append("\"connections\":[");
            bool first = true;
            foreach (string name in names)
            {
                Connection c = live.FirstOrDefault(x => x.Options != null && x.Options.Name == name);
                string status = c == null ? "Disconnected" : c.Status.ToString();
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"name\":\"").Append(J(name)).Append("\",\"status\":\"").Append(J(status)).Append("\",");
                sb.Append("\"selected\":").Append(settings.Names.Contains(name) ? "true" : "false").Append(",\"accounts\":[");
                bool firstAcc = true;
                if (c != null)
                    foreach (Account a in accounts.Where(a => a.Connection == c))
                    { if (!firstAcc) sb.Append(','); firstAcc = false; sb.Append('"').Append(J(a.Name)).Append('"'); }
                sb.Append("]}");
            }
            sb.Append("],\"log\":[");
            var tail = messages.Skip(Math.Max(0, messages.Count - 15)).ToList();
            for (int i = 0; i < tail.Count; i++) { if (i > 0) sb.Append(','); sb.Append('"').Append(J(tail[i])).Append('"'); }
            sb.Append("]}");
            Directory.CreateDirectory(Folder);
            string temp = StatusPath + ".tmp";
            File.WriteAllText(temp, sb.ToString());
            if (File.Exists(StatusPath)) File.Replace(temp, StatusPath, null); else File.Move(temp, StatusPath);
        }

        // JJ_MANUAL_CONNECT_V1: like Safe() but a connection without accounts may be turned off
        private bool SafeToDisconnect(Connection connection)
        {
            List<Account> accounts;
            lock (Account.All) accounts = Account.All.Where(a => a.Connection == connection).ToList();
            foreach (Account account in accounts)
            {
                int positions, orders;
                lock (account.Positions) positions = account.Positions.Count(p => p.MarketPosition != MarketPosition.Flat || p.Quantity != 0);
                lock (account.Orders) orders = account.Orders.Count(o => o.OrderState != OrderState.Filled && o.OrderState != OrderState.Cancelled && o.OrderState != OrderState.Rejected);
                if (JJReconnectPolicy.Busy(positions, orders)) return false;
            }
            return true;
        }

        private bool Safe(Connection connection)
        {
            List<Account> accounts;
            lock (Account.All) accounts = Account.All.Where(a => a.Connection == connection).ToList();
            if (accounts.Count == 0) return false;
            foreach (Account account in accounts)
            {
                int positions, orders;
                lock (account.Positions) positions = account.Positions.Count(p => p.MarketPosition != MarketPosition.Flat || p.Quantity != 0);
                lock (account.Orders) orders = account.Orders.Count(o => o.OrderState != OrderState.Filled && o.OrderState != OrderState.Cancelled && o.OrderState != OrderState.Rejected);
                if (JJReconnectPolicy.Busy(positions, orders)) return false;
            }
            return true;
        }

        private void Tick(object sender, EventArgs e)
        {
            try { RemoteTick(); } catch (Exception ex) { Log("Control remoto: " + ex.Message); }
            try
            {
                if (phase != "") { Advance(); return; }
                if (!settings.Enabled) return;
                DateTime now = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, eastern);
                if (!JJReconnectPolicy.Due(now, settings.Minutes, settings.LastDate)) return;
                settings.LastDate = now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                // Persist the attempt before any external side effect (also prevents repeats after restart).
                try { Persist(); }
                catch (Exception ex) { settings.Enabled = false; Log("Desactivado: no se pudo guardar la tentativa: " + ex.Message); return; }
                pending.Clear();
                foreach (string name in settings.Names) pending.Enqueue(name);
                Log("Iniciando ciclo programado.");
                Next();
            }
            catch (Exception ex) { pending.Clear(); phase = ""; Log("ERROR; ciclo detenido: " + ex.Message + ". Revisa la conexion manualmente."); }
        }

        private void Next()
        {
            phase = "";
            if (pending.Count == 0) { Log("Ciclo terminado. Consulta el registro de cada conexion; verifica el drawdown en el bot."); return; }
            activeName = pending.Dequeue();
            active = Connections().FirstOrDefault(c => c.Options.Name == activeName && c.Status == ConnectionStatus.Connected);
            bool manual = manualNames.Remove(activeName);
            if (active == null && manual)
            {
                // Manual request from the app on a disconnected connection: just connect it (no disconnect step).
                expectedAccounts = 0;
                phase = "pause"; deadline = DateTime.UtcNow;
                Log(activeName + ": conexion manual pedida desde la app.");
                return;
            }
            if (active == null)
            {
                // JJ_MANUAL_CONNECT_V1: a checked connection that is OFF at the scheduled time is connected
                bool alreadyComing = Connections().Any(c => c.Options != null && c.Options.Name == activeName && c.Status != ConnectionStatus.Disconnected);
                ConnectOptions offline = null;
                lock (NinjaTrader.Core.Globals.ConnectOptions)
                    offline = NinjaTrader.Core.Globals.ConnectOptions.FirstOrDefault(o => o.Name == activeName);
                if (alreadyComing) Log(activeName + ": OMITIDA; ya se esta conectando.");
                else if (offline == null) Log(activeName + ": OMITIDA; no se encontro el perfil guardado de conexion.");
                else
                {
                    Log(activeName + ": estaba desconectada; conectando.");
                    try { Connection.Connect(offline); } catch (Exception ex) { Log(activeName + ": ERROR al conectar: " + ex.Message); }
                }
                phase = "next"; return;
            }
            if (!Safe(active)) { Log(activeName + ": OMITIDA; hay posiciones, ordenes o no se pudieron validar las cuentas."); phase = "next"; return; }
            // Use the saved profile, not the runtime connection options: the adapter
            // may clear runtime authentication fields when it disconnects.
            lock (NinjaTrader.Core.Globals.ConnectOptions)
                activeOptions = NinjaTrader.Core.Globals.ConnectOptions.FirstOrDefault(o => o.Name == activeName);
            if (activeOptions == null)
            { Log(activeName + ": OMITIDA; no se encontro el perfil guardado de conexion."); phase = "next"; return; }
            lock (Account.All) expectedAccounts = Account.All.Count(a => a.Connection == active);
            phase = "disconnecting"; deadline = DateTime.UtcNow.AddSeconds(45);
            Log(activeName + ": desconectando.");
            active.Disconnect();
        }

        private void Advance()
        {
            if (phase == "next") { Next(); return; }
            if (phase == "disconnecting")
            {
                if (active.Status == ConnectionStatus.Disconnected && active.PriceStatus == ConnectionStatus.Disconnected)
                { phase = "pause"; deadline = DateTime.UtcNow.AddSeconds(5); return; }
                if (DateTime.UtcNow > deadline) { Log(activeName + ": ERROR; no se confirmo desconexion. Sin reconectar a ciegas."); pending.Clear(); phase = ""; }
                return;
            }
            if (phase == "pause")
            {
                if (DateTime.UtcNow < deadline) return;
                // A provider/user may already have reconnected. Never create a duplicate connection.
                active = Connections().FirstOrDefault(c => c.Options.Name == activeName && c.Status != ConnectionStatus.Disconnected);
                if (active == null)
                {
                    ConnectOptions saved;
                    lock (NinjaTrader.Core.Globals.ConnectOptions)
                        saved = NinjaTrader.Core.Globals.ConnectOptions.FirstOrDefault(o => o.Name == activeName);
                    if (saved == null) throw new InvalidOperationException("No se encontro la configuracion guardada de " + activeName);
                    active = Connection.Connect(saved);
                }
                phase = "connecting"; deadline = DateTime.UtcNow.AddSeconds(90);
                Log(activeName + ": esperando conexion y cuentas."); return;
            }
            if (phase == "connecting")
            {
                if (active == null) active = Connections().FirstOrDefault(c => c.Options.Name == activeName);
                int count = 0;
                if (active != null) lock (Account.All) count = Account.All.Count(a => a.Connection == active);
                if (active != null && active.Status == ConnectionStatus.Connected && active.PriceStatus == ConnectionStatus.Connected && count >= expectedAccounts)
                { phase = "settle"; deadline = DateTime.UtcNow.AddSeconds(10); return; }
                if (DateTime.UtcNow > deadline) { Log(activeName + ": ERROR; no se recuperaron conexion/cuentas en 90 s. Revision manual necesaria."); pending.Clear(); phase = ""; }
                return;
            }
            if (phase == "settle" && DateTime.UtcNow >= deadline)
            {
                if (active.Status != ConnectionStatus.Connected || active.PriceStatus != ConnectionStatus.Connected)
                { Log(activeName + ": ERROR; conexion inestable. Ciclo detenido."); pending.Clear(); phase = ""; return; }
                Log(activeName + ": RECONECTADA; se recuperaron las cuentas. Drawdown no verificado por este AddOn.");
                phase = "next";
            }
        }
    }
#endif
}

﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT BARS / DATA ENGINE
    // Stage 14 structural extraction only.
    //
    // Existing BarsRequest startup/shutdown and M5/Range-20
    // update callbacks are moved exactly as-is.
    //
    // No bars period, subscription, callback behavior,
    // signal timing, or trading logic was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void StartBarsEngine()
        {
            StopBarsEngine();

            // V1.6.34 - Level 2 is OBSERVE ONLY. It starts/stops with
            // the bot data engine but has zero authority over entries.
            StartLevel2Observe();

            barsReady = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestDirectionalPressure = "NEUTRAL";
            latestDirectionalLongPressureScore = 0;
            latestDirectionalShortPressureScore = 0;
            lastDirectionalPressureLogKey = string.Empty;
            lastDirectionalSafetyBlockKey = string.Empty;

            latestM5ContextReady = false;
            latestRangeMomentumState = "WAITING RANGE";

            try
            {
                barsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                barsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 5
                    };

                // Neutral template for data collection.
                // We enforce the NY bot time window separately later.
                barsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                barsRequest.Update +=
                    OnBarsRequestUpdate;

                barsRequestSubscribed = true;

                barsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnBarsRequestCompleted
                    )
                );

                // 1-HOUR CONTEXT
                h1BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h1BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 60
                    };

                h1BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h1BarsRequest.Update +=
                    OnH1BarsRequestUpdate;

                h1BarsRequestSubscribed = true;

                h1BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH1BarsRequestCompleted
                    )
                );

                // 4-HOUR CONTEXT
                h4BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h4BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 240
                    };

                h4BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h4BarsRequest.Update +=
                    OnH4BarsRequestUpdate;

                h4BarsRequestSubscribed = true;

                h4BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH4BarsRequestCompleted
                    )
                );

                // Internal 20-tick Range series. This is independent
                // from the chart the user has open.
                rangeBarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                rangeBarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Range,

                        Value = MomentumRangeTicks
                    };

                rangeBarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                rangeBarsRequest.Update +=
                    OnRangeBarsRequestUpdate;

                rangeBarsRequestSubscribed = true;

                rangeBarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnRangeBarsRequestCompleted
                    )
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BARS REQUEST EXCEPTION: "
                    + ex.Message
                );

                SetEngineError(
                    "DATA ERROR"
                );
            }
        }
        private void OnBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "BARS REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "DATA ERROR"
                        );
                    })
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count < SlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 5M BARS TO CALCULATE EMA 50."
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "WAITING FOR DATA"
                        );
                    })
                );

                return;
            }

            barsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            // Do not fire a historical crossover immediately at startup.
            lastSignalBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateSignalFromBars(
                request.Bars,
                false
            );

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    statusText.Text =
                        "● RUNNING";

                    statusText.Foreground =
                        Brushes.LimeGreen;
                })
            );

            PrintBotMessage(
                "5M DATA READY | BARS: "
                + request.Bars.Count
            );
        }
        private void OnRangeBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "RANGE REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH RANGE BARS FOR MOMENTUM."
                );

                return;
            }

            rangeBarsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            lastRangeBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateMomentumFromRangeBars(
                request.Bars,
                false
            );

            PrintBotMessage(
                "RANGE DATA READY | "
                + MomentumRangeTicks
                + " TICKS | BARS: "
                + request.Bars.Count
            );
        }
        private void OnRangeBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !rangeBarsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count <
                        MomentumAverageLookback +
                        MomentumBreakoutLookback + 3
                )
                {
                    return;
                }

                DateTime currentRangeBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newRangeBarStarted =
                    lastRangeBarTime != DateTime.MinValue &&
                    currentRangeBarTime != lastRangeBarTime;

                if (
                    rangeBarsRequest == null ||
                    rangeBarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateMomentumFromRangeBars(
                    rangeBarsRequest.Bars,
                    newRangeBarStarted
                );

                // Capital protection is evaluated on every Range update,
                // not only when a new Range bar closes.
                int liveRangeIndex =
                    rangeBarsRequest.Bars.Count - 1;

                if (liveRangeIndex >= 0)
                {
                    double liveRangePrice =
                        rangeBarsRequest.Bars.GetClose(
                            liveRangeIndex
                        );

                    double liveRangeHigh =
                        rangeBarsRequest.Bars.GetHigh(
                            liveRangeIndex
                        );

                    double liveRangeLow =
                        rangeBarsRequest.Bars.GetLow(
                            liveRangeIndex
                        );

                    DateTime liveRangeNy =
                        ConvertToNewYorkTime(
                            rangeBarsRequest.Bars.GetTime(
                                liveRangeIndex
                            )
                        );

                    UpdateBreakevenFollowThrough(
                        liveRangeHigh,
                        liveRangeLow,
                        liveRangeNy
                    );

                    UpdateUnrealizedPnL(
                        liveRangePrice
                    );

                    // Daily target protection has priority over
                    // the normal per-trade trailing logic.
                    UpdateDailyTargetProtection(
                        liveRangePrice
                    );

                    UpdateMomentumTrailingStop(
                        liveRangePrice
                    );

                    TrySmartScaleIn(
                        liveRangePrice
                    );

                    CheckForceFlatTime();
                    CheckDailyLossEmergency();
                }

                if (newRangeBarStarted)
                {
                    lastRangeBarTime =
                        currentRangeBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "RANGE UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void OnBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !barsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count < SlowEmaPeriod + 2
                )
                {
                    return;
                }

                DateTime currentBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newBarStarted =
                    lastSignalBarTime != DateTime.MinValue &&
                    currentBarTime != lastSignalBarTime;

                // Update current bias/EMA display on every real-time bar update.
                if (barsRequest == null || barsRequest.Bars == null)
                    return;

                UpdateSignalFromBars(
                    barsRequest.Bars,
                    newBarStarted
                );

                if (newBarStarted)
                {
                    lastSignalBarTime =
                        currentBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BAR UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void StopBarsEngine()
        {
            // V1.6.34 - Always detach market-depth subscriptions from
            // the exact instrument thread before the data engine stops.
            StopLevel2Observe();

            barsReady = false;

            if (barsRequest != null)
            {
                try
                {
                    if (barsRequestSubscribed)
                    {
                        barsRequest.Update -=
                            OnBarsRequestUpdate;

                        barsRequestSubscribed =
                            false;
                    }

                    barsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "BARS CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                barsRequest = null;
            }

            if (h1BarsRequest != null)
            {
                try
                {
                    if (h1BarsRequestSubscribed)
                    {
                        h1BarsRequest.Update -=
                            OnH1BarsRequestUpdate;

                        h1BarsRequestSubscribed =
                            false;
                    }

                    h1BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "1H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h1BarsRequest = null;
            }

            if (h4BarsRequest != null)
            {
                try
                {
                    if (h4BarsRequestSubscribed)
                    {
                        h4BarsRequest.Update -=
                            OnH4BarsRequestUpdate;

                        h4BarsRequestSubscribed =
                            false;
                    }

                    h4BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "4H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h4BarsRequest = null;
            }

            h1BarsReady = false;
            h4BarsReady = false;

            lastH1BarTime =
                DateTime.MinValue;

            lastH4BarTime =
                DateTime.MinValue;

            if (rangeBarsRequest != null)
            {
                try
                {
                    if (rangeBarsRequestSubscribed)
                    {
                        rangeBarsRequest.Update -=
                            OnRangeBarsRequestUpdate;

                        rangeBarsRequestSubscribed =
                            false;
                    }

                    rangeBarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "RANGE CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                rangeBarsRequest = null;
            }

            rangeBarsReady = false;
            lastRangeBarTime =
                DateTime.MinValue;

            lastSignalBarTime =
                DateTime.MinValue;

            ClearEmaCaches();
        }

    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT BARS / DATA ENGINE
    // Includes timer-driven Range subscription recovery. Bar periods,
    // order/risk rules and the existing entry freshness limit are preserved.
    // =========================================================
    public partial class JJBotWindow
    {
        private readonly object rangeRecoverySync = new object();
        private DateTime rangeRequestStartedUtc = DateTime.MinValue;
        private DateTime rangeRecoveryLastUtc = DateTime.MinValue;
        private DateTime rangeLagSinceUtc = DateTime.MinValue;
        private DateTime rangeRecoveryCheckUtc = DateTime.MinValue;
        private EventHandler<BarsUpdateEventArgs> rangeUpdateHandler;

        private void RangeRecoveryWatchdog(DateTime nowUtc)
        {
            if (!botRunning || IsPlaybackStrategyClockActive()
                || (nowUtc - rangeRecoveryCheckUtc).TotalSeconds < 5) return;
            rangeRecoveryCheckUtc = nowUtc;
            // Never wait on the UI/timer thread for a busy Range callback.
            if (!System.Threading.Monitor.TryEnter(rangeRecoverySync)) return;
            BarsRequest retired = null;
            try
            {
                if (!botRunning) return;
                DateTime callbackUtc = rangeFeedDiagnostic.LastCallbackUtc;
                DateTime barTime = rangeFeedDiagnostic.LastCallbackBarTime;
                double lag = barTime == DateTime.MinValue ? 0
                    : (V184ReferenceNowNy() - ConvertToNewYorkTime(barTime)).TotalSeconds;
                bool liveTrades = v184LastTradeUtc != DateTime.MinValue
                    && (nowUtc - v184LastTradeUtc).TotalSeconds >= 0
                    && (nowUtc - v184LastTradeUtc).TotalSeconds < 10;
                // A quiet Range bar can keep its opening timestamp while ticks
                // still arrive. Sustained-lag reloads require timestamp progress.
                bool advancing = (nowUtc - rangeFeedDiagnostic.LastAdvanceUtc).TotalSeconds < 15;
                if (lag > 30 && liveTrades && advancing)
                {
                    if (rangeLagSinceUtc == DateTime.MinValue) rangeLagSinceUtc = nowUtc;
                }
                else rangeLagSinceUtc = DateTime.MinValue;

                if (barTime != DateTime.MinValue)
                    V184ReportBarLag(ConvertToNewYorkTime(barTime));
                double callbackAge = (nowUtc - (callbackUtc == DateTime.MinValue
                    ? rangeRequestStartedUtc : callbackUtc)).TotalSeconds;
                if (!JJRangeRecoveryPolicy.ShouldRecover(liveTrades, botRunning, false,
                    (nowUtc - rangeRequestStartedUtc).TotalSeconds, callbackAge, lag,
                    rangeLagSinceUtc == DateTime.MinValue ? 0 : (nowUtc - rangeLagSinceUtc).TotalSeconds,
                    (nowUtc - rangeRecoveryLastUtc).TotalSeconds)) return;

                rangeRecoveryLastUtc = nowUtc;
                PrintBotMessage("RANGE WATCHDOG | CallbackAge " + callbackAge.ToString("0.0")
                    + "s | BarLag " + lag.ToString("0.0")
                    + "s | Action: RE-REQUEST RANGE ONLY | Entry freshness guards remain active");
                retired = rangeBarsRequest;
                rangeBarsReady = false;
                rangeBarsRequest = null;
                rangeBarsRequestSubscribed = false;
                if (retired != null && rangeUpdateHandler != null) retired.Update -= rangeUpdateHandler;
                rangeUpdateHandler = null;
                rangeFeedDiagnostic.Reset();
                rangeMomentumCache.Reset();
                rangeLagSinceUtc = DateTime.MinValue;
                lastRangeBarTime = DateTime.MinValue;
                latestRangeMomentumState = "WAITING RANGE RECOVERY";
                StartRangeSubscription();
            }
            catch (Exception ex)
            {
                PrintBotMessage("RANGE WATCHDOG ERROR: " + ex.Message);
            }
            finally
            {
                System.Threading.Monitor.Exit(rangeRecoverySync);
                // Dispose outside the callback gate: NinjaTrader may wait for an
                // already queued callback. It must be able to reject the old sender.
                if (retired != null)
                {
                    try { retired.Dispose(); }
                    catch (Exception ex) { PrintBotMessage("RANGE WATCHDOG CLEANUP ERROR: " + ex.Message); }
                }
            }
        }

        private void StartRangeSubscription()
        {
            rangeRequestStartedUtc = DateTime.UtcNow;
            BarsRequest fresh = new BarsRequest(selectedInstrument, BarsBack);
            fresh.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Range, Value = MomentumRangeTicks };
            fresh.TradingHours = TradingHours.Get("Default 24 x 7");
            rangeBarsRequest = fresh;
            // BarsRequest may forward a BarsSeries as sender. Capture this request
            // explicitly so obsolete callbacks can still be rejected by identity.
            rangeUpdateHandler = (sender, args) => OnRangeBarsRequestUpdate(fresh, args);
            fresh.Update += rangeUpdateHandler;
            rangeBarsRequestSubscribed = true;
            fresh.Request(new Action<BarsRequest, ErrorCode, string>(OnRangeBarsRequestCompleted));
        }

        private void StartBarsEngine()
        {
            StopBarsEngine();

            // Diagnostic only: do not carry observations across subscriptions.
            rangeFeedDiagnostic.Reset();
            rangeMomentumCache.Reset();
            lastRangeDiagnosticReportUtc = DateTime.MinValue;
            rangeLagSinceUtc = DateTime.MinValue;
            rangeRecoveryLastUtc = DateTime.MinValue;
            rangeRecoveryCheckUtc = DateTime.MinValue;

            // V1.6.34 - Level 2 is OBSERVE ONLY. It starts/stops with
            // the bot data engine but has zero authority over entries.
            StartLevel2Observe();

            barsReady = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestDirectionalPressure = "NEUTRAL";
            latestDirectionalLongPressureScore = 0;
            latestDirectionalShortPressureScore = 0;
            lastDirectionalPressureLogKey = string.Empty;
            lastDirectionalSafetyBlockKey = string.Empty;

            latestM5ContextReady = false;
            latestRangeMomentumState = "WAITING RANGE";

            try
            {
                barsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                barsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 5
                    };

                // Neutral template for data collection.
                // We enforce the NY bot time window separately later.
                barsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                barsRequest.Update +=
                    OnBarsRequestUpdate;

                barsRequestSubscribed = true;

                barsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnBarsRequestCompleted
                    )
                );

                // 1-HOUR CONTEXT
                h1BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h1BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 60
                    };

                h1BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h1BarsRequest.Update +=
                    OnH1BarsRequestUpdate;

                h1BarsRequestSubscribed = true;

                h1BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH1BarsRequestCompleted
                    )
                );

                // 4-HOUR CONTEXT
                h4BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h4BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 240
                    };

                h4BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h4BarsRequest.Update +=
                    OnH4BarsRequestUpdate;

                h4BarsRequestSubscribed = true;

                h4BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH4BarsRequestCompleted
                    )
                );

                // Range startup and watchdog use the same request setup.
                StartRangeSubscription();

                // V1.7.32 - CORE20 data (1m levels, Range-60, tape delta).
                // Only starts when Strategy = CORE20.
                StartCore20Engine();

                // V1.7.85 - join the market brain (signal families of this profile's strategy)
                V185RegisterSignalFamilies();
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BARS REQUEST EXCEPTION: "
                    + ex.Message
                );

                SetEngineError(
                    "DATA ERROR"
                );
            }
        }
        private void OnBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "BARS REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "DATA ERROR"
                        );
                    })
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count < SlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 5M BARS TO CALCULATE EMA 50."
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "WAITING FOR DATA"
                        );
                    })
                );

                return;
            }

            barsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            // Do not fire a historical crossover immediately at startup.
            lastSignalBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateSignalFromBars(
                request.Bars,
                false
            );

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    statusText.Text =
                        "● RUNNING";

                    statusText.Foreground =
                        Brushes.LimeGreen;
                })
            );

            PrintBotMessage(
                "5M DATA READY | BARS: "
                + request.Bars.Count
            );
        }
        private void OnRangeBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            lock (rangeRecoverySync)
            {
            if (!botRunning || !object.ReferenceEquals(request, rangeBarsRequest)) return;
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "RANGE REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH RANGE BARS FOR MOMENTUM."
                );

                return;
            }

            rangeBarsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            lastRangeBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateMomentumFromRangeBars(
                request.Bars,
                false
            );

            PrintBotMessage(
                "RANGE DATA READY | "
                + MomentumRangeTicks
                + " TICKS | BARS: "
                + request.Bars.Count
            );
            }
        }
        private void OnRangeBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            lock (rangeRecoverySync)
            {
            if (
                !botRunning ||
                !object.ReferenceEquals(sender, rangeBarsRequest) ||
                !rangeBarsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            long callbackStarted = System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count <
                        MomentumAverageLookback +
                        MomentumBreakoutLookback + 3
                )
                {
                    return;
                }

                DateTime currentRangeBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                // Count live callbacks separately from the initial historical load.
                rangeFeedDiagnostic.RecordCallback(DateTime.UtcNow, count, currentRangeBarTime);

                // V1.7.26 - PLAYBACK CLOCK WIRING.
                // TimeManager owns the clock, but it must be fed by an
                // authoritative replay timestamp. Range Bars update continuously
                // during Market Replay, so this keeps StrategyClockNY aligned
                // with the replay instead of falling back to the PC wall clock.
                UpdatePlaybackStrategyClock(
                    currentRangeBarTime
                );

                bool newRangeBarStarted =
                    lastRangeBarTime != DateTime.MinValue &&
                    currentRangeBarTime != lastRangeBarTime;

                // V1.7.85 - market brain heartbeat / stale take-over + status line
                V185SignalBrainTick();
                V185LogBrainStatus();

                // V1.7.84 - local copy: StopBot can null rangeBarsRequest while this
                // handler runs ("RANGE UPDATE ERROR: Object reference not set...").
                BarsRequest v184Req = rangeBarsRequest;
                Bars v184Bars = v184Req != null ? v184Req.Bars : null;

                if (
                    v184Req == null ||
                    v184Bars == null
                )
                {
                    return;
                }

                UpdateMomentumFromRangeBars(
                    v184Bars,
                    newRangeBarStarted && JJRangeRecoveryPolicy.CanEvaluateClosedBar(
                        V184ReferenceNowNy(),
                        ConvertToNewYorkTime(v184Bars.GetTime(Math.Max(0, v184Bars.Count - 2))),
                        IsPlaybackStrategyClockActive())
                );

                // Capital protection is evaluated on every Range update,
                // not only when a new Range bar closes.
                int liveRangeIndex =
                    v184Bars.Count - 1;

                if (liveRangeIndex >= 0)
                {
                    // V1.7.84 - use the freshest live trade (MarketData) when available:
                    // the Range BarsRequest can lag the market at the open, which produced
                    // a phantom +$626 unrealized (13-oct) and an MFE of $12 on a +30-pt TP (15-oct).
                    double liveRangePrice =
                        V184FreshLivePrice(
                            v184Bars.GetClose(
                                liveRangeIndex
                            )
                        );

                    double liveRangeHigh =
                        v184Bars.GetHigh(
                            liveRangeIndex
                        );

                    double liveRangeLow =
                        v184Bars.GetLow(
                            liveRangeIndex
                        );

                    DateTime liveRangeNy =
                        ConvertToNewYorkTime(
                            v184Bars.GetTime(
                                liveRangeIndex
                            )
                        );

                    UpdateBreakevenFollowThrough(
                        liveRangeHigh,
                        liveRangeLow,
                        liveRangeNy
                    );

                    // V1.7.84 - reports when the Range bars run behind the clock (Friday they ran
                    // 45-70 s late at the open) and blocks HYBRID entries while they do.
                    V184ReportBarLag(liveRangeNy);

                    // V1.7.84 - same lock as the tick-driven protection (JJBotV184Fixes.cs) so the two
                    // never run the trade management at the same time.
                    lock (v184MgmtLock)
                    {
                        v184LastMgmtUtc = DateTime.UtcNow;

                        UpdateUnrealizedPnL(
                            liveRangePrice
                        );

                        // Daily target protection has priority over
                        // the normal per-trade trailing logic.
                        UpdateDailyTargetProtection(
                            liveRangePrice
                        );

                        UpdateMomentumTrailingStop(
                            liveRangePrice
                        );

                        TrySmartScaleIn(
                            liveRangePrice
                        );
                    }

                    CheckForceFlatTime();
                    CheckDailyLossEmergency();
                }

                if (newRangeBarStarted)
                {
                    lastRangeBarTime =
                        currentRangeBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "RANGE UPDATE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                rangeFeedDiagnostic.RecordRangeWork(
                    (System.Diagnostics.Stopwatch.GetTimestamp() - callbackStarted) * 1000.0
                    / System.Diagnostics.Stopwatch.Frequency);
            }
            }
        }
        private void OnBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !barsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count < SlowEmaPeriod + 2
                )
                {
                    return;
                }

                DateTime currentBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                // V1.7.26 - Secondary Playback clock feed from the 5m stream.
                // Monotonic protection in TimeManager prevents any older
                // callback from moving the replay clock backwards.
                UpdatePlaybackStrategyClock(
                    currentBarTime
                );

                bool newBarStarted =
                    lastSignalBarTime != DateTime.MinValue &&
                    currentBarTime != lastSignalBarTime;

                // Update current bias/EMA display on every real-time bar update.
                if (barsRequest == null || barsRequest.Bars == null)
                    return;

                UpdateSignalFromBars(
                    barsRequest.Bars,
                    newBarStarted
                );

                if (newBarStarted)
                {
                    lastSignalBarTime =
                        currentBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BAR UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void StopBarsEngine()
        {
            // V1.7.85 - hand the signal brain role to the next profile
            V185UnregisterSignalFamilies();

            // V1.6.34 - Always detach market-depth subscriptions from
            // the exact instrument thread before the data engine stops.
            StopLevel2Observe();

            // V1.7.32 - CORE20 data engine.
            StopCore20Engine();

            barsReady = false;

            if (barsRequest != null)
            {
                try
                {
                    if (barsRequestSubscribed)
                    {
                        barsRequest.Update -=
                            OnBarsRequestUpdate;

                        barsRequestSubscribed =
                            false;
                    }

                    barsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "BARS CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                barsRequest = null;
            }

            if (h1BarsRequest != null)
            {
                try
                {
                    if (h1BarsRequestSubscribed)
                    {
                        h1BarsRequest.Update -=
                            OnH1BarsRequestUpdate;

                        h1BarsRequestSubscribed =
                            false;
                    }

                    h1BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "1H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h1BarsRequest = null;
            }

            if (h4BarsRequest != null)
            {
                try
                {
                    if (h4BarsRequestSubscribed)
                    {
                        h4BarsRequest.Update -=
                            OnH4BarsRequestUpdate;

                        h4BarsRequestSubscribed =
                            false;
                    }

                    h4BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "4H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h4BarsRequest = null;
            }

            h1BarsReady = false;
            h4BarsReady = false;

            lastH1BarTime =
                DateTime.MinValue;

            lastH4BarTime =
                DateTime.MinValue;

            if (rangeBarsRequest != null)
            {
                try
                {
                    if (rangeBarsRequestSubscribed)
                    {
                        if (rangeUpdateHandler != null)
                            rangeBarsRequest.Update -= rangeUpdateHandler;
                        rangeUpdateHandler = null;

                        rangeBarsRequestSubscribed =
                            false;
                    }

                    rangeBarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "RANGE CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                rangeBarsRequest = null;
            }

            rangeBarsReady = false;
            lastRangeBarTime =
                DateTime.MinValue;

            lastSignalBarTime =
                DateTime.MinValue;

            ClearEmaCaches();
        }

    }
}

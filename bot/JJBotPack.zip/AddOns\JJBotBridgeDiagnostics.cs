using System;
using System.Diagnostics;
using System.Globalization;
using System.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    // Read-only diagnostics. No trading or recovery actions.
    public static class JJBridgeDiagnosticRecord
    {
        public static double ElapsedMs(long started)
        {
            return (Stopwatch.GetTimestamp() - started) * 1000.0 / Stopwatch.Frequency;
        }

        public static string Format(string phase, string id, string detail)
        {
            return "BRIDGE DIAGNOSTIC | UTC: " + DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture)
                + " | Event: " + phase + " | ID: " + id + " | " + detail;
        }
    }

    public partial class JJBotWindow
    {
        private int bridgeDiagnosticPendingLogs;
        private long bridgeDiagnosticLastTick;
        private long bridgeDiagnosticLastTickLog;

        // V1.7.100 - the per-request HTTP trace (56,000 lines/day per profile) is OFF.
        // Errors (BUILD_ERROR / HTTP_ERROR / HTTP_EXCEPTION) are still logged.
        private const bool V1100BridgeTraceEnabled = false;

        private void BridgeDiagnosticTick()
        {
            if (!V1100BridgeTraceEnabled) return;
            long now = Stopwatch.GetTimestamp();
            long previous = Interlocked.Exchange(ref bridgeDiagnosticLastTick, now);
            if (bridgeDiagnosticLastTickLog != 0
                && JJBridgeDiagnosticRecord.ElapsedMs(bridgeDiagnosticLastTickLog) < 30000) return;
            bridgeDiagnosticLastTickLog = now;
            BridgeDiagnostic("PUBLISH_TICK", "none", "PreviousTickGapMs: "
                + (previous == 0 ? "FIRST" : JJBridgeDiagnosticRecord.ElapsedMs(previous).ToString("0.0", CultureInfo.InvariantCulture)));
        }

        private void BridgeDiagnostic(string phase, string id, string detail)
        {
            if (!V1100BridgeTraceEnabled
                && phase != "BUILD_ERROR" && phase != "HTTP_ERROR" && phase != "HTTP_EXCEPTION")
                return;

            // Embed the observation time before dispatching. UI congestion can delay
            // the usual persistent bot log; UTC inside the message remains authoritative.
            try
            {
                string message = JJBridgeDiagnosticRecord.Format(phase, id, detail);
                if (Interlocked.Increment(ref bridgeDiagnosticPendingLogs) > 64)
                {
                    Interlocked.Decrement(ref bridgeDiagnosticPendingLogs);
                    return;
                }
                try
                {
                    Dispatcher.BeginInvoke(new Action(delegate
                    {
                        try { AppendVisualLog(message); }
                        catch { /* Keep diagnostic output failures off the UI error path. */ }
                        finally { Interlocked.Decrement(ref bridgeDiagnosticPendingLogs); }
                    }));
                }
                catch { Interlocked.Decrement(ref bridgeDiagnosticPendingLogs); }
            }
            catch { /* Diagnostic failure must not change the bridge. */ }
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ AI CORE - CENTRAL MARKET DECISION BUS
    // RECOVERY BUILD
    // =========================================================
    // No profile is master.
    //
    // Profiles may OBSERVE the same market and submit a candidate only
    // after the ORIGINAL STABLE Final Entry Authority says EXECUTE.
    // This independent core commits ONE market decision per instrument/event.
    // Every profile then receives the SAME decision and applies only its own
    // account/session/risk authority before order submission.
    //
    // This file does NOT alter the stable signal logic, Smart Retest,
    // Opening logic, Learning, configured SL, Profit Retention, trailing,
    // scale-in or trade management.
    // =========================================================
    public sealed class JJCentralMarketDecision
    {
        public string DecisionId;
        public string InstrumentName;
        public string ObserverProfileId;
        public bool IsLong;
        public DateTime SignalBarTime;
        public string Strategy;
        public string Route;
        public string RouteReason;
        public string StructureSetupKey;
        public bool OpeningEntry;
        public int SetupConfidence;
        public string SetupQuality;
        public string SetupTiming;
        public string ManipulationState;
        public string LearningStructure;
        public DateTime CommittedUtc;
    }

    public static class JJBotCentralBrain
    {
        private static readonly object SyncRoot =
            new object();

        private static readonly Dictionary<string, JJCentralMarketDecision>
            LatestByInstrument =
                new Dictionary<string, JJCentralMarketDecision>(
                    StringComparer.OrdinalIgnoreCase
                );

        public static event Action<JJCentralMarketDecision>
            DecisionCommitted;

        public static bool TryCommitDecision(
            JJCentralMarketDecision proposal)
        {
            if (
                proposal == null ||
                string.IsNullOrWhiteSpace(
                    proposal.InstrumentName
                )
            )
            {
                return false;
            }

            JJCentralMarketDecision committed = null;
            Action<JJCentralMarketDecision> handler = null;

            lock (SyncRoot)
            {
                JJCentralMarketDecision existing;

                if (
                    LatestByInstrument.TryGetValue(
                        proposal.InstrumentName,
                        out existing
                    ) &&
                    existing != null
                )
                {
                    double ageMs =
                        (
                            DateTime.UtcNow -
                            existing.CommittedUtc
                        ).TotalMilliseconds;

                    if (
                        ageMs >= 0 &&
                        ageMs <= 1500
                    )
                    {
                        return false;
                    }
                }

                proposal.CommittedUtc =
                    DateTime.UtcNow;

                proposal.DecisionId =
                    (
                        proposal.InstrumentName ??
                        string.Empty
                    )
                    + "|"
                    + proposal.SignalBarTime.Ticks
                    + "|"
                    + (
                        proposal.IsLong
                            ? "LONG"
                            : "SHORT"
                      )
                    + "|"
                    + (
                        proposal.Strategy ??
                        string.Empty
                      )
                    + "|"
                    + (
                        proposal.Route ??
                        string.Empty
                      );

                LatestByInstrument[
                    proposal.InstrumentName
                ] =
                    proposal;

                committed =
                    proposal;

                handler =
                    DecisionCommitted;
            }

            if (handler != null)
            {
                try
                {
                    handler(committed);
                }
                catch
                {
                }
            }

            return true;
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ AI CORE - SINGLE CENTRAL SIGNAL AUTHORITY
    // V1.7.31 + V1.7.35 (isolated broadcast, strict conflict WAIT)
    // =========================================================
    // One market signal is selected centrally per instrument.
    // Profiles do NOT invent a new market direction after the central
    // decision.  They only apply their own account/session/risk authority.
    //
    // IMPORTANT:
    // - No "first profile wins" wall-clock lock.
    // - Candidate arbitration uses the strategy/Playback NY clock supplied
    //   by the profiles, not DateTime.UtcNow.
    // - A short market-time arbitration window collects simultaneous profile
    //   proposals, keeps the strongest candidate, and broadcasts ONE signal.
    // - Opposite candidates with nearly equal confidence are rejected as a
    //   central conflict instead of arbitrarily choosing the first arrival.
    // =========================================================
    public sealed class JJCentralMarketDecision
    {
        public string DecisionId;
        public string InstrumentName;
        public string ObserverProfileId;
        public bool IsLong;
        public DateTime SignalBarTime;
        public string Strategy;
        public string Route;
        public string RouteReason;
        public string StructureSetupKey;
        public bool OpeningEntry;
        public int SetupConfidence;
        public string SetupQuality;
        public string SetupTiming;
        public string ManipulationState;
        public string LearningStructure;

        // V1.7.35 - last traded price when the profile proposed the signal.
        // Lets each account refuse a decision if price already ran away.
        public double SignalPrice;

        // NY strategy clock at the instant this profile proposed the signal.
        public DateTime ObservedClockNy;

        // NY strategy clock at central commitment.  This is the authority for
        // decision age in both live and Playback.  CommittedUtc is telemetry
        // only and is intentionally NOT used for execution timing.
        public DateTime CommittedClockNy;
        public DateTime CommittedUtc;
    }

    internal sealed class JJCentralPendingDecision
    {
        public JJCentralMarketDecision Best;
        public DateTime WindowStartNy;
        public int BestConfidence;
        public int BestQualityRank;
        public int BestRouteRank;
        public int BestOpposingConfidence;
        public bool HasOpposingCandidate;
    }

    public static class JJBotCentralBrain
    {
        private static readonly object SyncRoot =
            new object();

        // 125 ms of MARKET/STRATEGY time.  Enough for all profiles observing
        // the same market event to submit their candidate without adding a
        // human-visible entry delay.
        private const double ArbitrationWindowMilliseconds = 125.0;

        // If opposite final-authority candidates arrive inside the same
        // central window and their confidence differs by less than this,
        // the market signal is considered conflicted and no order is emitted.
        private const int OppositeConflictMinimumConfidenceEdge = 5;

        private static readonly Dictionary<string, JJCentralPendingDecision>
            PendingByInstrument =
                new Dictionary<string, JJCentralPendingDecision>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly Dictionary<string, JJCentralMarketDecision>
            LatestByInstrument =
                new Dictionary<string, JJCentralMarketDecision>(
                    StringComparer.OrdinalIgnoreCase
                );

        public static event Action<JJCentralMarketDecision>
            DecisionCommitted;

        // V1.7.35 - telemetry: last window discarded as LONG/SHORT conflict.
        public static DateTime LastConflictNy = DateTime.MinValue;

        // V1.7.36 - one arbiter per instrument AND strategy family, so a CORE20
        // signal and a legacy (HYBRID/STRUCTURE/...) signal arriving in the same
        // window never cancel or starve each other.
        private static string ArbiterKey(JJCentralMarketDecision d)
        {
            string strategy = (d != null && d.Strategy != null) ? d.Strategy.Trim().ToUpperInvariant() : string.Empty;
            string family = strategy == "CORE20" ? "CORE20" : "LEGACY";
            return (d != null ? (d.InstrumentName ?? string.Empty) : string.Empty) + "|" + family;
        }

        private static int ClampConfidence(int value)
        {
            if (value < 0)
                return 0;

            if (value > 100)
                return 100;

            return value;
        }

        private static int GetQualityRank(string value)
        {
            string quality =
                string.IsNullOrWhiteSpace(value)
                    ? string.Empty
                    : value.Trim().ToUpperInvariant();

            if (quality.Contains("OPTIMAL"))
                return 4;

            if (quality.Contains("HIGH"))
                return 3;

            if (quality.Contains("GOOD"))
                return 2;

            if (quality.Contains("FAIR"))
                return 1;

            return 0;
        }

        private static int GetRouteRank(string value)
        {
            string route =
                string.IsNullOrWhiteSpace(value)
                    ? string.Empty
                    : value.Trim().ToUpperInvariant();

            if (route.Contains("FAST_OPEN"))
                return 4;

            if (route.Contains("DIRECT"))
                return 3;

            if (route.Contains("BREAKOUT"))
                return 2;

            if (route.Contains("RETEST"))
                return 1;

            return 0;
        }

        private static bool IsCandidateBetter(
            JJCentralMarketDecision proposal,
            JJCentralPendingDecision pending)
        {
            if (proposal == null || pending == null || pending.Best == null)
                return proposal != null;

            int proposalConfidence =
                ClampConfidence(proposal.SetupConfidence);

            int proposalQuality =
                GetQualityRank(proposal.SetupQuality);

            int proposalRoute =
                GetRouteRank(proposal.Route);

            if (proposalConfidence != pending.BestConfidence)
                return proposalConfidence > pending.BestConfidence;

            if (proposalQuality != pending.BestQualityRank)
                return proposalQuality > pending.BestQualityRank;

            if (proposalRoute != pending.BestRouteRank)
                return proposalRoute > pending.BestRouteRank;

            // Final deterministic tie-breaker.  It does NOT make a profile a
            // master; it merely guarantees the same result regardless of
            // thread/event arrival order when candidates are otherwise equal.
            string proposalId = proposal.ObserverProfileId ?? string.Empty;
            string currentId = pending.Best.ObserverProfileId ?? string.Empty;

            return string.Compare(
                proposalId,
                currentId,
                StringComparison.OrdinalIgnoreCase
            ) < 0;
        }

        private static void UpdatePendingWithProposal(
            JJCentralPendingDecision pending,
            JJCentralMarketDecision proposal)
        {
            if (pending == null || proposal == null)
                return;

            int confidence =
                ClampConfidence(proposal.SetupConfidence);

            if (pending.Best == null)
            {
                pending.Best = proposal;
                pending.BestConfidence = confidence;
                pending.BestQualityRank = GetQualityRank(proposal.SetupQuality);
                pending.BestRouteRank = GetRouteRank(proposal.Route);
                return;
            }

            if (pending.Best.IsLong != proposal.IsLong)
            {
                pending.HasOpposingCandidate = true;

                if (confidence > pending.BestOpposingConfidence)
                    pending.BestOpposingConfidence = confidence;
            }

            if (IsCandidateBetter(proposal, pending))
            {
                JJCentralMarketDecision oldBest = pending.Best;
                int oldBestConfidence = pending.BestConfidence;

                if (oldBest != null && oldBest.IsLong != proposal.IsLong)
                {
                    pending.HasOpposingCandidate = true;

                    if (oldBestConfidence > pending.BestOpposingConfidence)
                        pending.BestOpposingConfidence = oldBestConfidence;
                }

                pending.Best = proposal;
                pending.BestConfidence = confidence;
                pending.BestQualityRank = GetQualityRank(proposal.SetupQuality);
                pending.BestRouteRank = GetRouteRank(proposal.Route);
            }
        }

        private static JJCentralMarketDecision FinalizePendingLocked(
            string instrumentName,
            DateTime commitClockNy)
        {
            JJCentralPendingDecision pending;

            if (
                !PendingByInstrument.TryGetValue(
                    instrumentName,
                    out pending
                ) ||
                pending == null ||
                pending.Best == null
            )
            {
                return null;
            }

            PendingByInstrument.Remove(instrumentName);

            // V1.7.35 - if BOTH directions were approved by Final Entry
            // Authority inside the same tiny market-time window the market is
            // conflicted: WAIT centrally, whatever the confidence edge.  A
            // newer opposite candidate can mean the market just turned, so it
            // must never be out-voted by an older, higher-confidence snapshot.
            if (pending.HasOpposingCandidate)
            {
                LastConflictNy = commitClockNy;
                return null;
            }

            JJCentralMarketDecision committed =
                pending.Best;

            committed.CommittedClockNy =
                commitClockNy;

            committed.CommittedUtc =
                DateTime.UtcNow;

            committed.DecisionId =
                (committed.InstrumentName ?? string.Empty)
                + "|"
                + pending.WindowStartNy.Ticks
                + "|"
                + (committed.IsLong ? "LONG" : "SHORT")
                + "|"
                + (committed.Strategy ?? string.Empty)
                + "|"
                + (committed.Route ?? string.Empty);

            LatestByInstrument[
                instrumentName
            ] = committed;

            return committed;
        }

        private static void Publish(
            JJCentralMarketDecision committed)
        {
            if (committed == null)
                return;

            Action<JJCentralMarketDecision> handler =
                DecisionCommitted;

            if (handler == null)
                return;

            // V1.7.35 - isolated broadcast: every profile is invoked on its
            // own.  One failing subscriber can never stop the remaining
            // profiles from receiving the SAME decision.
            foreach (Delegate subscriber in handler.GetInvocationList())
            {
                try
                {
                    ((Action<JJCentralMarketDecision>)subscriber)(committed);
                }
                catch
                {
                }
            }
        }

        // A profile reaches this method ONLY after its existing stable Final
        // Entry Authority says EXECUTE.  The central brain does not create a
        // signal from Level2 or from a raw candidate; it arbitrates between
        // already-approved final candidates.
        public static bool TryCommitDecision(
            JJCentralMarketDecision proposal)
        {
            if (
                proposal == null ||
                string.IsNullOrWhiteSpace(proposal.InstrumentName)
            )
            {
                return false;
            }

            if (proposal.ObservedClockNy == DateTime.MinValue)
                return false;

            JJCentralMarketDecision commitBeforeNewWindow = null;

            lock (SyncRoot)
            {
                JJCentralPendingDecision pending;
                string arbiterKey = ArbiterKey(proposal);

                if (
                    PendingByInstrument.TryGetValue(
                        arbiterKey,
                        out pending
                    ) &&
                    pending != null
                )
                {
                    double elapsedMs =
                        (
                            proposal.ObservedClockNy -
                            pending.WindowStartNy
                        ).TotalMilliseconds;

                    if (elapsedMs < 0)
                    {
                        // Stale/out-of-order market proposal.
                        return false;
                    }

                    if (elapsedMs >= ArbitrationWindowMilliseconds)
                    {
                        commitBeforeNewWindow =
                            FinalizePendingLocked(
                                arbiterKey,
                                proposal.ObservedClockNy
                            );

                        pending = null;
                    }
                }

                if (pending == null)
                {
                    pending =
                        new JJCentralPendingDecision
                        {
                            WindowStartNy = proposal.ObservedClockNy
                        };

                    PendingByInstrument[
                        arbiterKey
                    ] = pending;
                }

                UpdatePendingWithProposal(
                    pending,
                    proposal
                );
            }

            // Publish outside the lock.  If the market advanced into a new
            // arbitration window, the PREVIOUS window's best signal becomes
            // the single central decision now.
            Publish(commitBeforeNewWindow);

            return true;
        }

        // Called from the live/Playback market stream.  This is what closes
        // the tiny arbitration window even if no second entry candidate is
        // produced.  currentClockNy MUST be the strategy clock, not wall time.
        public static void ObserveMarketTime(
            string instrumentName,
            DateTime currentClockNy)
        {
            if (
                string.IsNullOrWhiteSpace(instrumentName) ||
                currentClockNy == DateTime.MinValue
            )
            {
                return;
            }

            List<JJCentralMarketDecision> committedList = null;

            lock (SyncRoot)
            {
                string prefix = instrumentName + "|";

                foreach (string key in new List<string>(PendingByInstrument.Keys))
                {
                    if (!key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        continue;

                    JJCentralPendingDecision pending = PendingByInstrument[key];

                    if (pending == null)
                        continue;

                    double elapsedMs =
                        (
                            currentClockNy -
                            pending.WindowStartNy
                        ).TotalMilliseconds;

                    if (elapsedMs < ArbitrationWindowMilliseconds)
                        continue;

                    JJCentralMarketDecision committed =
                        FinalizePendingLocked(
                            key,
                            currentClockNy
                        );

                    if (committed != null)
                    {
                        if (committedList == null)
                            committedList = new List<JJCentralMarketDecision>();

                        committedList.Add(committed);
                    }
                }
            }

            if (committedList != null)
            {
                foreach (JJCentralMarketDecision c in committedList)
                    Publish(c);
            }
        }
    }
}

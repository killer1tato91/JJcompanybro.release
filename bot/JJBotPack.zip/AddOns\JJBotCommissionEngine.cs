#region Using declarations
using System;
using System.Collections.Generic;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT COMMISSION ENGINE V1.6.83
    // Accounting only. NO entry / signal / order-routing changes.
    //
    // Rule:
    // 1) If NinjaTrader reports a positive Execution.Commission, use it.
    // 2) If Ninja reports 0 (common on some prop connections), estimate
    //    the fee from the selected account firm + instrument + route.
    // 3) Rates below are ROUND-TURN per contract; this helper charges
    //    half on entry and half on exit, including scale-in fills.
    // =========================================================
    public partial class JJBotWindow
    {
        private string lastCommissionModelLogKey = string.Empty;
        private string lastCommissionUnknownLogKey = string.Empty;

        private static readonly Dictionary<string, double> LucidRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "ES", 3.50 }, { "MES", 1.00 },
                { "NQ", 3.50 }, { "MNQ", 1.00 },
                { "RTY", 3.50 }, { "M2K", 1.00 },
                { "YM", 3.50 }, { "MYM", 1.00 },
                { "NKD", 3.50 },
                { "6A", 4.80 }, { "6B", 4.80 }, { "6C", 4.80 },
                { "6E", 4.80 }, { "6J", 4.80 }, { "6S", 4.80 }, { "6N", 4.80 },
                { "CL", 4.00 }, { "MCL", 1.00 }, { "QM", 4.00 },
                { "NG", 4.00 }, { "QG", 2.60 },
                { "GC", 4.60 }, { "MGC", 1.60 },
                { "SI", 4.60 }, { "SIL", 3.20 }, { "HG", 4.60 }, { "PL", 4.60 },
                { "HE", 5.60 }, { "LE", 5.60 },
                { "ZS", 5.60 }, { "ZC", 5.60 }, { "ZL", 5.60 },
                { "ZM", 5.60 }, { "ZW", 5.60 }
            };

        private static readonly Dictionary<string, double> ApexTradovateRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "YM", 3.10 }, { "ES", 3.10 }, { "NQ", 3.10 }, { "RTY", 3.10 },
                { "EMD", 3.00 }, { "NKD", 4.64 },
                { "6A", 3.54 }, { "6B", 3.54 }, { "6C", 3.54 },
                { "6E", 3.54 }, { "6J", 3.54 }, { "6S", 3.54 }, { "6N", 3.54 },
                { "CL", 3.34 }, { "NG", 3.54 }, { "QM", 2.74 }, { "QG", 1.34 },
                { "GC", 3.54 }, { "SI", 3.54 }, { "HG", 3.54 }, { "PL", 3.54 }, { "PA", 3.54 },
                { "MYM", 1.04 }, { "MES", 1.04 }, { "MNQ", 1.04 }, { "M2K", 1.04 },
                { "SIL", 1.34 }, { "MGC", 1.34 }, { "MCL", 1.34 },
                { "M6A", 0.82 }, { "M6E", 0.82 },
                { "MBT", 5.34 }, { "MET", 0.74 }
            };

        private static readonly Dictionary<string, double> ApexRithmicRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "ES", 3.98 }, { "NQ", 3.98 }, { "YM", 3.98 }, { "RTY", 3.98 },
                { "EMD", 3.98 }, { "NKD", 3.98 },
                { "6A", 4.72 }, { "6B", 4.72 }, { "6C", 4.72 },
                { "6E", 4.72 }, { "6J", 4.72 }, { "6S", 4.72 }, { "6N", 4.72 },
                { "CL", 3.96 }, { "QM", 3.92 }, { "MCL", 1.02 },
                { "NG", 3.96 }, { "QG", 2.52 }, { "HO", 3.96 }, { "RB", 3.96 },
                { "GC", 4.62 }, { "SI", 4.62 }, { "HG", 4.62 }, { "PL", 4.62 }, { "PA", 4.62 },
                { "MES", 1.02 }, { "MYM", 1.02 }, { "MNQ", 1.02 }, { "M2K", 1.02 },
                { "SIL", 1.52 }, { "MGC", 1.52 },
                { "M6A", 0.84 }, { "M6E", 0.84 },
                { "MBT", 5.52 }, { "MET", 0.92 }
            };

        private static readonly Dictionary<string, double> MffuRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "NQ", 4.68 }, { "RTY", 4.68 }, { "ES", 4.68 },
                { "YM", 5.76 }, { "NKD", 6.22 },
                { "MNQ", 1.90 }, { "M2K", 1.90 }, { "MES", 1.90 }, { "MYM", 1.90 },
                { "GC", 5.12 }, { "MGC", 2.20 }, { "HG", 5.12 }, { "SI", 5.12 },
                { "SIL", 2.84 }, { "PL", 4.12 },
                { "CL", 4.92 }, { "QM", 4.32 }, { "MCL", 1.16 },
                { "NG", 5.12 }, { "QG", 2.92 }, { "HO", 4.92 }, { "RB", 6.00 },
                { "6A", 5.04 }, { "6B", 5.12 }, { "6C", 5.12 }, { "6E", 5.12 },
                { "6J", 5.12 }, { "6N", 5.12 }, { "6S", 5.12 },
                { "M6A", 1.44 }, { "M6E", 1.44 },
                { "MBT", 3.50 }, { "MET", 1.16 },
                { "HE", 6.12 }, { "LE", 6.12 },
                { "ZC", 6.12 }, { "ZS", 6.12 }, { "ZM", 6.12 }, { "ZL", 6.12 }, { "ZW", 6.12 }
            };

        private static readonly Dictionary<string, double> TradeifyRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "YM", 5.76 }, { "ES", 5.76 }, { "NQ", 5.76 }, { "RTY", 5.76 }, { "EMD", 5.66 },
                { "MYM", 1.82 }, { "MES", 1.82 }, { "MNQ", 1.82 }, { "M2K", 1.82 },
                { "CL", 6.00 }, { "NG", 6.20 }, { "QM", 5.40 }, { "QG", 4.00 },
                { "GC", 6.20 }, { "HG", 6.20 }, { "SI", 6.20 },
                { "MGC", 2.12 }, { "MCL", 2.12 },
                { "6A", 6.20 }, { "6B", 6.20 }, { "6J", 6.20 }, { "6C", 6.20 },
                { "6S", 10.20 }, { "6E", 6.20 },
                { "M6A", 1.60 }, { "M6E", 1.60 },
                { "HE", 9.20 }, { "LE", 11.20 }, { "GF", 7.20 },
                { "ZS", 15.20 }, { "ZL", 7.20 }, { "ZC", 7.20 }, { "ZW", 17.20 }, { "ZM", 9.20 }
            };

        private static readonly Dictionary<string, double> TopstepRoundTurnFees =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                { "ES", 3.78 }, { "MES", 1.22 }, { "NQ", 3.78 }, { "MNQ", 1.22 },
                { "RTY", 3.78 }, { "M2K", 1.22 }, { "YM", 3.78 }, { "MYM", 1.22 },
                { "NKD", 5.32 }, { "CL", 4.02 }, { "MCL", 1.52 }, { "QM", 3.42 },
                { "NG", 4.22 }, { "QG", 2.02 }, { "GC", 4.32 }, { "MGC", 1.92 },
                { "SI", 4.32 }, { "SIL", 2.72 }, { "HG", 4.32 }, { "PL", 4.32 }
            };

        private double ResolveExecutionCommission(
            double ninjaReportedCommission,
            int executionQuantity
        )
        {
            double reported =
                Math.Abs(ninjaReportedCommission);

            if (reported > 0.0000001)
            {
                return reported;
            }

            int quantity =
                Math.Max(0, executionQuantity);

            if (quantity <= 0)
            {
                return 0;
            }

            string accountName =
                selectedAccount != null
                    ? selectedAccount.Name ?? string.Empty
                    : string.Empty;

            string instrumentRoot =
                GetCommissionInstrumentRoot();

            string connectionText =
                GetSelectedAccountConnectionText();

            string model;
            double roundTurnPerContract;

            if (!TryGetRoundTurnFee(
                    accountName,
                    connectionText,
                    instrumentRoot,
                    out model,
                    out roundTurnPerContract
                ))
            {
                string unknownKey =
                    accountName + "|" + instrumentRoot;

                if (!string.Equals(
                        lastCommissionUnknownLogKey,
                        unknownKey,
                        StringComparison.Ordinal
                    ))
                {
                    lastCommissionUnknownLogKey =
                        unknownKey;

                    PrintBotMessage(
                        "COMMISSION RATE UNKNOWN"
                        + " | Account: " + accountName
                        + " | Instrument: " + instrumentRoot
                        + " | Ninja Commission: $0.00"
                        + " | Fees left at $0 until a rate is defined"
                    );
                }

                return 0;
            }

            double perSidePerContract =
                roundTurnPerContract / 2.0;

            double executionFee =
                perSidePerContract * quantity;

            string logKey =
                model
                + "|" + accountName
                + "|" + instrumentRoot
                + "|" + roundTurnPerContract.ToString("0.####");

            if (!string.Equals(
                    lastCommissionModelLogKey,
                    logKey,
                    StringComparison.Ordinal
                ))
            {
                lastCommissionModelLogKey =
                    logKey;

                PrintBotMessage(
                    "COMMISSION MODEL"
                    + " | " + model
                    + " | " + accountName
                    + " | " + instrumentRoot
                    + " | RT/Contract: " + roundTurnPerContract.ToString("$0.00")
                    + " | PerSide: " + perSidePerContract.ToString("$0.00")
                    + " | Source: JJ FALLBACK (Ninja reported $0.00)"
                );
            }

            return executionFee;
        }

        private bool TryGetRoundTurnFee(
            string accountName,
            string connectionText,
            string instrumentRoot,
            out string model,
            out double roundTurnFee
        )
        {
            model = string.Empty;
            roundTurnFee = 0;

            string account =
                (accountName ?? string.Empty).Trim().ToUpperInvariant();

            string route =
                (connectionText ?? string.Empty).Trim().ToUpperInvariant();

            Dictionary<string, double> table = null;

            if (
                account.Contains("LDI") ||
                account.Contains("LFE") ||
                account.Contains("LTE") ||
                account.Contains("LFF")
            )
            {
                model = "LUCID";
                table = LucidRoundTurnFees;
            }
            else if (
                account.Contains("APEX") ||
                account.Contains("PA-")
            )
            {
                if (route.Contains("RITHMIC"))
                {
                    model = "APEX RITHMIC";
                    table = ApexRithmicRoundTurnFees;
                }
                else
                {
                    // Conservative/default Apex route for accounts where Ninja
                    // does not expose the connection provider text.
                    model = route.Contains("TRADOVATE")
                        ? "APEX TRADOVATE"
                        : "APEX TRADOVATE (DEFAULT)";
                    table = ApexTradovateRoundTurnFees;
                }
            }
            else if (
                account.Contains("MFFU") ||
                account.Contains("MYFUNDED")
            )
            {
                model = "MFFU";
                table = MffuRoundTurnFees;
            }
            else if (
                account.Contains("TDFY") ||
                account.Contains("TRADEIFY") ||
                account.Contains("TRADEFY")
            )
            {
                model = "TRADEIFY";
                table = TradeifyRoundTurnFees;
            }
            else if (account.Contains("TOPSTEP"))
            {
                model = "TOPSTEP";
                table = TopstepRoundTurnFees;
            }

            if (table == null)
            {
                return false;
            }

            return table.TryGetValue(
                instrumentRoot,
                out roundTurnFee
            );
        }

        private string GetCommissionInstrumentRoot()
        {
            string fullName =
                selectedInstrument != null
                    ? selectedInstrument.FullName ?? string.Empty
                    : string.Empty;

            fullName =
                fullName.Trim();

            if (string.IsNullOrWhiteSpace(fullName))
            {
                return string.Empty;
            }

            int firstSpace =
                fullName.IndexOf(' ');

            string root =
                firstSpace > 0
                    ? fullName.Substring(0, firstSpace)
                    : fullName;

            return root
                .Trim()
                .ToUpperInvariant();
        }

        private string GetSelectedAccountConnectionText()
        {
            try
            {
                if (selectedAccount == null)
                {
                    return string.Empty;
                }

                object connection =
                    GetPropertyValue(
                        selectedAccount,
                        "Connection"
                    );

                if (connection == null)
                {
                    return string.Empty;
                }

                object options =
                    GetPropertyValue(
                        connection,
                        "Options"
                    );

                string text =
                    Convert.ToString(connection)
                    + " "
                    + Convert.ToString(options)
                    + " "
                    + Convert.ToString(
                        GetPropertyValue(connection, "Name")
                      )
                    + " "
                    + Convert.ToString(
                        GetPropertyValue(connection, "Provider")
                      )
                    + " "
                    + Convert.ToString(
                        GetPropertyValue(options, "Name")
                      )
                    + " "
                    + Convert.ToString(
                        GetPropertyValue(options, "Provider")
                      );

                return text;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static object GetPropertyValue(
            object source,
            string propertyName
        )
        {
            if (
                source == null ||
                string.IsNullOrWhiteSpace(propertyName)
            )
            {
                return null;
            }

            try
            {
                var property =
                    source
                        .GetType()
                        .GetProperty(propertyName);

                return property != null
                    ? property.GetValue(source, null)
                    : null;
            }
            catch
            {
                return null;
            }
        }
    }
}

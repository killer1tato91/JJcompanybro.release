using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT COMPILE COMPATIBILITY BRIDGE V1.7.12
    // For mixed V1.7.x module sets.
    // Compile-only compatibility: does not submit/change orders.
    // =========================================================
    public partial class JJBotWindow
    {
        // Trade-management compatibility state.
        private double activeTradePeakFavorableTicks = 0.0;

        // -----------------------------------------------------
        // PLAYBACK CLOCK COMPATIBILITY
        // -----------------------------------------------------
        // V1.7.25 FIX:
        // JJBotTimeManager is now the single authority for:
        //   IsPlaybackStrategyClockActive()
        //   IsAcceleratedReplayBacktestMode()
        //   GetStrategyUtcNow()
        //   GetCurrentNewYorkTime()
        //   UpdatePlaybackStrategyClock(...)
        //
        // Do NOT redeclare the method forms here; doing so creates
        // CS0111 / CS0121 duplicate and ambiguous-member compile errors.
        //
        // Lowercase aliases are retained only for older mixed modules.
        private bool isPlaybackStrategyClockActive
        {
            get
            {
                return IsPlaybackStrategyClockActive();
            }
        }

        private bool isAcceleratedReplayBacktestMode
        {
            get
            {
                return IsAcceleratedReplayBacktestMode();
            }
        }

        // -----------------------------------------------------
        // LEGACY / MIXED-MODULE STATE COMPATIBILITY
        // -----------------------------------------------------
        private bool asiaLossPremarketBlockedToday = false;
        private DateTime lastOpenCommitmentUntilUtc = DateTime.MinValue;

        // Fast Open 2.4 compatibility state.
        private DateTime fastOpenCommitmentUntilUtc = DateTime.MinValue;

        // Level 2 opening continuity compatibility state.
        private bool level2WarmupCompleted = false;
        private DateTime level2LastStrictReadyUtc = DateTime.MinValue;
        private DateTime level2LastOpeningContinuityLogUtc = DateTime.MinValue;
    }
}

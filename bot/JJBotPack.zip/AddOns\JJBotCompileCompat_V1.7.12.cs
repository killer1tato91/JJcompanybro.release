using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT COMPILE COMPATIBILITY BRIDGE V1.7.12
    // For mixed V1.7.x module sets.
    // Compile-only compatibility: does not submit/change orders.
    // =========================================================
    public partial class JJBotWindow
    {
        // Trade-management compatibility state.
        private double activeTradePeakFavorableTicks = 0.0;

        // -----------------------------------------------------
        // PLAYBACK CLOCK COMPATIBILITY
        // -----------------------------------------------------
        // Some current modules call the METHOD form with capitals:
        // IsPlaybackStrategyClockActive()
        // IsAcceleratedReplayBacktestMode()
        //
        // The installed TimeManager set does not currently expose them,
        // so provide them here using the selected account identity.
        private bool IsPlaybackStrategyClockActive()
        {
            try
            {
                string accountName =
                    selectedAccount == null
                        ? string.Empty
                        : selectedAccount.Name ?? string.Empty;

                return accountName.StartsWith(
                    "Playback",
                    StringComparison.OrdinalIgnoreCase
                );
            }
            catch
            {
                return false;
            }
        }

        private bool IsAcceleratedReplayBacktestMode()
        {
            return IsPlaybackStrategyClockActive();
        }

        // Lowercase aliases retained for older mixed modules.
        private bool isPlaybackStrategyClockActive
        {
            get
            {
                return IsPlaybackStrategyClockActive();
            }
        }

        private bool isAcceleratedReplayBacktestMode
        {
            get
            {
                return IsAcceleratedReplayBacktestMode();
            }
        }

        // -----------------------------------------------------
        // LEGACY / MIXED-MODULE STATE COMPATIBILITY
        // -----------------------------------------------------
        private bool asiaLossPremarketBlockedToday = false;
        private DateTime lastOpenCommitmentUntilUtc = DateTime.MinValue;

        // Fast Open 2.4 compatibility state.
        private DateTime fastOpenCommitmentUntilUtc = DateTime.MinValue;

        // Level 2 opening continuity compatibility state.
        private bool level2WarmupCompleted = false;
        private DateTime level2LastStrictReadyUtc = DateTime.MinValue;
        private DateTime level2LastOpeningContinuityLogUtc = DateTime.MinValue;
    }
}

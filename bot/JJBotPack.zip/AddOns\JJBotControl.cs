#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // SHARED STATE BRIDGE
    //
    // Lets JJBotControl publish its REAL execution state to
    // JJBotChart without the chart indicator submitting orders.
    // =========================================================
    public class JJBotSharedSnapshot
    {
        public bool IsRunning;
        public string AccountName;
        public string InstrumentName;

        public int TradesToday;
        public int MaxTrades;
        public int AmTrades;
        public int PmTrades;

        public double RealizedPnL;
        public double UnrealizedPnL;
        public double TotalPnL;

        public bool DailyLocked;

        public string Position;
        public int PositionQty;

        public double EntryPrice;
        public double StopPrice;
        public double TargetPrice;

        public string OrderStatus;
        public string Signal;
        public string Setup;

        // Advanced visual state for JJBotChart
        public string StrategyMode;
        public string SessionWindow;
        public string H4Trend;
        public string H1Trend;
        public string HtfContextBias;

        public string M5Trend;
        public string M5VwapSide;
        public string M5Liquidity;
        public string M5Structure;

        public string RangeMomentum;
        public int RangeLongScore;
        public int RangeShortScore;

        public bool LearningActive;
        public int LearningPatterns;
        public int LearningTrades;

        public string TrailingState;

        public long ExecutionSequence;
        public string LastExecutionSide;
        public double LastExecutionPrice;

        public DateTime LastUpdateUtc;

        public JJBotSharedSnapshot()
        {
            AccountName = string.Empty;
            InstrumentName = string.Empty;
            Position = "FLAT";
            OrderStatus = "WAITING";
            Signal = "WAITING";
            Setup = "WAITING";

            StrategyMode = "HYBRID";
            SessionWindow = "OUTSIDE";
            H4Trend = "WAITING";
            H1Trend = "WAITING";
            HtfContextBias = "NEUTRAL 0/2";
            M5Trend = "WAITING";
            M5VwapSide = "WAITING";
            M5Liquidity = "NONE";
            M5Structure = "WAITING";
            RangeMomentum = "WAITING RANGE";
            TrailingState = "OFF";

            LastExecutionSide = string.Empty;
            LastUpdateUtc = DateTime.MinValue;
        }

        public JJBotSharedSnapshot Clone()
        {
            return new JJBotSharedSnapshot
            {
                IsRunning = IsRunning,
                AccountName = AccountName,
                InstrumentName = InstrumentName,

                TradesToday = TradesToday,
                MaxTrades = MaxTrades,
                AmTrades = AmTrades,
                PmTrades = PmTrades,

                RealizedPnL = RealizedPnL,
                UnrealizedPnL = UnrealizedPnL,
                TotalPnL = TotalPnL,

                DailyLocked = DailyLocked,

                Position = Position,
                PositionQty = PositionQty,

                EntryPrice = EntryPrice,
                StopPrice = StopPrice,
                TargetPrice = TargetPrice,

                OrderStatus = OrderStatus,
                Signal = Signal,
                Setup = Setup,

                StrategyMode = StrategyMode,
                SessionWindow = SessionWindow,
                H4Trend = H4Trend,
                H1Trend = H1Trend,
                HtfContextBias = HtfContextBias,
                M5Trend = M5Trend,
                M5VwapSide = M5VwapSide,
                M5Liquidity = M5Liquidity,
                M5Structure = M5Structure,

                RangeMomentum = RangeMomentum,
                RangeLongScore = RangeLongScore,
                RangeShortScore = RangeShortScore,

                LearningActive = LearningActive,
                LearningPatterns = LearningPatterns,
                LearningTrades = LearningTrades,

                TrailingState = TrailingState,

                ExecutionSequence = ExecutionSequence,
                LastExecutionSide = LastExecutionSide,
                LastExecutionPrice = LastExecutionPrice,

                LastUpdateUtc = LastUpdateUtc
            };
        }
    }

    public static class JJBotSharedState
    {
        private static readonly object SyncRoot =
            new object();

        // V7 MULTI-INSTRUMENT:
        // One independent snapshot per Account + Instrument.
        // This prevents MES and MNQ windows from overwriting each
        // other's chart state when both bots are running together.
        private static readonly Dictionary<string, JJBotSharedSnapshot> snapshots =
            new Dictionary<string, JJBotSharedSnapshot>(
                StringComparer.OrdinalIgnoreCase
            );

        public static event Action StateChanged;

        // V7.1:
        // Removes a stale Account + Instrument state when a bot window
        // changes account/instrument. This prevents an old bot state from
        // remaining visible on a chart after the selector changes.
        public static void RemoveSnapshot(
            string accountName,
            string instrumentName)
        {
            Action handler = null;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                if (snapshots.Remove(key))
                {
                    handler =
                        StateChanged;
                }
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

       // =========================================================
// ACCOUNT + INSTRUMENT SNAPSHOT
// =========================================================
// This is the SAFE lookup used when the caller knows both
// the account and the instrument.
public static JJBotSharedSnapshot GetSnapshot(
    string accountName,
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(accountName) ||
        string.IsNullOrWhiteSpace(instrumentName)
    )
    {
        return null;
    }

    string key =
        BuildKey(
            accountName,
            instrumentName
        );

    lock (SyncRoot)
    {
        JJBotSharedSnapshot snapshot;

        if (
            !snapshots.TryGetValue(
                key,
                out snapshot
            ) ||
            snapshot == null
        )
        {
            return null;
        }

        return snapshot.Clone();
    }
}


// =========================================================
// INSTRUMENT-ONLY COMPATIBILITY LOOKUP
// =========================================================
// IMPORTANT:
// If MORE THAN ONE account has a bot running on the same
// instrument, this method intentionally returns null.
//
// It is safer to show NO LINK than randomly display the
// state of another account.
public static JJBotSharedSnapshot GetSnapshot(
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(
            instrumentName
        )
    )
    {
        return null;
    }

    lock (SyncRoot)
    {
        JJBotSharedSnapshot found = null;

        foreach (
            KeyValuePair<string, JJBotSharedSnapshot> pair
            in snapshots
        )
        {
            JJBotSharedSnapshot candidate =
                pair.Value;

            if (
                candidate == null ||
                string.IsNullOrWhiteSpace(
                    candidate.InstrumentName
                ) ||
                !string.Equals(
                    candidate.InstrumentName,
                    instrumentName,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                continue;
            }

            // More than one bot is publishing the same instrument.
            // Never guess which account the chart wants.
            if (found != null)
            {
                return null;
            }

            found =
                candidate;
        }

        return found != null
            ? found.Clone()
            : null;
    }
}

        // Kept for compatibility with any older visual code.
        // Returns the most recently updated bot of any instrument.
        public static JJBotSharedSnapshot GetSnapshot()
        {
            lock (SyncRoot)
            {
                JJBotSharedSnapshot newest = null;

                foreach (
                    KeyValuePair<string, JJBotSharedSnapshot> pair
                    in snapshots
                )
                {
                    JJBotSharedSnapshot candidate =
                        pair.Value;

                    if (
                        candidate != null &&
                        (
                            newest == null ||
                            candidate.LastUpdateUtc >
                                newest.LastUpdateUtc
                        )
                    )
                    {
                        newest = candidate;
                    }
                }

                return newest != null
                    ? newest.Clone()
                    : null;
            }
        }

        public static void Update(
            bool isRunning,
            string accountName,
            string instrumentName,
            int tradesToday,
            int maxTrades,
            int amTrades,
            int pmTrades,
            double realizedPnL,
            double unrealizedPnL,
            double totalPnL,
            bool dailyLocked,
            string position,
            int positionQty,
            double entryPrice,
            double stopPrice,
            double targetPrice,
            string orderStatus,
            string signal,
            string setup,
            string strategyMode,
            string sessionWindow,
            string h4Trend,
            string h1Trend,
            string htfContextBias,
            string m5Trend,
            string m5VwapSide,
            string m5Liquidity,
            string m5Structure,
            string rangeMomentum,
            int rangeLongScore,
            int rangeShortScore,
            bool learningActive,
            int learningPatterns,
            int learningTrades,
            string trailingState)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    snapshots[key] =
                        current;
                }

                current.IsRunning =
                    isRunning;

                current.AccountName =
                    accountName ?? string.Empty;

                current.InstrumentName =
                    instrumentName ?? string.Empty;

                current.TradesToday =
                    tradesToday;

                current.MaxTrades =
                    maxTrades;

                current.AmTrades =
                    amTrades;

                current.PmTrades =
                    pmTrades;

                current.RealizedPnL =
                    realizedPnL;

                current.UnrealizedPnL =
                    unrealizedPnL;

                current.TotalPnL =
                    totalPnL;

                current.DailyLocked =
                    dailyLocked;

                current.Position =
                    string.IsNullOrWhiteSpace(
                        position
                    )
                        ? "FLAT"
                        : position;

                current.PositionQty =
                    positionQty;

                current.EntryPrice =
                    entryPrice;

                current.StopPrice =
                    stopPrice;

                current.TargetPrice =
                    targetPrice;

                current.OrderStatus =
                    orderStatus ?? "WAITING";

                current.Signal =
                    signal ?? "WAITING";

                current.Setup =
                    setup ?? "WAITING";

                current.StrategyMode =
                    strategyMode ?? "HYBRID";

                current.SessionWindow =
                    sessionWindow ?? "OUTSIDE";

                current.H4Trend =
                    h4Trend ?? "WAITING";

                current.H1Trend =
                    h1Trend ?? "WAITING";

                current.HtfContextBias =
                    htfContextBias ?? "NEUTRAL 0/2";

                current.M5Trend =
                    m5Trend ?? "WAITING";

                current.M5VwapSide =
                    m5VwapSide ?? "WAITING";

                current.M5Liquidity =
                    m5Liquidity ?? "NONE";

                current.M5Structure =
                    m5Structure ?? "WAITING";

                current.RangeMomentum =
                    rangeMomentum ?? "WAITING RANGE";

                current.RangeLongScore =
                    rangeLongScore;

                current.RangeShortScore =
                    rangeShortScore;

                current.LearningActive =
                    learningActive;

                current.LearningPatterns =
                    learningPatterns;

                current.LearningTrades =
                    learningTrades;

                current.TrailingState =
                    trailingState ?? "OFF";

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        public static void PublishExecution(
            string accountName,
            string instrumentName,
            string side,
            double price)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    current.AccountName =
                        accountName ?? string.Empty;

                    current.InstrumentName =
                        instrumentName ?? string.Empty;

                    snapshots[key] =
                        current;
                }

                current.ExecutionSequence++;

                current.LastExecutionSide =
                    side ?? string.Empty;

                current.LastExecutionPrice =
                    price;

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }
    }

    public class JJBotControl : NinjaTrader.NinjaScript.AddOnBase
    {
        private NTMenuItem toolsMenu;
        private NTMenuItem jjBotMenuItem;

        // One persistent bot window/engine per NinjaTrader session.
        // Closing the visible window only hides it; the engine, telemetry
        // and command polling remain alive in the background.
        private JJBotWindow jjBotWindow;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "J&J NY Trading Bot Control Panel";
                Name = "JJBotControl";
            }
        }

        // =====================================================
        // ADD J&J BOT TO NINJATRADER TOOLS MENU
        // =====================================================
        protected override void OnWindowCreated(Window window)
        {
            ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            toolsMenu =
                controlCenter.FindFirst(
                    "ControlCenterMenuItemTools"
                ) as NTMenuItem;

            if (toolsMenu == null)
                return;

            jjBotMenuItem = new NTMenuItem
            {
                Header = "J&J NY Trading Bot",

                Style =
                    Application.Current.TryFindResource(
                        "MainMenuItem"
                    ) as Style
            };

            toolsMenu.Items.Add(jjBotMenuItem);
            jjBotMenuItem.Click += OnJJBotMenuClick;

            // Start the bridge/telemetry/command engine automatically.
            // IMPORTANT:
            // Create the hidden bot window on the SAME dispatcher that owns
            // NinjaTrader's Control Center. Application.Current.Dispatcher
            // is not guaranteed to be the same dispatcher in NinjaTrader.
            EnsureBackgroundBotEngine(
                controlCenter.Dispatcher
            );
        }

        private void EnsureBackgroundBotEngine(
            Dispatcher dispatcher)
        {
            if (dispatcher == null)
            {
                return;
            }

            dispatcher.BeginInvoke(
                new Action(
                    delegate
                    {
                        if (
                            jjBotWindow != null &&
                            jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        jjBotWindow =
                            new JJBotWindow();

                        // Intentionally do not call Show().
                        // Constructor starts telemetry and command polling.
                    }
                )
            );
        }

        // =====================================================
        // CLEANUP MENU
        // =====================================================
        protected override void OnWindowDestroyed(Window window)
        {
            if (!(window is ControlCenter))
                return;

            // NinjaTrader / Control Center is actually shutting down:
            // now the hidden engine must be allowed to close permanently.
            if (jjBotWindow != null)
            {
                try
                {
                    jjBotWindow.RequestPermanentClose();
                }
                catch
                {
                }

                jjBotWindow = null;
            }

            if (jjBotMenuItem != null)
            {
                jjBotMenuItem.Click -= OnJJBotMenuClick;

                if (
                    toolsMenu != null &&
                    toolsMenu.Items.Contains(jjBotMenuItem)
                )
                {
                    toolsMenu.Items.Remove(jjBotMenuItem);
                }

                jjBotMenuItem = null;
            }

            toolsMenu = null;
        }

        // =====================================================
        // OPEN BOT WINDOW
        // =====================================================
        private void OnJJBotMenuClick(
            object sender,
            RoutedEventArgs e)
        {
            /*
              IMPORTANT:
              If the hidden JJBotWindow already exists, the ONLY safe
              dispatcher for Show/Activate/WindowState is the dispatcher
              that owns that exact window.

              The menu/Control Center dispatcher is not guaranteed to be
              the owner of the existing hidden window.
            */
            if (
                jjBotWindow != null &&
                jjBotWindow.IsEngineWindowAlive
            )
            {
                Dispatcher windowDispatcher =
                    jjBotWindow.Dispatcher;

                if (windowDispatcher == null)
                {
                    return;
                }

                windowDispatcher.BeginInvoke(
                    new Action(() =>
                    {
                        if (
                            jjBotWindow == null ||
                            !jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        if (!jjBotWindow.IsVisible)
                        {
                            jjBotWindow.Show();
                        }

                        if (
                            jjBotWindow.WindowState ==
                                WindowState.Minimized
                        )
                        {
                            jjBotWindow.WindowState =
                                WindowState.Normal;
                        }

                        jjBotWindow.Activate();
                    })
                );

                return;
            }

            /*
              No window exists yet.
              Create + show it on the same dispatcher that owns
              NinjaTrader's menu/Control Center.
            */
            Dispatcher createDispatcher =
                jjBotMenuItem != null
                    ? jjBotMenuItem.Dispatcher
                    : (
                        toolsMenu != null
                            ? toolsMenu.Dispatcher
                            : null
                      );

            if (createDispatcher == null)
            {
                return;
            }

            createDispatcher.BeginInvoke(
                new Action(() =>
                {
                    if (
                        jjBotWindow == null ||
                        !jjBotWindow.IsEngineWindowAlive
                    )
                    {
                        jjBotWindow =
                            new JJBotWindow();
                    }

                    if (!jjBotWindow.IsVisible)
                    {
                        jjBotWindow.Show();
                    }

                    if (
                        jjBotWindow.WindowState ==
                            WindowState.Minimized
                    )
                    {
                        jjBotWindow.WindowState =
                            WindowState.Normal;
                    }

                    jjBotWindow.Activate();
                })
            );
        }
    }

    // =========================================================
    // RUNTIME / PERSISTENCE COORDINATOR
    // =========================================================
    // - One persistence lock per Account + Instrument.
    // - One active bot lease per Account + Instrument.
    //
    // This prevents two JJBot windows from actively trading the same
    // Account + Instrument at the same time and serializes XML access.
    // =========================================================
    public static class JJBotRuntimeCoordinator
    {
        private static readonly object SyncRoot =
            new object();

        private static readonly Dictionary<string, object>
            persistenceLocks =
                new Dictionary<string, object>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly HashSet<string>
            activeBotKeys =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

        public static object GetPersistenceLock(
            string accountName,
            string instrumentName)
        {
            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                object gate;

                if (
                    !persistenceLocks.TryGetValue(
                        key,
                        out gate
                    ) ||
                    gate == null
                )
                {
                    gate =
                        new object();

                    persistenceLocks[key] =
                        gate;
                }

                return gate;
            }
        }

        public static bool TryAcquireBotLease(
            string accountName,
            string instrumentName,
            out string leaseKey)
        {
            leaseKey =
                BuildKey(
                    accountName,
                    instrumentName
                );

            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                leaseKey =
                    string.Empty;

                return false;
            }

            lock (SyncRoot)
            {
                if (
                    activeBotKeys.Contains(
                        leaseKey
                    )
                )
                {
                    return false;
                }

                activeBotKeys.Add(
                    leaseKey
                );

                return true;
            }
        }

        public static void ReleaseBotLease(
            string leaseKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    leaseKey
                )
            )
            {
                return;
            }

            lock (SyncRoot)
            {
                activeBotKeys.Remove(
                    leaseKey
                );
            }
        }
    }

    // =========================================================
    // PERSISTENT DAILY STATE
    // =========================================================
    [Serializable]
    public class JJBotDailyStateData
    {
        public string NewYorkDate
        {
            get;
            set;
        }

        public string AccountName
        {
            get;
            set;
        }

        public string InstrumentName
        {
            get;
            set;
        }

        public int TradesToday
        {
            get;
            set;
        }

        public int AmTrades
        {
            get;
            set;
        }

        public int PmTrades
        {
            get;
            set;
        }

        public double RealizedPnL
        {
            get;
            set;
        }

        public bool DailyLocked
        {
            get;
            set;
        }

        public DateTime LastExecutedSignalBar
        {
            get;
            set;
        }

        // Structure setup keys are persisted so a restart cannot
        // re-trade the same already-filled sweep/BOS setup.
        public string ConsumedBullishStructureKey
        {
            get;
            set;
        }

        public string ConsumedBearishStructureKey
        {
            get;
            set;
        }

        public DateTime ConsumedBullishStructureConfirmTime
        {
            get;
            set;
        }

        public DateTime ConsumedBearishStructureConfirmTime
        {
            get;
            set;
        }

        public JJBotDailyStateData()
        {
            NewYorkDate = string.Empty;
            AccountName = string.Empty;
            InstrumentName = string.Empty;

            TradesToday = 0;
            AmTrades = 0;
            PmTrades = 0;
            RealizedPnL = 0;
            DailyLocked = false;

            LastExecutedSignalBar =
                DateTime.MinValue;

            ConsumedBullishStructureKey =
                string.Empty;

            ConsumedBearishStructureKey =
                string.Empty;

            ConsumedBullishStructureConfirmTime =
                DateTime.MinValue;

            ConsumedBearishStructureConfirmTime =
                DateTime.MinValue;
        }
    }

    // =========================================================
    // LEARNING ENGINE - PERSISTENT MEMORY
    // =========================================================
    [Serializable]
    public class JJBotLearningPattern
    {
        public string Key { get; set; }
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public int Trades { get; set; }
        public int Wins { get; set; }
        public int Losses { get; set; }
        public int Breakevens { get; set; }

        public double NetPnL { get; set; }
        public double TotalMfe { get; set; }
        public double TotalMae { get; set; }

        public JJBotLearningPattern()
        {
            Key = string.Empty;
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
        }
    }

    [Serializable]
    public class JJBotLearningMemory
    {
        public List<JJBotLearningPattern> Patterns { get; set; }

        public JJBotLearningMemory()
        {
            Patterns =
                new List<JJBotLearningPattern>();
        }
    }

    [Serializable]
    public class JJBotLearningTrade
    {
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public DateTime SignalTimeNy { get; set; }
        public double EntryPrice { get; set; }

        public double Mfe { get; set; }
        public double Mae { get; set; }

        public JJBotLearningTrade()
        {
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
        }
    }

    // =========================================================
    // J&J BOT WINDOW
    // =========================================================
    public class JJBotWindow : NTWindow
    {
        // =====================================================
        // LIVE DISPLAY
        // =====================================================
        private TextBlock statusText;
        private TextBlock pnlText;
        private TextBlock unrealizedPnlText;
        private TextBlock totalPnlText;
        private TextBlock tradesText;
        private TextBlock signalText;
        private TextBlock accountStatusText;
        private TextBlock instrumentStatusText;

        private TextBlock emaFastText;
        private TextBlock emaSlowText;
        private TextBlock lastPriceText;
        private TextBlock barTimeText;

        private TextBlock vwapText;
        private TextBlock nySessionText;
        private TextBlock trendText;
        private TextBlock setupText;

        private TextBlock liquidityText;
        private TextBlock structureText;
        private TextBlock momentumText;
        private TextBlock confirmationText;

        // Values published to JJBotChart.
        private string currentSignalState;
        private string currentSetupState;

        // =====================================================
        // EXECUTION MONITOR DISPLAY
        // =====================================================
        private TextBlock positionText;
        private TextBlock positionQtyText;
        private TextBlock entryPriceText;
        private TextBlock stopPriceText;
        private TextBlock targetPriceText;
        private TextBlock riskRewardText;
        private TextBlock orderStatusText;

        // =====================================================
        // VISUAL LOG
        // =====================================================
        private TextBox visualLogBox;
        private Button clearLogButton;
        private Queue<string> visualLogLines;

        private const int MaxVisualLogLines = 150;

        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        // Read-only bridge:
        // JJBotControl -> localhost backend -> React platform.
        //
        // IMPORTANT:
        // This bridge NEVER submits, changes or flattens orders.
        // It only publishes the bot's current state.
        private DispatcherTimer platformTelemetryTimer;
        private bool platformTelemetryRequestInFlight;
        private string platformApiKey;
        private string platformServerUrl;
        private string platformConfigFile;
        private DateTime lastPlatformTelemetrySuccessUtc;

        // Platform -> JJBotControl command polling.
        // Separate timer/HTTP request from telemetry so a slow command
        // request can never block state publishing.
        private DispatcherTimer platformCommandTimer;
        private bool platformCommandRequestInFlight;
        private string lastProcessedPlatformCommandId;

        // True only while a START_BOT command from J&J Company Bro
        // is applying its Account + Instrument + risk configuration.
        // This lets StartBotClicked use the platform-selected context
        // without requiring the visible NinjaTrader bot window.
        private bool platformRemoteStartContext;

        private const int PlatformTelemetryIntervalSeconds = 3;
        private const int PlatformCommandIntervalSeconds = 1;
        private const string PlatformBridgeVersion = "1.1.0";

        // =====================================================
        // NINJATRADER SELECTORS
        // =====================================================
        private AccountSelector accountSelector;
        private InstrumentSelector instrumentSelector;

        private Account selectedAccount;
        private Instrument selectedInstrument;

        // =====================================================
        // SETTINGS
        // =====================================================
        private ComboBox directionCombo;
        private ComboBox strategyCombo;

        private TextBox contractsBox;
        private TextBox stopBox;
        private TextBox targetBox;
        private TextBox maxTradesBox;
        private TextBox dailyTargetBox;
        private TextBox dailyLossBox;

        // =====================================================
        // BUTTONS
        // =====================================================
        private Button startButton;
        private Button stopButton;
        private Button closeAllButton;

        private Button testLongButton;
        private Button testShortButton;

        // =====================================================
        // BOT ENGINE
        // =====================================================
        private bool botRunning;

        // Cached on the UI thread when START BOT is pressed.
        // BarsRequest callbacks run on a different thread, so they must
        // never read WPF controls such as directionCombo directly.
        private string activeDirection;
        private string activeStrategyMode;

        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        private int activeContracts;
        private int activeStopTicks;
        private int activeTargetTicks;
        private int activeMaxTrades;
        private double activeDailyTarget;
        private double activeDailyLoss;

        // =====================================================
        // INPUT SAFETY LIMITS
        // =====================================================
        // Conservative hard caps for the SIM-only build.
        private const int MaxContractsAllowed = 20;
        private const int MaxStopTicksAllowed = 2000;
        private const int MaxTargetTicksAllowed = 4000;
        private const int MaxTradesPerSessionAllowed = 20;
        private const double MaxDailyTargetAllowed = 10000.0;
        private const double MaxDailyLossAllowed = 10000.0;

        private int tradesToday;
        private int amTradesToday;
        private int pmTradesToday;
        private string pendingEntrySession;

        private double botDailyPnL;
        private double botUnrealizedPnL;
        private DateTime activeTradingDate;

        private bool riskFlattenSent;
        private int riskFlattenStage;
        private DateTime riskFlattenLastActionUtc;
        private Order riskFlattenOrder;

        // Tracks both sides of commission so Learning NetPnL is exact.
        private double activeEntryCommission;

        // =====================================================
        // PARTIAL FILL / TRADE LIFECYCLE V1
        // =====================================================
        // Entry executions can arrive in multiple partial fills.
        // Keep one lifecycle, one learning record and one trade count.
        private int activeEffectiveTargetTicks;
        private int activeExitQuantity;
        private double activeExitGrossPnL;
        private double activeExitCommission;

        // Debounces repeated Range signal/block messages for the same Range bar.
        private string lastRangeSignalLogKey;
        private string lastRangeBlockedLogKey;

        private bool entryPending;
        private Order entryOrder;
        private Order stopOrder;
        private Order targetOrder;

        private double entryFillPrice;
        private double activeStopPrice;
        private double activeTargetPrice;
        private int entryQuantity;

        private MarketPosition entryMarketPosition;
        private string executionStatus;
// =====================================================
// EXECUTION STATE SYNCHRONIZATION
// =====================================================
// Protects shared execution/order state accessed from
// BarsRequest, OrderUpdate and ExecutionUpdate callbacks.
//
// IMPORTANT:
// Never call Submit(), Change() or Flatten() while holding
// this lock.
private readonly object executionStateLock =
    new object();
     // =====================================================
// TRADE PROTECTION / TRAILING STATE
// =====================================================
private bool activeEntryUsesMomentumTrailing;
private int momentumTrailingStage;
private double lastMomentumTrailingStopPrice;

// Prevent excessive Account.Change() requests.
private DateTime lastMomentumTrailingChangeUtc =
    DateTime.MinValue;


// =====================================================
// DAILY TARGET PROTECTION
// =====================================================
private bool dailyTargetProtectionArmed;
private double lastDailyTargetProtectionStopPrice;

private DateTime lastDailyTargetProtectionChangeUtc =
    DateTime.MinValue;


// Minimum delay between protective order modifications.
private const int ProtectiveOrderChangeThrottleMs = 500;

// =====================================================
// UNIFIED PROTECTIVE CHANGE COORDINATOR
// =====================================================
private bool protectiveChangeInFlight;

// V7 stability guard:
// Account.CreateOrder() can raise OrderUpdate synchronously while the
// SL/TP bracket is still being constructed. Without this guard,
// OnAccountOrderUpdate -> SyncProtectiveBracketToEntry can re-enter
// SubmitProtectiveBracket before the first bracket is complete,
// creating thousands of JJ_STOP/JJ_TARGET orders and freezing NT.
private bool protectiveBracketBuildInProgress;

private long protectiveChangeSequence;
private long activeProtectiveChangeToken;
private string protectiveChangeOwner;
private DateTime protectiveChangeStartedUtc =
    DateTime.MinValue;

private const int ProtectiveChangeTimeoutMs = 3000;

        // Prop-firm end-of-day protection
        private bool forceFlatSentToday;
        private DateTime forceFlatDateNy;

        private DateTime lastExecutedSignalBar;

        private Account subscribedAccount;

        // =====================================================
        // DAILY PERSISTENCE
        // =====================================================
        private bool persistentDailyLocked;
        private string stateFolderPath;

        // Prevents two windows from running the same Account + Instrument.
        private string activeRuntimeLeaseKey;

        private BarsRequest barsRequest;
        private bool barsRequestSubscribed;

        // Higher timeframe context engines.
        private BarsRequest h1BarsRequest;
        private bool h1BarsRequestSubscribed;
        private bool h1BarsReady;
        private DateTime lastH1BarTime;

        private BarsRequest h4BarsRequest;
        private bool h4BarsRequestSubscribed;
        private bool h4BarsReady;
        private DateTime lastH4BarTime;

        private DateTime lastSignalBarTime;
        private bool barsReady;

        // Internal Range series used ONLY by Momentum Engine.
        // No second chart is required.
        private BarsRequest rangeBarsRequest;
        private bool rangeBarsRequestSubscribed;
        private bool rangeBarsReady;
        private DateTime lastRangeBarTime;

        private readonly object marketContextLock =
            new object();

        // =====================================================
        // INCREMENTAL EMA CACHE
        // =====================================================
        // BarsRequest cannot be fed directly to NinjaTrader EMA.
        // Cache the EMA prefix per Bars instance + period so normal
        // updates are O(1) instead of recomputing from bar 0.
        private sealed class EmaCacheState
        {
            public DateTime FirstBarTime;
            public List<double> Values;

            public EmaCacheState()
            {
                FirstBarTime = DateTime.MinValue;
                Values = new List<double>();
            }
        }

        private readonly object emaCacheLock =
            new object();

        private readonly Dictionary<Bars, Dictionary<int, EmaCacheState>>
            emaCaches =
                new Dictionary<Bars, Dictionary<int, EmaCacheState>>();

        // Higher-timeframe context is informational/scoring only.
        // V1 does NOT use this as a hard entry filter.
        private string latestH4Trend;
        private string latestH1Trend;
        private int latestHtfLongScore;
        private int latestHtfShortScore;
        private string latestHtfContextBias;

        // Latest confirmed M5 context consumed by the Range trigger.
        private bool latestM5ContextReady;
        private bool latestM5BullishTrend;
        private bool latestM5BearishTrend;
        private bool latestM5AboveVwap;
        private bool latestM5BelowVwap;
        private bool latestM5BullishStructure;
        private bool latestM5BearishStructure;
        private string latestM5LiquidityState;
        private string latestM5StructureState;
        private DateTime latestM5DecisionNyTime;
        private double latestM5Vwap;

        // Latest confirmed Range momentum values for UI / logs.
        private int latestRangeLongScore;
        private int latestRangeShortScore;
        private double latestRangeRatio;
        private double latestRangeVolumeRatio;
        private double latestRangeBodyRatio;
        private double latestRangeEmaSlope;
        private bool latestRangeHighBreakout;
        private bool latestRangeLowBreakout;
        private string latestRangeMomentumState;

        // =====================================================
        // LEARNING ENGINE
        // =====================================================
        private JJBotLearningMemory learningMemory;
        private JJBotLearningTrade activeLearningTrade;

        private string pendingLearningSide;
        private string pendingLearningSession;
        private string pendingLearningStructure;
        private DateTime pendingLearningSignalTimeNy;

        // =====================================================
        // STRUCTURE SETUP CONSUMPTION
        // =====================================================
        // A structure setup is identified by:
        // direction + sweep timestamp + confirmation timestamp.
        //
        // The pending key is attached to the submitted M5 structure
        // entry. It becomes consumed ONLY after the entry actually fills.
        private string pendingStructureSetupKey;
        private DateTime pendingStructureConfirmTime;

        private string consumedBullishStructureSetupKey;
        private string consumedBearishStructureSetupKey;

        // Time frontiers prevent an older already-traded setup from
        // becoming eligible again after a newer setup is consumed.
        private DateTime consumedBullishStructureConfirmTime;
        private DateTime consumedBearishStructureConfirmTime;

        private const int FastEmaPeriod = 9;
        private const int SlowEmaPeriod = 50;
        private const int BarsBack = 200;

        // Higher timeframe trend context.
        private const int HtfFastEmaPeriod = 50;
        private const int HtfSlowEmaPeriod = 200;
        private const int HtfBarsBack = 260;

        // New York session rules
        private const int RthVwapStart = 93000;

        // Trading window 1: 09:30 - 12:00 ET
        private const int BotSession1Start = 93000;
        private const int BotSession1End = 120000;

        // Trading window 2: 14:00 - 15:30 ET
        private const int BotSession2Start = 140000;
        private const int BotSession2End = 153000;

        // =====================================================
        // LEARNING ENGINE V3 - FASTER / LESS FRAGMENTED
        // =====================================================
        // Primary bucket:
        //      SIDE + STRUCTURE
        //
        // Session (AM / PM) is still captured as metadata on each trade,
        // but it no longer fragments the learning decision.
        //
        // Hierarchy (most-specific evidence wins):
        //      SPECIFIC (SIDE+STRUCTURE) -> SIDE -> GLOBAL
        //
        // A level becomes actionable after 15 trades.
        //
        // BLOCK when either:
        //  A) Expectancy < -$8/trade AND NetPnL < -$80
        //  B) WinRate < 30% AND Expectancy < $0
        //
        // The win-rate rule never blocks a positive-expectancy pattern.
        // Existing old XML keys that included AM/PM remain usable because
        // SPECIFIC evidence is aggregated dynamically by Side + Structure.
        private const int LearningMinTrades = 15;
        private const double LearningMinExpectancy = -8.00;
        private const double LearningMinNetPnL = -80.00;
        private const double LearningMinWinRate = 30.0;

        // =====================================================
        // LIQUIDITY / STRUCTURE RULES
        // =====================================================
        private const int SweepLookback = 5;
        private const int SweepMaxAgeBars = 6;

        // Keep the structural swing anchored to the SAME reference
        // window used to define the sweep. This prevents silent
        // desynchronization if SweepLookback is changed later.
        private const int StructureLookback = SweepLookback;

        // Ignore one-tick micro sweeps/noise.
        private const int MinimumSweepTicks = 2;

        // Momentum Engine V2 rules (confirmed internal Range bars only)
        private const int MomentumAverageLookback = 10;
        private const int MomentumBreakoutLookback = 3;
        private const double MomentumRangeExpansion = 1.15;
        private const double MomentumVolumeExpansion = 1.20;
        private const double MomentumMinBodyRatio = 0.60;
        private const int MomentumMinScore = 4;
        private const int MomentumRangeTicks = 20;

        // Trade Capital Protection V2
        // Applies to ALL bot entries.
        // +40 ticks  -> Break Even
        // +70 ticks  -> Lock +30 ticks
        // +100 ticks -> Trail 40 ticks behind price
        private const int MomentumBreakEvenTriggerTicks = 40;
        private const int MomentumLockTriggerTicks = 70;
        private const int MomentumLockProfitTicks = 30;
        private const int MomentumTrailTriggerTicks = 100;
        private const int MomentumTrailDistanceTicks = 40;

        // Dynamic target: the configured target is the MAXIMUM target.
        private const int DynamicTargetMinTicks = 60;
        private const double DynamicTargetMediumFactor = 0.80;
        private const double DynamicTargetWeakFactor = 0.65;

        // Once the daily target is reached, protect most of it
        // instead of immediately flattening a profitable runner.
        private const double DailyTargetGivebackDollars = 50.0;
        private const int DailyTargetTrailDistanceTicks = 20;

        // Force flat at 16:25 ET for prop-firm safety.
        private const int ForceFlatTimeNy = 162500;

        // =====================================================
        // BACKGROUND ENGINE WINDOW LIFECYCLE
        // =====================================================
        private bool allowPermanentClose;
        private bool engineWindowAlive;

        public bool IsEngineWindowAlive
        {
            get
            {
                return engineWindowAlive;
            }
        }

        // =====================================================
        // CONSTRUCTOR
        // =====================================================
        public JJBotWindow()
        {
            Caption = "J&J NY Trading Bot";

            allowPermanentClose = false;
            engineWindowAlive = true;

            Width = 520;
            Height = 960;

            MinWidth = 480;
            MinHeight = 720;

            botRunning = false;
            activeDirection = "BOTH";
            activeStrategyMode = "HYBRID";

            currentSignalState =
                "WAITING";

            currentSetupState =
                "WAITING";

            activeContracts = 1;
            activeStopTicks = 100;
            activeTargetTicks = 150;
            activeMaxTrades = 2;
            activeDailyTarget = 300;
            activeDailyLoss = 200;

            tradesToday = 0;
            amTradesToday = 0;
            pmTradesToday = 0;
            pendingEntrySession = "OUTSIDE";

            botDailyPnL = 0;
            botUnrealizedPnL = 0;
            activeTradingDate = DateTime.MinValue;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;

            entryPending = false;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;

            activeEntryUsesMomentumTrailing = false;
            momentumTrailingStage = 0;
            lastMomentumTrailingStopPrice = 0;
            lastMomentumTrailingChangeUtc = DateTime.MinValue;
			
            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;
            lastDailyTargetProtectionChangeUtc = DateTime.MinValue;

            protectiveChangeInFlight = false;
            protectiveBracketBuildInProgress = false;
            protectiveChangeSequence = 0;
            activeProtectiveChangeToken = 0;
            protectiveChangeOwner = string.Empty;
            protectiveChangeStartedUtc =
                DateTime.MinValue;

            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;

            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            lastExecutedSignalBar = DateTime.MinValue;

            subscribedAccount = null;

            visualLogLines =
                new Queue<string>();

            platformTelemetryTimer = null;
            platformTelemetryRequestInFlight = false;
            platformApiKey = string.Empty;
            platformServerUrl = "http://localhost:3001";
            platformConfigFile = string.Empty;
            lastPlatformTelemetrySuccessUtc =
                DateTime.MinValue;

            platformCommandTimer = null;
            platformCommandRequestInFlight = false;
            lastProcessedPlatformCommandId =
                string.Empty;

            platformRemoteStartContext =
                false;

            persistentDailyLocked = false;

            activeRuntimeLeaseKey =
                string.Empty;

            stateFolderPath =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments
                    ),
                    "NinjaTrader 8",
                    "JJBotData"
                );

            barsReady = false;
            barsRequestSubscribed = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            h1BarsRequestSubscribed = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            h4BarsRequestSubscribed = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            rangeBarsRequestSubscribed = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestM5ContextReady = false;
            latestM5LiquidityState = "NONE";
            latestM5StructureState = "WAITING";
            latestRangeMomentumState = "WAITING RANGE";

            learningMemory =
                new JJBotLearningMemory();

            activeLearningTrade = null;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            Content = BuildInterface();

            Closing += OnBotWindowClosing;
            Closed += OnBotWindowClosed;

            LoadPlatformBridgeConfig();
            StartPlatformTelemetry();
            StartPlatformCommandPolling();
        }

        // =====================================================
        // MAIN INTERFACE
        // =====================================================
        private UIElement BuildInterface()
        {
            ScrollViewer scroll = new ScrollViewer();

            scroll.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            Border mainBorder = new Border();

            mainBorder.Padding =
                new Thickness(22);

            mainBorder.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        12,
                        17,
                        24
                    )
                );

            StackPanel mainPanel =
                new StackPanel();

            mainBorder.Child = mainPanel;
            scroll.Content = mainBorder;

            // =================================================
            // HEADER
            // =================================================
            TextBlock title = new TextBlock();

            title.Text =
                "J&J NY TRADING BOT";

            title.FontSize = 24;

            title.FontWeight =
                FontWeights.Bold;

            title.Foreground =
                Brushes.White;

            title.HorizontalAlignment =
                HorizontalAlignment.Center;

            title.Margin =
                new Thickness(
                    0,
                    5,
                    0,
                    3
                );

            mainPanel.Children.Add(title);

            TextBlock subtitle =
                new TextBlock();

            subtitle.Text =
                "AUTOMATED FUTURES ENGINE";

            subtitle.FontSize = 11;

            subtitle.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            subtitle.HorizontalAlignment =
                HorizontalAlignment.Center;

            subtitle.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    20
                );

            mainPanel.Children.Add(subtitle);

            // =================================================
            // TRADING CONNECTION
            // =================================================
            Border connectionCard =
                CreateCard();

            StackPanel connectionPanel =
                new StackPanel();

            connectionCard.Child =
                connectionPanel;

            connectionPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING CONNECTION"
                )
            );

            // ACCOUNT SELECTOR
            accountSelector =
                new AccountSelector();

            accountSelector.Width = 230;
            accountSelector.Height = 30;

            accountSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            accountSelector.SelectionChanged +=
                AccountSelectorChanged;

            AddRow(
                connectionPanel,
                "Account",
                accountSelector
            );

            // INSTRUMENT SELECTOR
            instrumentSelector =
                new InstrumentSelector();

            instrumentSelector.Width = 230;
            instrumentSelector.Height = 30;

            instrumentSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            instrumentSelector.InstrumentChanged +=
                InstrumentSelectorChanged;

            AddRow(
                connectionPanel,
                "Instrument",
                instrumentSelector
            );

            accountStatusText =
                CreateSmallStatusText(
                    "No account selected"
                );

            connectionPanel.Children.Add(
                accountStatusText
            );

            instrumentStatusText =
                CreateSmallStatusText(
                    "No instrument selected"
                );

            connectionPanel.Children.Add(
                instrumentStatusText
            );

            mainPanel.Children.Add(
                connectionCard
            );

            // =================================================
            // BOT STATUS
            // =================================================
            Border statusCard =
                CreateCard();

            StackPanel statusPanel =
                new StackPanel();

            statusCard.Child =
                statusPanel;

            statusPanel.Children.Add(
                CreateSectionTitle(
                    "BOT STATUS"
                )
            );

            statusText =
                new TextBlock();

            statusText.Text =
                "● STOPPED";

            statusText.FontSize = 20;

            statusText.FontWeight =
                FontWeights.Bold;

            statusText.Foreground =
                Brushes.OrangeRed;

            statusText.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    2
                );

            statusPanel.Children.Add(
                statusText
            );

            mainPanel.Children.Add(
                statusCard
            );

            TextBlock executionModeText =
                new TextBlock();

            executionModeText.Text =
                "EXECUTION MODE  •  SIM ONLY";

            executionModeText.Foreground =
                Brushes.Goldenrod;

            executionModeText.FontWeight =
                FontWeights.Bold;

            executionModeText.FontSize = 11;

            executionModeText.HorizontalAlignment =
                HorizontalAlignment.Center;

            executionModeText.Margin =
                new Thickness(
                    0,
                    -4,
                    0,
                    12
                );

            mainPanel.Children.Add(
                executionModeText
            );

            // =================================================
            // TRADING SETTINGS
            // =================================================
            Border settingsCard =
                CreateCard();

            StackPanel settingsPanel =
                new StackPanel();

            settingsCard.Child =
                settingsPanel;

            settingsPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING SETTINGS"
                )
            );

            directionCombo =
                new ComboBox();

            directionCombo.Items.Add(
                "BOTH"
            );

            directionCombo.Items.Add(
                "LONG ONLY"
            );

            directionCombo.Items.Add(
                "SHORT ONLY"
            );

            directionCombo.SelectedIndex = 0;

            directionCombo.Width = 150;
            directionCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Direction",
                directionCombo
            );

            strategyCombo =
                new ComboBox();

            strategyCombo.Items.Add(
                "STRUCTURE"
            );

            strategyCombo.Items.Add(
                "MOMENTUM SCALP"
            );

            strategyCombo.Items.Add(
                "HYBRID"
            );

            strategyCombo.SelectedIndex = 2;
            strategyCombo.Width = 150;
            strategyCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Strategy",
                strategyCombo
            );

            contractsBox =
                CreateTextBox("1");

            AddRow(
                settingsPanel,
                "Contracts",
                contractsBox
            );

            stopBox =
                CreateTextBox("100");

            AddRow(
                settingsPanel,
                "Stop Loss (ticks)",
                stopBox
            );

            targetBox =
                CreateTextBox("150");

            AddRow(
                settingsPanel,
                "Profit Target (ticks)",
                targetBox
            );

            maxTradesBox =
                CreateTextBox("2");

            AddRow(
                settingsPanel,
                "Max Trades / Session",
                maxTradesBox
            );

            mainPanel.Children.Add(
                settingsCard
            );

            // =================================================
            // RISK MANAGEMENT
            // =================================================
            Border riskCard =
                CreateCard();

            StackPanel riskPanel =
                new StackPanel();

            riskCard.Child =
                riskPanel;

            riskPanel.Children.Add(
                CreateSectionTitle(
                    "RISK MANAGEMENT"
                )
            );

            dailyTargetBox =
                CreateTextBox("300");

            AddRow(
                riskPanel,
                "Daily Target $",
                dailyTargetBox
            );

            dailyLossBox =
                CreateTextBox("200");

            AddRow(
                riskPanel,
                "Daily Loss $",
                dailyLossBox
            );

            mainPanel.Children.Add(
                riskCard
            );

            // =================================================
            // SIGNAL ENGINE
            // =================================================
            Border signalCard =
                CreateCard();

            StackPanel signalPanel =
                new StackPanel();

            signalCard.Child =
                signalPanel;

            signalPanel.Children.Add(
                CreateSectionTitle(
                    "SIGNAL ENGINE - 5 MINUTE"
                )
            );

            lastPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Last Price",
                lastPriceText
            );

            emaFastText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 9",
                emaFastText
            );

            emaSlowText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 50",
                emaSlowText
            );

            vwapText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Session VWAP",
                vwapText
            );

            trendText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Trend",
                trendText
            );

            nySessionText =
                CreateValueText(
                    "CLOSED"
                );

            AddInfoRow(
                signalPanel,
                "NY Session",
                nySessionText
            );

            liquidityText =
                CreateValueText(
                    "NONE"
                );

            AddInfoRow(
                signalPanel,
                "Liquidity Sweep",
                liquidityText
            );

            structureText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Structure",
                structureText
            );

            momentumText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Momentum",
                momentumText
            );

            confirmationText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Confirmation",
                confirmationText
            );

            setupText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Setup",
                setupText
            );

            barTimeText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "5m Bar",
                barTimeText
            );

            mainPanel.Children.Add(
                signalCard
            );

            // =================================================
            // EXECUTION MONITOR
            // =================================================
            Border executionCard =
                CreateCard();

            StackPanel executionPanel =
                new StackPanel();

            executionCard.Child =
                executionPanel;

            executionPanel.Children.Add(
                CreateSectionTitle(
                    "EXECUTION MONITOR"
                )
            );

            positionText =
                CreateValueText(
                    "FLAT"
                );

            AddInfoRow(
                executionPanel,
                "Position",
                positionText
            );

            positionQtyText =
                CreateValueText(
                    "0"
                );

            AddInfoRow(
                executionPanel,
                "Position Qty",
                positionQtyText
            );

            entryPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Entry Price",
                entryPriceText
            );

            stopPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Stop Loss",
                stopPriceText
            );

            targetPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Profit Target",
                targetPriceText
            );

            riskRewardText =
                CreateValueText(
                    "1 : 1.50"
                );

            AddInfoRow(
                executionPanel,
                "Risk / Reward",
                riskRewardText
            );

            orderStatusText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                executionPanel,
                "Order Status",
                orderStatusText
            );

            mainPanel.Children.Add(
                executionCard
            );

            // =================================================
            // LIVE SESSION
            // =================================================
            Border infoCard =
                CreateCard();

            StackPanel infoPanel =
                new StackPanel();

            infoCard.Child =
                infoPanel;

            infoPanel.Children.Add(
                CreateSectionTitle(
                    "LIVE SESSION"
                )
            );

            pnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Realized PnL",
                pnlText
            );

            unrealizedPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Unrealized PnL",
                unrealizedPnlText
            );

            totalPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Total PnL",
                totalPnlText
            );

            tradesText =
                CreateValueText(
                    "0 / 2"
                );

            AddInfoRow(
                infoPanel,
                "Trades",
                tradesText
            );

            signalText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                infoPanel,
                "Signal",
                signalText
            );

            mainPanel.Children.Add(
                infoCard
            );

            // =================================================
            // BOT ACTIVITY LOG
            // =================================================
            Border logCard =
                CreateCard();

            StackPanel logPanel =
                new StackPanel();

            logCard.Child =
                logPanel;

            Grid logHeader =
                new Grid();

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        GridLength.Auto
                }
            );

            TextBlock logTitle =
                CreateSectionTitle(
                    "BOT ACTIVITY LOG"
                );

            Grid.SetColumn(
                logTitle,
                0
            );

            logHeader.Children.Add(
                logTitle
            );

            clearLogButton =
                new Button();

            clearLogButton.Content =
                "CLEAR";

            clearLogButton.Width =
                65;

            clearLogButton.Height =
                24;

            clearLogButton.FontSize =
                10;

            clearLogButton.Margin =
                new Thickness(
                    8,
                    0,
                    0,
                    0
                );

            clearLogButton.Click +=
                ClearVisualLogClicked;

            Grid.SetColumn(
                clearLogButton,
                1
            );

            logHeader.Children.Add(
                clearLogButton
            );

            logPanel.Children.Add(
                logHeader
            );

            visualLogBox =
                new TextBox();

            visualLogBox.IsReadOnly =
                true;

            visualLogBox.AcceptsReturn =
                true;

            visualLogBox.TextWrapping =
                TextWrapping.Wrap;

            visualLogBox.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            visualLogBox.HorizontalScrollBarVisibility =
                ScrollBarVisibility.Disabled;

            visualLogBox.Height =
                190;

            visualLogBox.Margin =
                new Thickness(
                    0,
                    10,
                    0,
                    0
                );

            visualLogBox.Padding =
                new Thickness(8);

            visualLogBox.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        10,
                        15,
                        22
                    )
                );

            visualLogBox.Foreground =
                Brushes.LightGray;

            visualLogBox.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            visualLogBox.BorderThickness =
                new Thickness(1);

            visualLogBox.FontFamily =
                new FontFamily(
                    "Consolas"
                );

            visualLogBox.FontSize =
                11;

            logPanel.Children.Add(
                visualLogBox
            );

            mainPanel.Children.Add(
                logCard
            );

            AppendVisualLog(
                "Visual log ready."
            );

            // =================================================
            // TEST EXECUTION
            // SIM ONLY
            // =================================================
            Border testCard =
                CreateCard();

            StackPanel testPanel =
                new StackPanel();

            testCard.Child =
                testPanel;

            testPanel.Children.Add(
                CreateSectionTitle(
                    "TEST EXECUTION - SIM ONLY"
                )
            );

            TextBlock testHelp =
                new TextBlock();

            testHelp.Text =
                "Use only to verify Entry → SL/TP → OCO → Monitor.";

            testHelp.TextWrapping =
                TextWrapping.Wrap;

            testHelp.Foreground =
                Brushes.Gray;

            testHelp.FontSize = 10;

            testHelp.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    10
                );

            testPanel.Children.Add(
                testHelp
            );

            Grid testGrid =
                new Grid();

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testLongButton =
                CreateButton(
                    "TEST LONG"
                );

            testLongButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            testLongButton.Click +=
                TestLongClicked;

            Grid.SetColumn(
                testLongButton,
                0
            );

            testGrid.Children.Add(
                testLongButton
            );

            testShortButton =
                CreateButton(
                    "TEST SHORT"
                );

            testShortButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            testShortButton.Click +=
                TestShortClicked;

            Grid.SetColumn(
                testShortButton,
                1
            );

            testGrid.Children.Add(
                testShortButton
            );

            testPanel.Children.Add(
                testGrid
            );

            mainPanel.Children.Add(
                testCard
            );

            // =================================================
            // START / STOP
            // =================================================
            Grid buttonGrid =
                new Grid();

            buttonGrid.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    10
                );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            startButton =
                CreateButton(
                    "▶ START BOT"
                );

            startButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            startButton.Click +=
                StartBotClicked;

            Grid.SetColumn(
                startButton,
                0
            );

            buttonGrid.Children.Add(
                startButton
            );

            stopButton =
                CreateButton(
                    "■ STOP BOT"
                );

            stopButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            stopButton.IsEnabled =
                false;

            stopButton.Click +=
                StopBotClicked;

            Grid.SetColumn(
                stopButton,
                1
            );

            buttonGrid.Children.Add(
                stopButton
            );

            mainPanel.Children.Add(
                buttonGrid
            );

            // =================================================
            // CLOSE ALL
            // TEST MODE ONLY
            // =================================================
            closeAllButton =
                CreateButton(
                    "⚠ CLOSE ALL"
                );

            closeAllButton.FontSize = 15;

            closeAllButton.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    15
                );

            closeAllButton.Click +=
                CloseAllClicked;

            mainPanel.Children.Add(
                closeAllButton
            );

            TextBlock warning =
                new TextBlock();

            warning.Text =
                "SIM EXECUTION • PERSISTENCE V5 • VISUAL LOG ACTIVE • orders ONLY to accounts containing Sim.";

            warning.TextWrapping =
                TextWrapping.Wrap;

            warning.HorizontalAlignment =
                HorizontalAlignment.Center;

            warning.TextAlignment =
                TextAlignment.Center;

            warning.Foreground =
                Brushes.Goldenrod;

            warning.FontSize = 10;

            warning.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    8
                );

            mainPanel.Children.Add(
                warning
            );

            TextBlock footer =
                new TextBlock();

            footer.Text =
                "NY SESSIONS • 09:30-12:00 + 14:00-15:30 ET • EMA + VWAP + STRUCTURE + MOMENTUM + TRAILING + LEARNING";

            footer.HorizontalAlignment =
                HorizontalAlignment.Center;

            footer.Foreground =
                Brushes.Gray;

            footer.FontSize = 11;

            mainPanel.Children.Add(
                footer
            );

            return scroll;
        }

        // =====================================================
        // ACCOUNT CHANGED
        // =====================================================
        private void AccountSelectorChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (accountSelector == null)
                return;

            Account previousAccount =
                selectedAccount;

            Account newAccount =
                accountSelector.SelectedAccount;

            bool accountChanged =
                previousAccount != null
                ? (
                    newAccount == null ||
                    !string.Equals(
                        previousAccount.Name,
                        newAccount.Name,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                : newAccount != null;

            // =====================================================
            // SAFETY: ACCOUNT CHANGES MUST STOP THE ACTIVE ENGINE
            // =====================================================
            // Bars callbacks and Account.ExecutionUpdate / OrderUpdate
            // must never point at different accounts.
            if (
                accountChanged &&
                botRunning
            )
            {
                botRunning =
                    false;

                StopBarsEngine();

                ReleaseRuntimeLease();

                // Immediately detach callbacks from the OLD account.
                UnsubscribeExecutionAccount();

                currentSignalState =
                    "ACCOUNT CHANGED";

                currentSetupState =
                    "STOPPED";

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "ACCOUNT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;

                if (accountSelector != null)
                    accountSelector.IsEnabled = true;

                if (instrumentSelector != null)
                    instrumentSelector.IsEnabled = true;

                PrintBotMessage(
                    "BOT STOPPED - ACCOUNT CHANGED."
                );
            }

            // Even if the main signal engine was already stopped (for
            // example after a manual SIM test), never keep callbacks
            // subscribed to an account that is no longer selected.
            if (
                accountChanged &&
                !botRunning
            )
            {
                UnsubscribeExecutionAccount();
            }

            // Remove the OLD bridge state before the selection is replaced.
            if (
                accountChanged &&
                previousAccount != null &&
                selectedInstrument != null
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    previousAccount.Name,
                    selectedInstrument.FullName
                );
            }

            selectedAccount =
                newAccount;

            if (selectedAccount != null)
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "Account: "
                        + selectedAccount.Name;

                    accountStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "ACCOUNT SELECTED: "
                    + selectedAccount.Name
                );

                PublishSharedState();
            }
            else
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "No account selected";

                    accountStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            // Restore only AFTER the engine has been stopped and the
            // new Account + Instrument selection is stable.
            TryRestorePersistentStateForSelection();
        }

        // =====================================================
        // INSTRUMENT CHANGED
        // =====================================================
        private void InstrumentSelectorChanged(
            object sender,
            EventArgs e)
        {
            if (instrumentSelector == null)
                return;

            Instrument previousInstrument =
                selectedInstrument;

            Instrument newInstrument =
                instrumentSelector.Instrument;

            // Remove the OLD bridge entry before publishing the newly
            // selected instrument. Otherwise the old chart can keep a
            // stale snapshot forever.
            if (
                selectedAccount != null &&
                previousInstrument != null &&
                (
                    newInstrument == null ||
                    !string.Equals(
                        previousInstrument.FullName,
                        newInstrument.FullName,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    selectedAccount.Name,
                    previousInstrument.FullName
                );
            }

            // If the bot is running, stop the old data subscription first.
            if (botRunning)
            {
                StopBarsEngine();

                botRunning = false;

                ReleaseRuntimeLease();

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "INSTRUMENT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;
            }

            selectedInstrument =
                newInstrument;

            if (selectedInstrument != null)
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "Instrument: "
                        + selectedInstrument.FullName;

                    instrumentStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "INSTRUMENT SELECTED: "
                    + selectedInstrument.FullName
                );

                PublishSharedState();
            }
            else
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "No instrument selected";

                    instrumentStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            ResetSignalDisplay();
            ResetExecutionMonitor();

            TryRestorePersistentStateForSelection();
        }

        // =====================================================
        // TEST LONG / SHORT
        // SIM ONLY
        // =====================================================
        private void TestLongClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                true
            );
        }

        private void TestShortClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                false
            );
        }

        private void RunManualSimTest(
            bool isLong)
        {
            // When TEST LONG / TEST SHORT comes from J&J Company Bro,
            // ApplyPlatformStartConfiguration() has already resolved the
            // exact Account + Instrument selected in the platform.
            //
            // Do NOT overwrite them with the hidden NinjaTrader selectors
            // (which may still display Sim101).
            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;

                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select a SIM account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (
                !IsSimulationAccount(
                    selectedAccount
                )
            )
            {
                MessageBox.Show(
                    "TEST EXECUTION is SIM ONLY.\\n\\n"
                    + "Select an account whose name begins with 'Sim'.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                ) ||
                contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                ) ||
                stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                ) ||
                targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                ) ||
                maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                ) ||
                dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                ) ||
                dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            // Subscribe even when the main signal engine is STOPPED.
            SubscribeExecutionAccount(
                selectedAccount
            );

            // IMPORTANT:
            // TEST LONG / TEST SHORT must use the same persistent
            // counters as automatic trading. Otherwise reopening the
            // window could incorrectly start manual tests from 0 / 2.
            LoadOrResetPersistentDailyState();

            if (persistentDailyLocked)
            {
                // Manual TEST LONG / TEST SHORT are SIM-only diagnostics.
                // They are intentionally allowed even when the normal
                // automatic engine is DailyLocked (for example after 16:25 ET),
                // so configurations can be tested at night.
                PrintBotMessage(
                    "MANUAL SIM TEST - DAILY LOCK BYPASSED"
                    + " | Trades: "
                    + tradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                );
            }

            // Give the manual test its own temporary execution permission.
            bool wasRunning =
                botRunning;

            botRunning =
                true;

            executionStatus =
                isLong
                    ? "TEST LONG"
                    : "TEST SHORT";

            UpdateExecutionMonitor();

            DateTime uniqueTestSignal =
                DateTime.UtcNow;

         TrySubmitEntry(
    isLong,
    uniqueTestSignal,
    true
);

            // Keep the signal engine's previous RUNNING/STOPPED state.
            // The submitted order and its OCO bracket continue to be
            // managed by Account.ExecutionUpdate independently.
            botRunning =
                wasRunning;

            PrintBotMessage(
                "MANUAL SIM TEST REQUESTED | "
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
            );
        }

        // =====================================================
        // START BOT
        // =====================================================
        private void StartBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;
            }

            if (selectedAccount == null)
            {
                MessageBox.Show(
                    "Select an account before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (!IsSimulationAccount(selectedAccount))
            {
                MessageBox.Show(
                    "SIM ONLY protection is active.\n\n"
                    + "The selected account is not recognized as a simulation account.\n"
                    + "Select an account whose name begins with 'Sim'.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                PrintBotMessage(
                    "LIVE ACCOUNT BLOCKED: "
                    + selectedAccount.Name
                );

                return;
            }

            if (!platformRemoteStartContext)
            {
                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (selectedInstrument == null)
            {
                MessageBox.Show(
                    "Select an instrument before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                )
                || contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                )
                || stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                )
                || targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                )
                || maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                )
                || dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                )
                || dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            string requestedLeaseKey;

            if (
                !JJBotRuntimeCoordinator.TryAcquireBotLease(
                    selectedAccount.Name,
                    selectedInstrument.FullName,
                    out requestedLeaseKey
                )
            )
            {
                MessageBox.Show(
                    "Another J&J Bot window is already running this same "
                    + "Account + Instrument.\n\n"
                    + "Account: "
                    + selectedAccount.Name
                    + "\nInstrument: "
                    + selectedInstrument.FullName
                    + "\n\nStop or close the other bot window before starting this one.",
                    "J&J Trading Bot - DUPLICATE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                PrintBotMessage(
                    "START BLOCKED - DUPLICATE ACCOUNT + INSTRUMENT"
                    + " | Account: "
                    + selectedAccount.Name
                    + " | Instrument: "
                    + selectedInstrument.FullName
                );

                return;
            }

            activeRuntimeLeaseKey =
                requestedLeaseKey;

            activeDirection =
                directionCombo != null &&
                directionCombo.SelectedItem != null
                    ? directionCombo.SelectedItem.ToString()
                    : "BOTH";

            activeStrategyMode =
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
                    ? strategyCombo.SelectedItem.ToString()
                    : "HYBRID";

            string direction =
                activeDirection;

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            // Do NOT reset tradesToday / botDailyPnL here.
            // They belong to the persistent daily state and are
            // restored below by LoadOrResetPersistentDailyState().
            botUnrealizedPnL = 0;
            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;

            entryPending = false;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;
            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            SubscribeExecutionAccount(
                selectedAccount
            );

            LoadOrResetPersistentDailyState();

            tradesText.Text =
                tradesToday
                + " / "
                + activeMaxTrades;

            UpdatePnlDisplay();

            ResetExecutionMonitor();

            signalText.Text =
                "LOADING 5M DATA...";

            signalText.Foreground =
                Brushes.Goldenrod;

            statusText.Text =
                "● STARTING";

            statusText.Foreground =
                Brushes.Goldenrod;

            startButton.IsEnabled =
                false;

            stopButton.IsEnabled =
                true;

            botRunning = true;

            currentSignalState =
                "LOADING 5M DATA...";

            currentSetupState =
                "STARTING";

            PublishSharedState();

            if (directionCombo != null)
                directionCombo.IsEnabled = false;

            if (accountSelector != null)
                accountSelector.IsEnabled = false;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = false;

            LoadLearningMemory();

            PrintBotMessage(
                "LEARNING ENGINE V3 ACTIVE"
                + " | Hierarchy: SPECIFIC(SIDE+STRUCTURE) > SIDE > GLOBAL"
                + " | MinTrades: "
                + LearningMinTrades
                + " | Block A: Exp < "
                + LearningMinExpectancy.ToString("$0.00")
                + " & Net < "
                + LearningMinNetPnL.ToString("$0.00")
                + " | Block B: WinRate < "
                + LearningMinWinRate.ToString("0")
                + "% & Exp < $0"
            );

            PrintBotMessage(
                "STARTING"
                + " | Account: "
                + selectedAccount.Name
                + " | Instrument: "
                + selectedInstrument.FullName
                + " | Direction: "
                + direction
                + " | Strategy: "
                + activeStrategyMode
                + " | Contracts: "
                + contracts
                + " | SL: "
                + stopTicks
                + " ticks"
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxTrades: "
                + maxTrades
                + " | DailyTarget: $"
                + dailyTarget
                + " | DailyLoss: $"
                + dailyLoss
            );

            StartBarsEngine();
        }

        // =====================================================
        // START 5-MINUTE DATA ENGINE
        // =====================================================
        private void StartBarsEngine()
        {
            StopBarsEngine();

            barsReady = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestM5ContextReady = false;
            latestRangeMomentumState = "WAITING RANGE";

            try
            {
                barsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                barsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 5
                    };

                // Neutral template for data collection.
                // We enforce the NY bot time window separately later.
                barsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                barsRequest.Update +=
                    OnBarsRequestUpdate;

                barsRequestSubscribed = true;

                barsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnBarsRequestCompleted
                    )
                );

                // 1-HOUR CONTEXT
                h1BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h1BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 60
                    };

                h1BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h1BarsRequest.Update +=
                    OnH1BarsRequestUpdate;

                h1BarsRequestSubscribed = true;

                h1BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH1BarsRequestCompleted
                    )
                );

                // 4-HOUR CONTEXT
                h4BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h4BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 240
                    };

                h4BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h4BarsRequest.Update +=
                    OnH4BarsRequestUpdate;

                h4BarsRequestSubscribed = true;

                h4BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH4BarsRequestCompleted
                    )
                );

                // Internal 20-tick Range series. This is independent
                // from the chart the user has open.
                rangeBarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                rangeBarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Range,

                        Value = MomentumRangeTicks
                    };

                rangeBarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                rangeBarsRequest.Update +=
                    OnRangeBarsRequestUpdate;

                rangeBarsRequestSubscribed = true;

                rangeBarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnRangeBarsRequestCompleted
                    )
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BARS REQUEST EXCEPTION: "
                    + ex.Message
                );

                SetEngineError(
                    "DATA ERROR"
                );
            }
        }

        // =====================================================
        // INITIAL HISTORICAL BARS LOADED
        // =====================================================
        private void OnBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "BARS REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "DATA ERROR"
                        );
                    })
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count < SlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 5M BARS TO CALCULATE EMA 50."
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "WAITING FOR DATA"
                        );
                    })
                );

                return;
            }

            barsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            // Do not fire a historical crossover immediately at startup.
            lastSignalBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateSignalFromBars(
                request.Bars,
                false
            );

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    statusText.Text =
                        "● RUNNING";

                    statusText.Foreground =
                        Brushes.LimeGreen;
                })
            );

            PrintBotMessage(
                "5M DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL 1H CONTEXT BARS LOADED
        // =====================================================
        private void OnH1BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "1H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 1H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h1BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "1H",
                false
            );

            PrintBotMessage(
                "1H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL 4H CONTEXT BARS LOADED
        // =====================================================
        private void OnH4BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "4H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 4H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h4BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "4H",
                false
            );

            PrintBotMessage(
                "4H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL INTERNAL RANGE BARS LOADED
        // =====================================================
        private void OnRangeBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "RANGE REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH RANGE BARS FOR MOMENTUM."
                );

                return;
            }

            rangeBarsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            lastRangeBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateMomentumFromRangeBars(
                request.Bars,
                false
            );

            PrintBotMessage(
                "RANGE DATA READY | "
                + MomentumRangeTicks
                + " TICKS | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // REAL-TIME 1H CONTEXT UPDATE EVENT
        // =====================================================
        private void OnH1BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h1BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h1BarsRequest == null ||
                    h1BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h1BarsRequest.Bars,
                    "1H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "1H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // REAL-TIME 4H CONTEXT UPDATE EVENT
        // =====================================================
        private void OnH4BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h4BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h4BarsRequest == null ||
                    h4BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h4BarsRequest.Bars,
                    "4H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "4H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // HIGHER-TIMEFRAME CONTEXT ENGINE
        //
        // Uses the latest CLOSED 1H / 4H bar.
        // Trend model:
        //   Strong bullish: Close > EMA50 > EMA200
        //   Strong bearish: Close < EMA50 < EMA200
        //   Weak bullish:   EMA50 > EMA200
        //   Weak bearish:   EMA50 < EMA200
        //
        // IMPORTANT: this context does NOT block entries in V1.
        // It is published visually and available to learning.
        // =====================================================
        private void UpdateHigherTimeframeContext(
            Bars bars,
            string timeframe,
            bool realTimeUpdate)
        {
            if (
                bars == null ||
                bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                return;
            }

            int closedIndex =
                bars.Count - 2;

            if (
                closedIndex <
                    HtfSlowEmaPeriod
            )
            {
                return;
            }

            DateTime closedTime =
                bars.GetTime(
                    closedIndex
                );

            if (
                timeframe == "1H" &&
                closedTime ==
                    lastH1BarTime
            )
            {
                return;
            }

            if (
                timeframe == "4H" &&
                closedTime ==
                    lastH4BarTime
            )
            {
                return;
            }

            double ema50 =
                CalculateEma(
                    bars,
                    HtfFastEmaPeriod,
                    closedIndex
                );

            double ema200 =
                CalculateEma(
                    bars,
                    HtfSlowEmaPeriod,
                    closedIndex
                );

            double close =
                bars.GetClose(
                    closedIndex
                );

            string trend =
                close > ema50 &&
                ema50 > ema200
                    ? "BULLISH"
                    : close < ema50 &&
                      ema50 < ema200
                        ? "BEARISH"
                        : ema50 > ema200
                            ? "BULLISH WEAK"
                            : ema50 < ema200
                                ? "BEARISH WEAK"
                                : "NEUTRAL";

            lock (marketContextLock)
            {
                if (timeframe == "1H")
                {
                    latestH1Trend =
                        trend;

                    lastH1BarTime =
                        closedTime;
                }
                else
                {
                    latestH4Trend =
                        trend;

                    lastH4BarTime =
                        closedTime;
                }

                RecalculateHigherTimeframeScores();
            }

            PrintBotMessage(
                "HTF CONTEXT "
                + timeframe
                + " | "
                + trend
                + " | Close: "
                + close.ToString("0.00")
                + " | EMA50: "
                + ema50.ToString("0.00")
                + " | EMA200: "
                + ema200.ToString("0.00")
                + " | LONG "
                + latestHtfLongScore
                + "/2"
                + " | SHORT "
                + latestHtfShortScore
                + "/2"
            );

            PublishSharedState();
        }

        private void RecalculateHigherTimeframeScores()
        {
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            latestHtfContextBias =
                latestHtfLongScore >
                    latestHtfShortScore
                    ? "LONG "
                        + latestHtfLongScore
                        + "/2"
                    : latestHtfShortScore >
                        latestHtfLongScore
                        ? "SHORT "
                            + latestHtfShortScore
                            + "/2"
                        : "NEUTRAL "
                            + latestHtfLongScore
                            + "/2";
        }

        // =====================================================
        // REAL-TIME INTERNAL RANGE UPDATE EVENT
        // =====================================================
        private void OnRangeBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !rangeBarsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count <
                        MomentumAverageLookback +
                        MomentumBreakoutLookback + 3
                )
                {
                    return;
                }

                DateTime currentRangeBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newRangeBarStarted =
                    lastRangeBarTime != DateTime.MinValue &&
                    currentRangeBarTime != lastRangeBarTime;

                if (
                    rangeBarsRequest == null ||
                    rangeBarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateMomentumFromRangeBars(
                    rangeBarsRequest.Bars,
                    newRangeBarStarted
                );

                // Capital protection is evaluated on every Range update,
                // not only when a new Range bar closes.
                int liveRangeIndex =
                    rangeBarsRequest.Bars.Count - 1;

                if (liveRangeIndex >= 0)
                {
                    double liveRangePrice =
                        rangeBarsRequest.Bars.GetClose(
                            liveRangeIndex
                        );

                    UpdateUnrealizedPnL(
                        liveRangePrice
                    );

                    // Daily target protection has priority over
                    // the normal per-trade trailing logic.
                    UpdateDailyTargetProtection(
                        liveRangePrice
                    );

                    UpdateMomentumTrailingStop(
                        liveRangePrice
                    );

                    CheckForceFlatTime();
                    CheckDailyLossEmergency();
                }

                if (newRangeBarStarted)
                {
                    lastRangeBarTime =
                        currentRangeBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "RANGE UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // REAL-TIME BAR UPDATE EVENT
        // =====================================================
        private void OnBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !barsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count < SlowEmaPeriod + 2
                )
                {
                    return;
                }

                DateTime currentBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newBarStarted =
                    lastSignalBarTime != DateTime.MinValue &&
                    currentBarTime != lastSignalBarTime;

                // Update current bias/EMA display on every real-time bar update.
                if (barsRequest == null || barsRequest.Bars == null)
                    return;

                UpdateSignalFromBars(
                    barsRequest.Bars,
                    newBarStarted
                );

                if (newBarStarted)
                {
                    lastSignalBarTime =
                        currentBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BAR UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // CALCULATE EMA 9 / EMA 50
        // =====================================================
        private void UpdateSignalFromBars(
            Bars bars,
            bool checkClosedBarCross)
        {
            if (
                bars == null ||
                bars.Count < SlowEmaPeriod + 10
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            // lastIndex is the currently forming 5-minute bar.
            // The previous bar is the last fully confirmed/closed bar.
            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            // =================================================
            // CLOSED BAR VALUES FOR SIGNAL DECISIONS
            //
            // IMPORTANT:
            // EMA, price, VWAP, trend, liquidity and structure
            // are all evaluated from the SAME confirmed 5m bar.
            // =================================================
            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            double emaSlowCurrent =
                CalculateEma(
                    bars,
                    SlowEmaPeriod,
                    closedBarIndex
                );

            double lastPrice =
                bars.GetClose(
                    closedBarIndex
                );

            DateTime closedBarTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime decisionNyTime =
                ConvertToNewYorkTime(
                    closedBarTime
                );

            EnsureTradingDay(
                decisionNyTime.Date
            );

            double currentVwap =
                CalculateSessionVwap(
                    bars,
                    closedBarIndex
                );

            bool bullishTrend =
                emaFastCurrent >
                emaSlowCurrent;

            bool bearishTrend =
                emaFastCurrent <
                emaSlowCurrent;

            bool aboveVwap =
                currentVwap > 0 &&
                lastPrice > currentVwap;

            bool belowVwap =
                currentVwap > 0 &&
                lastPrice < currentVwap;

            bool nySessionActive =
                IsBotNySessionActive(
                    decisionNyTime
                );

            // Unrealized PnL must continue using the live/forming bar.
            double livePrice =
                bars.GetClose(
                    lastIndex
                );

            UpdateUnrealizedPnL(
                livePrice
            );

            CheckForceFlatTime();
            CheckDailyLossEmergency();

            string trend =
                bullishTrend
                    ? "BULLISH"
                    : bearishTrend
                        ? "BEARISH"
                        : "NEUTRAL";

            Brush trendBrush =
                bullishTrend
                    ? Brushes.LimeGreen
                    : bearishTrend
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // CLOSED-BAR STRUCTURE ANALYSIS
            // =================================================
            string liquidityState;
            string structureState;

            bool bullishStructureConfirmed;
            bool bearishStructureConfirmed;

            string bullishStructureSetupKey;
            string bearishStructureSetupKey;

            DetectLiquidityAndStructure(
                bars,
                closedBarIndex,
                out liquidityState,
                out structureState,
                out bullishStructureConfirmed,
                out bearishStructureConfirmed,
                out bullishStructureSetupKey,
                out bearishStructureSetupKey
            );

            Brush liquidityBrush =
                liquidityState == "LOW SWEPT"
                    ? Brushes.LimeGreen
                    : liquidityState == "HIGH SWEPT"
                        ? Brushes.OrangeRed
                        : liquidityState == "BOTH SWEPT"
                            ? Brushes.MediumPurple
                            : Brushes.Gray;

            Brush structureBrush =
                bullishStructureConfirmed
                    ? Brushes.LimeGreen
                    : bearishStructureConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // MOMENTUM ENGINE V2
            // Momentum is calculated by the INTERNAL Range-20
            // series. M5 supplies context only.
            // =================================================
            int longMomentumScore;
            int shortMomentumScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaFastSlope;
            bool highBreakout;
            bool lowBreakout;
            string momentumState;

            lock (marketContextLock)
            {
                longMomentumScore =
                    latestRangeLongScore;

                shortMomentumScore =
                    latestRangeShortScore;

                rangeRatio =
                    latestRangeRatio;

                volumeRatio =
                    latestRangeVolumeRatio;

                bodyRatio =
                    latestRangeBodyRatio;

                emaFastSlope =
                    latestRangeEmaSlope;

                highBreakout =
                    latestRangeHighBreakout;

                lowBreakout =
                    latestRangeLowBreakout;

                momentumState =
                    latestRangeMomentumState;
            }

            bool bullishMomentumConfirmed =
                longMomentumScore >= MomentumMinScore;

            bool bearishMomentumConfirmed =
                shortMomentumScore >= MomentumMinScore;

            Brush momentumBrush =
                bullishMomentumConfirmed
                    ? Brushes.LimeGreen
                    : bearishMomentumConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // Publish the latest confirmed M5 context so Range
            // momentum can use it as its directional filter.
            lock (marketContextLock)
            {
                latestM5ContextReady = true;
                latestM5BullishTrend = bullishTrend;
                latestM5BearishTrend = bearishTrend;
                latestM5AboveVwap = aboveVwap;
                latestM5BelowVwap = belowVwap;
                latestM5BullishStructure =
                    bullishStructureConfirmed;
                latestM5BearishStructure =
                    bearishStructureConfirmed;
                latestM5LiquidityState =
                    liquidityState;
                latestM5StructureState =
                    structureState;
                latestM5DecisionNyTime =
                    decisionNyTime;
                latestM5Vwap =
                    currentVwap;
            }

            // =================================================
            // DIRECTION FILTER
            // =================================================
            string direction =
                activeDirection;

            bool allowLong =
                direction == "BOTH" ||
                direction == "LONG ONLY";

            bool allowShort =
                direction == "BOTH" ||
                direction == "SHORT ONLY";

            // =================================================
            // FINAL CONDITIONS
            // =================================================
            bool structureLongReady =
                nySessionActive &&
                allowLong &&
                bullishTrend &&
                aboveVwap &&
                bullishStructureConfirmed;

            bool structureShortReady =
                nySessionActive &&
                allowShort &&
                bearishTrend &&
                belowVwap &&
                bearishStructureConfirmed;

            // Structure entries are evaluated on confirmed M5 bars.
            // Momentum entries are evaluated separately by Range-20.
            // Do not duplicate Range momentum state inside the M5 engine.

            bool rawLongReady =
                activeStrategyMode != "MOMENTUM SCALP" &&
                structureLongReady;

            bool rawShortReady =
                activeStrategyMode != "MOMENTUM SCALP" &&
                structureShortReady;

            string longLearningLookupContext =
                structureState;

            string shortLearningLookupContext =
                structureState;

            string learningLongReason;
            string learningShortReason;

            bool learningLongAllowed =
                IsLearningTradeAllowed(
                    "LONG",
                    decisionNyTime,
                    longLearningLookupContext,
                    out learningLongReason
                );

            bool learningShortAllowed =
                IsLearningTradeAllowed(
                    "SHORT",
                    decisionNyTime,
                    shortLearningLookupContext,
                    out learningShortReason
                );

            bool longReady =
                rawLongReady &&
                learningLongAllowed;

            bool shortReady =
                rawShortReady &&
                learningShortAllowed;

            double totalBotPnL =
                botDailyPnL +
                botUnrealizedPnL;

            string currentSessionWindow =
                GetBotSessionWindow(
                    decisionNyTime
                );

            bool sessionTradeLocked =
                IsSessionTradeLimitReached(
                    currentSessionWindow
                );

            bool dailyRiskLocked =
                persistentDailyLocked ||
                totalBotPnL >= activeDailyTarget ||
                totalBotPnL <= -activeDailyLoss;

            if (
                !persistentDailyLocked &&
                (
                    totalBotPnL >= activeDailyTarget ||
                    totalBotPnL <= -activeDailyLoss
                )
            )
            {
                persistentDailyLocked =
                    true;

                SavePersistentDailyState();
            }

            if (
                dailyRiskLocked ||
                sessionTradeLocked
            )
            {
                longReady = false;
                shortReady = false;
            }

            string confirmation =
                longReady || shortReady
                    ? "READY"
                    : "WAITING";

            Brush confirmationBrush =
                longReady
                    ? Brushes.LimeGreen
                    : shortReady
                        ? Brushes.OrangeRed
                        : Brushes.Gray;

            string setup;
            Brush setupBrush;

            string signal;
            Brush signalBrush;

            if (dailyRiskLocked)
            {
                setup =
                    "DAILY RISK LOCK";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "DAILY RISK LOCK";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (sessionTradeLocked)
            {
                setup =
                    currentSessionWindow
                    + " TRADE LIMIT";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    currentSessionWindow
                    + " LOCKED "
                    + GetSessionTradeCount(
                        currentSessionWindow
                    )
                    + "/"
                    + activeMaxTrades;

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (!nySessionActive)
            {
                setup =
                    "OUTSIDE NY SESSION";

                setupBrush =
                    Brushes.Gray;

                signal =
                    "OUTSIDE NY SESSION";

                signalBrush =
                    Brushes.Gray;
            }
            else if (
                rawLongReady &&
                !learningLongAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "LONG EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                rawShortReady &&
                !learningShortAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "SHORT EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (longReady)
            {
                setup =
                    "LONG READY";

                setupBrush =
                    Brushes.LimeGreen;

                signal =
                    "LONG SIGNAL";

                signalBrush =
                    Brushes.LimeGreen;
            }
            else if (shortReady)
            {
                setup =
                    "SHORT READY";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "SHORT SIGNAL";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (
                liquidityState != "NONE" &&
                !bullishStructureConfirmed &&
                !bearishStructureConfirmed
            )
            {
                setup =
                    "WAIT BOS/CHOCH";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "WAITING STRUCTURE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                bullishStructureConfirmed ||
                bearishStructureConfirmed
            )
            {
                setup =
                    "FILTERED";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "FILTERS NOT ALIGNED";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else
            {
                setup =
                    "WAIT LIQUIDITY";

                setupBrush =
                    Brushes.Gray;

                signal =
                    bullishTrend
                        ? "BULLISH"
                        : bearishTrend
                            ? "BEARISH"
                            : "WAITING";

                signalBrush =
                    bullishTrend
                        ? Brushes.LimeGreen
                        : bearishTrend
                            ? Brushes.OrangeRed
                            : Brushes.Gray;
            }

            // =================================================
            // OUTPUT ONLY WHEN A NEW 5M BAR IS CONFIRMED
            // =================================================
            if (checkClosedBarCross)
            {
                string vwapSide =
                    currentVwap <= 0
                        ? "VWAP N/A"
                        : aboveVwap
                            ? "ABOVE VWAP"
                            : belowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                // Diagnostic score.
                // The score is informational only and does NOT change
                // the actual entry conditions above.
                int buyScore = 0;
                int sellScore = 0;

                List<string> buyMissing =
                    new List<string>();

                List<string> sellMissing =
                    new List<string>();

                if (bullishTrend)
                    buyScore++;
                else
                    buyMissing.Add("Trend");

                if (aboveVwap)
                    buyScore++;
                else
                    buyMissing.Add("VWAP");

                if (
                    liquidityState == "LOW SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    buyScore++;
                else
                    buyMissing.Add("Low Sweep");

                if (bullishStructureConfirmed)
                    buyScore++;
                else
                    buyMissing.Add("Bullish Structure");

                if (bearishTrend)
                    sellScore++;
                else
                    sellMissing.Add("Trend");

                if (belowVwap)
                    sellScore++;
                else
                    sellMissing.Add("VWAP");

                if (
                    liquidityState == "HIGH SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    sellScore++;
                else
                    sellMissing.Add("High Sweep");

                if (bearishStructureConfirmed)
                    sellScore++;
                else
                    sellMissing.Add("Bearish Structure");

                PrintBotMessage(
                    "DECISION"
                    + " | "
                    + decisionNyTime.ToString("HH:mm")
                    + " ET"
                    + " | Trend: "
                    + trend
                    + " | "
                    + vwapSide
                    + " | Sweep: "
                    + liquidityState
                    + " | Structure: "
                    + structureState
                    + " | Session: "
                    + (
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED"
                    )
                    + " | Strategy: "
                    + activeStrategyMode
                    + " | Momentum: "
                    + momentumState
                    + " | Setup: "
                    + setup
                );

                PrintBotMessage(
                    "RANGE MOMENTUM "
                    + MomentumRangeTicks
                    + "T"
                    + " | LONG: "
                    + longMomentumScore
                    + "/5"
                    + " | SHORT: "
                    + shortMomentumScore
                    + "/5"
                    + " | Range x"
                    + rangeRatio.ToString("0.00")
                    + " | Volume x"
                    + volumeRatio.ToString("0.00")
                    + " | Body "
                    + (bodyRatio * 100.0).ToString("0")
                    + "%"
                    + " | EMA9 Slope: "
                    + emaFastSlope.ToString("0.00")
                    + " | Breakout: "
                    + (
                        highBreakout
                            ? "HIGH"
                            : lowBreakout
                                ? "LOW"
                                : "NONE"
                    )
                );

                LogLearningDecision(
                    decisionNyTime,
                    trend,
                    vwapSide,
                    liquidityState,
                    structureState,
                    setup,
                    buyScore,
                    sellScore
                );

                if (
                    rawLongReady &&
                    !learningLongAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK LONG | "
                        + learningLongReason
                    );
                }

                if (
                    rawShortReady &&
                    !learningShortAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK SHORT | "
                        + learningShortReason
                    );
                }

                PrintBotMessage(
                    "BUY SCORE: "
                    + buyScore
                    + "/4"
                    + (
                        buyMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    buyMissing
                                )
                            : " | READY"
                    )
                );

                PrintBotMessage(
                    "SELL SCORE: "
                    + sellScore
                    + "/4"
                    + (
                        sellMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    sellMissing
                                )
                            : " | READY"
                    )
                );

                if (longReady)
                {
                    PrintBotMessage(
                        "LONG SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string longLearningContext =
                        structureState;

                    CaptureLearningSignalContext(
                        "LONG",
                        decisionNyTime,
                        longLearningContext
                    );

                    TrySubmitEntry(
                        true,
                        closedBarTime,
                        false,
                        bullishStructureSetupKey
                    );
                }
                else if (shortReady)
                {
                    PrintBotMessage(
                        "SHORT SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string shortLearningContext =
                        structureState;

                    CaptureLearningSignalContext(
                        "SHORT",
                        decisionNyTime,
                        shortLearningContext
                    );

                    TrySubmitEntry(
                        false,
                        closedBarTime,
                        false,
                        bearishStructureSetupKey
                    );
                }
            }

            currentSignalState =
                signal;

            currentSetupState =
                setup;

            PublishSharedState();

            // =================================================
            // UPDATE UI
            // =================================================
            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    lastPriceText.Text =
                        FormatPrice(
                            lastPrice
                        );

                    emaFastText.Text =
                        FormatPrice(
                            emaFastCurrent
                        );

                    emaSlowText.Text =
                        FormatPrice(
                            emaSlowCurrent
                        );

                    vwapText.Text =
                        currentVwap > 0
                            ? FormatPrice(
                                currentVwap
                            )
                            : "--";

                    trendText.Text =
                        trend;

                    trendText.Foreground =
                        trendBrush;

                    nySessionText.Text =
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED";

                    nySessionText.Foreground =
                        nySessionActive
                            ? Brushes.LimeGreen
                            : Brushes.Gray;

                    liquidityText.Text =
                        liquidityState;

                    liquidityText.Foreground =
                        liquidityBrush;

                    structureText.Text =
                        structureState;

                    structureText.Foreground =
                        structureBrush;

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        momentumBrush;

                    confirmationText.Text =
                        confirmation;

                    confirmationText.Foreground =
                        confirmationBrush;

                    setupText.Text =
                        setup;

                    setupText.Foreground =
                        setupBrush;

                    barTimeText.Text =
                        decisionNyTime.ToString(
                            "MM/dd HH:mm"
                        )
                        + " ET";

                    signalText.Text =
                        signal;

                    signalText.Foreground =
                        signalBrush;

                    pnlText.Text =
                        botDailyPnL.ToString(
                            "$0.00"
                        );

                    tradesText.Text =
                        "AM "
                        + amTradesToday
                        + "/"
                        + activeMaxTrades
                        + " | PM "
                        + pmTradesToday
                        + "/"
                        + activeMaxTrades;
                })
            );
        }

        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        // =====================================================
        // PERSISTENT DAILY STATE
        // =====================================================
        private void TryRestorePersistentStateForSelection()
        {
            if (
                botRunning ||
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            LoadOrResetPersistentDailyState();
        }

        private void LoadOrResetPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                ConvertToNewYorkTime(
                    DateTime.Now
                );

            DateTime todayNy =
                nowNy.Date;

            activeTradingDate =
                todayNy;

            JJBotDailyStateData state =
                LoadPersistentDailyState();

            bool stateMatchesToday =
                state != null &&
                state.NewYorkDate ==
                    todayNy.ToString(
                        "yyyy-MM-dd"
                    ) &&
                string.Equals(
                    state.AccountName,
                    selectedAccount.Name,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                string.Equals(
                    state.InstrumentName,
                    selectedInstrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                );

            if (stateMatchesToday)
            {
                tradesToday =
                    Math.Max(
                        0,
                        state.TradesToday
                    );

                amTradesToday =
                    Math.Max(
                        0,
                        state.AmTrades
                    );

                pmTradesToday =
                    Math.Max(
                        0,
                        state.PmTrades
                    );

                botDailyPnL =
                    state.RealizedPnL;

                botUnrealizedPnL =
                    0;

                persistentDailyLocked =
                    state.DailyLocked;

                lastExecutedSignalBar =
                    state.LastExecutedSignalBar;

                consumedBullishStructureSetupKey =
                    state.ConsumedBullishStructureKey
                    ?? string.Empty;

                consumedBearishStructureSetupKey =
                    state.ConsumedBearishStructureKey
                    ?? string.Empty;

                consumedBullishStructureConfirmTime =
                    state.ConsumedBullishStructureConfirmTime;

                consumedBearishStructureConfirmTime =
                    state.ConsumedBearishStructureConfirmTime;

                // Backward-compatible recovery if an older state file
                // contains a consumed key but not the explicit timestamp.
                if (
                    consumedBullishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBullishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBullishStructureSetupKey
                        );
                }

                if (
                    consumedBearishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBearishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBearishStructureSetupKey
                        );
                }

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "DAILY STATE RESTORED"
                    + " | Date: "
                    + state.NewYorkDate
                    + " | Trades: "
                    + tradesToday
                    + " | AM: "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | PM: "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Locked: "
                    + persistentDailyLocked
                );
            }
            else
            {
                tradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
                botDailyPnL = 0;
                botUnrealizedPnL = 0;

                persistentDailyLocked =
                    false;

                lastExecutedSignalBar =
                    DateTime.MinValue;

                consumedBullishStructureSetupKey =
                    string.Empty;

                consumedBearishStructureSetupKey =
                    string.Empty;

                consumedBullishStructureConfirmTime =
                    DateTime.MinValue;

                consumedBearishStructureConfirmTime =
                    DateTime.MinValue;

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                SavePersistentDailyState();

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "NEW DAILY STATE CREATED"
                    + " | Date: "
                    + todayNy.ToString(
                        "yyyy-MM-dd"
                    )
                );
            }

            UpdatePnlDisplay();

            Action updateStateUi =
                new Action(() =>
                {
                    if (tradesText != null)
                    {
                        tradesText.Text =
                            "AM "
                            + amTradesToday
                            + "/"
                            + activeMaxTrades
                            + " | PM "
                            + pmTradesToday
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        persistentDailyLocked &&
                        signalText != null
                    )
                    {
                        signalText.Text =
                            "DAILY RISK LOCK";

                        signalText.Foreground =
                            Brushes.OrangeRed;
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                updateStateUi();
            }
            else
            {
                Dispatcher.InvokeAsync(
                    updateStateUi
                );
            }
        }

        private JJBotDailyStateData
            LoadPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return null;
            }

            string accountName =
                selectedAccount.Name;

            string instrumentName =
                selectedInstrument.FullName;

            string filePath =
                GetPersistentStateFilePath(
                    accountName,
                    instrumentName
                );

            string backupPath =
                filePath + ".bak";

            object persistenceLock =
                JJBotRuntimeCoordinator.GetPersistenceLock(
                    accountName,
                    instrumentName
                );

            lock (persistenceLock)
            {
                if (
                    string.IsNullOrWhiteSpace(
                        filePath
                    )
                )
                {
                    return null;
                }

                // Primary file first.
                if (File.Exists(filePath))
                {
                    try
                    {
                        return DeserializeDailyStateFile(
                            filePath
                        );
                    }
                    catch (Exception primaryEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD PRIMARY ERROR: "
                            + primaryEx.Message
                            + " | TRYING BACKUP."
                        );
                    }
                }

                // Automatic recovery from last known-good backup.
                if (File.Exists(backupPath))
                {
                    try
                    {
                        JJBotDailyStateData recovered =
                            DeserializeDailyStateFile(
                                backupPath
                            );

                        PrintBotMessage(
                            "STATE RECOVERED FROM BACKUP: "
                            + backupPath
                        );

                        return recovered;
                    }
                    catch (Exception backupEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD BACKUP ERROR: "
                            + backupEx.Message
                        );
                    }
                }

                return null;
            }
        }

        private JJBotDailyStateData
            DeserializeDailyStateFile(
                string filePath)
        {
            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(
                        JJBotDailyStateData
                    )
                );

            using (
                FileStream stream =
                    new FileStream(
                        filePath,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read
                    )
            )
            {
                return serializer.Deserialize(
                    stream
                ) as JJBotDailyStateData;
            }
        }

        private void SavePersistentDailyState()
        {
            string tempPath =
                string.Empty;

            try
            {
                if (
                    selectedAccount == null ||
                    selectedInstrument == null
                )
                {
                    return;
                }

                string accountName =
                    selectedAccount.Name;

                string instrumentName =
                    selectedInstrument.FullName;

                DateTime stateDate;
                int localTradesToday;
                int localAmTradesToday;
                int localPmTradesToday;
                double localBotDailyPnL;
                bool localDailyLocked;
                DateTime localLastExecutedSignalBar;
                string localConsumedBullishStructureKey;
                string localConsumedBearishStructureKey;
                DateTime localConsumedBullishStructureConfirmTime;
                DateTime localConsumedBearishStructureConfirmTime;

                // Capture one internally consistent state snapshot.
                lock (executionStateLock)
                {
                    stateDate =
                        activeTradingDate !=
                            DateTime.MinValue
                            ? activeTradingDate
                            : ConvertToNewYorkTime(
                                DateTime.Now
                            ).Date;

                    localTradesToday =
                        tradesToday;

                    localAmTradesToday =
                        amTradesToday;

                    localPmTradesToday =
                        pmTradesToday;

                    localBotDailyPnL =
                        botDailyPnL;

                    localDailyLocked =
                        persistentDailyLocked;

                    localLastExecutedSignalBar =
                        lastExecutedSignalBar;

                    localConsumedBullishStructureKey =
                        consumedBullishStructureSetupKey;

                    localConsumedBearishStructureKey =
                        consumedBearishStructureSetupKey;

                    localConsumedBullishStructureConfirmTime =
                        consumedBullishStructureConfirmTime;

                    localConsumedBearishStructureConfirmTime =
                        consumedBearishStructureConfirmTime;
                }

                JJBotDailyStateData state =
                    new JJBotDailyStateData();

                state.NewYorkDate =
                    stateDate.ToString(
                        "yyyy-MM-dd"
                    );

                state.AccountName =
                    accountName;

                state.InstrumentName =
                    instrumentName;

                state.TradesToday =
                    localTradesToday;

                state.AmTrades =
                    localAmTradesToday;

                state.PmTrades =
                    localPmTradesToday;

                state.RealizedPnL =
                    localBotDailyPnL;

                state.DailyLocked =
                    localDailyLocked;

                state.LastExecutedSignalBar =
                    localLastExecutedSignalBar;

                state.ConsumedBullishStructureKey =
                    localConsumedBullishStructureKey
                    ?? string.Empty;

                state.ConsumedBearishStructureKey =
                    localConsumedBearishStructureKey
                    ?? string.Empty;

                state.ConsumedBullishStructureConfirmTime =
                    localConsumedBullishStructureConfirmTime;

                state.ConsumedBearishStructureConfirmTime =
                    localConsumedBearishStructureConfirmTime;

                Directory.CreateDirectory(
                    stateFolderPath
                );

                string filePath =
                    GetPersistentStateFilePath(
                        accountName,
                        instrumentName
                    );

                string backupPath =
                    filePath + ".bak";

                tempPath =
                    filePath
                    + ".tmp."
                    + Guid.NewGuid()
                        .ToString("N");

                object persistenceLock =
                    JJBotRuntimeCoordinator.GetPersistenceLock(
                        accountName,
                        instrumentName
                    );

                lock (persistenceLock)
                {
                    XmlSerializer serializer =
                        new XmlSerializer(
                            typeof(
                                JJBotDailyStateData
                            )
                        );

                    // Never serialize directly into the live XML.
                    using (
                        FileStream stream =
                            new FileStream(
                                tempPath,
                                FileMode.CreateNew,
                                FileAccess.Write,
                                FileShare.None
                            )
                    )
                    {
                        serializer.Serialize(
                            stream,
                            state
                        );

                        stream.Flush(
                            true
                        );
                    }

                    if (File.Exists(filePath))
                    {
                        try
                        {
                            // Atomic replacement on NTFS.
                            // The previous good state becomes .bak.
                            File.Replace(
                                tempPath,
                                filePath,
                                backupPath,
                                true
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (
                            PlatformNotSupportedException
                        )
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (IOException)
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                    }
                    else
                    {
                        File.Move(
                            tempPath,
                            filePath
                        );

                        tempPath =
                            string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "STATE SAVE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                if (
                    !string.IsNullOrWhiteSpace(
                        tempPath
                    ) &&
                    File.Exists(
                        tempPath
                    )
                )
                {
                    try
                    {
                        File.Delete(
                            tempPath
                        );
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void ReplaceStateFileFallback(
            string tempPath,
            string filePath,
            string backupPath)
        {
            // The per-key persistence lock is already held here.
            // This fallback is used only if File.Replace is unavailable.
            if (File.Exists(filePath))
            {
                File.Copy(
                    filePath,
                    backupPath,
                    true
                );
            }

            File.Copy(
                tempPath,
                filePath,
                true
            );

            File.Delete(
                tempPath
            );
        }

        private string GetPersistentStateFilePath()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return string.Empty;
            }

            return GetPersistentStateFilePath(
                selectedAccount.Name,
                selectedInstrument.FullName
            );
        }

        private string GetPersistentStateFilePath(
            string accountName,
            string instrumentName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                return string.Empty;
            }

            string safeAccount =
                MakeSafeFileName(
                    accountName
                );

            string safeInstrument =
                MakeSafeFileName(
                    instrumentName
                );

            return Path.Combine(
                stateFolderPath,
                "daily_"
                + safeAccount
                + "_"
                + safeInstrument
                + ".xml"
            );
        }

        private string MakeSafeFileName(
            string value)
        {
            if (
                string.IsNullOrWhiteSpace(
                    value
                )
            )
            {
                return "unknown";
            }

            char[] invalidChars =
                Path.GetInvalidFileNameChars();

            foreach (
                char invalidChar
                in invalidChars
            )
            {
                value =
                    value.Replace(
                        invalidChar,
                        '_'
                    );
            }

            value =
                value.Replace(
                    ' ',
                    '_'
                );

            return value;
        }

        private bool IsSimulationAccount(
            Account account)
        {
            if (
                account == null ||
                string.IsNullOrWhiteSpace(
                    account.Name
                )
            )
            {
                return false;
            }

            string accountName =
                account.Name.Trim();

            // Conservative SIM-only gate:
            // only NinjaTrader-style simulation accounts whose
            // names BEGIN with "Sim" are accepted.
            //
            // This intentionally rejects funded/evaluation/live
            // accounts unless this safety policy is changed later.
            return accountName.StartsWith(
                "Sim",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private void SubscribeExecutionAccount(
            Account account)
        {
            UnsubscribeExecutionAccount();

            if (
                account == null ||
                !IsSimulationAccount(account)
            )
            {
                return;
            }

            subscribedAccount =
                account;

            subscribedAccount.ExecutionUpdate +=
                OnAccountExecutionUpdate;

            subscribedAccount.OrderUpdate +=
                OnAccountOrderUpdate;
        }

        private void UnsubscribeExecutionAccount()
        {
            if (
                subscribedAccount != null
            )
            {
                subscribedAccount.ExecutionUpdate -=
                    OnAccountExecutionUpdate;

                subscribedAccount.OrderUpdate -=
                    OnAccountOrderUpdate;

                subscribedAccount =
                    null;
            }
        }

        private void EnsureTradingDay(
            DateTime nyDate)
        {
            // Prevent older/historical callbacks from moving the
            // active NY trading day backwards and resetting counters.
            if (
                activeTradingDate !=
                    DateTime.MinValue &&
                nyDate <=
                    activeTradingDate
            )
            {
                return;
            }

            activeTradingDate =
                nyDate;

            tradesToday = 0;
            amTradesToday = 0;
            pmTradesToday = 0;
            pendingEntrySession = "OUTSIDE";
            botDailyPnL = 0;
            botUnrealizedPnL = 0;

            persistentDailyLocked =
                false;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;

            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;

            forceFlatSentToday = false;
            forceFlatDateNy = nyDate;

            lastExecutedSignalBar =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            SavePersistentDailyState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (pnlText != null)
                        pnlText.Text = "$0.00";

                    if (unrealizedPnlText != null)
                        unrealizedPnlText.Text = "$0.00";

                    if (totalPnlText != null)
                        totalPnlText.Text = "$0.00";

                    if (tradesText != null)
                        tradesText.Text =
                            "AM 0/"
                            + activeMaxTrades
                            + " | PM 0/"
                            + activeMaxTrades;
                })
            );

            PrintBotMessage(
                "NEW NY TRADING DAY: "
                + nyDate.ToString(
                    "yyyy-MM-dd"
                )
            );
        }

        private bool IsSelectedInstrumentFlat()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return false;
            }

            lock (
                selectedAccount.Positions
            )
            {
                foreach (
                    Position position
                    in selectedAccount.Positions
                )
                {
                    if (
                        position == null ||
                        position.Instrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        position.Instrument.FullName ==
                            selectedInstrument.FullName
                    )
                    {
                        return
                            position.MarketPosition ==
                            MarketPosition.Flat;
                    }
                }
            }

            // No position object for this instrument means flat.
            return true;
        }

       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null)
        {
            if (!botRunning)
                return;

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            if (
                !IsSimulationAccount(
                    account
                )
            )
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - ACCOUNT IS NOT SIM."
                );

                return;
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // Automatic entries MUST obey NY session.
            // Manual SIM tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + signalBarTime.ToString("yyyyMMddHHmmss");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + activeMaxTrades
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT."
                    );
                }

                return;
            }

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? "JJ_ENTRY_LONG"
                        : "JJ_ENTRY_SHORT";

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        activeContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    pendingEntrySession =
                        signalSession;

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    lastExecutedSignalBar =
                        signalBarTime;
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + activeContracts
                    + " | "
                    + instrument.FullName
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // ACCOUNT ORDER UPDATE
        //
        // Keeps the monitor synchronized with the REAL working
        // stop/target orders. If the user drags SL or TP on the
        // chart, NinjaTrader raises OrderUpdate and the monitor
        // refreshes immediately.
        // =====================================================
        private void OnAccountOrderUpdate(
            object sender,
            OrderEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Order == null ||
                e.Order.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Order.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Order.Name;

            if (
                orderName == "JJ_ENTRY_LONG" ||
                orderName == "JJ_ENTRY_SHORT"
            )
            {
                bool entryRejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool entryCancelled =
                    e.Order.OrderState ==
                        OrderState.Cancelled;

                bool entryFilled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (
                    entryRejected ||
                    entryCancelled ||
                    entryFilled
                )
                {
                    lock (executionStateLock)
                    {
                        entryPending =
                            false;

                        entryOrder =
                            e.Order;

                        if (
                            entryRejected &&
                            entryQuantity <= 0
                        )
                        {
                            executionStatus =
                                "ENTRY ERROR";

                            // No real fill occurred, so the pending
                            // structure remains unconsumed.
                            pendingStructureSetupKey =
                                string.Empty;

                            pendingStructureConfirmTime =
                                DateTime.MinValue;
                        }
                        else if (
                            entryCancelled &&
                            entryQuantity > 0
                        )
                        {
                            executionStatus =
                                "ENTRY PARTIAL";
                        }
                        else if (entryFilled)
                        {
                            executionStatus =
                                stopOrder != null &&
                                targetOrder != null
                                    ? "PROTECTED"
                                    : "ENTRY FILLED";
                        }
                    }

                    UpdateExecutionMonitor();
                }

                return;
            }

            if (
                orderName != "JJ_STOP" &&
                orderName != "JJ_TARGET"
            )
            {
                return;
            }

            try
            {
                bool rejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToChangeOrder ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool shouldFlatten =
                    false;

                double stopForLog;
                double targetForLog;

                lock (executionStateLock)
                {
                    if (
                        orderName == "JJ_STOP"
                    )
                    {
                        stopOrder =
                            e.Order;

                        if (
                            e.Order.StopPrice > 0
                        )
                        {
                            activeStopPrice =
                                e.Order.StopPrice;
                        }
                    }
                    else if (
                        orderName == "JJ_TARGET"
                    )
                    {
                        targetOrder =
                            e.Order;

                        if (
                            e.Order.LimitPrice > 0
                        )
                        {
                            activeTargetPrice =
                                e.Order.LimitPrice;
                        }
                    }

                    if (rejected)
                    {
                        executionStatus =
                            "PROTECTION ERROR";

                        shouldFlatten =
                            entryMarketPosition !=
                                MarketPosition.Flat;
                    }
                    else
                    {
                        bool stopWorking =
                            stopOrder != null &&
                            (
                                stopOrder.OrderState ==
                                    OrderState.Working ||
                                stopOrder.OrderState ==
                                    OrderState.Accepted ||
                                stopOrder.OrderState ==
                                    OrderState.ChangePending ||
                                stopOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        bool targetWorking =
                            targetOrder != null &&
                            (
                                targetOrder.OrderState ==
                                    OrderState.Working ||
                                targetOrder.OrderState ==
                                    OrderState.Accepted ||
                                targetOrder.OrderState ==
                                    OrderState.ChangePending ||
                                targetOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        if (
                            stopWorking &&
                            targetWorking &&
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "PROTECTED";
                        }
                        else if (
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "UPDATING OCO";
                        }
                    }

                    stopForLog =
                        activeStopPrice;

                    targetForLog =
                        activeTargetPrice;
                }

                UpdateExecutionMonitor();

                bool bracketBuildInProgress;

                lock (executionStateLock)
                {
                    bracketBuildInProgress =
                        protectiveBracketBuildInProgress;
                }

                if (
                    !rejected &&
                    !bracketBuildInProgress
                )
                {
                    double localEntryAverage;
                    int localEntryQty;
                    MarketPosition localEntrySide;

                    lock (executionStateLock)
                    {
                        localEntryAverage =
                            entryFillPrice;

                        localEntryQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                activeExitQuantity
                            );

                        localEntrySide =
                            entryMarketPosition;
                    }

                    if (
                        localEntryQty > 0 &&
                        localEntryAverage > 0 &&
                        localEntrySide !=
                            MarketPosition.Flat
                    )
                    {
                        SyncProtectiveBracketToEntry(
                            localEntryAverage,
                            localEntryQty,
                            localEntrySide
                        );
                    }
                }

                if (rejected)
                {
                    PrintBotMessage(
                        "ORDER ERROR"
                        + " | "
                        + orderName
                        + " | State: "
                        + e.Order.OrderState
                        + " | Error: "
                        + e.Error
                        + " | Comment: "
                        + e.Comment
                    );

                    Account account =
                        selectedAccount;

                    Instrument instrument =
                        selectedInstrument;

                    if (
                        shouldFlatten &&
                        account != null &&
                        instrument != null &&
                        IsSimulationAccount(
                            account
                        )
                    )
                    {
                        try
                        {
                            // Never call Flatten while holding executionStateLock.
                            account.Flatten(
                                new[]
                                {
                                    instrument
                                }
                            );

                            lock (executionStateLock)
                            {
                                executionStatus =
                                    "FLATTENING";
                            }

                            UpdateExecutionMonitor();
                        }
                        catch (
                            Exception flattenEx
                        )
                        {
                            PrintBotMessage(
                                "ORDER ERROR FLATTEN FAILED: "
                                + flattenEx.Message
                            );
                        }
                    }

                    return;
                }

                PrintBotMessage(
                    "ORDER UPDATE"
                    + " | "
                    + orderName
                    + " | State: "
                    + e.Order.OrderState
                    + " | Stop: "
                    + stopForLog.ToString("0.00")
                    + " | Target: "
                    + targetForLog.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "ORDER UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        private void OnAccountExecutionUpdate(
            object sender,
            ExecutionEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Execution == null ||
                e.Execution.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Execution.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Execution.Order != null
                    ? e.Execution.Order.Name
                    : e.Execution.Name;

            Account executionAccount =
                sender as Account;

            if (executionAccount == null)
            {
                executionAccount =
                    selectedAccount;
            }

            Instrument executionInstrument =
                e.Execution.Instrument;

            // ---------------------------------------------
            // ENTRY FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            if (
                orderName == "JJ_ENTRY_LONG" ||
                orderName == "JJ_ENTRY_SHORT"
            )
            {
                MarketPosition filledSide =
                    orderName == "JJ_ENTRY_LONG"
                        ? MarketPosition.Long
                        : MarketPosition.Short;

                bool firstFill;
                int cumulativeEntryQty;
                double averageEntryPrice;
                int localTradesToday;
                int localAmTrades;
                int localPmTrades;

                lock (executionStateLock)
                {
                    firstFill =
                        entryQuantity <= 0 ||
                        entryMarketPosition ==
                            MarketPosition.Flat;

                    int previousQty =
                        Math.Max(
                            0,
                            entryQuantity
                        );

                    double previousAverage =
                        entryFillPrice;

                    cumulativeEntryQty =
                        previousQty +
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (cumulativeEntryQty <= 0)
                    {
                        return;
                    }

                    averageEntryPrice =
                        previousQty > 0 &&
                        previousAverage > 0
                            ? (
                                (
                                    previousAverage
                                    * previousQty
                                )
                                +
                                (
                                    e.Price
                                    * e.Quantity
                                )
                            )
                            / cumulativeEntryQty
                            : e.Price;

                    entryFillPrice =
                        averageEntryPrice;

                    entryQuantity =
                        cumulativeEntryQty;

                    activeEntryCommission +=
                        e.Execution.Commission;

                    botDailyPnL -=
                        e.Execution.Commission;

                    botUnrealizedPnL =
                        0;

                    entryMarketPosition =
                        filledSide;

                    if (
                        e.Execution.Order != null
                    )
                    {
                        entryOrder =
                            e.Execution.Order;

                        entryPending =
                            e.Execution.Order.OrderState ==
                                OrderState.PartFilled;
                    }
                    else
                    {
                        entryPending =
                            cumulativeEntryQty <
                                activeContracts;
                    }

                    if (firstFill)
                    {
                        // Consume the structure only once: on the first
                        // real execution of this entry lifecycle.
                        if (
                            !string.IsNullOrWhiteSpace(
                                pendingStructureSetupKey
                            )
                        )
                        {
                            if (
                                filledSide ==
                                    MarketPosition.Long
                            )
                            {
                                consumedBullishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBullishStructureConfirmTime
                                )
                                {
                                    consumedBullishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                            else
                            {
                                consumedBearishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBearishStructureConfirmTime
                                )
                                {
                                    consumedBearishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                        }

                        string learningSide =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSide
                            )
                                ? pendingLearningSide
                                : (
                                    filledSide ==
                                        MarketPosition.Long
                                        ? "LONG"
                                        : "SHORT"
                                );

                        string learningSession =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSession
                            )
                                ? pendingLearningSession
                                : "UNKNOWN";

                        string learningStructure =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningStructure
                            )
                                ? pendingLearningStructure
                                : "UNKNOWN";

                        JJBotLearningTrade newLearningTrade =
                            new JJBotLearningTrade();

                        newLearningTrade.Side =
                            learningSide;

                        newLearningTrade.SessionWindow =
                            learningSession;

                        newLearningTrade.Structure =
                            learningStructure;

                        newLearningTrade.SignalTimeNy =
                            pendingLearningSignalTimeNy;

                        newLearningTrade.EntryPrice =
                            averageEntryPrice;

                        newLearningTrade.Mfe =
                            0;

                        newLearningTrade.Mae =
                            0;

                        activeLearningTrade =
                            newLearningTrade;

                        pendingStructureSetupKey =
                            string.Empty;

                        pendingStructureConfirmTime =
                            DateTime.MinValue;

                        riskFlattenSent =
                            false;

                        riskFlattenStage =
                            0;

                        riskFlattenLastActionUtc =
                            DateTime.MinValue;

                        riskFlattenOrder =
                            null;

                        activeEntryUsesMomentumTrailing =
                            true;

                        momentumTrailingStage =
                            0;

                        lastMomentumTrailingStopPrice =
                            0;

                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        dailyTargetProtectionArmed =
                            false;

                        lastDailyTargetProtectionStopPrice =
                            0;

                        lastDailyTargetProtectionChangeUtc =
                            DateTime.MinValue;

                        activeExitQuantity =
                            0;

                        activeExitGrossPnL =
                            0;

                        activeExitCommission =
                            0;

                        executionStatus =
                            e.Execution.Order != null &&
                            e.Execution.Order.OrderState ==
                                OrderState.PartFilled
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";

                        // Exactly one trade count per lifecycle.
                        tradesToday++;

                        if (
                            string.Equals(
                                pendingEntrySession,
                                "AM",
                                StringComparison.OrdinalIgnoreCase
                            )
                        )
                        {
                            amTradesToday++;
                        }
                        else if (
                            string.Equals(
                                pendingEntrySession,
                                "PM",
                                StringComparison.OrdinalIgnoreCase
                            )
                        )
                        {
                            pmTradesToday++;
                        }
                    }
                    else
                    {
                        // Keep one learning trade and update only its
                        // weighted average entry.
                        if (
                            activeLearningTrade != null
                        )
                        {
                            activeLearningTrade.EntryPrice =
                                averageEntryPrice;
                        }

                        executionStatus =
                            entryPending
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";
                    }

                    localTradesToday =
                        tradesToday;

                    localAmTrades =
                        amTradesToday;

                    localPmTrades =
                        pmTradesToday;
                }

                if (firstFill)
                {
                    PrintBotMessage(
                        "TRADE PROTECTION ARMED"
                        + " | BE +"
                        + MomentumBreakEvenTriggerTicks
                        + "t"
                        + " | LOCK +"
                        + MomentumLockProfitTicks
                        + "t @ +"
                        + MomentumLockTriggerTicks
                        + "t"
                        + " | TRAIL "
                        + MomentumTrailDistanceTicks
                        + "t @ +"
                        + MomentumTrailTriggerTicks
                        + "t"
                    );

                    JJBotSharedState.PublishExecution(
                        executionAccount != null
                            ? executionAccount.Name
                            : string.Empty,
                        executionInstrument != null
                            ? executionInstrument.FullName
                            : string.Empty,
                        filledSide ==
                            MarketPosition.Long
                            ? "BUY"
                            : "SELL",
                        e.Price
                    );
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                PrintBotMessage(
                    (
                        entryPending
                            ? "ENTRY PARTIAL FILL"
                            : "ENTRY FILL COMPLETE"
                    )
                    + " | Fill Qty: "
                    + e.Quantity
                    + " | Total Qty: "
                    + cumulativeEntryQty
                    + "/"
                    + activeContracts
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                );

                if (firstFill)
                {
                    PrintBotMessage(
                        "SESSION TRADE COUNT"
                        + " | AM: "
                        + localAmTrades
                        + "/"
                        + activeMaxTrades
                        + " | PM: "
                        + localPmTrades
                        + "/"
                        + activeMaxTrades
                        + " | Day: "
                        + localTradesToday
                    );
                }

                SyncProtectiveBracketToEntry(
                    averageEntryPrice,
                    cumulativeEntryQty,
                    filledSide
                );

                UpdateExecutionUi();

                return;
            }

            MarketPosition currentSide;
            double currentEntryPrice;
            int currentEntryQty;
            double currentEntryCommission;

            lock (executionStateLock)
            {
                currentSide =
                    entryMarketPosition;

                currentEntryPrice =
                    entryFillPrice;

                currentEntryQty =
                    entryQuantity;

                currentEntryCommission =
                    activeEntryCommission;
            }

            // ---------------------------------------------
            // EXIT FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            if (
                currentSide !=
                    MarketPosition.Flat &&
                currentEntryPrice > 0 &&
                currentEntryQty > 0
            )
            {
                Order executionOrder =
                    e.Execution.Order;

                OrderAction executionAction =
                    executionOrder != null
                        ? executionOrder.OrderAction
                        : OrderAction.Buy;

                bool protectiveExit =
                    orderName == "JJ_STOP" ||
                    orderName == "JJ_TARGET";

                bool riskExit =
                    orderName == "JJ_RISK_FLATTEN";

                bool externalClosingAction =
                    (
                        currentSide ==
                            MarketPosition.Long &&
                        executionAction ==
                            OrderAction.Sell
                    ) ||
                    (
                        currentSide ==
                            MarketPosition.Short &&
                        executionAction ==
                            OrderAction.BuyToCover
                    );

                bool recognizedExit =
                    protectiveExit ||
                    riskExit ||
                    (
                        orderName != "JJ_ENTRY_LONG" &&
                        orderName != "JJ_ENTRY_SHORT" &&
                        externalClosingAction
                    );

                if (recognizedExit)
                {
                    double pointValue =
                        executionInstrument
                            .MasterInstrument
                            .PointValue;

                    int exitQty =
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (exitQty <= 0)
                    {
                        return;
                    }

                    double grossPnL =
                        currentSide ==
                            MarketPosition.Long
                            ? (
                                e.Price -
                                currentEntryPrice
                            )
                            * pointValue
                            * exitQty
                            : (
                                currentEntryPrice -
                                e.Price
                            )
                            * pointValue
                            * exitQty;

                    double exitCommission =
                        e.Execution.Commission;

                    bool accountFlatAfterExecution =
                        e.Execution.Position == 0 ||
                        IsSelectedInstrumentFlat();

                    bool lifecycleComplete;
                    int localExitQty;
                    int localRemainingQty;
                    double localBotPnL;
                    bool localDailyLocked;
                    double finalLearningNet;

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition !=
                                currentSide ||
                            entryFillPrice <= 0
                        )
                        {
                            return;
                        }

                        botDailyPnL +=
                            grossPnL;

                        botDailyPnL -=
                            exitCommission;

                        activeExitQuantity +=
                            exitQty;

                        activeExitGrossPnL +=
                            grossPnL;

                        activeExitCommission +=
                            exitCommission;

                        localExitQty =
                            Math.Min(
                                activeExitQuantity,
                                entryQuantity
                            );

                        localRemainingQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                localExitQty
                            );

                        lifecycleComplete =
                            accountFlatAfterExecution ||
                            localRemainingQty <= 0;

                        botUnrealizedPnL =
                            lifecycleComplete
                                ? 0
                                : botUnrealizedPnL;

                        if (lifecycleComplete)
                        {
                            persistentDailyLocked =
                                persistentDailyLocked ||
                                botDailyPnL >=
                                    activeDailyTarget ||
                                botDailyPnL <=
                                    -activeDailyLoss;

                            executionStatus =
                                persistentDailyLocked
                                    ? "DAILY RISK LOCK"
                                    : (
                                        protectiveExit
                                            ? (
                                                orderName ==
                                                    "JJ_TARGET"
                                                    ? "TARGET FILLED"
                                                    : "STOP FILLED"
                                            )
                                            : "FLAT CONFIRMED"
                                    );

                            finalLearningNet =
                                activeExitGrossPnL
                                - activeEntryCommission
                                - activeExitCommission;
                        }
                        else
                        {
                            executionStatus =
                                protectiveExit
                                    ? "EXIT PARTIAL"
                                    : "FLATTEN PARTIAL";

                            finalLearningNet =
                                0;
                        }

                        localBotPnL =
                            botDailyPnL;

                        localDailyLocked =
                            persistentDailyLocked;
                    }

                    SavePersistentDailyState();
                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        (
                            lifecycleComplete
                                ? "EXIT COMPLETE"
                                : "EXIT PARTIAL FILL"
                        )
                        + " | Order: "
                        + orderName
                        + " | Fill Qty: "
                        + exitQty
                        + " | Closed: "
                        + localExitQty
                        + "/"
                        + currentEntryQty
                        + " | Remaining: "
                        + localRemainingQty
                        + " | Exit: "
                        + e.Price.ToString("0.00")
                        + " | Bot PnL: "
                        + localBotPnL.ToString("$0.00")
                    );

                    if (!lifecycleComplete)
                    {
                        ResizeProtectiveOrdersAfterPartialExit(
                            orderName,
                            localRemainingQty
                        );

                        UpdateExecutionUi();
                        return;
                    }

                    RecordLearningTradeResult(
                        finalLearningNet
                    );

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition ==
                                currentSide
                        )
                        {
                            entryFillPrice = 0;
                            activeStopPrice = 0;
                            activeTargetPrice = 0;
                            entryQuantity = 0;
                            botUnrealizedPnL = 0;
                            activeEntryCommission = 0;
                            activeEffectiveTargetTicks = 0;
                            activeExitQuantity = 0;
                            activeExitGrossPnL = 0;
                            activeExitCommission = 0;

                            protectiveChangeInFlight =
                                false;

                            activeProtectiveChangeToken =
                                0;

                            protectiveChangeOwner =
                                string.Empty;

                            protectiveChangeStartedUtc =
                                DateTime.MinValue;

                            entryMarketPosition =
                                MarketPosition.Flat;

                            entryPending =
                                false;

                            activeEntryUsesMomentumTrailing =
                                false;

                            momentumTrailingStage =
                                0;

                            lastMomentumTrailingStopPrice =
                                0;

                            lastMomentumTrailingChangeUtc =
                                DateTime.MinValue;

                            dailyTargetProtectionArmed =
                                false;

                            lastDailyTargetProtectionStopPrice =
                                0;

                            lastDailyTargetProtectionChangeUtc =
                                DateTime.MinValue;

                            entryOrder = null;
                            stopOrder = null;
                            targetOrder = null;
                            riskFlattenOrder = null;
                            riskFlattenSent = false;
                            riskFlattenStage = 0;
                            riskFlattenLastActionUtc =
                                DateTime.MinValue;
                        }
                    }

                    UpdateExecutionMonitor();
                    UpdateExecutionUi();
                    return;
                }
            }
        }

        // =====================================================
        // DYNAMIC PROFIT TARGET
        //
        // The user configured TP is treated as the MAXIMUM.
        // Strong context keeps 100%, medium uses 80%, weak uses 65%.
        // =====================================================
        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            if (activeTargetTicks <= 0)
                return 1;

            int momentumScore = 0;
            int htfScore = 0;
            bool breakout = false;
            double volumeRatio = 0;

            lock (marketContextLock)
            {
                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    momentumScore =
                        latestRangeLongScore;

                    htfScore =
                        latestHtfLongScore;

                    breakout =
                        latestRangeHighBreakout;
                }
                else
                {
                    momentumScore =
                        latestRangeShortScore;

                    htfScore =
                        latestHtfShortScore;

                    breakout =
                        latestRangeLowBreakout;
                }

                volumeRatio =
                    latestRangeVolumeRatio;
            }

            int minimumTicks =
                Math.Min(
                    DynamicTargetMinTicks,
                    activeTargetTicks
                );

            int targetTicks;

            if (
                momentumScore >= 4 &&
                breakout &&
                htfScore >= 1
            )
            {
                // Strong move: allow the full configured target.
                targetTicks =
                    activeTargetTicks;
            }
            else if (
                momentumScore >= 3 &&
                (
                    breakout ||
                    volumeRatio >=
                        MomentumVolumeExpansion
                )
            )
            {
                // Medium move: reduce target to 80%.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetMediumFactor
                    );
            }
            else
            {
                // Weak/slow move: take profit sooner.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetWeakFactor
                    );
            }

            targetTicks =
                Math.Max(
                    minimumTicks,
                    Math.Min(
                        activeTargetTicks,
                        targetTicks
                    )
                );

            PrintBotMessage(
                "DYNAMIC TARGET"
                + " | Momentum: "
                + momentumScore
                + "/5"
                + " | HTF: "
                + htfScore
                + "/2"
                + " | Breakout: "
                + breakout
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxCfg: "
                + activeTargetTicks
                + " ticks"
            );

            return targetTicks;
        }

        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int effectiveTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    "JJ_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        "JJ_STOP",
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        "JJ_TARGET",
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }

        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }

        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }

        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    "JJ_TARGET",
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    "JJ_STOP",
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        private double RoundToInstrumentTick(
            double price)
        {
            if (
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return price;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return price;

            return
                Math.Round(
                    price / tickSize,
                    0,
                    MidpointRounding.AwayFromZero
                )
                * tickSize;
        }

        // =====================================================
        // MOMENTUM CAPITAL PROTECTION V1
        //
        // Applies ONLY to entries whose learning context contains
        // "MOMENTUM" (including STRUCTURE+MOMENTUM).
        //
        // Stage 1: +40 ticks  -> stop to break even
        // Stage 2: +70 ticks  -> lock +30 ticks
        // Stage 3: +100 ticks -> continuously trail 40 ticks
        //
        // The stop is NEVER moved backwards.
        // =====================================================
        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            bool localTrailingActive;
            bool localDailyProtectionArmed;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            if (
                favorableTicks <
                    MomentumBreakEvenTriggerTicks
            )
            {
                return;
            }

            double desiredStop =
                localActiveStopPrice;

            int desiredStage =
                localMomentumStage;

            // Stage 1: Break Even
            if (
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                desiredStop =
                    localEntryFillPrice;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Dynamic trailing
            if (
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    desiredStop =
                        Math.Max(
                            desiredStop,
                            trailCandidate
                        );
                }
                else
                {
                    desiredStop =
                        Math.Min(
                            desiredStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    3;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? "BREAK EVEN"
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        // =====================================================
        // DAILY TARGET PROTECTION
        //
        // Once total bot PnL reaches the configured daily target,
        // stop opening new trades and trail the current winner while
        // protecting approximately DailyTargetGivebackDollars.
        // =====================================================
        private void UpdateDailyTargetProtection(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            double localBotDailyPnL;
            double localBotUnrealizedPnL;
            bool localDailyProtectionArmed;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localBotDailyPnL =
                    botDailyPnL;

                localBotUnrealizedPnL =
                    botUnrealizedPnL;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;
            }

            if (
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            double totalPnL =
                localBotDailyPnL +
                localBotUnrealizedPnL;

            if (
                !localDailyProtectionArmed &&
                totalPnL <
                    activeDailyTarget
            )
            {
                return;
            }

            bool newlyArmed =
                false;

            if (!localDailyProtectionArmed)
            {
                lock (executionStateLock)
                {
                    // Re-check before arming.
                    if (
                        !dailyTargetProtectionArmed &&
                        stopOrder != null &&
                        entryMarketPosition !=
                            MarketPosition.Flat &&
                        (
                            botDailyPnL +
                            botUnrealizedPnL
                        ) >=
                            activeDailyTarget
                    )
                    {
                        dailyTargetProtectionArmed =
                            true;

                        persistentDailyLocked =
                            true;

                        executionStatus =
                            "DAILY TARGET TRAILING";

                        newlyArmed =
                            true;

                        localDailyProtectionArmed =
                            true;

                        localBotDailyPnL =
                            botDailyPnL;

                        localBotUnrealizedPnL =
                            botUnrealizedPnL;

                        totalPnL =
                            localBotDailyPnL +
                            localBotUnrealizedPnL;
                    }
                }

                if (!localDailyProtectionArmed)
                    return;

                if (newlyArmed)
                {
                    SavePersistentDailyState();
                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "DAILY TARGET PROTECTION ARMED"
                        + " | Total: "
                        + totalPnL.ToString("$0.00")
                        + " | Target: "
                        + activeDailyTarget.ToString("$0.00")
                    );
                }
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            double pointValue =
                instrument
                    .MasterInstrument
                    .PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double protectedDailyPnL =
                Math.Max(
                    0,
                    activeDailyTarget -
                    DailyTargetGivebackDollars
                );

            double requiredUnrealized =
                Math.Max(
                    0,
                    protectedDailyPnL -
                    localBotDailyPnL
                );

            double dollarsPerPoint =
                pointValue *
                localEntryQuantity;

            if (dollarsPerPoint <= 0)
                return;

            double requiredPoints =
                requiredUnrealized /
                dollarsPerPoint;

            double protectionFloor;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                protectionFloor =
                    localEntryFillPrice +
                    requiredPoints;
            }
            else
            {
                protectionFloor =
                    localEntryFillPrice -
                    requiredPoints;
            }

            double trailCandidate;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                trailCandidate =
                    currentPrice
                    - DailyTargetTrailDistanceTicks
                    * tickSize;
            }
            else
            {
                trailCandidate =
                    currentPrice
                    + DailyTargetTrailDistanceTicks
                    * tickSize;
            }

            double desiredStop;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    Math.Max(
                        localActiveStopPrice,
                        Math.Max(
                            protectionFloor,
                            trailCandidate
                        )
                    );

                desiredStop =
                    Math.Min(
                        desiredStop,
                        currentPrice - tickSize
                    );
            }
            else
            {
                desiredStop =
                    Math.Min(
                        localActiveStopPrice,
                        Math.Min(
                            protectionFloor,
                            trailCandidate
                        )
                    );

                desiredStop =
                    Math.Max(
                        desiredStop,
                        currentPrice + tickSize
                    );
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "DAILY_TARGET_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    !dailyTargetProtectionArmed ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastDailyTargetProtectionChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastDailyTargetProtectionChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastDailyTargetProtectionStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastDailyTargetProtectionStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                lastDailyTargetProtectionChangeUtc =
                    reservationTimeUtc;

                lastDailyTargetProtectionStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                PrintBotMessage(
                    "DAILY TARGET TRAILING"
                    + " | Total PnL: "
                    + totalPnL.ToString("$0.00")
                    + " | Protected Floor: "
                    + protectedDailyPnL.ToString("$0.00")
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastDailyTargetProtectionStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastDailyTargetProtectionChangeUtc =
                            DateTime.MinValue;

                        lastDailyTargetProtectionStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "DAILY TARGET TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        // =====================================================
        // PROP-FIRM FORCE FLAT
        // =====================================================
        private void CheckForceFlatTime()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                ConvertToNewYorkTime(
                    DateTime.Now
                );

            if (
                forceFlatDateNy !=
                    nowNy.Date
            )
            {
                forceFlatDateNy =
                    nowNy.Date;

                forceFlatSentToday =
                    false;
            }

            // Weekend safety:
            // The 16:25 ET prop-firm force-flat rule must never create
            // a Daily Lock on Saturday or Sunday. Without this guard,
            // simply opening NinjaTrader on a weekend after 16:25 ET
            // creates a brand-new daily state with DailyLocked=true.
            if (
                nowNy.DayOfWeek ==
                    DayOfWeek.Saturday ||
                nowNy.DayOfWeek ==
                    DayOfWeek.Sunday
            )
            {
                return;
            }

            if (
                ToTimeInt(nowNy) <
                    ForceFlatTimeNy
            )
            {
                return;
            }

            // No new entries after the force-flat time on trading weekdays.
            persistentDailyLocked =
                true;

            SavePersistentDailyState();

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (isFlat)
            {
                if (!forceFlatSentToday)
                {
                    forceFlatSentToday =
                        true;

                    executionStatus =
                        "FORCE FLAT - FLAT";

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "FORCE FLAT CHECK"
                        + " | "
                        + nowNy.ToString("HH:mm:ss")
                        + " ET"
                        + " | Position already FLAT."
                    );
                }

                return;
            }

            if (forceFlatSentToday)
                return;

            forceFlatSentToday =
                true;

            try
            {
                executionStatus =
                    "FORCE FLAT";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "FORCE FLAT START"
                    + " | "
                    + nowNy.ToString("HH:mm:ss")
                    + " ET"
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                );

                selectedAccount.Flatten(
                    new[]
                    {
                        selectedInstrument
                    }
                );

                PrintBotMessage(
                    "FORCE FLAT SENT"
                    + " | Account.Flatten"
                    + " | "
                    + selectedInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                forceFlatSentToday =
                    false;

                PrintBotMessage(
                    "FORCE FLAT ERROR: "
                    + ex.Message
                );
            }
        }

        private void UpdateUnrealizedPnL(
            double currentPrice)
        {
            Instrument instrument =
                selectedInstrument;

            double localEntryPrice;
            int localQuantity;
            MarketPosition localPosition;

            lock (executionStateLock)
            {
                localEntryPrice =
                    entryFillPrice;

                localQuantity =
                    entryQuantity;

                localPosition =
                    entryMarketPosition;
            }

            if (
                instrument == null ||
                instrument.MasterInstrument == null ||
                localEntryPrice <= 0 ||
                localQuantity <= 0 ||
                localPosition ==
                    MarketPosition.Flat
            )
            {
                lock (executionStateLock)
                {
                    botUnrealizedPnL =
                        0;
                }

                UpdatePnlDisplay();
                return;
            }

            double pointValue =
                instrument
                    .MasterInstrument
                    .PointValue;

            double newUnrealizedPnL =
                0;

            if (
                localPosition ==
                    MarketPosition.Long
            )
            {
                newUnrealizedPnL =
                    (
                        currentPrice -
                        localEntryPrice
                    )
                    * pointValue
                    * localQuantity;
            }
            else if (
                localPosition ==
                    MarketPosition.Short
            )
            {
                newUnrealizedPnL =
                    (
                        localEntryPrice -
                        currentPrice
                    )
                    * pointValue
                    * localQuantity;
            }

            lock (executionStateLock)
            {
                // Do not apply a PnL calculation to a trade that
                // changed while this method was calculating it.
                if (
                    entryFillPrice !=
                        localEntryPrice ||
                    entryQuantity !=
                        localQuantity ||
                    entryMarketPosition !=
                        localPosition
                )
                {
                    return;
                }

                botUnrealizedPnL =
                    newUnrealizedPnL;

                if (
                    activeLearningTrade != null
                )
                {
                    if (
                        botUnrealizedPnL >
                        activeLearningTrade.Mfe
                    )
                    {
                        activeLearningTrade.Mfe =
                            botUnrealizedPnL;
                    }

                    if (
                        botUnrealizedPnL <
                        activeLearningTrade.Mae
                    )
                    {
                        activeLearningTrade.Mae =
                            botUnrealizedPnL;
                    }
                }
            }

            UpdatePnlDisplay();
        }

        private void UpdatePnlDisplay()
        {
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;

            lock (executionStateLock)
            {
                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;
            }

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (unrealizedPnlText != null)
                    {
                        unrealizedPnlText.Text =
                            localUnrealizedPnL.ToString(
                                "$0.00"
                            );

                        unrealizedPnlText.Foreground =
                            localUnrealizedPnL > 0
                                ? Brushes.LimeGreen
                                : localUnrealizedPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }

                    if (totalPnlText != null)
                    {
                        totalPnlText.Text =
                            totalPnL.ToString(
                                "$0.00"
                            );

                        totalPnlText.Foreground =
                            totalPnL > 0
                                ? Brushes.LimeGreen
                                : totalPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }
                })
            );
        }

        private void CheckDailyLossEmergency()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null ||
                !IsSimulationAccount(selectedAccount)
            )
            {
                return;
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAvgPrice;

            bool actualFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAvgPrice
                );

            if (actualFlat)
            {
                if (riskFlattenSent)
                {
                    executionStatus =
                        persistentDailyLocked
                            ? "DAILY RISK LOCK"
                            : "FLAT CONFIRMED";

                    PrintBotMessage(
                        "FLATTEN CONFIRMED | Position: FLAT"
                    );

                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;
                    UpdateExecutionMonitor();
                }

                return;
            }

            double totalPnL =
                botDailyPnL +
                botUnrealizedPnL;

            // Hard flatten is ONLY for the configured DAILY LOSS.
            // A DailyLocked state caused by profit target or force-flat time
            // must never be mistaken for a loss emergency.
            bool dailyLossActuallyHit =
                totalPnL <=
                    -activeDailyLoss;

            if (!dailyLossActuallyHit)
                return;

            if (!riskFlattenSent)
            {
                persistentDailyLocked = true;
                riskFlattenSent = true;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                SavePersistentDailyState();

                executionStatus =
                    "DAILY LOSS FLATTEN";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "DAILY LOSS LIMIT HIT"
                    + " | Total PnL: "
                    + totalPnL.ToString("$0.00")
                    + " | HARD FLATTEN STARTED."
                );
            }

            // Throttle emergency actions. Range updates can arrive many times
            // per second; a flatten attempt is allowed at most once per second.
            DateTime nowUtc = DateTime.UtcNow;

            if (
                riskFlattenLastActionUtc != DateTime.MinValue &&
                (nowUtc - riskFlattenLastActionUtc).TotalMilliseconds < 1000
            )
            {
                return;
            }

            try
            {
                if (riskFlattenStage == 0)
                {
                    selectedAccount.Flatten(
                        new[] { selectedInstrument }
                    );

                    riskFlattenStage = 1;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 1"
                        + " | Account.Flatten sent"
                        + " | Position: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                if (riskFlattenStage == 1)
                {
                    selectedAccount.CancelAllOrders(
                        selectedInstrument
                    );

                    riskFlattenStage = 2;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 2"
                        + " | CancelAllOrders sent"
                        + " | Position still: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                bool canSubmitFallback =
                    riskFlattenOrder == null ||
                    riskFlattenOrder.OrderState == OrderState.Filled ||
                    riskFlattenOrder.OrderState == OrderState.Cancelled ||
                    riskFlattenOrder.OrderState == OrderState.Rejected;

                if (!canSubmitFallback)
                {
                    riskFlattenLastActionUtc = nowUtc;
                    return;
                }

                OrderAction closeAction =
                    actualSide == MarketPosition.Long
                        ? OrderAction.Sell
                        : OrderAction.BuyToCover;

                riskFlattenOrder =
                    selectedAccount.CreateOrder(
                        selectedInstrument,
                        closeAction,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        actualQty,
                        0,
                        0,
                        string.Empty,
                        "JJ_RISK_FLATTEN",
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                selectedAccount.Submit(
                    new[] { riskFlattenOrder }
                );

                riskFlattenStage = 3;
                riskFlattenLastActionUtc = nowUtc;

                executionStatus =
                    "HARD FLATTEN MARKET";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "DAILY LOSS FLATTEN FALLBACK"
                    + " | MARKET " + closeAction
                    + " " + actualQty
                    + " | Position was: " + actualSide
                );
            }
            catch (Exception ex)
            {
                riskFlattenLastActionUtc = nowUtc;

                PrintBotMessage(
                    "DAILY LOSS FLATTEN ERROR: "
                    + ex.Message
                );
            }
        }

        // Returns true when the REAL account position for the selected
        // instrument is flat. This deliberately does not rely only on the
        // bot's internal entryMarketPosition flag.
        private bool TryGetSelectedInstrumentPosition(
            out MarketPosition marketPosition,
            out int quantity,
            out double averagePrice)
        {
            marketPosition = MarketPosition.Flat;
            quantity = 0;
            averagePrice = 0;

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return true;
            }

            lock (selectedAccount.Positions)
            {
                foreach (Position position in selectedAccount.Positions)
                {
                    if (
                        position == null ||
                        position.Instrument == null ||
                        position.Instrument.FullName !=
                            selectedInstrument.FullName
                    )
                    {
                        continue;
                    }

                    marketPosition = position.MarketPosition;
                    quantity = position.Quantity;
                    averagePrice = position.AveragePrice;

                    return
                        marketPosition == MarketPosition.Flat ||
                        quantity <= 0;
                }
            }

            return true;
        }

        private void UpdateExecutionMonitor()
        {
            MarketPosition localPosition;
            int localQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            int localStopTicks;
            int localTargetTicks;

            lock (executionStateLock)
            {
                localPosition =
                    entryMarketPosition;

                localQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localStopTicks =
                    activeStopTicks;

                localTargetTicks =
                    activeTargetTicks;
            }

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (positionText != null)
                    {
                        if (
                            localPosition ==
                                MarketPosition.Long
                        )
                        {
                            positionText.Text =
                                "LONG";

                            positionText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localPosition ==
                                MarketPosition.Short
                        )
                        {
                            positionText.Text =
                                "SHORT";

                            positionText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else
                        {
                            positionText.Text =
                                "FLAT";

                            positionText.Foreground =
                                Brushes.White;
                        }
                    }

                    if (positionQtyText != null)
                    {
                        positionQtyText.Text =
                            localQuantity.ToString();
                    }

                    if (entryPriceText != null)
                    {
                        entryPriceText.Text =
                            localEntryPrice > 0
                                ? FormatPrice(
                                    localEntryPrice
                                )
                                : "--";
                    }

                    if (stopPriceText != null)
                    {
                        stopPriceText.Text =
                            localStopPrice > 0
                                ? FormatPrice(
                                    localStopPrice
                                )
                                : "--";
                    }

                    if (targetPriceText != null)
                    {
                        targetPriceText.Text =
                            localTargetPrice > 0
                                ? FormatPrice(
                                    localTargetPrice
                                )
                                : "--";
                    }

                    if (riskRewardText != null)
                    {
                        double riskDistance =
                            0;

                        double rewardDistance =
                            0;

                        if (
                            localEntryPrice > 0 &&
                            localStopPrice > 0 &&
                            localTargetPrice > 0
                        )
                        {
                            riskDistance =
                                Math.Abs(
                                    localEntryPrice -
                                    localStopPrice
                                );

                            rewardDistance =
                                Math.Abs(
                                    localTargetPrice -
                                    localEntryPrice
                                );
                        }

                        double rr =
                            riskDistance > 0
                                ? rewardDistance /
                                    riskDistance
                                : (
                                    localStopTicks > 0
                                        ? (
                                            double
                                            )localTargetTicks
                                            / localStopTicks
                                        : 0
                                );

                        riskRewardText.Text =
                            "1 : "
                            + rr.ToString(
                                "0.00"
                            );
                    }

                    if (orderStatusText != null)
                    {
                        orderStatusText.Text =
                            localExecutionStatus;

                        if (
                            localExecutionStatus ==
                                "PROTECTED"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localExecutionStatus ==
                                "STOP FILLED" ||
                            localExecutionStatus ==
                                "ENTRY ERROR" ||
                            localExecutionStatus ==
                                "PROTECTION ERROR" ||
                            localExecutionStatus ==
                                "DAILY LOSS FLATTEN"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else if (
                            localExecutionStatus ==
                                "ENTRY SUBMITTED" ||
                            localExecutionStatus ==
                                "ENTRY FILLED" ||
                            localExecutionStatus ==
                                "FLATTENING" ||
                            localExecutionStatus ==
                                "WAITING PROTECTION" ||
                            localExecutionStatus ==
                                "UPDATING OCO"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.Goldenrod;
                        }
                        else
                        {
                            orderStatusText.Foreground =
                                Brushes.White;
                        }
                    }
                })
            );
        }

        private void ResetExecutionMonitor()
        {
            lock (executionStateLock)
            {
                entryFillPrice = 0;
                activeStopPrice = 0;
                activeTargetPrice = 0;
                entryQuantity = 0;
                activeEffectiveTargetTicks = 0;
                activeExitQuantity = 0;
                activeExitGrossPnL = 0;
                activeExitCommission = 0;
                activeEntryCommission = 0;

                protectiveChangeInFlight = false;
                activeProtectiveChangeToken = 0;
                protectiveChangeOwner =
                    string.Empty;
                protectiveChangeStartedUtc =
                    DateTime.MinValue;

                botUnrealizedPnL = 0;
                riskFlattenSent = false;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                entryMarketPosition =
                    MarketPosition.Flat;

                executionStatus =
                    "WAITING";

                activeEntryUsesMomentumTrailing =
                    false;

                momentumTrailingStage =
                    0;

                lastMomentumTrailingStopPrice =
                    0;

                lastMomentumTrailingChangeUtc =
                    DateTime.MinValue;

                dailyTargetProtectionArmed =
                    false;

                lastDailyTargetProtectionStopPrice =
                    0;

                lastDailyTargetProtectionChangeUtc =
                    DateTime.MinValue;
            }

            UpdateExecutionMonitor();
        }

        private void UpdateExecutionUi()
        {
            UpdatePnlDisplay();

            double localRealizedPnL;
            double localUnrealizedPnL;
            int localAmTrades;
            int localPmTrades;
            bool localDailyLocked;

            lock (executionStateLock)
            {
                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localDailyLocked =
                    persistentDailyLocked;
            }

            double localTotalPnL =
                localRealizedPnL +
                localUnrealizedPnL;

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (tradesText != null)
                    {
                        tradesText.Text =
                            "AM "
                            + localAmTrades
                            + "/"
                            + activeMaxTrades
                            + " | PM "
                            + localPmTrades
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        localDailyLocked ||
                        localTotalPnL >=
                            activeDailyTarget ||
                        localTotalPnL <=
                            -activeDailyLoss
                    )
                    {
                        if (signalText != null)
                        {
                            signalText.Text =
                                "DAILY RISK LOCK";

                            signalText.Foreground =
                                Brushes.OrangeRed;
                        }
                    }
                })
            );
        }

        // =====================================================
        // LIQUIDITY SWEEP + BOS / CHOCH
        //
        // LONG SEQUENCE:
        // 1) A closed bar trades below the lowest low of the
        //    previous SweepLookback bars.
        // 2) That same bar closes back ABOVE that prior low.
        //    -> LOW SWEPT
        // 3) Within SweepMaxAgeBars, price CLOSES above the
        //    pre-sweep structure high.
        //    -> BULLISH BOS / CHOCH
        //
        // SHORT is the inverse.
        // =====================================================
        private void DetectLiquidityAndStructure(
            Bars bars,
            int closedBarIndex,
            out string liquidityState,
            out string structureState,
            out bool bullishConfirmed,
            out bool bearishConfirmed,
            out string bullishSetupKey,
            out string bearishSetupKey)
        {
            liquidityState =
                "NONE";

            structureState =
                "WAITING";

            bullishConfirmed =
                false;

            bearishConfirmed =
                false;

            bullishSetupKey =
                string.Empty;

            bearishSetupKey =
                string.Empty;

            if (
                bars == null ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                closedBarIndex <
                    SweepLookback + StructureLookback
            )
            {
                return;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
            {
                return;
            }

            double minimumSweepDistance =
                MinimumSweepTicks
                * tickSize;

            string consumedBullishKey;
            string consumedBearishKey;
            DateTime consumedBullishConfirmTime;
            DateTime consumedBearishConfirmTime;

            lock (executionStateLock)
            {
                consumedBullishKey =
                    consumedBullishStructureSetupKey
                    ?? string.Empty;

                consumedBearishKey =
                    consumedBearishStructureSetupKey
                    ?? string.Empty;

                consumedBullishConfirmTime =
                    consumedBullishStructureConfirmTime;

                consumedBearishConfirmTime =
                    consumedBearishStructureConfirmTime;
            }

            int firstSweepIndex =
                Math.Max(
                    SweepLookback,
                    closedBarIndex
                        - SweepMaxAgeBars
                );

            int latestLiquidityIndex =
                -1;

            int latestBullishConfirmIndex =
                -1;

            int latestBearishConfirmIndex =
                -1;

            int latestBullishSweepIndex =
                -1;

            int latestBearishSweepIndex =
                -1;

            string latestBullishSetupKey =
                string.Empty;

            string latestBearishSetupKey =
                string.Empty;

            // Scan oldest -> newest so the most recent valid,
            // UNCONSUMED structural event wins.
            for (
                int sweepIndex =
                    firstSweepIndex;
                sweepIndex <= closedBarIndex;
                sweepIndex++
            )
            {
                int priorStart =
                    Math.Max(
                        0,
                        sweepIndex
                            - SweepLookback
                    );

                int priorEnd =
                    sweepIndex - 1;

                if (
                    priorEnd <= priorStart
                )
                {
                    continue;
                }

                double priorLow =
                    GetLowestLow(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double priorHigh =
                    GetHighestHigh(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double sweepLow =
                    bars.GetLow(
                        sweepIndex
                    );

                double sweepHigh =
                    bars.GetHigh(
                        sweepIndex
                    );

                double sweepClose =
                    bars.GetClose(
                        sweepIndex
                    );

                // A sweep must reclaim the prior level AND exceed it
                // by at least MinimumSweepTicks. One-tick noise is ignored.
                bool lowSweep =
                    (
                        priorLow -
                        sweepLow
                    ) >=
                        minimumSweepDistance &&
                    sweepClose >
                        priorLow;

                bool highSweep =
                    (
                        sweepHigh -
                        priorHigh
                    ) >=
                        minimumSweepDistance &&
                    sweepClose <
                        priorHigh;

                // One candle can legitimately sweep both sides.
                // Represent that explicitly instead of allowing the
                // HIGH branch to overwrite the LOW branch.
                if (
                    (lowSweep || highSweep) &&
                    sweepIndex >=
                        latestLiquidityIndex
                )
                {
                    latestLiquidityIndex =
                        sweepIndex;

                    liquidityState =
                        lowSweep && highSweep
                            ? "BOTH SWEPT"
                            : lowSweep
                                ? "LOW SWEPT"
                                : "HIGH SWEPT";
                }

                // ---------------------------------------------
                // BULLISH STRUCTURE BREAK AFTER LOW SWEEP
                // ---------------------------------------------
                if (lowSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureHigh =
                        GetHighestHigh(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            > structureHigh
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    true,
                                    sweepIndex,
                                    confirmIndex
                                );

                            // The FIRST close through the pre-sweep
                            // structure level defines this setup.
                            // If it was already filled/consumed, do not
                            // reinterpret later closes as a new setup.
                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBullishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBullishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBullishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBullishConfirmIndex
                            )
                            {
                                latestBullishConfirmIndex =
                                    confirmIndex;

                                latestBullishSweepIndex =
                                    sweepIndex;

                                latestBullishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }

                // ---------------------------------------------
                // BEARISH STRUCTURE BREAK AFTER HIGH SWEEP
                // ---------------------------------------------
                if (highSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureLow =
                        GetLowestLow(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            < structureLow
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    false,
                                    sweepIndex,
                                    confirmIndex
                                );

                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBearishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBearishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBearishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBearishConfirmIndex
                            )
                            {
                                latestBearishConfirmIndex =
                                    confirmIndex;

                                latestBearishSweepIndex =
                                    sweepIndex;

                                latestBearishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }
            }

            // Pick the most recent UNCONSUMED structural break.
            if (
                latestBullishConfirmIndex >
                    latestBearishConfirmIndex
            )
            {
                bullishConfirmed =
                    true;

                bearishConfirmed =
                    false;

                bullishSetupKey =
                    latestBullishSetupKey;

                // BOS / CHOCH is classified from the EMA context that
                // existed BEFORE the sweep, not after the break.
                int contextIndex =
                    Math.Max(
                        0,
                        latestBullishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep <
                        slowBeforeSweep
                        ? "BULLISH CHOCH"
                        : "BULLISH BOS";
            }
            else if (
                latestBearishConfirmIndex >
                    latestBullishConfirmIndex
            )
            {
                bullishConfirmed =
                    false;

                bearishConfirmed =
                    true;

                bearishSetupKey =
                    latestBearishSetupKey;

                int contextIndex =
                    Math.Max(
                        0,
                        latestBearishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep >
                        slowBeforeSweep
                        ? "BEARISH CHOCH"
                        : "BEARISH BOS";
            }
        }

        private string BuildStructureSetupKey(
            Bars bars,
            bool isLong,
            int sweepIndex,
            int confirmIndex)
        {
            if (
                bars == null ||
                sweepIndex < 0 ||
                confirmIndex < 0 ||
                sweepIndex >= bars.Count ||
                confirmIndex >= bars.Count
            )
            {
                return string.Empty;
            }

            DateTime sweepTime =
                bars.GetTime(
                    sweepIndex
                );

            DateTime confirmTime =
                bars.GetTime(
                    confirmIndex
                );

            return
                (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
                + "|S:"
                + sweepTime.Ticks
                + "|C:"
                + confirmTime.Ticks;
        }

        private DateTime GetStructureConfirmTimeFromKey(
            string setupKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    setupKey
                )
            )
            {
                return DateTime.MinValue;
            }

            const string marker =
                "|C:";

            int markerIndex =
                setupKey.LastIndexOf(
                    marker,
                    StringComparison.Ordinal
                );

            if (
                markerIndex < 0
            )
            {
                return DateTime.MinValue;
            }

            string ticksText =
                setupKey.Substring(
                    markerIndex +
                    marker.Length
                );

            long ticks;

            if (
                !long.TryParse(
                    ticksText,
                    out ticks
                ) ||
                ticks <= 0 ||
                ticks > DateTime.MaxValue.Ticks
            )
            {
                return DateTime.MinValue;
            }

            try
            {
                return new DateTime(
                    ticks
                );
            }
            catch
            {
                return DateTime.MinValue;
            }
        }

        // =====================================================
        // HIGHEST HIGH IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        private double GetHighestHigh(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double highest =
                bars.GetHigh(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetHigh(i);

                if (
                    value > highest
                )
                {
                    highest =
                        value;
                }
            }

            return highest;
        }

        // =====================================================
        // LOWEST LOW IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        private double GetLowestLow(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double lowest =
                bars.GetLow(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetLow(i);

                if (
                    value < lowest
                )
                {
                    lowest =
                        value;
                }
            }

            return lowest;
        }

        // =====================================================
        // SESSION VWAP
        //
        // This is a 5-minute OHLCV session VWAP calculation:
        // TypicalPrice = (High + Low + Close) / 3
        // weighted by each 5-minute bar's volume.
        //
        // VWAP starts at 09:30 New York time each day.
        // =====================================================
        private double CalculateSessionVwap(
            Bars bars,
            int endIndex)
        {
            if (
                bars == null ||
                endIndex < 0 ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            DateTime endNyTime =
                ConvertToNewYorkTime(
                    bars.GetTime(
                        endIndex
                    )
                );

            DateTime sessionDate =
                endNyTime.Date;

            double cumulativePriceVolume =
                0;

            double cumulativeVolume =
                0;

            for (
                int i = endIndex;
                i >= 0;
                i--
            )
            {
                DateTime barNyTime =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNyTime.Date <
                    sessionDate
                )
                {
                    break;
                }

                if (
                    barNyTime.Date !=
                    sessionDate
                )
                {
                    continue;
                }

                int nyTime =
                    ToTimeInt(
                        barNyTime
                    );

                if (
                    nyTime <
                    RthVwapStart
                )
                {
                    break;
                }

                long volume =
                    bars.GetVolume(i);

                if (volume <= 0)
                    continue;

                double typicalPrice =
                    (
                        bars.GetHigh(i)
                        + bars.GetLow(i)
                        + bars.GetClose(i)
                    )
                    / 3.0;

                cumulativePriceVolume +=
                    typicalPrice
                    * volume;

                cumulativeVolume +=
                    volume;
            }

            if (
                cumulativeVolume <= 0
            )
            {
                return 0;
            }

            return
                cumulativePriceVolume
                / cumulativeVolume;
        }

        // =====================================================
        // NY SESSION FILTER
        // =====================================================
        private bool IsBotNySessionActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            bool session1 =
                value >= BotSession1Start &&
                value <= BotSession1End;

            bool session2 =
                value >= BotSession2Start &&
                value <= BotSession2End;

            return
                session1 ||
                session2;
        }

        private string GetBotSessionWindow(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            if (
                value >= BotSession1Start &&
                value <= BotSession1End
            )
            {
                return "AM";
            }

            if (
                value >= BotSession2Start &&
                value <= BotSession2End
            )
            {
                return "PM";
            }

            return "OUTSIDE";
        }

        private int GetSessionTradeCount(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return amTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return pmTradesToday;
            }

            return 0;
        }

        private bool IsSessionTradeLimitReached(
            string sessionWindow)
        {
            if (
                string.IsNullOrWhiteSpace(
                    sessionWindow
                ) ||
                sessionWindow == "OUTSIDE"
            )
            {
                return false;
            }

            return
                GetSessionTradeCount(
                    sessionWindow
                ) >=
                activeMaxTrades;
        }

        private string GetSessionTradeStatus(
            DateTime nyTime)
        {
            string session =
                GetBotSessionWindow(
                    nyTime
                );

            if (session == "AM")
            {
                return
                    "AM "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            if (session == "PM")
            {
                return
                    "PM "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            return
                "AM "
                + amTradesToday
                + "/"
                + activeMaxTrades
                + " | PM "
                + pmTradesToday
                + "/"
                + activeMaxTrades;
        }

        // =====================================================
        // CONVERT BAR TIME FROM NINJATRADER APPLICATION
        // TIME ZONE TO NEW YORK TIME.
        // =====================================================
        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                // If conversion ever fails, keep the original
                // timestamp instead of crashing the bot.
                return time;
            }
        }

        // =====================================================
        // DATETIME -> HHMMSS INTEGER
        // =====================================================
        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }

        // =====================================================
        // RANGE MOMENTUM TRIGGER ENGINE
        // =====================================================
        private void UpdateMomentumFromRangeBars(
            Bars bars,
            bool evaluateClosedRangeBar)
        {
            if (
                bars == null ||
                bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            int longScore;
            int shortScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaSlope;
            bool highBreakout;
            bool lowBreakout;

            CalculateMomentumScores(
                bars,
                closedBarIndex,
                emaFastCurrent,
                out longScore,
                out shortScore,
                out rangeRatio,
                out volumeRatio,
                out bodyRatio,
                out emaSlope,
                out highBreakout,
                out lowBreakout
            );

            bool bullishMomentum =
                longScore >= MomentumMinScore;

            bool bearishMomentum =
                shortScore >= MomentumMinScore;

            string momentumState =
                bullishMomentum &&
                !bearishMomentum
                    ? "BULLISH "
                        + longScore
                        + "/5"
                    : bearishMomentum &&
                        !bullishMomentum
                        ? "BEARISH "
                            + shortScore
                            + "/5"
                        : "L "
                            + longScore
                            + "/5 | S "
                            + shortScore
                            + "/5";

            lock (marketContextLock)
            {
                latestRangeLongScore =
                    longScore;
                latestRangeShortScore =
                    shortScore;
                latestRangeRatio =
                    rangeRatio;
                latestRangeVolumeRatio =
                    volumeRatio;
                latestRangeBodyRatio =
                    bodyRatio;
                latestRangeEmaSlope =
                    emaSlope;
                latestRangeHighBreakout =
                    highBreakout;
                latestRangeLowBreakout =
                    lowBreakout;
                latestRangeMomentumState =
                    momentumState;
            }

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (
                        !botRunning ||
                        momentumText == null
                    )
                    {
                        return;
                    }

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        bullishMomentum
                            ? Brushes.LimeGreen
                            : bearishMomentum
                                ? Brushes.OrangeRed
                                : Brushes.Goldenrod;
                })
            );

            if (!evaluateClosedRangeBar)
                return;

            DateTime closedRangeTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime rangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            EnsureTradingDay(
                rangeNyTime.Date
            );

            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool m5AboveVwap;
            bool m5BelowVwap;
            string m5Structure;

            lock (marketContextLock)
            {
                m5Ready =
                    latestM5ContextReady;
                m5Bullish =
                    latestM5BullishTrend;
                m5Bearish =
                    latestM5BearishTrend;
                m5AboveVwap =
                    latestM5AboveVwap;
                m5BelowVwap =
                    latestM5BelowVwap;
                m5Structure =
                    latestM5StructureState;
            }

            if (!m5Ready)
                return;

            bool nySessionActive =
                IsBotNySessionActive(
                    rangeNyTime
                );

            bool allowMomentumMode =
                activeStrategyMode == "MOMENTUM SCALP" ||
                activeStrategyMode == "HYBRID";

            if (
                !nySessionActive ||
                !allowMomentumMode
            )
            {
                return;
            }

            bool allowLong =
                activeDirection == "BOTH" ||
                activeDirection == "LONG ONLY";

            bool allowShort =
                activeDirection == "BOTH" ||
                activeDirection == "SHORT ONLY";

            bool rawLongReady =
                allowLong &&
                m5Bullish &&
                m5AboveVwap &&
                bullishMomentum;

            bool rawShortReady =
                allowShort &&
                m5Bearish &&
                m5BelowVwap &&
                bearishMomentum;

            if (
                !rawLongReady &&
                !rawShortReady
            )
            {
                return;
            }

            string learningContext =
                "R20 MOMENTUM "
                + (
                    rawLongReady
                        ? longScore
                        : shortScore
                )
                + "/5";

            string learningReason;

            bool learningAllowed =
                IsLearningTradeAllowed(
                    rawLongReady
                        ? "LONG"
                        : "SHORT",
                    rangeNyTime,
                    learningContext,
                    out learningReason
                );

            string rangeSignalLogKey =
                rangeNyTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + (rawLongReady ? longScore : shortScore);

            if (rangeSignalLogKey != lastRangeSignalLogKey)
            {
                lastRangeSignalLogKey = rangeSignalLogKey;

                PrintBotMessage(
                    "RANGE MOMENTUM SIGNAL"
                    + " | "
                    + rangeNyTime.ToString("HH:mm:ss")
                    + " ET"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20 Score: "
                    + (rawLongReady ? longScore : shortScore)
                    + "/5"
                    + " | M5 Trend: "
                    + (
                        m5Bullish
                            ? "BULLISH"
                            : m5Bearish
                                ? "BEARISH"
                                : "NEUTRAL"
                    )
                    + " | M5 VWAP: "
                    + (
                        m5AboveVwap
                            ? "ABOVE"
                            : m5BelowVwap
                                ? "BELOW"
                                : "AT"
                    )
                    + " | M5 Structure: "
                    + m5Structure
                );
            }

            if (!learningAllowed)
            {
                PrintBotMessage(
                    "LEARNING BLOCK RANGE | "
                    + learningReason
                );

                return;
            }

            CaptureLearningSignalContext(
                rawLongReady
                    ? "LONG"
                    : "SHORT",
                rangeNyTime,
                learningContext
            );

            TrySubmitEntry(
                rawLongReady,
                closedRangeTime
            );
        }

        // =====================================================
        // MOMENTUM ENGINE V2 - RANGE SERIES
        // =====================================================
        private void CalculateMomentumScores(
            Bars bars,
            int closedBarIndex,
            double emaFastCurrent,
            out int longScore,
            out int shortScore,
            out double rangeRatio,
            out double volumeRatio,
            out double bodyRatio,
            out double emaFastSlope,
            out bool highBreakout,
            out bool lowBreakout)
        {
            longScore = 0;
            shortScore = 0;
            rangeRatio = 0;
            volumeRatio = 0;
            bodyRatio = 0;
            emaFastSlope = 0;
            highBreakout = false;
            lowBreakout = false;

            if (
                bars == null ||
                closedBarIndex <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 2
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            double high =
                bars.GetHigh(
                    closedBarIndex
                );

            double low =
                bars.GetLow(
                    closedBarIndex
                );

            double currentRange =
                Math.Max(
                    0,
                    high - low
                );

            double currentBody =
                Math.Abs(
                    close - open
                );

            bodyRatio =
                currentRange > 0
                    ? currentBody /
                        currentRange
                    : 0;

            double averageRange = 0;
            double averageVolume = 0;

            for (
                int i = closedBarIndex -
                    MomentumAverageLookback;
                i < closedBarIndex;
                i++
            )
            {
                averageRange +=
                    Math.Max(
                        0,
                        bars.GetHigh(i) -
                        bars.GetLow(i)
                    );

                averageVolume +=
                    bars.GetVolume(i);
            }

            averageRange /=
                MomentumAverageLookback;

            averageVolume /=
                MomentumAverageLookback;

            rangeRatio =
                averageRange > 0
                    ? currentRange /
                        averageRange
                    : 0;

            double currentVolume =
                bars.GetVolume(
                    closedBarIndex
                );

            volumeRatio =
                averageVolume > 0
                    ? currentVolume /
                        averageVolume
                    : 0;

            double emaFastPrevious =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex - 1
                );

            emaFastSlope =
                emaFastCurrent -
                emaFastPrevious;

            double previousHighest =
                double.MinValue;

            double previousLowest =
                double.MaxValue;

            for (
                int i = closedBarIndex -
                    MomentumBreakoutLookback;
                i < closedBarIndex;
                i++
            )
            {
                previousHighest =
                    Math.Max(
                        previousHighest,
                        bars.GetHigh(i)
                    );

                previousLowest =
                    Math.Min(
                        previousLowest,
                        bars.GetLow(i)
                    );
            }

            highBreakout =
                close > previousHighest;

            lowBreakout =
                close < previousLowest;

            bool bullishCandle =
                close > open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool bearishCandle =
                close < open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    MomentumRangeExpansion;

            bool volumeExpanded =
                volumeRatio >=
                    MomentumVolumeExpansion;

            bool emaRising =
                emaFastSlope > 0;

            bool emaFalling =
                emaFastSlope < 0;

            // Five independent components:
            // 1) strong directional body
            // 2) EMA9 slope
            // 3) range expansion
            // 4) relative volume expansion
            // 5) close breakout of recent bars
            if (bullishCandle)
                longScore++;

            if (emaRising)
                longScore++;

            if (rangeExpanded)
                longScore++;

            if (volumeExpanded)
                longScore++;

            if (highBreakout)
                longScore++;

            if (bearishCandle)
                shortScore++;

            if (emaFalling)
                shortScore++;

            if (rangeExpanded)
                shortScore++;

            if (volumeExpanded)
                shortScore++;

            if (lowBreakout)
                shortScore++;
        }

        // =====================================================
        // EMA CALCULATION
        //
        // BarsRequest data cannot be passed directly into
        // NinjaTrader indicators, so EMA is calculated here.
        // =====================================================
        private double CalculateEma(
            Bars bars,
            int period,
            int endIndex)
        {
            if (
                bars == null ||
                period <= 0 ||
                endIndex < 0 ||
                bars.Count <= 0
            )
            {
                return 0;
            }

            int safeEndIndex =
                Math.Min(
                    endIndex,
                    bars.Count - 1
                );

            if (safeEndIndex < 0)
                return 0;

            DateTime firstBarTime;

            try
            {
                firstBarTime =
                    bars.GetTime(0);
            }
            catch
            {
                firstBarTime =
                    DateTime.MinValue;
            }

            double multiplier =
                2.0 / (period + 1.0);

            lock (emaCacheLock)
            {
                Dictionary<int, EmaCacheState> periodCaches;

                if (
                    !emaCaches.TryGetValue(
                        bars,
                        out periodCaches
                    ) ||
                    periodCaches == null
                )
                {
                    periodCaches =
                        new Dictionary<int, EmaCacheState>();

                    emaCaches[bars] =
                        periodCaches;
                }

                EmaCacheState cache;

                if (
                    !periodCaches.TryGetValue(
                        period,
                        out cache
                    ) ||
                    cache == null
                )
                {
                    cache =
                        new EmaCacheState();

                    periodCaches[period] =
                        cache;
                }

                // BarsRequest may roll its internal history window.
                // If bar zero changes, discard the old EMA seed and
                // rebuild once from the new window.
                if (
                    cache.FirstBarTime !=
                        firstBarTime ||
                    cache.Values.Count >
                        bars.Count
                )
                {
                    cache.FirstBarTime =
                        firstBarTime;

                    cache.Values.Clear();
                }

                while (
                    cache.Values.Count <=
                        safeEndIndex
                )
                {
                    int index =
                        cache.Values.Count;

                    double close =
                        bars.GetClose(
                            index
                        );

                    if (index == 0)
                    {
                        cache.Values.Add(
                            close
                        );
                    }
                    else
                    {
                        double previousEma =
                            cache.Values[
                                index - 1
                            ];

                        double ema =
                            (
                                close -
                                previousEma
                            )
                            * multiplier
                            + previousEma;

                        cache.Values.Add(
                            ema
                        );
                    }
                }

                return cache.Values[
                    safeEndIndex
                ];
            }
        }

        private void ClearEmaCaches()
        {
            lock (emaCacheLock)
            {
                emaCaches.Clear();
            }
        }

        // =====================================================
        // STOP BOT
        // =====================================================
        private void ReleaseRuntimeLease()
        {
            string leaseKey =
                activeRuntimeLeaseKey;

            activeRuntimeLeaseKey =
                string.Empty;

            JJBotRuntimeCoordinator.ReleaseBotLease(
                leaseKey
            );
        }

        private void StopBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            botRunning = false;

            ReleaseRuntimeLease();

            currentSignalState =
                "STOPPED";

            currentSetupState =
                "STOPPED";

            PublishSharedState();

            StopBarsEngine();

            statusText.Text =
                "● STOPPED";

            statusText.Foreground =
                Brushes.OrangeRed;

            signalText.Text =
                "STOPPED";

            signalText.Foreground =
                Brushes.White;

            startButton.IsEnabled =
                true;

            stopButton.IsEnabled =
                false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;

            PrintBotMessage(
                "BOT STOPPED - EXISTING OCO ORDERS/POSITION ARE NOT FLATTENED."
            );
        }

        // =====================================================
        // CLOSE ALL
        // TEST MODE ONLY - DOES NOT SEND ORDERS
        // =====================================================
        private void CloseAllClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select an account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (
                !IsSimulationAccount(
                    selectedAccount
                )
            )
            {
                MessageBox.Show(
                    "CLOSE ALL is blocked because the selected account is not SIM.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                return;
            }

            try
            {
                selectedAccount.Flatten(
                    new[]
                    {
                        selectedInstrument
                    }
                );

                botRunning = false;

                ReleaseRuntimeLease();

                entryPending = false;

                currentSignalState =
                    "SIM FLATTEN SENT";

                currentSetupState =
                    "STOPPED";

                executionStatus =
                    "FLATTENING";

                PublishSharedState();

                riskFlattenSent =
                    true;

                UpdateExecutionMonitor();

                StopBarsEngine();

                statusText.Text =
                    "● STOPPED";

                statusText.Foreground =
                    Brushes.OrangeRed;

                signalText.Text =
                    "SIM FLATTEN SENT";

                signalText.Foreground =
                    Brushes.Goldenrod;

                startButton.IsEnabled =
                    true;

                stopButton.IsEnabled =
                    false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;

                if (accountSelector != null)
                    accountSelector.IsEnabled = true;

                if (instrumentSelector != null)
                    instrumentSelector.IsEnabled = true;

                PrintBotMessage(
                    "SIM CLOSE ALL / FLATTEN SENT: "
                    + selectedInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "CLOSE ALL ERROR: "
                    + ex.Message
                );

                MessageBox.Show(
                    ex.Message,
                    "J&J Trading Bot - Close All Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }

        // =====================================================
        // STOP / DISPOSE DATA ENGINE
        // =====================================================
        private void StopBarsEngine()
        {
            barsReady = false;

            if (barsRequest != null)
            {
                try
                {
                    if (barsRequestSubscribed)
                    {
                        barsRequest.Update -=
                            OnBarsRequestUpdate;

                        barsRequestSubscribed =
                            false;
                    }

                    barsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "BARS CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                barsRequest = null;
            }

            if (h1BarsRequest != null)
            {
                try
                {
                    if (h1BarsRequestSubscribed)
                    {
                        h1BarsRequest.Update -=
                            OnH1BarsRequestUpdate;

                        h1BarsRequestSubscribed =
                            false;
                    }

                    h1BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "1H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h1BarsRequest = null;
            }

            if (h4BarsRequest != null)
            {
                try
                {
                    if (h4BarsRequestSubscribed)
                    {
                        h4BarsRequest.Update -=
                            OnH4BarsRequestUpdate;

                        h4BarsRequestSubscribed =
                            false;
                    }

                    h4BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "4H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h4BarsRequest = null;
            }

            h1BarsReady = false;
            h4BarsReady = false;

            lastH1BarTime =
                DateTime.MinValue;

            lastH4BarTime =
                DateTime.MinValue;

            if (rangeBarsRequest != null)
            {
                try
                {
                    if (rangeBarsRequestSubscribed)
                    {
                        rangeBarsRequest.Update -=
                            OnRangeBarsRequestUpdate;

                        rangeBarsRequestSubscribed =
                            false;
                    }

                    rangeBarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "RANGE CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                rangeBarsRequest = null;
            }

            rangeBarsReady = false;
            lastRangeBarTime =
                DateTime.MinValue;

            lastSignalBarTime =
                DateTime.MinValue;

            ClearEmaCaches();
        }

        // =====================================================
        // ERROR STATE
        // =====================================================
        private void SetEngineError(
            string text)
        {
            botRunning = false;

            StopBarsEngine();

            if (statusText != null)
            {
                statusText.Text =
                    "● STOPPED";

                statusText.Foreground =
                    Brushes.OrangeRed;
            }

            if (signalText != null)
            {
                signalText.Text =
                    text;

                signalText.Foreground =
                    Brushes.OrangeRed;
            }

            if (startButton != null)
                startButton.IsEnabled = true;

            if (stopButton != null)
                stopButton.IsEnabled = false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;
        }

        // =====================================================
        // RESET SIGNAL DISPLAY
        // =====================================================
        private void ResetSignalDisplay()
        {
            if (lastPriceText != null)
                lastPriceText.Text = "--";

            if (emaFastText != null)
                emaFastText.Text = "--";

            if (emaSlowText != null)
                emaSlowText.Text = "--";

            if (barTimeText != null)
                barTimeText.Text = "--";

            if (vwapText != null)
                vwapText.Text = "--";

            if (trendText != null)
                trendText.Text = "--";

            if (nySessionText != null)
            {
                nySessionText.Text = "CLOSED";
                nySessionText.Foreground = Brushes.Gray;
            }

            if (setupText != null)
            {
                setupText.Text = "WAITING";
                setupText.Foreground = Brushes.White;
            }

            if (liquidityText != null)
            {
                liquidityText.Text = "NONE";
                liquidityText.Foreground = Brushes.Gray;
            }

            if (structureText != null)
            {
                structureText.Text = "WAITING";
                structureText.Foreground = Brushes.Goldenrod;
            }

            if (momentumText != null)
            {
                momentumText.Text = "WAITING";
                momentumText.Foreground = Brushes.Goldenrod;
            }

            if (confirmationText != null)
            {
                confirmationText.Text = "WAITING";
                confirmationText.Foreground = Brushes.Gray;
            }

            if (
                signalText != null &&
                !botRunning
            )
            {
                signalText.Text =
                    "WAITING";

                signalText.Foreground =
                    Brushes.White;
            }
        }

        // =====================================================
        // BACKGROUND MODE
        // =====================================================
        // Clicking X hides only the control panel. The bot engine,
        // BarsRequests, telemetry and remote command polling continue.
        private void OnBotWindowClosing(
            object sender,
            CancelEventArgs e)
        {
            if (allowPermanentClose)
            {
                return;
            }

            e.Cancel = true;

            Hide();

            PrintBotMessage(
                "CONTROL PANEL HIDDEN"
                + " | Bot engine remains active in background."
            );

            PublishPlatformTelemetry();
        }

        public void RequestPermanentClose()
        {
            if (!engineWindowAlive)
            {
                return;
            }

            allowPermanentClose = true;

            try
            {
                if (Dispatcher.CheckAccess())
                {
                    Close();
                }
                else
                {
                    Dispatcher.Invoke(
                        new Action(() =>
                        {
                            Close();
                        })
                    );
                }
            }
            catch
            {
            }
        }

        // =====================================================
        // WINDOW CLEANUP
        // =====================================================
       private void OnBotWindowClosed(
    object sender,
    EventArgs e)
{
            engineWindowAlive = false;

            StopPlatformTelemetry();
            StopPlatformCommandPolling();

    botRunning = false;

    ReleaseRuntimeLease();

    currentSignalState =
        "WINDOW CLOSED";

    currentSetupState =
        "STOPPED";

    // Save persistent counters BEFORE destroying
    // the Account + Instrument bridge.
    SavePersistentDailyState();

    // Remove the exact shared snapshot instead of
    // leaving a permanent STOPPED bot on the chart.
    if (
        selectedAccount != null &&
        selectedInstrument != null
    )
    {
        JJBotSharedState.RemoveSnapshot(
            selectedAccount.Name,
            selectedInstrument.FullName
        );
    }

    StopBarsEngine();
    UnsubscribeExecutionAccount();

            if (accountSelector != null)
            {
                accountSelector.SelectionChanged -=
                    AccountSelectorChanged;

                accountSelector.Cleanup();
                accountSelector = null;
            }

            if (instrumentSelector != null)
            {
                instrumentSelector.InstrumentChanged -=
                    InstrumentSelectorChanged;

                instrumentSelector.Cleanup();
                instrumentSelector = null;
            }

            if (startButton != null)
            {
                startButton.Click -=
                    StartBotClicked;
            }

            if (stopButton != null)
            {
                stopButton.Click -=
                    StopBotClicked;
            }

            if (closeAllButton != null)
            {
                closeAllButton.Click -=
                    CloseAllClicked;
            }

            if (testLongButton != null)
            {
                testLongButton.Click -=
                    TestLongClicked;
            }

            if (testShortButton != null)
            {
                testShortButton.Click -=
                    TestShortClicked;
            }

            if (clearLogButton != null)
            {
                clearLogButton.Click -=
                    ClearVisualLogClicked;
            }

            Closing -=
                OnBotWindowClosing;

            Closed -=
                OnBotWindowClosed;
        }

        // =====================================================
        // INVALID VALUE MESSAGE
        // =====================================================
        private void ShowInvalidValue(
            string message)
        {
            MessageBox.Show(
                message,
                "J&J Trading Bot",
                MessageBoxButton.OK,
                MessageBoxImage.Warning
            );
        }

        // =====================================================
        // PRICE FORMAT
        // =====================================================
        private string FormatPrice(
            double price)
        {
            if (
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
            )
            {
                try
                {
                    return selectedInstrument
                        .MasterInstrument
                        .FormatPrice(
                            price
                        );
                }
                catch
                {
                }
            }

            return price.ToString(
                "0.00"
            );
        }

        // =====================================================
        // OUTPUT
        // =====================================================
        // =====================================================
        // PUBLISH REAL ADDON STATE TO JJBotChart
        // =====================================================
        private void PublishSharedState()
        {
            string position;
            int localTradesToday;
            int localAmTrades;
            int localPmTrades;
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;
            bool localDailyLocked;
            int localEntryQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            bool localDailyTargetProtectionArmed;
            bool localMomentumTrailingActive;
            int localMomentumTrailingStage;

            lock (executionStateLock)
            {
                position =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? "LONG"
                        : entryMarketPosition ==
                            MarketPosition.Short
                            ? "SHORT"
                            : "FLAT";

                localTradesToday =
                    tradesToday;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;

                localDailyLocked =
                    persistentDailyLocked;

                localEntryQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localDailyTargetProtectionArmed =
                    dailyTargetProtectionArmed;

                localMomentumTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localMomentumTrailingStage =
                    momentumTrailingStage;
            }

            string h4Trend =
                "WAITING";

            string h1Trend =
                "WAITING";

            string htfContextBias =
                "NEUTRAL 0/2";

            string m5Trend =
                "WAITING";

            string m5VwapSide =
                "WAITING";

            string m5Liquidity =
                "NONE";

            string m5Structure =
                "WAITING";

            string rangeMomentum =
                "WAITING RANGE";

            int rangeLongScore = 0;
            int rangeShortScore = 0;

            DateTime sessionReferenceNy =
                ConvertToNewYorkTime(
                    DateTime.Now
                );

            lock (marketContextLock)
            {
                h4Trend =
                    latestH4Trend
                    ?? "WAITING";

                h1Trend =
                    latestH1Trend
                    ?? "WAITING";

                htfContextBias =
                    latestHtfContextBias
                    ?? "NEUTRAL 0/2";

                if (latestM5ContextReady)
                {
                    m5Trend =
                        latestM5BullishTrend
                            ? "BULLISH"
                            : latestM5BearishTrend
                                ? "BEARISH"
                                : "NEUTRAL";

                    m5VwapSide =
                        latestM5AboveVwap
                            ? "ABOVE VWAP"
                            : latestM5BelowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                    m5Liquidity =
                        latestM5LiquidityState
                        ?? "NONE";

                    m5Structure =
                        latestM5StructureState
                        ?? "WAITING";

                    if (
                        latestM5DecisionNyTime !=
                            DateTime.MinValue
                    )
                    {
                        sessionReferenceNy =
                            latestM5DecisionNyTime;
                    }
                }

                rangeMomentum =
                    latestRangeMomentumState
                    ?? "WAITING RANGE";

                rangeLongScore =
                    latestRangeLongScore;

                rangeShortScore =
                    latestRangeShortScore;
            }

            int learningPatterns = 0;
            int learningTrades = 0;

            if (
                learningMemory != null &&
                learningMemory.Patterns != null
            )
            {
                learningPatterns =
                    learningMemory.Patterns.Count;

                foreach (
                    JJBotLearningPattern pattern
                    in learningMemory.Patterns
                )
                {
                    if (pattern != null)
                    {
                        learningTrades +=
                            pattern.Trades;
                    }
                }
            }

            string trailingState =
                "OFF";

            if (localDailyTargetProtectionArmed)
            {
                trailingState =
                    "DAILY TARGET TRAIL";
            }
            else if (localMomentumTrailingActive)
            {
                trailingState =
                    localMomentumTrailingStage == 0
                        ? "ARMED"
                        : localMomentumTrailingStage == 1
                            ? "BREAK EVEN"
                            : localMomentumTrailingStage == 2
                                ? "LOCK +"
                                    + MomentumLockProfitTicks
                                    + "t"
                                : "TRAIL "
                                    + MomentumTrailDistanceTicks
                                    + "t";
            }

            JJBotSharedState.Update(
                botRunning,
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty,
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty,
                localTradesToday,
                activeMaxTrades,
                localAmTrades,
                localPmTrades,
                localRealizedPnL,
                localUnrealizedPnL,
                totalPnL,
                localDailyLocked,
                position,
                localEntryQuantity,
                localEntryPrice,
                localStopPrice,
                localTargetPrice,
                localExecutionStatus,
                currentSignalState,
                currentSetupState,
                activeStrategyMode,
                GetBotSessionWindow(
                    sessionReferenceNy
                ),
                h4Trend,
                h1Trend,
                htfContextBias,
                m5Trend,
                m5VwapSide,
                m5Liquidity,
                m5Structure,
                rangeMomentum,
                rangeLongScore,
                rangeShortScore,
                true,
                learningPatterns,
                learningTrades,
                trailingState
            );
        }

        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        private void LoadPlatformBridgeConfig()
        {
            try
            {
                platformConfigFile =
                    Path.Combine(
                        Environment.GetFolderPath(
                            Environment.SpecialFolder.MyDocuments
                        ),
                        "J&J Company Bro",
                        "config.json"
                    );

                if (
                    !File.Exists(
                        platformConfigFile
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: config.json not found at "
                        + platformConfigFile
                    );

                    return;
                }

                string json =
                    File.ReadAllText(
                        platformConfigFile
                    );

                string loadedApiKey =
                    ExtractJsonStringValue(
                        json,
                        "apiKey"
                    );

                string loadedServerUrl =
                    ExtractJsonStringValue(
                        json,
                        "serverUrl"
                    );

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedApiKey
                    )
                )
                {
                    platformApiKey =
                        loadedApiKey.Trim();
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedServerUrl
                    )
                )
                {
                    platformServerUrl =
                        loadedServerUrl
                            .Trim()
                            .TrimEnd('/');
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformServerUrl
                    )
                )
                {
                    platformServerUrl =
                        "http://localhost:3001";
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: apiKey missing in config.json"
                    );
                }
                else
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE READY"
                    );
                }
            }
            catch (Exception ex)
            {
                platformApiKey =
                    string.Empty;

                platformServerUrl =
                    "http://localhost:3001";

                PrintBotMessage(
                    "PLATFORM BRIDGE CONFIG ERROR: "
                    + ex.Message
                );
            }
        }

        private string ExtractJsonStringValue(
            string json,
            string propertyName)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return string.Empty;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*\\\"(?<value>(?:\\\\.|[^\\\"])*)\\\"";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                if (
                    !match.Success
                )
                {
                    return string.Empty;
                }

                string value =
                    match.Groups["value"].Value;

                return
                    value
                        .Replace("\\\\", "\\")
                        .Replace("\\\"", "\"")
                        .Replace("\\r", "\r")
                        .Replace("\\n", "\n")
                        .Replace("\\t", "\t");
            }
            catch
            {
                return string.Empty;
            }
        }

        private int ExtractJsonIntValue(
            string json,
            string propertyName,
            int fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                int value;

                if (
                    match.Success &&
                    int.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }

        private double ExtractJsonDoubleValue(
            string json,
            string propertyName,
            double fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+(?:\\.[0-9]+)?)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                double value;

                if (
                    match.Success &&
                    double.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }

        private void StartPlatformTelemetry()
        {
            if (
                platformTelemetryTimer != null
            )
            {
                return;
            }

            platformTelemetryTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformTelemetryTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformTelemetryIntervalSeconds
                );

            platformTelemetryTimer.Tick +=
                PlatformTelemetryTimerTick;

            platformTelemetryTimer.Start();

            // Send once immediately so the platform does not
            // have to wait for the first timer interval.
            PublishPlatformTelemetry();
        }

        private void StopPlatformTelemetry()
        {
            DispatcherTimer timer =
                platformTelemetryTimer;

            platformTelemetryTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformTelemetryTimerTick;
            }
            catch
            {
            }
        }

        private void PlatformTelemetryTimerTick(
            object sender,
            EventArgs e)
        {
            PublishPlatformTelemetry();
        }

        private void PublishPlatformTelemetry()
        {
            if (
                platformTelemetryRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                // The main J&J Company Bro AddOn may have
                // created config.json after this bot window
                // was opened. Retry loading it automatically.
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                PublishSharedState();

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : string.Empty;

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : string.Empty;

                JJBotSharedSnapshot snapshot =
                    JJBotSharedState.GetSnapshot(
                        accountName,
                        instrumentName
                    );

                string direction =
                    GetTelemetryDirection();

                string strategy =
                    GetTelemetryStrategy();

                int contracts =
                    botRunning
                        ? activeContracts
                        : GetTelemetryIntFromTextBox(
                            contractsBox,
                            activeContracts
                        );

                int stopTicks =
                    botRunning
                        ? activeStopTicks
                        : GetTelemetryIntFromTextBox(
                            stopBox,
                            activeStopTicks
                        );

                int targetTicks =
                    botRunning
                        ? activeTargetTicks
                        : GetTelemetryIntFromTextBox(
                            targetBox,
                            activeTargetTicks
                        );

                int maxTrades =
                    botRunning
                        ? activeMaxTrades
                        : GetTelemetryIntFromTextBox(
                            maxTradesBox,
                            activeMaxTrades
                        );

                double dailyTarget =
                    botRunning
                        ? activeDailyTarget
                        : GetTelemetryDoubleFromTextBox(
                            dailyTargetBox,
                            activeDailyTarget
                        );

                double dailyLoss =
                    botRunning
                        ? activeDailyLoss
                        : GetTelemetryDoubleFromTextBox(
                            dailyLossBox,
                            activeDailyLoss
                        );

                string json =
                    BuildPlatformTelemetryJson(
                        snapshot,
                        accountName,
                        instrumentName,
                        direction,
                        strategy,
                        contracts,
                        stopTicks,
                        targetTicks,
                        maxTrades,
                        dailyTarget,
                        dailyLoss
                    );

                string endpoint =
                    platformServerUrl
                        .TrimEnd('/')
                    + "/api/bot/state";

                platformTelemetryRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        SendPlatformTelemetryRequest(
                            endpoint,
                            json
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformTelemetryRequestInFlight =
                    false;

                PrintBotMessage(
                    "PLATFORM TELEMETRY BUILD ERROR: "
                    + ex.Message
                );
            }
        }

        private string GetTelemetryDirection()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeDirection
                )
            )
            {
                return activeDirection;
            }

            if (
                directionCombo != null &&
                directionCombo.SelectedItem != null
            )
            {
                return
                    directionCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeDirection
                )
                    ? "BOTH"
                    : activeDirection;
        }

        private string GetTelemetryStrategy()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
            )
            {
                return activeStrategyMode;
            }

            if (
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
            )
            {
                return
                    strategyCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
                    ? "HYBRID"
                    : activeStrategyMode;
        }

        private int GetTelemetryIntFromTextBox(
            TextBox box,
            int fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            int value;

            if (
                int.TryParse(
                    box.Text,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }

        private double GetTelemetryDoubleFromTextBox(
            TextBox box,
            double fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            double value;

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.CurrentCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }

        private string[] GetPlatformAvailableInstruments()
        {
            List<string> names =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            DateTime now =
                DateTime.Now.Date;

            DateTime minimumExpiry =
                now.AddDays(-45);

            DateTime maximumExpiry =
                now.AddMonths(18);

            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string fullName =
                        instrument.FullName;

                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        continue;
                    }

                    DateTime expiry =
                        instrument.Expiry;

                    if (
                        expiry != DateTime.MinValue &&
                        (
                            expiry.Date < minimumExpiry ||
                            expiry.Date > maximumExpiry
                        )
                    )
                    {
                        continue;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        names.Add(
                            fullName
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "INSTRUMENT LIST ERROR: "
                    + ex.Message
                );
            }

            if (
                selectedInstrument != null &&
                !string.IsNullOrWhiteSpace(
                    selectedInstrument.FullName
                ) &&
                seen.Add(
                    selectedInstrument.FullName
                )
            )
            {
                names.Add(
                    selectedInstrument.FullName
                );
            }

            names.Sort(
                StringComparer.OrdinalIgnoreCase
            );

            if (
                names.Count > 300
            )
            {
                names =
                    names.GetRange(
                        0,
                        300
                    );
            }

            return names.ToArray();
        }

        private void AppendJsonStringArrayProperty(
            StringBuilder builder,
            string name,
            string[] values,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":[");

            bool first =
                true;

            if (values != null)
            {
                for (
                    int i = 0;
                    i < values.Length;
                    i++
                )
                {
                    string value =
                        values[i];

                    if (
                        string.IsNullOrWhiteSpace(
                            value
                        )
                    )
                    {
                        continue;
                    }

                    if (!first)
                    {
                        builder.Append(",");
                    }

                    AppendJsonString(
                        builder,
                        value
                    );

                    first =
                        false;
                }
            }

            builder.Append("]");
        }

        private string BuildPlatformTelemetryJson(
            JJBotSharedSnapshot snapshot,
            string accountName,
            string instrumentName,
            string direction,
            string strategy,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss)
        {
            bool running =
                snapshot != null
                    ? snapshot.IsRunning
                    : botRunning;

            int trades =
                snapshot != null
                    ? snapshot.TradesToday
                    : tradesToday;

            double dailyPnl =
                snapshot != null
                    ? snapshot.RealizedPnL
                    : botDailyPnL;

            string position =
                snapshot != null
                    ? snapshot.Position
                    : "FLAT";

            int positionQty =
                snapshot != null
                    ? snapshot.PositionQty
                    : 0;

            double entryPrice =
                snapshot != null
                    ? snapshot.EntryPrice
                    : 0;

            string trend =
                snapshot != null
                    ? snapshot.M5Trend
                    : "WAITING";

            string vwap =
                snapshot != null
                    ? snapshot.M5VwapSide
                    : "WAITING";

            string liquidity =
                snapshot != null
                    ? snapshot.M5Liquidity
                    : "NONE";

            string structure =
                snapshot != null
                    ? snapshot.M5Structure
                    : "WAITING";

            int rangeLong =
                snapshot != null
                    ? snapshot.RangeLongScore
                    : latestRangeLongScore;

            int rangeShort =
                snapshot != null
                    ? snapshot.RangeShortScore
                    : latestRangeShortScore;

            string currentSignal =
                snapshot != null
                    ? snapshot.Signal
                    : currentSignalState;

            string setup =
                snapshot != null
                    ? snapshot.Setup
                    : currentSetupState;

            bool learningActive =
                snapshot != null
                    ? snapshot.LearningActive
                    : true;

            string learningStatus =
                learningActive
                    ? "ACTIVE"
                    : "OFF";

            string[] logLines =
                visualLogLines != null
                    ? visualLogLines.ToArray()
                    : new string[0];

            int logStart =
                Math.Max(
                    0,
                    logLines.Length - 30
                );

            StringBuilder builder =
                new StringBuilder();

            builder.Append("{");
            builder.Append("\"apiKey\":");
            AppendJsonString(
                builder,
                platformApiKey
            );
            builder.Append(",\"state\":{");

            AppendJsonProperty(
                builder,
                "running",
                running
                    ? "true"
                    : "false",
                false
            );

            AppendJsonStringProperty(
                builder,
                "account",
                accountName,
                true
            );

            AppendJsonStringProperty(
                builder,
                "instrument",
                instrumentName,
                true
            );

            AppendJsonStringArrayProperty(
                builder,
                "availableInstruments",
                GetPlatformAvailableInstruments(),
                true
            );

            AppendJsonStringProperty(
                builder,
                "strategy",
                strategy,
                true
            );

            AppendJsonStringProperty(
                builder,
                "direction",
                direction,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "contracts",
                contracts,
                true
            );

            AppendJsonStringProperty(
                builder,
                "trendM5",
                trend,
                true
            );

            AppendJsonStringProperty(
                builder,
                "vwap",
                vwap,
                true
            );

            AppendJsonStringProperty(
                builder,
                "liquidity",
                liquidity,
                true
            );

            AppendJsonStringProperty(
                builder,
                "structure",
                structure,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeLongScore",
                rangeLong,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeShortScore",
                rangeShort,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeScoreMax",
                5,
                true
            );

            AppendJsonStringProperty(
                builder,
                "currentSignal",
                currentSignal,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setup",
                setup,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "stopTicks",
                stopTicks,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "targetTicks",
                targetTicks,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyTarget",
                dailyTarget,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyLoss",
                dailyLoss,
                true
            );

            AppendJsonStringProperty(
                builder,
                "learningStatus",
                learningStatus,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyPnl",
                dailyPnl,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "tradesThisSession",
                trades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "maxTradesPerSession",
                maxTrades,
                true
            );

            AppendJsonStringProperty(
                builder,
                "position",
                position,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "positionQuantity",
                positionQty,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "averageEntryPrice",
                entryPrice,
                true
            );

            AppendJsonStringProperty(
                builder,
                "addonVersion",
                PlatformBridgeVersion,
                true
            );

            AppendJsonStringProperty(
                builder,
                "engineVersion",
                "LEARNING V3",
                true
            );

            builder.Append(",\"logs\":[");

            bool firstLog = true;

            for (
                int i = logStart;
                i < logLines.Length;
                i++
            )
            {
                if (!firstLog)
                {
                    builder.Append(",");
                }

                AppendJsonString(
                    builder,
                    logLines[i]
                );

                firstLog = false;
            }

            builder.Append("]");
            builder.Append("}}");

            return builder.ToString();
        }

        private void AppendJsonProperty(
            StringBuilder builder,
            string name,
            string rawValue,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");
            builder.Append(rawValue);
        }

        private void AppendJsonStringProperty(
            StringBuilder builder,
            string name,
            string value,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");

            AppendJsonString(
                builder,
                value
            );
        }

        private void AppendJsonNumberProperty(
            StringBuilder builder,
            string name,
            int value,
            bool prependComma)
        {
            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }

        private void AppendJsonDoubleProperty(
            StringBuilder builder,
            string name,
            double value,
            bool prependComma)
        {
            if (
                double.IsNaN(value) ||
                double.IsInfinity(value)
            )
            {
                value = 0;
            }

            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    "0.########",
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }

        private void AppendJsonString(
            StringBuilder builder,
            string value)
        {
            builder.Append("\"");

            string text =
                value ?? string.Empty;

            for (
                int i = 0;
                i < text.Length;
                i++
            )
            {
                char c =
                    text[i];

                switch (c)
                {
                    case '\\':
                        builder.Append("\\\\");
                        break;

                    case '"':
                        builder.Append("\\\"");
                        break;

                    case '\r':
                        builder.Append("\\r");
                        break;

                    case '\n':
                        builder.Append("\\n");
                        break;

                    case '\t':
                        builder.Append("\\t");
                        break;

                    default:
                        if (c < 32)
                        {
                            builder.Append(
                                "\\u"
                                + ((int)c).ToString(
                                    "x4"
                                )
                            );
                        }
                        else
                        {
                            builder.Append(c);
                        }
                        break;
                }
            }

            builder.Append("\"");
        }

        private void SendPlatformTelemetryRequest(
            string endpoint,
            string json)
        {
            try
            {
                byte[] body =
                    Encoding.UTF8.GetBytes(
                        json
                    );

                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "POST";

                request.ContentType =
                    "application/json";

                request.ContentLength =
                    body.Length;

                request.Timeout =
                    2500;

                request.ReadWriteTimeout =
                    2500;

                using (
                    Stream requestStream =
                        request.GetRequestStream()
                )
                {
                    requestStream.Write(
                        body,
                        0,
                        body.Length
                    );
                }

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                {
                    int statusCode =
                        (int)response.StatusCode;

                    if (
                        statusCode >= 200 &&
                        statusCode < 300
                    )
                    {
                        lastPlatformTelemetrySuccessUtc =
                            DateTime.UtcNow;
                    }
                }
            }
            catch (WebException ex)
            {
                // Do not spam the visual log every 3 seconds.
                // Only emit a message if the platform bridge had
                // previously been healthy.
                if (
                    lastPlatformTelemetrySuccessUtc !=
                        DateTime.MinValue
                )
                {
                    DateTime lastSuccess =
                        lastPlatformTelemetrySuccessUtc;

                    lastPlatformTelemetrySuccessUtc =
                        DateTime.MinValue;

                    Dispatcher.BeginInvoke(
                        new Action(
                            delegate
                            {
                                AppendVisualLog(
                                    "PLATFORM TELEMETRY OFFLINE: "
                                    + ex.Message
                                );
                            }
                        )
                    );
                }
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "PLATFORM TELEMETRY ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformTelemetryRequestInFlight =
                    false;
            }
        }

        // =====================================================
        // J&J COMPANY BRO - REMOTE BOT COMMANDS
        // =====================================================
        private void StartPlatformCommandPolling()
        {
            if (
                platformCommandTimer != null
            )
            {
                return;
            }

            platformCommandTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformCommandTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformCommandIntervalSeconds
                );

            platformCommandTimer.Tick +=
                PlatformCommandTimerTick;

            platformCommandTimer.Start();
        }

        private void StopPlatformCommandPolling()
        {
            DispatcherTimer timer =
                platformCommandTimer;

            platformCommandTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformCommandTimerTick;
            }
            catch
            {
            }
        }

        private void PlatformCommandTimerTick(
            object sender,
            EventArgs e)
        {
            PollPlatformCommand();
        }

        private void PollPlatformCommand()
        {
            if (
                platformCommandRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                string endpoint =
                    platformServerUrl
                        .TrimEnd('/')
                    + "/api/bot/commands?apiKey="
                    + Uri.EscapeDataString(
                        platformApiKey
                    );

                platformCommandRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        ReadPlatformCommandRequest(
                            endpoint
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformCommandRequestInFlight =
                    false;

                AppendVisualLog(
                    "BOT COMMAND POLL ERROR: "
                    + ex.Message
                );
            }
        }

        private void ReadPlatformCommandRequest(
            string endpoint)
        {
            string responseText =
                string.Empty;

            try
            {
                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "GET";

                request.Accept =
                    "application/json";

                request.Timeout =
                    2000;

                request.ReadWriteTimeout =
                    2000;

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                using (
                    Stream stream =
                        response.GetResponseStream()
                )
                using (
                    StreamReader reader =
                        new StreamReader(
                            stream,
                            Encoding.UTF8
                        )
                )
                {
                    responseText =
                        reader.ReadToEnd();
                }

                if (
                    string.IsNullOrWhiteSpace(
                        responseText
                    ) ||
                    responseText.Trim() == "[]"
                )
                {
                    return;
                }

                string commandId =
                    ExtractJsonStringValue(
                        responseText,
                        "id"
                    );

                string commandType =
                    ExtractJsonStringValue(
                        responseText,
                        "type"
                    )
                        .Trim()
                        .ToUpperInvariant();

                string commandAccount =
                    ExtractJsonStringValue(
                        responseText,
                        "account"
                    );

                string commandInstrument =
                    ExtractJsonStringValue(
                        responseText,
                        "instrument"
                    );

                string commandQuery =
                    ExtractJsonStringValue(
                        responseText,
                        "query"
                    );

                string commandStrategy =
                    ExtractJsonStringValue(
                        responseText,
                        "strategy"
                    );

                string commandDirection =
                    ExtractJsonStringValue(
                        responseText,
                        "direction"
                    );

                int commandContracts =
                    ExtractJsonIntValue(
                        responseText,
                        "contracts",
                        1
                    );

                int commandStopTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "stopTicks",
                        100
                    );

                int commandTargetTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "targetTicks",
                        150
                    );

                int commandMaxTrades =
                    ExtractJsonIntValue(
                        responseText,
                        "maxTradesPerSession",
                        2
                    );

                double commandDailyTarget =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyTarget",
                        300
                    );

                double commandDailyLoss =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyLoss",
                        200
                    );

                if (
                    string.IsNullOrWhiteSpace(
                        commandId
                    ) ||
                    string.IsNullOrWhiteSpace(
                        commandType
                    )
                )
                {
                    return;
                }

                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            ExecutePlatformCommand(
                                commandId,
                                commandType,
                                commandAccount,
                                commandInstrument,
                                commandQuery,
                                commandStrategy,
                                commandDirection,
                                commandContracts,
                                commandStopTicks,
                                commandTargetTicks,
                                commandMaxTrades,
                                commandDailyTarget,
                                commandDailyLoss
                            );
                        }
                    )
                );
            }
            catch (WebException)
            {
                // Backend may be restarting. Telemetry heartbeat already
                // exposes the disconnected state, so do not spam the log.
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "BOT COMMAND ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformCommandRequestInFlight =
                    false;
            }
        }

        private string[] SearchNinjaInstruments(
            string query)
        {
            string normalizedQuery =
                (query ?? string.Empty)
                    .Trim();

            if (
                string.IsNullOrWhiteSpace(
                    normalizedQuery
                )
            )
            {
                return new string[0];
            }

            string upperQuery =
                normalizedQuery
                    .ToUpperInvariant();

            string masterQuery =
                upperQuery
                    .Split(
                        new char[]
                        {
                            ' ',
                            '\t'
                        },
                        StringSplitOptions
                            .RemoveEmptyEntries
                    )
                    .FirstOrDefault()
                ?? upperQuery;

            List<string> results =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            Action<string> addMatch =
                delegate(
                    string fullName)
                {
                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        return;
                    }

                    if (
                        fullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0 &&
                        fullName.IndexOf(
                            masterQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0
                    )
                    {
                        return;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        results.Add(
                            fullName
                        );
                    }
                };

            // 1) Search instruments already materialized in NinjaTrader.
            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string masterName =
                        instrument
                            .MasterInstrument
                            .Name
                        ?? string.Empty;

                    string description =
                        instrument
                            .MasterInstrument
                            .Description
                        ?? string.Empty;

                    if (
                        instrument.FullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        masterName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        description.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0
                    )
                    {
                        addMatch(
                            instrument.FullName
                        );
                    }
                }
            }
            catch
            {
            }

            // 2) Ask NinjaTrader for the master instrument directly.
            //    This is the important path for symbols such as MNQ that
            //    may not yet exist in Instrument.All for this session.
            try
            {
                Instrument masterInstrument =
                    Instrument.GetInstrument(
                        masterQuery
                    );

                if (
                    masterInstrument != null &&
                    masterInstrument.MasterInstrument != null &&
                    masterInstrument
                        .MasterInstrument
                        .InstrumentType ==
                    InstrumentType.Future
                )
                {
                    DateTime minimumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(-3);

                    DateTime maximumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(24);

                    foreach (
                        var rollover
                        in masterInstrument
                            .MasterInstrument
                            .RolloverCollection
                    )
                    {
                        DateTime contractMonth =
                            rollover.ContractMonth;

                        if (
                            contractMonth <
                                minimumMonth ||
                            contractMonth >
                                maximumMonth
                        )
                        {
                            continue;
                        }

                        string candidate =
                            masterInstrument
                                .MasterInstrument
                                .Name
                            + " "
                            + contractMonth
                                .ToString(
                                    "MM-yy",
                                    CultureInfo.InvariantCulture
                                );

                        Instrument contract =
                            Instrument.GetInstrument(
                                candidate
                            );

                        if (
                            contract != null
                        )
                        {
                            addMatch(
                                contract.FullName
                            );
                        }
                    }
                }
            }
            catch
            {
            }

            results =
                results
                    .OrderBy(
                        value =>
                            value.StartsWith(
                                masterQuery,
                                StringComparison.OrdinalIgnoreCase
                            )
                                ? 0
                                : 1
                    )
                    .ThenBy(
                        value =>
                            value,
                        StringComparer.OrdinalIgnoreCase
                    )
                    .Take(120)
                    .ToList();

            return results.ToArray();
        }

        private void PostPlatformInstrumentSearchResult(
            string requestId,
            string query,
            string[] instruments)
        {
            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                return;
            }

            string endpoint =
                platformServerUrl
                    .TrimEnd('/')
                + "/api/bot/instruments/search-result";

            StringBuilder searchJson =
                new StringBuilder();

            searchJson.Append("{");

            AppendJsonStringProperty(
                searchJson,
                "apiKey",
                platformApiKey,
                false
            );

            AppendJsonStringProperty(
                searchJson,
                "requestId",
                requestId,
                true
            );

            AppendJsonStringProperty(
                searchJson,
                "query",
                query,
                true
            );

            AppendJsonStringArrayProperty(
                searchJson,
                "instruments",
                instruments,
                true
            );

            searchJson.Append("}");

            string payload =
                searchJson.ToString();

            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    try
                    {
                        byte[] bytes =
                            Encoding.UTF8
                                .GetBytes(
                                    payload
                                );

                        HttpWebRequest request =
                            (HttpWebRequest)
                            WebRequest.Create(
                                endpoint
                            );

                        request.Method =
                            "POST";

                        request.ContentType =
                            "application/json";

                        request.Timeout =
                            2500;

                        request.ReadWriteTimeout =
                            2500;

                        request.ContentLength =
                            bytes.Length;

                        using (
                            Stream requestStream =
                                request.GetRequestStream()
                        )
                        {
                            requestStream.Write(
                                bytes,
                                0,
                                bytes.Length
                            );
                        }

                        using (
                            HttpWebResponse response =
                                (HttpWebResponse)
                                request.GetResponse()
                        )
                        {
                        }
                    }
                    catch
                    {
                    }
                }
            );
        }

        private bool ApplyPlatformStartConfiguration(
            string accountName,
            string instrumentName,
            string strategy,
            string direction,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss)
        {
            Account resolvedAccount =
                null;

            try
            {
                resolvedAccount =
                    Account.All.FirstOrDefault(
                        account =>
                            account != null &&
                            string.Equals(
                                account.Name,
                                accountName,
                                StringComparison.OrdinalIgnoreCase
                            )
                    );
            }
            catch
            {
            }

            if (resolvedAccount == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Account not found: "
                    + accountName
                );

                return false;
            }

            if (
                !IsSimulationAccount(
                    resolvedAccount
                )
            )
            {
                AppendVisualLog(
                    "REMOTE START BLOCKED | LIVE ACCOUNT: "
                    + resolvedAccount.Name
                );

                return false;
            }

            Instrument resolvedInstrument =
                null;

            try
            {
                resolvedInstrument =
                    Instrument.GetInstrument(
                        instrumentName
                    );
            }
            catch
            {
            }

            if (resolvedInstrument == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Instrument not found: "
                    + instrumentName
                );

                return false;
            }

            selectedAccount =
                resolvedAccount;

            selectedInstrument =
                resolvedInstrument;

            if (accountStatusText != null)
            {
                accountStatusText.Text =
                    "Account: "
                    + selectedAccount.Name;

                accountStatusText.Foreground =
                    Brushes.LightGreen;
            }

            if (instrumentStatusText != null)
            {
                instrumentStatusText.Text =
                    "Instrument: "
                    + selectedInstrument.FullName;

                instrumentStatusText.Foreground =
                    Brushes.LightGreen;
            }

            // InstrumentSelector.Instrument is a writable property in
            // NinjaTrader. Keep its UI synchronized when the hidden
            // control panel is later opened.
            if (instrumentSelector != null)
            {
                try
                {
                    instrumentSelector.Instrument =
                        resolvedInstrument;
                }
                catch
                {
                }
            }

            string normalizedStrategy =
                string.IsNullOrWhiteSpace(
                    strategy
                )
                    ? "HYBRID"
                    : strategy
                        .Trim()
                        .ToUpperInvariant();

            string normalizedDirection =
                string.IsNullOrWhiteSpace(
                    direction
                )
                    ? "BOTH"
                    : direction
                        .Trim()
                        .ToUpperInvariant();

            if (
                strategyCombo != null &&
                strategyCombo.Items.Contains(
                    normalizedStrategy
                )
            )
            {
                strategyCombo.SelectedItem =
                    normalizedStrategy;
            }

            if (
                directionCombo != null &&
                directionCombo.Items.Contains(
                    normalizedDirection
                )
            )
            {
                directionCombo.SelectedItem =
                    normalizedDirection;
            }

            if (contractsBox != null)
                contractsBox.Text =
                    contracts.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (stopBox != null)
                stopBox.Text =
                    stopTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (targetBox != null)
                targetBox.Text =
                    targetTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (maxTradesBox != null)
                maxTradesBox.Text =
                    maxTrades.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyTargetBox != null)
                dailyTargetBox.Text =
                    dailyTarget.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyLossBox != null)
                dailyLossBox.Text =
                    dailyLoss.ToString(
                        CultureInfo.InvariantCulture
                    );

            AppendVisualLog(
                "REMOTE CONFIG APPLIED | "
                + selectedAccount.Name
                + " | "
                + selectedInstrument.FullName
                + " | "
                + normalizedStrategy
                + " | "
                + normalizedDirection
                + " | Qty "
                + contracts
                + " | SL "
                + stopTicks
                + " | TP "
                + targetTicks
            );

            return true;
        }

        private void ExecutePlatformCommand(
            string commandId,
            string commandType,
            string commandAccount,
            string commandInstrument,
            string commandQuery,
            string commandStrategy,
            string commandDirection,
            int commandContracts,
            int commandStopTicks,
            int commandTargetTicks,
            int commandMaxTrades,
            double commandDailyTarget,
            double commandDailyLoss)
        {
            if (
                string.IsNullOrWhiteSpace(
                    commandId
                ) ||
                string.Equals(
                    commandId,
                    lastProcessedPlatformCommandId,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return;
            }

            lastProcessedPlatformCommandId =
                commandId;

            if (
                string.Equals(
                    commandType,
                    "SEARCH_INSTRUMENTS",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                string[] searchResults =
                    SearchNinjaInstruments(
                        commandQuery
                    );

                PostPlatformInstrumentSearchResult(
                    commandId,
                    commandQuery,
                    searchResults
                );

                return;
            }

            bool commandNeedsPlatformContext =
                string.Equals(
                    commandType,
                    "START_BOT",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_LONG",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_SHORT",
                    StringComparison.OrdinalIgnoreCase
                );

            if (commandNeedsPlatformContext)
            {
                if (
                    !ApplyPlatformStartConfiguration(
                        commandAccount,
                        commandInstrument,
                        commandStrategy,
                        commandDirection,
                        commandContracts,
                        commandStopTicks,
                        commandTargetTicks,
                        commandMaxTrades,
                        commandDailyTarget,
                        commandDailyLoss
                    )
                )
                {
                    return;
                }
            }

            string selectedAccountName =
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty;

            string selectedInstrumentName =
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty;

            // STOP is allowed even if the selector has changed.
            // Every other command must target the exact bot shown
            // in this JJBotWindow.
            if (
                !string.Equals(
                    commandType,
                    "STOP_BOT",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                if (
                    string.IsNullOrWhiteSpace(
                        selectedAccountName
                    ) ||
                    string.IsNullOrWhiteSpace(
                        selectedInstrumentName
                    ) ||
                    !string.Equals(
                        selectedAccountName,
                        commandAccount,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    !string.Equals(
                        selectedInstrumentName,
                        commandInstrument,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    AppendVisualLog(
                        "REMOTE COMMAND REJECTED | "
                        + commandType
                        + " | Target "
                        + commandAccount
                        + " / "
                        + commandInstrument
                        + " does not match selected "
                        + selectedAccountName
                        + " / "
                        + selectedInstrumentName
                    );

                    return;
                }
            }

            AppendVisualLog(
                "REMOTE COMMAND RECEIVED | "
                + commandType
            );

            try
            {
                switch (commandType)
                {
                    case "START_BOT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            StartBotClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "STOP_BOT":
                        StopBotClicked(
                            null,
                            null
                        );
                        break;

                    case "CLOSE_ALL":
                        CloseAllClicked(
                            null,
                            null
                        );
                        break;

                    case "TEST_LONG":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestLongClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "TEST_SHORT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestShortClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    default:
                        AppendVisualLog(
                            "REMOTE COMMAND IGNORED | "
                            + commandType
                        );
                        return;
                }

                PublishSharedState();
                PublishPlatformTelemetry();
            }
            catch (Exception ex)
            {
                AppendVisualLog(
                    "REMOTE COMMAND FAILED | "
                    + commandType
                    + " | "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // LEARNING ENGINE HELPERS
        // =====================================================
        private void CaptureLearningSignalContext(
            string side,
            DateTime signalTimeNy,
            string structure)
        {
            pendingLearningSide =
                side ?? string.Empty;

            pendingLearningSession =
                GetBotSessionWindow(
                    signalTimeNy
                );

            pendingLearningStructure =
                structure ?? "UNKNOWN";

            pendingLearningSignalTimeNy =
                signalTimeNy;
        }

        private string GetLearningPatternKey(
            string side,
            DateTime nyTime,
            string structure)
        {
            // nyTime is intentionally retained in the signature for
            // compatibility with existing callers, but AM/PM no longer
            // fragments the learning bucket.
            return
                (
                    string.IsNullOrWhiteSpace(
                        side
                    )
                        ? "UNKNOWN"
                        : side
                )
                + "|"
                + (
                    string.IsNullOrWhiteSpace(
                        structure
                    )
                        ? "UNKNOWN"
                        : structure
                );
        }

        private JJBotLearningPattern FindLearningPattern(
            string key)
        {
            if (
                learningMemory == null
            )
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            if (
                learningMemory.Patterns == null
            )
            {
                learningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern != null &&
                    string.Equals(
                        pattern.Key,
                        key,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return pattern;
                }
            }

            return null;
        }

        private JJBotLearningPattern BuildSpecificLearningAggregate(
            string side,
            string structure)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE_SPECIFIC";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                "*";

            aggregate.Structure =
                string.IsNullOrWhiteSpace(
                    structure
                )
                    ? "UNKNOWN"
                    : structure;

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                if (
                    !string.Equals(
                        pattern.Side ?? string.Empty,
                        side ?? string.Empty,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.Equals(
                        string.IsNullOrWhiteSpace(
                            pattern.Structure
                        )
                            ? "UNKNOWN"
                            : pattern.Structure,
                        string.IsNullOrWhiteSpace(
                            structure
                        )
                            ? "UNKNOWN"
                            : structure,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;
            }

            return aggregate;
        }

        private JJBotLearningPattern BuildLearningAggregate(
            string side,
            string sessionWindow)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                sessionWindow ?? string.Empty;

            aggregate.Structure =
                "*";

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        side
                    ) &&
                    !string.Equals(
                        pattern.Side,
                        side,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        sessionWindow
                    ) &&
                    !string.Equals(
                        pattern.SessionWindow,
                        sessionWindow,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;
            }

            return aggregate;
        }

        private bool EvaluateLearningEvidence(
            JJBotLearningPattern pattern,
            string level,
            out bool hasEvidence,
            out bool allowed,
            out string reason)
        {
            hasEvidence =
                false;

            allowed =
                true;

            reason =
                level
                + " NO DATA";

            if (
                pattern == null ||
                pattern.Trades <
                    LearningMinTrades
            )
            {
                int sample =
                    pattern != null
                        ? pattern.Trades
                        : 0;

                reason =
                    level
                    + " SAMPLE "
                    + sample
                    + "/"
                    + LearningMinTrades
                    + " - INSUFFICIENT";

                return true;
            }

            hasEvidence =
                true;

            double expectancy =
                pattern.Trades > 0
                    ? pattern.NetPnL
                        / pattern.Trades
                    : 0;

            double winRate =
                pattern.Trades > 0
                    ? (
                        (double)pattern.Wins
                        / pattern.Trades
                    )
                    * 100.0
                    : 0;

            double avgMfe =
                pattern.Trades > 0
                    ? pattern.TotalMfe
                        / pattern.Trades
                    : 0;

            double avgMae =
                pattern.Trades > 0
                    ? pattern.TotalMae
                        / pattern.Trades
                    : 0;

            bool negativeExpectancy =
                expectancy <
                    LearningMinExpectancy;

            bool negativeNetEvidence =
                pattern.NetPnL <
                    LearningMinNetPnL;

            bool winRateTooLow =
                winRate <
                    LearningMinWinRate &&
                expectancy < 0;

            bool expectancyNetBlock =
                negativeExpectancy &&
                negativeNetEvidence;

            allowed =
                !(
                    expectancyNetBlock ||
                    winRateTooLow
                );

            string blockReason =
                expectancyNetBlock
                    ? "NEGATIVE EXPECTANCY + NET"
                    : winRateTooLow
                        ? "LOW WINRATE + NEGATIVE EXPECTANCY"
                        : "EDGE ACCEPTABLE";

            reason =
                level
                + " ACTIVE"
                + " | Trades: "
                + pattern.Trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | WinRate: "
                + winRate.ToString("0.0")
                + "%"
                + " | Expectancy: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | AvgMFE: "
                + avgMfe.ToString("$0.00")
                + " | AvgMAE: "
                + avgMae.ToString("$0.00")
                + " | Rule A: Exp < "
                + LearningMinExpectancy.ToString("$0.00")
                + " & Net < "
                + LearningMinNetPnL.ToString("$0.00")
                + " | Rule B: WinRate < "
                + LearningMinWinRate.ToString("0")
                + "% & Exp < $0"
                + " | Decision: "
                + blockReason
                + " | "
                + (
                    allowed
                        ? "ALLOWED"
                        : "BLOCKED"
                );

            return true;
        }

        private bool IsLearningTradeAllowed(
            string side,
            DateTime nyTime,
            string structure,
            out string reason)
        {
            reason =
                "NO HISTORY - ALLOWED";

            if (
                selectedInstrument == null
            )
            {
                return true;
            }

            if (
                learningMemory == null
            )
            {
                LoadLearningMemory();
            }

            string normalizedSide =
                string.IsNullOrWhiteSpace(
                    side
                )
                    ? "UNKNOWN"
                    : side;

            string normalizedStructure =
                string.IsNullOrWhiteSpace(
                    structure
                )
                    ? "UNKNOWN"
                    : structure;

            // =====================================================
            // HIERARCHICAL DECISION V3
            // =====================================================
            // SPECIFIC is aggregated by Side + Structure across both
            // AM and PM. This also lets old XML keys that contained
            // the session continue contributing to the new bucket.
            JJBotLearningPattern specific =
                BuildSpecificLearningAggregate(
                    normalizedSide,
                    normalizedStructure
                );

            JJBotLearningPattern sideAggregate =
                BuildLearningAggregate(
                    normalizedSide,
                    string.Empty
                );

            JJBotLearningPattern globalAggregate =
                BuildLearningAggregate(
                    string.Empty,
                    string.Empty
                );

            JJBotLearningPattern[] candidates =
                new JJBotLearningPattern[]
                {
                    specific,
                    sideAggregate,
                    globalAggregate
                };

            string[] levels =
                new string[]
                {
                    "SPECIFIC",
                    "SIDE",
                    "GLOBAL"
                };

            for (
                int i = 0;
                i < candidates.Length;
                i++
            )
            {
                bool hasEvidence;
                bool allowed;
                string levelReason;

                EvaluateLearningEvidence(
                    candidates[i],
                    levels[i],
                    out hasEvidence,
                    out allowed,
                    out levelReason
                );

                if (hasEvidence)
                {
                    reason =
                        levelReason;

                    return allowed;
                }
            }

            reason =
                "LEARNING V3"
                + " | Specific: "
                + specific.Trades
                + " | Side: "
                + sideAggregate.Trades
                + " | Global: "
                + globalAggregate.Trades
                + " | Need "
                + LearningMinTrades
                + "+ at any level"
                + " - ALLOWED";

            return true;
        }

        private void RecordLearningTradeResult(
            double netTradePnL)
        {
            if (
                activeLearningTrade == null
            )
            {
                return;
            }

            if (
                learningMemory == null
            )
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            DateTime signalNy =
                activeLearningTrade.SignalTimeNy !=
                    DateTime.MinValue
                    ? activeLearningTrade.SignalTimeNy
                    : ConvertToNewYorkTime(
                        DateTime.Now
                    );

            string key =
                GetLearningPatternKey(
                    activeLearningTrade.Side,
                    signalNy,
                    activeLearningTrade.Structure
                );

            JJBotLearningPattern pattern =
                FindLearningPattern(
                    key
                );

            if (pattern == null)
            {
                pattern =
                    new JJBotLearningPattern();

                pattern.Key =
                    key;

                pattern.Side =
                    activeLearningTrade.Side;

                // Session remains on the live trade as metadata,
                // but the stored V3 bucket intentionally spans AM + PM.
                pattern.SessionWindow =
                    "ALL";

                pattern.Structure =
                    activeLearningTrade.Structure;

                learningMemory.Patterns.Add(
                    pattern
                );
            }

            pattern.Trades++;

            const double LearningPnLEpsilon = 0.01;

            if (netTradePnL > LearningPnLEpsilon)
                pattern.Wins++;
            else if (netTradePnL < -LearningPnLEpsilon)
                pattern.Losses++;
            else
                pattern.Breakevens++;

            pattern.NetPnL +=
                netTradePnL;

            pattern.TotalMfe +=
                activeLearningTrade.Mfe;

            pattern.TotalMae +=
                activeLearningTrade.Mae;

            SaveLearningMemory();

            double winRate =
                pattern.Trades > 0
                    ? (
                        (double)pattern.Wins
                        / pattern.Trades
                    )
                    * 100.0
                    : 0;

            double expectancy =
                pattern.Trades > 0
                    ? pattern.NetPnL
                        / pattern.Trades
                    : 0;

            double averageMfe =
                pattern.Trades > 0
                    ? pattern.TotalMfe
                        / pattern.Trades
                    : 0;

            double averageMae =
                pattern.Trades > 0
                    ? pattern.TotalMae
                        / pattern.Trades
                    : 0;

            JJBotLearningPattern specificAggregate =
                BuildSpecificLearningAggregate(
                    pattern.Side,
                    pattern.Structure
                );

            JJBotLearningPattern sideAggregate =
                BuildLearningAggregate(
                    pattern.Side,
                    string.Empty
                );

            JJBotLearningPattern globalAggregate =
                BuildLearningAggregate(
                    string.Empty,
                    string.Empty
                );

            PrintBotMessage(
                "LEARNING UPDATED"
                + " | "
                + key
                + " | Trades: "
                + pattern.Trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | WinRate: "
                + winRate.ToString("0.0")
                + "%"
                + " | TradeNet: "
                + netTradePnL.ToString("$0.00")
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | Expectancy: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | AvgMFE: "
                + averageMfe.ToString("$0.00")
                + " | AvgMAE: "
                + averageMae.ToString("$0.00")
                + " | HIERARCHY SPECIFIC: "
                + specificAggregate.Trades
                + " | SIDE: "
                + sideAggregate.Trades
                + " | GLOBAL: "
                + globalAggregate.Trades
            );

            activeLearningTrade = null;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;
        }

        private string GetLearningFolderPath()
        {
            return Path.Combine(
                stateFolderPath,
                "Learning"
            );
        }

        private string GetLearningMemoryFilePath()
        {
            if (
                selectedInstrument == null
            )
            {
                return string.Empty;
            }

            string safeInstrument =
                MakeSafeFileName(
                    selectedInstrument.FullName
                );

            return Path.Combine(
                GetLearningFolderPath(),
                "memory_"
                    + safeInstrument
                    + ".xml"
            );
        }

        private void LoadLearningMemory()
        {
            try
            {
                learningMemory =
                    new JJBotLearningMemory();

                string path =
                    GetLearningMemoryFilePath();

                if (
                    string.IsNullOrWhiteSpace(
                        path
                    ) ||
                    !File.Exists(
                        path
                    )
                )
                {
                    return;
                }

                XmlSerializer serializer =
                    new XmlSerializer(
                        typeof(
                            JJBotLearningMemory
                        )
                    );

                using (
                    FileStream stream =
                        new FileStream(
                            path,
                            FileMode.Open,
                            FileAccess.Read,
                            FileShare.Read
                        )
                )
                {
                    JJBotLearningMemory loaded =
                        serializer.Deserialize(
                            stream
                        ) as JJBotLearningMemory;

                    if (loaded != null)
                    {
                        learningMemory =
                            loaded;
                    }
                }
            }
            catch (Exception ex)
            {
                learningMemory =
                    new JJBotLearningMemory();

                PrintBotMessage(
                    "LEARNING LOAD ERROR: "
                    + ex.Message
                );
            }
        }

        private void SaveLearningMemory()
        {
            try
            {
                if (
                    selectedInstrument == null ||
                    learningMemory == null
                )
                {
                    return;
                }

                Directory.CreateDirectory(
                    GetLearningFolderPath()
                );

                string path =
                    GetLearningMemoryFilePath();

                XmlSerializer serializer =
                    new XmlSerializer(
                        typeof(
                            JJBotLearningMemory
                        )
                    );

                using (
                    FileStream stream =
                        new FileStream(
                            path,
                            FileMode.Create,
                            FileAccess.Write,
                            FileShare.None
                        )
                )
                {
                    serializer.Serialize(
                        stream,
                        learningMemory
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING SAVE ERROR: "
                    + ex.Message
                );
            }
        }

        private void LogLearningDecision(
            DateTime decisionNyTime,
            string trend,
            string vwapSide,
            string liquidity,
            string structure,
            string setup,
            int buyScore,
            int sellScore)
        {
            try
            {
                if (
                    selectedInstrument == null
                )
                {
                    return;
                }

                Directory.CreateDirectory(
                    GetLearningFolderPath()
                );

                string safeInstrument =
                    MakeSafeFileName(
                        selectedInstrument.FullName
                    );

                string filePath =
                    Path.Combine(
                        GetLearningFolderPath(),
                        "decisions_"
                            + decisionNyTime.ToString(
                                "yyyy-MM-dd"
                            )
                            + "_"
                            + safeInstrument
                            + ".csv"
                    );

                bool writeHeader =
                    !File.Exists(
                        filePath
                    );

                using (
                    StreamWriter writer =
                        new StreamWriter(
                            filePath,
                            true
                        )
                )
                {
                    if (writeHeader)
                    {
                        writer.WriteLine(
                            "TimeNY,Session,Trend,VWAP,Sweep,Structure,Setup,BuyScore,SellScore"
                        );
                    }

                    writer.WriteLine(
                        decisionNyTime.ToString(
                            "yyyy-MM-dd HH:mm:ss"
                        )
                        + ","
                        + GetBotSessionWindow(
                            decisionNyTime
                        )
                        + ","
                        + EscapeCsv(
                            trend
                        )
                        + ","
                        + EscapeCsv(
                            vwapSide
                        )
                        + ","
                        + EscapeCsv(
                            liquidity
                        )
                        + ","
                        + EscapeCsv(
                            structure
                        )
                        + ","
                        + EscapeCsv(
                            setup
                        )
                        + ","
                        + buyScore
                        + ","
                        + sellScore
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING DECISION LOG ERROR: "
                    + ex.Message
                );
            }
        }

        private string EscapeCsv(
            string value)
        {
            if (value == null)
                return string.Empty;

            string escaped =
                value.Replace(
                    "\"",
                    "\"\""
                );

            if (
                escaped.Contains(",") ||
                escaped.Contains("\"") ||
                escaped.Contains("\n") ||
                escaped.Contains("\r")
            )
            {
                return
                    "\""
                    + escaped
                    + "\"";
            }

            return escaped;
        }

        private void PrintBotMessage(
            string message)
        {
            NinjaTrader.Code.Output.Process(
                "J&J BOT | "
                + message,
                PrintTo.OutputTab1
            );

            AppendVisualLog(
                message
            );
        }

        // =====================================================
        // VISUAL LOG
        // Thread-safe: BarsRequest, OrderUpdate and ExecutionUpdate
        // can call this method from non-UI threads.
        // =====================================================
        private void AppendVisualLog(
            string message)
        {
            if (
                string.IsNullOrWhiteSpace(
                    message
                )
            )
            {
                return;
            }

            Action appendAction =
                new Action(() =>
                {
                    if (
                        visualLogLines == null
                    )
                    {
                        visualLogLines =
                            new Queue<string>();
                    }

                    string timeStamp;

                    try
                    {
                        DateTime nyTime =
                            ConvertToNewYorkTime(
                                DateTime.Now
                            );

                        timeStamp =
                            nyTime.ToString(
                                "HH:mm:ss"
                            );
                    }
                    catch
                    {
                        timeStamp =
                            DateTime.Now.ToString(
                                "HH:mm:ss"
                            );
                    }

                    visualLogLines.Enqueue(
                        "["
                        + timeStamp
                        + "] "
                        + message
                    );

                    while (
                        visualLogLines.Count >
                            MaxVisualLogLines
                    )
                    {
                        visualLogLines.Dequeue();
                    }

                    if (
                        visualLogBox != null
                    )
                    {
                        visualLogBox.Text =
                            string.Join(
                                Environment.NewLine,
                                visualLogLines.ToArray()
                            );

                        visualLogBox.CaretIndex =
                            visualLogBox.Text.Length;

                        visualLogBox.ScrollToEnd();
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                appendAction();
            }
            else
            {
                Dispatcher.BeginInvoke(
                    appendAction
                );
            }
        }

        private void ClearVisualLogClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                visualLogLines != null
            )
            {
                visualLogLines.Clear();
            }

            if (
                visualLogBox != null
            )
            {
                visualLogBox.Clear();
            }

            AppendVisualLog(
                "Log cleared."
            );
        }

        // =====================================================
        // CARD
        // =====================================================
        private Border CreateCard()
        {
            Border card =
                new Border();

            card.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        20,
                        27,
                        37
                    )
                );

            card.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            card.BorderThickness =
                new Thickness(1);

            card.CornerRadius =
                new CornerRadius(8);

            card.Padding =
                new Thickness(15);

            card.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    12
                );

            return card;
        }

        // =====================================================
        // SECTION TITLE
        // =====================================================
        private TextBlock CreateSectionTitle(
            string text)
        {
            TextBlock block =
                new TextBlock();

            block.Text = text;

            block.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            block.FontWeight =
                FontWeights.Bold;

            block.FontSize = 12;

            return block;
        }

        // =====================================================
        // SMALL STATUS TEXT
        // =====================================================
        private TextBlock CreateSmallStatusText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.Gray;

            block.FontSize = 10;

            block.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    0
                );

            return block;
        }

        // =====================================================
        // TEXTBOX
        // =====================================================
        private TextBox CreateTextBox(
            string value)
        {
            TextBox box =
                new TextBox();

            box.Text = value;

            box.Width = 110;
            box.Height = 28;

            box.TextAlignment =
                TextAlignment.Right;

            box.VerticalContentAlignment =
                VerticalAlignment.Center;

            return box;
        }

        // =====================================================
        // LABEL + CONTROL ROW
        // =====================================================
        private void AddRow(
            StackPanel panel,
            string label,
            Control control)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        new GridLength(250)
                }
            );

            TextBlock text =
                new TextBlock();

            text.Text = label;

            text.Foreground =
                Brushes.WhiteSmoke;

            text.VerticalAlignment =
                VerticalAlignment.Center;

            Grid.SetColumn(
                text,
                0
            );

            row.Children.Add(
                text
            );

            control.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                control,
                1
            );

            row.Children.Add(
                control
            );

            panel.Children.Add(
                row
            );
        }

        // =====================================================
        // INFO TEXT
        // =====================================================
        private TextBlock CreateValueText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.White;

            block.FontWeight =
                FontWeights.Bold;

            return block;
        }

        private void AddInfoRow(
            StackPanel panel,
            string label,
            TextBlock value)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            TextBlock labelBlock =
                new TextBlock();

            labelBlock.Text =
                label;

            labelBlock.Foreground =
                Brushes.LightGray;

            Grid.SetColumn(
                labelBlock,
                0
            );

            row.Children.Add(
                labelBlock
            );

            value.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                value,
                1
            );

            row.Children.Add(
                value
            );

            panel.Children.Add(
                row
            );
        }

        // =====================================================
        // BUTTON
        // =====================================================
        private Button CreateButton(
            string text)
        {
            Button button =
                new Button();

            button.Content = text;

            button.Height = 42;

            button.FontWeight =
                FontWeights.Bold;

            button.Cursor =
                System.Windows.Input.Cursors.Hand;

            return button;
        }
    }
}

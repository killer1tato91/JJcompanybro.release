﻿#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it.
// V1.6.18 SHADOW SIGNAL RECORDER + CALIBRATED CONFIDENCE + POSITION RECOVERY.
// Trading/risk state is anchored to the CME-style NY session: a new session begins at 18:00 ET
// (Sunday-Thursday). The 16:25 ET FORCE FLAT lock is preserved only until that next session begins.
// Preserves V1.6.13 Learning Decision Engine, V1.6.12 Safety Hardening, Smart Retest, Premarket Context,
// all existing signal logic, execution protection, trailing, Smart Scale-In and telemetry behavior.
namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // SHARED STATE BRIDGE
    //
    // Lets JJBotControl publish its REAL execution state to
    // JJBotChart without the chart indicator submitting orders.
    // =========================================================
    public class JJBotSharedSnapshot
    {
        public bool IsRunning;
        public string AccountName;
        public string InstrumentName;

        public int TradesToday;
        public int MaxTrades;
        public int AmTrades;
        public int PmTrades;

        public double RealizedPnL;
        public double UnrealizedPnL;
        public double TotalPnL;

        public bool DailyLocked;

        public string Position;
        public int PositionQty;

        public double EntryPrice;
        public double StopPrice;
        public double TargetPrice;

        public string OrderStatus;
        public string Signal;
        public string Setup;

        // Advanced visual state for JJBotChart
        public string StrategyMode;
        public string SessionWindow;
        public string H4Trend;
        public string H1Trend;
        public string HtfContextBias;

        public string M5Trend;
        public string M5VwapSide;
        public string M5Liquidity;
        public string M5Structure;

        public string RangeMomentum;
        public int RangeLongScore;
        public int RangeShortScore;

        public bool LearningActive;
        public int LearningPatterns;
        public int LearningTrades;

        public string TrailingState;

        public long ExecutionSequence;
        public string LastExecutionSide;
        public double LastExecutionPrice;

        public DateTime LastUpdateUtc;

        public JJBotSharedSnapshot()
        {
            AccountName = string.Empty;
            InstrumentName = string.Empty;
            Position = "FLAT";
            OrderStatus = "WAITING";
            Signal = "WAITING";
            Setup = "WAITING";

            StrategyMode = "HYBRID";
            SessionWindow = "OUTSIDE";
            H4Trend = "WAITING";
            H1Trend = "WAITING";
            HtfContextBias = "NEUTRAL 0/2";
            M5Trend = "WAITING";
            M5VwapSide = "WAITING";
            M5Liquidity = "NONE";
            M5Structure = "WAITING";
            RangeMomentum = "WAITING RANGE";
            TrailingState = "OFF";

            LastExecutionSide = string.Empty;
            LastUpdateUtc = DateTime.MinValue;
        }

        public JJBotSharedSnapshot Clone()
        {
            return new JJBotSharedSnapshot
            {
                IsRunning = IsRunning,
                AccountName = AccountName,
                InstrumentName = InstrumentName,

                TradesToday = TradesToday,
                MaxTrades = MaxTrades,
                AmTrades = AmTrades,
                PmTrades = PmTrades,

                RealizedPnL = RealizedPnL,
                UnrealizedPnL = UnrealizedPnL,
                TotalPnL = TotalPnL,

                DailyLocked = DailyLocked,

                Position = Position,
                PositionQty = PositionQty,

                EntryPrice = EntryPrice,
                StopPrice = StopPrice,
                TargetPrice = TargetPrice,

                OrderStatus = OrderStatus,
                Signal = Signal,
                Setup = Setup,

                StrategyMode = StrategyMode,
                SessionWindow = SessionWindow,
                H4Trend = H4Trend,
                H1Trend = H1Trend,
                HtfContextBias = HtfContextBias,
                M5Trend = M5Trend,
                M5VwapSide = M5VwapSide,
                M5Liquidity = M5Liquidity,
                M5Structure = M5Structure,

                RangeMomentum = RangeMomentum,
                RangeLongScore = RangeLongScore,
                RangeShortScore = RangeShortScore,

                LearningActive = LearningActive,
                LearningPatterns = LearningPatterns,
                LearningTrades = LearningTrades,

                TrailingState = TrailingState,

                ExecutionSequence = ExecutionSequence,
                LastExecutionSide = LastExecutionSide,
                LastExecutionPrice = LastExecutionPrice,

                LastUpdateUtc = LastUpdateUtc
            };
        }
    }

    public static class JJBotSharedState
    {
        private static readonly object SyncRoot =
            new object();

        // V7 MULTI-INSTRUMENT:
        // One independent snapshot per Account + Instrument.
        // This prevents MES and MNQ windows from overwriting each
        // other's chart state when both bots are running together.
        private static readonly Dictionary<string, JJBotSharedSnapshot> snapshots =
            new Dictionary<string, JJBotSharedSnapshot>(
                StringComparer.OrdinalIgnoreCase
            );

        public static event Action StateChanged;

        // V7.1:
        // Removes a stale Account + Instrument state when a bot window
        // changes account/instrument. This prevents an old bot state from
        // remaining visible on a chart after the selector changes.
        public static void RemoveSnapshot(
            string accountName,
            string instrumentName)
        {
            Action handler = null;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                if (snapshots.Remove(key))
                {
                    handler =
                        StateChanged;
                }
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

       // =========================================================
// ACCOUNT + INSTRUMENT SNAPSHOT
// =========================================================
// This is the SAFE lookup used when the caller knows both
// the account and the instrument.
public static JJBotSharedSnapshot GetSnapshot(
    string accountName,
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(accountName) ||
        string.IsNullOrWhiteSpace(instrumentName)
    )
    {
        return null;
    }

    string key =
        BuildKey(
            accountName,
            instrumentName
        );

    lock (SyncRoot)
    {
        JJBotSharedSnapshot snapshot;

        if (
            !snapshots.TryGetValue(
                key,
                out snapshot
            ) ||
            snapshot == null
        )
        {
            return null;
        }

        return snapshot.Clone();
    }
}


// =========================================================
// INSTRUMENT-ONLY COMPATIBILITY LOOKUP
// =========================================================
// IMPORTANT:
// If MORE THAN ONE account has a bot running on the same
// instrument, this method intentionally returns null.
//
// It is safer to show NO LINK than randomly display the
// state of another account.
public static JJBotSharedSnapshot GetSnapshot(
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(
            instrumentName
        )
    )
    {
        return null;
    }

    lock (SyncRoot)
    {
        JJBotSharedSnapshot found = null;

        foreach (
            KeyValuePair<string, JJBotSharedSnapshot> pair
            in snapshots
        )
        {
            JJBotSharedSnapshot candidate =
                pair.Value;

            if (
                candidate == null ||
                string.IsNullOrWhiteSpace(
                    candidate.InstrumentName
                ) ||
                !string.Equals(
                    candidate.InstrumentName,
                    instrumentName,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                continue;
            }

            // More than one bot is publishing the same instrument.
            // Never guess which account the chart wants.
            if (found != null)
            {
                return null;
            }

            found =
                candidate;
        }

        return found != null
            ? found.Clone()
            : null;
    }
}

        // Kept for compatibility with any older visual code.
        // Returns the most recently updated bot of any instrument.
        public static JJBotSharedSnapshot GetSnapshot()
        {
            lock (SyncRoot)
            {
                JJBotSharedSnapshot newest = null;

                foreach (
                    KeyValuePair<string, JJBotSharedSnapshot> pair
                    in snapshots
                )
                {
                    JJBotSharedSnapshot candidate =
                        pair.Value;

                    if (
                        candidate != null &&
                        (
                            newest == null ||
                            candidate.LastUpdateUtc >
                                newest.LastUpdateUtc
                        )
                    )
                    {
                        newest = candidate;
                    }
                }

                return newest != null
                    ? newest.Clone()
                    : null;
            }
        }

        public static void Update(
            bool isRunning,
            string accountName,
            string instrumentName,
            int tradesToday,
            int maxTrades,
            int amTrades,
            int pmTrades,
            double realizedPnL,
            double unrealizedPnL,
            double totalPnL,
            bool dailyLocked,
            string position,
            int positionQty,
            double entryPrice,
            double stopPrice,
            double targetPrice,
            string orderStatus,
            string signal,
            string setup,
            string strategyMode,
            string sessionWindow,
            string h4Trend,
            string h1Trend,
            string htfContextBias,
            string m5Trend,
            string m5VwapSide,
            string m5Liquidity,
            string m5Structure,
            string rangeMomentum,
            int rangeLongScore,
            int rangeShortScore,
            bool learningActive,
            int learningPatterns,
            int learningTrades,
            string trailingState)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    snapshots[key] =
                        current;
                }

                current.IsRunning =
                    isRunning;

                current.AccountName =
                    accountName ?? string.Empty;

                current.InstrumentName =
                    instrumentName ?? string.Empty;

                current.TradesToday =
                    tradesToday;

                current.MaxTrades =
                    maxTrades;

                current.AmTrades =
                    amTrades;

                current.PmTrades =
                    pmTrades;

                current.RealizedPnL =
                    realizedPnL;

                current.UnrealizedPnL =
                    unrealizedPnL;

                current.TotalPnL =
                    totalPnL;

                current.DailyLocked =
                    dailyLocked;

                current.Position =
                    string.IsNullOrWhiteSpace(
                        position
                    )
                        ? "FLAT"
                        : position;

                current.PositionQty =
                    positionQty;

                current.EntryPrice =
                    entryPrice;

                current.StopPrice =
                    stopPrice;

                current.TargetPrice =
                    targetPrice;

                current.OrderStatus =
                    orderStatus ?? "WAITING";

                current.Signal =
                    signal ?? "WAITING";

                current.Setup =
                    setup ?? "WAITING";

                current.StrategyMode =
                    strategyMode ?? "HYBRID";

                current.SessionWindow =
                    sessionWindow ?? "OUTSIDE";

                current.H4Trend =
                    h4Trend ?? "WAITING";

                current.H1Trend =
                    h1Trend ?? "WAITING";

                current.HtfContextBias =
                    htfContextBias ?? "NEUTRAL 0/2";

                current.M5Trend =
                    m5Trend ?? "WAITING";

                current.M5VwapSide =
                    m5VwapSide ?? "WAITING";

                current.M5Liquidity =
                    m5Liquidity ?? "NONE";

                current.M5Structure =
                    m5Structure ?? "WAITING";

                current.RangeMomentum =
                    rangeMomentum ?? "WAITING RANGE";

                current.RangeLongScore =
                    rangeLongScore;

                current.RangeShortScore =
                    rangeShortScore;

                current.LearningActive =
                    learningActive;

                current.LearningPatterns =
                    learningPatterns;

                current.LearningTrades =
                    learningTrades;

                current.TrailingState =
                    trailingState ?? "OFF";

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        public static void PublishExecution(
            string accountName,
            string instrumentName,
            string side,
            double price)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    current.AccountName =
                        accountName ?? string.Empty;

                    current.InstrumentName =
                        instrumentName ?? string.Empty;

                    snapshots[key] =
                        current;
                }

                current.ExecutionSequence++;

                current.LastExecutionSide =
                    side ?? string.Empty;

                current.LastExecutionPrice =
                    price;

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }
    }

    public class JJBotControl : NinjaTrader.NinjaScript.AddOnBase
    {
        private NTMenuItem toolsMenu;
        private NTMenuItem jjBotMenuItem;

        // One persistent bot window/engine per NinjaTrader session.
        // Closing the visible window only hides it; the engine, telemetry
        // and command polling remain alive in the background.
        private JJBotWindow jjBotWindow;

        // V15 - five independent hidden bot engines.
        private readonly Dictionary<string, JJBotWindow>
            jjBotProfileWindows =
                new Dictionary<string, JJBotWindow>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly string[] BotProfileIds =
        {
            "profile-1",
            "profile-2",
            "profile-3",
            "profile-4",
            "profile-5"
        };

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "J&J NY Trading Bot Control Panel";
                Name = "JJBotControl";
            }
        }

        // =====================================================
        // ADD J&J BOT TO NINJATRADER TOOLS MENU
        // =====================================================
        protected override void OnWindowCreated(Window window)
        {
            ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            toolsMenu =
                controlCenter.FindFirst(
                    "ControlCenterMenuItemTools"
                ) as NTMenuItem;

            if (toolsMenu == null)
                return;

            jjBotMenuItem = new NTMenuItem
            {
                Header = "J&J NY Trading Bot",

                Style =
                    Application.Current.TryFindResource(
                        "MainMenuItem"
                    ) as Style
            };

            toolsMenu.Items.Add(jjBotMenuItem);
            jjBotMenuItem.Click += OnJJBotMenuClick;

            // Start the bridge/telemetry/command engine automatically.
            // IMPORTANT:
            // Create the hidden bot window on the SAME dispatcher that owns
            // NinjaTrader's Control Center. Application.Current.Dispatcher
            // is not guaranteed to be the same dispatcher in NinjaTrader.
            EnsureBackgroundBotEngine(
                controlCenter.Dispatcher
            );
        }

        private void EnsureBackgroundBotEngine(
            Dispatcher dispatcher)
        {
            if (dispatcher == null)
            {
                return;
            }

            dispatcher.BeginInvoke(
                new Action(
                    delegate
                    {
                        if (
                            jjBotWindow != null &&
                            jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        foreach (
                            string profileId
                            in BotProfileIds
                        )
                        {
                            JJBotWindow profileWindow;

                            if (
                                jjBotProfileWindows.TryGetValue(
                                    profileId,
                                    out profileWindow
                                ) &&
                                profileWindow != null &&
                                profileWindow.IsEngineWindowAlive
                            )
                            {
                                continue;
                            }

                            profileWindow =
                                new JJBotWindow(
                                    profileId,
                                    string.Equals(
                                        profileId,
                                        "profile-1",
                                        StringComparison.OrdinalIgnoreCase
                                    )
                                );

                            jjBotProfileWindows[profileId] =
                                profileWindow;

                            if (
                                string.Equals(
                                    profileId,
                                    "profile-1",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                jjBotWindow =
                                    profileWindow;
                            }
                        }

                        // Windows stay hidden. Each profile polls only
                        // its own command queue and publishes its own state.
                    }
                )
            );
        }

        // =====================================================
        // CLEANUP MENU
        // =====================================================
        protected override void OnWindowDestroyed(Window window)
        {
            if (!(window is ControlCenter))
                return;

            // NinjaTrader / Control Center is actually shutting down:
            // now the hidden engine must be allowed to close permanently.
            foreach (
                KeyValuePair<string, JJBotWindow> pair
                in jjBotProfileWindows.ToArray()
            )
            {
                try
                {
                    if (pair.Value != null)
                    {
                        pair.Value.RequestPermanentClose();
                    }
                }
                catch
                {
                }
            }

            jjBotProfileWindows.Clear();
            jjBotWindow = null;

            if (jjBotMenuItem != null)
            {
                jjBotMenuItem.Click -= OnJJBotMenuClick;

                if (
                    toolsMenu != null &&
                    toolsMenu.Items.Contains(jjBotMenuItem)
                )
                {
                    toolsMenu.Items.Remove(jjBotMenuItem);
                }

                jjBotMenuItem = null;
            }

            toolsMenu = null;
        }

        // =====================================================
        // OPEN BOT WINDOW
        // =====================================================
        private void OnJJBotMenuClick(
            object sender,
            RoutedEventArgs e)
        {
            /*
              IMPORTANT:
              If the hidden JJBotWindow already exists, the ONLY safe
              dispatcher for Show/Activate/WindowState is the dispatcher
              that owns that exact window.

              The menu/Control Center dispatcher is not guaranteed to be
              the owner of the existing hidden window.
            */
            if (
                jjBotWindow != null &&
                jjBotWindow.IsEngineWindowAlive
            )
            {
                Dispatcher windowDispatcher =
                    jjBotWindow.Dispatcher;

                if (windowDispatcher == null)
                {
                    return;
                }

                windowDispatcher.BeginInvoke(
                    new Action(() =>
                    {
                        if (
                            jjBotWindow == null ||
                            !jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        if (!jjBotWindow.IsVisible)
                        {
                            jjBotWindow.Show();
                        }

                        if (
                            jjBotWindow.WindowState ==
                                WindowState.Minimized
                        )
                        {
                            jjBotWindow.WindowState =
                                WindowState.Normal;
                        }

                        jjBotWindow.Activate();
                    })
                );

                return;
            }

            /*
              No window exists yet.
              Create + show it on the same dispatcher that owns
              NinjaTrader's menu/Control Center.
            */
            Dispatcher createDispatcher =
                jjBotMenuItem != null
                    ? jjBotMenuItem.Dispatcher
                    : (
                        toolsMenu != null
                            ? toolsMenu.Dispatcher
                            : null
                      );

            if (createDispatcher == null)
            {
                return;
            }

            createDispatcher.BeginInvoke(
                new Action(() =>
                {
                    if (
                        jjBotWindow == null ||
                        !jjBotWindow.IsEngineWindowAlive
                    )
                    {
                        jjBotWindow =
                            new JJBotWindow(
                                "profile-1",
                                true
                            );

                        jjBotProfileWindows[
                            "profile-1"
                        ] =
                            jjBotWindow;
                    }

                    if (!jjBotWindow.IsVisible)
                    {
                        jjBotWindow.Show();
                    }

                    if (
                        jjBotWindow.WindowState ==
                            WindowState.Minimized
                    )
                    {
                        jjBotWindow.WindowState =
                            WindowState.Normal;
                    }

                    jjBotWindow.Activate();
                })
            );
        }
    }

    // =========================================================
    // RUNTIME / PERSISTENCE COORDINATOR
    // =========================================================
    // - One persistence lock per Account + Instrument.
    // - One active bot lease per Account + Instrument.
    //
    // This prevents two JJBot windows from actively trading the same
    // Account + Instrument at the same time and serializes XML access.
    // =========================================================
    public static class JJBotRuntimeCoordinator
    {
        private static readonly object SyncRoot =
            new object();

        private static readonly Dictionary<string, object>
            persistenceLocks =
                new Dictionary<string, object>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly HashSet<string>
            activeBotKeys =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

        public static object GetPersistenceLock(
            string accountName,
            string instrumentName)
        {
            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                object gate;

                if (
                    !persistenceLocks.TryGetValue(
                        key,
                        out gate
                    ) ||
                    gate == null
                )
                {
                    gate =
                        new object();

                    persistenceLocks[key] =
                        gate;
                }

                return gate;
            }
        }

        public static bool TryAcquireBotLease(
            string accountName,
            string instrumentName,
            out string leaseKey)
        {
            leaseKey =
                BuildKey(
                    accountName,
                    instrumentName
                );

            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                leaseKey =
                    string.Empty;

                return false;
            }

            lock (SyncRoot)
            {
                if (
                    activeBotKeys.Contains(
                        leaseKey
                    )
                )
                {
                    return false;
                }

                activeBotKeys.Add(
                    leaseKey
                );

                return true;
            }
        }

        public static void ReleaseBotLease(
            string leaseKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    leaseKey
                )
            )
            {
                return;
            }

            lock (SyncRoot)
            {
                activeBotKeys.Remove(
                    leaseKey
                );
            }
        }
    }

    // =========================================================
    // PERSISTENT SESSION STATE
    // =========================================================
    [Serializable]
    public class JJBotDailyStateData
    {
        // V1.6.12 - explicit persistence schema tag.
        // 0 means legacy/unknown. New saves use schema 2.
        public int SchemaVersion
        {
            get;
            set;
        }

        public string NewYorkDate
        {
            get;
            set;
        }

        public string AccountName
        {
            get;
            set;
        }

        public string InstrumentName
        {
            get;
            set;
        }

        public int TradesToday
        {
            get;
            set;
        }

        public int AmTrades
        {
            get;
            set;
        }

        public int PmTrades
        {
            get;
            set;
        }

        // V1.6.8 - independent premarket counter.
        public int PremarketTrades
        {
            get;
            set;
        }

        // V13 - strict lunch-session counter.
        public int MiddayTrades
        {
            get;
            set;
        }

// V11 PnL accounting:
        // GrossPnL = price movement before commissions/fees.
        // Fees = entry + exit execution commissions.
        // RealizedPnL remains NET for backward compatibility.
        public double GrossPnL
        {
            get;
            set;
        }

        public double Fees
        {
            get;
            set;
        }

        public double RealizedPnL
        {
            get;
            set;
        }

        // V1.6.4 - dynamic daily/session profit protection.
        // These fields are backward compatible with older XML files.
        public double PeakTotalPnL
        {
            get;
            set;
        }

        public double ProtectedProfitFloor
        {
            get;
            set;
        }

        public bool ProfitFloorArmed
        {
            get;
            set;
        }

        public bool DailyLocked
        {
            get;
            set;
        }

        // V1.6.2 - diagnostic persistence for daily lock source.
        public string DailyLockReason
        {
            get;
            set;
        }

        public DateTime LastExecutedSignalBar
        {
            get;
            set;
        }

        // Structure setup keys are persisted so a restart cannot
        // re-trade the same already-filled sweep/BOS setup.
        public string ConsumedBullishStructureKey
        {
            get;
            set;
        }

        public string ConsumedBearishStructureKey
        {
            get;
            set;
        }

        public DateTime ConsumedBullishStructureConfirmTime
        {
            get;
            set;
        }

        public DateTime ConsumedBearishStructureConfirmTime
        {
            get;
            set;
        }

        public bool OpeningTradeTaken
        {
            get;
            set;
        }

        public JJBotDailyStateData()
        {
            SchemaVersion = 0;
            NewYorkDate = string.Empty;
            AccountName = string.Empty;
            InstrumentName = string.Empty;

            TradesToday = 0;
            AmTrades = 0;
            PmTrades = 0;
            PremarketTrades = 0;
            MiddayTrades = 0;
            GrossPnL = 0;
            Fees = 0;
            RealizedPnL = 0;
            PeakTotalPnL = 0;
            ProtectedProfitFloor = 0;
            ProfitFloorArmed = false;
            DailyLocked = false;
            DailyLockReason = string.Empty;

            LastExecutedSignalBar =
                DateTime.MinValue;

            ConsumedBullishStructureKey =
                string.Empty;

            ConsumedBearishStructureKey =
                string.Empty;

            ConsumedBullishStructureConfirmTime =
                DateTime.MinValue;

            ConsumedBearishStructureConfirmTime =
                DateTime.MinValue;

            OpeningTradeTaken = false;
        }
    }

    // =========================================================
    // LEARNING ENGINE - PERSISTENT MEMORY
    // =========================================================
    [Serializable]
    public class JJBotLearningPattern
    {
        public string Key { get; set; }
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public int Trades { get; set; }
        public int Wins { get; set; }
        public int Losses { get; set; }
        public int Breakevens { get; set; }

        public double NetPnL { get; set; }
        public double TotalMfe { get; set; }
        public double TotalMae { get; set; }

        // V1.6.4 Step 6 - resolved BE follow-through observations.
        // These fields are XML-persisted with the existing Learning memory.
        public int BeFollowThroughResolved { get; set; }
        public int BeFollowThroughTargetHits { get; set; }

        // V1.6.13 - RECENCY-WEIGHTED EVIDENCE.
        // These accumulators decay with time so newer market behavior matters
        // more than old regimes, while lifetime totals remain untouched.
        public double RecentWeight { get; set; }
        public double RecentWins { get; set; }
        public double RecentNetPnL { get; set; }
        public double RecentTotalMfe { get; set; }
        public double RecentTotalMae { get; set; }
        public DateTime RecentAsOfUtc { get; set; }

        // V1.6.16 - calibration evidence for the confidence shown at entry.
        public int ConfidenceTrades { get; set; }
        public int ConfidenceWins { get; set; }
        public double TechnicalConfidenceSum { get; set; }
        public double ConfidenceNetPnL { get; set; }

        public JJBotLearningPattern()
        {
            Key = string.Empty;
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
        }
    }

    [Serializable]
    public class JJBotLearningMemory
    {
        public List<JJBotLearningPattern> Patterns { get; set; }

        public JJBotLearningMemory()
        {
            Patterns =
                new List<JJBotLearningPattern>();
        }
    }

    [Serializable]
    public class JJBotLearningTrade
    {
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public DateTime SignalTimeNy { get; set; }
        public double EntryPrice { get; set; }

        public double Mfe { get; set; }
        public double Mae { get; set; }

        // V1.6.16 - exact confidence context at the moment of entry.
        public int TechnicalConfidence { get; set; }
        public string SetupQuality { get; set; }
        public string SetupTiming { get; set; }
        public string ManipulationState { get; set; }

        public JJBotLearningTrade()
        {
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
            SetupQuality = string.Empty;
            SetupTiming = string.Empty;
            ManipulationState = string.Empty;
        }
    }

    // =========================================================
    // V1.6.4 STEP 6 - BREAKEVEN FOLLOW-THROUGH TRACKER
    // =========================================================
    public class JJBotBreakevenFollowThrough
    {
        public string PatternKey { get; set; }
        public string EventKey { get; set; }
        public string Side { get; set; }

        public double EntryPrice { get; set; }
        public double OriginalTargetPrice { get; set; }

        public DateTime ExitTimeNy { get; set; }
        public DateTime ExpiresTimeNy { get; set; }

        public JJBotBreakevenFollowThrough()
        {
            PatternKey = string.Empty;
            EventKey = string.Empty;
            Side = string.Empty;
            ExitTimeNy = DateTime.MinValue;
            ExpiresTimeNy = DateTime.MinValue;
        }
    }

    // =========================================================
    // J&J BOT WINDOW
    // =========================================================
    public class JJBotWindow : NTWindow
    {
        // =====================================================
        // LIVE DISPLAY
        // =====================================================
        private TextBlock statusText;
        private TextBlock grossPnlText;
        private TextBlock feesPnlText;
        private TextBlock pnlText;
        private TextBlock unrealizedPnlText;
        private TextBlock totalPnlText;
        private TextBlock tradesText;
        private TextBlock signalText;
        private TextBlock accountStatusText;
        private TextBlock instrumentStatusText;

        private TextBlock emaFastText;
        private TextBlock emaSlowText;
        private TextBlock lastPriceText;
        private TextBlock barTimeText;

        private TextBlock vwapText;
        private TextBlock nySessionText;
        private TextBlock trendText;
        private TextBlock setupText;

        private TextBlock liquidityText;
        private TextBlock structureText;
        private TextBlock momentumText;
        private TextBlock confirmationText;

        // Values published to JJBotChart.
        private string currentSignalState;
        private string currentSetupState;

        // =====================================================
        // EXECUTION MONITOR DISPLAY
        // =====================================================
        private TextBlock positionText;
        private TextBlock positionQtyText;
        private TextBlock entryPriceText;
        private TextBlock stopPriceText;
        private TextBlock targetPriceText;
        private TextBlock riskRewardText;
        private TextBlock orderStatusText;

        // =====================================================
        // VISUAL LOG
        // =====================================================
        private TextBox visualLogBox;
        private Button clearLogButton;
        private Queue<string> visualLogLines;

        private const int MaxVisualLogLines = 2000;

        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        // Read-only bridge:
        // JJBotControl -> localhost backend -> React platform.
        //
        // IMPORTANT:
        // This bridge NEVER submits, changes or flattens orders.
        // It only publishes the bot's current state.
        private DispatcherTimer platformTelemetryTimer;
        private bool platformTelemetryRequestInFlight;
        private string platformApiKey;
        private string platformServerUrl;
        private string platformConfigFile;

        // V15 runtime identity.
        private string platformProfileId;
        private bool primaryProfileWindow;
        private DateTime lastPlatformTelemetrySuccessUtc;

        // Platform -> JJBotControl command polling.
        // Separate timer/HTTP request from telemetry so a slow command
        // request can never block state publishing.
        private DispatcherTimer platformCommandTimer;
        private bool platformCommandRequestInFlight;
        private string lastProcessedPlatformCommandId;

        // True only while a START_BOT command from J&J Company Bro
        // is applying its Account + Instrument + risk configuration.
        // This lets StartBotClicked use the platform-selected context
        // without requiring the visible NinjaTrader bot window.
        private bool platformRemoteStartContext;

        private const int PlatformTelemetryIntervalSeconds = 3;
        private const int PlatformCommandIntervalSeconds = 1;
        // V1.6.6 - keep the local visual history large, but only publish
        // a compact tail to the platform. This prevents one noisy profile
        // from timing out its own telemetry request.
        private const int PlatformTelemetryMaxLogLines = 1000;
        private const string PlatformBridgeVersion = "1.3.2";

        // =====================================================
        // NINJATRADER SELECTORS
        // =====================================================
        private AccountSelector accountSelector;
        private InstrumentSelector instrumentSelector;

        private Account selectedAccount;
        private Instrument selectedInstrument;

        // =====================================================
        // SETTINGS
        // =====================================================
        private ComboBox directionCombo;
        private ComboBox strategyCombo;

        private TextBox contractsBox;
        private TextBox stopBox;
        private TextBox targetBox;
        private TextBox maxTradesBox;
        private TextBox dailyTargetBox;
        private TextBox dailyLossBox;
        private TextBox dollarRiskCapBox;

        // =====================================================
        // BUTTONS
        // =====================================================
        private Button startButton;
        private Button stopButton;
        private Button closeAllButton;

        private Button testLongButton;
        private Button testShortButton;

        // =====================================================
        // BOT ENGINE
        // =====================================================
        private bool botRunning;

        // V1.6.14R2 - delayed Position Recovery.
        // NinjaTrader can expose Account.Positions a short time after START,
        // especially after an app/PC restart. During this short recovery
        // window automatic entries are blocked until the position state has
        // had time to synchronize.
        private DispatcherTimer positionRecoveryTimer;
        private int positionRecoveryAttempts;
        private bool positionRecoveryPending;
        private const int PositionRecoveryMaxAttempts = 8;
        private const int PositionRecoveryRetryMilliseconds = 1000;

        // Cached on the UI thread when START BOT is pressed.
        // BarsRequest callbacks run on a different thread, so they must
        // never read WPF controls such as directionCombo directly.
        private string activeDirection;
        private string activeStrategyMode;

        // V1.6.4 Step 5 - AUTO direction resolved by market context.
        private string autoResolvedDirection;
        private string autoDirectionReason;

        // V1.6.14 LOG FIX - telemetry/log debounce is intentionally
        // independent from the live AUTO state. Fast Range callbacks may
        // temporarily change autoResolvedDirection between evaluations;
        // that must not make identical AUTO DIRECTION messages flood the log.
        private string lastLoggedAutoDirection;
        private string lastLoggedAutoDirectionReason;
        private DateTime lastAutoDirectionLogUtc;

        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        private int activeContracts;
        private int activeStopTicks;
        private int activeTargetTicks;
        private int activeMaxTrades;
        private double activeDailyTarget;
        private double activeDailyLoss;

        // V1.6.4 Step 4 - monetary risk cap per initial entry.
        // Auto Risk Sizing reduces contracts when configured SL risk
        // would exceed this cap.
        private double activeDollarRiskCap;

        // =====================================================
        // INPUT SAFETY LIMITS
        // =====================================================
        // Conservative hard caps for the SIM-only build.
        private const int MaxContractsAllowed = 20;
        private const int MaxStopTicksAllowed = 2000;
        private const int MaxTargetTicksAllowed = 4000;
        private const int MaxTradesPerSessionAllowed = 20;
        private const double MaxDailyTargetAllowed = 10000.0;
        private const double MaxDailyLossAllowed = 10000.0;
        private const double MaxDollarRiskCapAllowed = 10000.0;

        // V1.6.14 persistence schema. Schema 1 = legacy V11-compatible,
        // schema 2 = explicit Gross/Fees/Net, schema 3 = session-date semantics
        // (18:00 ET session rollover instead of midnight/calendar-day rollover).
        private const int CurrentDailyStateSchemaVersion = 3;

        private int tradesToday;
        private int premarketTradesToday;
        private int amTradesToday;
        private int pmTradesToday;
        private int middayTradesToday;
        private string pendingEntrySession;

// Actual order quantity after Auto Risk Sizing. activeContracts remains
// the user's configured maximum quantity.
private int pendingEntryRequestedQuantity;

        // V9 - MANUAL TEST ISOLATION
        // TEST_LONG / TEST_SHORT must exercise real order/bracket/trailing
        // mechanics without contaminating official session statistics,
        // Daily PnL or Learning memory.
        private bool pendingEntryIsManualTest;
        private bool activeTradeIsManualTest;

        // V12 - Opening Mode lifecycle.
        private bool pendingEntryIsOpening;
        private bool activeTradeIsOpening;

        // V1.6.8 - identifies the active lifecycle as a premarket trade so
        // the 09:28 transition guard can flatten it before the cash open.
        private bool pendingEntryIsPremarket;
        private bool activeTradeIsPremarket;

        private bool openingTradeTakenToday;

        private bool openingRangeReady;
        private double openingRangeHigh;
        private double openingRangeLow;
        private DateTime openingRangeBarTimeNy;
        private DateTime openingRangeLoggedDate;

        // V1.6.8 - PREMARKET ENGINE V1.
        // Built from completed M5 bars. Range-20 compares the live fast
        // move against the latest completed premarket frontier.
        private bool premarketRangeReady;
        private double premarketRangeHigh;
        private double premarketRangeLow;
        private DateTime premarketRangeDateNy;
        private DateTime premarketRangeLastM5TimeNy;
        private string lastPremarketChaseBlockLogKey;

        // V1.6.4 Step 3 - pre-entry/opening guard state.
        private bool preEntryRangeReady;
        private double preEntryRangeHigh;
        private double preEntryRangeLow;
        private DateTime preEntryRangeDateNy;
        private bool openingRangeGuardBlocked;
        private string openingRangeGuardReason;
        private DateTime openingRangeGuardDateNy;
        private string lastLateEntryBlockLogKey;

        // V11 - Daily accounting.
        // botDailyPnL is NET realized PnL and remains the value used by
        // Daily Target / Daily Loss and Learning compatibility paths.
        private double botDailyGrossPnL;
        private double botDailyFees;
        private double botDailyPnL;
        private double botUnrealizedPnL;

        // V1.6.4 - DAILY / SESSION PROFIT FLOOR
        // Protects part of the best total PnL reached during the NY day.
        // The floor can only move UP; it can never loosen once armed.
        private double dailyPeakTotalPnL;
        private double dailyProtectedProfitFloor;
        private bool dailyProfitFloorArmed;
        private double lastLoggedProtectedProfitFloor;
        private DateTime activeTradingDate;

        private bool riskFlattenSent;
        private int riskFlattenStage;
        private DateTime riskFlattenLastActionUtc;
        private Order riskFlattenOrder;

        // Tracks both sides of commission so Learning NetPnL is exact.
        private double activeEntryCommission;

        // =====================================================
        // PARTIAL FILL / TRADE LIFECYCLE V1
        // =====================================================
        // Entry executions can arrive in multiple partial fills.
        // Keep one lifecycle, one learning record and one trade count.
        private int activeEffectiveTargetTicks;
        private int activeExitQuantity;
        private double activeExitGrossPnL;
        private double activeExitCommission;

        // Debounces repeated Range signal/block messages for the same Range bar.
        private string lastRangeSignalLogKey;
        private string lastRangeBlockedLogKey;
        private string lastLearningBlockedLogKey;

        // =====================================================
        // V1.6.18 - SHADOW SIGNAL RECORDER
        // Records signal candidates and forward outcomes WITHOUT submitting,
        // changing or cancelling orders. This dataset is intended for
        // walk-forward parameter validation and threshold audits.
        private sealed class JJBotShadowSignal
        {
            public string Id;
            public DateTime SignalTimeNy;
            public string Side;
            public string SessionWindow;
            public string Decision;
            public string DecisionReason;
            public double SignalPrice;
            public int MomentumScore;
            public double RangeRatio;
            public double VolumeRatio;
            public double BodyRatio;
            public double SlopeTicks;
            public bool DirectionalBreakout;
            public int AggressionScore;
            public bool AggressiveExpansion;
            public bool ExtremeMomentum;
            public string M5Trend;
            public string M5Vwap;
            public string M5Structure;
            public string M5Liquidity;
            public int HtfAlignmentScore;
            public int TechnicalQuality;
            public string SetupQuality;
            public string SetupTiming;
            public string ManipulationState;
            public double MfeTicks;
            public double MaeTicks;
            public readonly HashSet<int> WrittenHorizons =
                new HashSet<int>();
        }

        private readonly object shadowSignalLock =
            new object();

        private readonly List<JJBotShadowSignal> activeShadowSignals =
            new List<JJBotShadowSignal>();

        private readonly HashSet<string> shadowSignalIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private const bool ShadowSignalRecorderEnabled = true;
        private static readonly int[] ShadowSignalHorizonsSeconds =
            new int[] { 30, 60, 180, 300 };

        private string pendingShadowSignalId = string.Empty;

        // =====================================================
        // V1.6.16 - STATISTICALLY CALIBRATED CONFIDENCE
        // =====================================================
        private int GetCalibratedSetupConfidence(
            string side,
            string structure,
            int technicalConfidence,
            out int sampleTrades,
            out double observedWinRate)
        {
            sampleTrades = 0;
            observedWinRate = 0;

            int technical =
                Math.Max(
                    0,
                    Math.Min(99, technicalConfidence)
                );

            if (
                string.IsNullOrWhiteSpace(side) ||
                string.IsNullOrWhiteSpace(structure)
            )
            {
                return technical;
            }

            string key =
                GetLearningPatternKey(
                    side,
                    GetCurrentNewYorkTime(),
                    structure
                );

            JJBotLearningPattern pattern =
                FindLearningPattern(key);

            if (
                pattern == null ||
                pattern.ConfidenceTrades <= 0
            )
            {
                return technical;
            }

            sampleTrades =
                pattern.ConfidenceTrades;

            observedWinRate =
                (
                    (double)pattern.ConfidenceWins /
                    Math.Max(
                        1,
                        pattern.ConfidenceTrades
                    )
                ) * 100.0;

            // Do not pretend a tiny sample is predictive.
            // Before 15 observations, the displayed value remains the
            // technical score exactly as before.
            double historicalWeight = 0;

            if (sampleTrades >= 50)
                historicalWeight = 0.70;
            else if (sampleTrades >= 30)
                historicalWeight = 0.50;
            else if (sampleTrades >= 15)
                historicalWeight = 0.30;

            if (historicalWeight <= 0)
            {
                return technical;
            }

            double expectancy =
                pattern.ConfidenceNetPnL /
                Math.Max(
                    1,
                    pattern.ConfidenceTrades
                );

            // Expectancy only nudges the calibration. It cannot dominate
            // the actual observed hit-rate.
            double expectancyAdjustment =
                Math.Max(
                    -5.0,
                    Math.Min(
                        5.0,
                        expectancy / 10.0
                    )
                );

            double calibrated =
                (
                    technical *
                    (1.0 - historicalWeight)
                ) +
                (
                    observedWinRate *
                    historicalWeight
                ) +
                expectancyAdjustment;

            return
                Math.Max(
                    0,
                    Math.Min(
                        99,
                        (int)Math.Round(calibrated)
                    )
                );
        }

        // =====================================================
        // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE ENGINE
        // =====================================================
        // Advisory layer for MNQ/NQ. It scores confluence already calculated
        // by the bot; it does NOT add a new hard entry filter in V1.
        private string lastSetupQualityLogKey;
        private int latestSetupConfidence;
        private string latestSetupQuality;
        private string latestSetupTiming;
        private string latestManipulationState;

        // V1.6.15A - UI confidence lifecycle.
        // pending* snapshots the exact analysis at order submission.
        // active* freezes that value after the first fill so the orb
        // keeps showing the confidence that actually produced the trade.
        private int pendingTradeSetupConfidence;
        private string pendingTradeSetupQuality;
        private string pendingTradeSetupTiming;
        private string pendingTradeManipulationState;
        private int activeTradeSetupConfidence;
        private string activeTradeSetupQuality;
        private string activeTradeSetupTiming;
        private string activeTradeManipulationState;

        // V1.6.9 - aggressive expansion / exhaustion diagnostics.
        private string lastAggressionSignalLogKey;
        private string lastExhaustionBlockLogKey;
        private string lastPullbackWaitLogKey;
        private string lastStructureExhaustionLogKey;

        // V1.6.11 - pending Smart Retest entry. A stretched ordinary signal is
        // remembered for a short window instead of being forgotten. The next
        // Range bars may confirm a breakout retest, M5 structure retest or a
        // micro-pullback continuation. Aggressive Expansion still enters direct.
        private bool pendingSmartRetestActive;
        // V1.6.16B - telemetry-only dedupe. Does NOT alter Smart Retest logic.
        private string lastSmartRetestConfirmedLogKey = string.Empty;
        private bool pendingSmartRetestIsLong;
        private DateTime pendingSmartRetestCreatedNy;
        private DateTime pendingSmartRetestExpiresNy;
        private double pendingSmartRetestBreakoutLevel;
        private double pendingSmartRetestStructureLevel;
        private double pendingSmartRetestImpulseExtreme;
        private int pendingSmartRetestOriginalScore;
        private string pendingSmartRetestReason;
        private string pendingSmartRetestStructureSetupKey;
        private string lastSmartRetestLogKey;

        // Latest real M5 BOS/CHOCH break levels. These are the structural prices
        // that were actually closed through, not an EMA proxy.
        private double latestM5BullishStructureBreakLevel;
        private double latestM5BearishStructureBreakLevel;

        // V1.6.11 - PREMARKET CONTEXT ENGINE. Built continuously from completed
        // M5 bars so Opening starts with a statistical map already prepared.
        private bool premarketContextReady;
        private DateTime premarketContextDateNy;
        private double premarketContextOpen;
        private double premarketContextLastClose;
        private double premarketContextMid;
        private double premarketContextRangeTicks;
        private int premarketContextBars;
        private int premarketBullBars;
        private int premarketBearBars;
        private int premarketUpperHalfCloses;
        private int premarketLowerHalfCloses;
        private double premarketContextPosition;
        private string premarketContextBias;
        private int premarketContextBiasScore;
        private DateTime lastPremarketContextLogNy;
        private DateTime lastPremarketContextFinalLogDateNy;

        // V1.6.2 - automatic re-entry cooldown / rearm.
        private DateTime lastAutomaticTradeExitNy;
        private DateTime lastAutomaticTradeExitRangeBarTime;
        private bool lastAutomaticTradeExitWasBreakeven;
        private bool lastAutomaticTradeExitWasLoss;
        private string lastAutomaticTradeExitSide;
        private string lastReentryBlockLogKey;
        private string lastPriceChaseBlockLogKey;

        private const int AutomaticReentryCooldownSeconds = 60;

        private bool entryPending;
        private Order entryOrder;
        private Order stopOrder;
        private Order targetOrder;

        private double entryFillPrice;
        private double activeStopPrice;
        private double activeTargetPrice;
        private int entryQuantity;

        private MarketPosition entryMarketPosition;
        private string executionStatus;
// =====================================================
// EXECUTION STATE SYNCHRONIZATION
// =====================================================
// Protects shared execution/order state accessed from
// BarsRequest, OrderUpdate and ExecutionUpdate callbacks.
//
// IMPORTANT:
// Never call Submit(), Change() or Flatten() while holding
// this lock.
//
// V1.6.12 LOCK ORDER / DEADLOCK RULE:
// Prefer snapshot-and-release instead of nesting executionStateLock,
// marketContextLock, emaCacheLock, SharedLearningSyncRoot or persistence
// locks. If a second domain is needed, release the first lock before
// taking the next one. External NinjaTrader order/account calls always
// happen after our locks are released.
private readonly object executionStateLock =
    new object();
     // =====================================================
// TRADE PROTECTION / TRAILING STATE
// =====================================================
private bool activeEntryUsesMomentumTrailing;
private int momentumTrailingStage;
private double lastMomentumTrailingStopPrice;

// V1.6.4 Step 2 - snapshot the BE policy at entry so a later market-state
// change cannot alter the protection rules of an already-open trade.
private bool activeStrongMomentumProtection;
private int activeBreakEvenTriggerTicks;

// Prevent excessive Account.Change() requests.
private DateTime lastMomentumTrailingChangeUtc =
    DateTime.MinValue;


// =====================================================
// DAILY TARGET PROTECTION
// =====================================================
private bool dailyTargetProtectionArmed;
private double lastDailyTargetProtectionStopPrice;

// =====================================================
// V14 - SMART SCALE-IN V1
// =====================================================
private bool smartScaleInUsed;
private bool smartScaleInPending;
private Order smartScaleInOrder;
private int initialTradeQuantity;
private double initialTradeRiskDollars;
private DateTime lastSmartScaleInAttemptUtc =
    DateTime.MinValue;

private const int SmartScaleInTriggerTicks = 70;
private const int SmartScaleInContracts = 1;
private const int SmartScaleInMinMomentumScore = 4;
private const int SmartScaleInMinHtfScore = 1;
private const int SmartScaleInAttemptThrottleMs = 3000;


private DateTime lastDailyTargetProtectionChangeUtc =
    DateTime.MinValue;


// Minimum delay between protective order modifications.
private const int ProtectiveOrderChangeThrottleMs = 500;

// =====================================================
// UNIFIED PROTECTIVE CHANGE COORDINATOR
// =====================================================
private bool protectiveChangeInFlight;

// V7 stability guard:
// Account.CreateOrder() can raise OrderUpdate synchronously while the
// SL/TP bracket is still being constructed. Without this guard,
// OnAccountOrderUpdate -> SyncProtectiveBracketToEntry can re-enter
// SubmitProtectiveBracket before the first bracket is complete,
// creating thousands of JJ_STOP/JJ_TARGET orders and freezing NT.
private bool protectiveBracketBuildInProgress;

private long protectiveChangeSequence;
private long activeProtectiveChangeToken;
private string protectiveChangeOwner;
private DateTime protectiveChangeStartedUtc =
    DateTime.MinValue;

private const int ProtectiveChangeTimeoutMs = 3000;

        // Prop-firm end-of-day protection
        private bool forceFlatSentToday;
        private DateTime forceFlatDateNy;

        // V1.6.8 - premarket transition protection.
        private bool premarketForceFlatSentToday;
        private DateTime premarketForceFlatDateNy;

        private DateTime lastExecutedSignalBar;

        private Account subscribedAccount;

        // =====================================================
        // SESSION PERSISTENCE (legacy field names retained for compatibility)
        // =====================================================
        private bool persistentDailyLocked;

        // V1.6.2 - tells us WHY the daily lock exists.
        private string persistentDailyLockReason;

        private string stateFolderPath;

        // Prevents two windows from running the same Account + Instrument.
        private string activeRuntimeLeaseKey;

        private BarsRequest barsRequest;
        private bool barsRequestSubscribed;

        // Higher timeframe context engines.
        private BarsRequest h1BarsRequest;
        private bool h1BarsRequestSubscribed;
        private bool h1BarsReady;
        private DateTime lastH1BarTime;

        private BarsRequest h4BarsRequest;
        private bool h4BarsRequestSubscribed;
        private bool h4BarsReady;
        private DateTime lastH4BarTime;

        private DateTime lastSignalBarTime;
        private bool barsReady;

        // Internal Range series used ONLY by Momentum Engine.
        // No second chart is required.
        private BarsRequest rangeBarsRequest;
        private bool rangeBarsRequestSubscribed;
        private bool rangeBarsReady;
        private DateTime lastRangeBarTime;

        private readonly object marketContextLock =
            new object();

        // =====================================================
        // INCREMENTAL EMA CACHE
        // =====================================================
        // BarsRequest cannot be fed directly to NinjaTrader EMA.
        // Cache the EMA prefix per Bars instance + period so normal
        // updates are O(1) instead of recomputing from bar 0.
        private sealed class EmaCacheState
        {
            public DateTime FirstBarTime;
            public List<double> Values;

            public EmaCacheState()
            {
                FirstBarTime = DateTime.MinValue;
                Values = new List<double>();
            }
        }

        private readonly object emaCacheLock =
            new object();

        private readonly Dictionary<Bars, Dictionary<int, EmaCacheState>>
            emaCaches =
                new Dictionary<Bars, Dictionary<int, EmaCacheState>>();

        // Higher-timeframe context is informational/scoring only.
        // V1 does NOT use this as a hard entry filter.
        private string latestH4Trend;
        private string latestH1Trend;
        private int latestHtfLongScore;
        private int latestHtfShortScore;
        private string latestHtfContextBias;

        // Latest confirmed M5 context consumed by the Range trigger.
        private bool latestM5ContextReady;
        private bool latestM5BullishTrend;
        private bool latestM5BearishTrend;
        private bool latestM5AboveVwap;
        private bool latestM5BelowVwap;
        private bool latestM5BullishStructure;
        private bool latestM5BearishStructure;
        private string latestM5LiquidityState;
        private string latestM5StructureState;
        private DateTime latestM5DecisionNyTime;
        private double latestM5Vwap;

        // Latest confirmed Range momentum values for UI / logs.
        private int latestRangeLongScore;
        private int latestRangeShortScore;
        private double latestRangeRatio;
        private double latestRangeVolumeRatio;
        private double latestRangeBodyRatio;
        private double latestRangeEmaSlope;
        private bool latestRangeHighBreakout;
        private bool latestRangeLowBreakout;
        private string latestRangeMomentumState;

        // =====================================================
        // LEARNING ENGINE
        // =====================================================
        // V1.6.7 - TWO-LAYER LEARNING
        // Base = official J&J learning distributed by the app updater.
        // User = only this installation's new observations.
        // learningMemory = effective read model (Base + User).
        private JJBotLearningMemory baseLearningMemory;
        private JJBotLearningMemory userLearningMemory;
        private JJBotLearningMemory learningMemory;
        private string learningBaseVersion;
        private JJBotLearningTrade activeLearningTrade;

        // =====================================================
        // V16 - SHARED LEARNING STORE
        // =====================================================
        // All five profile engines share one in-process memory per
        // instrument. The existing pattern key (SIDE + STRUCTURE/SETUP)
        // keeps OPENING, MOMENTUM and STRUCTURE evidence separated.
        private static readonly object SharedLearningSyncRoot =
            new object();

        private static readonly Dictionary<string, JJBotLearningMemory>
            SharedLearningMemories =
                new Dictionary<string, JJBotLearningMemory>(
                    StringComparer.OrdinalIgnoreCase
                );

        // User layer is shared independently so all profiles on the same
        // instrument append to one local delta without ever writing Base.
        private static readonly Dictionary<string, JJBotLearningMemory>
            SharedUserLearningMemories =
                new Dictionary<string, JJBotLearningMemory>(
                    StringComparer.OrdinalIgnoreCase
                );

        // =====================================================
        // V1.6.2 - SHARED LEARNING EVENT DEDUPLICATION
        // =====================================================
        // Several profiles can execute the same market signal on the same
        // instrument. The accounts still trade independently, but the shared
        // Learning memory must count that market event only once.
        //
        // Ownership is deterministic:
        // the lowest participating profile number wins (P1 before P2, etc.).
        // If profile-1 is not participating, the next lowest profile records it.
        private static readonly Dictionary<string, string>
            SharedLearningEventOwners =
                new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase
                );

        private string activeLearningEventKey;

        private string pendingLearningSide;
        private string pendingLearningSession;
        private string pendingLearningStructure;
        private DateTime pendingLearningSignalTimeNy;

        // V1.6.4 Step 6 - after a price-BE exit, keep watching the
        // original TP without sending any order. Multiple trackers may
        // coexist if more than one BE occurs within the observation window.
        private readonly object beFollowThroughLock =
            new object();

        private readonly List<JJBotBreakevenFollowThrough>
            beFollowThroughTrackers =
                new List<JJBotBreakevenFollowThrough>();

        private const int BeFollowThroughWindowMinutes = 30;

        // =====================================================
        // STRUCTURE SETUP CONSUMPTION
        // =====================================================
        // A structure setup is identified by:
        // direction + sweep timestamp + confirmation timestamp.
        //
        // The pending key is attached to the submitted M5 structure
        // entry. It becomes consumed ONLY after the entry actually fills.
        private string pendingStructureSetupKey;
        private DateTime pendingStructureConfirmTime;

        private string consumedBullishStructureSetupKey;
        private string consumedBearishStructureSetupKey;

        // Time frontiers prevent an older already-traded setup from
        // becoming eligible again after a newer setup is consumed.
        private DateTime consumedBullishStructureConfirmTime;
        private DateTime consumedBearishStructureConfirmTime;

        private const int FastEmaPeriod = 9;
        private const int SlowEmaPeriod = 50;
        private const int BarsBack = 200;

        // Higher timeframe trend context.
        private const int HtfFastEmaPeriod = 50;
        private const int HtfSlowEmaPeriod = 200;
        private const int HtfBarsBack = 260;

        // New York session rules
        private const int RthVwapStart = 93000;

        // =====================================================
        // V1.6.8 PREMARKET ENGINE V1
        // =====================================================
        // Momentum-only window. It does NOT consume an AM slot.
        // New entries stop at 09:25 so the bot is flat-or-managed going
        // into the five minutes immediately before the 09:30 cash open.
        private const int PremarketSessionStart = 73000;
        private const int PremarketSessionEnd = 92500;
        private const int PremarketForceFlatTime = 92800;
        private const int PremarketMaxTrades = 1;
        private const int PremarketMomentumMinScore = 4;
        private const int PremarketExtremeMinScore = 3;
        private const double PremarketExtremeMinBodyRatio = 0.75;
        private const double PremarketExtremeMinSlopeTicks = 4.0;
        private const int PremarketMaxChaseTicks = 60;

        // Trading window 1: 09:30 - 11:59:59 ET
        private const int BotSession1Start = 93000;
        private const int BotSession1End = 115959;

        // V13 strict Midday: 12:00 - 13:59:59 ET
        private const int BotMiddayStart = 120000;
        private const int BotMiddayEnd = 135959;
        private const int MiddayMaxTrades = 1;
        private const int MiddayMomentumMinScore = 5;
        private const int MiddayMinHtfAlignmentScore = 1;

        // Trading window 2: 14:00 - 15:30 ET
        private const int BotSession2Start = 140000;
        private const int BotSession2End = 153000;

        // =====================================================
        // V12 OPENING MODE
        // =====================================================
        private const int OpeningRangeStart = 93000;
        private const int OpeningEntryStart = 93500;
        private const int OpeningEntryEnd = 100000;
        private const int OpeningBreakoutBufferTicks = 2;

        // V1.6.4 Step 3 - pre-entry/opening safety context.
        // Pre-entry context is measured before the cash open.
        private const int PreEntryRangeStart = 90000;
        private const int PreEntryRangeEnd = 92959;

        // Guard only pathological opening expansion.
        // If the first 5m opening range is more than 1.25x the full
        // 09:00-09:29 pre-entry range, Opening entries are skipped and
        // HYBRID may fall back to Structure/Momentum.
        private const double OpeningMaxPreEntryExpansionRatio = 1.25;

        // Late-entry tolerances. Range-20 signals are near-real-time,
        // while confirmed M5 Structure/Opening bars can naturally be
        // several minutes old because the bar timestamp is its start.
        private const int MomentumLateEntryMaxSeconds = 90;
        private const int StructureLateEntryMaxSeconds = 420;
        private const int OpeningLateEntryMaxSeconds = 420;

        // =====================================================
        // V1.6.13 - LEARNING DECISION ENGINE
        // =====================================================
        // Existing SIDE + STRUCTURE buckets are preserved. The new layer adds:
        //   1) confidence tiers instead of a single N=15 hard threshold,
        //   2) Bayesian win-rate shrinkage for small samples,
        //   3) recency-weighted evidence (30-day half-life), and
        //   4) ALLOW / CAUTION / BLOCK decisions.
        //
        // Safety rule: learning can only hard-block after a stronger sample.
        // 0-14 = observe, 15-29 = advisory, 30-49 = caution/severe block only,
        // 50+ = full evidence. Existing signal logic, SL/TP and trailing are unchanged.
        private const int LearningObserveTrades = 15;
        private const int LearningCautionTrades = 30;
        private const int LearningStrongTrades = 50;
        private const double LearningSevereExpectancy = -12.00;
        private const double LearningModerateExpectancy = -8.00;
        private const double LearningSevereNetPnL = -180.00;
        private const double LearningModerateNetPnL = -120.00;
        private const double LearningMinWinRate = 30.0;
        private const double LearningBayesianPriorWinRate = 0.50;
        private const double LearningBayesianPriorStrength = 20.0;
        private const double LearningRecencyHalfLifeDays = 30.0;
        private const double LearningRecentMinWeight = 8.0;

        // Compatibility aliases retained for existing UI/log text paths.
        private const int LearningMinTrades = LearningObserveTrades;
        private const double LearningMinExpectancy = LearningModerateExpectancy;
        private const double LearningMinNetPnL = LearningModerateNetPnL;

        // =====================================================
        // LIQUIDITY / STRUCTURE RULES
        // =====================================================
        private const int SweepLookback = 5;
        private const int SweepMaxAgeBars = 6;

        // Keep the structural swing anchored to the SAME reference
        // window used to define the sweep. This prevents silent
        // desynchronization if SweepLookback is changed later.
        private const int StructureLookback = SweepLookback;

        // Ignore one-tick micro sweeps/noise.
        private const int MinimumSweepTicks = 2;

        // Momentum Engine V2 rules (confirmed internal Range bars only)
        private const int MomentumAverageLookback = 10;
        private const int MomentumBreakoutLookback = 3;
        private const double MomentumRangeExpansion = 1.15;
        private const double MomentumVolumeExpansion = 1.20;
        private const double MomentumMinBodyRatio = 0.60;
        private const int MomentumMinScore = 4;

        // =====================================================
        // V1.6.9 - AGGRESSIVE EXPANSION ENGINE
        // =====================================================
        // Detects a FRESH price/volume expansion from native bar data.
        // This is not Level 2 order-flow; it is a fast aggression proxy
        // using body, range expansion, relative volume, EMA velocity,
        // breakout and multi-bar displacement.
        private const int AggressionMinScore = 4;
        private const double AggressionMinBodyRatio = 0.70;
        private const double AggressionMinRangeRatio = 1.30;
        private const double AggressionMinVolumeRatio = 1.20;
        private const double AggressionMinSlopeTicks = 5.0;
        private const int AggressionLookbackBars = 3;
        private const int AggressionMinDirectionalBars = 2;
        private const double AggressionMinDisplacementTicks = 35.0;

        // Once the directional move is already very mature, ordinary
        // Momentum entries are vetoed unless a NEW aggressive expansion
        // is actually present. 800 ticks = 200 points on MNQ/NQ.
        private const double ExhaustionMinMoveTicks = 800.0;
        private const double ExhaustionMaxWeakVolumeRatio = 1.00;
        private const double ExhaustionMaxWeakBodyRatio = 0.55;
        private const int ExhaustionSessionScanMaxBars = 240;

        // V1.6.5 - EARLY EXTREME MOMENTUM OVERRIDE.
        // This does NOT lower the normal Momentum threshold globally.
        // A 3/5 signal is actionable only when it also has breakout,
        // strong body, strong EMA slope and VWAP alignment.
        private const int ExtremeMomentumMinScore = 3;
        private const double ExtremeMomentumMinBodyRatio = 0.75;
        private const double ExtremeMomentumMinSlopeTicks = 4.0;
        // V1.6.10: the 2026-08-19 session showed that a 3/5 breakout with
        // very weak participation (example ~0.55x volume) can be a bad chase,
        // while ~1.15x still produced valid follow-through. Keep 3/5, but require
        // at least normal participation before the Extreme fast path may enter.
        private const double ExtremeMomentumMinVolumeRatio = 1.00;

        // V1.6.11 - SMART RETEST ENTRY ENGINE. EMA9 remains only one anti-chase
        // reference. Actual re-entry confirmation can come from price structure.
        private const double PullbackMaxExtensionTicks3of5 = 40.0;
        private const double PullbackMaxExtensionTicks4Plus = 60.0;
        private const int SmartRetestWindowSeconds = 300;
        private const int SmartRetestLevelToleranceTicks = 12;
        private const int SmartRetestStructureToleranceTicks = 16;
        private const int SmartRetestMinResumeScore = 2;
        private const int SmartRetestMicroPullbackLookback = 3;

        // Premarket opening-context interpretation. Context is confirmation,
        // not a hard standalone trade trigger.
        private const double PremarketStrongBiasPosition = 0.67;
        private const double PremarketWeakBiasPosition = 0.55;
        private const int PremarketContextMinBars = 6;

        // V1.6.10 - STRUCTURE MATURE-MOVE GUARD.
        // Structure can stay 4/4 after a large move. If continuation evidence is
        // weak, do not sell/buy the tail of an already mature directional leg.
        private const double StructureExhaustionMinMoveTicks = 400.0;
        private const int StructureExhaustionMaxMomentumScore = 2;
        private const double StructureExhaustionMaxVolumeRatio = 1.00;

        // Opening breakout must still be fresh.  Once price has travelled
        // more than 50% of the opening-range width beyond the breakout
        // boundary, the Opening entry is skipped instead of chasing price.
        private const double OpeningMaxChaseRangeFraction = 0.50;
        private const int OpeningMinChaseTicks = 20;

        // A strong new Momentum signal may re-arm early after a PRICE BE
        // exit. Losses still observe the full normal cooldown.
        private const int StrongMomentumReentryMinSeconds = 20;

        private const int MomentumRangeTicks = 20;

        // Trade Capital Protection V3 - Adaptive / Staged
        // Standard setup:
        // +40 ticks  -> Break Even
        //
        // Strong Momentum setup (4/5+, aligned breakout, volume >= 1.50x):
        // +60 ticks  -> Break Even
        //
        // V1.6.10: give valid runners more room after the 2026-08-19 case
        // where +70t was locked at +30t and the market later continued strongly.
        // Both modes then use staged protection:
        // +100 ticks -> Lock +30 ticks
        // +140 ticks -> Lock +70 ticks
        // +180 ticks -> Trail 60 ticks behind price
        //
        // IMPORTANT: every stop update is still filtered by
        // EnforceNeverWorsenStop(), so protection can never move backwards.
        private const int MomentumBreakEvenTriggerTicks = 40;
        private const int StrongMomentumBreakEvenTriggerTicks = 60;
        private const int StrongMomentumMinScore = 4;
        private const double StrongMomentumMinVolumeRatio = 1.50;

        private const int MomentumLockTriggerTicks = 100;
        private const int MomentumLockProfitTicks = 30;

        private const int MomentumLock2TriggerTicks = 140;
        private const int MomentumLock2ProfitTicks = 70;

        private const int MomentumTrailTriggerTicks = 180;
        private const int MomentumTrailDistanceTicks = 60;

        // Dynamic target: the configured target is the MAXIMUM target.
        private const int DynamicTargetMinTicks = 60;
        private const double DynamicTargetMediumFactor = 0.80;
        private const double DynamicTargetWeakFactor = 0.65;

        // Once the daily target is reached, protect most of it
        // instead of immediately flattening a profitable runner.
        private const double DailyTargetGivebackDollars = 50.0;
        private const int DailyTargetTrailDistanceTicks = 20;

        // V1.6.4 dynamic daily/session profit floor.
        // Once the day has reached at least $50 (or 20% of the configured
        // daily target, whichever is greater), retain 50% of the best
        // total PnL reached. Example: peak +$60 => protected floor +$30.
        private const double DailyProfitFloorActivationMinDollars = 50.0;
        private const double DailyProfitFloorTargetActivationFactor = 0.20;
        private const double DailyProfitFloorRetentionFactor = 0.50;
        private const double DailyProfitFloorLogStepDollars = 10.0;

        // Force flat at 16:25 ET for prop-firm safety.
        private const int ForceFlatTimeNy = 162500;
        // V1.6.14: a new CME-style trading/risk session begins at 18:00 ET.
        // FORCE FLAT and all session-scoped counters/profit protection are released here.
        private const int TradingSessionResetTimeNy = 180000;

        // =====================================================
        // BACKGROUND ENGINE WINDOW LIFECYCLE
        // =====================================================
        private bool allowPermanentClose;
        private bool engineWindowAlive;

        public bool IsEngineWindowAlive
        {
            get
            {
                return engineWindowAlive;
            }
        }

        // =====================================================
        // CONSTRUCTOR
        // =====================================================
        public JJBotWindow(
            string profileId = "profile-1",
            bool isPrimaryProfileWindow = true)
        {
            platformProfileId =
                string.IsNullOrWhiteSpace(
                    profileId
                )
                    ? "profile-1"
                    : profileId
                        .Trim()
                        .ToLowerInvariant();

            primaryProfileWindow =
                isPrimaryProfileWindow;

            Caption =
                "J&J NY Trading Bot - "
                + platformProfileId;

            allowPermanentClose = false;
            engineWindowAlive = true;

            Width = 520;
            Height = 960;

            MinWidth = 480;
            MinHeight = 720;

            botRunning = false;
            activeDirection = "BOTH";
            activeStrategyMode = "HYBRID";
            autoResolvedDirection = "BOTH";
            autoDirectionReason = "MANUAL BOTH";
            lastLoggedAutoDirection = string.Empty;
            lastLoggedAutoDirectionReason = string.Empty;
            lastAutoDirectionLogUtc = DateTime.MinValue;

            currentSignalState =
                "WAITING";

            currentSetupState =
                "WAITING";

            activeContracts = 1;
            activeStopTicks = 100;
            activeTargetTicks = 150;
            activeMaxTrades = 2;
            activeDailyTarget = 300;
            activeDailyLoss = 200;
            activeDollarRiskCap = 100;

            tradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
            pendingEntryRequestedQuantity = 0;
            pendingEntryIsManualTest = false;
            activeTradeIsManualTest = false;

            pendingEntryIsOpening = false;
            activeTradeIsOpening = false;
            pendingEntryIsPremarket = false;
            activeTradeIsPremarket = false;
            openingTradeTakenToday = false;
            openingRangeReady = false;
            openingRangeHigh = 0;
            openingRangeLow = 0;
            openingRangeBarTimeNy = DateTime.MinValue;

            premarketRangeReady = false;
            premarketRangeHigh = 0;
            premarketRangeLow = 0;
            premarketRangeDateNy = DateTime.MinValue;
            premarketRangeLastM5TimeNy = DateTime.MinValue;
            lastPremarketChaseBlockLogKey = string.Empty;
            premarketContextReady = false;
            premarketContextDateNy = DateTime.MinValue;
            premarketContextBias = "NEUTRAL";
            premarketContextBiasScore = 0;
            lastPremarketContextLogNy = DateTime.MinValue;
            lastPremarketContextFinalLogDateNy = DateTime.MinValue;
            pendingSmartRetestActive = false;
            pendingSmartRetestReason = string.Empty;
            pendingSmartRetestStructureSetupKey = string.Empty;
            lastSmartRetestLogKey = string.Empty;

            preEntryRangeReady = false;
            preEntryRangeHigh = 0;
            preEntryRangeLow = 0;
            preEntryRangeDateNy = DateTime.MinValue;
            openingRangeGuardBlocked = false;
            openingRangeGuardReason = string.Empty;
            openingRangeGuardDateNy = DateTime.MinValue;
            lastLateEntryBlockLogKey = string.Empty;
            openingRangeLoggedDate = DateTime.MinValue;

            botDailyGrossPnL = 0;
            botDailyFees = 0;
            botDailyPnL = 0;
            botUnrealizedPnL = 0;
            dailyPeakTotalPnL = 0;
            dailyProtectedProfitFloor = 0;
            dailyProfitFloorArmed = false;
            lastLoggedProtectedProfitFloor = 0;
            activeTradingDate = DateTime.MinValue;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;
            lastLearningBlockedLogKey = string.Empty;

            lastAutomaticTradeExitNy =
                DateTime.MinValue;

            lastAutomaticTradeExitRangeBarTime =
                DateTime.MinValue;

            lastAutomaticTradeExitWasBreakeven =
                false;

            lastReentryBlockLogKey =
                string.Empty;

            lastPriceChaseBlockLogKey =
                string.Empty;

            entryPending = false;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;

            activeEntryUsesMomentumTrailing = false;
            momentumTrailingStage = 0;
            lastMomentumTrailingStopPrice = 0;
            activeStrongMomentumProtection = false;
            activeBreakEvenTriggerTicks =
                MomentumBreakEvenTriggerTicks;
            lastMomentumTrailingChangeUtc = DateTime.MinValue;
			
            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;
            lastDailyTargetProtectionChangeUtc = DateTime.MinValue;

            smartScaleInUsed = false;
            smartScaleInPending = false;
            smartScaleInOrder = null;
            initialTradeQuantity = 0;
            initialTradeRiskDollars = 0;
            lastSmartScaleInAttemptUtc = DateTime.MinValue;

            protectiveChangeInFlight = false;
            protectiveBracketBuildInProgress = false;
            protectiveChangeSequence = 0;
            activeProtectiveChangeToken = 0;
            protectiveChangeOwner = string.Empty;
            protectiveChangeStartedUtc =
                DateTime.MinValue;

            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;
            premarketForceFlatSentToday = false;
            premarketForceFlatDateNy = DateTime.MinValue;

            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            lastExecutedSignalBar = DateTime.MinValue;

            subscribedAccount = null;

            visualLogLines =
                new Queue<string>();

            platformTelemetryTimer = null;
            platformTelemetryRequestInFlight = false;
            platformApiKey = string.Empty;
            platformServerUrl = "http://localhost:3001";
            platformConfigFile = string.Empty;
            lastPlatformTelemetrySuccessUtc =
                DateTime.MinValue;

            platformCommandTimer = null;
            platformCommandRequestInFlight = false;
            lastProcessedPlatformCommandId =
                string.Empty;

            platformRemoteStartContext =
                false;

            PrintBotMessage(
                "PROFILE ENGINE READY"
                + " | "
                + platformProfileId
                + " | Prefix: "
                + GetProfileOrderPrefix()
            );

            persistentDailyLocked = false;
            persistentDailyLockReason = string.Empty;

            activeRuntimeLeaseKey =
                string.Empty;

            stateFolderPath =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments
                    ),
                    "NinjaTrader 8",
                    "JJBotData"
                );

            barsReady = false;
            barsRequestSubscribed = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            h1BarsRequestSubscribed = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            h4BarsRequestSubscribed = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            rangeBarsRequestSubscribed = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestM5ContextReady = false;
            latestM5LiquidityState = "NONE";
            latestM5StructureState = "WAITING";
            latestRangeMomentumState = "WAITING RANGE";

            baseLearningMemory =
                new JJBotLearningMemory();

            userLearningMemory =
                new JJBotLearningMemory();

            learningMemory =
                new JJBotLearningMemory();

            learningBaseVersion =
                "NONE";

            activeLearningTrade = null;
            activeLearningEventKey = string.Empty;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            Content = BuildInterface();

            Closing += OnBotWindowClosing;
            Closed += OnBotWindowClosed;

            LoadPlatformBridgeConfig();
            StartPlatformTelemetry();
            StartPlatformCommandPolling();
        }

        // =====================================================
        // MAIN INTERFACE
        // =====================================================
        private UIElement BuildInterface()
        {
            ScrollViewer scroll = new ScrollViewer();

            scroll.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            Border mainBorder = new Border();

            mainBorder.Padding =
                new Thickness(22);

            mainBorder.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        12,
                        17,
                        24
                    )
                );

            StackPanel mainPanel =
                new StackPanel();

            mainBorder.Child = mainPanel;
            scroll.Content = mainBorder;

            // =================================================
            // HEADER
            // =================================================
            TextBlock title = new TextBlock();

            title.Text =
                "J&J NY TRADING BOT";

            title.FontSize = 24;

            title.FontWeight =
                FontWeights.Bold;

            title.Foreground =
                Brushes.White;

            title.HorizontalAlignment =
                HorizontalAlignment.Center;

            title.Margin =
                new Thickness(
                    0,
                    5,
                    0,
                    3
                );

            mainPanel.Children.Add(title);

            TextBlock subtitle =
                new TextBlock();

            subtitle.Text =
                "AUTOMATED FUTURES ENGINE";

            subtitle.FontSize = 11;

            subtitle.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            subtitle.HorizontalAlignment =
                HorizontalAlignment.Center;

            subtitle.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    20
                );

            mainPanel.Children.Add(subtitle);

            // =================================================
            // TRADING CONNECTION
            // =================================================
            Border connectionCard =
                CreateCard();

            StackPanel connectionPanel =
                new StackPanel();

            connectionCard.Child =
                connectionPanel;

            connectionPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING CONNECTION"
                )
            );

            // ACCOUNT SELECTOR
            accountSelector =
                new AccountSelector();

            accountSelector.Width = 230;
            accountSelector.Height = 30;

            accountSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            accountSelector.SelectionChanged +=
                AccountSelectorChanged;

            AddRow(
                connectionPanel,
                "Account",
                accountSelector
            );

            // INSTRUMENT SELECTOR
            instrumentSelector =
                new InstrumentSelector();

            instrumentSelector.Width = 230;
            instrumentSelector.Height = 30;

            instrumentSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            instrumentSelector.InstrumentChanged +=
                InstrumentSelectorChanged;

            AddRow(
                connectionPanel,
                "Instrument",
                instrumentSelector
            );

            accountStatusText =
                CreateSmallStatusText(
                    "No account selected"
                );

            connectionPanel.Children.Add(
                accountStatusText
            );

            instrumentStatusText =
                CreateSmallStatusText(
                    "No instrument selected"
                );

            connectionPanel.Children.Add(
                instrumentStatusText
            );

            mainPanel.Children.Add(
                connectionCard
            );

            // =================================================
            // BOT STATUS
            // =================================================
            Border statusCard =
                CreateCard();

            StackPanel statusPanel =
                new StackPanel();

            statusCard.Child =
                statusPanel;

            statusPanel.Children.Add(
                CreateSectionTitle(
                    "BOT STATUS"
                )
            );

            statusText =
                new TextBlock();

            statusText.Text =
                "● STOPPED";

            statusText.FontSize = 20;

            statusText.FontWeight =
                FontWeights.Bold;

            statusText.Foreground =
                Brushes.OrangeRed;

            statusText.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    2
                );

            statusPanel.Children.Add(
                statusText
            );

            mainPanel.Children.Add(
                statusCard
            );

            TextBlock executionModeText =
                new TextBlock();

            executionModeText.Text =
                "EXECUTION MODE  •  SIM ONLY";

            executionModeText.Foreground =
                Brushes.Goldenrod;

            executionModeText.FontWeight =
                FontWeights.Bold;

            executionModeText.FontSize = 11;

            executionModeText.HorizontalAlignment =
                HorizontalAlignment.Center;

            executionModeText.Margin =
                new Thickness(
                    0,
                    -4,
                    0,
                    12
                );

            mainPanel.Children.Add(
                executionModeText
            );

            // =================================================
            // TRADING SETTINGS
            // =================================================
            Border settingsCard =
                CreateCard();

            StackPanel settingsPanel =
                new StackPanel();

            settingsCard.Child =
                settingsPanel;

            settingsPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING SETTINGS"
                )
            );

            directionCombo =
                new ComboBox();

            directionCombo.Items.Add(
                "BOTH"
            );

            directionCombo.Items.Add(
                "AUTO"
            );

            directionCombo.Items.Add(
                "LONG ONLY"
            );

            directionCombo.Items.Add(
                "SHORT ONLY"
            );

            directionCombo.SelectedIndex = 0;

            directionCombo.Width = 150;
            directionCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Direction",
                directionCombo
            );

            strategyCombo =
                new ComboBox();

            strategyCombo.Items.Add(
                "STRUCTURE"
            );

            strategyCombo.Items.Add(
                "MOMENTUM SCALP"
            );

            strategyCombo.Items.Add(
                "OPENING"
            );

            strategyCombo.Items.Add(
                "HYBRID"
            );

            strategyCombo.SelectedIndex = 3;
            strategyCombo.Width = 150;
            strategyCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Strategy",
                strategyCombo
            );

            contractsBox =
                CreateTextBox("1");

            AddRow(
                settingsPanel,
                "Contracts",
                contractsBox
            );

            stopBox =
                CreateTextBox("100");

            AddRow(
                settingsPanel,
                "Stop Loss (ticks)",
                stopBox
            );

            targetBox =
                CreateTextBox("150");

            AddRow(
                settingsPanel,
                "Profit Target (ticks)",
                targetBox
            );

            maxTradesBox =
                CreateTextBox("2");

            AddRow(
                settingsPanel,
                "Max Trades / Session",
                maxTradesBox
            );

            mainPanel.Children.Add(
                settingsCard
            );

            // =================================================
            // RISK MANAGEMENT
            // =================================================
            Border riskCard =
                CreateCard();

            StackPanel riskPanel =
                new StackPanel();

            riskCard.Child =
                riskPanel;

            riskPanel.Children.Add(
                CreateSectionTitle(
                    "RISK MANAGEMENT"
                )
            );

            dailyTargetBox =
                CreateTextBox("300");

            AddRow(
                riskPanel,
                "Daily Target $",
                dailyTargetBox
            );

            dailyLossBox =
                CreateTextBox("200");

            AddRow(
                riskPanel,
                "Daily Loss $",
                dailyLossBox
            );

            dollarRiskCapBox =
                CreateTextBox("100");

            AddRow(
                riskPanel,
                "Dollar Risk Cap $",
                dollarRiskCapBox
            );

            mainPanel.Children.Add(
                riskCard
            );

            // =================================================
            // SIGNAL ENGINE
            // =================================================
            Border signalCard =
                CreateCard();

            StackPanel signalPanel =
                new StackPanel();

            signalCard.Child =
                signalPanel;

            signalPanel.Children.Add(
                CreateSectionTitle(
                    "SIGNAL ENGINE - 5 MINUTE"
                )
            );

            lastPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Last Price",
                lastPriceText
            );

            emaFastText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 9",
                emaFastText
            );

            emaSlowText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 50",
                emaSlowText
            );

            vwapText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Session VWAP",
                vwapText
            );

            trendText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Trend",
                trendText
            );

            nySessionText =
                CreateValueText(
                    "CLOSED"
                );

            AddInfoRow(
                signalPanel,
                "NY Session",
                nySessionText
            );

            liquidityText =
                CreateValueText(
                    "NONE"
                );

            AddInfoRow(
                signalPanel,
                "Liquidity Sweep",
                liquidityText
            );

            structureText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Structure",
                structureText
            );

            momentumText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Momentum",
                momentumText
            );

            confirmationText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Confirmation",
                confirmationText
            );

            setupText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Setup",
                setupText
            );

            barTimeText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "5m Bar",
                barTimeText
            );

            mainPanel.Children.Add(
                signalCard
            );

            // =================================================
            // EXECUTION MONITOR
            // =================================================
            Border executionCard =
                CreateCard();

            StackPanel executionPanel =
                new StackPanel();

            executionCard.Child =
                executionPanel;

            executionPanel.Children.Add(
                CreateSectionTitle(
                    "EXECUTION MONITOR"
                )
            );

            positionText =
                CreateValueText(
                    "FLAT"
                );

            AddInfoRow(
                executionPanel,
                "Position",
                positionText
            );

            positionQtyText =
                CreateValueText(
                    "0"
                );

            AddInfoRow(
                executionPanel,
                "Position Qty",
                positionQtyText
            );

            entryPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Entry Price",
                entryPriceText
            );

            stopPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Stop Loss",
                stopPriceText
            );

            targetPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Profit Target",
                targetPriceText
            );

            riskRewardText =
                CreateValueText(
                    "1 : 1.50"
                );

            AddInfoRow(
                executionPanel,
                "Risk / Reward",
                riskRewardText
            );

            orderStatusText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                executionPanel,
                "Order Status",
                orderStatusText
            );

            mainPanel.Children.Add(
                executionCard
            );

            // =================================================
            // LIVE SESSION
            // =================================================
            Border infoCard =
                CreateCard();

            StackPanel infoPanel =
                new StackPanel();

            infoCard.Child =
                infoPanel;

            infoPanel.Children.Add(
                CreateSectionTitle(
                    "LIVE SESSION"
                )
            );

            grossPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Gross PnL",
                grossPnlText
            );

            feesPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Commissions / Fees",
                feesPnlText
            );

            pnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Net Realized PnL",
                pnlText
            );

            unrealizedPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Unrealized PnL",
                unrealizedPnlText
            );

            totalPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Total PnL",
                totalPnlText
            );

            tradesText =
                CreateValueText(
                    "0 / 2"
                );

            AddInfoRow(
                infoPanel,
                "Trades",
                tradesText
            );

            signalText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                infoPanel,
                "Signal",
                signalText
            );

            mainPanel.Children.Add(
                infoCard
            );

            // =================================================
            // BOT ACTIVITY LOG
            // =================================================
            Border logCard =
                CreateCard();

            StackPanel logPanel =
                new StackPanel();

            logCard.Child =
                logPanel;

            Grid logHeader =
                new Grid();

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        GridLength.Auto
                }
            );

            TextBlock logTitle =
                CreateSectionTitle(
                    "BOT ACTIVITY LOG"
                );

            Grid.SetColumn(
                logTitle,
                0
            );

            logHeader.Children.Add(
                logTitle
            );

            clearLogButton =
                new Button();

            clearLogButton.Content =
                "CLEAR";

            clearLogButton.Width =
                65;

            clearLogButton.Height =
                24;

            clearLogButton.FontSize =
                10;

            clearLogButton.Margin =
                new Thickness(
                    8,
                    0,
                    0,
                    0
                );

            clearLogButton.Click +=
                ClearVisualLogClicked;

            Grid.SetColumn(
                clearLogButton,
                1
            );

            logHeader.Children.Add(
                clearLogButton
            );

            logPanel.Children.Add(
                logHeader
            );

            visualLogBox =
                new TextBox();

            visualLogBox.IsReadOnly =
                true;

            visualLogBox.AcceptsReturn =
                true;

            visualLogBox.TextWrapping =
                TextWrapping.Wrap;

            visualLogBox.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            visualLogBox.HorizontalScrollBarVisibility =
                ScrollBarVisibility.Disabled;

            visualLogBox.Height =
                190;

            visualLogBox.Margin =
                new Thickness(
                    0,
                    10,
                    0,
                    0
                );

            visualLogBox.Padding =
                new Thickness(8);

            visualLogBox.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        10,
                        15,
                        22
                    )
                );

            visualLogBox.Foreground =
                Brushes.LightGray;

            visualLogBox.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            visualLogBox.BorderThickness =
                new Thickness(1);

            visualLogBox.FontFamily =
                new FontFamily(
                    "Consolas"
                );

            visualLogBox.FontSize =
                11;

            logPanel.Children.Add(
                visualLogBox
            );

            mainPanel.Children.Add(
                logCard
            );

            AppendVisualLog(
                "Visual log ready."
            );

            // =================================================
            // TEST EXECUTION
            // SIM ONLY
            // =================================================
            Border testCard =
                CreateCard();

            StackPanel testPanel =
                new StackPanel();

            testCard.Child =
                testPanel;

            testPanel.Children.Add(
                CreateSectionTitle(
                    "TEST EXECUTION - SIM ONLY"
                )
            );

            TextBlock testHelp =
                new TextBlock();

            testHelp.Text =
                "Use only to verify Entry → SL/TP → OCO → Monitor.";

            testHelp.TextWrapping =
                TextWrapping.Wrap;

            testHelp.Foreground =
                Brushes.Gray;

            testHelp.FontSize = 10;

            testHelp.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    10
                );

            testPanel.Children.Add(
                testHelp
            );

            Grid testGrid =
                new Grid();

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testLongButton =
                CreateButton(
                    "TEST LONG"
                );

            testLongButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            testLongButton.Click +=
                TestLongClicked;

            Grid.SetColumn(
                testLongButton,
                0
            );

            testGrid.Children.Add(
                testLongButton
            );

            testShortButton =
                CreateButton(
                    "TEST SHORT"
                );

            testShortButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            testShortButton.Click +=
                TestShortClicked;

            Grid.SetColumn(
                testShortButton,
                1
            );

            testGrid.Children.Add(
                testShortButton
            );

            testPanel.Children.Add(
                testGrid
            );

            mainPanel.Children.Add(
                testCard
            );

            // =================================================
            // START / STOP
            // =================================================
            Grid buttonGrid =
                new Grid();

            buttonGrid.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    10
                );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            startButton =
                CreateButton(
                    "▶ START BOT"
                );

            startButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            startButton.Click +=
                StartBotClicked;

            Grid.SetColumn(
                startButton,
                0
            );

            buttonGrid.Children.Add(
                startButton
            );

            stopButton =
                CreateButton(
                    "■ STOP BOT"
                );

            stopButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            stopButton.IsEnabled =
                false;

            stopButton.Click +=
                StopBotClicked;

            Grid.SetColumn(
                stopButton,
                1
            );

            buttonGrid.Children.Add(
                stopButton
            );

            mainPanel.Children.Add(
                buttonGrid
            );

            // =================================================
            // CLOSE ALL
            // TEST MODE ONLY
            // =================================================
            closeAllButton =
                CreateButton(
                    "⚠ CLOSE ALL"
                );

            closeAllButton.FontSize = 15;

            closeAllButton.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    15
                );

            closeAllButton.Click +=
                CloseAllClicked;

            mainPanel.Children.Add(
                closeAllButton
            );

            TextBlock warning =
                new TextBlock();

            warning.Text =
                "SIM EXECUTION • PERSISTENCE V5 • VISUAL LOG ACTIVE • orders ONLY to accounts containing Sim.";

            warning.TextWrapping =
                TextWrapping.Wrap;

            warning.HorizontalAlignment =
                HorizontalAlignment.Center;

            warning.TextAlignment =
                TextAlignment.Center;

            warning.Foreground =
                Brushes.Goldenrod;

            warning.FontSize = 10;

            warning.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    8
                );

            mainPanel.Children.Add(
                warning
            );

            TextBlock footer =
                new TextBlock();

            footer.Text =
                "NY • OPENING 09:35-10:00 • AM • MIDDAY STRICT 12:00-14:00 • PM • TRAILING + LEARNING";

            footer.HorizontalAlignment =
                HorizontalAlignment.Center;

            footer.Foreground =
                Brushes.Gray;

            footer.FontSize = 11;

            mainPanel.Children.Add(
                footer
            );

            return scroll;
        }

        // =====================================================
        // ACCOUNT CHANGED
        // =====================================================
        private void AccountSelectorChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (accountSelector == null)
                return;

            Account previousAccount =
                selectedAccount;

            Account newAccount =
                accountSelector.SelectedAccount;

            bool accountChanged =
                previousAccount != null
                ? (
                    newAccount == null ||
                    !string.Equals(
                        previousAccount.Name,
                        newAccount.Name,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                : newAccount != null;

            // =====================================================
            // SAFETY: ACCOUNT CHANGES MUST STOP THE ACTIVE ENGINE
            // =====================================================
            // Bars callbacks and Account.ExecutionUpdate / OrderUpdate
            // must never point at different accounts.
            if (
                accountChanged &&
                botRunning
            )
            {
                botRunning =
                    false;

                StopBarsEngine();

                ReleaseRuntimeLease();

                // Immediately detach callbacks from the OLD account.
                UnsubscribeExecutionAccount();

                currentSignalState =
                    "ACCOUNT CHANGED";

                currentSetupState =
                    "STOPPED";

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "ACCOUNT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;

                if (accountSelector != null)
                    accountSelector.IsEnabled = true;

                if (instrumentSelector != null)
                    instrumentSelector.IsEnabled = true;

                PrintBotMessage(
                    "BOT STOPPED - ACCOUNT CHANGED."
                );
            }

            // Even if the main signal engine was already stopped (for
            // example after a manual SIM test), never keep callbacks
            // subscribed to an account that is no longer selected.
            if (
                accountChanged &&
                !botRunning
            )
            {
                UnsubscribeExecutionAccount();
            }

            // Remove the OLD bridge state before the selection is replaced.
            if (
                accountChanged &&
                previousAccount != null &&
                selectedInstrument != null
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    previousAccount.Name,
                    selectedInstrument.FullName
                );
            }

            selectedAccount =
                newAccount;

            if (selectedAccount != null)
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "Account: "
                        + selectedAccount.Name;

                    accountStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "ACCOUNT SELECTED: "
                    + selectedAccount.Name
                );

                PublishSharedState();
            }
            else
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "No account selected";

                    accountStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            // Restore only AFTER the engine has been stopped and the
            // new Account + Instrument selection is stable.
            TryRestorePersistentStateForSelection();
        }

        // =====================================================
        // INSTRUMENT CHANGED
        // =====================================================
        private void InstrumentSelectorChanged(
            object sender,
            EventArgs e)
        {
            if (instrumentSelector == null)
                return;

            Instrument previousInstrument =
                selectedInstrument;

            Instrument newInstrument =
                instrumentSelector.Instrument;

            // Remove the OLD bridge entry before publishing the newly
            // selected instrument. Otherwise the old chart can keep a
            // stale snapshot forever.
            if (
                selectedAccount != null &&
                previousInstrument != null &&
                (
                    newInstrument == null ||
                    !string.Equals(
                        previousInstrument.FullName,
                        newInstrument.FullName,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    selectedAccount.Name,
                    previousInstrument.FullName
                );
            }

            // If the bot is running, stop the old data subscription first.
            if (botRunning)
            {
                StopBarsEngine();

                botRunning = false;

                ReleaseRuntimeLease();

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "INSTRUMENT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;
            }

            selectedInstrument =
                newInstrument;

            if (selectedInstrument != null)
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "Instrument: "
                        + selectedInstrument.FullName;

                    instrumentStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "INSTRUMENT SELECTED: "
                    + selectedInstrument.FullName
                );

                PublishSharedState();
            }
            else
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "No instrument selected";

                    instrumentStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            ResetSignalDisplay();
            ResetExecutionMonitor();

            TryRestorePersistentStateForSelection();
        }

        // =====================================================
        // TEST LONG / SHORT
        // SIM ONLY
        // =====================================================
        private void TestLongClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                true
            );
        }

        private void TestShortClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                false
            );
        }

        private void RunManualSimTest(
            bool isLong)
        {
            // When TEST LONG / TEST SHORT comes from J&J Company Bro,
            // ApplyPlatformStartConfiguration() has already resolved the
            // exact Account + Instrument selected in the platform.
            //
            // Do NOT overwrite them with the hidden NinjaTrader selectors
            // (which may still display Sim101).
            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;

                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select a SIM account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (
                !IsSimulationAccount(
                    selectedAccount
                )
            )
            {
                MessageBox.Show(
                    "TEST EXECUTION is SIM ONLY.\\n\\n"
                    + "Select an account whose name begins with 'Sim'.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;
            double dollarRiskCap;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                ) ||
                contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                ) ||
                stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                ) ||
                targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                ) ||
                maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                ) ||
                dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                ) ||
                dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                dollarRiskCapBox == null ||
                !double.TryParse(
                    dollarRiskCapBox.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out dollarRiskCap
                ) ||
                dollarRiskCap <= 0 ||
                dollarRiskCap > MaxDollarRiskCapAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Dollar Risk Cap. Maximum: "
                    + MaxDollarRiskCapAllowed.ToString("$0.00")
                    + "."
                );

                return;
            }

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            activeDollarRiskCap =
                dollarRiskCap;

            // Subscribe even when the main signal engine is STOPPED.
            SubscribeExecutionAccount(
                selectedAccount
            );

            // IMPORTANT:
            // TEST LONG / TEST SHORT must use the same persistent
            // counters as automatic trading. Otherwise reopening the
            // window could incorrectly start manual tests from 0 / 2.
            LoadOrResetPersistentDailyState();

            if (persistentDailyLocked)
            {
                // Manual TEST LONG / TEST SHORT are SIM-only diagnostics.
                // They are intentionally allowed even when the normal
                // automatic engine is DailyLocked (for example after 16:25 ET),
                // so configurations can be tested at night.
                PrintBotMessage(
                    "MANUAL SIM TEST - DAILY LOCK BYPASSED"
                    + " | Trades: "
                    + tradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                );
            }

            // Give the manual test its own temporary execution permission.
            bool wasRunning =
                botRunning;

            botRunning =
                true;

            executionStatus =
                isLong
                    ? "TEST LONG"
                    : "TEST SHORT";

            UpdateExecutionMonitor();

            DateTime uniqueTestSignal =
                DateTime.UtcNow;

         TrySubmitEntry(
    isLong,
    uniqueTestSignal,
    true
);

            // Keep the signal engine's previous RUNNING/STOPPED state.
            // The submitted order and its OCO bracket continue to be
            // managed by Account.ExecutionUpdate independently.
            botRunning =
                wasRunning;

            PrintBotMessage(
                "MANUAL SIM TEST REQUESTED | "
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
            );
        }

        // =====================================================
        // START BOT
        // =====================================================
        private void StartBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;
            }

            if (selectedAccount == null)
            {
                MessageBox.Show(
                    "Select an account before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (!IsSimulationAccount(selectedAccount))
            {
                MessageBox.Show(
                    "SIM ONLY protection is active.\n\n"
                    + "The selected account is not recognized as a simulation account.\n"
                    + "Select an account whose name begins with 'Sim'.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                PrintBotMessage(
                    "LIVE ACCOUNT BLOCKED: "
                    + selectedAccount.Name
                );

                return;
            }

            if (!platformRemoteStartContext)
            {
                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (selectedInstrument == null)
            {
                MessageBox.Show(
                    "Select an instrument before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;
            double dollarRiskCap;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                )
                || contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                )
                || stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                )
                || targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                )
                || maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                )
                || dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                )
                || dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                dollarRiskCapBox == null ||
                !double.TryParse(
                    dollarRiskCapBox.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out dollarRiskCap
                ) ||
                dollarRiskCap <= 0 ||
                dollarRiskCap > MaxDollarRiskCapAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Dollar Risk Cap. Maximum: "
                    + MaxDollarRiskCapAllowed.ToString("$0.00")
                    + "."
                );

                return;
            }

            string requestedLeaseKey;

            if (
                !JJBotRuntimeCoordinator.TryAcquireBotLease(
                    selectedAccount.Name,
                    selectedInstrument.FullName,
                    out requestedLeaseKey
                )
            )
            {
                MessageBox.Show(
                    "Another J&J Bot window is already running this same "
                    + "Account + Instrument.\n\n"
                    + "Account: "
                    + selectedAccount.Name
                    + "\nInstrument: "
                    + selectedInstrument.FullName
                    + "\n\nStop or close the other bot window before starting this one.",
                    "J&J Trading Bot - DUPLICATE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                PrintBotMessage(
                    "START BLOCKED - DUPLICATE ACCOUNT + INSTRUMENT"
                    + " | Account: "
                    + selectedAccount.Name
                    + " | Instrument: "
                    + selectedInstrument.FullName
                );

                return;
            }

            activeRuntimeLeaseKey =
                requestedLeaseKey;

            activeDirection =
                directionCombo != null &&
                directionCombo.SelectedItem != null
                    ? directionCombo.SelectedItem.ToString()
                    : "BOTH";

            activeStrategyMode =
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
                    ? strategyCombo.SelectedItem.ToString()
                    : "HYBRID";

            string direction =
                activeDirection;

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            activeDollarRiskCap =
                dollarRiskCap;

            // Do NOT reset tradesToday / botDailyPnL here.
            // They belong to the persistent daily state and are
            // restored below by LoadOrResetPersistentDailyState().
            botUnrealizedPnL = 0;
            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;
            lastLearningBlockedLogKey = string.Empty;

            entryPending = false;
            pendingEntryRequestedQuantity = 0;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;
            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            SubscribeExecutionAccount(
                selectedAccount
            );

            LoadOrResetPersistentDailyState();

            tradesText.Text =
                tradesToday
                + " / "
                + activeMaxTrades;

            UpdatePnlDisplay();

            ResetExecutionMonitor();

            // V1.6.14R - POSITION RECOVERY / TRAILING RESUME
            // If NinjaTrader/account still has an open position after the
            // desktop app or bot was stopped/restarted, adopt that real
            // position BEFORE the signal engine begins looking for entries.
            // Existing protective orders are reused and the stop is never
            // moved backwards.
            bool recoveredExistingPosition =
                TryRecoverExistingPosition();

            signalText.Text =
                recoveredExistingPosition
                    ? "RECOVERED POSITION - LOADING MARKET DATA..."
                    : "LOADING 5M DATA...";

            signalText.Foreground =
                Brushes.Goldenrod;

            statusText.Text =
                "● STARTING";

            statusText.Foreground =
                Brushes.Goldenrod;

            startButton.IsEnabled =
                false;

            stopButton.IsEnabled =
                true;

            botRunning = true;

            if (!recoveredExistingPosition)
            {
                StartPositionRecoveryRetry();
            }
            else
            {
                StopPositionRecoveryRetry();
            }

            currentSignalState =
                recoveredExistingPosition
                    ? "POSITION RECOVERED"
                    : "LOADING 5M DATA...";

            currentSetupState =
                "STARTING";

            PublishSharedState();

            if (directionCombo != null)
                directionCombo.IsEnabled = false;

            if (accountSelector != null)
                accountSelector.IsEnabled = false;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = false;

            LoadLearningMemory();

            PrintBotMessage(
                "LEARNING DECISION ENGINE V1.6.13 ACTIVE"
                + " | SHARED ACROSS PROFILES BY INSTRUMENT"
                + " | Hierarchy: SPECIFIC(SIDE+STRUCTURE) > SIDE > GLOBAL"
                + " | Observe: "
                + LearningObserveTrades
                + " | Caution: "
                + LearningCautionTrades
                + " | Strong: "
                + LearningStrongTrades
                + " | Block A: Exp < "
                + LearningMinExpectancy.ToString("$0.00")
                + " & Net < "
                + LearningMinNetPnL.ToString("$0.00")
                + " | Block B: WinRate < "
                + LearningMinWinRate.ToString("0")
                + "% & Exp < $0"
            );

            PrintBotMessage(
                "STARTING"
                + " | Account: "
                + selectedAccount.Name
                + " | Instrument: "
                + selectedInstrument.FullName
                + " | Direction: "
                + direction
                + " | Strategy: "
                + activeStrategyMode
                + " | Contracts: "
                + contracts
                + " | SL: "
                + stopTicks
                + " ticks"
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxTrades: "
                + maxTrades
                + " | DailyTarget: $"
                + dailyTarget
                + " | DailyLoss: $"
                + dailyLoss
                + " | DollarRiskCap: "
                + activeDollarRiskCap.ToString("$0.00")
                + " | StrategyClockNY: "
                + GetCurrentNewYorkTime()
                    .ToString("HH:mm:ss")
                + " ET"
            );

            StartBarsEngine();
        }

        // =====================================================
        // START 5-MINUTE DATA ENGINE
        // =====================================================
        private void StartBarsEngine()
        {
            StopBarsEngine();

            barsReady = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestM5ContextReady = false;
            latestRangeMomentumState = "WAITING RANGE";

            try
            {
                barsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                barsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 5
                    };

                // Neutral template for data collection.
                // We enforce the NY bot time window separately later.
                barsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                barsRequest.Update +=
                    OnBarsRequestUpdate;

                barsRequestSubscribed = true;

                barsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnBarsRequestCompleted
                    )
                );

                // 1-HOUR CONTEXT
                h1BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h1BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 60
                    };

                h1BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h1BarsRequest.Update +=
                    OnH1BarsRequestUpdate;

                h1BarsRequestSubscribed = true;

                h1BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH1BarsRequestCompleted
                    )
                );

                // 4-HOUR CONTEXT
                h4BarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        HtfBarsBack
                    );

                h4BarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Minute,

                        Value = 240
                    };

                h4BarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                h4BarsRequest.Update +=
                    OnH4BarsRequestUpdate;

                h4BarsRequestSubscribed = true;

                h4BarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnH4BarsRequestCompleted
                    )
                );

                // Internal 20-tick Range series. This is independent
                // from the chart the user has open.
                rangeBarsRequest =
                    new BarsRequest(
                        selectedInstrument,
                        BarsBack
                    );

                rangeBarsRequest.BarsPeriod =
                    new BarsPeriod
                    {
                        BarsPeriodType =
                            BarsPeriodType.Range,

                        Value = MomentumRangeTicks
                    };

                rangeBarsRequest.TradingHours =
                    TradingHours.Get(
                        "Default 24 x 7"
                    );

                rangeBarsRequest.Update +=
                    OnRangeBarsRequestUpdate;

                rangeBarsRequestSubscribed = true;

                rangeBarsRequest.Request(
                    new Action<BarsRequest, ErrorCode, string>(
                        OnRangeBarsRequestCompleted
                    )
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BARS REQUEST EXCEPTION: "
                    + ex.Message
                );

                SetEngineError(
                    "DATA ERROR"
                );
            }
        }

        // =====================================================
        // INITIAL HISTORICAL BARS LOADED
        // =====================================================
        private void OnBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "BARS REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "DATA ERROR"
                        );
                    })
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count < SlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 5M BARS TO CALCULATE EMA 50."
                );

                Dispatcher.InvokeAsync(
                    new Action(() =>
                    {
                        SetEngineError(
                            "WAITING FOR DATA"
                        );
                    })
                );

                return;
            }

            barsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            // Do not fire a historical crossover immediately at startup.
            lastSignalBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateSignalFromBars(
                request.Bars,
                false
            );

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    statusText.Text =
                        "● RUNNING";

                    statusText.Foreground =
                        Brushes.LimeGreen;
                })
            );

            PrintBotMessage(
                "5M DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL 1H CONTEXT BARS LOADED
        // =====================================================
        private void OnH1BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "1H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 1H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h1BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "1H",
                false
            );

            PrintBotMessage(
                "1H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL 4H CONTEXT BARS LOADED
        // =====================================================
        private void OnH4BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "4H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 4H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h4BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "4H",
                false
            );

            PrintBotMessage(
                "4H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // INITIAL INTERNAL RANGE BARS LOADED
        // =====================================================
        private void OnRangeBarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "RANGE REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH RANGE BARS FOR MOMENTUM."
                );

                return;
            }

            rangeBarsReady = true;

            int lastIndex =
                request.Bars.Count - 1;

            lastRangeBarTime =
                request.Bars.GetTime(
                    lastIndex
                );

            UpdateMomentumFromRangeBars(
                request.Bars,
                false
            );

            PrintBotMessage(
                "RANGE DATA READY | "
                + MomentumRangeTicks
                + " TICKS | BARS: "
                + request.Bars.Count
            );
        }

        // =====================================================
        // REAL-TIME 1H CONTEXT UPDATE EVENT
        // =====================================================
        private void OnH1BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h1BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h1BarsRequest == null ||
                    h1BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h1BarsRequest.Bars,
                    "1H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "1H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // REAL-TIME 4H CONTEXT UPDATE EVENT
        // =====================================================
        private void OnH4BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h4BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h4BarsRequest == null ||
                    h4BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h4BarsRequest.Bars,
                    "4H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "4H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // HIGHER-TIMEFRAME CONTEXT ENGINE
        //
        // Uses the latest CLOSED 1H / 4H bar.
        // Trend model:
        //   Strong bullish: Close > EMA50 > EMA200
        //   Strong bearish: Close < EMA50 < EMA200
        //   Weak bullish:   EMA50 > EMA200
        //   Weak bearish:   EMA50 < EMA200
        //
        // IMPORTANT: this context does NOT block entries in V1.
        // It is published visually and available to learning.
        // =====================================================
        private void UpdateHigherTimeframeContext(
            Bars bars,
            string timeframe,
            bool realTimeUpdate)
        {
            if (
                bars == null ||
                bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                return;
            }

            int closedIndex =
                bars.Count - 2;

            if (
                closedIndex <
                    HtfSlowEmaPeriod
            )
            {
                return;
            }

            DateTime closedTime =
                bars.GetTime(
                    closedIndex
                );

            if (
                timeframe == "1H" &&
                closedTime ==
                    lastH1BarTime
            )
            {
                return;
            }

            if (
                timeframe == "4H" &&
                closedTime ==
                    lastH4BarTime
            )
            {
                return;
            }

            double ema50 =
                CalculateEma(
                    bars,
                    HtfFastEmaPeriod,
                    closedIndex
                );

            double ema200 =
                CalculateEma(
                    bars,
                    HtfSlowEmaPeriod,
                    closedIndex
                );

            double close =
                bars.GetClose(
                    closedIndex
                );

            string trend =
                close > ema50 &&
                ema50 > ema200
                    ? "BULLISH"
                    : close < ema50 &&
                      ema50 < ema200
                        ? "BEARISH"
                        : ema50 > ema200
                            ? "BULLISH WEAK"
                            : ema50 < ema200
                                ? "BEARISH WEAK"
                                : "NEUTRAL";

            lock (marketContextLock)
            {
                if (timeframe == "1H")
                {
                    latestH1Trend =
                        trend;

                    lastH1BarTime =
                        closedTime;
                }
                else
                {
                    latestH4Trend =
                        trend;

                    lastH4BarTime =
                        closedTime;
                }

                RecalculateHigherTimeframeScores();
            }

            PrintBotMessage(
                "HTF CONTEXT "
                + timeframe
                + " | "
                + trend
                + " | Close: "
                + close.ToString("0.00")
                + " | EMA50: "
                + ema50.ToString("0.00")
                + " | EMA200: "
                + ema200.ToString("0.00")
                + " | LONG "
                + latestHtfLongScore
                + "/2"
                + " | SHORT "
                + latestHtfShortScore
                + "/2"
            );

            PublishSharedState();
        }

        private void RecalculateHigherTimeframeScores()
        {
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            latestHtfContextBias =
                latestHtfLongScore >
                    latestHtfShortScore
                    ? "LONG "
                        + latestHtfLongScore
                        + "/2"
                    : latestHtfShortScore >
                        latestHtfLongScore
                        ? "SHORT "
                            + latestHtfShortScore
                            + "/2"
                        : "NEUTRAL "
                            + latestHtfLongScore
                            + "/2";
        }

        // =====================================================
        // REAL-TIME INTERNAL RANGE UPDATE EVENT
        // =====================================================
        private void OnRangeBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !rangeBarsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count <
                        MomentumAverageLookback +
                        MomentumBreakoutLookback + 3
                )
                {
                    return;
                }

                DateTime currentRangeBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newRangeBarStarted =
                    lastRangeBarTime != DateTime.MinValue &&
                    currentRangeBarTime != lastRangeBarTime;

                if (
                    rangeBarsRequest == null ||
                    rangeBarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateMomentumFromRangeBars(
                    rangeBarsRequest.Bars,
                    newRangeBarStarted
                );

                // Capital protection is evaluated on every Range update,
                // not only when a new Range bar closes.
                int liveRangeIndex =
                    rangeBarsRequest.Bars.Count - 1;

                if (liveRangeIndex >= 0)
                {
                    double liveRangePrice =
                        rangeBarsRequest.Bars.GetClose(
                            liveRangeIndex
                        );

                    double liveRangeHigh =
                        rangeBarsRequest.Bars.GetHigh(
                            liveRangeIndex
                        );

                    double liveRangeLow =
                        rangeBarsRequest.Bars.GetLow(
                            liveRangeIndex
                        );

                    DateTime liveRangeNy =
                        ConvertToNewYorkTime(
                            rangeBarsRequest.Bars.GetTime(
                                liveRangeIndex
                            )
                        );

                    UpdateBreakevenFollowThrough(
                        liveRangeHigh,
                        liveRangeLow,
                        liveRangeNy
                    );

                    UpdateUnrealizedPnL(
                        liveRangePrice
                    );

                    // Daily target protection has priority over
                    // the normal per-trade trailing logic.
                    UpdateDailyTargetProtection(
                        liveRangePrice
                    );

                    UpdateMomentumTrailingStop(
                        liveRangePrice
                    );

                    TrySmartScaleIn(
                        liveRangePrice
                    );

                    CheckForceFlatTime();
                    CheckDailyLossEmergency();
                }

                if (newRangeBarStarted)
                {
                    lastRangeBarTime =
                        currentRangeBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "RANGE UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // REAL-TIME BAR UPDATE EVENT
        // =====================================================
        private void OnBarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            if (
                !botRunning ||
                !barsReady ||
                e == null ||
                e.BarsSeries == null
            )
            {
                return;
            }

            try
            {
                int count =
                    e.BarsSeries.Count;

                if (
                    count < SlowEmaPeriod + 2
                )
                {
                    return;
                }

                DateTime currentBarTime =
                    e.BarsSeries.GetTime(
                        count - 1
                    );

                bool newBarStarted =
                    lastSignalBarTime != DateTime.MinValue &&
                    currentBarTime != lastSignalBarTime;

                // Update current bias/EMA display on every real-time bar update.
                if (barsRequest == null || barsRequest.Bars == null)
                    return;

                UpdateSignalFromBars(
                    barsRequest.Bars,
                    newBarStarted
                );

                if (newBarStarted)
                {
                    lastSignalBarTime =
                        currentBarTime;
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "BAR UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // CALCULATE EMA 9 / EMA 50
        // =====================================================
        // =====================================================
        // V12 - OPENING MODE HELPERS
        // =====================================================
        private bool IsOpeningBuildWindow(
            DateTime nyTime)
        {
            if (
                activeStrategyMode != "HYBRID" &&
                activeStrategyMode != "OPENING"
            )
            {
                return false;
            }

            int timeValue =
                nyTime.Hour * 10000
                + nyTime.Minute * 100
                + nyTime.Second;

            return
                timeValue >= OpeningRangeStart &&
                timeValue < OpeningEntryStart;
        }

        private bool IsOpeningEntryWindow(
            DateTime nyTime)
        {
            int timeValue =
                nyTime.Hour * 10000
                + nyTime.Minute * 100
                + nyTime.Second;

            return
                timeValue >= OpeningEntryStart &&
                timeValue < OpeningEntryEnd;
        }

        private bool IsOpeningPriorityActive(
            DateTime nyTime)
        {
            if (
                activeStrategyMode != "HYBRID" &&
                activeStrategyMode != "OPENING"
            )
            {
                return false;
            }

            if (openingTradeTakenToday)
            {
                return false;
            }

            return IsOpeningEntryWindow(
                nyTime
            );
        }

        // =====================================================
        // V1.6.8 PREMARKET RANGE
        // =====================================================
        private bool TryBuildPremarketRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex <= 0
            )
            {
                return false;
            }

            // Exclude the newest closed M5 bar. The fast Range engine can
            // then detect a true breakout beyond the latest completed
            // premarket frontier instead of comparing price to itself.
            int endIndex =
                Math.Max(
                    0,
                    closedBarIndex - 1
                );

            double high =
                double.MinValue;

            double low =
                double.MaxValue;

            int matchedBars = 0;
            DateTime lastMatchedNy =
                DateTime.MinValue;

            for (
                int i = 0;
                i <= endIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date !=
                        nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeValue <
                        PremarketSessionStart ||
                    timeValue >
                        PremarketSessionEnd
                )
                {
                    continue;
                }

                high =
                    Math.Max(
                        high,
                        bars.GetHigh(i)
                    );

                low =
                    Math.Min(
                        low,
                        bars.GetLow(i)
                    );

                matchedBars++;
                lastMatchedNy =
                    barNy;
            }

            if (
                matchedBars <= 0 ||
                high == double.MinValue ||
                low == double.MaxValue ||
                high <= low
            )
            {
                return false;
            }

            premarketRangeReady =
                true;

            premarketRangeHigh =
                high;

            premarketRangeLow =
                low;

            premarketRangeDateNy =
                nyTradingDate;

            premarketRangeLastM5TimeNy =
                lastMatchedNy;

            return true;
        }

        // =====================================================
        // V1.6.11 - PREMARKET CONTEXT ENGINE
        // =====================================================
        private bool UpdatePremarketContextFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0 ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return false;
            }

            double high = double.MinValue;
            double low = double.MaxValue;
            double firstOpen = 0;
            double lastClose = 0;
            int barsCount = 0;
            int bullBars = 0;
            int bearBars = 0;
            List<double> closes = new List<double>();

            for (int i = 0; i <= closedBarIndex; i++)
            {
                DateTime barNy = ConvertToNewYorkTime(bars.GetTime(i));
                if (barNy.Date != nyTradingDate)
                    continue;

                int tv = ToTimeInt(barNy);
                if (tv < PremarketSessionStart || tv > PremarketSessionEnd)
                    continue;

                double o = bars.GetOpen(i);
                double h = bars.GetHigh(i);
                double l = bars.GetLow(i);
                double c = bars.GetClose(i);

                if (barsCount == 0)
                    firstOpen = o;

                high = Math.Max(high, h);
                low = Math.Min(low, l);
                lastClose = c;
                closes.Add(c);
                barsCount++;

                if (c > o) bullBars++;
                else if (c < o) bearBars++;
            }

            if (barsCount <= 0 || high <= low)
                return false;

            double mid = (high + low) / 2.0;
            int upper = 0;
            int lower = 0;
            foreach (double c in closes)
            {
                if (c > mid) upper++;
                else if (c < mid) lower++;
            }

            double tickSize = selectedInstrument.MasterInstrument.TickSize;
            double position = (lastClose - low) / (high - low);
            position = Math.Max(0, Math.Min(1, position));

            int biasScore = 0;
            if (lastClose > firstOpen) biasScore++;
            else if (lastClose < firstOpen) biasScore--;
            if (bullBars > bearBars) biasScore++;
            else if (bearBars > bullBars) biasScore--;
            if (upper > lower) biasScore++;
            else if (lower > upper) biasScore--;
            if (position >= PremarketStrongBiasPosition) biasScore++;
            else if (position <= 1.0 - PremarketStrongBiasPosition) biasScore--;

            string bias =
                biasScore >= 3 ? "BULLISH" :
                biasScore <= -3 ? "BEARISH" :
                biasScore > 0 ? "BULLISH-LEAN" :
                biasScore < 0 ? "BEARISH-LEAN" : "NEUTRAL";

            premarketContextReady = barsCount >= PremarketContextMinBars;
            premarketContextDateNy = nyTradingDate;
            premarketContextOpen = firstOpen;
            premarketContextLastClose = lastClose;
            premarketContextMid = mid;
            premarketContextRangeTicks = tickSize > 0 ? (high - low) / tickSize : 0;
            premarketContextBars = barsCount;
            premarketBullBars = bullBars;
            premarketBearBars = bearBars;
            premarketUpperHalfCloses = upper;
            premarketLowerHalfCloses = lower;
            premarketContextPosition = position;
            premarketContextBias = bias;
            premarketContextBiasScore = biasScore;

            DateTime nowNy = GetCurrentNewYorkTime();
            bool openingSnapshot = ToTimeInt(nowNy) >= 92500;
            bool finalNotLogged = lastPremarketContextFinalLogDateNy.Date != nyTradingDate.Date;
            bool periodic = lastPremarketContextLogNy == DateTime.MinValue ||
                (nowNy - lastPremarketContextLogNy).TotalMinutes >= 30;

            if (premarketContextReady && (periodic || (openingSnapshot && finalNotLogged)))
            {
                bool finalSnapshot = openingSnapshot && finalNotLogged;
                lastPremarketContextLogNy = nowNy;
                if (finalSnapshot)
                    lastPremarketContextFinalLogDateNy = nyTradingDate.Date;

                PrintBotMessage(
                    (finalSnapshot ? "PREMARKET CONTEXT READY FOR OPEN" : "PREMARKET CONTEXT UPDATE")
                    + " | High: " + high.ToString("0.00")
                    + " | Low: " + low.ToString("0.00")
                    + " | Mid: " + mid.ToString("0.00")
                    + " | Range: " + premarketContextRangeTicks.ToString("0") + "t"
                    + " | LastPos: " + (position * 100.0).ToString("0") + "%"
                    + " | Bull/Bear M5: " + bullBars + "/" + bearBars
                    + " | Upper/Lower closes: " + upper + "/" + lower
                    + " | Bias: " + bias + " (" + biasScore + ")"
                );
            }

            return true;
        }

        private bool TryGetLatestM5StructureBreakLevel(
            Bars bars,
            int closedBarIndex,
            bool isLong,
            out double level)
        {
            level = 0;
            if (bars == null || closedBarIndex < SweepLookback + StructureLookback)
                return false;

            int firstSweepIndex = Math.Max(SweepLookback, closedBarIndex - SweepMaxAgeBars);
            int bestConfirm = -1;
            double bestLevel = 0;

            for (int sweepIndex = firstSweepIndex; sweepIndex <= closedBarIndex; sweepIndex++)
            {
                int priorStart = Math.Max(0, sweepIndex - SweepLookback);
                int priorEnd = sweepIndex - 1;
                if (priorEnd <= priorStart) continue;

                double priorLow = GetLowestLow(bars, priorStart, priorEnd);
                double priorHigh = GetHighestHigh(bars, priorStart, priorEnd);
                double sweepLow = bars.GetLow(sweepIndex);
                double sweepHigh = bars.GetHigh(sweepIndex);
                double sweepClose = bars.GetClose(sweepIndex);
                double tickSize = selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize : 0;
                if (tickSize <= 0) return false;

                bool sweep = isLong
                    ? (priorLow - sweepLow >= MinimumSweepTicks * tickSize && sweepClose > priorLow)
                    : (sweepHigh - priorHigh >= MinimumSweepTicks * tickSize && sweepClose < priorHigh);
                if (!sweep) continue;

                int structureStart = Math.Max(0, sweepIndex - StructureLookback);
                double structureLevel = isLong
                    ? GetHighestHigh(bars, structureStart, sweepIndex - 1)
                    : GetLowestLow(bars, structureStart, sweepIndex - 1);

                for (int confirmIndex = sweepIndex + 1; confirmIndex <= closedBarIndex; confirmIndex++)
                {
                    double c = bars.GetClose(confirmIndex);
                    bool confirmed = isLong ? c > structureLevel : c < structureLevel;
                    if (confirmed)
                    {
                        if (confirmIndex >= bestConfirm)
                        {
                            bestConfirm = confirmIndex;
                            bestLevel = structureLevel;
                        }
                        break;
                    }
                }
            }

            if (bestConfirm < 0 || bestLevel <= 0)
                return false;

            level = bestLevel;
            return true;
        }

        private bool IsPremarketPriceChaseBlocked(
            bool isLong,
            double price,
            out double extensionTicks)
        {
            extensionTicks = 0;

            if (
                !premarketRangeReady ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return false;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
            {
                return false;
            }

            double extensionPoints =
                isLong
                    ? price -
                        premarketRangeHigh
                    : premarketRangeLow -
                        price;

            extensionTicks =
                Math.Max(
                    0,
                    extensionPoints /
                        tickSize
                );

            return
                extensionTicks >
                    PremarketMaxChaseTicks;
        }

        private void LogPremarketPriceChaseBlock(
            bool isLong,
            DateTime signalNy,
            double price,
            double extensionTicks)
        {
            string key =
                signalNy.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                  )
                + "|"
                + Math.Round(
                    extensionTicks
                ).ToString(
                    CultureInfo.InvariantCulture
                );

            if (
                key ==
                    lastPremarketChaseBlockLogKey
            )
            {
                return;
            }

            lastPremarketChaseBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - PREMARKET PRICE EXTENDED"
                + " | Side: "
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                  )
                + " | Price: "
                + price.ToString(
                    "0.00",
                    CultureInfo.InvariantCulture
                )
                + " | Extension: "
                + extensionTicks.ToString(
                    "0",
                    CultureInfo.InvariantCulture
                )
                + "t"
                + " | Max: "
                + PremarketMaxChaseTicks
                + "t"
            );
        }

        private bool TryBuildPreEntryRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0
            )
            {
                return false;
            }

            double high = double.MinValue;
            double low = double.MaxValue;
            int matchedBars = 0;

            for (
                int i = 0;
                i <= closedBarIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date != nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeValue < PreEntryRangeStart ||
                    timeValue > PreEntryRangeEnd
                )
                {
                    continue;
                }

                high =
                    Math.Max(
                        high,
                        bars.GetHigh(i)
                    );

                low =
                    Math.Min(
                        low,
                        bars.GetLow(i)
                    );

                matchedBars++;
            }

            if (
                matchedBars <= 0 ||
                high <= low
            )
            {
                return false;
            }

            bool shouldLog =
                !preEntryRangeReady ||
                preEntryRangeDateNy !=
                    nyTradingDate;

            preEntryRangeReady = true;
            preEntryRangeHigh = high;
            preEntryRangeLow = low;
            preEntryRangeDateNy =
                nyTradingDate;

            if (shouldLog)
            {
                PrintBotMessage(
                    "PRE-ENTRY RANGE READY"
                    + " | 09:00-09:29 ET"
                    + " | High: "
                    + preEntryRangeHigh.ToString("0.00")
                    + " | Low: "
                    + preEntryRangeLow.ToString("0.00")
                    + " | Width: "
                    + (
                        preEntryRangeHigh -
                        preEntryRangeLow
                      ).ToString("0.00")
                );
            }

            return true;
        }

        private void EvaluateOpeningRangeGuard(
            DateTime nyTradingDate)
        {
            if (
                !openingRangeReady ||
                !preEntryRangeReady ||
                preEntryRangeDateNy !=
                    nyTradingDate
            )
            {
                openingRangeGuardBlocked = false;
                openingRangeGuardReason =
                    string.Empty;
                openingRangeGuardDateNy =
                    nyTradingDate;

                return;
            }

            double preEntryWidth =
                preEntryRangeHigh -
                preEntryRangeLow;

            double openingWidth =
                openingRangeHigh -
                openingRangeLow;

            if (
                preEntryWidth <= 0 ||
                openingWidth <= 0
            )
            {
                openingRangeGuardBlocked = false;
                openingRangeGuardReason =
                    string.Empty;
                openingRangeGuardDateNy =
                    nyTradingDate;

                return;
            }

            double expansionRatio =
                openingWidth /
                preEntryWidth;

            bool blocked =
                expansionRatio >
                    OpeningMaxPreEntryExpansionRatio;

            bool changed =
                openingRangeGuardDateNy !=
                    nyTradingDate ||
                openingRangeGuardBlocked !=
                    blocked;

            openingRangeGuardBlocked =
                blocked;

            openingRangeGuardReason =
                blocked
                    ? "OPENING OVEREXTENDED "
                        + expansionRatio.ToString("0.00")
                        + "x PRE-ENTRY"
                    : string.Empty;

            openingRangeGuardDateNy =
                nyTradingDate;

            if (changed)
            {
                PrintBotMessage(
                    blocked
                        ? "OPENING RANGE GUARD BLOCKED"
                            + " | Opening: "
                            + openingWidth.ToString("0.00")
                            + " | PreEntry: "
                            + preEntryWidth.ToString("0.00")
                            + " | Ratio: "
                            + expansionRatio.ToString("0.00")
                            + "x"
                            + " | HYBRID FALLBACK ALLOWED"
                        : "OPENING RANGE GUARD READY"
                            + " | Opening/PreEntry Ratio: "
                            + expansionRatio.ToString("0.00")
                            + "x"
                );
            }
        }

        private bool IsLateAutomaticEntry(
            DateTime signalNyTime,
            bool momentumEntry,
            bool openingEntry,
            out int ageSeconds,
            out int maxSeconds)
        {
            ageSeconds = 0;
            maxSeconds =
                momentumEntry
                    ? MomentumLateEntryMaxSeconds
                    : openingEntry
                        ? OpeningLateEntryMaxSeconds
                        : StructureLateEntryMaxSeconds;

            DateTime strategyClockNy =
                GetCurrentNewYorkTime();

            double rawAgeSeconds =
                (
                    strategyClockNy -
                    signalNyTime
                ).TotalSeconds;

            // A bar timestamp can be a few seconds ahead because of feed/
            // scheduler timing. Never classify a future timestamp as late.
            ageSeconds =
                Math.Max(
                    0,
                    (int)Math.Floor(
                        rawAgeSeconds
                    )
                );

            return
                ageSeconds >
                    maxSeconds;
        }

        private bool TryBuildOpeningRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0
            )
            {
                return false;
            }

            int bestIndex = -1;
            DateTime bestNyTime =
                DateTime.MaxValue;

            for (
                int i = 0;
                i <= closedBarIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date != nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    barNy.Hour * 10000
                    + barNy.Minute * 100
                    + barNy.Second;

                if (
                    timeValue < OpeningRangeStart ||
                    timeValue >= 94000
                )
                {
                    continue;
                }

                if (barNy < bestNyTime)
                {
                    bestNyTime = barNy;
                    bestIndex = i;
                }
            }

            if (bestIndex < 0)
            {
                return false;
            }

            double candidateHigh =
                bars.GetHigh(
                    bestIndex
                );

            double candidateLow =
                bars.GetLow(
                    bestIndex
                );

            if (
                candidateHigh <= candidateLow
            )
            {
                return false;
            }

            openingRangeHigh =
                candidateHigh;

            openingRangeLow =
                candidateLow;

            openingRangeBarTimeNy =
                bestNyTime;

            openingRangeReady =
                true;

            EvaluateOpeningRangeGuard(
                nyTradingDate
            );

            if (
                openingRangeLoggedDate !=
                    nyTradingDate
            )
            {
                openingRangeLoggedDate =
                    nyTradingDate;

                PrintBotMessage(
                    "OPENING RANGE READY"
                    + " | "
                    + bestNyTime.ToString("HH:mm")
                    + " ET"
                    + " | High: "
                    + openingRangeHigh.ToString("0.00")
                    + " | Low: "
                    + openingRangeLow.ToString("0.00")
                );
            }

            return true;
        }

        private bool IsOpeningPriceChaseBlocked(
            bool isLong,
            double currentPrice,
            out double extensionPoints,
            out double maxExtensionPoints)
        {
            extensionPoints = 0;
            maxExtensionPoints = 0;

            if (
                !openingRangeReady ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                openingRangeHigh <= openingRangeLow
            )
            {
                return false;
            }

            double tickSize =
                selectedInstrument.MasterInstrument.TickSize;

            if (tickSize <= 0)
                return false;

            double openingWidth =
                openingRangeHigh -
                openingRangeLow;

            maxExtensionPoints =
                Math.Max(
                    openingWidth *
                        OpeningMaxChaseRangeFraction,
                    tickSize *
                        OpeningMinChaseTicks
                );

            extensionPoints =
                isLong
                    ? Math.Max(
                        0,
                        currentPrice -
                            openingRangeHigh
                      )
                    : Math.Max(
                        0,
                        openingRangeLow -
                            currentPrice
                      );

            return
                extensionPoints >
                    maxExtensionPoints;
        }

        private void LogOpeningPriceChaseBlock(
            bool isLong,
            DateTime nyTime,
            double currentPrice,
            double extensionPoints,
            double maxExtensionPoints)
        {
            string key =
                nyTime.ToString(
                    "yyyyMMddHHmm"
                )
                + "|"
                + (isLong ? "LONG" : "SHORT")
                + "|"
                + Math.Round(
                    extensionPoints,
                    2
                  ).ToString(
                    CultureInfo.InvariantCulture
                  );

            if (key == lastPriceChaseBlockLogKey)
                return;

            lastPriceChaseBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - OPENING PRICE EXTENDED"
                + " | Side: "
                + (isLong ? "LONG" : "SHORT")
                + " | Price: "
                + currentPrice.ToString("0.00")
                + " | OR High: "
                + openingRangeHigh.ToString("0.00")
                + " | OR Low: "
                + openingRangeLow.ToString("0.00")
                + " | Extension: "
                + extensionPoints.ToString("0.00")
                + " pts"
                + " | Max: "
                + maxExtensionPoints.ToString("0.00")
                + " pts"
            );
        }

        private string ResolveEffectiveDirection(
            DateTime nyTime,
            double referencePrice,
            bool bullishTrend,
            bool bearishTrend,
            bool aboveVwap,
            bool belowVwap)
        {
            if (
                !string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                autoResolvedDirection =
                    activeDirection;

                autoDirectionReason =
                    "MANUAL "
                    + activeDirection;

                return activeDirection;
            }

            string resolved =
                "NONE";

            string reason =
                "NO CLEAR CONTEXT";

            if (
                IsOpeningEntryWindow(nyTime) &&
                premarketContextReady &&
                premarketContextDateNy == nyTime.Date
            )
            {
                bool pmBull = premarketContextBiasScore >= 2;
                bool pmBear = premarketContextBiasScore <= -2;

                if (pmBull && bullishTrend && aboveVwap && referencePrice >= premarketContextMid)
                {
                    resolved = "LONG ONLY";
                    reason = "PREMARKET " + premarketContextBias
                        + " + ABOVE PM MID + BULLISH + ABOVE VWAP";
                }
                else if (pmBear && bearishTrend && belowVwap && referencePrice <= premarketContextMid)
                {
                    resolved = "SHORT ONLY";
                    reason = "PREMARKET " + premarketContextBias
                        + " + BELOW PM MID + BEARISH + BELOW VWAP";
                }
            }

            if (
                resolved == "NONE" &&
                IsOpeningEntryWindow(
                    nyTime
                ) &&
                preEntryRangeReady &&
                preEntryRangeHigh >
                    preEntryRangeLow
            )
            {
                double midpoint =
                    (
                        preEntryRangeHigh +
                        preEntryRangeLow
                    ) / 2.0;

                if (
                    referencePrice > midpoint &&
                    bullishTrend &&
                    aboveVwap
                )
                {
                    resolved =
                        "LONG ONLY";

                    reason =
                        "PRE-ENTRY ABOVE MID + BULLISH + ABOVE VWAP";
                }
                else if (
                    referencePrice < midpoint &&
                    bearishTrend &&
                    belowVwap
                )
                {
                    resolved =
                        "SHORT ONLY";

                    reason =
                        "PRE-ENTRY BELOW MID + BEARISH + BELOW VWAP";
                }
            }

            if (resolved == "NONE")
            {
                if (
                    bullishTrend &&
                    aboveVwap &&
                    !bearishTrend
                )
                {
                    resolved =
                        "LONG ONLY";

                    reason =
                        "M5 BULLISH + ABOVE VWAP";
                }
                else if (
                    bearishTrend &&
                    belowVwap &&
                    !bullishTrend
                )
                {
                    resolved =
                        "SHORT ONLY";

                    reason =
                        "M5 BEARISH + BELOW VWAP";
                }
            }

            // V1.6.14 LOG FIX
            // IMPORTANT: compare against the LAST LOGGED state, not against
            // autoResolvedDirection. The fast Range engine is allowed to set
            // autoResolvedDirection temporarily (for Aggressive/Extreme R20),
            // so comparing against the live state caused repeated
            // "Resolved: NONE" messages in the same second.
            bool directionChanged =
                !string.Equals(
                    lastLoggedAutoDirection,
                    resolved,
                    StringComparison.OrdinalIgnoreCase
                );

            autoResolvedDirection =
                resolved;

            autoDirectionReason =
                reason;

            if (directionChanged)
            {
                lastLoggedAutoDirection =
                    resolved;

                lastLoggedAutoDirectionReason =
                    reason;

                lastAutoDirectionLogUtc =
                    DateTime.UtcNow;

                PrintBotMessage(
                    "AUTO DIRECTION"
                    + " | Resolved: "
                    + autoResolvedDirection
                    + " | Reason: "
                    + autoDirectionReason
                );
            }

            return resolved;
        }

        private void UpdateSignalFromBars(
            Bars bars,
            bool checkClosedBarCross)
        {
            if (
                bars == null ||
                bars.Count < SlowEmaPeriod + 10
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            // lastIndex is the currently forming 5-minute bar.
            // The previous bar is the last fully confirmed/closed bar.
            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            // =================================================
            // CLOSED BAR VALUES FOR SIGNAL DECISIONS
            //
            // IMPORTANT:
            // EMA, price, VWAP, trend, liquidity and structure
            // are all evaluated from the SAME confirmed 5m bar.
            // =================================================
            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            double emaSlowCurrent =
                CalculateEma(
                    bars,
                    SlowEmaPeriod,
                    closedBarIndex
                );

            double lastPrice =
                bars.GetClose(
                    closedBarIndex
                );

            DateTime closedBarTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime decisionNyTime =
                ConvertToNewYorkTime(
                    closedBarTime
                );

            EnsureTradingDay(
                decisionNyTime
            );

            double currentVwap =
                CalculateSessionVwap(
                    bars,
                    closedBarIndex
                );

            bool bullishTrend =
                emaFastCurrent >
                emaSlowCurrent;

            bool bearishTrend =
                emaFastCurrent <
                emaSlowCurrent;

            bool aboveVwap =
                currentVwap > 0 &&
                lastPrice > currentVwap;

            bool belowVwap =
                currentVwap > 0 &&
                lastPrice < currentVwap;

            bool nySessionActive =
                IsBotNySessionActive(
                    decisionNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    decisionNyTime
                );

            if (premarketSession)
            {
                TryBuildPremarketRangeFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );

                UpdatePremarketContextFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );
            }
            else if (
                ToTimeInt(decisionNyTime) >= 92500 &&
                ToTimeInt(decisionNyTime) <= 100000 &&
                premarketContextDateNy != decisionNyTime.Date
            )
            {
                // A bot started shortly before/at the open still reconstructs
                // the completed premarket map from historical M5 bars.
                UpdatePremarketContextFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );
            }

            // Unrealized PnL must continue using the live/forming bar.
            double livePrice =
                bars.GetClose(
                    lastIndex
                );

            UpdateBreakevenFollowThrough(
                bars.GetHigh(
                    lastIndex
                ),
                bars.GetLow(
                    lastIndex
                ),
                ConvertToNewYorkTime(
                    bars.GetTime(
                        lastIndex
                    )
                )
            );

            UpdateUnrealizedPnL(
                livePrice
            );

            CheckForceFlatTime();
            CheckDailyLossEmergency();

            string trend =
                bullishTrend
                    ? "BULLISH"
                    : bearishTrend
                        ? "BEARISH"
                        : "NEUTRAL";

            Brush trendBrush =
                bullishTrend
                    ? Brushes.LimeGreen
                    : bearishTrend
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // CLOSED-BAR STRUCTURE ANALYSIS
            // =================================================
            string liquidityState;
            string structureState;

            bool bullishStructureConfirmed;
            bool bearishStructureConfirmed;

            string bullishStructureSetupKey;
            string bearishStructureSetupKey;

            DetectLiquidityAndStructure(
                bars,
                closedBarIndex,
                out liquidityState,
                out structureState,
                out bullishStructureConfirmed,
                out bearishStructureConfirmed,
                out bullishStructureSetupKey,
                out bearishStructureSetupKey
            );

            Brush liquidityBrush =
                liquidityState == "LOW SWEPT"
                    ? Brushes.LimeGreen
                    : liquidityState == "HIGH SWEPT"
                        ? Brushes.OrangeRed
                        : liquidityState == "BOTH SWEPT"
                            ? Brushes.MediumPurple
                            : Brushes.Gray;

            Brush structureBrush =
                bullishStructureConfirmed
                    ? Brushes.LimeGreen
                    : bearishStructureConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // MOMENTUM ENGINE V2
            // Momentum is calculated by the INTERNAL Range-20
            // series. M5 supplies context only.
            // =================================================
            int longMomentumScore;
            int shortMomentumScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaFastSlope;
            bool highBreakout;
            bool lowBreakout;
            string momentumState;

            lock (marketContextLock)
            {
                longMomentumScore =
                    latestRangeLongScore;

                shortMomentumScore =
                    latestRangeShortScore;

                rangeRatio =
                    latestRangeRatio;

                volumeRatio =
                    latestRangeVolumeRatio;

                bodyRatio =
                    latestRangeBodyRatio;

                emaFastSlope =
                    latestRangeEmaSlope;

                highBreakout =
                    latestRangeHighBreakout;

                lowBreakout =
                    latestRangeLowBreakout;

                momentumState =
                    latestRangeMomentumState;
            }

            bool bullishMomentumConfirmed =
                longMomentumScore >= MomentumMinScore;

            bool bearishMomentumConfirmed =
                shortMomentumScore >= MomentumMinScore;

            Brush momentumBrush =
                bullishMomentumConfirmed
                    ? Brushes.LimeGreen
                    : bearishMomentumConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            double bullishStructureBreakLevel = 0;
            double bearishStructureBreakLevel = 0;
            TryGetLatestM5StructureBreakLevel(
                bars, closedBarIndex, true, out bullishStructureBreakLevel
            );
            TryGetLatestM5StructureBreakLevel(
                bars, closedBarIndex, false, out bearishStructureBreakLevel
            );

            // Publish the latest confirmed M5 context so Range
            // momentum can use it as its directional filter.
            lock (marketContextLock)
            {
                latestM5ContextReady = true;
                latestM5BullishTrend = bullishTrend;
                latestM5BearishTrend = bearishTrend;
                latestM5AboveVwap = aboveVwap;
                latestM5BelowVwap = belowVwap;
                latestM5BullishStructure =
                    bullishStructureConfirmed;
                latestM5BearishStructure =
                    bearishStructureConfirmed;
                latestM5LiquidityState =
                    liquidityState;
                latestM5StructureState =
                    structureState;
                latestM5DecisionNyTime =
                    decisionNyTime;
                latestM5Vwap =
                    currentVwap;
                latestM5BullishStructureBreakLevel =
                    bullishStructureBreakLevel;
                latestM5BearishStructureBreakLevel =
                    bearishStructureBreakLevel;
            }

            // =================================================
            // DIRECTION FILTER
            // =================================================
            string direction =
                ResolveEffectiveDirection(
                    decisionNyTime,
                    lastPrice,
                    bullishTrend,
                    bearishTrend,
                    aboveVwap,
                    belowVwap
                );

            bool allowLong =
                direction == "BOTH" ||
                direction == "LONG ONLY";

            bool allowShort =
                direction == "BOTH" ||
                direction == "SHORT ONLY";

            // =================================================
            // V12 OPENING MODE
            // =================================================
            bool openingModeEnabled =
                activeStrategyMode == "OPENING" ||
                activeStrategyMode == "HYBRID";

            bool openingWindow =
                IsOpeningEntryWindow(
                    decisionNyTime
                );

            bool openingPriority =
                IsOpeningPriorityActive(
                    decisionNyTime
                );

            // V1.6.2:
            // 09:30-09:35 is reserved ONLY to build the opening range.
            // No Structure/Momentum entry can consume an AM slot there.
            bool openingBuildLock =
                IsOpeningBuildWindow(
                    decisionNyTime
                );

            if (
                openingModeEnabled &&
                openingWindow
            )
            {
                if (
                    !preEntryRangeReady ||
                    preEntryRangeDateNy !=
                        decisionNyTime.Date
                )
                {
                    TryBuildPreEntryRangeFromBars(
                        bars,
                        closedBarIndex,
                        decisionNyTime.Date
                    );
                }

                if (!openingRangeReady)
                {
                    TryBuildOpeningRangeFromBars(
                        bars,
                        closedBarIndex,
                        decisionNyTime.Date
                    );
                }
            }

            if (
                openingModeEnabled &&
                openingWindow &&
                premarketContextReady &&
                premarketContextDateNy == decisionNyTime.Date
            )
            {
                // The opening engine now consumes the premarket map as context.
                // It remains confirmation/statistics rather than a standalone trigger.
                currentSetupState =
                    "OPENING | PM " + premarketContextBias
                    + " | PM H/L " + premarketRangeHigh.ToString("0.00")
                    + "/" + premarketRangeLow.ToString("0.00");
            }

            bool openingLongReady =
                false;

            bool openingShortReady =
                false;

            if (
                openingModeEnabled &&
                openingWindow &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                decisionNyTime >
                    openingRangeBarTimeNy
            )
            {
                double openingBuffer =
                    selectedInstrument != null
                        ? selectedInstrument
                            .MasterInstrument
                            .TickSize
                            * OpeningBreakoutBufferTicks
                        : 0;

                openingLongReady =
                    allowLong &&
                    bullishTrend &&
                    aboveVwap &&
                    lastPrice >=
                        openingRangeHigh +
                        openingBuffer;

                openingShortReady =
                    allowShort &&
                    bearishTrend &&
                    belowVwap &&
                    lastPrice <=
                        openingRangeLow -
                        openingBuffer;

                if (openingLongReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (
                        IsOpeningPriceChaseBlocked(
                            true,
                            lastPrice,
                            out extensionPoints,
                            out maxExtensionPoints
                        )
                    )
                    {
                        openingLongReady =
                            false;

                        LogOpeningPriceChaseBlock(
                            true,
                            decisionNyTime,
                            lastPrice,
                            extensionPoints,
                            maxExtensionPoints
                        );
                    }
                }

                if (openingShortReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (
                        IsOpeningPriceChaseBlocked(
                            false,
                            lastPrice,
                            out extensionPoints,
                            out maxExtensionPoints
                        )
                    )
                    {
                        openingShortReady =
                            false;

                        LogOpeningPriceChaseBlock(
                            false,
                            decisionNyTime,
                            lastPrice,
                            extensionPoints,
                            maxExtensionPoints
                        );
                    }
                }
            }

            // =================================================
            // FINAL CONDITIONS
            // =================================================
            // Premarket V1 is momentum-only. Structure remains RTH/Midday/PM
            // so the new early window cannot silently change the proven M5 path.
            bool structureLongReady =
                nySessionActive &&
                !premarketSession &&
                allowLong &&
                bullishTrend &&
                aboveVwap &&
                bullishStructureConfirmed;

            bool structureShortReady =
                nySessionActive &&
                !premarketSession &&
                allowShort &&
                bearishTrend &&
                belowVwap &&
                bearishStructureConfirmed;

            string decisionSessionWindow =
                GetBotSessionWindow(
                    decisionNyTime
                );

            bool strictMidday =
                string.Equals(
                    decisionSessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            if (strictMidday)
            {
                structureLongReady =
                    structureLongReady &&
                    latestHtfLongScore >=
                        MiddayMinHtfAlignmentScore;

                structureShortReady =
                    structureShortReady &&
                    latestHtfShortScore >=
                        MiddayMinHtfAlignmentScore;
            }

            // Structure entries are evaluated on confirmed M5 bars.
            // Momentum entries are evaluated separately by Range-20.
            // Do not duplicate Range momentum state inside the M5 engine.

            bool structureModeEnabled =
                activeStrategyMode == "STRUCTURE" ||
                activeStrategyMode == "HYBRID";

            bool openingSignalPresent =
                openingLongReady ||
                openingShortReady;

            bool rawLongReady =
                structureModeEnabled &&
                !openingBuildLock &&
                !openingSignalPresent &&
                structureLongReady;

            bool rawShortReady =
                structureModeEnabled &&
                !openingBuildLock &&
                !openingSignalPresent &&
                structureShortReady;

            // =====================================================
            // V1.6.10 - GLOBAL STRUCTURE MATURE-MOVE GUARD
            // =====================================================
            // A 4/4 BOS/CHOCH can remain valid after the directional leg is
            // already mature. When Range continuation is weak (<=2/5, <=1.0x
            // volume and no fresh breakout), wait instead of entering the tail.
            double structureTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double structureUpMoveTicks;
            double structureDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                decisionNyTime,
                structureTickSize,
                out structureUpMoveTicks,
                out structureDownMoveTicks
            );

            bool weakLongContinuation =
                longMomentumScore <= StructureExhaustionMaxMomentumScore &&
                volumeRatio <= StructureExhaustionMaxVolumeRatio &&
                !highBreakout;

            bool weakShortContinuation =
                shortMomentumScore <= StructureExhaustionMaxMomentumScore &&
                volumeRatio <= StructureExhaustionMaxVolumeRatio &&
                !lowBreakout;

            if (
                rawLongReady &&
                structureUpMoveTicks >= StructureExhaustionMinMoveTicks &&
                weakLongContinuation
            )
            {
                LogStructureMatureMoveBlock(
                    true, decisionNyTime, structureUpMoveTicks,
                    longMomentumScore, volumeRatio, highBreakout
                );
                rawLongReady = false;
            }

            if (
                rawShortReady &&
                structureDownMoveTicks >= StructureExhaustionMinMoveTicks &&
                weakShortContinuation
            )
            {
                LogStructureMatureMoveBlock(
                    false, decisionNyTime, structureDownMoveTicks,
                    shortMomentumScore, volumeRatio, lowBreakout
                );
                rawShortReady = false;
            }

            string longLearningLookupContext =
                structureState;

            string shortLearningLookupContext =
                structureState;

            string learningLongReason;
            string learningShortReason;

            bool learningLongAllowed =
                IsLearningTradeAllowed(
                    "LONG",
                    decisionNyTime,
                    longLearningLookupContext,
                    out learningLongReason
                );

            bool learningShortAllowed =
                IsLearningTradeAllowed(
                    "SHORT",
                    decisionNyTime,
                    shortLearningLookupContext,
                    out learningShortReason
                );

            bool openingLearningAllowed =
                true;

            string openingLearningReason =
                string.Empty;

            if (
                openingLongReady ||
                openingShortReady
            )
            {
                openingLearningAllowed =
                    IsLearningTradeAllowed(
                        openingLongReady
                            ? "LONG"
                            : "SHORT",
                        decisionNyTime,
                        "OPENING BREAKOUT",
                        out openingLearningReason
                    );
            }

            bool openingReady =
                (openingLongReady || openingShortReady) &&
                openingLearningAllowed;

            bool longReady =
                rawLongReady &&
                learningLongAllowed;

            bool shortReady =
                rawShortReady &&
                learningShortAllowed;

            double totalBotPnL =
                botDailyPnL +
                botUnrealizedPnL;

            string currentSessionWindow =
                decisionSessionWindow;

            bool sessionTradeLocked =
                IsSessionTradeLimitReached(
                    currentSessionWindow
                );

            bool dailyRiskLocked =
                persistentDailyLocked ||
                totalBotPnL >= activeDailyTarget ||
                totalBotPnL <= -activeDailyLoss;

            if (
                !persistentDailyLocked &&
                (
                    totalBotPnL >= activeDailyTarget ||
                    totalBotPnL <= -activeDailyLoss
                )
            )
            {
                SetPersistentDailyLock(
                    totalBotPnL >= activeDailyTarget
                        ? "DAILY TARGET"
                        : "DAILY LOSS"
                );
            }

            if (
                dailyRiskLocked ||
                sessionTradeLocked
            )
            {
                longReady = false;
                shortReady = false;
                openingReady = false;
            }

            string confirmation =
                longReady || shortReady
                    ? "READY"
                    : "WAITING";

            Brush confirmationBrush =
                longReady
                    ? Brushes.LimeGreen
                    : shortReady
                        ? Brushes.OrangeRed
                        : Brushes.Gray;

            string setup;
            Brush setupBrush;

            string signal;
            Brush signalBrush;

            if (dailyRiskLocked)
            {
                setup =
                    "DAILY RISK LOCK";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "DAILY RISK LOCK";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (sessionTradeLocked)
            {
                setup =
                    currentSessionWindow
                    + " TRADE LIMIT";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    currentSessionWindow
                    + " LOCKED "
                    + GetSessionTradeCount(
                        currentSessionWindow
                    )
                    + "/"
                    + activeMaxTrades;

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (!nySessionActive)
            {
                setup =
                    "OUTSIDE NY SESSION";

                setupBrush =
                    Brushes.Gray;

                signal =
                    "OUTSIDE NY SESSION";

                signalBrush =
                    Brushes.Gray;
            }
            else if (
                (openingLongReady || openingShortReady) &&
                !openingLearningAllowed
            )
            {
                setup =
                    "OPENING LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "OPENING EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (openingReady)
            {
                setup =
                    openingLongReady
                        ? "OPENING LONG READY"
                        : "OPENING SHORT READY";

                setupBrush =
                    openingLongReady
                        ? Brushes.LimeGreen
                        : Brushes.OrangeRed;

                signal =
                    openingLongReady
                        ? "OPENING LONG SIGNAL"
                        : "OPENING SHORT SIGNAL";

                signalBrush =
                    openingLongReady
                        ? Brushes.LimeGreen
                        : Brushes.OrangeRed;
            }
            else if (openingBuildLock)
            {
                setup =
                    "OPENING BUILD";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "BUILDING OPENING RANGE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                openingPriority &&
                !openingSignalPresent &&
                !longReady &&
                !shortReady
            )
            {
                // Opening gets the first look. If there is no Opening
                // breakout, valid Structure/Momentum setups may fall through.
                setup =
                    "OPENING WATCH";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    openingRangeReady
                        ? "WAIT OPENING / FALLBACK READY"
                        : "WAIT OPENING RANGE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                rawLongReady &&
                !learningLongAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "LONG EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                rawShortReady &&
                !learningShortAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "SHORT EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (longReady)
            {
                setup =
                    "LONG READY";

                setupBrush =
                    Brushes.LimeGreen;

                signal =
                    "LONG SIGNAL";

                signalBrush =
                    Brushes.LimeGreen;
            }
            else if (shortReady)
            {
                setup =
                    "SHORT READY";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "SHORT SIGNAL";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (
                liquidityState != "NONE" &&
                !bullishStructureConfirmed &&
                !bearishStructureConfirmed
            )
            {
                setup =
                    "WAIT BOS/CHOCH";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "WAITING STRUCTURE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                bullishStructureConfirmed ||
                bearishStructureConfirmed
            )
            {
                setup =
                    "FILTERED";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "FILTERS NOT ALIGNED";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else
            {
                setup =
                    "WAIT LIQUIDITY";

                setupBrush =
                    Brushes.Gray;

                signal =
                    bullishTrend
                        ? "BULLISH"
                        : bearishTrend
                            ? "BEARISH"
                            : "WAITING";

                signalBrush =
                    bullishTrend
                        ? Brushes.LimeGreen
                        : bearishTrend
                            ? Brushes.OrangeRed
                            : Brushes.Gray;
            }

            // =================================================
            // OUTPUT ONLY WHEN A NEW 5M BAR IS CONFIRMED
            // =================================================
            if (checkClosedBarCross)
            {
                string vwapSide =
                    currentVwap <= 0
                        ? "VWAP N/A"
                        : aboveVwap
                            ? "ABOVE VWAP"
                            : belowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                // Diagnostic score.
                // The score is informational only and does NOT change
                // the actual entry conditions above.
                int buyScore = 0;
                int sellScore = 0;

                List<string> buyMissing =
                    new List<string>();

                List<string> sellMissing =
                    new List<string>();

                if (bullishTrend)
                    buyScore++;
                else
                    buyMissing.Add("Trend");

                if (aboveVwap)
                    buyScore++;
                else
                    buyMissing.Add("VWAP");

                if (
                    liquidityState == "LOW SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    buyScore++;
                else
                    buyMissing.Add("Low Sweep");

                if (bullishStructureConfirmed)
                    buyScore++;
                else
                    buyMissing.Add("Bullish Structure");

                if (bearishTrend)
                    sellScore++;
                else
                    sellMissing.Add("Trend");

                if (belowVwap)
                    sellScore++;
                else
                    sellMissing.Add("VWAP");

                if (
                    liquidityState == "HIGH SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    sellScore++;
                else
                    sellMissing.Add("High Sweep");

                if (bearishStructureConfirmed)
                    sellScore++;
                else
                    sellMissing.Add("Bearish Structure");

                PrintBotMessage(
                    "DECISION"
                    + " | "
                    + decisionNyTime.ToString("HH:mm")
                    + " ET"
                    + " | Trend: "
                    + trend
                    + " | "
                    + vwapSide
                    + " | Sweep: "
                    + liquidityState
                    + " | Structure: "
                    + structureState
                    + " | Session: "
                    + (
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED"
                    )
                    + " | Strategy: "
                    + activeStrategyMode
                    + " | Momentum: "
                    + momentumState
                    + " | Setup: "
                    + setup
                );

                PrintBotMessage(
                    "RANGE MOMENTUM "
                    + MomentumRangeTicks
                    + "T"
                    + " | LONG: "
                    + longMomentumScore
                    + "/5"
                    + " | SHORT: "
                    + shortMomentumScore
                    + "/5"
                    + " | Range x"
                    + rangeRatio.ToString("0.00")
                    + " | Volume x"
                    + volumeRatio.ToString("0.00")
                    + " | Body "
                    + (bodyRatio * 100.0).ToString("0")
                    + "%"
                    + " | EMA9 Slope: "
                    + emaFastSlope.ToString("0.00")
                    + " | Breakout: "
                    + (
                        highBreakout
                            ? "HIGH"
                            : lowBreakout
                                ? "LOW"
                                : "NONE"
                    )
                );

                LogLearningDecision(
                    decisionNyTime,
                    trend,
                    vwapSide,
                    liquidityState,
                    structureState,
                    setup,
                    buyScore,
                    sellScore
                );

                if (
                    rawLongReady &&
                    !learningLongAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK LONG | "
                        + learningLongReason
                    );
                }

                if (
                    rawShortReady &&
                    !learningShortAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK SHORT | "
                        + learningShortReason
                    );
                }

                PrintBotMessage(
                    "BUY SCORE: "
                    + buyScore
                    + "/4"
                    + (
                        buyMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    buyMissing
                                )
                            : " | READY"
                    )
                );

                PrintBotMessage(
                    "SELL SCORE: "
                    + sellScore
                    + "/4"
                    + (
                        sellMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    sellMissing
                                )
                            : " | READY"
                    )
                );

                if (openingReady)
                {
                    bool openingIsLong =
                        openingLongReady;

                    PrintBotMessage(
                        "OPENING SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Side: "
                        + (openingIsLong ? "LONG" : "SHORT")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | OR High: "
                        + openingRangeHigh.ToString("0.00")
                        + " | OR Low: "
                        + openingRangeLow.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Trend: "
                        + trend
                    );

                    CaptureLearningSignalContext(
                        openingIsLong
                            ? "LONG"
                            : "SHORT",
                        decisionNyTime,
                        "OPENING BREAKOUT"
                    );

                    TrySubmitEntry(
                        openingIsLong,
                        closedBarTime,
                        false,
                        null,
                        true
                    );
                }
                else if (longReady)
                {
                    PrintBotMessage(
                        "LONG SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string longLearningContext =
                        structureState;

                    if (bullishStructureBreakLevel > 0)
                    {
                        ArmSmartRetest(
                            true,
                            decisionNyTime,
                            bullishStructureBreakLevel,
                            bullishStructureBreakLevel,
                            lastPrice,
                            4,
                            "M5 STRUCTURE READY",
                            bullishStructureSetupKey
                        );

                        PrintBotMessage(
                            "WAIT STRUCTURE RETEST"
                            + " | Side: LONG"
                            + " | Level: " + bullishStructureBreakLevel.ToString("0.00")
                            + " | Setup: " + structureState
                        );
                    }
                    else
                    {
                        CaptureLearningSignalContext(
                            "LONG",
                            decisionNyTime,
                            longLearningContext
                        );

                        TrySubmitEntry(
                            true,
                            closedBarTime,
                            false,
                            bullishStructureSetupKey
                        );
                    }
                }
                else if (shortReady)
                {
                    PrintBotMessage(
                        "SHORT SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string shortLearningContext =
                        structureState;

                    if (bearishStructureBreakLevel > 0)
                    {
                        ArmSmartRetest(
                            false,
                            decisionNyTime,
                            bearishStructureBreakLevel,
                            bearishStructureBreakLevel,
                            lastPrice,
                            4,
                            "M5 STRUCTURE READY",
                            bearishStructureSetupKey
                        );

                        PrintBotMessage(
                            "WAIT STRUCTURE RETEST"
                            + " | Side: SHORT"
                            + " | Level: " + bearishStructureBreakLevel.ToString("0.00")
                            + " | Setup: " + structureState
                        );
                    }
                    else
                    {
                        CaptureLearningSignalContext(
                            "SHORT",
                            decisionNyTime,
                            shortLearningContext
                        );

                        TrySubmitEntry(
                            false,
                            closedBarTime,
                            false,
                            bearishStructureSetupKey
                        );
                    }
                }
            }

            currentSignalState =
                signal;

            currentSetupState =
                setup;

            PublishSharedState();

            // =================================================
            // UPDATE UI
            // =================================================
            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    lastPriceText.Text =
                        FormatPrice(
                            lastPrice
                        );

                    emaFastText.Text =
                        FormatPrice(
                            emaFastCurrent
                        );

                    emaSlowText.Text =
                        FormatPrice(
                            emaSlowCurrent
                        );

                    vwapText.Text =
                        currentVwap > 0
                            ? FormatPrice(
                                currentVwap
                            )
                            : "--";

                    trendText.Text =
                        trend;

                    trendText.Foreground =
                        trendBrush;

                    nySessionText.Text =
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED";

                    nySessionText.Foreground =
                        nySessionActive
                            ? Brushes.LimeGreen
                            : Brushes.Gray;

                    liquidityText.Text =
                        liquidityState;

                    liquidityText.Foreground =
                        liquidityBrush;

                    structureText.Text =
                        structureState;

                    structureText.Foreground =
                        structureBrush;

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        momentumBrush;

                    confirmationText.Text =
                        confirmation;

                    confirmationText.Foreground =
                        confirmationBrush;

                    setupText.Text =
                        setup;

                    setupText.Foreground =
                        setupBrush;

                    barTimeText.Text =
                        decisionNyTime.ToString(
                            "MM/dd HH:mm"
                        )
                        + " ET";

                    signalText.Text =
                        signal;

                    signalText.Foreground =
                        signalBrush;

                    pnlText.Text =
                        botDailyPnL.ToString(
                            "$0.00"
                        );

                    tradesText.Text =
                        "AM "
                        + amTradesToday
                        + "/"
                        + activeMaxTrades
                        + " | PM "
                        + pmTradesToday
                        + "/"
                        + activeMaxTrades;
                })
            );
        }

        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        // =====================================================
        // PERSISTENT DAILY STATE
        // =====================================================
        private void TryRestorePersistentStateForSelection()
        {
            if (
                botRunning ||
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            LoadOrResetPersistentDailyState();
        }

        private void LoadOrResetPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            DateTime tradingSessionDate =
                GetTradingSessionDate(
                    nowNy
                );

            activeTradingDate =
                tradingSessionDate;

            JJBotDailyStateData state =
                LoadPersistentDailyState();

            bool stateMatchesToday =
                state != null &&
                state.NewYorkDate ==
                    tradingSessionDate.ToString(
                        "yyyy-MM-dd"
                    ) &&
                string.Equals(
                    state.AccountName,
                    selectedAccount.Name,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                string.Equals(
                    state.InstrumentName,
                    selectedInstrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                );

            if (stateMatchesToday)
            {
                tradesToday =
                    Math.Max(
                        0,
                        state.TradesToday
                    );

                amTradesToday =
                    Math.Max(
                        0,
                        state.AmTrades
                    );

                pmTradesToday =
                    Math.Max(
                        0,
                        state.PmTrades
                    );

                premarketTradesToday =
                    Math.Max(
                        0,
                        state.PremarketTrades
                    );

                middayTradesToday =
                    Math.Max(
                        0,
                        state.MiddayTrades
                    );

                botDailyPnL =
                    state.RealizedPnL;

                // Backward compatibility:
                // Old XML files only contain RealizedPnL (which was NET).
                // If V11 fields are absent/default zero, preserve the
                // historical net as gross with zero known fees.
                if (
                    state.SchemaVersion <
                        CurrentDailyStateSchemaVersion &&
                    Math.Abs(state.GrossPnL) < 0.0000001 &&
                    Math.Abs(state.Fees) < 0.0000001 &&
                    Math.Abs(state.RealizedPnL) > 0.0000001
                )
                {
                    botDailyGrossPnL =
                        state.RealizedPnL;

                    botDailyFees =
                        0;
                }
                else
                {
                    botDailyGrossPnL =
                        state.GrossPnL;

                    botDailyFees =
                        Math.Max(
                            0,
                            state.Fees
                        );
                }

                botUnrealizedPnL =
                    0;

                dailyPeakTotalPnL =
                    Math.Max(
                        state.PeakTotalPnL,
                        botDailyPnL
                    );

                dailyProtectedProfitFloor =
                    Math.Max(
                        0,
                        state.ProtectedProfitFloor
                    );

                dailyProfitFloorArmed =
                    state.ProfitFloorArmed &&
                    dailyProtectedProfitFloor > 0;

                lastLoggedProtectedProfitFloor =
                    dailyProtectedProfitFloor;

                persistentDailyLocked =
                    state.DailyLocked;

                persistentDailyLockReason =
                    state.DailyLockReason
                    ?? string.Empty;

                // V1.6.2 GHOST LOCK RECOVERY:
                // Before 16:25 ET, a lock with zero trades, zero PnL and no
                // recorded reason is invalid and is safe to clear.
                bool zeroActivityState =
                    tradesToday == 0 &&
                    Math.Abs(botDailyGrossPnL) < 0.0000001 &&
                    Math.Abs(botDailyFees) < 0.0000001 &&
                    Math.Abs(botDailyPnL) < 0.0000001;

                DateTime restoreNowNy =
                    GetCurrentNewYorkTime();

                bool beforeForceFlat =
                    ToTimeInt(restoreNowNy) <
                        ForceFlatTimeNy;

                // V1.6.14.1 - FORCE FLAT is a SESSION-CLOSE lock only.
                // It is valid exclusively from 16:25 ET until the 18:00 ET
                // futures-session reset. If NinjaTrader/app was not running
                // at 18:00, the persisted FORCE FLAT lock can otherwise be
                // restored the next morning and immediately block START.
                // Clear ONLY this stale reason; real risk locks (daily loss,
                // profit-floor, etc.) remain untouched.
                int restoreTimeValue =
                    ToTimeInt(restoreNowNy);

                bool forceFlatLockWindowActive =
                    restoreNowNy.DayOfWeek != DayOfWeek.Saturday &&
                    restoreNowNy.DayOfWeek != DayOfWeek.Sunday &&
                    restoreTimeValue >= ForceFlatTimeNy &&
                    restoreTimeValue < TradingSessionResetTimeNy;

                bool restoredForceFlatLock =
                    persistentDailyLocked &&
                    string.Equals(
                        persistentDailyLockReason,
                        "FORCE FLAT 16:25 ET",
                        StringComparison.OrdinalIgnoreCase
                    );

                if (
                    restoredForceFlatLock &&
                    !forceFlatLockWindowActive
                )
                {
                    persistentDailyLocked = false;
                    persistentDailyLockReason = string.Empty;
                    forceFlatSentToday = false;
                    forceFlatDateNy = DateTime.MinValue;
                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;

                    PrintBotMessage(
                        "STALE FORCE FLAT LOCK CLEARED"
                        + " | Strategy Clock: "
                        + restoreNowNy.ToString("yyyy-MM-dd HH:mm:ss")
                        + " ET"
                        + " | New session is available."
                    );

                    SavePersistentDailyState();
                }

                if (
                    persistentDailyLocked &&
                    zeroActivityState &&
                    beforeForceFlat &&
                    string.IsNullOrWhiteSpace(
                        persistentDailyLockReason
                    )
                )
                {
                    persistentDailyLocked =
                        false;

                    persistentDailyLockReason =
                        string.Empty;

                    PrintBotMessage(
                        "GHOST DAILY LOCK CLEARED"
                        + " | Date: "
                        + state.NewYorkDate
                        + " | Trades: 0"
                        + " | Gross: $0.00"
                        + " | Fees: $0.00"
                        + " | Net: $0.00"
                    );

                    SavePersistentDailyState();
                }

                lastExecutedSignalBar =
                    state.LastExecutedSignalBar;

                consumedBullishStructureSetupKey =
                    state.ConsumedBullishStructureKey
                    ?? string.Empty;

                consumedBearishStructureSetupKey =
                    state.ConsumedBearishStructureKey
                    ?? string.Empty;

                consumedBullishStructureConfirmTime =
                    state.ConsumedBullishStructureConfirmTime;

                consumedBearishStructureConfirmTime =
                    state.ConsumedBearishStructureConfirmTime;

                openingTradeTakenToday =
                    state.OpeningTradeTaken;

                openingRangeReady = false;
                openingRangeHigh = 0;
                openingRangeLow = 0;
                openingRangeBarTimeNy = DateTime.MinValue;
                openingRangeLoggedDate = DateTime.MinValue;

                premarketRangeReady = false;
                premarketRangeHigh = 0;
                premarketRangeLow = 0;
                premarketRangeDateNy = DateTime.MinValue;
                premarketRangeLastM5TimeNy = DateTime.MinValue;
                lastPremarketChaseBlockLogKey = string.Empty;
                premarketContextReady = false;
                premarketContextDateNy = DateTime.MinValue;
                premarketContextBias = "NEUTRAL";
                premarketContextBiasScore = 0;
                lastPremarketContextLogNy = DateTime.MinValue;
                lastPremarketContextFinalLogDateNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;

                // Backward-compatible recovery if an older state file
                // contains a consumed key but not the explicit timestamp.
                if (
                    consumedBullishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBullishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBullishStructureSetupKey
                        );
                }

                if (
                    consumedBearishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBearishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBearishStructureSetupKey
                        );
                }

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "TRADING SESSION STATE RESTORED"
                    + " | Date: "
                    + state.NewYorkDate
                    + " | Trades: "
                    + tradesToday
                    + " | PRE: "
                    + premarketTradesToday
                    + "/"
                    + PremarketMaxTrades
                    + " | AM: "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | MIDDAY: "
                    + middayTradesToday
                    + "/"
                    + MiddayMaxTrades
                    + " | PM: "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Gross: "
                    + botDailyGrossPnL.ToString("$0.00")
                    + " | Fees: "
                    + botDailyFees.ToString("$0.00")
                    + " | Net: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Peak: "
                    + dailyPeakTotalPnL.ToString("$0.00")
                    + " | ProfitFloor: "
                    + (
                        dailyProfitFloorArmed
                            ? dailyProtectedProfitFloor.ToString("$0.00")
                            : "OFF"
                      )
                    + " | Locked: "
                    + persistentDailyLocked
                    + " | LockReason: "
                    + (
                        string.IsNullOrWhiteSpace(
                            persistentDailyLockReason
                        )
                            ? "NONE"
                            : persistentDailyLockReason
                      )
                    + " | OpeningTaken: "
                    + openingTradeTakenToday
                );
            }
            else
            {
                tradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
                botDailyGrossPnL = 0;
                botDailyFees = 0;
                botDailyPnL = 0;
                botUnrealizedPnL = 0;
                dailyPeakTotalPnL = 0;
                dailyProtectedProfitFloor = 0;
                dailyProfitFloorArmed = false;
                lastLoggedProtectedProfitFloor = 0;

                persistentDailyLocked =
                    false;

                persistentDailyLockReason =
                    string.Empty;

                lastExecutedSignalBar =
                    DateTime.MinValue;

                consumedBullishStructureSetupKey =
                    string.Empty;

                consumedBearishStructureSetupKey =
                    string.Empty;

                consumedBullishStructureConfirmTime =
                    DateTime.MinValue;

                consumedBearishStructureConfirmTime =
                    DateTime.MinValue;

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                pendingEntryIsOpening = false;
                activeTradeIsOpening = false;
                pendingEntryIsPremarket = false;
                activeTradeIsPremarket = false;
                openingTradeTakenToday = false;
                openingRangeReady = false;
                openingRangeHigh = 0;
                openingRangeLow = 0;
                openingRangeBarTimeNy = DateTime.MinValue;
                openingRangeLoggedDate = DateTime.MinValue;

                premarketRangeReady = false;
                premarketRangeHigh = 0;
                premarketRangeLow = 0;
                premarketRangeDateNy = DateTime.MinValue;
                premarketRangeLastM5TimeNy = DateTime.MinValue;
                lastPremarketChaseBlockLogKey = string.Empty;
                premarketContextReady = false;
                premarketContextDateNy = DateTime.MinValue;
                premarketContextBias = "NEUTRAL";
                premarketContextBiasScore = 0;
                lastPremarketContextLogNy = DateTime.MinValue;
                lastPremarketContextFinalLogDateNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;

                SavePersistentDailyState();

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "NEW TRADING SESSION STATE CREATED"
                    + " | Date: "
                    + tradingSessionDate.ToString(
                        "yyyy-MM-dd"
                    )
                );
            }

            UpdatePnlDisplay();

            Action updateStateUi =
                new Action(() =>
                {
                    if (tradesText != null)
                    {
                        tradesText.Text =
                            "AM "
                            + amTradesToday
                            + "/"
                            + activeMaxTrades
                            + " | PM "
                            + pmTradesToday
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        persistentDailyLocked &&
                        signalText != null
                    )
                    {
                        signalText.Text =
                            "DAILY RISK LOCK";

                        signalText.Foreground =
                            Brushes.OrangeRed;
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                updateStateUi();
            }
            else
            {
                Dispatcher.InvokeAsync(
                    updateStateUi
                );
            }
        }

        private JJBotDailyStateData
            LoadPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return null;
            }

            string accountName =
                selectedAccount.Name;

            string instrumentName =
                selectedInstrument.FullName;

            string filePath =
                GetPersistentStateFilePath(
                    accountName,
                    instrumentName
                );

            string backupPath =
                filePath + ".bak";

            object persistenceLock =
                JJBotRuntimeCoordinator.GetPersistenceLock(
                    accountName,
                    instrumentName
                );

            lock (persistenceLock)
            {
                if (
                    string.IsNullOrWhiteSpace(
                        filePath
                    )
                )
                {
                    return null;
                }

                // Primary file first.
                if (File.Exists(filePath))
                {
                    try
                    {
                        return DeserializeDailyStateFile(
                            filePath
                        );
                    }
                    catch (Exception primaryEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD PRIMARY ERROR: "
                            + primaryEx.Message
                            + " | TRYING BACKUP."
                        );
                    }
                }

                // Automatic recovery from last known-good backup.
                if (File.Exists(backupPath))
                {
                    try
                    {
                        JJBotDailyStateData recovered =
                            DeserializeDailyStateFile(
                                backupPath
                            );

                        PrintBotMessage(
                            "STATE RECOVERED FROM BACKUP: "
                            + backupPath
                        );

                        return recovered;
                    }
                    catch (Exception backupEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD BACKUP ERROR: "
                            + backupEx.Message
                        );
                    }
                }

                return null;
            }
        }

        private JJBotDailyStateData
            DeserializeDailyStateFile(
                string filePath)
        {
            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(
                        JJBotDailyStateData
                    )
                );

            using (
                FileStream stream =
                    new FileStream(
                        filePath,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read
                    )
            )
            {
                return serializer.Deserialize(
                    stream
                ) as JJBotDailyStateData;
            }
        }

        private void SavePersistentDailyState()
        {
            string tempPath =
                string.Empty;

            try
            {
                if (
                    selectedAccount == null ||
                    selectedInstrument == null
                )
                {
                    return;
                }

                string accountName =
                    selectedAccount.Name;

                string instrumentName =
                    selectedInstrument.FullName;

                DateTime stateDate;
                int localTradesToday;
                int localPremarketTradesToday;
                int localAmTradesToday;
                int localPmTradesToday;
                int localMiddayTradesToday;
double localBotDailyGrossPnL;
                double localBotDailyFees;
                double localBotDailyPnL;
                double localDailyPeakTotalPnL;
                double localDailyProtectedProfitFloor;
                bool localDailyProfitFloorArmed;
                bool localDailyLocked;
                string localDailyLockReason;
                DateTime localLastExecutedSignalBar;
                string localConsumedBullishStructureKey;
                string localConsumedBearishStructureKey;
                DateTime localConsumedBullishStructureConfirmTime;
                DateTime localConsumedBearishStructureConfirmTime;
                bool localOpeningTradeTaken;

                // Capture one internally consistent state snapshot.
                lock (executionStateLock)
                {
                    stateDate =
                        activeTradingDate !=
                            DateTime.MinValue
                            ? activeTradingDate
                            : GetTradingSessionDate(
                                GetCurrentNewYorkTime()
                              );

                    localTradesToday =
                        tradesToday;

                    localPremarketTradesToday =
                        premarketTradesToday;

                    localAmTradesToday =
                        amTradesToday;

                    localPmTradesToday =
                        pmTradesToday;

                    localMiddayTradesToday =
                        middayTradesToday;

                    localBotDailyGrossPnL =
                        botDailyGrossPnL;

                    localBotDailyFees =
                        botDailyFees;

                    localBotDailyPnL =
                        botDailyPnL;

                    localDailyPeakTotalPnL =
                        dailyPeakTotalPnL;

                    localDailyProtectedProfitFloor =
                        dailyProtectedProfitFloor;

                    localDailyProfitFloorArmed =
                        dailyProfitFloorArmed;

                    localDailyLocked =
                        persistentDailyLocked;

                    localDailyLockReason =
                        persistentDailyLockReason
                        ?? string.Empty;

                    localLastExecutedSignalBar =
                        lastExecutedSignalBar;

                    localConsumedBullishStructureKey =
                        consumedBullishStructureSetupKey;

                    localConsumedBearishStructureKey =
                        consumedBearishStructureSetupKey;

                    localConsumedBullishStructureConfirmTime =
                        consumedBullishStructureConfirmTime;

                    localConsumedBearishStructureConfirmTime =
                        consumedBearishStructureConfirmTime;

                    localOpeningTradeTaken =
                        openingTradeTakenToday;
                }

                JJBotDailyStateData state =
                    new JJBotDailyStateData();

                state.SchemaVersion =
                    CurrentDailyStateSchemaVersion;

                state.NewYorkDate =
                    stateDate.ToString(
                        "yyyy-MM-dd"
                    );

                state.AccountName =
                    accountName;

                state.InstrumentName =
                    instrumentName;

                state.TradesToday =
                    localTradesToday;

                state.PremarketTrades =
                    localPremarketTradesToday;

                state.AmTrades =
                    localAmTradesToday;

                state.PmTrades =
                    localPmTradesToday;

                state.MiddayTrades =
                    localMiddayTradesToday;

                state.GrossPnL =
                    localBotDailyGrossPnL;

                state.Fees =
                    localBotDailyFees;

                state.RealizedPnL =
                    localBotDailyPnL;

                state.PeakTotalPnL =
                    localDailyPeakTotalPnL;

                state.ProtectedProfitFloor =
                    localDailyProtectedProfitFloor;

                state.ProfitFloorArmed =
                    localDailyProfitFloorArmed;

                state.DailyLocked =
                    localDailyLocked;

                state.DailyLockReason =
                    localDailyLockReason;

                state.LastExecutedSignalBar =
                    localLastExecutedSignalBar;

                state.ConsumedBullishStructureKey =
                    localConsumedBullishStructureKey
                    ?? string.Empty;

                state.ConsumedBearishStructureKey =
                    localConsumedBearishStructureKey
                    ?? string.Empty;

                state.ConsumedBullishStructureConfirmTime =
                    localConsumedBullishStructureConfirmTime;

                state.ConsumedBearishStructureConfirmTime =
                    localConsumedBearishStructureConfirmTime;

                state.OpeningTradeTaken =
                    localOpeningTradeTaken;

                Directory.CreateDirectory(
                    stateFolderPath
                );

                string filePath =
                    GetPersistentStateFilePath(
                        accountName,
                        instrumentName
                    );

                string backupPath =
                    filePath + ".bak";

                tempPath =
                    filePath
                    + ".tmp."
                    + Guid.NewGuid()
                        .ToString("N");

                object persistenceLock =
                    JJBotRuntimeCoordinator.GetPersistenceLock(
                        accountName,
                        instrumentName
                    );

                lock (persistenceLock)
                {
                    XmlSerializer serializer =
                        new XmlSerializer(
                            typeof(
                                JJBotDailyStateData
                            )
                        );

                    // Never serialize directly into the live XML.
                    using (
                        FileStream stream =
                            new FileStream(
                                tempPath,
                                FileMode.CreateNew,
                                FileAccess.Write,
                                FileShare.None
                            )
                    )
                    {
                        serializer.Serialize(
                            stream,
                            state
                        );

                        stream.Flush(
                            true
                        );
                    }

                    if (File.Exists(filePath))
                    {
                        try
                        {
                            // Atomic replacement on NTFS.
                            // The previous good state becomes .bak.
                            File.Replace(
                                tempPath,
                                filePath,
                                backupPath,
                                true
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (
                            PlatformNotSupportedException
                        )
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (IOException)
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                    }
                    else
                    {
                        File.Move(
                            tempPath,
                            filePath
                        );

                        tempPath =
                            string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "STATE SAVE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                if (
                    !string.IsNullOrWhiteSpace(
                        tempPath
                    ) &&
                    File.Exists(
                        tempPath
                    )
                )
                {
                    try
                    {
                        File.Delete(
                            tempPath
                        );
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void ReplaceStateFileFallback(
            string tempPath,
            string filePath,
            string backupPath)
        {
            // The per-key persistence lock is already held here.
            // This fallback is used only if File.Replace is unavailable.
            if (File.Exists(filePath))
            {
                File.Copy(
                    filePath,
                    backupPath,
                    true
                );
            }

            File.Copy(
                tempPath,
                filePath,
                true
            );

            File.Delete(
                tempPath
            );
        }

        private string GetPersistentStateFilePath()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return string.Empty;
            }

            return GetPersistentStateFilePath(
                selectedAccount.Name,
                selectedInstrument.FullName
            );
        }

        private string GetPersistentStateFilePath(
            string accountName,
            string instrumentName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                return string.Empty;
            }

            string safeAccount =
                MakeSafeFileName(
                    accountName
                );

            string safeInstrument =
                MakeSafeFileName(
                    instrumentName
                );

            return Path.Combine(
                stateFolderPath,
                "daily_"
                + safeAccount
                + "_"
                + safeInstrument
                + ".xml"
            );
        }

        private string MakeSafeFileName(
            string value)
        {
            if (
                string.IsNullOrWhiteSpace(
                    value
                )
            )
            {
                return "unknown";
            }

            char[] invalidChars =
                Path.GetInvalidFileNameChars();

            foreach (
                char invalidChar
                in invalidChars
            )
            {
                value =
                    value.Replace(
                        invalidChar,
                        '_'
                    );
            }

            value =
                value.Replace(
                    ' ',
                    '_'
                );

            return value;
        }

        private bool IsSimulationAccount(
            Account account)
        {
            if (
                account == null ||
                string.IsNullOrWhiteSpace(
                    account.Name
                )
            )
            {
                return false;
            }

            string accountName =
                account.Name.Trim();

            // Conservative SIM-only gate:
            // only NinjaTrader-style simulation accounts whose
            // names BEGIN with "Sim" are accepted.
            //
            // This intentionally rejects funded/evaluation/live
            // accounts unless this safety policy is changed later.
            return accountName.StartsWith(
                "Sim",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private void SubscribeExecutionAccount(
            Account account)
        {
            UnsubscribeExecutionAccount();

            if (
                account == null ||
                !IsSimulationAccount(account)
            )
            {
                return;
            }

            subscribedAccount =
                account;

            subscribedAccount.ExecutionUpdate +=
                OnAccountExecutionUpdate;

            subscribedAccount.OrderUpdate +=
                OnAccountOrderUpdate;
        }

        private void UnsubscribeExecutionAccount()
        {
            if (
                subscribedAccount != null
            )
            {
                subscribedAccount.ExecutionUpdate -=
                    OnAccountExecutionUpdate;

                subscribedAccount.OrderUpdate -=
                    OnAccountOrderUpdate;

                subscribedAccount =
                    null;
            }
        }

        // =====================================================
        // V1.6.14 - CME-STYLE TRADING SESSION DATE
        // =====================================================
        // Session label semantics:
        // - Sunday 18:00 ET -> Monday session
        // - Monday 18:00 ET -> Tuesday session
        // - ...
        // - Thursday 18:00 ET -> Friday session
        // - Friday after 18:00, Saturday and Sunday before 18:00 stay on
        //   the Friday session because there is no new CME equity-index session.
        //
        // This lets the 16:25 ET FORCE FLAT lock expire at the next real
        // 18:00 ET session boundary instead of waiting for midnight.
        private DateTime GetTradingSessionDate(
            DateTime nyTime)
        {
            DateTime calendarDate =
                nyTime.Date;

            int timeValue =
                ToTimeInt(
                    nyTime
                );

            if (nyTime.DayOfWeek == DayOfWeek.Saturday)
            {
                return calendarDate.AddDays(-1);
            }

            if (nyTime.DayOfWeek == DayOfWeek.Sunday)
            {
                return timeValue >= TradingSessionResetTimeNy
                    ? calendarDate.AddDays(1)
                    : calendarDate.AddDays(-2);
            }

            if (nyTime.DayOfWeek == DayOfWeek.Friday)
            {
                // There is no Friday 18:00 ET futures reopen.
                return calendarDate;
            }

            if (timeValue >= TradingSessionResetTimeNy)
            {
                return calendarDate.AddDays(1);
            }

            return calendarDate;
        }

        private void EnsureTradingDay(
            DateTime nyTime)
        {
            DateTime sessionDate =
                GetTradingSessionDate(
                    nyTime
                );
            // Prevent older/historical callbacks from moving the
            // active NY trading day backwards and resetting counters.
            if (
                activeTradingDate !=
                    DateTime.MinValue &&
                sessionDate <=
                    activeTradingDate
            )
            {
                return;
            }

            activeTradingDate =
                sessionDate;

            tradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
            botDailyGrossPnL = 0;
            botDailyFees = 0;
            botDailyPnL = 0;
            botUnrealizedPnL = 0;
            dailyPeakTotalPnL = 0;
            dailyProtectedProfitFloor = 0;
            dailyProfitFloorArmed = false;
            lastLoggedProtectedProfitFloor = 0;

            persistentDailyLocked =
                false;

            persistentDailyLockReason =
                string.Empty;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;

            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;

            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;
            premarketForceFlatSentToday = false;
            premarketForceFlatDateNy = DateTime.MinValue;

            lastExecutedSignalBar =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            pendingEntryIsOpening = false;
            activeTradeIsOpening = false;
            pendingEntryIsPremarket = false;
            activeTradeIsPremarket = false;
            openingTradeTakenToday = false;
            openingRangeReady = false;
            openingRangeHigh = 0;
            openingRangeLow = 0;
            openingRangeBarTimeNy = DateTime.MinValue;

            premarketRangeReady = false;
            premarketRangeHigh = 0;
            premarketRangeLow = 0;
            premarketRangeDateNy = DateTime.MinValue;
            premarketRangeLastM5TimeNy = DateTime.MinValue;
            lastPremarketChaseBlockLogKey = string.Empty;

            preEntryRangeReady = false;
            preEntryRangeHigh = 0;
            preEntryRangeLow = 0;
            preEntryRangeDateNy = DateTime.MinValue;
            openingRangeGuardBlocked = false;
            openingRangeGuardReason = string.Empty;
            openingRangeGuardDateNy = DateTime.MinValue;
            lastLateEntryBlockLogKey = string.Empty;
            openingRangeLoggedDate = DateTime.MinValue;

            lastAutomaticTradeExitNy =
                DateTime.MinValue;

            lastAutomaticTradeExitRangeBarTime =
                DateTime.MinValue;

            lastAutomaticTradeExitWasBreakeven =
                false;

            lastReentryBlockLogKey =
                string.Empty;

            lastPriceChaseBlockLogKey =
                string.Empty;

            SavePersistentDailyState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (grossPnlText != null)
                        grossPnlText.Text = "$0.00";

                    if (feesPnlText != null)
                        feesPnlText.Text = "$0.00";

                    if (pnlText != null)
                        pnlText.Text = "$0.00";

                    if (unrealizedPnlText != null)
                        unrealizedPnlText.Text = "$0.00";

                    if (totalPnlText != null)
                        totalPnlText.Text = "$0.00";

                    if (tradesText != null)
                        tradesText.Text =
                            "AM 0/"
                            + activeMaxTrades
                            + " | PM 0/"
                            + activeMaxTrades;
                })
            );

            PrintBotMessage(
                "NEW NY TRADING SESSION: "
                + sessionDate.ToString(
                    "yyyy-MM-dd"
                )
            );
        }

        private bool IsSelectedInstrumentFlat()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return false;
            }

            lock (
                selectedAccount.Positions
            )
            {
                foreach (
                    Position position
                    in selectedAccount.Positions
                )
                {
                    if (
                        position == null ||
                        position.Instrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        position.Instrument.FullName ==
                            selectedInstrument.FullName
                    )
                    {
                        return
                            position.MarketPosition ==
                            MarketPosition.Flat;
                    }
                }
            }

            // No position object for this instrument means flat.
            return true;
        }

        // =====================================================
        // V15.1 - PROFILE ORDER OWNERSHIP
        // =====================================================
        private string GetProfileOrderPrefix()
        {
            int profileNumber = 1;

            if (
                !string.IsNullOrWhiteSpace(
                    platformProfileId
                )
            )
            {
                Match match =
                    Regex.Match(
                        platformProfileId,
                        @"profile-(\d+)",
                        RegexOptions.IgnoreCase
                    );

                int parsed;

                if (
                    match.Success &&
                    int.TryParse(
                        match.Groups[1].Value,
                        out parsed
                    ) &&
                    parsed >= 1 &&
                    parsed <= 5
                )
                {
                    profileNumber = parsed;
                }
            }

            return "P" + profileNumber + "_";
        }

        private string GetProfileOrderName(
            string baseName)
        {
            return
                GetProfileOrderPrefix()
                + (baseName ?? string.Empty);
        }

        private bool IsAnyProfileBotOrder(
            string orderName)
        {
            return
                !string.IsNullOrWhiteSpace(orderName) &&
                Regex.IsMatch(
                    orderName,
                    @"^P[1-5]_JJ_",
                    RegexOptions.IgnoreCase
                );
        }

        private bool IsOwnProfileBotOrder(
            string orderName)
        {
            return
                !string.IsNullOrWhiteSpace(orderName) &&
                orderName.StartsWith(
                    GetProfileOrderPrefix() + "JJ_",
                    StringComparison.OrdinalIgnoreCase
                );
        }

        private bool IsAutomaticReentryBlocked(
            bool isLong,
            DateTime signalBarTime,
            bool momentumEntry,
            bool highConvictionMomentum,
            out string reason)
        {
            reason =
                string.Empty;

            if (
                lastAutomaticTradeExitNy ==
                    DateTime.MinValue
            )
            {
                return false;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            double elapsedSeconds =
                (
                    nowNy -
                    lastAutomaticTradeExitNy
                ).TotalSeconds;

            if (
                elapsedSeconds <
                    AutomaticReentryCooldownSeconds
            )
            {
                bool strongBeReentryAllowed =
                    momentumEntry &&
                    highConvictionMomentum &&
                    lastAutomaticTradeExitWasBreakeven &&
                    elapsedSeconds >=
                        StrongMomentumReentryMinSeconds;

                if (!strongBeReentryAllowed)
                {
                    int remaining =
                        Math.Max(
                            1,
                            AutomaticReentryCooldownSeconds -
                            (int)Math.Floor(
                                Math.Max(
                                    0,
                                    elapsedSeconds
                                )
                            )
                        );

                    reason =
                        "COOLDOWN "
                        + remaining
                        + "s";

                    return true;
                }

                PrintBotMessage(
                    "REENTRY EARLY REARM"
                    + " | Prior exit: PRICE BE"
                    + " | Strong momentum: YES"
                    + " | Elapsed: "
                    + ((int)elapsedSeconds)
                    + "s"
                );
            }

            // V1.6.10 - SAME-SIDE LOSS REARM.
            // A simple 60-second timer is not enough after a true loss. The
            // same direction must return with high-conviction momentum. This
            // still allows a real second impulse (for example the valid 3/5
            // with normal volume seen on 2026-08-19), but blocks weak repeats.
            string requestedSide =
                isLong
                    ? "LONG"
                    : "SHORT";

            if (
                lastAutomaticTradeExitWasLoss &&
                string.Equals(
                    lastAutomaticTradeExitSide,
                    requestedSide,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                !highConvictionMomentum
            )
            {
                reason =
                    "SAME-SIDE LOSS - WAIT FRESH HIGH-CONVICTION EXPANSION";

                return true;
            }

            // Momentum must additionally wait for a Range-20 signal bar
            // strictly newer than the Range bar active when the prior
            // automatic trade closed.
            if (
                momentumEntry &&
                lastAutomaticTradeExitRangeBarTime !=
                    DateTime.MinValue &&
                signalBarTime <=
                    lastAutomaticTradeExitRangeBarTime
            )
            {
                reason =
                    "WAIT NEW RANGE BAR";

                return true;
            }

            return false;
        }

        private int GetAutoRiskSizedContracts(
            Instrument instrument,
            int configuredContracts,
            int stopTicks,
            double dollarRiskCap,
            out double riskPerContract,
            out double totalConfiguredRisk)
        {
            riskPerContract = 0;
            totalConfiguredRisk = 0;

            if (
                instrument == null ||
                configuredContracts <= 0 ||
                stopTicks <= 0 ||
                dollarRiskCap <= 0
            )
            {
                return 0;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return 0;
            }

            double tickValue =
                tickSize *
                pointValue;

            riskPerContract =
                stopTicks *
                tickValue;

            if (riskPerContract <= 0)
            {
                return 0;
            }

            totalConfiguredRisk =
                configuredContracts *
                riskPerContract;

            int maxContractsByRisk =
                (int)Math.Floor(
                    dollarRiskCap /
                    riskPerContract
                );

            if (maxContractsByRisk <= 0)
            {
                return 0;
            }

            return Math.Min(
                configuredContracts,
                maxContractsByRisk
            );
        }

       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null,
            bool openingEntry = false,
            bool highConvictionMomentum = false)
        {
            if (!botRunning)
                return;

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            if (
                !IsSimulationAccount(
                    account
                )
            )
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - ACCOUNT IS NOT SIM."
                );

                return;
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // Automatic entries MUST obey NY session.
            // Manual SIM tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            bool momentumEntry =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(
                    structureSetupKey
                );

            if (!manualTest)
            {
                int lateEntryAgeSeconds;
                int lateEntryMaxSeconds;

                if (
                    IsLateAutomaticEntry(
                        signalNyTime,
                        momentumEntry,
                        openingEntry,
                        out lateEntryAgeSeconds,
                        out lateEntryMaxSeconds
                    )
                )
                {
                    string lateEntryKey =
                        signalBarTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + (
                            openingEntry
                                ? "OPENING"
                                : momentumEntry
                                    ? "MOMENTUM"
                                    : "STRUCTURE"
                          );

                    if (
                        lateEntryKey !=
                            lastLateEntryBlockLogKey
                    )
                    {
                        lastLateEntryBlockLogKey =
                            lateEntryKey;

                        PrintBotMessage(
                            "SKIP TRADE - LATE ENTRY"
                            + " | Type: "
                            + (
                                openingEntry
                                    ? "OPENING"
                                    : momentumEntry
                                        ? "MOMENTUM"
                                        : "STRUCTURE"
                              )
                            + " | Age: "
                            + lateEntryAgeSeconds
                            + "s"
                            + " | Max: "
                            + lateEntryMaxSeconds
                            + "s"
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | StrategyClock: "
                            + GetCurrentNewYorkTime()
                                .ToString(
                                    "HH:mm:ss"
                                )
                            + " ET"
                        );
                    }

                    return;
                }

                string reentryReason;

                if (
                    IsAutomaticReentryBlocked(
                        isLong,
                        signalBarTime,
                        momentumEntry,
                        highConvictionMomentum,
                        out reentryReason
                    )
                )
                {
                    // V1.6.6 - one reentry-block log per cooldown cycle
                    // and side. Do not create a new key every second as the
                    // remaining cooldown text changes.
                    string reentryBlockKey =
                        "REENTRY|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + lastAutomaticTradeExitNy.ToString(
                            "yyyyMMddHHmmss"
                        );

                    if (
                        reentryBlockKey !=
                            lastReentryBlockLogKey
                    )
                    {
                        lastReentryBlockLogKey =
                            reentryBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - REENTRY REARM"
                            + " | "
                            + reentryReason
                            + " | Side: "
                            + (
                                isLong
                                    ? "LONG"
                                    : "SHORT"
                              )
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                        );
                    }

                    return;
                }
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                // V1.6.6 - session limit is a persistent state, not a
                // per-Range-bar event. Log it once until the state changes.
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + GetSessionTradeCount(
                        signalSession
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        signalSession
                    );

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + GetSessionTradeLimit(
                            signalSession
                        )
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !manualTest &&
                positionRecoveryPending
            )
            {
                string recoveryBlockedKey =
                    "POSITION_RECOVERY_PENDING|"
                    + signalBarTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (
                    recoveryBlockedKey !=
                        lastRangeBlockedLogKey
                )
                {
                    lastRangeBlockedLogKey =
                        recoveryBlockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION RECOVERY PENDING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | Waiting for NinjaTrader account sync."
                    );
                }

                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | SignalBar: "
                        + ConvertToNewYorkTime(
                            signalBarTime
                          ).ToString(
                            "HH:mm:ss"
                          )
                        + " ET"
                    );
                }

                return;
            }

            double riskPerContract;
            double configuredRisk;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    activeStopTicks,
                    activeDollarRiskCap,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DOLLAR RISK CAP"
                    + " | ConfigQty: "
                    + activeContracts
                    + " | SL: "
                    + activeStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );

                return;
            }

            if (
                effectiveEntryContracts <
                    activeContracts
            )
            {
                PrintBotMessage(
                    "AUTO RISK SIZING"
                    + " | ConfigQty: "
                    + activeContracts
                    + " -> EffectiveQty: "
                    + effectiveEntryContracts
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | ConfigRisk: "
                    + configuredRisk.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );
            }

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            openingEntry &&
                            openingTradeTakenToday
                        ) ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    pendingEntrySession =
                        signalSession;

                    pendingEntryRequestedQuantity =
                        effectiveEntryContracts;

                    pendingEntryIsManualTest =
                        manualTest;

                    pendingEntryIsOpening =
                        openingEntry;

                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence =
                        manualTest
                            ? 0
                            : latestSetupConfidence;

                    pendingTradeSetupQuality =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupQuality
                                )
                                    ? "ANALYZING"
                                    : latestSetupQuality
                              );

                    pendingTradeSetupTiming =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupTiming
                                )
                                    ? "ANALYZING"
                                    : latestSetupTiming
                              );

                    pendingTradeManipulationState =
                        manualTest
                            ? "NONE"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestManipulationState
                                )
                                    ? "NONE"
                                    : latestManipulationState
                              );

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    if (!manualTest)
                    {
                        lastExecutedSignalBar =
                            signalBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;
                    }
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + effectiveEntryContracts
                    + (
                        effectiveEntryContracts != activeContracts
                            ? " (Configured "
                                + activeContracts
                                + ")"
                            : string.Empty
                      )
                    + " | Risk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + "/"
                    + activeDollarRiskCap.ToString("$0.00")
                    + " | "
                    + instrument.FullName
                    + (
                        openingEntry
                            ? " | Setup: OPENING"
                            : string.Empty
                    )
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingEntryRequestedQuantity =
                        0;

                    pendingEntryIsManualTest =
                        false;

                    pendingEntryIsOpening =
                        false;

                    pendingEntryIsPremarket =
                        false;

                    pendingTradeSetupConfidence =
                        0;

                    pendingTradeSetupQuality =
                        string.Empty;

                    pendingTradeSetupTiming =
                        string.Empty;

                    pendingTradeManipulationState =
                        string.Empty;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // ACCOUNT ORDER UPDATE
        //
        // Keeps the monitor synchronized with the REAL working
        // stop/target orders. If the user drags SL or TP on the
        // chart, NinjaTrader raises OrderUpdate and the monitor
        // refreshes immediately.
        // =====================================================
        private void OnAccountOrderUpdate(
            object sender,
            OrderEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Order == null ||
                e.Order.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Order.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Order.Name;

            if (
                IsAnyProfileBotOrder(orderName) &&
                !IsOwnProfileBotOrder(orderName)
            )
            {
                return;
            }

            if (
                orderName == GetProfileOrderName("JJ_SCALE_IN_LONG") ||
                orderName == GetProfileOrderName("JJ_SCALE_IN_SHORT")
            )
            {
                bool failed =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Order.OrderState ==
                        OrderState.Cancelled ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool filled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (
                    failed ||
                    filled
                )
                {
                    lock (executionStateLock)
                    {
                        smartScaleInPending = false;
                        smartScaleInOrder = e.Order;

                        if (failed)
                        {
                            smartScaleInUsed = false;
                        }
                    }
                }

                if (failed)
                {
                    PrintBotMessage(
                        "SMART SCALE-IN ORDER FAILED"
                        + " | State: "
                        + e.Order.OrderState
                        + " | Error: "
                        + e.Error
                    );
                }

                return;
            }

            if (
                orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                orderName == GetProfileOrderName("JJ_ENTRY_SHORT")
            )
            {
                bool entryRejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool entryCancelled =
                    e.Order.OrderState ==
                        OrderState.Cancelled;

                bool entryFilled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (
                    entryRejected ||
                    entryCancelled ||
                    entryFilled
                )
                {
                    lock (executionStateLock)
                    {
                        entryPending =
                            false;

                        entryOrder =
                            e.Order;

                        if (
                            entryRejected &&
                            entryQuantity <= 0
                        )
                        {
                            executionStatus =
                                "ENTRY ERROR";

                            // No real fill occurred, so the pending
                            // structure remains unconsumed.
                            pendingStructureSetupKey =
                                string.Empty;

                            pendingStructureConfirmTime =
                                DateTime.MinValue;
                        }
                        else if (
                            entryCancelled &&
                            entryQuantity > 0
                        )
                        {
                            executionStatus =
                                "ENTRY PARTIAL";
                        }
                        else if (entryFilled)
                        {
                            executionStatus =
                                stopOrder != null &&
                                targetOrder != null
                                    ? "PROTECTED"
                                    : "ENTRY FILLED";
                        }
                    }

                    UpdateExecutionMonitor();
                }

                return;
            }

            if (
                orderName != GetProfileOrderName("JJ_STOP") &&
                orderName != GetProfileOrderName("JJ_TARGET")
            )
            {
                return;
            }

            try
            {
                bool rejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToChangeOrder ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool shouldFlatten =
                    false;

                double stopForLog;
                double targetForLog;

                lock (executionStateLock)
                {
                    if (
                        orderName == GetProfileOrderName("JJ_STOP")
                    )
                    {
                        stopOrder =
                            e.Order;

                        if (
                            e.Order.StopPrice > 0
                        )
                        {
                            activeStopPrice =
                                e.Order.StopPrice;
                        }
                    }
                    else if (
                        orderName == GetProfileOrderName("JJ_TARGET")
                    )
                    {
                        targetOrder =
                            e.Order;

                        if (
                            e.Order.LimitPrice > 0
                        )
                        {
                            activeTargetPrice =
                                e.Order.LimitPrice;
                        }
                    }

                    if (rejected)
                    {
                        executionStatus =
                            "PROTECTION ERROR";

                        shouldFlatten =
                            entryMarketPosition !=
                                MarketPosition.Flat;
                    }
                    else
                    {
                        bool stopWorking =
                            stopOrder != null &&
                            (
                                stopOrder.OrderState ==
                                    OrderState.Working ||
                                stopOrder.OrderState ==
                                    OrderState.Accepted ||
                                stopOrder.OrderState ==
                                    OrderState.ChangePending ||
                                stopOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        bool targetWorking =
                            targetOrder != null &&
                            (
                                targetOrder.OrderState ==
                                    OrderState.Working ||
                                targetOrder.OrderState ==
                                    OrderState.Accepted ||
                                targetOrder.OrderState ==
                                    OrderState.ChangePending ||
                                targetOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        if (
                            stopWorking &&
                            targetWorking &&
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "PROTECTED";
                        }
                        else if (
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "UPDATING OCO";
                        }
                    }

                    stopForLog =
                        activeStopPrice;

                    targetForLog =
                        activeTargetPrice;
                }

                UpdateExecutionMonitor();

                bool bracketBuildInProgress;

                lock (executionStateLock)
                {
                    bracketBuildInProgress =
                        protectiveBracketBuildInProgress;
                }

                if (
                    !rejected &&
                    !bracketBuildInProgress
                )
                {
                    double localEntryAverage;
                    int localEntryQty;
                    MarketPosition localEntrySide;

                    lock (executionStateLock)
                    {
                        localEntryAverage =
                            entryFillPrice;

                        localEntryQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                activeExitQuantity
                            );

                        localEntrySide =
                            entryMarketPosition;
                    }

                    if (
                        localEntryQty > 0 &&
                        localEntryAverage > 0 &&
                        localEntrySide !=
                            MarketPosition.Flat
                    )
                    {
                        SyncProtectiveBracketToEntry(
                            localEntryAverage,
                            localEntryQty,
                            localEntrySide
                        );
                    }
                }

                if (rejected)
                {
                    PrintBotMessage(
                        "ORDER ERROR"
                        + " | "
                        + orderName
                        + " | State: "
                        + e.Order.OrderState
                        + " | Error: "
                        + e.Error
                        + " | Comment: "
                        + e.Comment
                    );

                    Account account =
                        selectedAccount;

                    Instrument instrument =
                        selectedInstrument;

                    if (
                        shouldFlatten &&
                        account != null &&
                        instrument != null &&
                        IsSimulationAccount(
                            account
                        )
                    )
                    {
                        try
                        {
                            // Never call Flatten while holding executionStateLock.
                            account.Flatten(
                                new[]
                                {
                                    instrument
                                }
                            );

                            lock (executionStateLock)
                            {
                                executionStatus =
                                    "FLATTENING";
                            }

                            UpdateExecutionMonitor();
                        }
                        catch (
                            Exception flattenEx
                        )
                        {
                            PrintBotMessage(
                                "ORDER ERROR FLATTEN FAILED: "
                                + flattenEx.Message
                            );
                        }
                    }

                    return;
                }

                PrintBotMessage(
                    "ORDER UPDATE"
                    + " | "
                    + orderName
                    + " | State: "
                    + e.Order.OrderState
                    + " | Stop: "
                    + stopForLog.ToString("0.00")
                    + " | Target: "
                    + targetForLog.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "ORDER UPDATE ERROR: "
                    + ex.Message
                );
            }
        }

        private void OnAccountExecutionUpdate(
            object sender,
            ExecutionEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Execution == null ||
                e.Execution.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Execution.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Execution.Order != null
                    ? e.Execution.Order.Name
                    : e.Execution.Name;

            if (
                IsAnyProfileBotOrder(orderName) &&
                !IsOwnProfileBotOrder(orderName)
            )
            {
                return;
            }

            Account executionAccount =
                sender as Account;

            if (executionAccount == null)
            {
                executionAccount =
                    selectedAccount;
            }

            Instrument executionInstrument =
                e.Execution.Instrument;

            // ---------------------------------------------
            // ENTRY FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            bool isPrimaryEntryFill =
                orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                orderName == GetProfileOrderName("JJ_ENTRY_SHORT");

            bool isScaleInFill =
                orderName == GetProfileOrderName("JJ_SCALE_IN_LONG") ||
                orderName == GetProfileOrderName("JJ_SCALE_IN_SHORT");

            if (
                isPrimaryEntryFill ||
                isScaleInFill
            )
            {
                MarketPosition filledSide =
                    (
                        orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                        orderName == GetProfileOrderName("JJ_SCALE_IN_LONG")
                    )
                        ? MarketPosition.Long
                        : MarketPosition.Short;

                bool firstFill;
                int cumulativeEntryQty;
                double averageEntryPrice;
                int localTradesToday;
                int localPremarketTrades;
                int localAmTrades;
                int localPmTrades;
                int localMiddayTrades;
                bool localManualTest;
                bool localOpeningEntry;
                bool localPremarketEntry;

                lock (executionStateLock)
                {
                    firstFill =
                        !isScaleInFill &&
                        (
                            entryQuantity <= 0 ||
                            entryMarketPosition ==
                                MarketPosition.Flat
                        );

                    localManualTest =
                        firstFill
                            ? pendingEntryIsManualTest
                            : activeTradeIsManualTest;

                    localOpeningEntry =
                        firstFill
                            ? pendingEntryIsOpening
                            : activeTradeIsOpening;

                    localPremarketEntry =
                        firstFill
                            ? pendingEntryIsPremarket
                            : activeTradeIsPremarket;

                    if (firstFill)
                    {
                        smartScaleInUsed = false;
                        smartScaleInPending = false;
                        smartScaleInOrder = null;
                        initialTradeQuantity = 0;
                        initialTradeRiskDollars = 0;
                        lastSmartScaleInAttemptUtc =
                            DateTime.MinValue;

                        activeTradeIsManualTest =
                            localManualTest;

                        activeTradeIsOpening =
                            localOpeningEntry;

                        activeTradeIsPremarket =
                            localPremarketEntry;

                        activeTradeSetupConfidence =
                            pendingTradeSetupConfidence;

                        activeTradeSetupQuality =
                            string.IsNullOrWhiteSpace(
                                pendingTradeSetupQuality
                            )
                                ? "ANALYZING"
                                : pendingTradeSetupQuality;

                        activeTradeSetupTiming =
                            string.IsNullOrWhiteSpace(
                                pendingTradeSetupTiming
                            )
                                ? "ANALYZING"
                                : pendingTradeSetupTiming;

                        activeTradeManipulationState =
                            string.IsNullOrWhiteSpace(
                                pendingTradeManipulationState
                            )
                                ? "NONE"
                                : pendingTradeManipulationState;

                        if (
                            localOpeningEntry &&
                            !localManualTest
                        )
                        {
                            openingTradeTakenToday =
                                true;
                        }
                    }

                    if (
                        isScaleInFill &&
                        (
                            entryMarketPosition ==
                                MarketPosition.Flat ||
                            entryMarketPosition !=
                                filledSide
                        )
                    )
                    {
                        return;
                    }

                    int previousQty =
                        Math.Max(
                            0,
                            entryQuantity
                        );

                    double previousAverage =
                        entryFillPrice;

                    cumulativeEntryQty =
                        previousQty +
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (cumulativeEntryQty <= 0)
                    {
                        return;
                    }

                    averageEntryPrice =
                        previousQty > 0 &&
                        previousAverage > 0
                            ? (
                                (
                                    previousAverage
                                    * previousQty
                                )
                                +
                                (
                                    e.Price
                                    * e.Quantity
                                )
                            )
                            / cumulativeEntryQty
                            : e.Price;

                    entryFillPrice =
                        averageEntryPrice;

                    entryQuantity =
                        cumulativeEntryQty;

                    activeEntryCommission +=
                        e.Execution.Commission;

                    if (!localManualTest)
                    {
                        botDailyFees +=
                            e.Execution.Commission;

                        botDailyPnL -=
                            e.Execution.Commission;
                    }

                    botUnrealizedPnL =
                        0;

                    entryMarketPosition =
                        filledSide;

                    if (
                        e.Execution.Order != null
                    )
                    {
                        if (isScaleInFill)
                        {
                            smartScaleInOrder =
                                e.Execution.Order;

                            smartScaleInPending =
                                e.Execution.Order.OrderState ==
                                    OrderState.PartFilled;
                        }
                        else
                        {
                            entryOrder =
                                e.Execution.Order;

                            entryPending =
                                e.Execution.Order.OrderState ==
                                    OrderState.PartFilled;

                            if (!entryPending)
                            {
                                pendingEntryRequestedQuantity =
                                    0;
                            }
                        }
                    }
                    else if (!isScaleInFill)
                    {
                        int requestedQty =
                            pendingEntryRequestedQuantity > 0
                                ? pendingEntryRequestedQuantity
                                : activeContracts;

                        entryPending =
                            cumulativeEntryQty <
                                requestedQty;
                    }

                    if (!isScaleInFill)
                    {
                        initialTradeQuantity =
                            cumulativeEntryQty;

                        initialTradeRiskDollars =
                            activeStopTicks
                            * executionInstrument
                                .MasterInstrument
                                .TickSize
                            * executionInstrument
                                .MasterInstrument
                                .PointValue
                            * initialTradeQuantity;
                    }
                    else
                    {
                        smartScaleInUsed = true;
                        smartScaleInPending = false;
                    }

                    if (firstFill)
                    {
                        // Consume the structure only once: on the first
                        // real execution of this entry lifecycle.
                        if (
                            !string.IsNullOrWhiteSpace(
                                pendingStructureSetupKey
                            )
                        )
                        {
                            if (
                                filledSide ==
                                    MarketPosition.Long
                            )
                            {
                                consumedBullishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBullishStructureConfirmTime
                                )
                                {
                                    consumedBullishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                            else
                            {
                                consumedBearishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBearishStructureConfirmTime
                                )
                                {
                                    consumedBearishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                        }

                        if (!localManualTest)
                        {
                        string learningSide =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSide
                            )
                                ? pendingLearningSide
                                : (
                                    filledSide ==
                                        MarketPosition.Long
                                        ? "LONG"
                                        : "SHORT"
                                );

                        string learningSession =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSession
                            )
                                ? pendingLearningSession
                                : "UNKNOWN";

                        string learningStructure =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningStructure
                            )
                                ? pendingLearningStructure
                                : "UNKNOWN";

                        JJBotLearningTrade newLearningTrade =
                            new JJBotLearningTrade();

                        newLearningTrade.Side =
                            learningSide;

                        newLearningTrade.SessionWindow =
                            learningSession;

                        newLearningTrade.Structure =
                            learningStructure;

                        newLearningTrade.SignalTimeNy =
                            pendingLearningSignalTimeNy;

                        newLearningTrade.EntryPrice =
                            averageEntryPrice;

                        newLearningTrade.Mfe =
                            0;

                        newLearningTrade.Mae =
                            0;

                        newLearningTrade.TechnicalConfidence =
                            activeTradeSetupConfidence;

                        newLearningTrade.SetupQuality =
                            activeTradeSetupQuality ?? string.Empty;

                        newLearningTrade.SetupTiming =
                            activeTradeSetupTiming ?? string.Empty;

                        newLearningTrade.ManipulationState =
                            activeTradeManipulationState ?? string.Empty;

                        activeLearningTrade =
                            newLearningTrade;

                        activeLearningEventKey =
                            BuildSharedLearningEventKey(
                                newLearningTrade.Side,
                                newLearningTrade.SignalTimeNy,
                                newLearningTrade.Structure
                            );

                        lock (SharedLearningSyncRoot)
                        {
                            ClaimSharedLearningEvent(
                                activeLearningEventKey
                            );
                        }
                        }
                        else
                        {
                            activeLearningTrade =
                                null;

                            activeLearningEventKey =
                                string.Empty;
                        }

                        pendingStructureSetupKey =
                            string.Empty;

                        pendingStructureConfirmTime =
                            DateTime.MinValue;

                        riskFlattenSent =
                            false;

                        riskFlattenStage =
                            0;

                        riskFlattenLastActionUtc =
                            DateTime.MinValue;

                        riskFlattenOrder =
                            null;

                        activeEntryUsesMomentumTrailing =
                            true;

                        // Snapshot the entry-quality context once.
                        // A strong Momentum trade gets more room before BE,
                        // based on the exact signal-side score/breakout/volume.
                        int entryMomentumScore =
                            filledSide ==
                                MarketPosition.Long
                                ? latestRangeLongScore
                                : latestRangeShortScore;

                        bool entryBreakoutAligned =
                            filledSide ==
                                MarketPosition.Long
                                ? latestRangeHighBreakout
                                : latestRangeLowBreakout;

                        bool entryContextIsMomentum =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningStructure
                            ) &&
                            pendingLearningStructure.IndexOf(
                                "MOMENTUM",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0;

                        activeStrongMomentumProtection =
                            !localManualTest &&
                            entryContextIsMomentum &&
                            entryMomentumScore >=
                                StrongMomentumMinScore &&
                            entryBreakoutAligned &&
                            latestRangeVolumeRatio >=
                                StrongMomentumMinVolumeRatio;

                        activeBreakEvenTriggerTicks =
                            activeStrongMomentumProtection
                                ? StrongMomentumBreakEvenTriggerTicks
                                : MomentumBreakEvenTriggerTicks;

                        momentumTrailingStage =
                            0;

                        lastMomentumTrailingStopPrice =
                            0;

                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        dailyTargetProtectionArmed =
                            false;

                        lastDailyTargetProtectionStopPrice =
                            0;

                        lastDailyTargetProtectionChangeUtc =
                            DateTime.MinValue;

                        activeExitQuantity =
                            0;

                        activeExitGrossPnL =
                            0;

                        activeExitCommission =
                            0;

                        executionStatus =
                            e.Execution.Order != null &&
                            e.Execution.Order.OrderState ==
                                OrderState.PartFilled
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";

                        // Exactly one official trade count per lifecycle.
                        // Manual TEST_LONG / TEST_SHORT are diagnostic only.
                        if (!localManualTest)
                        {
                            tradesToday++;

                            if (
                                string.Equals(
                                    pendingEntrySession,
                                    "PREMARKET",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                premarketTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "AM",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                amTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "MIDDAY",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                middayTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "PM",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                pmTradesToday++;
                            }
                        }
                    }
                    else
                    {
                        // Keep one learning trade and update only its
                        // weighted average entry.
                        if (
                            activeLearningTrade != null
                        )
                        {
                            activeLearningTrade.EntryPrice =
                                averageEntryPrice;
                        }

                        executionStatus =
                            entryPending
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";
                    }

                    localTradesToday =
                        tradesToday;

                    localPremarketTrades =
                        premarketTradesToday;

                    localAmTrades =
                        amTradesToday;

                    localPmTrades =
                        pmTradesToday;

                    localMiddayTrades =
                        middayTradesToday;
                }

                if (isScaleInFill)
                {
                    PrintBotMessage(
                        "SMART SCALE-IN FILLED"
                        + " | Fill: "
                        + e.Quantity
                        + " @ "
                        + e.Price.ToString("0.00")
                        + " | Total Qty: "
                        + cumulativeEntryQty
                        + " | New Avg: "
                        + averageEntryPrice.ToString("0.00")
                    );
                }

                if (
                    firstFill &&
                    localOpeningEntry &&
                    !localManualTest
                )
                {
                    PrintBotMessage(
                        "OPENING TRADE FILLED"
                        + " | Side: "
                        + (
                            filledSide ==
                                MarketPosition.Long
                                ? "LONG"
                                : "SHORT"
                        )
                        + " | Avg: "
                        + averageEntryPrice.ToString("0.00")
                        + " | Opening trade consumed for today."
                    );
                }

                if (firstFill)
                {
                    PrintBotMessage(
                        "TRADE PROTECTION ARMED"
                        + " | BE +"
                        + activeBreakEvenTriggerTicks
                        + "t"
                        + (
                            activeStrongMomentumProtection
                                ? " (ADAPTIVE STRONG)"
                                : " (STANDARD)"
                          )
                        + " | LOCK +"
                        + MomentumLockProfitTicks
                        + "t @ +"
                        + MomentumLockTriggerTicks
                        + "t"
                        + " | LOCK2 +"
                        + MomentumLock2ProfitTicks
                        + "t @ +"
                        + MomentumLock2TriggerTicks
                        + "t"
                        + " | TRAIL "
                        + MomentumTrailDistanceTicks
                        + "t @ +"
                        + MomentumTrailTriggerTicks
                        + "t"
                        + " | SCALE +1 @ +"
                        + SmartScaleInTriggerTicks
                        + "t if confirmed & risk <= initial"
                    );

                    JJBotSharedState.PublishExecution(
                        executionAccount != null
                            ? executionAccount.Name
                            : string.Empty,
                        executionInstrument != null
                            ? executionInstrument.FullName
                            : string.Empty,
                        filledSide ==
                            MarketPosition.Long
                            ? "BUY"
                            : "SELL",
                        e.Price
                    );
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                PrintBotMessage(
                    (
                        isScaleInFill
                            ? "SCALE-IN ENTRY FILL"
                            : (
                                entryPending
                                    ? "ENTRY PARTIAL FILL"
                                    : "ENTRY FILL COMPLETE"
                              )
                    )
                    + " | Fill Qty: "
                    + e.Quantity
                    + " | Total Qty: "
                    + cumulativeEntryQty
                    + (
                        isScaleInFill
                            ? string.Empty
                            : "/"
                                + (
                                    pendingEntryRequestedQuantity > 0
                                        ? pendingEntryRequestedQuantity
                                        : activeContracts
                                  )
                    )
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                );

                if (firstFill && !localManualTest)
                {
                    PrintBotMessage(
                        "SESSION TRADE COUNT"
                        + " | PRE: "
                        + localPremarketTrades
                        + "/"
                        + PremarketMaxTrades
                        + " | AM: "
                        + localAmTrades
                        + "/"
                        + activeMaxTrades
                        + " | MIDDAY: "
                        + localMiddayTrades
                        + "/"
                        + MiddayMaxTrades
                        + " | PM: "
                        + localPmTrades
                        + "/"
                        + activeMaxTrades
                        + " | Day: "
                        + localTradesToday
                    );
                }

                SyncProtectiveBracketToEntry(
                    averageEntryPrice,
                    cumulativeEntryQty,
                    filledSide
                );

                if (isScaleInFill)
                {
                    EnforceSmartScaleInRiskCap();
                }

                UpdateExecutionUi();

                return;
            }

            MarketPosition currentSide;
            double currentEntryPrice;
            int currentEntryQty;
            double currentEntryCommission;
            bool currentTradeIsManualTest;

            lock (executionStateLock)
            {
                currentSide =
                    entryMarketPosition;

                currentEntryPrice =
                    entryFillPrice;

                currentEntryQty =
                    entryQuantity;

                currentEntryCommission =
                    activeEntryCommission;

                currentTradeIsManualTest =
                    activeTradeIsManualTest;
            }

            // ---------------------------------------------
            // EXIT FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            if (
                currentSide !=
                    MarketPosition.Flat &&
                currentEntryPrice > 0 &&
                currentEntryQty > 0
            )
            {
                Order executionOrder =
                    e.Execution.Order;

                OrderAction executionAction =
                    executionOrder != null
                        ? executionOrder.OrderAction
                        : OrderAction.Buy;

                bool protectiveExit =
                    orderName == GetProfileOrderName("JJ_STOP") ||
                    orderName == GetProfileOrderName("JJ_TARGET");

                bool riskExit =
                    orderName == GetProfileOrderName("JJ_RISK_FLATTEN");

                bool externalClosingAction =
                    (
                        currentSide ==
                            MarketPosition.Long &&
                        executionAction ==
                            OrderAction.Sell
                    ) ||
                    (
                        currentSide ==
                            MarketPosition.Short &&
                        executionAction ==
                            OrderAction.BuyToCover
                    );

                bool recognizedExit =
                    protectiveExit ||
                    riskExit ||
                    (
                        !IsAnyProfileBotOrder(orderName) &&
                        orderName != GetProfileOrderName("JJ_ENTRY_LONG") &&
                        orderName != GetProfileOrderName("JJ_ENTRY_SHORT") &&
                        orderName != GetProfileOrderName("JJ_SCALE_IN_LONG") &&
                        orderName != GetProfileOrderName("JJ_SCALE_IN_SHORT") &&
                        externalClosingAction
                    );

                if (recognizedExit)
                {
                    double pointValue =
                        executionInstrument
                            .MasterInstrument
                            .PointValue;

                    int exitQty =
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (exitQty <= 0)
                    {
                        return;
                    }

                    double grossPnL =
                        currentSide ==
                            MarketPosition.Long
                            ? (
                                e.Price -
                                currentEntryPrice
                            )
                            * pointValue
                            * exitQty
                            : (
                                currentEntryPrice -
                                e.Price
                            )
                            * pointValue
                            * exitQty;

                    double exitCommission =
                        e.Execution.Commission;

                    bool accountFlatAfterExecution =
                        e.Execution.Position == 0 ||
                        IsSelectedInstrumentFlat();

                    bool lifecycleComplete;
                    int localExitQty;
                    int localRemainingQty;
                    double localBotPnL;
                    bool localDailyLocked;
                    double finalLearningNet;

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition !=
                                currentSide ||
                            entryFillPrice <= 0
                        )
                        {
                            return;
                        }

                        if (!currentTradeIsManualTest)
                        {
                            botDailyGrossPnL +=
                                grossPnL;

                            botDailyFees +=
                                exitCommission;

                            botDailyPnL +=
                                grossPnL;

                            botDailyPnL -=
                                exitCommission;
                        }

                        activeExitQuantity +=
                            exitQty;

                        activeExitGrossPnL +=
                            grossPnL;

                        activeExitCommission +=
                            exitCommission;

                        localExitQty =
                            Math.Min(
                                activeExitQuantity,
                                entryQuantity
                            );

                        localRemainingQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                localExitQty
                            );

                        lifecycleComplete =
                            accountFlatAfterExecution ||
                            localRemainingQty <= 0;

                        botUnrealizedPnL =
                            lifecycleComplete
                                ? 0
                                : botUnrealizedPnL;

                        if (lifecycleComplete)
                        {
                            if (!currentTradeIsManualTest)
                            {
                                if (
                                    botDailyPnL >=
                                        activeDailyTarget
                                )
                                {
                                    SetPersistentDailyLock(
                                        "DAILY TARGET"
                                    );
                                }
                                else if (
                                    botDailyPnL <=
                                        -activeDailyLoss
                                )
                                {
                                    SetPersistentDailyLock(
                                        "DAILY LOSS"
                                    );
                                }
                            }

                            executionStatus =
                                persistentDailyLocked
                                    ? "DAILY RISK LOCK"
                                    : (
                                        protectiveExit
                                            ? (
                                                orderName ==
                                                    GetProfileOrderName("JJ_TARGET")
                                                    ? "TARGET FILLED"
                                                    : "STOP FILLED"
                                            )
                                            : "FLAT CONFIRMED"
                                    );

                            finalLearningNet =
                                activeExitGrossPnL
                                - activeEntryCommission
                                - activeExitCommission;
                        }
                        else
                        {
                            executionStatus =
                                protectiveExit
                                    ? "EXIT PARTIAL"
                                    : "FLATTEN PARTIAL";

                            finalLearningNet =
                                0;
                        }

                        localBotPnL =
                            botDailyPnL;

                        localDailyLocked =
                            persistentDailyLocked;
                    }

                    SavePersistentDailyState();
                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        (
                            lifecycleComplete
                                ? "EXIT COMPLETE"
                                : "EXIT PARTIAL FILL"
                        )
                        + " | Order: "
                        + orderName
                        + " | Fill Qty: "
                        + exitQty
                        + " | Closed: "
                        + localExitQty
                        + "/"
                        + currentEntryQty
                        + " | Remaining: "
                        + localRemainingQty
                        + " | Exit: "
                        + e.Price.ToString("0.00")
                        + " | Bot Net PnL: "
                        + localBotPnL.ToString("$0.00")
                        + (
                            currentTradeIsManualTest
                                ? string.Empty
                                : " | Day Gross: "
                                    + botDailyGrossPnL.ToString("$0.00")
                                    + " | Day Fees: "
                                    + botDailyFees.ToString("$0.00")
                        )
                    );

                    if (!lifecycleComplete)
                    {
                        ResizeProtectiveOrdersAfterPartialExit(
                            orderName,
                            localRemainingQty
                        );

                        UpdateExecutionUi();
                        return;
                    }

                    if (!currentTradeIsManualTest)
                    {
                        lastAutomaticTradeExitWasBreakeven =
                            Math.Abs(
                                activeExitGrossPnL
                            ) <= 0.01;

                        lastAutomaticTradeExitWasLoss =
                            activeExitGrossPnL < -0.01;

                        lastAutomaticTradeExitSide =
                            currentSide == MarketPosition.Long
                                ? "LONG"
                                : currentSide == MarketPosition.Short
                                    ? "SHORT"
                                    : string.Empty;

                        lastAutomaticTradeExitNy =
                            GetCurrentNewYorkTime();

                        lastAutomaticTradeExitRangeBarTime =
                            lastRangeBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;

                        lastRangeSignalLogKey =
                            string.Empty;

                        lastRangeBlockedLogKey =
                            string.Empty;

                        lastLearningBlockedLogKey =
                            string.Empty;

                        PrintBotMessage(
                            "REENTRY REARM ARMED"
                            + " | Cooldown: "
                            + AutomaticReentryCooldownSeconds
                            + "s"
                            + " | Range frontier: "
                            + (
                                lastAutomaticTradeExitRangeBarTime ==
                                    DateTime.MinValue
                                    ? "N/A"
                                    : ConvertToNewYorkTime(
                                        lastAutomaticTradeExitRangeBarTime
                                      ).ToString(
                                        "HH:mm:ss"
                                      )
                              )
                            + " ET"
                        );

                        RecordLearningTradeResult(
                            finalLearningNet
                        );
                    }
                    else
                    {
                        PrintBotMessage(
                            "MANUAL TEST RESULT"
                            + " | Gross: "
                            + activeExitGrossPnL.ToString("$0.00")
                            + " | EntryFees: "
                            + activeEntryCommission.ToString("$0.00")
                            + " | ExitFees: "
                            + activeExitCommission.ToString("$0.00")
                            + " | Net: "
                            + finalLearningNet.ToString("$0.00")
                            + " | Official Daily PnL unchanged: "
                            + localBotPnL.ToString("$0.00")
                        );
                    }

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition ==
                                currentSide
                        )
                        {
                            entryFillPrice = 0;
                            activeStopPrice = 0;
                            activeTargetPrice = 0;
                            entryQuantity = 0;
                            botUnrealizedPnL = 0;
                            activeEntryCommission = 0;
                            activeEffectiveTargetTicks = 0;
                            activeExitQuantity = 0;
                            activeExitGrossPnL = 0;
                            activeExitCommission = 0;

                            protectiveChangeInFlight =
                                false;

                            activeProtectiveChangeToken =
                                0;

                            protectiveChangeOwner =
                                string.Empty;

                            protectiveChangeStartedUtc =
                                DateTime.MinValue;

                            entryMarketPosition =
                                MarketPosition.Flat;

                            entryPending =
                                false;

                            pendingEntryIsManualTest =
                                false;

                            activeTradeIsManualTest =
                                false;

                            pendingEntryIsOpening =
                                false;

                            activeTradeIsOpening =
                                false;

                            pendingEntryIsPremarket =
                                false;

                            activeTradeIsPremarket =
                                false;

                            activeEntryUsesMomentumTrailing =
                                false;

                            momentumTrailingStage =
                                0;

                            lastMomentumTrailingStopPrice =
                                0;

                            activeStrongMomentumProtection =
                                false;

                            activeBreakEvenTriggerTicks =
                                MomentumBreakEvenTriggerTicks;

                            lastMomentumTrailingChangeUtc =
                                DateTime.MinValue;

                            dailyTargetProtectionArmed =
                                false;

                            smartScaleInUsed = false;
                            smartScaleInPending = false;
                            smartScaleInOrder = null;
                            initialTradeQuantity = 0;
                            initialTradeRiskDollars = 0;
                            lastSmartScaleInAttemptUtc =
                                DateTime.MinValue;

                            lastDailyTargetProtectionStopPrice =
                                0;

                            lastDailyTargetProtectionChangeUtc =
                                DateTime.MinValue;

                            entryOrder = null;
                            stopOrder = null;
                            targetOrder = null;
                            riskFlattenOrder = null;
                            riskFlattenSent = false;
                            riskFlattenStage = 0;
                            riskFlattenLastActionUtc =
                                DateTime.MinValue;
                        }
                    }

                    UpdateExecutionMonitor();
                    UpdateExecutionUi();
                    return;
                }
            }
        }

        // =====================================================
        // DYNAMIC PROFIT TARGET
        //
        // The user configured TP is treated as the MAXIMUM.
        // Strong context keeps 100%, medium uses 80%, weak uses 65%.
        // =====================================================
        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            if (activeTargetTicks <= 0)
                return 1;

            int momentumScore = 0;
            int htfScore = 0;
            bool breakout = false;
            double volumeRatio = 0;

            lock (marketContextLock)
            {
                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    momentumScore =
                        latestRangeLongScore;

                    htfScore =
                        latestHtfLongScore;

                    breakout =
                        latestRangeHighBreakout;
                }
                else
                {
                    momentumScore =
                        latestRangeShortScore;

                    htfScore =
                        latestHtfShortScore;

                    breakout =
                        latestRangeLowBreakout;
                }

                volumeRatio =
                    latestRangeVolumeRatio;
            }

            int minimumTicks =
                Math.Min(
                    DynamicTargetMinTicks,
                    activeTargetTicks
                );

            int targetTicks;

            if (
                momentumScore >= 4 &&
                breakout &&
                htfScore >= 1
            )
            {
                // Strong move: allow the full configured target.
                targetTicks =
                    activeTargetTicks;
            }
            else if (
                momentumScore >= 3 &&
                (
                    breakout ||
                    volumeRatio >=
                        MomentumVolumeExpansion
                )
            )
            {
                // Medium move: reduce target to 80%.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetMediumFactor
                    );
            }
            else
            {
                // Weak/slow move: take profit sooner.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetWeakFactor
                    );
            }

            targetTicks =
                Math.Max(
                    minimumTicks,
                    Math.Min(
                        activeTargetTicks,
                        targetTicks
                    )
                );

            PrintBotMessage(
                "DYNAMIC TARGET"
                + " | Momentum: "
                + momentumScore
                + "/5"
                + " | HTF: "
                + htfScore
                + "/2"
                + " | Breakout: "
                + breakout
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxCfg: "
                + activeTargetTicks
                + " ticks"
            );

            return targetTicks;
        }

        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int effectiveTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    GetProfileOrderPrefix()
                    + "JJ_OCO_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        GetProfileOrderName("JJ_STOP"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        GetProfileOrderName("JJ_TARGET"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }

        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }

        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }

        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            // =====================================================
            // V8 - NEVER-WORSEN PROTECTIVE STOP GUARD
            // =====================================================
            // OCO Sync may resize/synchronize the bracket, but it must
            // NEVER move an already-improved stop backwards.
            //
            // LONG  -> higher stop is better.
            // SHORT -> lower stop is better.
            //
            // activeStopPrice is reserved immediately by BE / Lock /
            // Trailing / Daily Target protection before Account.Change(),
            // so synchronous OrderUpdate callbacks cannot reconstruct the
            // original SL while NinjaTrader is processing the change.
            double protectedStopPrice;

            lock (executionStateLock)
            {
                protectedStopPrice =
                    activeStopPrice;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    marketPosition,
                    protectedStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_TARGET"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_STOP"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        // =====================================================
        // V1.6.4 - CENTRAL NEVER-WORSEN STOP GUARD
        // =====================================================
        // Every protective module can tighten risk, but no module may
        // ever move a protected stop back toward greater risk.
        private double EnforceNeverWorsenStop(
            MarketPosition side,
            double currentProtectedStop,
            double requestedStop)
        {
            if (requestedStop <= 0)
                return currentProtectedStop;

            if (currentProtectedStop <= 0)
                return requestedStop;

            if (side == MarketPosition.Long)
            {
                return Math.Max(
                    currentProtectedStop,
                    requestedStop
                );
            }

            if (side == MarketPosition.Short)
            {
                return Math.Min(
                    currentProtectedStop,
                    requestedStop
                );
            }

            return currentProtectedStop;
        }

        private double RoundToInstrumentTick(
            double price)
        {
            if (
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return price;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return price;

            return
                Math.Round(
                    price / tickSize,
                    0,
                    MidpointRounding.AwayFromZero
                )
                * tickSize;
        }

        // =====================================================
        // MOMENTUM CAPITAL PROTECTION V1
        //
        // Applies ONLY to entries whose learning context contains
        // "MOMENTUM" (including STRUCTURE+MOMENTUM).
        //
        // Stage 1: +40 ticks  -> stop to break even
        // Stage 2: +70 ticks  -> lock +30 ticks
        // Stage 3: +100 ticks -> continuously trail 40 ticks
        //
        // The stop is NEVER moved backwards.
        // =====================================================
        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            int localBreakEvenTriggerTicks;
            bool localStrongMomentumProtection;
            bool localTrailingActive;
            bool localDailyProtectionArmed;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localBreakEvenTriggerTicks =
                    activeBreakEvenTriggerTicks > 0
                        ? activeBreakEvenTriggerTicks
                        : MomentumBreakEvenTriggerTicks;

                localStrongMomentumProtection =
                    activeStrongMomentumProtection;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            if (
                favorableTicks <
                    localBreakEvenTriggerTicks
            )
            {
                return;
            }

            double desiredStop =
                localActiveStopPrice;

            int desiredStage =
                localMomentumStage;

            // Stage 1: Break Even
            if (
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                desiredStop =
                    localEntryFillPrice;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Second staged profit lock
            if (
                favorableTicks >=
                    MomentumLock2TriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLock2ProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLock2ProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        3
                    );
            }

            // Stage 4: Dynamic trailing
            if (
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    desiredStop =
                        Math.Max(
                            desiredStop,
                            trailCandidate
                        );
                }
                else
                {
                    desiredStop =
                        Math.Min(
                            desiredStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    4;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                // V8:
                // Reserve the improved stop immediately. This closes the
                // race where OrderUpdate/OCO Sync could still see the old
                // activeStopPrice and restore the original protective SL.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? (
                                localStrongMomentumProtection
                                    ? "ADAPTIVE BREAK EVEN"
                                    : "BREAK EVEN"
                              )
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : desiredStage == 3
                                    ? "LOCK PROFIT 2"
                                    : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        // =====================================================
        // V14 - SMART SCALE-IN V1
        // =====================================================
        private void TrySmartScaleIn(
            double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            MarketPosition side;
            double entryPrice;
            double stopPrice;
            int currentQty;
            int baseQty;
            double initialRisk;
            bool manualTrade;
            bool scaleUsed;
            bool scalePending;
            bool targetProtection;
            bool entryIsPending;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                entryPrice = entryFillPrice;
                stopPrice = activeStopPrice;

                currentQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                baseQty = initialTradeQuantity;
                initialRisk = initialTradeRiskDollars;
                manualTrade = activeTradeIsManualTest;
                scaleUsed = smartScaleInUsed;
                scalePending = smartScaleInPending;
                targetProtection = dailyTargetProtectionArmed;
                entryIsPending = entryPending;
            }

            if (
                side == MarketPosition.Flat ||
                entryPrice <= 0 ||
                stopPrice <= 0 ||
                currentQty <= 0 ||
                baseQty <= 0 ||
                initialRisk <= 0 ||
                manualTrade ||
                scaleUsed ||
                scalePending ||
                targetProtection ||
                entryIsPending
            )
            {
                return;
            }

            // No scale-in after a partial exit.
            if (currentQty != baseQty)
            {
                return;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - entryPrice) / tickSize
                    : (entryPrice - currentPrice) / tickSize;

            if (
                favorableTicks <
                    SmartScaleInTriggerTicks
            )
            {
                return;
            }

            // The stop must already have locked +30 ticks before
            // the bot is allowed to add a contract.
            double lockStop =
                side == MarketPosition.Long
                    ? entryPrice
                        + MomentumLockProfitTicks
                        * tickSize
                    : entryPrice
                        - MomentumLockProfitTicks
                        * tickSize;

            bool stopProtected =
                side == MarketPosition.Long
                    ? stopPrice >=
                        lockStop - tickSize * 0.5
                    : stopPrice <=
                        lockStop + tickSize * 0.5;

            if (!stopProtected)
            {
                return;
            }

            int momentumScore;
            int htfScore;

            lock (marketContextLock)
            {
                momentumScore =
                    side == MarketPosition.Long
                        ? latestRangeLongScore
                        : latestRangeShortScore;

                htfScore =
                    side == MarketPosition.Long
                        ? latestHtfLongScore
                        : latestHtfShortScore;
            }

            if (
                momentumScore <
                    SmartScaleInMinMomentumScore ||
                htfScore <
                    SmartScaleInMinHtfScore
            )
            {
                return;
            }

            // Estimated worst-case PnL if the new contract fills
            // around currentPrice and the EXISTING stop is hit.
            double existingWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        entryPrice
                      )
                      * pointValue
                      * currentQty
                    : (
                        entryPrice -
                        stopPrice
                      )
                      * pointValue
                      * currentQty;

            double addedWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        currentPrice
                      )
                      * pointValue
                      * SmartScaleInContracts
                    : (
                        currentPrice -
                        stopPrice
                      )
                      * pointValue
                      * SmartScaleInContracts;

            double combinedWorstCase =
                existingWorstCase +
                addedWorstCase;

            double scaleInRiskLimit =
                Math.Min(
                    initialRisk,
                    activeDollarRiskCap > 0
                        ? activeDollarRiskCap
                        : initialRisk
                );

            if (
                combinedWorstCase <
                    -scaleInRiskLimit
            )
            {
                PrintBotMessage(
                    "SMART SCALE-IN BLOCKED - RISK CAP"
                    + " | WorstCase: "
                    + combinedWorstCase.ToString("$0.00")
                    + " | Limit: -"
                    + scaleInRiskLimit.ToString("$0.00")
                );

                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            // V1.6.12 - FINAL atomic revalidation immediately before
            // reserving the scale-in. The earlier snapshot is only a fast
            // eligibility check; fills/trailing may have changed quantity
            // or stop while momentum context was being evaluated.
            lock (executionStateLock)
            {
                if (
                    smartScaleInUsed ||
                    smartScaleInPending ||
                    entryPending ||
                    entryMarketPosition != side ||
                    activeTradeIsManualTest ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                int refreshedQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                double refreshedEntryPrice =
                    entryFillPrice;

                double refreshedStopPrice =
                    activeStopPrice;

                double refreshedInitialRisk =
                    initialTradeRiskDollars;

                if (
                    refreshedQty <= 0 ||
                    refreshedQty != initialTradeQuantity ||
                    refreshedEntryPrice <= 0 ||
                    refreshedStopPrice <= 0 ||
                    refreshedInitialRisk <= 0
                )
                {
                    return;
                }

                double refreshedLockStop =
                    side == MarketPosition.Long
                        ? refreshedEntryPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : refreshedEntryPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                bool refreshedStopProtected =
                    side == MarketPosition.Long
                        ? refreshedStopPrice >=
                            refreshedLockStop - tickSize * 0.5
                        : refreshedStopPrice <=
                            refreshedLockStop + tickSize * 0.5;

                if (!refreshedStopProtected)
                {
                    return;
                }

                double refreshedExistingWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            refreshedEntryPrice
                          )
                          * pointValue
                          * refreshedQty
                        : (
                            refreshedEntryPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * refreshedQty;

                double refreshedAddedWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            currentPrice
                          )
                          * pointValue
                          * SmartScaleInContracts
                        : (
                            currentPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * SmartScaleInContracts;

                double refreshedCombinedWorstCase =
                    refreshedExistingWorstCase +
                    refreshedAddedWorstCase;

                double refreshedRiskLimit =
                    Math.Min(
                        refreshedInitialRisk,
                        activeDollarRiskCap > 0
                            ? activeDollarRiskCap
                            : refreshedInitialRisk
                    );

                if (
                    refreshedCombinedWorstCase <
                        -refreshedRiskLimit
                )
                {
                    return;
                }

                if (
                    lastSmartScaleInAttemptUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSmartScaleInAttemptUtc
                    ).TotalMilliseconds <
                        SmartScaleInAttemptThrottleMs
                )
                {
                    return;
                }

                // Keep the values used by the submission/log consistent
                // with the final validated execution snapshot.
                entryPrice = refreshedEntryPrice;
                stopPrice = refreshedStopPrice;
                currentQty = refreshedQty;
                initialRisk = refreshedInitialRisk;

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = nowUtc;
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        SmartScaleInContracts,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (
                        smartScaleInUsed ||
                        entryMarketPosition != side
                    )
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(
                    new[]
                    {
                        scaleOrder
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN SUBMITTED"
                    + " | Side: "
                    + (
                        side == MarketPosition.Long
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Add: "
                    + SmartScaleInContracts
                    + " | Profit: "
                    + favorableTicks.ToString("0")
                    + " ticks"
                    + " | Momentum: "
                    + momentumScore
                    + "/5"
                    + " | HTF: "
                    + htfScore
                    + "/2"
                    + " | InitialRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage(
                    "SMART SCALE-IN ERROR: "
                    + ex.Message
                );
            }
        }

        private void EnforceSmartScaleInRiskCap()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            Order localStop;
            MarketPosition side;
            double averageEntry;
            double currentStop;
            int openQty;
            double initialRisk;

            lock (executionStateLock)
            {
                if (
                    !smartScaleInUsed ||
                    entryMarketPosition ==
                        MarketPosition.Flat ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    initialTradeRiskDollars <= 0
                )
                {
                    return;
                }

                localStop = stopOrder;
                side = entryMarketPosition;
                averageEntry = entryFillPrice;
                currentStop = activeStopPrice;

                openQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                initialRisk =
                    initialTradeRiskDollars;
            }

            if (
                localStop == null ||
                openQty <= 0 ||
                currentStop <= 0
            )
            {
                return;
            }

            if (
                localStop.OrderState !=
                    OrderState.Working &&
                localStop.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (pointValue <= 0)
            {
                return;
            }

            double riskCapStop =
                side == MarketPosition.Long
                    ? averageEntry
                        - initialRisk
                        / (
                            pointValue
                            * openQty
                        )
                    : averageEntry
                        + initialRisk
                        / (
                            pointValue
                            * openQty
                        );

            riskCapStop =
                RoundToInstrumentTick(
                    riskCapStop
                );

            double desiredStop =
                side == MarketPosition.Long
                    ? Math.Max(
                        currentStop,
                        riskCapStop
                      )
                    : Math.Min(
                        currentStop,
                        riskCapStop
                      );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > currentStop
                    : desiredStop < currentStop;

            if (!improves)
            {
                return;
            }

            long token;

            if (
                !TryBeginProtectiveChange(
                    "SMART_SCALE_IN_RISK",
                    out token
                )
            )
            {
                return;
            }

            try
            {
                lock (executionStateLock)
                {
                    if (
                        !ReferenceEquals(
                            stopOrder,
                            localStop
                        ) ||
                        entryMarketPosition != side
                    )
                    {
                        return;
                    }

                    activeStopPrice = desiredStop;
                    localStop.StopPriceChanged = desiredStop;
                }

                account.Change(
                    new[]
                    {
                        localStop
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP"
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                    + " | MaxRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    token
                );
            }
        }

        // =====================================================
        // DAILY TARGET PROTECTION
        //
        // Once total bot PnL reaches the configured daily target,
        // stop opening new trades and trail the current winner while
        // protecting approximately DailyTargetGivebackDollars.
        // =====================================================
        private void UpdateDailyTargetProtection(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            double localBotDailyPnL;
            double localBotUnrealizedPnL;
            bool localDailyProtectionArmed;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localBotDailyPnL =
                    botDailyPnL;

                localBotUnrealizedPnL =
                    botUnrealizedPnL;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;
            }

            if (
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            double totalPnL =
                localBotDailyPnL +
                localBotUnrealizedPnL;

            if (
                !localDailyProtectionArmed &&
                totalPnL <
                    activeDailyTarget
            )
            {
                return;
            }

            bool newlyArmed =
                false;

            if (!localDailyProtectionArmed)
            {
                lock (executionStateLock)
                {
                    // Re-check before arming.
                    if (
                        !dailyTargetProtectionArmed &&
                        stopOrder != null &&
                        entryMarketPosition !=
                            MarketPosition.Flat &&
                        (
                            botDailyPnL +
                            botUnrealizedPnL
                        ) >=
                            activeDailyTarget
                    )
                    {
                        dailyTargetProtectionArmed =
                            true;

                        SetPersistentDailyLock(
                            "DAILY TARGET"
                        );

                        executionStatus =
                            "DAILY TARGET TRAILING";

                        newlyArmed =
                            true;

                        localDailyProtectionArmed =
                            true;

                        localBotDailyPnL =
                            botDailyPnL;

                        localBotUnrealizedPnL =
                            botUnrealizedPnL;

                        totalPnL =
                            localBotDailyPnL +
                            localBotUnrealizedPnL;
                    }
                }

                if (!localDailyProtectionArmed)
                    return;

                if (newlyArmed)
                {
                    SavePersistentDailyState();
                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "DAILY TARGET PROTECTION ARMED"
                        + " | Total: "
                        + totalPnL.ToString("$0.00")
                        + " | Target: "
                        + activeDailyTarget.ToString("$0.00")
                    );
                }
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            double pointValue =
                instrument
                    .MasterInstrument
                    .PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double protectedDailyPnL =
                Math.Max(
                    0,
                    activeDailyTarget -
                    DailyTargetGivebackDollars
                );

            double requiredUnrealized =
                Math.Max(
                    0,
                    protectedDailyPnL -
                    localBotDailyPnL
                );

            double dollarsPerPoint =
                pointValue *
                localEntryQuantity;

            if (dollarsPerPoint <= 0)
                return;

            double requiredPoints =
                requiredUnrealized /
                dollarsPerPoint;

            double protectionFloor;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                protectionFloor =
                    localEntryFillPrice +
                    requiredPoints;
            }
            else
            {
                protectionFloor =
                    localEntryFillPrice -
                    requiredPoints;
            }

            double trailCandidate;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                trailCandidate =
                    currentPrice
                    - DailyTargetTrailDistanceTicks
                    * tickSize;
            }
            else
            {
                trailCandidate =
                    currentPrice
                    + DailyTargetTrailDistanceTicks
                    * tickSize;
            }

            double desiredStop;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    Math.Max(
                        localActiveStopPrice,
                        Math.Max(
                            protectionFloor,
                            trailCandidate
                        )
                    );

                desiredStop =
                    Math.Min(
                        desiredStop,
                        currentPrice - tickSize
                    );
            }
            else
            {
                desiredStop =
                    Math.Min(
                        localActiveStopPrice,
                        Math.Min(
                            protectionFloor,
                            trailCandidate
                        )
                    );

                desiredStop =
                    Math.Max(
                        desiredStop,
                        currentPrice + tickSize
                    );
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "DAILY_TARGET_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    !dailyTargetProtectionArmed ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastDailyTargetProtectionChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastDailyTargetProtectionChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastDailyTargetProtectionStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastDailyTargetProtectionStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                lastDailyTargetProtectionChangeUtc =
                    reservationTimeUtc;

                lastDailyTargetProtectionStopPrice =
                    desiredStop;

                // V8:
                // Daily-target protection follows the same monotonic-stop
                // rule. Reserve the better stop before Account.Change()
                // so OCO Sync can never move it backwards.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                PrintBotMessage(
                    "DAILY TARGET TRAILING"
                    + " | Total PnL: "
                    + totalPnL.ToString("$0.00")
                    + " | Protected Floor: "
                    + protectedDailyPnL.ToString("$0.00")
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastDailyTargetProtectionStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastDailyTargetProtectionChangeUtc =
                            DateTime.MinValue;

                        lastDailyTargetProtectionStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "DAILY TARGET TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }

        // =====================================================
        // PROP-FIRM FORCE FLAT
        // =====================================================
        private void SetPersistentDailyLock(
            string reason)
        {
            string normalizedReason =
                string.IsNullOrWhiteSpace(reason)
                    ? "UNKNOWN"
                    : reason.Trim().ToUpperInvariant();

            bool changed =
                !persistentDailyLocked ||
                !string.Equals(
                    persistentDailyLockReason,
                    normalizedReason,
                    StringComparison.OrdinalIgnoreCase
                );

            persistentDailyLocked =
                true;

            persistentDailyLockReason =
                normalizedReason;

            SavePersistentDailyState();

            if (changed)
            {
                PrintBotMessage(
                    "DAILY LOCK SET"
                    + " | Reason: "
                    + persistentDailyLockReason
                    + " | Trades: "
                    + tradesToday
                    + " | Gross: "
                    + botDailyGrossPnL.ToString("$0.00")
                    + " | Fees: "
                    + botDailyFees.ToString("$0.00")
                    + " | Net: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Unrealized: "
                    + botUnrealizedPnL.ToString("$0.00")
                    + " | Total: "
                    + (botDailyPnL + botUnrealizedPnL).ToString("$0.00")
                    + " | ProfitFloor: "
                    + (
                        dailyProfitFloorArmed
                            ? dailyProtectedProfitFloor.ToString("$0.00")
                            : "OFF"
                      )
                );
            }
        }

        private void CheckForceFlatTime()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            // V1.6.14: release prior-session locks/counters exactly when the
            // next CME-style session begins. This runs even though automated
            // entries are still restricted to their configured windows.
            EnsureTradingDay(
                nowNy
            );

            if (
                forceFlatDateNy !=
                    nowNy.Date
            )
            {
                forceFlatDateNy =
                    nowNy.Date;

                forceFlatSentToday =
                    false;
            }

            if (
                premarketForceFlatDateNy !=
                    nowNy.Date
            )
            {
                premarketForceFlatDateNy =
                    nowNy.Date;

                premarketForceFlatSentToday =
                    false;
            }

            // V1.6.8 - close only a position that originated from the
            // premarket engine before the 09:30 cash open. This does NOT
            // create a daily lock and does not affect later AM entries.
            int nowTimeValue =
                ToTimeInt(
                    nowNy
                );

            bool localActivePremarketTrade;

            lock (executionStateLock)
            {
                localActivePremarketTrade =
                    activeTradeIsPremarket &&
                    entryQuantity > 0;
            }

            if (
                localActivePremarketTrade &&
                nowTimeValue >=
                    PremarketForceFlatTime &&
                nowTimeValue <
                    OpeningRangeStart &&
                !premarketForceFlatSentToday
            )
            {
                premarketForceFlatSentToday =
                    true;

                try
                {
                    executionStatus =
                        "PREMARKET FORCE FLAT";

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "PREMARKET FORCE FLAT START"
                        + " | "
                        + nowNy.ToString(
                            "HH:mm:ss"
                        )
                        + " ET"
                        + " | Before 09:30 cash open"
                    );

                    selectedAccount.Flatten(
                        new[]
                        {
                            selectedInstrument
                        }
                    );
                }
                catch (Exception ex)
                {
                    premarketForceFlatSentToday =
                        false;

                    PrintBotMessage(
                        "PREMARKET FORCE FLAT ERROR: "
                        + ex.Message
                    );
                }
            }

            // Weekend safety:
            // The 16:25 ET prop-firm force-flat rule must never create
            // a Daily Lock on Saturday or Sunday. Without this guard,
            // simply opening NinjaTrader on a weekend after 16:25 ET
            // creates a brand-new daily state with DailyLocked=true.
            if (
                nowNy.DayOfWeek ==
                    DayOfWeek.Saturday ||
                nowNy.DayOfWeek ==
                    DayOfWeek.Sunday
            )
            {
                return;
            }

            // The FORCE FLAT lock belongs only to the closing portion of
            // the current session. At 18:00 ET a new session has started, so
            // never recreate the old 16:25 lock after the session reset.
            if (
                nowTimeValue < ForceFlatTimeNy ||
                nowTimeValue >= TradingSessionResetTimeNy
            )
            {
                return;
            }

            // No new entries after the force-flat time on trading weekdays.
            SetPersistentDailyLock(
                "FORCE FLAT 16:25 ET"
            );

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (isFlat)
            {
                if (!forceFlatSentToday)
                {
                    forceFlatSentToday =
                        true;

                    executionStatus =
                        "FORCE FLAT - FLAT";

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "FORCE FLAT CHECK"
                        + " | "
                        + nowNy.ToString("HH:mm:ss")
                        + " ET"
                        + " | Position already FLAT."
                    );
                }

                return;
            }

            if (forceFlatSentToday)
                return;

            forceFlatSentToday =
                true;

            try
            {
                executionStatus =
                    "FORCE FLAT";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "FORCE FLAT START"
                    + " | "
                    + nowNy.ToString("HH:mm:ss")
                    + " ET"
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                );

                selectedAccount.Flatten(
                    new[]
                    {
                        selectedInstrument
                    }
                );

                PrintBotMessage(
                    "FORCE FLAT SENT"
                    + " | Account.Flatten"
                    + " | "
                    + selectedInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                forceFlatSentToday =
                    false;

                PrintBotMessage(
                    "FORCE FLAT ERROR: "
                    + ex.Message
                );
            }
        }

        private void UpdateUnrealizedPnL(
            double currentPrice)
        {
            Instrument instrument =
                selectedInstrument;

            double localEntryPrice;
            int localQuantity;
            MarketPosition localPosition;
            bool localManualTest;

            lock (executionStateLock)
            {
                localEntryPrice =
                    entryFillPrice;

                localQuantity =
                    entryQuantity;

                localPosition =
                    entryMarketPosition;

                localManualTest =
                    activeTradeIsManualTest;
            }

            if (
                instrument == null ||
                instrument.MasterInstrument == null ||
                localEntryPrice <= 0 ||
                localQuantity <= 0 ||
                localPosition ==
                    MarketPosition.Flat
            )
            {
                lock (executionStateLock)
                {
                    botUnrealizedPnL =
                        0;
                }

                UpdatePnlDisplay();
                return;
            }

            double pointValue =
                instrument
                    .MasterInstrument
                    .PointValue;

            double newUnrealizedPnL =
                0;

            if (
                localPosition ==
                    MarketPosition.Long
            )
            {
                newUnrealizedPnL =
                    (
                        currentPrice -
                        localEntryPrice
                    )
                    * pointValue
                    * localQuantity;
            }
            else if (
                localPosition ==
                    MarketPosition.Short
            )
            {
                newUnrealizedPnL =
                    (
                        localEntryPrice -
                        currentPrice
                    )
                    * pointValue
                    * localQuantity;
            }

            lock (executionStateLock)
            {
                // Do not apply a PnL calculation to a trade that
                // changed while this method was calculating it.
                if (
                    entryFillPrice !=
                        localEntryPrice ||
                    entryQuantity !=
                        localQuantity ||
                    entryMarketPosition !=
                        localPosition
                )
                {
                    return;
                }

                botUnrealizedPnL =
                    localManualTest
                        ? 0
                        : newUnrealizedPnL;

                if (
                    !localManualTest &&
                    activeLearningTrade != null
                )
                {
                    if (
                        botUnrealizedPnL >
                        activeLearningTrade.Mfe
                    )
                    {
                        activeLearningTrade.Mfe =
                            botUnrealizedPnL;
                    }

                    if (
                        botUnrealizedPnL <
                        activeLearningTrade.Mae
                    )
                    {
                        activeLearningTrade.Mae =
                            botUnrealizedPnL;
                    }
                }
            }

            UpdatePnlDisplay();
        }

        private void UpdatePnlDisplay()
        {
            double localGrossPnL;
            double localFees;
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;

            lock (executionStateLock)
            {
                localGrossPnL =
                    botDailyGrossPnL;

                localFees =
                    botDailyFees;

                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;
            }

            UpdateDailyProfitFloorState(
                totalPnL
            );

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (grossPnlText != null)
                    {
                        grossPnlText.Text =
                            localGrossPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (feesPnlText != null)
                    {
                        feesPnlText.Text =
                            localFees.ToString(
                                "$0.00"
                            );
                    }

                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (unrealizedPnlText != null)
                    {
                        unrealizedPnlText.Text =
                            localUnrealizedPnL.ToString(
                                "$0.00"
                            );

                        unrealizedPnlText.Foreground =
                            localUnrealizedPnL > 0
                                ? Brushes.LimeGreen
                                : localUnrealizedPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }

                    if (totalPnlText != null)
                    {
                        totalPnlText.Text =
                            totalPnL.ToString(
                                "$0.00"
                            );

                        totalPnlText.Foreground =
                            totalPnL > 0
                                ? Brushes.LimeGreen
                                : totalPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }
                })
            );
        }

        // =====================================================
        // V1.6.4 - DYNAMIC DAILY / SESSION PROFIT FLOOR
        // =====================================================
        private void UpdateDailyProfitFloorState(
            double totalPnL)
        {
            bool newlyArmed = false;
            bool floorRaised = false;
            double localPeak;
            double localRealized;
            double localFloor;

            lock (executionStateLock)
            {
                // Keep Daily Peak as TOTAL PnL for telemetry/diagnostics.
                // IMPORTANT V1.6.14 PROFIT-FLOOR FIX:
                // Unrealized MFE may raise the displayed session peak, but it
                // must NOT create or raise a hard session floor by itself.
                // The protected floor is based only on BANKED/REALIZED profit.
                // This prevents a first trade that briefly goes +$75 floating
                // from arming a $37.50 floor and then flattening on normal noise.
                if (totalPnL > dailyPeakTotalPnL)
                {
                    dailyPeakTotalPnL =
                        totalPnL;
                }

                localRealized =
                    botDailyPnL;

                double activationThreshold =
                    Math.Max(
                        DailyProfitFloorActivationMinDollars,
                        activeDailyTarget *
                            DailyProfitFloorTargetActivationFactor
                    );

                // Arm/raise protection only from REALIZED session profits.
                // Once armed, the floor remains monotonic and can never loosen.
                if (localRealized >= activationThreshold)
                {
                    double candidateFloor =
                        localRealized *
                        DailyProfitFloorRetentionFactor;

                    if (!dailyProfitFloorArmed)
                    {
                        dailyProfitFloorArmed = true;
                        newlyArmed = true;
                    }

                    if (candidateFloor > dailyProtectedProfitFloor)
                    {
                        dailyProtectedProfitFloor =
                            candidateFloor;

                        if (
                            newlyArmed ||
                            dailyProtectedProfitFloor -
                                lastLoggedProtectedProfitFloor >=
                                    DailyProfitFloorLogStepDollars
                        )
                        {
                            floorRaised = true;
                            lastLoggedProtectedProfitFloor =
                                dailyProtectedProfitFloor;
                        }
                    }
                }

                localPeak = dailyPeakTotalPnL;
                localFloor = dailyProtectedProfitFloor;
            }

            if (newlyArmed || floorRaised)
            {
                SavePersistentDailyState();

                PrintBotMessage(
                    "DAILY PROFIT FLOOR "
                    + (newlyArmed ? "ARMED" : "RAISED")
                    + " | TotalPeak: "
                    + localPeak.ToString("$0.00")
                    + " | RealizedBasis: "
                    + localRealized.ToString("$0.00")
                    + " | Protected: "
                    + localFloor.ToString("$0.00")
                    + " | Retention: 50%"
                );
            }
        }

        private void CheckDailyLossEmergency()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null ||
                !IsSimulationAccount(selectedAccount)
            )
            {
                return;
            }

            double totalPnL =
                botDailyPnL +
                botUnrealizedPnL;

            UpdateDailyProfitFloorState(
                totalPnL
            );

            bool localProfitFloorArmed;
            double localProtectedProfitFloor;

            lock (executionStateLock)
            {
                localProfitFloorArmed =
                    dailyProfitFloorArmed;

                localProtectedProfitFloor =
                    dailyProtectedProfitFloor;
            }

            bool profitFloorActuallyHit =
                localProfitFloorArmed &&
                localProtectedProfitFloor > 0 &&
                totalPnL <=
                    localProtectedProfitFloor;

            MarketPosition actualSide;
            int actualQty;
            double actualAvgPrice;

            bool actualFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAvgPrice
                );

            if (actualFlat)
            {
                if (
                    profitFloorActuallyHit &&
                    !persistentDailyLocked
                )
                {
                    SetPersistentDailyLock(
                        "DAILY PROFIT FLOOR"
                    );

                    PrintBotMessage(
                        "DAILY PROFIT FLOOR HIT"
                        + " | Realized: "
                        + botDailyPnL.ToString("$0.00")
                        + " | Unrealized: "
                        + botUnrealizedPnL.ToString("$0.00")
                        + " | Total: "
                        + totalPnL.ToString("$0.00")
                        + " | Protected Floor: "
                        + localProtectedProfitFloor.ToString("$0.00")
                        + " | FLAT - TRADING LOCKED."
                    );
                }
                if (riskFlattenSent)
                {
                    executionStatus =
                        persistentDailyLocked
                            ? "DAILY RISK LOCK"
                            : "FLAT CONFIRMED";

                    PrintBotMessage(
                        "FLATTEN CONFIRMED | Position: FLAT"
                    );

                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;
                    UpdateExecutionMonitor();
                }

                return;
            }

            // Hard flatten remains mandatory for configured DAILY LOSS.
            // V1.6.4 also flattens when the protected daily/session profit
            // floor is touched after being armed.
            // A DailyLocked state caused by profit target or force-flat time
            // must never be mistaken for a loss emergency.
            bool dailyLossActuallyHit =
                totalPnL <=
                    -activeDailyLoss;

            if (
                !dailyLossActuallyHit &&
                !profitFloorActuallyHit
            )
            {
                return;
            }

            string riskLockReason =
                dailyLossActuallyHit
                    ? "DAILY LOSS"
                    : "DAILY PROFIT FLOOR";

            if (!riskFlattenSent)
            {
                SetPersistentDailyLock(
                    riskLockReason
                );

                riskFlattenSent = true;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                SavePersistentDailyState();

                executionStatus =
                    dailyLossActuallyHit
                        ? "DAILY LOSS FLATTEN"
                        : "PROFIT FLOOR FLATTEN";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    (
                        dailyLossActuallyHit
                            ? "DAILY LOSS LIMIT HIT"
                            : "DAILY PROFIT FLOOR HIT"
                    )
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Unrealized: "
                    + botUnrealizedPnL.ToString("$0.00")
                    + " | Total: "
                    + totalPnL.ToString("$0.00")
                    + (
                        profitFloorActuallyHit
                            ? " | Protected Floor: "
                                + localProtectedProfitFloor.ToString("$0.00")
                            : " | Daily Loss Limit: -"
                                + activeDailyLoss.ToString("$0.00")
                      )
                    + " | HARD FLATTEN STARTED."
                );
            }

            // Throttle emergency actions. Range updates can arrive many times
            // per second; a flatten attempt is allowed at most once per second.
            DateTime nowUtc = DateTime.UtcNow;

            if (
                riskFlattenLastActionUtc != DateTime.MinValue &&
                (nowUtc - riskFlattenLastActionUtc).TotalMilliseconds < 1000
            )
            {
                return;
            }

            try
            {
                if (riskFlattenStage == 0)
                {
                    selectedAccount.Flatten(
                        new[] { selectedInstrument }
                    );

                    riskFlattenStage = 1;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 1"
                        + " | Account.Flatten sent"
                        + " | Position: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                if (riskFlattenStage == 1)
                {
                    selectedAccount.CancelAllOrders(
                        selectedInstrument
                    );

                    riskFlattenStage = 2;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 2"
                        + " | CancelAllOrders sent"
                        + " | Position still: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                bool canSubmitFallback =
                    riskFlattenOrder == null ||
                    riskFlattenOrder.OrderState == OrderState.Filled ||
                    riskFlattenOrder.OrderState == OrderState.Cancelled ||
                    riskFlattenOrder.OrderState == OrderState.Rejected;

                if (!canSubmitFallback)
                {
                    riskFlattenLastActionUtc = nowUtc;
                    return;
                }

                // V1.6.12 - refresh the REAL position immediately before
                // the market fallback. Partial fills may have changed the
                // quantity since the first snapshot at the top of this method.
                MarketPosition fallbackSide;
                int fallbackQty;
                double fallbackAvgPrice;

                bool fallbackFlat =
                    TryGetSelectedInstrumentPosition(
                        out fallbackSide,
                        out fallbackQty,
                        out fallbackAvgPrice
                    );

                if (
                    fallbackFlat ||
                    fallbackQty <= 0 ||
                    fallbackSide == MarketPosition.Flat
                )
                {
                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;
                    executionStatus =
                        persistentDailyLocked
                            ? "DAILY RISK LOCK"
                            : "FLAT CONFIRMED";
                    UpdateExecutionMonitor();
                    return;
                }

                OrderAction closeAction =
                    fallbackSide == MarketPosition.Long
                        ? OrderAction.Sell
                        : OrderAction.BuyToCover;

                riskFlattenOrder =
                    selectedAccount.CreateOrder(
                        selectedInstrument,
                        closeAction,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        fallbackQty,
                        0,
                        0,
                        string.Empty,
                        GetProfileOrderName("JJ_RISK_FLATTEN"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                selectedAccount.Submit(
                    new[] { riskFlattenOrder }
                );

                riskFlattenStage = 3;
                riskFlattenLastActionUtc = nowUtc;

                executionStatus =
                    "HARD FLATTEN MARKET";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "DAILY LOSS FLATTEN FALLBACK"
                    + " | MARKET " + closeAction
                    + " " + fallbackQty
                    + " | Position was: " + fallbackSide
                );
            }
            catch (Exception ex)
            {
                riskFlattenLastActionUtc = nowUtc;

                PrintBotMessage(
                    "DAILY LOSS FLATTEN ERROR: "
                    + ex.Message
                );
            }
        }

        // Returns true when the REAL account position for the selected
        // instrument is flat. This deliberately does not rely only on the
        // bot's internal entryMarketPosition flag.
        private bool TryGetSelectedInstrumentPosition(
            out MarketPosition marketPosition,
            out int quantity,
            out double averagePrice)
        {
            marketPosition = MarketPosition.Flat;
            quantity = 0;
            averagePrice = 0;

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return true;
            }

            lock (selectedAccount.Positions)
            {
                foreach (Position position in selectedAccount.Positions)
                {
                    if (
                        position == null ||
                        position.Instrument == null ||
                        position.Instrument.FullName !=
                            selectedInstrument.FullName
                    )
                    {
                        continue;
                    }

                    marketPosition = position.MarketPosition;
                    quantity = position.Quantity;
                    averagePrice = position.AveragePrice;

                    return
                        marketPosition == MarketPosition.Flat ||
                        quantity <= 0;
                }
            }

            return true;
        }


        // =====================================================
        // V1.6.14R - POSITION RECOVERY / TRAILING RESUME
        //
        // Safety goal:
        // If the app/bot is restarted while NinjaTrader still has an
        // open position for the selected Account + Instrument, adopt the
        // real account position instead of treating the bot as flat.
        //
        // The method:
        // 1) reads the REAL account position,
        // 2) re-attaches the existing profile STOP/TARGET when present,
        // 3) restores the internal entry/qty/side state,
        // 4) derives the trailing stage from the CURRENT stop so that a
        //    restart can NEVER move protection backwards,
        // 5) if no complete bracket exists, SyncProtectiveBracketToEntry
        //    rebuilds protection using the existing safety logic.
        //
        // It deliberately does NOT increment session trade counters and
        // does NOT create a new Learning trade. This is adoption of an
        // already-open position, not a new entry.
        // =====================================================
        // =====================================================
        // V1.6.14R2 - DELAYED POSITION RECOVERY RETRY
        // =====================================================
        private void StartPositionRecoveryRetry()
        {
            StopPositionRecoveryRetry();

            positionRecoveryAttempts = 0;
            positionRecoveryPending = true;

            positionRecoveryTimer =
                new DispatcherTimer(
                    DispatcherPriority.Normal,
                    Dispatcher
                );

            positionRecoveryTimer.Interval =
                TimeSpan.FromMilliseconds(
                    PositionRecoveryRetryMilliseconds
                );

            positionRecoveryTimer.Tick +=
                PositionRecoveryTimerTick;

            positionRecoveryTimer.Start();

            PrintBotMessage(
                "POSITION RECOVERY WAIT"
                + " | NinjaTrader position sync retry armed"
                + " | MaxAttempts: "
                + PositionRecoveryMaxAttempts
                + " | Every: "
                + PositionRecoveryRetryMilliseconds
                + "ms"
            );
        }

        private void StopPositionRecoveryRetry()
        {
            DispatcherTimer timer =
                positionRecoveryTimer;

            positionRecoveryTimer = null;
            positionRecoveryPending = false;
            positionRecoveryAttempts = 0;

            if (timer == null)
                return;

            try
            {
                timer.Stop();
                timer.Tick -=
                    PositionRecoveryTimerTick;
            }
            catch
            {
            }
        }

        private void PositionRecoveryTimerTick(
            object sender,
            EventArgs e)
        {
            if (!botRunning)
            {
                StopPositionRecoveryRetry();
                return;
            }

            positionRecoveryAttempts++;

            MarketPosition scanSide =
                MarketPosition.Flat;

            int scanQty = 0;
            double scanAverage = 0;

            bool scanFlat = true;

            try
            {
                scanFlat =
                    TryGetSelectedInstrumentPosition(
                        out scanSide,
                        out scanQty,
                        out scanAverage
                    );
            }
            catch
            {
                scanFlat = true;
            }

            PrintBotMessage(
                "POSITION RECOVERY SCAN"
                + " | Attempt: "
                + positionRecoveryAttempts
                + "/"
                + PositionRecoveryMaxAttempts
                + " | Flat: "
                + scanFlat
                + " | Side: "
                + scanSide
                + " | Qty: "
                + scanQty
                + " | Avg: "
                + (
                    scanAverage > 0
                        ? FormatPrice(scanAverage)
                        : "0"
                  )
            );

            if (!scanFlat)
            {
                bool recovered =
                    TryRecoverExistingPosition();

                if (recovered)
                {
                    positionRecoveryPending = false;

                    PrintBotMessage(
                        "POSITION RECOVERY COMPLETE"
                        + " | Delayed account sync adopted successfully"
                        + " | Attempt: "
                        + positionRecoveryAttempts
                    );

                    StopPositionRecoveryRetry();
                    PublishSharedState();
                    return;
                }
            }

            if (
                positionRecoveryAttempts >=
                    PositionRecoveryMaxAttempts
            )
            {
                PrintBotMessage(
                    "POSITION RECOVERY WINDOW COMPLETE"
                    + " | No adoptable position found after "
                    + PositionRecoveryMaxAttempts
                    + " attempts."
                );

                StopPositionRecoveryRetry();
            }
        }

        private bool TryRecoverExistingPosition()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(account)
            )
            {
                return false;
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (
                isFlat ||
                actualSide == MarketPosition.Flat ||
                actualQty <= 0 ||
                actualAverage <= 0
            )
            {
                return false;
            }

            PrintBotMessage(
                "EXISTING POSITION DETECTED"
                + " | Account: " + account.Name
                + " | Instrument: " + instrument.FullName
                + " | Side: " + actualSide
                + " | Qty: " + actualQty
                + " | Avg: " + FormatPrice(actualAverage)
            );

            Order recoveredStop = null;
            Order recoveredTarget = null;

            string expectedStopName =
                GetProfileOrderName("JJ_STOP");

            string expectedTargetName =
                GetProfileOrderName("JJ_TARGET");

            try
            {
                lock (account.Orders)
                {
                    foreach (Order order in account.Orders)
                    {
                        if (
                            order == null ||
                            order.Instrument == null ||
                            order.Instrument.FullName != instrument.FullName
                        )
                        {
                            continue;
                        }

                        bool activeOrder =
                            order.OrderState == OrderState.Working ||
                            order.OrderState == OrderState.Accepted ||
                            order.OrderState == OrderState.Submitted ||
                            order.OrderState == OrderState.ChangePending ||
                            order.OrderState == OrderState.ChangeSubmitted;

                        if (!activeOrder)
                            continue;

                        string orderName =
                            order.Name ?? string.Empty;

                        if (
                            recoveredStop == null &&
                            string.Equals(
                                orderName,
                                expectedStopName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.StopPrice > 0
                        )
                        {
                            recoveredStop = order;
                            continue;
                        }

                        if (
                            recoveredTarget == null &&
                            string.Equals(
                                orderName,
                                expectedTargetName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.LimitPrice > 0
                        )
                        {
                            recoveredTarget = order;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "POSITION RECOVERY ORDER SCAN ERROR: "
                    + ex.Message
                );
            }

            double tickSize =
                instrument.MasterInstrument != null
                    ? instrument.MasterInstrument.TickSize
                    : 0;

            int recoveredStage = 0;
            double recoveredStopPrice =
                recoveredStop != null
                    ? recoveredStop.StopPrice
                    : 0;

            double recoveredTargetPrice =
                recoveredTarget != null
                    ? recoveredTarget.LimitPrice
                    : 0;

            if (
                tickSize > 0 &&
                recoveredStopPrice > 0
            )
            {
                double protectedTicks =
                    actualSide == MarketPosition.Long
                        ? (
                            recoveredStopPrice -
                            actualAverage
                          ) / tickSize
                        : (
                            actualAverage -
                            recoveredStopPrice
                          ) / tickSize;

                // Derive the minimum already-achieved protection stage
                // from the live stop. This is intentionally conservative:
                // a restart may resume at the same/better stop, never worse.
                if (protectedTicks >= MomentumLock2ProfitTicks)
                    recoveredStage = 3;
                else if (protectedTicks >= MomentumLockProfitTicks)
                    recoveredStage = 2;
                else if (protectedTicks >= 0)
                    recoveredStage = 1;
            }

            lock (executionStateLock)
            {
                entryPending = false;
                pendingEntryRequestedQuantity = 0;
                entryOrder = null;

                entryFillPrice = actualAverage;
                entryQuantity = actualQty;
                entryMarketPosition = actualSide;

                stopOrder = recoveredStop;
                targetOrder = recoveredTarget;

                activeStopPrice = recoveredStopPrice;
                activeTargetPrice = recoveredTargetPrice;

                if (
                    tickSize > 0 &&
                    recoveredTargetPrice > 0
                )
                {
                    double targetTicks =
                        actualSide == MarketPosition.Long
                            ? (
                                recoveredTargetPrice -
                                actualAverage
                              ) / tickSize
                            : (
                                actualAverage -
                                recoveredTargetPrice
                              ) / tickSize;

                    activeEffectiveTargetTicks =
                        Math.Max(
                            1,
                            (int)Math.Round(targetTicks)
                        );
                }
                else
                {
                    activeEffectiveTargetTicks =
                        activeTargetTicks;
                }

                activeExitQuantity = 0;
                activeExitGrossPnL = 0;
                activeExitCommission = 0;

                // Every current bot entry is protected by the momentum
                // capital-protection engine. Recovery resumes that engine.
                activeEntryUsesMomentumTrailing = true;
                activeStrongMomentumProtection = false;
                activeBreakEvenTriggerTicks =
                    MomentumBreakEvenTriggerTicks;

                momentumTrailingStage =
                    recoveredStage;

                lastMomentumTrailingStopPrice =
                    recoveredStopPrice;

                lastMomentumTrailingChangeUtc =
                    DateTime.MinValue;

                dailyTargetProtectionArmed = false;
                lastDailyTargetProtectionStopPrice = 0;
                lastDailyTargetProtectionChangeUtc =
                    DateTime.MinValue;

                executionStatus =
                    recoveredStop != null &&
                    recoveredTarget != null
                        ? "RECOVERED - PROTECTED"
                        : "RECOVERING PROTECTION";
            }

            UpdateExecutionMonitor();

            PrintBotMessage(
                "POSITION ADOPTED"
                + " | Side: " + actualSide
                + " | Qty: " + actualQty
                + " | Entry: " + FormatPrice(actualAverage)
                + " | Existing SL: "
                + (
                    recoveredStopPrice > 0
                        ? FormatPrice(recoveredStopPrice)
                        : "NONE"
                  )
                + " | Existing TP: "
                + (
                    recoveredTargetPrice > 0
                        ? FormatPrice(recoveredTargetPrice)
                        : "NONE"
                  )
                + " | TrailingStage: "
                + recoveredStage
            );

            if (
                recoveredStop == null &&
                recoveredTarget == null
            )
            {
                PrintBotMessage(
                    "POSITION RECOVERY - NO OCO FOUND"
                    + " | Building a fresh protective bracket"
                    + " for the recovered position."
                );

                SubmitProtectiveBracket(
                    actualAverage,
                    actualQty,
                    actualSide
                );
            }
            else if (
                recoveredStop == null ||
                recoveredTarget == null
            )
            {
                // Never create a second bracket on top of one surviving
                // protective order. That could duplicate exposure or
                // accidentally replace a better live stop.
                PrintBotMessage(
                    "POSITION RECOVERY WARNING - PARTIAL OCO FOUND"
                    + " | Existing SL: "
                    + (
                        recoveredStopPrice > 0
                            ? FormatPrice(recoveredStopPrice)
                            : "NONE"
                      )
                    + " | Existing TP: "
                    + (
                        recoveredTargetPrice > 0
                            ? FormatPrice(recoveredTargetPrice)
                            : "NONE"
                      )
                    + " | No duplicate bracket submitted."
                );
            }

            PrintBotMessage(
                "TRADE PROTECTION RESUMED"
                + " | BE +" + MomentumBreakEvenTriggerTicks + "t"
                + " | LOCK +" + MomentumLockProfitTicks
                + "t @ +" + MomentumLockTriggerTicks + "t"
                + " | LOCK2 +" + MomentumLock2ProfitTicks
                + "t @ +" + MomentumLock2TriggerTicks + "t"
                + " | TRAIL " + MomentumTrailDistanceTicks
                + "t @ +" + MomentumTrailTriggerTicks + "t"
                + " | NEVER-WORSEN ACTIVE"
            );

            return true;
        }

        private void UpdateExecutionMonitor()
        {
            MarketPosition localPosition;
            int localQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            int localStopTicks;
            int localTargetTicks;

            lock (executionStateLock)
            {
                localPosition =
                    entryMarketPosition;

                localQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localStopTicks =
                    activeStopTicks;

                localTargetTicks =
                    activeTargetTicks;
            }

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (positionText != null)
                    {
                        if (
                            localPosition ==
                                MarketPosition.Long
                        )
                        {
                            positionText.Text =
                                "LONG";

                            positionText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localPosition ==
                                MarketPosition.Short
                        )
                        {
                            positionText.Text =
                                "SHORT";

                            positionText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else
                        {
                            positionText.Text =
                                "FLAT";

                            positionText.Foreground =
                                Brushes.White;
                        }
                    }

                    if (positionQtyText != null)
                    {
                        positionQtyText.Text =
                            localQuantity.ToString();
                    }

                    if (entryPriceText != null)
                    {
                        entryPriceText.Text =
                            localEntryPrice > 0
                                ? FormatPrice(
                                    localEntryPrice
                                )
                                : "--";
                    }

                    if (stopPriceText != null)
                    {
                        stopPriceText.Text =
                            localStopPrice > 0
                                ? FormatPrice(
                                    localStopPrice
                                )
                                : "--";
                    }

                    if (targetPriceText != null)
                    {
                        targetPriceText.Text =
                            localTargetPrice > 0
                                ? FormatPrice(
                                    localTargetPrice
                                )
                                : "--";
                    }

                    if (riskRewardText != null)
                    {
                        double riskDistance =
                            0;

                        double rewardDistance =
                            0;

                        if (
                            localEntryPrice > 0 &&
                            localStopPrice > 0 &&
                            localTargetPrice > 0
                        )
                        {
                            riskDistance =
                                Math.Abs(
                                    localEntryPrice -
                                    localStopPrice
                                );

                            rewardDistance =
                                Math.Abs(
                                    localTargetPrice -
                                    localEntryPrice
                                );
                        }

                        double rr =
                            riskDistance > 0
                                ? rewardDistance /
                                    riskDistance
                                : (
                                    localStopTicks > 0
                                        ? (
                                            double
                                            )localTargetTicks
                                            / localStopTicks
                                        : 0
                                );

                        riskRewardText.Text =
                            "1 : "
                            + rr.ToString(
                                "0.00"
                            );
                    }

                    if (orderStatusText != null)
                    {
                        orderStatusText.Text =
                            localExecutionStatus;

                        if (
                            localExecutionStatus ==
                                "PROTECTED"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localExecutionStatus ==
                                "STOP FILLED" ||
                            localExecutionStatus ==
                                "ENTRY ERROR" ||
                            localExecutionStatus ==
                                "PROTECTION ERROR" ||
                            localExecutionStatus ==
                                "DAILY LOSS FLATTEN"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else if (
                            localExecutionStatus ==
                                "ENTRY SUBMITTED" ||
                            localExecutionStatus ==
                                "ENTRY FILLED" ||
                            localExecutionStatus ==
                                "FLATTENING" ||
                            localExecutionStatus ==
                                "WAITING PROTECTION" ||
                            localExecutionStatus ==
                                "UPDATING OCO"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.Goldenrod;
                        }
                        else
                        {
                            orderStatusText.Foreground =
                                Brushes.White;
                        }
                    }
                })
            );
        }

        private void ResetExecutionMonitor()
        {
            lock (executionStateLock)
            {
                entryFillPrice = 0;
                activeStopPrice = 0;
                activeTargetPrice = 0;
                entryQuantity = 0;
                activeEffectiveTargetTicks = 0;
                activeExitQuantity = 0;
                activeExitGrossPnL = 0;
                activeExitCommission = 0;
                activeEntryCommission = 0;

                pendingTradeSetupConfidence = 0;
                pendingTradeSetupQuality = string.Empty;
                pendingTradeSetupTiming = string.Empty;
                pendingTradeManipulationState = string.Empty;
                activeTradeSetupConfidence = 0;
                activeTradeSetupQuality = string.Empty;
                activeTradeSetupTiming = string.Empty;
                activeTradeManipulationState = string.Empty;

                protectiveChangeInFlight = false;
                activeProtectiveChangeToken = 0;
                protectiveChangeOwner =
                    string.Empty;
                protectiveChangeStartedUtc =
                    DateTime.MinValue;

                botUnrealizedPnL = 0;
                riskFlattenSent = false;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                entryMarketPosition =
                    MarketPosition.Flat;

                executionStatus =
                    "WAITING";

                activeEntryUsesMomentumTrailing =
                    false;

                momentumTrailingStage =
                    0;

                lastMomentumTrailingStopPrice =
                    0;

                activeStrongMomentumProtection =
                    false;

                activeBreakEvenTriggerTicks =
                    MomentumBreakEvenTriggerTicks;

                lastMomentumTrailingChangeUtc =
                    DateTime.MinValue;

                dailyTargetProtectionArmed =
                    false;

                lastDailyTargetProtectionStopPrice =
                    0;

                lastDailyTargetProtectionChangeUtc =
                    DateTime.MinValue;
            }

            UpdateExecutionMonitor();
        }

        private void UpdateExecutionUi()
        {
            UpdatePnlDisplay();

            double localRealizedPnL;
            double localUnrealizedPnL;
            int localAmTrades;
            int localPmTrades;
            bool localDailyLocked;

            lock (executionStateLock)
            {
                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localDailyLocked =
                    persistentDailyLocked;
            }

            double localTotalPnL =
                localRealizedPnL +
                localUnrealizedPnL;

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (tradesText != null)
                    {
                        tradesText.Text =
                            "AM "
                            + localAmTrades
                            + "/"
                            + activeMaxTrades
                            + " | PM "
                            + localPmTrades
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        localDailyLocked ||
                        localTotalPnL >=
                            activeDailyTarget ||
                        localTotalPnL <=
                            -activeDailyLoss
                    )
                    {
                        if (signalText != null)
                        {
                            signalText.Text =
                                "DAILY RISK LOCK";

                            signalText.Foreground =
                                Brushes.OrangeRed;
                        }
                    }
                })
            );
        }

        // =====================================================
        // LIQUIDITY SWEEP + BOS / CHOCH
        //
        // LONG SEQUENCE:
        // 1) A closed bar trades below the lowest low of the
        //    previous SweepLookback bars.
        // 2) That same bar closes back ABOVE that prior low.
        //    -> LOW SWEPT
        // 3) Within SweepMaxAgeBars, price CLOSES above the
        //    pre-sweep structure high.
        //    -> BULLISH BOS / CHOCH
        //
        // SHORT is the inverse.
        // =====================================================
        private void DetectLiquidityAndStructure(
            Bars bars,
            int closedBarIndex,
            out string liquidityState,
            out string structureState,
            out bool bullishConfirmed,
            out bool bearishConfirmed,
            out string bullishSetupKey,
            out string bearishSetupKey)
        {
            liquidityState =
                "NONE";

            structureState =
                "WAITING";

            bullishConfirmed =
                false;

            bearishConfirmed =
                false;

            bullishSetupKey =
                string.Empty;

            bearishSetupKey =
                string.Empty;

            if (
                bars == null ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                closedBarIndex <
                    SweepLookback + StructureLookback
            )
            {
                return;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
            {
                return;
            }

            double minimumSweepDistance =
                MinimumSweepTicks
                * tickSize;

            string consumedBullishKey;
            string consumedBearishKey;
            DateTime consumedBullishConfirmTime;
            DateTime consumedBearishConfirmTime;

            lock (executionStateLock)
            {
                consumedBullishKey =
                    consumedBullishStructureSetupKey
                    ?? string.Empty;

                consumedBearishKey =
                    consumedBearishStructureSetupKey
                    ?? string.Empty;

                consumedBullishConfirmTime =
                    consumedBullishStructureConfirmTime;

                consumedBearishConfirmTime =
                    consumedBearishStructureConfirmTime;
            }

            int firstSweepIndex =
                Math.Max(
                    SweepLookback,
                    closedBarIndex
                        - SweepMaxAgeBars
                );

            int latestLiquidityIndex =
                -1;

            int latestBullishConfirmIndex =
                -1;

            int latestBearishConfirmIndex =
                -1;

            int latestBullishSweepIndex =
                -1;

            int latestBearishSweepIndex =
                -1;

            string latestBullishSetupKey =
                string.Empty;

            string latestBearishSetupKey =
                string.Empty;

            // Scan oldest -> newest so the most recent valid,
            // UNCONSUMED structural event wins.
            for (
                int sweepIndex =
                    firstSweepIndex;
                sweepIndex <= closedBarIndex;
                sweepIndex++
            )
            {
                int priorStart =
                    Math.Max(
                        0,
                        sweepIndex
                            - SweepLookback
                    );

                int priorEnd =
                    sweepIndex - 1;

                if (
                    priorEnd <= priorStart
                )
                {
                    continue;
                }

                double priorLow =
                    GetLowestLow(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double priorHigh =
                    GetHighestHigh(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double sweepLow =
                    bars.GetLow(
                        sweepIndex
                    );

                double sweepHigh =
                    bars.GetHigh(
                        sweepIndex
                    );

                double sweepClose =
                    bars.GetClose(
                        sweepIndex
                    );

                // A sweep must reclaim the prior level AND exceed it
                // by at least MinimumSweepTicks. One-tick noise is ignored.
                bool lowSweep =
                    (
                        priorLow -
                        sweepLow
                    ) >=
                        minimumSweepDistance &&
                    sweepClose >
                        priorLow;

                bool highSweep =
                    (
                        sweepHigh -
                        priorHigh
                    ) >=
                        minimumSweepDistance &&
                    sweepClose <
                        priorHigh;

                // One candle can legitimately sweep both sides.
                // Represent that explicitly instead of allowing the
                // HIGH branch to overwrite the LOW branch.
                if (
                    (lowSweep || highSweep) &&
                    sweepIndex >=
                        latestLiquidityIndex
                )
                {
                    latestLiquidityIndex =
                        sweepIndex;

                    liquidityState =
                        lowSweep && highSweep
                            ? "BOTH SWEPT"
                            : lowSweep
                                ? "LOW SWEPT"
                                : "HIGH SWEPT";
                }

                // ---------------------------------------------
                // BULLISH STRUCTURE BREAK AFTER LOW SWEEP
                // ---------------------------------------------
                if (lowSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureHigh =
                        GetHighestHigh(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            > structureHigh
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    true,
                                    sweepIndex,
                                    confirmIndex
                                );

                            // The FIRST close through the pre-sweep
                            // structure level defines this setup.
                            // If it was already filled/consumed, do not
                            // reinterpret later closes as a new setup.
                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBullishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBullishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBullishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBullishConfirmIndex
                            )
                            {
                                latestBullishConfirmIndex =
                                    confirmIndex;

                                latestBullishSweepIndex =
                                    sweepIndex;

                                latestBullishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }

                // ---------------------------------------------
                // BEARISH STRUCTURE BREAK AFTER HIGH SWEEP
                // ---------------------------------------------
                if (highSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureLow =
                        GetLowestLow(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            < structureLow
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    false,
                                    sweepIndex,
                                    confirmIndex
                                );

                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBearishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBearishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBearishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBearishConfirmIndex
                            )
                            {
                                latestBearishConfirmIndex =
                                    confirmIndex;

                                latestBearishSweepIndex =
                                    sweepIndex;

                                latestBearishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }
            }

            // Pick the most recent UNCONSUMED structural break.
            if (
                latestBullishConfirmIndex >
                    latestBearishConfirmIndex
            )
            {
                bullishConfirmed =
                    true;

                bearishConfirmed =
                    false;

                bullishSetupKey =
                    latestBullishSetupKey;

                // BOS / CHOCH is classified from the EMA context that
                // existed BEFORE the sweep, not after the break.
                int contextIndex =
                    Math.Max(
                        0,
                        latestBullishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep <
                        slowBeforeSweep
                        ? "BULLISH CHOCH"
                        : "BULLISH BOS";
            }
            else if (
                latestBearishConfirmIndex >
                    latestBullishConfirmIndex
            )
            {
                bullishConfirmed =
                    false;

                bearishConfirmed =
                    true;

                bearishSetupKey =
                    latestBearishSetupKey;

                int contextIndex =
                    Math.Max(
                        0,
                        latestBearishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep >
                        slowBeforeSweep
                        ? "BEARISH CHOCH"
                        : "BEARISH BOS";
            }
        }

        private string BuildStructureSetupKey(
            Bars bars,
            bool isLong,
            int sweepIndex,
            int confirmIndex)
        {
            if (
                bars == null ||
                sweepIndex < 0 ||
                confirmIndex < 0 ||
                sweepIndex >= bars.Count ||
                confirmIndex >= bars.Count
            )
            {
                return string.Empty;
            }

            DateTime sweepTime =
                bars.GetTime(
                    sweepIndex
                );

            DateTime confirmTime =
                bars.GetTime(
                    confirmIndex
                );

            return
                (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
                + "|S:"
                + sweepTime.Ticks
                + "|C:"
                + confirmTime.Ticks;
        }

        private DateTime GetStructureConfirmTimeFromKey(
            string setupKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    setupKey
                )
            )
            {
                return DateTime.MinValue;
            }

            const string marker =
                "|C:";

            int markerIndex =
                setupKey.LastIndexOf(
                    marker,
                    StringComparison.Ordinal
                );

            if (
                markerIndex < 0
            )
            {
                return DateTime.MinValue;
            }

            string ticksText =
                setupKey.Substring(
                    markerIndex +
                    marker.Length
                );

            long ticks;

            if (
                !long.TryParse(
                    ticksText,
                    out ticks
                ) ||
                ticks <= 0 ||
                ticks > DateTime.MaxValue.Ticks
            )
            {
                return DateTime.MinValue;
            }

            try
            {
                return new DateTime(
                    ticks
                );
            }
            catch
            {
                return DateTime.MinValue;
            }
        }

        // =====================================================
        // HIGHEST HIGH IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        private double GetHighestHigh(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double highest =
                bars.GetHigh(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetHigh(i);

                if (
                    value > highest
                )
                {
                    highest =
                        value;
                }
            }

            return highest;
        }

        // =====================================================
        // LOWEST LOW IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        private double GetLowestLow(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double lowest =
                bars.GetLow(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetLow(i);

                if (
                    value < lowest
                )
                {
                    lowest =
                        value;
                }
            }

            return lowest;
        }

        // =====================================================
        // SESSION VWAP
        //
        // This is a 5-minute OHLCV session VWAP calculation:
        // TypicalPrice = (High + Low + Close) / 3
        // weighted by each 5-minute bar's volume.
        //
        // VWAP starts at 09:30 New York time each day.
        // =====================================================
        private double CalculateSessionVwap(
            Bars bars,
            int endIndex)
        {
            if (
                bars == null ||
                endIndex < 0 ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            DateTime endNyTime =
                ConvertToNewYorkTime(
                    bars.GetTime(
                        endIndex
                    )
                );

            DateTime sessionDate =
                endNyTime.Date;

            double cumulativePriceVolume =
                0;

            double cumulativeVolume =
                0;

            for (
                int i = endIndex;
                i >= 0;
                i--
            )
            {
                DateTime barNyTime =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNyTime.Date <
                    sessionDate
                )
                {
                    break;
                }

                if (
                    barNyTime.Date !=
                    sessionDate
                )
                {
                    continue;
                }

                int nyTime =
                    ToTimeInt(
                        barNyTime
                    );

                if (
                    nyTime <
                    RthVwapStart
                )
                {
                    break;
                }

                long volume =
                    bars.GetVolume(i);

                if (volume <= 0)
                    continue;

                double typicalPrice =
                    (
                        bars.GetHigh(i)
                        + bars.GetLow(i)
                        + bars.GetClose(i)
                    )
                    / 3.0;

                cumulativePriceVolume +=
                    typicalPrice
                    * volume;

                cumulativeVolume +=
                    volume;
            }

            if (
                cumulativeVolume <= 0
            )
            {
                return 0;
            }

            return
                cumulativePriceVolume
                / cumulativeVolume;
        }

        // =====================================================
        // NY SESSION FILTER
        // =====================================================
        private bool IsPremarketSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            return
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;
        }

        private bool IsBotNySessionActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            bool premarketSession =
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;

            bool session1 =
                value >= BotSession1Start &&
                value <= BotSession1End;

            bool middaySession =
                value >= BotMiddayStart &&
                value <= BotMiddayEnd;

            bool session2 =
                value >= BotSession2Start &&
                value <= BotSession2End;

            return
                premarketSession ||
                session1 ||
                middaySession ||
                session2;
        }

        private string GetBotSessionWindow(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            if (
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd
            )
            {
                return "PREMARKET";
            }

            if (
                value >= BotSession1Start &&
                value <= BotSession1End
            )
            {
                return "AM";
            }

            if (
                value >= BotMiddayStart &&
                value <= BotMiddayEnd
            )
            {
                return "MIDDAY";
            }

            if (
                value >= BotSession2Start &&
                value <= BotSession2End
            )
            {
                return "PM";
            }

            return "OUTSIDE";
        }

        private int GetSessionTradeCount(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return premarketTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return amTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return middayTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return pmTradesToday;
            }

            return 0;
        }

        private bool IsSessionTradeLimitReached(
            string sessionWindow)
        {
            if (
                string.IsNullOrWhiteSpace(
                    sessionWindow
                ) ||
                sessionWindow == "OUTSIDE"
            )
            {
                return false;
            }

            int sessionLimit =
                GetSessionTradeLimit(
                    sessionWindow
                );

            return
                GetSessionTradeCount(
                    sessionWindow
                ) >=
                sessionLimit;
        }

        private int GetSessionTradeLimit(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return PremarketMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return MiddayMaxTrades;
            }

            return activeMaxTrades;
        }

        private string GetSessionTradeStatus(
            DateTime nyTime)
        {
            string session =
                GetBotSessionWindow(
                    nyTime
                );

            if (session == "PREMARKET")
            {
                return
                    "PREMARKET "
                    + premarketTradesToday
                    + "/"
                    + PremarketMaxTrades;
            }

            if (session == "AM")
            {
                return
                    "AM "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            if (session == "MIDDAY")
            {
                return
                    "MIDDAY "
                    + middayTradesToday
                    + "/"
                    + MiddayMaxTrades;
            }

            if (session == "PM")
            {
                return
                    "PM "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            return
                "PRE "
                + premarketTradesToday
                + "/"
                + PremarketMaxTrades
                + " | AM "
                + amTradesToday
                + "/"
                + activeMaxTrades
                + " | MIDDAY "
                + middayTradesToday
                + "/"
                + MiddayMaxTrades
                + " | PM "
                + pmTradesToday
                + "/"
                + activeMaxTrades;
        }

        // =====================================================
        // CONVERT BAR TIME FROM NINJATRADER APPLICATION
        // TIME ZONE TO NEW YORK TIME.
        // =====================================================
        // =====================================================
        // V1.6.2 - RELIABLE CURRENT NEW YORK CLOCK
        // =====================================================
        // Bar timestamps may use NinjaTrader's configured display timezone.
        // The actual current clock must use UTC -> New York directly.
        private DateTime GetCurrentNewYorkTime()
        {
            try
            {
                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                return TimeZoneInfo.ConvertTimeFromUtc(
                    DateTime.UtcNow,
                    newYorkTimeZone
                );
            }
            catch
            {
                return DateTime.Now;
            }
        }

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                // If conversion ever fails, keep the original
                // timestamp instead of crashing the bot.
                return time;
            }
        }

        // =====================================================
        // DATETIME -> HHMMSS INTEGER
        // =====================================================
        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }

        // =====================================================
        // RANGE MOMENTUM TRIGGER ENGINE
        // =====================================================
        private void UpdateMomentumFromRangeBars(
            Bars bars,
            bool evaluateClosedRangeBar)
        {
            if (
                bars == null ||
                bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            int longScore;
            int shortScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaSlope;
            bool highBreakout;
            bool lowBreakout;

            CalculateMomentumScores(
                bars,
                closedBarIndex,
                emaFastCurrent,
                out longScore,
                out shortScore,
                out rangeRatio,
                out volumeRatio,
                out bodyRatio,
                out emaSlope,
                out highBreakout,
                out lowBreakout
            );

            bool bullishMomentum =
                longScore >= MomentumMinScore;

            bool bearishMomentum =
                shortScore >= MomentumMinScore;

            string momentumState =
                bullishMomentum &&
                !bearishMomentum
                    ? "BULLISH "
                        + longScore
                        + "/5"
                    : bearishMomentum &&
                        !bullishMomentum
                        ? "BEARISH "
                            + shortScore
                            + "/5"
                        : "L "
                            + longScore
                            + "/5 | S "
                            + shortScore
                            + "/5";

            lock (marketContextLock)
            {
                latestRangeLongScore =
                    longScore;
                latestRangeShortScore =
                    shortScore;
                latestRangeRatio =
                    rangeRatio;
                latestRangeVolumeRatio =
                    volumeRatio;
                latestRangeBodyRatio =
                    bodyRatio;
                latestRangeEmaSlope =
                    emaSlope;
                latestRangeHighBreakout =
                    highBreakout;
                latestRangeLowBreakout =
                    lowBreakout;
                latestRangeMomentumState =
                    momentumState;
            }

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (
                        !botRunning ||
                        momentumText == null
                    )
                    {
                        return;
                    }

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        bullishMomentum
                            ? Brushes.LimeGreen
                            : bearishMomentum
                                ? Brushes.OrangeRed
                                : Brushes.Goldenrod;
                })
            );

            if (!evaluateClosedRangeBar)
                return;

            DateTime closedRangeTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime rangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            EnsureTradingDay(
                rangeNyTime
            );

            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool m5AboveVwap;
            bool m5BelowVwap;
            string m5Structure;
            string m5Liquidity;
            int htfLongScore;
            int htfShortScore;
            double m5BullishBreakLevel;
            double m5BearishBreakLevel;

            lock (marketContextLock)
            {
                m5Ready =
                    latestM5ContextReady;
                m5Bullish =
                    latestM5BullishTrend;
                m5Bearish =
                    latestM5BearishTrend;
                m5AboveVwap =
                    latestM5AboveVwap;
                m5BelowVwap =
                    latestM5BelowVwap;
                m5Structure =
                    latestM5StructureState;

                m5Liquidity =
                    latestM5LiquidityState;

                htfLongScore =
                    latestHtfLongScore;

                htfShortScore =
                    latestHtfShortScore;
                m5BullishBreakLevel =
                    latestM5BullishStructureBreakLevel;
                m5BearishBreakLevel =
                    latestM5BearishStructureBreakLevel;
            }

            if (!m5Ready)
                return;

            bool nySessionActive =
                IsBotNySessionActive(
                    rangeNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    rangeNyTime
                );

            bool allowMomentumMode =
                activeStrategyMode == "MOMENTUM SCALP" ||
                activeStrategyMode == "HYBRID";

            bool openingPriority =
                IsOpeningPriorityActive(
                    rangeNyTime
                );

            bool openingBuildLock =
                IsOpeningBuildWindow(
                    rangeNyTime
                );

            // V1.6.2:
            // 09:30-09:35: Momentum is blocked while the opening range forms.
            // 09:35-10:00: Momentum is fallback only. If price is currently
            // presenting a valid Opening breakout, Opening gets first priority.
            double rangeClose =
                bars.GetClose(
                    closedBarIndex
                );

            double openingBuffer =
                selectedInstrument != null
                    ? selectedInstrument
                        .MasterInstrument
                        .TickSize
                        * OpeningBreakoutBufferTicks
                    : 0;

            bool openingLongCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bullish &&
                m5AboveVwap &&
                rangeClose >=
                    openingRangeHigh +
                    openingBuffer;

            bool openingShortCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bearish &&
                m5BelowVwap &&
                rangeClose <=
                    openingRangeLow -
                    openingBuffer;

            // =====================================================
            // V1.6.5 - EARLY EXTREME MOMENTUM DETECTION
            // =====================================================
            double momentumTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double slopeTicks =
                momentumTickSize > 0
                    ? emaSlope /
                        momentumTickSize
                    : 0;

            // V1.6.18 - advance previously-recorded shadow candidates using
            // only completed Range bars. This has no execution side effects.
            UpdateShadowSignalOutcomes(
                rangeNyTime,
                rangeClose,
                bars.GetHigh(closedBarIndex),
                bars.GetLow(closedBarIndex),
                momentumTickSize
            );

            bool extremeLongMomentum =
                longScore >=
                    ExtremeMomentumMinScore &&
                highBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    ExtremeMomentumMinSlopeTicks &&
                m5AboveVwap;

            bool extremeShortMomentum =
                shortScore >=
                    ExtremeMomentumMinScore &&
                lowBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -ExtremeMomentumMinSlopeTicks &&
                m5BelowVwap;

            // Premarket has no RTH VWAP yet, so its fast path uses the
            // completed premarket frontier + M5 direction instead.
            bool premarketRangeValid =
                premarketSession &&
                premarketRangeReady &&
                premarketRangeDateNy ==
                    rangeNyTime.Date;

            bool premarketHighBreakout =
                premarketRangeValid &&
                rangeClose >
                    premarketRangeHigh;

            bool premarketLowBreakout =
                premarketRangeValid &&
                rangeClose <
                    premarketRangeLow;

            bool premarketExtremeLong =
                premarketHighBreakout &&
                longScore >=
                    PremarketExtremeMinScore &&
                highBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    PremarketExtremeMinSlopeTicks &&
                (
                    m5Bullish ||
                    htfLongScore >= 1
                );

            bool premarketExtremeShort =
                premarketLowBreakout &&
                shortScore >=
                    PremarketExtremeMinScore &&
                lowBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -PremarketExtremeMinSlopeTicks &&
                (
                    m5Bearish ||
                    htfShortScore >= 1
                );

            bool premarketLongBias =
                premarketHighBreakout &&
                (
                    (
                        m5Bullish &&
                        longScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeLong
                );

            bool premarketShortBias =
                premarketLowBreakout &&
                (
                    (
                        m5Bearish &&
                        shortScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeShort
                );

            // =====================================================
            // V1.6.9 - FRESH AGGRESSIVE EXPANSION DETECTION
            // =====================================================
            int aggressiveLongScore;
            int aggressiveShortScore;
            int aggressiveLongDirectionalBars;
            int aggressiveShortDirectionalBars;
            double aggressiveLongDisplacementTicks;
            double aggressiveShortDisplacementTicks;

            CalculateAggressionState(
                bars,
                closedBarIndex,
                momentumTickSize,
                rangeRatio,
                volumeRatio,
                bodyRatio,
                slopeTicks,
                highBreakout,
                lowBreakout,
                out aggressiveLongScore,
                out aggressiveShortScore,
                out aggressiveLongDirectionalBars,
                out aggressiveShortDirectionalBars,
                out aggressiveLongDisplacementTicks,
                out aggressiveShortDisplacementTicks
            );

            bool aggressiveLongExpansion =
                aggressiveLongScore >= AggressionMinScore &&
                highBreakout &&
                aggressiveLongDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveLongDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketHighBreakout &&
                            (
                                m5Bullish ||
                                htfLongScore >= 1
                            )
                          )
                        : m5AboveVwap
                );

            bool aggressiveShortExpansion =
                aggressiveShortScore >= AggressionMinScore &&
                lowBreakout &&
                aggressiveShortDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveShortDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketLowBreakout &&
                            (
                                m5Bearish ||
                                htfShortScore >= 1
                            )
                          )
                        : m5BelowVwap
                );

            // Aggressive expansion is allowed to resolve AUTO before the
            // slower M5 trend flips, but only on the correct side of VWAP
            // during RTH (or after a true premarket-range breakout).
            if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                aggressiveLongExpansion !=
                    aggressiveShortExpansion
            )
            {
                autoResolvedDirection =
                    aggressiveLongExpansion
                        ? "LONG ONLY"
                        : "SHORT ONLY";

                autoDirectionReason =
                    aggressiveLongExpansion
                        ? "FRESH AGGRESSIVE EXPANSION LONG"
                        : "FRESH AGGRESSIVE EXPANSION SHORT";
            }

            // Do not let an already over-extended Opening candidate suppress
            // a fresh Range momentum signal.
            if (openingLongCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingLongCandidate =
                        false;
                }
            }

            if (openingShortCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingShortCandidate =
                        false;
                }
            }

            bool openingCandidatePresent =
                openingLongCandidate ||
                openingShortCandidate;

            bool extremeOpeningOverride =
                openingBuildLock &&
                (
                    extremeLongMomentum ||
                    extremeShortMomentum ||
                    aggressiveLongExpansion ||
                    aggressiveShortExpansion
                );

            if (
                !nySessionActive ||
                !allowMomentumMode ||
                (
                    openingBuildLock &&
                    !extremeOpeningOverride
                ) ||
                openingCandidatePresent
            )
            {
                return;
            }

            string effectiveRangeDirection;

            // Premarket AUTO is resolved from the premarket frontier because
            // the regular-session VWAP intentionally does not exist yet.
            if (
                premarketSession &&
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                bool premarketAutoLong =
                    premarketLongBias ||
                    aggressiveLongExpansion;

                bool premarketAutoShort =
                    premarketShortBias ||
                    aggressiveShortExpansion;

                if (
                    premarketAutoLong !=
                        premarketAutoShort
                )
                {
                    effectiveRangeDirection =
                        premarketAutoLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        aggressiveLongExpansion ||
                        aggressiveShortExpansion
                            ? (
                                premarketAutoLong
                                    ? "PREMARKET FRESH AGGRESSIVE EXPANSION LONG"
                                    : "PREMARKET FRESH AGGRESSIVE EXPANSION SHORT"
                              )
                            : (
                                premarketAutoLong
                                    ? "PREMARKET HIGH BREAKOUT + MOMENTUM"
                                    : "PREMARKET LOW BREAKOUT + MOMENTUM"
                              );
                }
                else
                {
                    effectiveRangeDirection =
                        "NONE";

                    autoResolvedDirection =
                        "NONE";

                    autoDirectionReason =
                        "PREMARKET WAITING FOR RANGE BREAKOUT";
                }
            }
            // RTH AUTO normally follows M5 + VWAP context. For an extreme
            // Range impulse, let the fast engine resolve direction early.
            else if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                (
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion ||
                    extremeLongMomentum !=
                        extremeShortMomentum
                )
            )
            {
                bool resolveLong =
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion
                        ? aggressiveLongExpansion
                        : extremeLongMomentum;

                effectiveRangeDirection =
                    resolveLong
                        ? "LONG ONLY"
                        : "SHORT ONLY";

                autoResolvedDirection =
                    effectiveRangeDirection;

                autoDirectionReason =
                    aggressiveLongExpansion ||
                    aggressiveShortExpansion
                        ? (
                            resolveLong
                                ? "FRESH AGGRESSIVE EXPANSION LONG"
                                : "FRESH AGGRESSIVE EXPANSION SHORT"
                          )
                        : (
                            resolveLong
                                ? "EXTREME R20 LONG + BREAKOUT + VWAP"
                                : "EXTREME R20 SHORT + BREAKOUT + VWAP"
                          );
            }
            else
            {
                effectiveRangeDirection =
                    ResolveEffectiveDirection(
                        rangeNyTime,
                        rangeClose,
                        m5Bullish,
                        m5Bearish,
                        m5AboveVwap,
                        m5BelowVwap
                    );
            }

            bool allowLong =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "LONG ONLY";

            bool allowShort =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "SHORT ONLY";

            string momentumSession =
                GetBotSessionWindow(
                    rangeNyTime
                );

            bool strictMiddayMomentum =
                string.Equals(
                    momentumSession,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            bool rawLongReady =
                premarketSession
                    ? (
                        allowLong &&
                        (
                            premarketLongBias ||
                            aggressiveLongExpansion
                        )
                      )
                    : (
                        allowLong &&
                        m5AboveVwap &&
                        (
                            (
                                m5Bullish &&
                                bullishMomentum
                            ) ||
                            extremeLongMomentum ||
                            aggressiveLongExpansion
                        )
                      );

            bool rawShortReady =
                premarketSession
                    ? (
                        allowShort &&
                        (
                            premarketShortBias ||
                            aggressiveShortExpansion
                        )
                      )
                    : (
                        allowShort &&
                        m5BelowVwap &&
                        (
                            (
                                m5Bearish &&
                                bearishMomentum
                            ) ||
                            extremeShortMomentum ||
                            aggressiveShortExpansion
                        )
                      );

            if (strictMiddayMomentum)
            {
                rawLongReady =
                    rawLongReady &&
                    (
                        (
                            longScore >=
                                MiddayMomentumMinScore &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveLongExpansion &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );

                rawShortReady =
                    rawShortReady &&
                    (
                        (
                            shortScore >=
                                MiddayMomentumMinScore &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveShortExpansion &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );
            }

            if (premarketSession)
            {
                if (!premarketRangeValid)
                {
                    return;
                }

                if (rawLongReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            true,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawLongReady =
                            false;
                    }
                }

                if (rawShortReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            false,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawShortReady =
                            false;
                    }
                }
            }

            // =====================================================
            // V1.6.9 - POST-MOVE EXHAUSTION GUARD
            // =====================================================
            // A mature directional move may keep producing ordinary Momentum
            // scores even after the best expansion is gone. If price is already
            // far from the session opposite extreme and current flow is weak,
            // do not keep chasing that same direction. A genuinely NEW
            // aggressive expansion is allowed through.
            double sessionUpMoveTicks;
            double sessionDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                out sessionUpMoveTicks,
                out sessionDownMoveTicks
            );

            bool weakCurrentExpansion =
                volumeRatio <=
                    ExhaustionMaxWeakVolumeRatio ||
                bodyRatio <=
                    ExhaustionMaxWeakBodyRatio;

            if (
                rawLongReady &&
                !aggressiveLongExpansion &&
                sessionUpMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    true,
                    rangeNyTime,
                    sessionUpMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    longScore
                );

                rawLongReady =
                    false;
            }

            if (
                rawShortReady &&
                !aggressiveShortExpansion &&
                sessionDownMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    false,
                    rangeNyTime,
                    sessionDownMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    shortScore
                );

                rawShortReady =
                    false;
            }

            // =====================================================
            // V1.6.11 - SMART RETEST / NO-CHASE ENTRY ENGINE
            // =====================================================
            // Extended ordinary signals arm a short-lived pending setup instead
            // of being forgotten. Aggressive Expansion still enters immediately.
            if (rawLongReady && !aggressiveLongExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = longScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "EXTENDED LONG SIGNAL"
                    );
                    LogPullbackWait(true, rangeNyTime, extensionTicks, maxExtensionTicks, longScore);
                    rawLongReady = false;
                }
            }

            if (rawShortReady && !aggressiveShortExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = shortScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "EXTENDED SHORT SIGNAL"
                    );
                    LogPullbackWait(false, rangeNyTime, extensionTicks, maxExtensionTicks, shortScore);
                    rawShortReady = false;
                }
            }

            // A pending setup may now be confirmed even though the original
            // breakout bar is gone. This is the actual pullback-entry layer.
            bool smartRetestLong = false;
            bool smartRetestShort = false;
            string smartRetestPattern = string.Empty;
            string smartRetestStructureSetupKey = string.Empty;

            TryConfirmSmartRetest(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                rangeClose,
                longScore,
                shortScore,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                out smartRetestLong,
                out smartRetestShort,
                out smartRetestPattern,
                out smartRetestStructureSetupKey
            );

            if (smartRetestLong)
            {
                rawLongReady = true;
                rawShortReady = false;
                PrintSmartRetestConfirmed(true, rangeNyTime, smartRetestPattern, rangeClose, longScore);
            }
            else if (smartRetestShort)
            {
                rawShortReady = true;
                rawLongReady = false;
                PrintSmartRetestConfirmed(false, rangeNyTime, smartRetestPattern, rangeClose, shortScore);
            }

            // =====================================================
            // V1.6.18 - SHADOW SIGNAL DATASET
            // =====================================================
            // Capture meaningful candidates even when a later guard rejects
            // the trade. This is intentionally observational only.
            bool shadowLongCandidate =
                longScore >= MomentumMinScore ||
                extremeLongMomentum ||
                aggressiveLongExpansion ||
                highBreakout ||
                smartRetestLong;

            bool shadowShortCandidate =
                shortScore >= MomentumMinScore ||
                extremeShortMomentum ||
                aggressiveShortExpansion ||
                lowBreakout ||
                smartRetestShort;

            string shadowLongId = string.Empty;
            string shadowShortId = string.Empty;

            if (shadowLongCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    true,
                    longScore,
                    aggressiveLongExpansion,
                    extremeLongMomentum,
                    smartRetestLong,
                    highBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfLongScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        true,
                        rawLongReady,
                        allowLong,
                        premarketSession,
                        m5AboveVwap,
                        m5Bullish,
                        strictMiddayMomentum,
                        longScore,
                        htfLongScore,
                        aggressiveLongExpansion,
                        sessionUpMoveTicks,
                        weakCurrentExpansion
                    );

                shadowLongId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        true,
                        momentumSession,
                        rawLongReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        longScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        highBreakout,
                        aggressiveLongScore,
                        aggressiveLongExpansion,
                        extremeLongMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfLongScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            if (shadowShortCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    false,
                    shortScore,
                    aggressiveShortExpansion,
                    extremeShortMomentum,
                    smartRetestShort,
                    lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfShortScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        false,
                        rawShortReady,
                        allowShort,
                        premarketSession,
                        m5BelowVwap,
                        m5Bearish,
                        strictMiddayMomentum,
                        shortScore,
                        htfShortScore,
                        aggressiveShortExpansion,
                        sessionDownMoveTicks,
                        weakCurrentExpansion
                    );

                shadowShortId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        false,
                        momentumSession,
                        rawShortReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        shortScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        lowBreakout,
                        aggressiveShortScore,
                        aggressiveShortExpansion,
                        extremeShortMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfShortScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            // =====================================================
            // V1.6.15A - LIVE ANALYSIS CONFIDENCE
            // =====================================================
            // Keep an advisory percentage alive while the bot is still
            // analyzing. This does NOT authorize or block entries.
            if (
                !rawLongReady &&
                !rawShortReady
            )
            {
                bool analysisIsLong;

                if (
                    string.Equals(
                        autoResolvedDirection,
                        "LONG ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = true;
                }
                else if (
                    string.Equals(
                        autoResolvedDirection,
                        "SHORT ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = false;
                }
                else
                {
                    analysisIsLong =
                        longScore >= shortScore;
                }

                int analysisConfidence;
                string analysisQuality;
                string analysisTiming;
                string analysisManipulation;
                string analysisReason;

                EvaluateNasdaqSetupQuality(
                    analysisIsLong,
                    analysisIsLong
                        ? longScore
                        : shortScore,
                    analysisIsLong
                        ? aggressiveLongExpansion
                        : aggressiveShortExpansion,
                    analysisIsLong
                        ? extremeLongMomentum
                        : extremeShortMomentum,
                    false,
                    analysisIsLong
                        ? highBreakout
                        : lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    analysisIsLong
                        ? htfLongScore
                        : htfShortScore,
                    out analysisConfidence,
                    out analysisQuality,
                    out analysisTiming,
                    out analysisManipulation,
                    out analysisReason
                );

                latestSetupConfidence =
                    analysisConfidence;

                latestSetupQuality =
                    analysisConfidence >= 70
                        ? analysisQuality
                        : "ANALYZING";

                latestSetupTiming =
                    "ANALYZING";

                latestManipulationState =
                    analysisManipulation;

                return;
            }

            bool selectedAggressiveExpansion =
                rawLongReady
                    ? aggressiveLongExpansion
                    : aggressiveShortExpansion;

            if (selectedAggressiveExpansion)
            {
                string aggressionLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT");

                if (
                    aggressionLogKey !=
                        lastAggressionSignalLogKey
                )
                {
                    lastAggressionSignalLogKey =
                        aggressionLogKey;

                    PrintBotMessage(
                        "AGGRESSIVE EXPANSION DETECTED"
                        + " | Side: "
                        + (rawLongReady ? "LONG" : "SHORT")
                        + " | Aggression: "
                        + (
                            rawLongReady
                                ? aggressiveLongScore
                                : aggressiveShortScore
                          )
                        + "/5"
                        + " | R20: "
                        + (
                            rawLongReady
                                ? longScore
                                : shortScore
                          )
                        + "/5"
                        + " | Displacement: "
                        + (
                            rawLongReady
                                ? aggressiveLongDisplacementTicks
                                : aggressiveShortDisplacementTicks
                          ).ToString("0")
                        + "t"
                        + " | Range x"
                        + rangeRatio.ToString("0.00")
                        + " | Volume x"
                        + volumeRatio.ToString("0.00")
                        + " | Body "
                        + (bodyRatio * 100.0).ToString("0")
                        + "%"
                        + " | EMA Slope "
                        + slopeTicks.ToString("0.0")
                        + "t"
                    );
                }
            }

            bool highConvictionMomentum =
                selectedAggressiveExpansion ||
                (
                rawLongReady
                    ? (
                        (
                            premarketSession &&
                            premarketExtremeLong
                        ) ||
                        extremeLongMomentum ||
                        (
                            longScore >= 4 &&
                            highBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                    : (
                        (
                            premarketSession &&
                            premarketExtremeShort
                        ) ||
                        extremeShortMomentum ||
                        (
                            shortScore >= 4 &&
                            lowBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                );

            bool effectiveExtremeMomentum =
                premarketSession
                    ? (
                        rawLongReady
                            ? premarketExtremeLong
                            : premarketExtremeShort
                      )
                    : (
                        rawLongReady
                            ? extremeLongMomentum
                            : extremeShortMomentum
                      );

            // =====================================================
            // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE
            // =====================================================
            int setupConfidence;
            string setupQuality;
            string setupTiming;
            string manipulationState;
            string setupQualityReason;

            EvaluateNasdaqSetupQuality(
                rawLongReady,
                rawLongReady ? longScore : shortScore,
                selectedAggressiveExpansion,
                effectiveExtremeMomentum,
                !string.IsNullOrWhiteSpace(smartRetestPattern),
                rawLongReady ? highBreakout : lowBreakout,
                bodyRatio,
                volumeRatio,
                slopeTicks,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                m5Structure,
                m5Liquidity,
                rawLongReady ? htfLongScore : htfShortScore,
                out setupConfidence,
                out setupQuality,
                out setupTiming,
                out manipulationState,
                out setupQualityReason
            );

            latestSetupConfidence =
                setupConfidence;
            latestSetupQuality =
                setupQuality;
            latestSetupTiming =
                setupTiming;
            latestManipulationState =
                manipulationState;

            string setupQualityLogKey =
                closedRangeTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + setupConfidence
                + "|"
                + setupQuality
                + "|"
                + setupTiming
                + "|"
                + manipulationState;

            if (
                setupQualityLogKey !=
                    lastSetupQualityLogKey
            )
            {
                lastSetupQualityLogKey =
                    setupQualityLogKey;

                PrintBotMessage(
                    "SETUP QUALITY"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | "
                    + setupQuality
                    + " | Confidence: "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                    + " | "
                    + setupQualityReason
                );
            }

            currentSetupState =
                setupQuality
                + " "
                + setupConfidence
                + "% | "
                + setupTiming;

            string learningContext =
                (
                    !string.IsNullOrWhiteSpace(smartRetestPattern)
                        ? "SMART RETEST " + smartRetestPattern + " "
                        : selectedAggressiveExpansion
                        ? (
                            premarketSession
                                ? "PREMARKET AGGRESSIVE EXPANSION "
                                : "R20 AGGRESSIVE EXPANSION "
                          )
                        : (
                            premarketSession
                                ? (
                                    effectiveExtremeMomentum
                                        ? "PREMARKET R20 EXTREME MOMENTUM "
                                        : "PREMARKET R20 MOMENTUM "
                                  )
                                : (
                                    effectiveExtremeMomentum
                                        ? "R20 EXTREME MOMENTUM "
                                        : "R20 MOMENTUM "
                                  )
                          )
                )
                + (
                    rawLongReady
                        ? longScore
                        : shortScore
                )
                + "/5";

            string learningReason;

            bool learningAllowed =
                IsLearningTradeAllowed(
                    rawLongReady
                        ? "LONG"
                        : "SHORT",
                    rangeNyTime,
                    learningContext,
                    out learningReason
                );

            DateTime closedRangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            string rangeSignalLogKey =
                closedRangeTime.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + (rawLongReady ? longScore : shortScore);

            if (rangeSignalLogKey != lastRangeSignalLogKey)
            {
                lastRangeSignalLogKey = rangeSignalLogKey;

                PrintBotMessage(
                    "RANGE MOMENTUM SIGNAL"
                    + (
                        premarketSession
                            ? " | PREMARKET"
                            : (
                                openingPriority
                                    ? " | OPENING FALLBACK"
                                    : string.Empty
                              )
                      )
                    + " | Bar: "
                    + closedRangeNyTime.ToString("HH:mm:ss")
                    + " ET"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20 Score: "
                    + (rawLongReady ? longScore : shortScore)
                    + "/5"
                    + " | M5 Trend: "
                    + (
                        m5Bullish
                            ? "BULLISH"
                            : m5Bearish
                                ? "BEARISH"
                                : "NEUTRAL"
                    )
                    + " | M5 VWAP: "
                    + (
                        m5AboveVwap
                            ? "ABOVE"
                            : m5BelowVwap
                                ? "BELOW"
                                : "AT"
                    )
                    + " | M5 Structure: "
                    + m5Structure
                    + " | Quality: "
                    + setupQuality
                    + " "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                );
            }

            if (!learningAllowed)
            {
                UpdateShadowSignalDecision(
                    rawLongReady
                        ? shadowLongId
                        : shadowShortId,
                    "LEARNING_BLOCKED",
                    learningReason
                );

                string learningBlockedLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT")
                    + "|"
                    + learningContext
                    + "|"
                    + learningReason;

                if (
                    learningBlockedLogKey !=
                        lastLearningBlockedLogKey
                )
                {
                    lastLearningBlockedLogKey =
                        learningBlockedLogKey;

                    PrintBotMessage(
                        "LEARNING BLOCK RANGE"
                        + " | Bar: "
                        + closedRangeNyTime.ToString(
                            "HH:mm:ss"
                        )
                        + " ET"
                        + " | "
                        + learningReason
                    );
                }

                return;
            }

            lastLearningBlockedLogKey =
                string.Empty;

            CaptureLearningSignalContext(
                rawLongReady
                    ? "LONG"
                    : "SHORT",
                rangeNyTime,
                learningContext
            );

            pendingShadowSignalId =
                rawLongReady
                    ? shadowLongId
                    : shadowShortId;

            UpdateShadowSignalDecision(
                pendingShadowSignalId,
                "ENTRY_ATTEMPT",
                "PASSED SIGNAL + LEARNING GATES"
            );

            TrySubmitEntry(
                rawLongReady,
                closedRangeTime,
                false,
                string.IsNullOrWhiteSpace(smartRetestStructureSetupKey)
                    ? null
                    : smartRetestStructureSetupKey,
                false,
                highConvictionMomentum
            );
        }

        // =====================================================
        // V1.6.18 - SHADOW SIGNAL RECORDER HELPERS
        // =====================================================
        private string BuildShadowDecisionReason(
            bool isLong,
            bool ready,
            bool directionAllowed,
            bool premarketSession,
            bool vwapAligned,
            bool m5TrendAligned,
            bool strictMiddayMomentum,
            int momentumScore,
            int htfAlignmentScore,
            bool aggressiveExpansion,
            double sessionExtensionTicks,
            bool weakCurrentExpansion)
        {
            if (ready)
                return "PASSED CURRENT SIGNAL GATES";

            if (!directionAllowed)
                return "DIRECTION FILTER";

            if (!premarketSession && !vwapAligned)
                return "VWAP FILTER";

            if (
                strictMiddayMomentum &&
                !(
                    (
                        momentumScore >= MiddayMomentumMinScore &&
                        htfAlignmentScore >= MiddayMinHtfAlignmentScore
                    ) ||
                    (
                        aggressiveExpansion &&
                        htfAlignmentScore >= MiddayMinHtfAlignmentScore
                    )
                )
            )
            {
                return "MIDDAY FILTER";
            }

            if (
                !aggressiveExpansion &&
                sessionExtensionTicks >= ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                return "POST-MOVE EXHAUSTION";
            }

            if (!premarketSession && !m5TrendAligned)
                return "M5 TREND / MOMENTUM FILTER";

            return "SIGNAL FILTER";
        }

        private string RegisterShadowSignalCandidate(
            DateTime signalBarTime,
            DateTime signalTimeNy,
            bool isLong,
            string sessionWindow,
            string decision,
            string decisionReason,
            double signalPrice,
            int momentumScore,
            double rangeRatio,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            bool directionalBreakout,
            int aggressionScore,
            bool aggressiveExpansion,
            bool extremeMomentum,
            string m5Trend,
            string m5Vwap,
            string m5Structure,
            string m5Liquidity,
            int htfAlignmentScore,
            int technicalQuality,
            string setupQuality,
            string setupTiming,
            string manipulationState)
        {
            if (!ShadowSignalRecorderEnabled)
                return string.Empty;

            string side = isLong ? "LONG" : "SHORT";
            string id =
                signalBarTime.ToString("yyyyMMddHHmmss")
                + "|"
                + side;

            JJBotShadowSignal item = null;

            lock (shadowSignalLock)
            {
                if (shadowSignalIds.Contains(id))
                    return id;

                shadowSignalIds.Add(id);

                item = new JJBotShadowSignal
                {
                    Id = id,
                    SignalTimeNy = signalTimeNy,
                    Side = side,
                    SessionWindow = sessionWindow ?? string.Empty,
                    Decision = decision ?? string.Empty,
                    DecisionReason = decisionReason ?? string.Empty,
                    SignalPrice = signalPrice,
                    MomentumScore = momentumScore,
                    RangeRatio = rangeRatio,
                    VolumeRatio = volumeRatio,
                    BodyRatio = bodyRatio,
                    SlopeTicks = slopeTicks,
                    DirectionalBreakout = directionalBreakout,
                    AggressionScore = aggressionScore,
                    AggressiveExpansion = aggressiveExpansion,
                    ExtremeMomentum = extremeMomentum,
                    M5Trend = m5Trend ?? string.Empty,
                    M5Vwap = m5Vwap ?? string.Empty,
                    M5Structure = m5Structure ?? string.Empty,
                    M5Liquidity = m5Liquidity ?? string.Empty,
                    HtfAlignmentScore = htfAlignmentScore,
                    TechnicalQuality = technicalQuality,
                    SetupQuality = setupQuality ?? string.Empty,
                    SetupTiming = setupTiming ?? string.Empty,
                    ManipulationState = manipulationState ?? string.Empty,
                    MfeTicks = 0,
                    MaeTicks = 0
                };

                activeShadowSignals.Add(item);
            }

            AppendShadowSignalCsv(item, "CANDIDATE", 0, signalPrice, 0);
            return id;
        }

        private void UpdateShadowSignalDecision(
            string id,
            string decision,
            string reason)
        {
            if (
                !ShadowSignalRecorderEnabled ||
                string.IsNullOrWhiteSpace(id)
            )
            {
                return;
            }

            JJBotShadowSignal found = null;

            lock (shadowSignalLock)
            {
                for (int i = 0; i < activeShadowSignals.Count; i++)
                {
                    if (
                        string.Equals(
                            activeShadowSignals[i].Id,
                            id,
                            StringComparison.OrdinalIgnoreCase
                        )
                    )
                    {
                        found = activeShadowSignals[i];
                        found.Decision = decision ?? found.Decision;
                        found.DecisionReason = reason ?? found.DecisionReason;
                        break;
                    }
                }
            }

            if (found != null)
                AppendShadowSignalCsv(found, "DECISION", 0, found.SignalPrice, 0);
        }

        private void UpdateShadowSignalOutcomes(
            DateTime currentTimeNy,
            double currentClose,
            double currentHigh,
            double currentLow,
            double tickSize)
        {
            if (
                !ShadowSignalRecorderEnabled ||
                tickSize <= 0
            )
            {
                return;
            }

            List<Tuple<JJBotShadowSignal, int, double>> writes =
                new List<Tuple<JJBotShadowSignal, int, double>>();

            lock (shadowSignalLock)
            {
                for (int i = activeShadowSignals.Count - 1; i >= 0; i--)
                {
                    JJBotShadowSignal item = activeShadowSignals[i];
                    if (item == null)
                    {
                        activeShadowSignals.RemoveAt(i);
                        continue;
                    }

                    double favorableTicks;
                    double adverseTicks;

                    if (item.Side == "LONG")
                    {
                        favorableTicks =
                            (currentHigh - item.SignalPrice) / tickSize;
                        adverseTicks =
                            (currentLow - item.SignalPrice) / tickSize;
                    }
                    else
                    {
                        favorableTicks =
                            (item.SignalPrice - currentLow) / tickSize;
                        adverseTicks =
                            (item.SignalPrice - currentHigh) / tickSize;
                    }

                    item.MfeTicks =
                        Math.Max(item.MfeTicks, favorableTicks);
                    item.MaeTicks =
                        Math.Min(item.MaeTicks, adverseTicks);

                    int elapsedSeconds =
                        Math.Max(
                            0,
                            (int)Math.Floor(
                                (currentTimeNy - item.SignalTimeNy).TotalSeconds
                            )
                        );

                    for (int h = 0; h < ShadowSignalHorizonsSeconds.Length; h++)
                    {
                        int horizon = ShadowSignalHorizonsSeconds[h];
                        if (
                            elapsedSeconds >= horizon &&
                            !item.WrittenHorizons.Contains(horizon)
                        )
                        {
                            item.WrittenHorizons.Add(horizon);

                            double moveTicks =
                                item.Side == "LONG"
                                    ? (currentClose - item.SignalPrice) / tickSize
                                    : (item.SignalPrice - currentClose) / tickSize;

                            writes.Add(
                                Tuple.Create(item, horizon, moveTicks)
                            );
                        }
                    }

                    if (
                        item.WrittenHorizons.Contains(300) ||
                        elapsedSeconds > 900
                    )
                    {
                        activeShadowSignals.RemoveAt(i);
                    }
                }
            }

            for (int i = 0; i < writes.Count; i++)
            {
                AppendShadowSignalCsv(
                    writes[i].Item1,
                    "OUTCOME",
                    writes[i].Item2,
                    currentClose,
                    writes[i].Item3
                );
            }
        }

        private string GetShadowSignalFolderPath()
        {
            string root = stateFolderPath;

            if (string.IsNullOrWhiteSpace(root))
            {
                root = Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments
                    ),
                    "NinjaTrader 8",
                    "JJBotData"
                );
            }

            return Path.Combine(root, "ShadowSignals");
        }

        private void AppendShadowSignalCsv(
            JJBotShadowSignal item,
            string eventType,
            int horizonSeconds,
            double observedPrice,
            double moveTicks)
        {
            if (item == null)
                return;

            try
            {
                string folder = GetShadowSignalFolderPath();
                Directory.CreateDirectory(folder);

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : "UNKNOWN";

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : "UNKNOWN";

                string safeAccount =
                    Regex.Replace(accountName, "[^A-Za-z0-9_.-]", "_");
                string safeInstrument =
                    Regex.Replace(instrumentName, "[^A-Za-z0-9_.-]", "_");

                string filePath =
                    Path.Combine(
                        folder,
                        "shadow_"
                        + safeAccount
                        + "_"
                        + safeInstrument
                        + "_"
                        + item.SignalTimeNy.ToString("yyyyMMdd")
                        + ".csv"
                    );

                bool writeHeader = !File.Exists(filePath);

                StringBuilder line = new StringBuilder();
                line.Append(CsvShadow(item.Id)).Append(',');
                line.Append(CsvShadow(eventType)).Append(',');
                line.Append(CsvShadow(item.SignalTimeNy.ToString("o"))).Append(',');
                line.Append(CsvShadow(accountName)).Append(',');
                line.Append(CsvShadow(instrumentName)).Append(',');
                line.Append(CsvShadow(item.Side)).Append(',');
                line.Append(CsvShadow(item.SessionWindow)).Append(',');
                line.Append(CsvShadow(item.Decision)).Append(',');
                line.Append(CsvShadow(item.DecisionReason)).Append(',');
                line.Append(item.SignalPrice.ToString("0.########", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MomentumScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.RangeRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.VolumeRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.BodyRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.SlopeTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.DirectionalBreakout ? "1" : "0").Append(',');
                line.Append(item.AggressionScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.AggressiveExpansion ? "1" : "0").Append(',');
                line.Append(item.ExtremeMomentum ? "1" : "0").Append(',');
                line.Append(CsvShadow(item.M5Trend)).Append(',');
                line.Append(CsvShadow(item.M5Vwap)).Append(',');
                line.Append(CsvShadow(item.M5Structure)).Append(',');
                line.Append(CsvShadow(item.M5Liquidity)).Append(',');
                line.Append(item.HtfAlignmentScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.TechnicalQuality.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(CsvShadow(item.SetupQuality)).Append(',');
                line.Append(CsvShadow(item.SetupTiming)).Append(',');
                line.Append(CsvShadow(item.ManipulationState)).Append(',');
                line.Append(horizonSeconds.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(observedPrice.ToString("0.########", CultureInfo.InvariantCulture)).Append(',');
                line.Append(moveTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MfeTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MaeTicks.ToString("0.####", CultureInfo.InvariantCulture));

                string header =
                    "CandidateId,EventType,SignalTimeNY,Account,Instrument,Side,Session,Decision,DecisionReason,SignalPrice,R20,RangeRatio,VolumeRatio,BodyRatio,EmaSlopeTicks,Breakout,AggressionScore,AggressiveExpansion,ExtremeMomentum,M5Trend,M5VWAP,M5Structure,M5Liquidity,HTFAlignment,TechnicalQuality,SetupQuality,SetupTiming,Manipulation,HorizonSeconds,ObservedPrice,MoveTicks,MfeTicks,MaeTicks";

                lock (shadowSignalLock)
                {
                    if (writeHeader)
                        File.AppendAllText(filePath, header + Environment.NewLine, Encoding.UTF8);

                    File.AppendAllText(
                        filePath,
                        line.ToString() + Environment.NewLine,
                        Encoding.UTF8
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SHADOW RECORDER ERROR | " + ex.Message
                );
            }
        }

        private string CsvShadow(string value)
        {
            string text = value ?? string.Empty;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }

        // =====================================================
        // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE ENGINE
        // =====================================================
        private void EvaluateNasdaqSetupQuality(
            bool isLong,
            int momentumScore,
            bool aggressiveExpansion,
            bool extremeMomentum,
            bool smartRetest,
            bool directionalBreakout,
            double bodyRatio,
            double volumeRatio,
            double slopeTicks,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            string m5Structure,
            string m5Liquidity,
            int htfAlignmentScore,
            out int confidence,
            out string quality,
            out string timing,
            out string manipulation,
            out string reason)
        {
            int score = 35;

            // R20 is the primary Nasdaq trigger.
            score +=
                Math.Max(
                    0,
                    Math.Min(5, momentumScore)
                ) * 7;

            bool trendAligned =
                isLong
                    ? m5Bullish
                    : m5Bearish;

            bool vwapAligned =
                isLong
                    ? m5AboveVwap
                    : m5BelowVwap;

            bool structureAligned =
                IsStructureAlignedForSetup(
                    isLong,
                    m5Structure
                );

            if (trendAligned)
                score += 8;

            if (vwapAligned)
                score += 7;

            if (structureAligned)
                score += 5;

            score +=
                Math.Max(
                    0,
                    Math.Min(2, htfAlignmentScore)
                ) * 4;

            if (directionalBreakout)
                score += 6;

            if (aggressiveExpansion)
                score += 8;
            else if (extremeMomentum)
                score += 5;

            if (smartRetest)
                score += 5;

            if (bodyRatio >= 0.70)
                score += 4;
            else if (bodyRatio < 0.55)
                score -= 5;

            if (volumeRatio >= 1.20)
                score += 4;
            else if (volumeRatio < 0.85)
                score -= 5;

            double directionalSlope =
                isLong
                    ? slopeTicks
                    : -slopeTicks;

            if (directionalSlope >= 5.0)
                score += 4;
            else if (directionalSlope < 1.0)
                score -= 4;

            manipulation =
                GetManipulationState(
                    isLong,
                    m5Liquidity,
                    m5Structure
                );

            if (
                manipulation ==
                    "CONFIRMED WITH SETUP"
            )
            {
                score += 5;
            }
            else if (
                manipulation ==
                    "OPPOSING RISK"
            )
            {
                score -= 10;
            }

            confidence =
                Math.Max(
                    45,
                    Math.Min(99, score)
                );

            if (confidence >= 88)
                quality = "OPTIMAL";
            else if (confidence >= 80)
                quality = "HIGH";
            else if (confidence >= 70)
                quality = "CONFIRMED";
            else
                quality = "STANDARD";

            if (smartRetest)
            {
                timing = "CONFIRMED RETEST";
            }
            else if (
                aggressiveExpansion ||
                extremeMomentum
            )
            {
                timing = "EARLY";
            }
            else if (
                directionalBreakout &&
                momentumScore >= 4
            )
            {
                timing = "CONFIRMED";
            }
            else
            {
                timing = "DEVELOPING";
            }

            reason =
                "R20 "
                + momentumScore
                + "/5"
                + " | M5 "
                + (trendAligned ? "ALIGNED" : "MIXED")
                + " | VWAP "
                + (vwapAligned ? "ALIGNED" : "MIXED")
                + " | HTF "
                + Math.Max(0, Math.Min(2, htfAlignmentScore))
                + "/2"
                + " | Breakout "
                + (directionalBreakout ? "YES" : "NO")
                + " | Aggression "
                + (aggressiveExpansion ? "YES" : "NO");
        }

        private bool IsStructureAlignedForSetup(
            bool isLong,
            string structureState)
        {
            string state =
                (structureState ?? string.Empty)
                    .ToUpperInvariant();

            if (isLong)
            {
                return
                    state.Contains("BULLISH");
            }

            return
                state.Contains("BEARISH");
        }

        private string GetManipulationState(
            bool isLong,
            string liquidityState,
            string structureState)
        {
            string liquidity =
                (liquidityState ?? string.Empty)
                    .ToUpperInvariant();

            string structure =
                (structureState ?? string.Empty)
                    .ToUpperInvariant();

            bool bullishStructure =
                structure.Contains("BULLISH");

            bool bearishStructure =
                structure.Contains("BEARISH");

            // Liquidity sweep + reversal structure in the same direction
            // is treated as manipulation confirmation, not a standalone trigger.
            if (
                isLong &&
                liquidity.Contains("LOW SWEPT") &&
                bullishStructure
            )
            {
                return "CONFIRMED WITH SETUP";
            }

            if (
                !isLong &&
                liquidity.Contains("HIGH SWEPT") &&
                bearishStructure
            )
            {
                return "CONFIRMED WITH SETUP";
            }

            // Opposite sweep/reversal combination is a warning only in V1.
            if (
                isLong &&
                liquidity.Contains("HIGH SWEPT") &&
                bearishStructure
            )
            {
                return "OPPOSING RISK";
            }

            if (
                !isLong &&
                liquidity.Contains("LOW SWEPT") &&
                bullishStructure
            )
            {
                return "OPPOSING RISK";
            }

            return "NONE";
        }

        // =====================================================
        // V1.6.11 - SMART RETEST HELPERS
        // =====================================================
        private void ArmSmartRetest(
            bool isLong,
            DateTime nyTime,
            double breakoutLevel,
            double structureLevel,
            double impulseExtreme,
            int score,
            string reason,
            string structureSetupKey = null)
        {
            pendingSmartRetestActive = true;
            pendingSmartRetestIsLong = isLong;
            pendingSmartRetestCreatedNy = nyTime;
            pendingSmartRetestExpiresNy = nyTime.AddSeconds(SmartRetestWindowSeconds);
            pendingSmartRetestBreakoutLevel = breakoutLevel;
            pendingSmartRetestStructureLevel = structureLevel;
            pendingSmartRetestImpulseExtreme = impulseExtreme;
            pendingSmartRetestOriginalScore = score;
            pendingSmartRetestReason = reason ?? string.Empty;
            pendingSmartRetestStructureSetupKey = structureSetupKey ?? string.Empty;

            string key = (isLong ? "LONG" : "SHORT") + "|" + nyTime.ToString("yyyyMMddHHmmss");
            if (key != lastSmartRetestLogKey)
            {
                lastSmartRetestLogKey = key;
                PrintBotMessage(
                    "SMART RETEST ARMED"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | R20: " + score + "/5"
                    + " | Breakout: " + breakoutLevel.ToString("0.00")
                    + " | M5 Structure: " + (structureLevel > 0 ? structureLevel.ToString("0.00") : "N/A")
                    + " | Window: " + SmartRetestWindowSeconds + "s"
                );
            }
        }

        private void TryConfirmSmartRetest(
            Bars bars,
            int closedBarIndex,
            DateTime nyTime,
            double tickSize,
            double close,
            int longScore,
            int shortScore,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            out bool confirmLong,
            out bool confirmShort,
            out string pattern,
            out string structureSetupKey)
        {
            confirmLong = false;
            confirmShort = false;
            pattern = string.Empty;
            structureSetupKey = string.Empty;

            if (!pendingSmartRetestActive || bars == null || tickSize <= 0)
                return;

            if (nyTime > pendingSmartRetestExpiresNy || nyTime.Date != pendingSmartRetestCreatedNy.Date)
            {
                PrintBotMessage("SMART RETEST EXPIRED | Side: "
                    + (pendingSmartRetestIsLong ? "LONG" : "SHORT")
                    + " | No valid retest confirmation.");
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;
                return;
            }

            if (closedBarIndex < 2)
                return;

            bool isLong = pendingSmartRetestIsLong;
            double high = bars.GetHigh(closedBarIndex);
            double low = bars.GetLow(closedBarIndex);
            double open = bars.GetOpen(closedBarIndex);
            double priorOpen = bars.GetOpen(closedBarIndex - 1);
            double priorClose = bars.GetClose(closedBarIndex - 1);
            double priorHigh = bars.GetHigh(closedBarIndex - 1);
            double priorLow = bars.GetLow(closedBarIndex - 1);
            double levelTol = SmartRetestLevelToleranceTicks * tickSize;
            double structureTol = SmartRetestStructureToleranceTicks * tickSize;

            bool contextOk = isLong
                ? (m5Bullish && m5AboveVwap && longScore >= SmartRetestMinResumeScore)
                : (m5Bearish && m5BelowVwap && shortScore >= SmartRetestMinResumeScore);

            if (!contextOk)
                return;

            bool breakoutRetest = false;
            if (pendingSmartRetestBreakoutLevel > 0)
            {
                breakoutRetest = isLong
                    ? (low <= pendingSmartRetestBreakoutLevel + levelTol && close > pendingSmartRetestBreakoutLevel)
                    : (high >= pendingSmartRetestBreakoutLevel - levelTol && close < pendingSmartRetestBreakoutLevel);
            }

            bool structureRetest = false;
            if (pendingSmartRetestStructureLevel > 0)
            {
                structureRetest = isLong
                    ? (low <= pendingSmartRetestStructureLevel + structureTol && close > pendingSmartRetestStructureLevel)
                    : (high >= pendingSmartRetestStructureLevel - structureTol && close < pendingSmartRetestStructureLevel);
            }

            bool priorWasPullback = isLong ? priorClose < priorOpen : priorClose > priorOpen;
            bool resumed = isLong
                ? (close > open && close > priorHigh)
                : (close < open && close < priorLow);
            bool microPullbackContinuation = priorWasPullback && resumed;

            if (structureRetest)
                pattern = "STRUCTURE RETEST";
            else if (breakoutRetest)
                pattern = "BREAKOUT RETEST";
            else if (microPullbackContinuation)
                pattern = "MICRO PULLBACK";
            else
                return;

            structureSetupKey = pendingSmartRetestStructureSetupKey;
            confirmLong = isLong;
            confirmShort = !isLong;
            pendingSmartRetestActive = false;
            pendingSmartRetestStructureSetupKey = string.Empty;
        }

        private void PrintSmartRetestConfirmed(
            bool isLong,
            DateTime nyTime,
            string pattern,
            double price,
            int score)
        {
            string normalizedPattern =
                string.IsNullOrWhiteSpace(pattern)
                    ? "RETEST"
                    : pattern.Trim().ToUpperInvariant();

            string logKey =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + normalizedPattern
                + "|"
                + nyTime.ToString("yyyyMMddHHmmss")
                + "|"
                + price.ToString("0.00");

            // The evaluator can be called multiple times while the same
            // confirmed retest is still visible. Keep the trading state
            // untouched and suppress only duplicate telemetry.
            if (
                string.Equals(
                    lastSmartRetestConfirmedLogKey,
                    logKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastSmartRetestConfirmedLogKey =
                logKey;

            PrintBotMessage(
                "SMART RETEST CONFIRMED"
                + " | " + normalizedPattern
                + " | Side: " + (isLong ? "LONG" : "SHORT")
                + " | Price: " + price.ToString("0.00")
                + " | R20: " + score + "/5"
                + " | NY: " + nyTime.ToString("HH:mm:ss")
            );
        }

        // =====================================================
        // V1.6.9 - AGGRESSION / EXHAUSTION HELPERS
        // =====================================================
        private void CalculateAggressionState(
            Bars bars,
            int closedBarIndex,
            double tickSize,
            double rangeRatio,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            bool highBreakout,
            bool lowBreakout,
            out int longAggressionScore,
            out int shortAggressionScore,
            out int longDirectionalBars,
            out int shortDirectionalBars,
            out double longDisplacementTicks,
            out double shortDisplacementTicks)
        {
            longAggressionScore = 0;
            shortAggressionScore = 0;
            longDirectionalBars = 0;
            shortDirectionalBars = 0;
            longDisplacementTicks = 0;
            shortDisplacementTicks = 0;

            if (
                bars == null ||
                tickSize <= 0 ||
                closedBarIndex <
                    AggressionLookbackBars + 1
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            bool bullishBody =
                close > open &&
                bodyRatio >=
                    AggressionMinBodyRatio;

            bool bearishBody =
                close < open &&
                bodyRatio >=
                    AggressionMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    AggressionMinRangeRatio;

            bool volumeExpanded =
                volumeRatio >=
                    AggressionMinVolumeRatio;

            bool slopeUp =
                slopeTicks >=
                    AggressionMinSlopeTicks;

            bool slopeDown =
                slopeTicks <=
                    -AggressionMinSlopeTicks;

            if (bullishBody)
                longAggressionScore++;

            if (bearishBody)
                shortAggressionScore++;

            if (rangeExpanded)
            {
                longAggressionScore++;
                shortAggressionScore++;
            }

            if (volumeExpanded)
            {
                longAggressionScore++;
                shortAggressionScore++;
            }

            if (slopeUp)
                longAggressionScore++;

            if (slopeDown)
                shortAggressionScore++;

            if (highBreakout)
                longAggressionScore++;

            if (lowBreakout)
                shortAggressionScore++;

            int startIndex =
                Math.Max(
                    1,
                    closedBarIndex -
                        AggressionLookbackBars + 1
                );

            for (
                int i = startIndex;
                i <= closedBarIndex;
                i++
            )
            {
                double currentClose =
                    bars.GetClose(i);

                double previousClose =
                    bars.GetClose(i - 1);

                if (
                    currentClose >
                        previousClose
                )
                {
                    longDirectionalBars++;
                }
                else if (
                    currentClose <
                        previousClose
                )
                {
                    shortDirectionalBars++;
                }
            }

            int displacementStart =
                Math.Max(
                    0,
                    closedBarIndex -
                        AggressionLookbackBars
                );

            double displacement =
                close -
                bars.GetClose(
                    displacementStart
                );

            longDisplacementTicks =
                Math.Max(
                    0,
                    displacement /
                        tickSize
                );

            shortDisplacementTicks =
                Math.Max(
                    0,
                    -displacement /
                        tickSize
                );
        }

        private void CalculateSessionMoveExtensionTicks(
            Bars bars,
            int closedBarIndex,
            DateTime currentNyTime,
            double tickSize,
            out double upMoveTicks,
            out double downMoveTicks)
        {
            upMoveTicks = 0;
            downMoveTicks = 0;

            if (
                bars == null ||
                tickSize <= 0 ||
                closedBarIndex < 0
            )
            {
                return;
            }

            double sessionHigh =
                double.MinValue;

            double sessionLow =
                double.MaxValue;

            int firstIndex =
                Math.Max(
                    0,
                    closedBarIndex -
                        ExhaustionSessionScanMaxBars
                );

            for (
                int i = closedBarIndex;
                i >= firstIndex;
                i--
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date !=
                        currentNyTime.Date
                )
                {
                    break;
                }

                int timeInt =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeInt <
                        PremarketSessionStart
                )
                {
                    break;
                }

                sessionHigh =
                    Math.Max(
                        sessionHigh,
                        bars.GetHigh(i)
                    );

                sessionLow =
                    Math.Min(
                        sessionLow,
                        bars.GetLow(i)
                    );
            }

            if (
                sessionHigh ==
                    double.MinValue ||
                sessionLow ==
                    double.MaxValue
            )
            {
                return;
            }

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            upMoveTicks =
                Math.Max(
                    0,
                    (close - sessionLow) /
                        tickSize
                );

            downMoveTicks =
                Math.Max(
                    0,
                    (sessionHigh - close) /
                        tickSize
                );
        }

        private void LogPostMoveExhaustionBlock(
            bool isLong,
            DateTime nyTime,
            double moveTicks,
            double volumeRatio,
            double bodyRatio,
            int momentumScore)
        {
            string side =
                isLong
                    ? "LONG"
                    : "SHORT";

            string key =
                side
                + "|"
                + nyTime.ToString(
                    "yyyyMMddHHmm"
                )
                + "|"
                + Math.Floor(
                    moveTicks / 100.0
                  ).ToString(
                    CultureInfo.InvariantCulture
                  );

            if (
                string.Equals(
                    key,
                    lastExhaustionBlockLogKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastExhaustionBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - POST-MOVE EXHAUSTION"
                + " | Side: "
                + side
                + " | Move: "
                + moveTicks.ToString("0")
                + "t"
                + " | R20: "
                + momentumScore
                + "/5"
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | Body "
                + (bodyRatio * 100.0).ToString("0")
                + "%"
                + " | Reason: mature move without fresh aggression"
            );
        }

        private void LogStructureMatureMoveBlock(
            bool isLong,
            DateTime nyTime,
            double moveTicks,
            int momentumScore,
            double volumeRatio,
            bool breakout)
        {
            string side = isLong ? "LONG" : "SHORT";
            string key =
                side + "|" + nyTime.ToString("yyyyMMddHHmm") + "|"
                + Math.Floor(moveTicks / 100.0).ToString(CultureInfo.InvariantCulture);

            if (string.Equals(key, lastStructureExhaustionLogKey, StringComparison.Ordinal))
                return;

            lastStructureExhaustionLogKey = key;

            PrintBotMessage(
                "SKIP STRUCTURE - MATURE MOVE / NO FRESH EXPANSION"
                + " | Side: " + side
                + " | Move: " + moveTicks.ToString("0") + "t"
                + " | R20: " + momentumScore + "/5"
                + " | Volume x" + volumeRatio.ToString("0.00")
                + " | Breakout: " + (breakout ? "YES" : "NO")
            );
        }

        private void LogPullbackWait(
            bool isLong,
            DateTime nyTime,
            double extensionTicks,
            double maxExtensionTicks,
            int momentumScore)
        {
            string side = isLong ? "LONG" : "SHORT";
            string key =
                side + "|" + nyTime.ToString("yyyyMMddHHmmss") + "|" + momentumScore;

            if (string.Equals(key, lastPullbackWaitLogKey, StringComparison.Ordinal))
                return;

            lastPullbackWaitLogKey = key;

            PrintBotMessage(
                "WAIT PULLBACK - ENTRY EXTENDED"
                + " | Side: " + side
                + " | R20: " + momentumScore + "/5"
                + " | EMA9 Extension: " + extensionTicks.ToString("0") + "t"
                + " | Max: " + maxExtensionTicks.ToString("0") + "t"
                + " | Action: do not chase; wait later valid signal"
            );
        }

        // =====================================================
        // MOMENTUM ENGINE V2 - RANGE SERIES
        // =====================================================
        private void CalculateMomentumScores(
            Bars bars,
            int closedBarIndex,
            double emaFastCurrent,
            out int longScore,
            out int shortScore,
            out double rangeRatio,
            out double volumeRatio,
            out double bodyRatio,
            out double emaFastSlope,
            out bool highBreakout,
            out bool lowBreakout)
        {
            longScore = 0;
            shortScore = 0;
            rangeRatio = 0;
            volumeRatio = 0;
            bodyRatio = 0;
            emaFastSlope = 0;
            highBreakout = false;
            lowBreakout = false;

            if (
                bars == null ||
                closedBarIndex <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 2
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            double high =
                bars.GetHigh(
                    closedBarIndex
                );

            double low =
                bars.GetLow(
                    closedBarIndex
                );

            double currentRange =
                Math.Max(
                    0,
                    high - low
                );

            double currentBody =
                Math.Abs(
                    close - open
                );

            bodyRatio =
                currentRange > 0
                    ? currentBody /
                        currentRange
                    : 0;

            double averageRange = 0;
            double averageVolume = 0;

            for (
                int i = closedBarIndex -
                    MomentumAverageLookback;
                i < closedBarIndex;
                i++
            )
            {
                averageRange +=
                    Math.Max(
                        0,
                        bars.GetHigh(i) -
                        bars.GetLow(i)
                    );

                averageVolume +=
                    bars.GetVolume(i);
            }

            averageRange /=
                MomentumAverageLookback;

            averageVolume /=
                MomentumAverageLookback;

            rangeRatio =
                averageRange > 0
                    ? currentRange /
                        averageRange
                    : 0;

            double currentVolume =
                bars.GetVolume(
                    closedBarIndex
                );

            volumeRatio =
                averageVolume > 0
                    ? currentVolume /
                        averageVolume
                    : 0;

            double emaFastPrevious =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex - 1
                );

            emaFastSlope =
                emaFastCurrent -
                emaFastPrevious;

            double previousHighest =
                double.MinValue;

            double previousLowest =
                double.MaxValue;

            for (
                int i = closedBarIndex -
                    MomentumBreakoutLookback;
                i < closedBarIndex;
                i++
            )
            {
                previousHighest =
                    Math.Max(
                        previousHighest,
                        bars.GetHigh(i)
                    );

                previousLowest =
                    Math.Min(
                        previousLowest,
                        bars.GetLow(i)
                    );
            }

            highBreakout =
                close > previousHighest;

            lowBreakout =
                close < previousLowest;

            bool bullishCandle =
                close > open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool bearishCandle =
                close < open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    MomentumRangeExpansion;

            bool volumeExpanded =
                volumeRatio >=
                    MomentumVolumeExpansion;

            bool emaRising =
                emaFastSlope > 0;

            bool emaFalling =
                emaFastSlope < 0;

            // Five independent components:
            // 1) strong directional body
            // 2) EMA9 slope
            // 3) range expansion
            // 4) relative volume expansion
            // 5) close breakout of recent bars
            if (bullishCandle)
                longScore++;

            if (emaRising)
                longScore++;

            if (rangeExpanded)
                longScore++;

            if (volumeExpanded)
                longScore++;

            if (highBreakout)
                longScore++;

            if (bearishCandle)
                shortScore++;

            if (emaFalling)
                shortScore++;

            if (rangeExpanded)
                shortScore++;

            if (volumeExpanded)
                shortScore++;

            if (lowBreakout)
                shortScore++;
        }

        // =====================================================
        // EMA CALCULATION
        //
        // BarsRequest data cannot be passed directly into
        // NinjaTrader indicators, so EMA is calculated here.
        // =====================================================
        private double CalculateEma(
            Bars bars,
            int period,
            int endIndex)
        {
            if (
                bars == null ||
                period <= 0 ||
                endIndex < 0 ||
                bars.Count <= 0
            )
            {
                return 0;
            }

            int safeEndIndex =
                Math.Min(
                    endIndex,
                    bars.Count - 1
                );

            if (safeEndIndex < 0)
                return 0;

            DateTime firstBarTime;

            try
            {
                firstBarTime =
                    bars.GetTime(0);
            }
            catch
            {
                firstBarTime =
                    DateTime.MinValue;
            }

            double multiplier =
                2.0 / (period + 1.0);

            lock (emaCacheLock)
            {
                Dictionary<int, EmaCacheState> periodCaches;

                if (
                    !emaCaches.TryGetValue(
                        bars,
                        out periodCaches
                    ) ||
                    periodCaches == null
                )
                {
                    periodCaches =
                        new Dictionary<int, EmaCacheState>();

                    emaCaches[bars] =
                        periodCaches;
                }

                EmaCacheState cache;

                if (
                    !periodCaches.TryGetValue(
                        period,
                        out cache
                    ) ||
                    cache == null
                )
                {
                    cache =
                        new EmaCacheState();

                    periodCaches[period] =
                        cache;
                }

                // BarsRequest may roll its internal history window.
                // If bar zero changes, discard the old EMA seed and
                // rebuild once from the new window.
                if (
                    cache.FirstBarTime !=
                        firstBarTime ||
                    cache.Values.Count >
                        bars.Count
                )
                {
                    cache.FirstBarTime =
                        firstBarTime;

                    cache.Values.Clear();
                }

                while (
                    cache.Values.Count <=
                        safeEndIndex
                )
                {
                    int index =
                        cache.Values.Count;

                    double close =
                        bars.GetClose(
                            index
                        );

                    if (index == 0)
                    {
                        cache.Values.Add(
                            close
                        );
                    }
                    else
                    {
                        double previousEma =
                            cache.Values[
                                index - 1
                            ];

                        double ema =
                            (
                                close -
                                previousEma
                            )
                            * multiplier
                            + previousEma;

                        cache.Values.Add(
                            ema
                        );
                    }
                }

                return cache.Values[
                    safeEndIndex
                ];
            }
        }

        private void ClearEmaCaches()
        {
            lock (emaCacheLock)
            {
                emaCaches.Clear();
            }
        }

        // =====================================================
        // STOP BOT
        // =====================================================
        private void ReleaseRuntimeLease()
        {
            string leaseKey =
                activeRuntimeLeaseKey;

            activeRuntimeLeaseKey =
                string.Empty;

            JJBotRuntimeCoordinator.ReleaseBotLease(
                leaseKey
            );
        }

        private void StopBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            botRunning = false;

            StopPositionRecoveryRetry();

            ReleaseRuntimeLease();

            currentSignalState =
                "STOPPED";

            currentSetupState =
                "STOPPED";

            PublishSharedState();

            StopBarsEngine();

            statusText.Text =
                "● STOPPED";

            statusText.Foreground =
                Brushes.OrangeRed;

            signalText.Text =
                "STOPPED";

            signalText.Foreground =
                Brushes.White;

            startButton.IsEnabled =
                true;

            stopButton.IsEnabled =
                false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;

            PrintBotMessage(
                "BOT STOPPED - EXISTING OCO ORDERS/POSITION ARE NOT FLATTENED."
            );
        }


        // =====================================================
        // V10 - REMOTE CLOSE ALL CONTEXT RESOLUTION
        // =====================================================
        private Account ResolveAccountByName(
            string accountName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    accountName
                )
            )
            {
                return null;
            }

            foreach (
                Account account
                in Account.All
            )
            {
                if (
                    account != null &&
                    string.Equals(
                        account.Name,
                        accountName,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return account;
                }
            }

            return null;
        }

        private Instrument ResolveInstrumentByName(
            string instrumentName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                return null;
            }

            try
            {
                return Instrument.GetInstrument(
                    instrumentName
                );
            }
            catch
            {
                return null;
            }
        }

        private void CloseAllForContext(
            Account targetAccount,
            Instrument targetInstrument,
            string origin)
        {
            if (
                targetAccount == null ||
                targetInstrument == null
            )
            {
                PrintBotMessage(
                    "CLOSE ALL CONTEXT ERROR"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | Account/Instrument not resolved."
                );

                return;
            }

            if (
                !IsSimulationAccount(
                    targetAccount
                )
            )
            {
                PrintBotMessage(
                    "CLOSE ALL BLOCKED - NON SIM"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | "
                    + targetAccount.Name
                    + " / "
                    + targetInstrument.FullName
                );

                return;
            }

            try
            {
                targetAccount.Flatten(
                    new[]
                    {
                        targetInstrument
                    }
                );

                botRunning = false;

                ReleaseRuntimeLease();

                entryPending = false;

                currentSignalState =
                    "SIM FLATTEN SENT";

                currentSetupState =
                    "STOPPED";

                executionStatus =
                    "FLATTENING";

                PublishSharedState();

                riskFlattenSent =
                    true;

                UpdateExecutionMonitor();
                StopBarsEngine();

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "SIM FLATTEN SENT";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                {
                    startButton.IsEnabled =
                        true;
                }

                if (stopButton != null)
                {
                    stopButton.IsEnabled =
                        false;
                }

                if (directionCombo != null)
                {
                    directionCombo.IsEnabled =
                        true;
                }

                if (accountSelector != null)
                {
                    accountSelector.IsEnabled =
                        true;
                }

                if (instrumentSelector != null)
                {
                    instrumentSelector.IsEnabled =
                        true;
                }

                PrintBotMessage(
                    "SIM CLOSE ALL / FLATTEN SENT"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | "
                    + targetAccount.Name
                    + " / "
                    + targetInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "CLOSE ALL ERROR"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // CLOSE ALL
        // TEST MODE ONLY - DOES NOT SEND ORDERS
        // =====================================================
        private void CloseAllClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select an account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (
                !IsSimulationAccount(
                    selectedAccount
                )
            )
            {
                MessageBox.Show(
                    "CLOSE ALL is blocked because the selected account is not SIM.",
                    "J&J Trading Bot - LIVE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop
                );

                return;
            }

            CloseAllForContext(
                selectedAccount,
                selectedInstrument,
                "NINJA UI"
            );
        }

        // =====================================================
        // STOP / DISPOSE DATA ENGINE
        // =====================================================
        private void StopBarsEngine()
        {
            barsReady = false;

            if (barsRequest != null)
            {
                try
                {
                    if (barsRequestSubscribed)
                    {
                        barsRequest.Update -=
                            OnBarsRequestUpdate;

                        barsRequestSubscribed =
                            false;
                    }

                    barsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "BARS CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                barsRequest = null;
            }

            if (h1BarsRequest != null)
            {
                try
                {
                    if (h1BarsRequestSubscribed)
                    {
                        h1BarsRequest.Update -=
                            OnH1BarsRequestUpdate;

                        h1BarsRequestSubscribed =
                            false;
                    }

                    h1BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "1H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h1BarsRequest = null;
            }

            if (h4BarsRequest != null)
            {
                try
                {
                    if (h4BarsRequestSubscribed)
                    {
                        h4BarsRequest.Update -=
                            OnH4BarsRequestUpdate;

                        h4BarsRequestSubscribed =
                            false;
                    }

                    h4BarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "4H CONTEXT CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                h4BarsRequest = null;
            }

            h1BarsReady = false;
            h4BarsReady = false;

            lastH1BarTime =
                DateTime.MinValue;

            lastH4BarTime =
                DateTime.MinValue;

            if (rangeBarsRequest != null)
            {
                try
                {
                    if (rangeBarsRequestSubscribed)
                    {
                        rangeBarsRequest.Update -=
                            OnRangeBarsRequestUpdate;

                        rangeBarsRequestSubscribed =
                            false;
                    }

                    rangeBarsRequest.Dispose();
                }
                catch (Exception ex)
                {
                    PrintBotMessage(
                        "RANGE CLEANUP ERROR: "
                        + ex.Message
                    );
                }

                rangeBarsRequest = null;
            }

            rangeBarsReady = false;
            lastRangeBarTime =
                DateTime.MinValue;

            lastSignalBarTime =
                DateTime.MinValue;

            ClearEmaCaches();
        }

        // =====================================================
        // ERROR STATE
        // =====================================================
        private void SetEngineError(
            string text)
        {
            botRunning = false;

            StopBarsEngine();

            if (statusText != null)
            {
                statusText.Text =
                    "● STOPPED";

                statusText.Foreground =
                    Brushes.OrangeRed;
            }

            if (signalText != null)
            {
                signalText.Text =
                    text;

                signalText.Foreground =
                    Brushes.OrangeRed;
            }

            if (startButton != null)
                startButton.IsEnabled = true;

            if (stopButton != null)
                stopButton.IsEnabled = false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;
        }

        // =====================================================
        // RESET SIGNAL DISPLAY
        // =====================================================
        private void ResetSignalDisplay()
        {
            if (lastPriceText != null)
                lastPriceText.Text = "--";

            if (emaFastText != null)
                emaFastText.Text = "--";

            if (emaSlowText != null)
                emaSlowText.Text = "--";

            if (barTimeText != null)
                barTimeText.Text = "--";

            if (vwapText != null)
                vwapText.Text = "--";

            if (trendText != null)
                trendText.Text = "--";

            if (nySessionText != null)
            {
                nySessionText.Text = "CLOSED";
                nySessionText.Foreground = Brushes.Gray;
            }

            if (setupText != null)
            {
                setupText.Text = "WAITING";
                setupText.Foreground = Brushes.White;
            }

            if (liquidityText != null)
            {
                liquidityText.Text = "NONE";
                liquidityText.Foreground = Brushes.Gray;
            }

            if (structureText != null)
            {
                structureText.Text = "WAITING";
                structureText.Foreground = Brushes.Goldenrod;
            }

            if (momentumText != null)
            {
                momentumText.Text = "WAITING";
                momentumText.Foreground = Brushes.Goldenrod;
            }

            if (confirmationText != null)
            {
                confirmationText.Text = "WAITING";
                confirmationText.Foreground = Brushes.Gray;
            }

            if (
                signalText != null &&
                !botRunning
            )
            {
                signalText.Text =
                    "WAITING";

                signalText.Foreground =
                    Brushes.White;
            }
        }

        // =====================================================
        // BACKGROUND MODE
        // =====================================================
        // Clicking X hides only the control panel. The bot engine,
        // BarsRequests, telemetry and remote command polling continue.
        private void OnBotWindowClosing(
            object sender,
            CancelEventArgs e)
        {
            if (allowPermanentClose)
            {
                return;
            }

            e.Cancel = true;

            Hide();

            PrintBotMessage(
                "CONTROL PANEL HIDDEN"
                + " | Bot engine remains active in background."
            );

            PublishPlatformTelemetry();
        }

        public void RequestPermanentClose()
        {
            if (!engineWindowAlive)
            {
                return;
            }

            allowPermanentClose = true;

            try
            {
                if (Dispatcher.CheckAccess())
                {
                    Close();
                }
                else
                {
                    Dispatcher.Invoke(
                        new Action(() =>
                        {
                            Close();
                        })
                    );
                }
            }
            catch
            {
            }
        }

        // =====================================================
        // WINDOW CLEANUP
        // =====================================================
       private void OnBotWindowClosed(
    object sender,
    EventArgs e)
{
            engineWindowAlive = false;

            StopPlatformTelemetry();
            StopPlatformCommandPolling();

    botRunning = false;

    ReleaseRuntimeLease();

    currentSignalState =
        "WINDOW CLOSED";

    currentSetupState =
        "STOPPED";

    // Save persistent counters BEFORE destroying
    // the Account + Instrument bridge.
    SavePersistentDailyState();

    // Remove the exact shared snapshot instead of
    // leaving a permanent STOPPED bot on the chart.
    if (
        selectedAccount != null &&
        selectedInstrument != null
    )
    {
        JJBotSharedState.RemoveSnapshot(
            selectedAccount.Name,
            selectedInstrument.FullName
        );
    }

    StopBarsEngine();
    UnsubscribeExecutionAccount();

            if (accountSelector != null)
            {
                accountSelector.SelectionChanged -=
                    AccountSelectorChanged;

                accountSelector.Cleanup();
                accountSelector = null;
            }

            if (instrumentSelector != null)
            {
                instrumentSelector.InstrumentChanged -=
                    InstrumentSelectorChanged;

                instrumentSelector.Cleanup();
                instrumentSelector = null;
            }

            if (startButton != null)
            {
                startButton.Click -=
                    StartBotClicked;
            }

            if (stopButton != null)
            {
                stopButton.Click -=
                    StopBotClicked;
            }

            if (closeAllButton != null)
            {
                closeAllButton.Click -=
                    CloseAllClicked;
            }

            if (testLongButton != null)
            {
                testLongButton.Click -=
                    TestLongClicked;
            }

            if (testShortButton != null)
            {
                testShortButton.Click -=
                    TestShortClicked;
            }

            if (clearLogButton != null)
            {
                clearLogButton.Click -=
                    ClearVisualLogClicked;
            }

            Closing -=
                OnBotWindowClosing;

            Closed -=
                OnBotWindowClosed;
        }

        // =====================================================
        // INVALID VALUE MESSAGE
        // =====================================================
        private void ShowInvalidValue(
            string message)
        {
            MessageBox.Show(
                message,
                "J&J Trading Bot",
                MessageBoxButton.OK,
                MessageBoxImage.Warning
            );
        }

        // =====================================================
        // PRICE FORMAT
        // =====================================================
        private string FormatPrice(
            double price)
        {
            if (
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
            )
            {
                try
                {
                    return selectedInstrument
                        .MasterInstrument
                        .FormatPrice(
                            price
                        );
                }
                catch
                {
                }
            }

            return price.ToString(
                "0.00"
            );
        }

        // =====================================================
        // OUTPUT
        // =====================================================
        // =====================================================
        // PUBLISH REAL ADDON STATE TO JJBotChart
        // =====================================================
        private void PublishSharedState()
        {
            string position;
            int localTradesToday;
            int localAmTrades;
            int localPmTrades;
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;
            bool localDailyLocked;
            int localEntryQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            bool localDailyTargetProtectionArmed;
            bool localMomentumTrailingActive;
            int localMomentumTrailingStage;

            lock (executionStateLock)
            {
                position =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? "LONG"
                        : entryMarketPosition ==
                            MarketPosition.Short
                            ? "SHORT"
                            : "FLAT";

                localTradesToday =
                    tradesToday;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;

                localDailyLocked =
                    persistentDailyLocked;

                localEntryQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localDailyTargetProtectionArmed =
                    dailyTargetProtectionArmed;

                localMomentumTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localMomentumTrailingStage =
                    momentumTrailingStage;
            }

            string h4Trend =
                "WAITING";

            string h1Trend =
                "WAITING";

            string htfContextBias =
                "NEUTRAL 0/2";

            string m5Trend =
                "WAITING";

            string m5VwapSide =
                "WAITING";

            string m5Liquidity =
                "NONE";

            string m5Structure =
                "WAITING";

            string rangeMomentum =
                "WAITING RANGE";

            int rangeLongScore = 0;
            int rangeShortScore = 0;

            DateTime sessionReferenceNy =
                GetCurrentNewYorkTime();

            lock (marketContextLock)
            {
                h4Trend =
                    latestH4Trend
                    ?? "WAITING";

                h1Trend =
                    latestH1Trend
                    ?? "WAITING";

                htfContextBias =
                    latestHtfContextBias
                    ?? "NEUTRAL 0/2";

                if (latestM5ContextReady)
                {
                    m5Trend =
                        latestM5BullishTrend
                            ? "BULLISH"
                            : latestM5BearishTrend
                                ? "BEARISH"
                                : "NEUTRAL";

                    m5VwapSide =
                        latestM5AboveVwap
                            ? "ABOVE VWAP"
                            : latestM5BelowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                    m5Liquidity =
                        latestM5LiquidityState
                        ?? "NONE";

                    m5Structure =
                        latestM5StructureState
                        ?? "WAITING";

                    if (
                        latestM5DecisionNyTime !=
                            DateTime.MinValue
                    )
                    {
                        sessionReferenceNy =
                            latestM5DecisionNyTime;
                    }
                }

                rangeMomentum =
                    latestRangeMomentumState
                    ?? "WAITING RANGE";

                rangeLongScore =
                    latestRangeLongScore;

                rangeShortScore =
                    latestRangeShortScore;
            }

            int learningPatterns = 0;
            int learningTrades = 0;

            lock (SharedLearningSyncRoot)
            {
                if (
                    learningMemory != null &&
                    learningMemory.Patterns != null
                )
                {
                    learningPatterns =
                        learningMemory.Patterns.Count;

                    foreach (
                        JJBotLearningPattern pattern
                        in learningMemory.Patterns
                    )
                    {
                        if (pattern != null)
                        {
                            learningTrades +=
                                pattern.Trades;
                        }
                    }
                }
            }

            string trailingState =
                "OFF";

            if (localDailyTargetProtectionArmed)
            {
                trailingState =
                    "DAILY TARGET TRAIL";
            }
            else if (localMomentumTrailingActive)
            {
                trailingState =
                    localMomentumTrailingStage == 0
                        ? "ARMED"
                        : localMomentumTrailingStage == 1
                            ? "BREAK EVEN"
                            : localMomentumTrailingStage == 2
                                ? "LOCK +"
                                    + MomentumLockProfitTicks
                                    + "t"
                                : localMomentumTrailingStage == 3
                                    ? "LOCK +"
                                        + MomentumLock2ProfitTicks
                                        + "t"
                                    : "TRAIL "
                                        + MomentumTrailDistanceTicks
                                        + "t";
            }

            JJBotSharedState.Update(
                botRunning,
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty,
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty,
                localTradesToday,
                activeMaxTrades,
                localAmTrades,
                localPmTrades,
                localRealizedPnL,
                localUnrealizedPnL,
                totalPnL,
                localDailyLocked,
                position,
                localEntryQuantity,
                localEntryPrice,
                localStopPrice,
                localTargetPrice,
                localExecutionStatus,
                currentSignalState,
                currentSetupState,
                activeStrategyMode,
                GetBotSessionWindow(
                    sessionReferenceNy
                ),
                h4Trend,
                h1Trend,
                htfContextBias,
                m5Trend,
                m5VwapSide,
                m5Liquidity,
                m5Structure,
                rangeMomentum,
                rangeLongScore,
                rangeShortScore,
                true,
                learningPatterns,
                learningTrades,
                trailingState
            );
        }

        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        private void LoadPlatformBridgeConfig()
        {
            try
            {
                platformConfigFile =
                    Path.Combine(
                        Environment.GetFolderPath(
                            Environment.SpecialFolder.MyDocuments
                        ),
                        "J&J Company Bro",
                        "config.json"
                    );

                if (
                    !File.Exists(
                        platformConfigFile
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: config.json not found at "
                        + platformConfigFile
                    );

                    return;
                }

                string json =
                    File.ReadAllText(
                        platformConfigFile
                    );

                string loadedApiKey =
                    ExtractJsonStringValue(
                        json,
                        "apiKey"
                    );

                string loadedServerUrl =
                    ExtractJsonStringValue(
                        json,
                        "serverUrl"
                    );

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedApiKey
                    )
                )
                {
                    platformApiKey =
                        loadedApiKey.Trim();
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedServerUrl
                    )
                )
                {
                    platformServerUrl =
                        loadedServerUrl
                            .Trim()
                            .TrimEnd('/');
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformServerUrl
                    )
                )
                {
                    platformServerUrl =
                        "http://localhost:3001";
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: apiKey missing in config.json"
                    );
                }
                else
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE READY"
                    );
                }
            }
            catch (Exception ex)
            {
                platformApiKey =
                    string.Empty;

                platformServerUrl =
                    "http://localhost:3001";

                PrintBotMessage(
                    "PLATFORM BRIDGE CONFIG ERROR: "
                    + ex.Message
                );
            }
        }

        private string ExtractJsonStringValue(
            string json,
            string propertyName)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return string.Empty;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*\\\"(?<value>(?:\\\\.|[^\\\"])*)\\\"";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                if (
                    !match.Success
                )
                {
                    return string.Empty;
                }

                string value =
                    match.Groups["value"].Value;

                return
                    value
                        .Replace("\\\\", "\\")
                        .Replace("\\\"", "\"")
                        .Replace("\\r", "\r")
                        .Replace("\\n", "\n")
                        .Replace("\\t", "\t");
            }
            catch
            {
                return string.Empty;
            }
        }

        private int ExtractJsonIntValue(
            string json,
            string propertyName,
            int fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                int value;

                if (
                    match.Success &&
                    int.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }

        private double ExtractJsonDoubleValue(
            string json,
            string propertyName,
            double fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+(?:\\.[0-9]+)?)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                double value;

                if (
                    match.Success &&
                    double.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }

        private void StartPlatformTelemetry()
        {
            if (
                platformTelemetryTimer != null
            )
            {
                return;
            }

            platformTelemetryTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformTelemetryTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformTelemetryIntervalSeconds
                );

            platformTelemetryTimer.Tick +=
                PlatformTelemetryTimerTick;

            platformTelemetryTimer.Start();

            // Send once immediately so the platform does not
            // have to wait for the first timer interval.
            PublishPlatformTelemetry();
        }

        private void StopPlatformTelemetry()
        {
            DispatcherTimer timer =
                platformTelemetryTimer;

            platformTelemetryTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformTelemetryTimerTick;
            }
            catch
            {
            }
        }

        private void PlatformTelemetryTimerTick(
            object sender,
            EventArgs e)
        {
            PublishPlatformTelemetry();
        }

        private void PublishPlatformTelemetry()
        {
            if (
                platformTelemetryRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                // The main J&J Company Bro AddOn may have
                // created config.json after this bot window
                // was opened. Retry loading it automatically.
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                PublishSharedState();

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : string.Empty;

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : string.Empty;

                JJBotSharedSnapshot snapshot =
                    JJBotSharedState.GetSnapshot(
                        accountName,
                        instrumentName
                    );

                string direction =
                    GetTelemetryDirection();

                string strategy =
                    GetTelemetryStrategy();

                int contracts =
                    botRunning
                        ? activeContracts
                        : GetTelemetryIntFromTextBox(
                            contractsBox,
                            activeContracts
                        );

                int stopTicks =
                    botRunning
                        ? activeStopTicks
                        : GetTelemetryIntFromTextBox(
                            stopBox,
                            activeStopTicks
                        );

                int targetTicks =
                    botRunning
                        ? activeTargetTicks
                        : GetTelemetryIntFromTextBox(
                            targetBox,
                            activeTargetTicks
                        );

                int maxTrades =
                    botRunning
                        ? activeMaxTrades
                        : GetTelemetryIntFromTextBox(
                            maxTradesBox,
                            activeMaxTrades
                        );

                double dailyTarget =
                    botRunning
                        ? activeDailyTarget
                        : GetTelemetryDoubleFromTextBox(
                            dailyTargetBox,
                            activeDailyTarget
                        );

                double dailyLoss =
                    botRunning
                        ? activeDailyLoss
                        : GetTelemetryDoubleFromTextBox(
                            dailyLossBox,
                            activeDailyLoss
                        );

                double dollarRiskCap =
                    botRunning
                        ? activeDollarRiskCap
                        : GetTelemetryDoubleFromTextBox(
                            dollarRiskCapBox,
                            activeDollarRiskCap
                        );

                string json =
                    BuildPlatformTelemetryJson(
                        snapshot,
                        accountName,
                        instrumentName,
                        direction,
                        strategy,
                        contracts,
                        stopTicks,
                        targetTicks,
                        maxTrades,
                        dailyTarget,
                        dailyLoss,
                        dollarRiskCap
                    );

                string endpoint =
                    platformServerUrl
                        .TrimEnd('/')
                    + "/api/bot/state";

                platformTelemetryRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        SendPlatformTelemetryRequest(
                            endpoint,
                            json
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformTelemetryRequestInFlight =
                    false;

                PrintBotMessage(
                    "PLATFORM TELEMETRY BUILD ERROR: "
                    + ex.Message
                );
            }
        }

        private string GetTelemetryDirection()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeDirection
                )
            )
            {
                return activeDirection;
            }

            if (
                directionCombo != null &&
                directionCombo.SelectedItem != null
            )
            {
                return
                    directionCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeDirection
                )
                    ? "BOTH"
                    : activeDirection;
        }

        private string GetTelemetryStrategy()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
            )
            {
                return activeStrategyMode;
            }

            if (
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
            )
            {
                return
                    strategyCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
                    ? "HYBRID"
                    : activeStrategyMode;
        }

        private int GetTelemetryIntFromTextBox(
            TextBox box,
            int fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            int value;

            if (
                int.TryParse(
                    box.Text,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }

        private double GetTelemetryDoubleFromTextBox(
            TextBox box,
            double fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            double value;

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.CurrentCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }

        private string[] GetPlatformAvailableInstruments()
        {
            List<string> names =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            DateTime now =
                DateTime.Now.Date;

            DateTime minimumExpiry =
                now.AddDays(-45);

            DateTime maximumExpiry =
                now.AddMonths(18);

            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string fullName =
                        instrument.FullName;

                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        continue;
                    }

                    DateTime expiry =
                        instrument.Expiry;

                    if (
                        expiry != DateTime.MinValue &&
                        (
                            expiry.Date < minimumExpiry ||
                            expiry.Date > maximumExpiry
                        )
                    )
                    {
                        continue;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        names.Add(
                            fullName
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "INSTRUMENT LIST ERROR: "
                    + ex.Message
                );
            }

            if (
                selectedInstrument != null &&
                !string.IsNullOrWhiteSpace(
                    selectedInstrument.FullName
                ) &&
                seen.Add(
                    selectedInstrument.FullName
                )
            )
            {
                names.Add(
                    selectedInstrument.FullName
                );
            }

            names.Sort(
                StringComparer.OrdinalIgnoreCase
            );

            if (
                names.Count > 300
            )
            {
                names =
                    names.GetRange(
                        0,
                        300
                    );
            }

            return names.ToArray();
        }

        private void AppendJsonStringArrayProperty(
            StringBuilder builder,
            string name,
            string[] values,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":[");

            bool first =
                true;

            if (values != null)
            {
                for (
                    int i = 0;
                    i < values.Length;
                    i++
                )
                {
                    string value =
                        values[i];

                    if (
                        string.IsNullOrWhiteSpace(
                            value
                        )
                    )
                    {
                        continue;
                    }

                    if (!first)
                    {
                        builder.Append(",");
                    }

                    AppendJsonString(
                        builder,
                        value
                    );

                    first =
                        false;
                }
            }

            builder.Append("]");
        }

        private string BuildPlatformTelemetryJson(
            JJBotSharedSnapshot snapshot,
            string accountName,
            string instrumentName,
            string direction,
            string strategy,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss,
            double dollarRiskCap)
        {
            bool running =
                snapshot != null
                    ? snapshot.IsRunning
                    : botRunning;

            int trades =
                snapshot != null
                    ? snapshot.TradesToday
                    : tradesToday;

            // dailyPnl remains NET for backward compatibility.
            double dailyPnl =
                snapshot != null
                    ? snapshot.RealizedPnL
                    : botDailyPnL;

            double grossPnl =
                botDailyGrossPnL;

            double commissionsFees =
                botDailyFees;

            string position =
                snapshot != null
                    ? snapshot.Position
                    : "FLAT";

            int positionQty =
                snapshot != null
                    ? snapshot.PositionQty
                    : 0;

            double entryPrice =
                snapshot != null
                    ? snapshot.EntryPrice
                    : 0;

            string trend =
                snapshot != null
                    ? snapshot.M5Trend
                    : "WAITING";

            string vwap =
                snapshot != null
                    ? snapshot.M5VwapSide
                    : "WAITING";

            string liquidity =
                snapshot != null
                    ? snapshot.M5Liquidity
                    : "NONE";

            string structure =
                snapshot != null
                    ? snapshot.M5Structure
                    : "WAITING";

            int rangeLong =
                snapshot != null
                    ? snapshot.RangeLongScore
                    : latestRangeLongScore;

            int rangeShort =
                snapshot != null
                    ? snapshot.RangeShortScore
                    : latestRangeShortScore;

            string currentSignal =
                snapshot != null
                    ? snapshot.Signal
                    : currentSignalState;

            string setup =
                snapshot != null
                    ? snapshot.Setup
                    : currentSetupState;

            double unrealizedPnl =
                snapshot != null
                    ? snapshot.UnrealizedPnL
                    : botUnrealizedPnL;

            double totalPnl =
                snapshot != null
                    ? snapshot.TotalPnL
                    : botDailyPnL +
                        botUnrealizedPnL;

            int amTrades =
                snapshot != null
                    ? snapshot.AmTrades
                    : amTradesToday;

            int pmTrades =
                snapshot != null
                    ? snapshot.PmTrades
                    : pmTradesToday;

            DateTime strategyClockNy =
                GetCurrentNewYorkTime();

            DateTime marketTimeNy =
                latestM5DecisionNyTime !=
                    DateTime.MinValue
                    ? latestM5DecisionNyTime
                    : strategyClockNy;

            string lockReason =
                string.IsNullOrWhiteSpace(
                    persistentDailyLockReason
                )
                    ? "NONE"
                    : persistentDailyLockReason;

            string openingState =
                openingRangeGuardBlocked
                    ? "BLOCKED"
                    : openingRangeReady
                        ? "READY"
                        : "BUILDING";

            string preEntryState =
                preEntryRangeReady
                    ? "READY"
                    : "WAITING";

            bool activeTrade =
                !string.Equals(
                    position,
                    "FLAT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                positionQty > 0;

            int telemetryTechnicalConfidence =
                activeTrade &&
                activeTradeSetupConfidence > 0
                    ? activeTradeSetupConfidence
                    : latestSetupConfidence;

            string telemetryConfidenceSide =
                activeTrade
                    ? (
                        entryMarketPosition ==
                            MarketPosition.Long
                            ? "LONG"
                            : (
                                entryMarketPosition ==
                                    MarketPosition.Short
                                    ? "SHORT"
                                    : string.Empty
                              )
                      )
                    : (
                        string.Equals(
                            autoResolvedDirection,
                            "LONG ONLY",
                            StringComparison.OrdinalIgnoreCase
                        )
                            ? "LONG"
                            : (
                                string.Equals(
                                    autoResolvedDirection,
                                    "SHORT ONLY",
                                    StringComparison.OrdinalIgnoreCase
                                )
                                    ? "SHORT"
                                    : string.Empty
                              )
                      );

            string telemetryConfidenceStructure =
                activeTrade &&
                activeLearningTrade != null
                    ? activeLearningTrade.Structure
                    : latestM5StructureState;

            int telemetryConfidenceSampleTrades;
            double telemetryObservedWinRate;

            int telemetrySetupConfidence =
                GetCalibratedSetupConfidence(
                    telemetryConfidenceSide,
                    telemetryConfidenceStructure,
                    telemetryTechnicalConfidence,
                    out telemetryConfidenceSampleTrades,
                    out telemetryObservedWinRate
                );

            string telemetrySetupQuality =
                activeTrade &&
                !string.IsNullOrWhiteSpace(
                    activeTradeSetupQuality
                )
                    ? activeTradeSetupQuality
                    : (
                        string.IsNullOrWhiteSpace(
                            latestSetupQuality
                        )
                            ? "ANALYZING"
                            : latestSetupQuality
                      );

            bool telemetryConfidenceFrozen =
                activeTrade &&
                activeTradeSetupConfidence > 0;

            bool learningActive =
                snapshot != null
                    ? snapshot.LearningActive
                    : true;

            string learningStatus =
                learningActive
                    ? "ACTIVE"
                    : "OFF";

            string[] logLines =
                visualLogLines != null
                    ? visualLogLines.ToArray()
                    : new string[0];

            // V1.6.6 - retain up to MaxVisualLogLines locally, but send
            // only the most recent telemetry tail to the platform.
            int logStart =
                Math.Max(
                    0,
                    logLines.Length -
                        PlatformTelemetryMaxLogLines
                );

            StringBuilder builder =
                new StringBuilder();

            builder.Append("{");
            builder.Append("\"apiKey\":");
            AppendJsonString(
                builder,
                platformApiKey
            );
            builder.Append(",\"profileId\":");
            AppendJsonString(
                builder,
                platformProfileId
            );
            builder.Append(",\"state\":{");

            AppendJsonStringProperty(
                builder,
                "profileId",
                platformProfileId,
                false
            );

            AppendJsonProperty(
                builder,
                "running",
                running
                    ? "true"
                    : "false",
                true
            );

            AppendJsonStringProperty(
                builder,
                "account",
                accountName,
                true
            );

            AppendJsonStringProperty(
                builder,
                "instrument",
                instrumentName,
                true
            );

            AppendJsonStringArrayProperty(
                builder,
                "availableInstruments",
                GetPlatformAvailableInstruments(),
                true
            );

            AppendJsonStringProperty(
                builder,
                "strategy",
                strategy,
                true
            );

            AppendJsonStringProperty(
                builder,
                "direction",
                direction,
                true
            );

            AppendJsonStringProperty(
                builder,
                "resolvedDirection",
                string.Equals(
                    direction,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
                    ? autoResolvedDirection
                    : direction,
                true
            );

            AppendJsonStringProperty(
                builder,
                "directionReason",
                string.Equals(
                    direction,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
                    ? autoDirectionReason
                    : "MANUAL "
                        + direction,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "contracts",
                contracts,
                true
            );

            AppendJsonStringProperty(
                builder,
                "trendM5",
                trend,
                true
            );

            AppendJsonStringProperty(
                builder,
                "vwap",
                vwap,
                true
            );

            AppendJsonStringProperty(
                builder,
                "liquidity",
                liquidity,
                true
            );

            AppendJsonStringProperty(
                builder,
                "structure",
                structure,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeLongScore",
                rangeLong,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeShortScore",
                rangeShort,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeScoreMax",
                5,
                true
            );

            AppendJsonStringProperty(
                builder,
                "currentSignal",
                currentSignal,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setup",
                setup,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "setupConfidence",
                telemetrySetupConfidence,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "technicalSetupConfidence",
                telemetryTechnicalConfidence,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "confidenceSampleTrades",
                telemetryConfidenceSampleTrades,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "observedConfidenceWinRate",
                telemetryObservedWinRate,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setupQuality",
                telemetrySetupQuality,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setupTiming",
                string.IsNullOrWhiteSpace(
                    latestSetupTiming
                )
                    ? "ANALYZING"
                    : latestSetupTiming,
                true
            );

            AppendJsonStringProperty(
                builder,
                "manipulationState",
                string.IsNullOrWhiteSpace(
                    latestManipulationState
                )
                    ? "NONE"
                    : latestManipulationState,
                true
            );

            AppendJsonProperty(
                builder,
                "setupConfidenceFrozen",
                telemetryConfidenceFrozen
                    ? "true"
                    : "false",
                true
            );

            AppendJsonNumberProperty(
                builder,
                "stopTicks",
                stopTicks,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "targetTicks",
                targetTicks,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyTarget",
                dailyTarget,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyLoss",
                dailyLoss,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dollarRiskCap",
                activeDollarRiskCap,
                true
            );

            AppendJsonStringProperty(
                builder,
                "learningStatus",
                learningStatus,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "grossPnl",
                grossPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "commissionsFees",
                commissionsFees,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "netPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "realizedPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "unrealizedPnl",
                unrealizedPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "totalPnl",
                totalPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyPeakPnl",
                dailyPeakTotalPnL,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "protectedProfitFloor",
                dailyProfitFloorArmed
                    ? dailyProtectedProfitFloor
                    : 0,
                true
            );

            AppendJsonProperty(
                builder,
                "profitFloorArmed",
                dailyProfitFloorArmed
                    ? "true"
                    : "false",
                true
            );

            AppendJsonStringProperty(
                builder,
                "dailyLockReason",
                lockReason,
                true
            );

            AppendJsonStringProperty(
                builder,
                "strategyClockNy",
                strategyClockNy.ToString(
                    "yyyy-MM-dd HH:mm:ss"
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "marketTimeNy",
                marketTimeNy.ToString(
                    "yyyy-MM-dd HH:mm:ss"
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "openingState",
                openingState,
                true
            );

            AppendJsonStringProperty(
                builder,
                "openingGuardReason",
                string.IsNullOrWhiteSpace(
                    openingRangeGuardReason
                )
                    ? "NONE"
                    : openingRangeGuardReason,
                true
            );

            AppendJsonStringProperty(
                builder,
                "preEntryState",
                preEntryState,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "preEntryHigh",
                preEntryRangeReady
                    ? preEntryRangeHigh
                    : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "preEntryLow",
                preEntryRangeReady
                    ? preEntryRangeLow
                    : 0,
                true
            );

            AppendJsonProperty(
                builder,
                "activeTrade",
                activeTrade
                    ? "true"
                    : "false",
                true
            );

            AppendJsonNumberProperty(
                builder,
                "tradesToday",
                trades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "premarketTrades",
                premarketTradesToday,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "amTrades",
                amTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "middayTrades",
                middayTradesToday,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "pmTrades",
                pmTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "premarketMaxTrades",
                PremarketMaxTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "middayMaxTrades",
                MiddayMaxTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "tradesThisSession",
                GetSessionTradeCount(
                    GetBotSessionWindow(
                        strategyClockNy
                    )
                ),
                true
            );

            AppendJsonNumberProperty(
                builder,
                "maxTradesPerSession",
                GetSessionTradeLimit(
                    GetBotSessionWindow(
                        strategyClockNy
                    )
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "position",
                position,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "positionQuantity",
                positionQty,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "averageEntryPrice",
                entryPrice,
                true
            );

            AppendJsonStringProperty(
                builder,
                "addonVersion",
                PlatformBridgeVersion,
                true
            );

            AppendJsonStringProperty(
                builder,
                "engineVersion",
                "V1.6.18",
                true
            );

            builder.Append(",\"logs\":[");

            bool firstLog = true;

            for (
                int i = logStart;
                i < logLines.Length;
                i++
            )
            {
                if (!firstLog)
                {
                    builder.Append(",");
                }

                AppendJsonString(
                    builder,
                    logLines[i]
                );

                firstLog = false;
            }

            builder.Append("]");
            builder.Append("}}");

            return builder.ToString();
        }

        private void AppendJsonProperty(
            StringBuilder builder,
            string name,
            string rawValue,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");
            builder.Append(rawValue);
        }

        private void AppendJsonStringProperty(
            StringBuilder builder,
            string name,
            string value,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");

            AppendJsonString(
                builder,
                value
            );
        }

        private void AppendJsonNumberProperty(
            StringBuilder builder,
            string name,
            int value,
            bool prependComma)
        {
            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }

        private void AppendJsonDoubleProperty(
            StringBuilder builder,
            string name,
            double value,
            bool prependComma)
        {
            if (
                double.IsNaN(value) ||
                double.IsInfinity(value)
            )
            {
                value = 0;
            }

            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    "0.########",
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }

        private void AppendJsonString(
            StringBuilder builder,
            string value)
        {
            builder.Append("\"");

            string text =
                value ?? string.Empty;

            for (
                int i = 0;
                i < text.Length;
                i++
            )
            {
                char c =
                    text[i];

                switch (c)
                {
                    case '\\':
                        builder.Append("\\\\");
                        break;

                    case '"':
                        builder.Append("\\\"");
                        break;

                    case '\r':
                        builder.Append("\\r");
                        break;

                    case '\n':
                        builder.Append("\\n");
                        break;

                    case '\t':
                        builder.Append("\\t");
                        break;

                    default:
                        if (c < 32)
                        {
                            builder.Append(
                                "\\u"
                                + ((int)c).ToString(
                                    "x4"
                                )
                            );
                        }
                        else
                        {
                            builder.Append(c);
                        }
                        break;
                }
            }

            builder.Append("\"");
        }

        // V1.6.12 - send credentials in the standard Authorization header.
        // Legacy apiKey body/query compatibility is intentionally retained
        // until the localhost backend is upgraded to accept header-only auth.
        // Removing the legacy field before that server change would break the
        // existing bridge, so this is a backward-compatible migration step.
        private void ApplyPlatformAuthorizationHeader(
            HttpWebRequest request)
        {
            if (
                request == null ||
                string.IsNullOrWhiteSpace(platformApiKey)
            )
            {
                return;
            }

            request.Headers[HttpRequestHeader.Authorization] =
                "Bearer " + platformApiKey;
        }

        private void SendPlatformTelemetryRequest(
            string endpoint,
            string json)
        {
            try
            {
                byte[] body =
                    Encoding.UTF8.GetBytes(
                        json
                    );

                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "POST";

                ApplyPlatformAuthorizationHeader(
                    request
                );

                request.ContentType =
                    "application/json";

                request.ContentLength =
                    body.Length;

                request.Timeout =
                    2500;

                request.ReadWriteTimeout =
                    2500;

                using (
                    Stream requestStream =
                        request.GetRequestStream()
                )
                {
                    requestStream.Write(
                        body,
                        0,
                        body.Length
                    );
                }

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                {
                    int statusCode =
                        (int)response.StatusCode;

                    if (
                        statusCode >= 200 &&
                        statusCode < 300
                    )
                    {
                        lastPlatformTelemetrySuccessUtc =
                            DateTime.UtcNow;
                    }
                }
            }
            catch (WebException ex)
            {
                // Do not spam the visual log every 3 seconds.
                // Only emit a message if the platform bridge had
                // previously been healthy.
                if (
                    lastPlatformTelemetrySuccessUtc !=
                        DateTime.MinValue
                )
                {
                    DateTime lastSuccess =
                        lastPlatformTelemetrySuccessUtc;

                    lastPlatformTelemetrySuccessUtc =
                        DateTime.MinValue;

                    Dispatcher.BeginInvoke(
                        new Action(
                            delegate
                            {
                                AppendVisualLog(
                                    "PLATFORM TELEMETRY OFFLINE: "
                                    + ex.Message
                                );
                            }
                        )
                    );
                }
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "PLATFORM TELEMETRY ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformTelemetryRequestInFlight =
                    false;
            }
        }

        // =====================================================
        // J&J COMPANY BRO - REMOTE BOT COMMANDS
        // =====================================================
        private void StartPlatformCommandPolling()
        {
            if (
                platformCommandTimer != null
            )
            {
                return;
            }

            platformCommandTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformCommandTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformCommandIntervalSeconds
                );

            platformCommandTimer.Tick +=
                PlatformCommandTimerTick;

            platformCommandTimer.Start();
        }

        private void StopPlatformCommandPolling()
        {
            DispatcherTimer timer =
                platformCommandTimer;

            platformCommandTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformCommandTimerTick;
            }
            catch
            {
            }
        }

        private void PlatformCommandTimerTick(
            object sender,
            EventArgs e)
        {
            PollPlatformCommand();
        }

        private void PollPlatformCommand()
        {
            if (
                platformCommandRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                // Backward-compatible bridge migration: Authorization
                // header is now sent by ReadPlatformCommandRequest. The legacy
                // query parameter remains until the Node backend accepts
                // header-only authentication.
                string endpoint =
                    platformServerUrl
                        .TrimEnd('/')
                    + "/api/bot/commands?apiKey="
                    + Uri.EscapeDataString(
                        platformApiKey
                    )
                    + "&profileId="
                    + Uri.EscapeDataString(
                        platformProfileId
                    );

                platformCommandRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        ReadPlatformCommandRequest(
                            endpoint
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformCommandRequestInFlight =
                    false;

                AppendVisualLog(
                    "BOT COMMAND POLL ERROR: "
                    + ex.Message
                );
            }
        }

        private void ReadPlatformCommandRequest(
            string endpoint)
        {
            string responseText =
                string.Empty;

            try
            {
                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "GET";

                ApplyPlatformAuthorizationHeader(
                    request
                );

                request.Accept =
                    "application/json";

                request.Timeout =
                    2000;

                request.ReadWriteTimeout =
                    2000;

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                using (
                    Stream stream =
                        response.GetResponseStream()
                )
                using (
                    StreamReader reader =
                        new StreamReader(
                            stream,
                            Encoding.UTF8
                        )
                )
                {
                    responseText =
                        reader.ReadToEnd();
                }

                if (
                    string.IsNullOrWhiteSpace(
                        responseText
                    ) ||
                    responseText.Trim() == "[]"
                )
                {
                    return;
                }

                string commandId =
                    ExtractJsonStringValue(
                        responseText,
                        "id"
                    );

                string commandType =
                    ExtractJsonStringValue(
                        responseText,
                        "type"
                    )
                        .Trim()
                        .ToUpperInvariant();

                string commandAccount =
                    ExtractJsonStringValue(
                        responseText,
                        "account"
                    );

                string commandInstrument =
                    ExtractJsonStringValue(
                        responseText,
                        "instrument"
                    );

                string commandQuery =
                    ExtractJsonStringValue(
                        responseText,
                        "query"
                    );

                string commandStrategy =
                    ExtractJsonStringValue(
                        responseText,
                        "strategy"
                    );

                string commandDirection =
                    ExtractJsonStringValue(
                        responseText,
                        "direction"
                    );

                int commandContracts =
                    ExtractJsonIntValue(
                        responseText,
                        "contracts",
                        1
                    );

                int commandStopTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "stopTicks",
                        100
                    );

                int commandTargetTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "targetTicks",
                        150
                    );

                int commandMaxTrades =
                    ExtractJsonIntValue(
                        responseText,
                        "maxTradesPerSession",
                        2
                    );

                double commandDailyTarget =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyTarget",
                        300
                    );

                double commandDailyLoss =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyLoss",
                        200
                    );

                double commandDollarRiskCap =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dollarRiskCap",
                        100
                    );

                if (
                    string.IsNullOrWhiteSpace(
                        commandId
                    ) ||
                    string.IsNullOrWhiteSpace(
                        commandType
                    )
                )
                {
                    return;
                }

                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            ExecutePlatformCommand(
                                commandId,
                                commandType,
                                commandAccount,
                                commandInstrument,
                                commandQuery,
                                commandStrategy,
                                commandDirection,
                                commandContracts,
                                commandStopTicks,
                                commandTargetTicks,
                                commandMaxTrades,
                                commandDailyTarget,
                                commandDailyLoss,
                                commandDollarRiskCap
                            );
                        }
                    )
                );
            }
            catch (WebException)
            {
                // Backend may be restarting. Telemetry heartbeat already
                // exposes the disconnected state, so do not spam the log.
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "BOT COMMAND ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformCommandRequestInFlight =
                    false;
            }
        }

        private string[] SearchNinjaInstruments(
            string query)
        {
            string normalizedQuery =
                (query ?? string.Empty)
                    .Trim();

            if (
                string.IsNullOrWhiteSpace(
                    normalizedQuery
                )
            )
            {
                return new string[0];
            }

            string upperQuery =
                normalizedQuery
                    .ToUpperInvariant();

            string masterQuery =
                upperQuery
                    .Split(
                        new char[]
                        {
                            ' ',
                            '\t'
                        },
                        StringSplitOptions
                            .RemoveEmptyEntries
                    )
                    .FirstOrDefault()
                ?? upperQuery;

            List<string> results =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            Action<string> addMatch =
                delegate(
                    string fullName)
                {
                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        return;
                    }

                    if (
                        fullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0 &&
                        fullName.IndexOf(
                            masterQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0
                    )
                    {
                        return;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        results.Add(
                            fullName
                        );
                    }
                };

            // 1) Search instruments already materialized in NinjaTrader.
            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string masterName =
                        instrument
                            .MasterInstrument
                            .Name
                        ?? string.Empty;

                    string description =
                        instrument
                            .MasterInstrument
                            .Description
                        ?? string.Empty;

                    if (
                        instrument.FullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        masterName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        description.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0
                    )
                    {
                        addMatch(
                            instrument.FullName
                        );
                    }
                }
            }
            catch
            {
            }

            // 2) Ask NinjaTrader for the master instrument directly.
            //    This is the important path for symbols such as MNQ that
            //    may not yet exist in Instrument.All for this session.
            try
            {
                Instrument masterInstrument =
                    Instrument.GetInstrument(
                        masterQuery
                    );

                if (
                    masterInstrument != null &&
                    masterInstrument.MasterInstrument != null &&
                    masterInstrument
                        .MasterInstrument
                        .InstrumentType ==
                    InstrumentType.Future
                )
                {
                    DateTime minimumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(-3);

                    DateTime maximumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(24);

                    foreach (
                        var rollover
                        in masterInstrument
                            .MasterInstrument
                            .RolloverCollection
                    )
                    {
                        DateTime contractMonth =
                            rollover.ContractMonth;

                        if (
                            contractMonth <
                                minimumMonth ||
                            contractMonth >
                                maximumMonth
                        )
                        {
                            continue;
                        }

                        string candidate =
                            masterInstrument
                                .MasterInstrument
                                .Name
                            + " "
                            + contractMonth
                                .ToString(
                                    "MM-yy",
                                    CultureInfo.InvariantCulture
                                );

                        Instrument contract =
                            Instrument.GetInstrument(
                                candidate
                            );

                        if (
                            contract != null
                        )
                        {
                            addMatch(
                                contract.FullName
                            );
                        }
                    }
                }
            }
            catch
            {
            }

            results =
                results
                    .OrderBy(
                        value =>
                            value.StartsWith(
                                masterQuery,
                                StringComparison.OrdinalIgnoreCase
                            )
                                ? 0
                                : 1
                    )
                    .ThenBy(
                        value =>
                            value,
                        StringComparer.OrdinalIgnoreCase
                    )
                    .Take(120)
                    .ToList();

            return results.ToArray();
        }

        private void PostPlatformInstrumentSearchResult(
            string requestId,
            string query,
            string[] instruments)
        {
            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                return;
            }

            string endpoint =
                platformServerUrl
                    .TrimEnd('/')
                + "/api/bot/instruments/search-result";

            StringBuilder searchJson =
                new StringBuilder();

            searchJson.Append("{");

            AppendJsonStringProperty(
                searchJson,
                "apiKey",
                platformApiKey,
                false
            );

            AppendJsonStringProperty(
                searchJson,
                "requestId",
                requestId,
                true
            );

            AppendJsonStringProperty(
                searchJson,
                "query",
                query,
                true
            );

            AppendJsonStringArrayProperty(
                searchJson,
                "instruments",
                instruments,
                true
            );

            searchJson.Append("}");

            string payload =
                searchJson.ToString();

            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    try
                    {
                        byte[] bytes =
                            Encoding.UTF8
                                .GetBytes(
                                    payload
                                );

                        HttpWebRequest request =
                            (HttpWebRequest)
                            WebRequest.Create(
                                endpoint
                            );

                        request.Method =
                            "POST";

                        ApplyPlatformAuthorizationHeader(
                            request
                        );

                        request.ContentType =
                            "application/json";

                        request.Timeout =
                            2500;

                        request.ReadWriteTimeout =
                            2500;

                        request.ContentLength =
                            bytes.Length;

                        using (
                            Stream requestStream =
                                request.GetRequestStream()
                        )
                        {
                            requestStream.Write(
                                bytes,
                                0,
                                bytes.Length
                            );
                        }

                        using (
                            HttpWebResponse response =
                                (HttpWebResponse)
                                request.GetResponse()
                        )
                        {
                        }
                    }
                    catch
                    {
                    }
                }
            );
        }

        private bool ApplyPlatformStartConfiguration(
            string accountName,
            string instrumentName,
            string strategy,
            string direction,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss,
            double dollarRiskCap)
        {
            Account resolvedAccount =
                null;

            try
            {
                resolvedAccount =
                    Account.All.FirstOrDefault(
                        account =>
                            account != null &&
                            string.Equals(
                                account.Name,
                                accountName,
                                StringComparison.OrdinalIgnoreCase
                            )
                    );
            }
            catch
            {
            }

            if (resolvedAccount == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Account not found: "
                    + accountName
                );

                return false;
            }

            if (
                !IsSimulationAccount(
                    resolvedAccount
                )
            )
            {
                AppendVisualLog(
                    "REMOTE START BLOCKED | LIVE ACCOUNT: "
                    + resolvedAccount.Name
                );

                return false;
            }

            Instrument resolvedInstrument =
                null;

            try
            {
                resolvedInstrument =
                    Instrument.GetInstrument(
                        instrumentName
                    );
            }
            catch
            {
            }

            if (resolvedInstrument == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Instrument not found: "
                    + instrumentName
                );

                return false;
            }

            selectedAccount =
                resolvedAccount;

            selectedInstrument =
                resolvedInstrument;

            if (accountStatusText != null)
            {
                accountStatusText.Text =
                    "Account: "
                    + selectedAccount.Name;

                accountStatusText.Foreground =
                    Brushes.LightGreen;
            }

            if (instrumentStatusText != null)
            {
                instrumentStatusText.Text =
                    "Instrument: "
                    + selectedInstrument.FullName;

                instrumentStatusText.Foreground =
                    Brushes.LightGreen;
            }

            // InstrumentSelector.Instrument is a writable property in
            // NinjaTrader. Keep its UI synchronized when the hidden
            // control panel is later opened.
            if (instrumentSelector != null)
            {
                try
                {
                    instrumentSelector.Instrument =
                        resolvedInstrument;
                }
                catch
                {
                }
            }

            string normalizedStrategy =
                string.IsNullOrWhiteSpace(
                    strategy
                )
                    ? "HYBRID"
                    : strategy
                        .Trim()
                        .ToUpperInvariant();

            string normalizedDirection =
                string.IsNullOrWhiteSpace(
                    direction
                )
                    ? "BOTH"
                    : direction
                        .Trim()
                        .ToUpperInvariant();

            if (
                strategyCombo != null &&
                strategyCombo.Items.Contains(
                    normalizedStrategy
                )
            )
            {
                strategyCombo.SelectedItem =
                    normalizedStrategy;
            }

            if (
                directionCombo != null &&
                directionCombo.Items.Contains(
                    normalizedDirection
                )
            )
            {
                directionCombo.SelectedItem =
                    normalizedDirection;
            }

            if (contractsBox != null)
                contractsBox.Text =
                    contracts.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (stopBox != null)
                stopBox.Text =
                    stopTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (targetBox != null)
                targetBox.Text =
                    targetTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (maxTradesBox != null)
                maxTradesBox.Text =
                    maxTrades.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyTargetBox != null)
                dailyTargetBox.Text =
                    dailyTarget.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyLossBox != null)
                dailyLossBox.Text =
                    dailyLoss.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dollarRiskCapBox != null)
                dollarRiskCapBox.Text =
                    Math.Max(
                        1.0,
                        dollarRiskCap
                    ).ToString(
                        CultureInfo.InvariantCulture
                    );

            AppendVisualLog(
                "REMOTE CONFIG APPLIED | "
                + selectedAccount.Name
                + " | "
                + selectedInstrument.FullName
                + " | "
                + normalizedStrategy
                + " | "
                + normalizedDirection
                + " | Qty "
                + contracts
                + " | SL "
                + stopTicks
                + " | TP "
                + targetTicks
                + " | RiskCap $"
                + Math.Max(
                    1.0,
                    dollarRiskCap
                  ).ToString("0.00")
            );

            return true;
        }

        private void ExecutePlatformCommand(
            string commandId,
            string commandType,
            string commandAccount,
            string commandInstrument,
            string commandQuery,
            string commandStrategy,
            string commandDirection,
            int commandContracts,
            int commandStopTicks,
            int commandTargetTicks,
            int commandMaxTrades,
            double commandDailyTarget,
            double commandDailyLoss,
            double commandDollarRiskCap)
        {
            if (
                string.IsNullOrWhiteSpace(
                    commandId
                ) ||
                string.Equals(
                    commandId,
                    lastProcessedPlatformCommandId,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return;
            }

            lastProcessedPlatformCommandId =
                commandId;

            if (
                string.Equals(
                    commandType,
                    "SEARCH_INSTRUMENTS",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                string[] searchResults =
                    SearchNinjaInstruments(
                        commandQuery
                    );

                PostPlatformInstrumentSearchResult(
                    commandId,
                    commandQuery,
                    searchResults
                );

                return;
            }

            bool commandNeedsPlatformContext =
                string.Equals(
                    commandType,
                    "START_BOT",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_LONG",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_SHORT",
                    StringComparison.OrdinalIgnoreCase
                );

            if (commandNeedsPlatformContext)
            {
                if (
                    !ApplyPlatformStartConfiguration(
                        commandAccount,
                        commandInstrument,
                        commandStrategy,
                        commandDirection,
                        commandContracts,
                        commandStopTicks,
                        commandTargetTicks,
                        commandMaxTrades,
                        commandDailyTarget,
                        commandDailyLoss,
                        commandDollarRiskCap
                    )
                )
                {
                    return;
                }
            }

            string selectedAccountName =
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty;

            string selectedInstrumentName =
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty;

            // STOP_BOT and CLOSE_ALL must not depend on what the
            // visible NinjaTrader selectors currently show.
            // CLOSE_ALL resolves the exact Account + Instrument sent
            // by the platform immediately before execution.
            if (
                !string.Equals(
                    commandType,
                    "STOP_BOT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                !string.Equals(
                    commandType,
                    "CLOSE_ALL",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                if (
                    string.IsNullOrWhiteSpace(
                        selectedAccountName
                    ) ||
                    string.IsNullOrWhiteSpace(
                        selectedInstrumentName
                    ) ||
                    !string.Equals(
                        selectedAccountName,
                        commandAccount,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    !string.Equals(
                        selectedInstrumentName,
                        commandInstrument,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    AppendVisualLog(
                        "REMOTE COMMAND REJECTED | "
                        + commandType
                        + " | Target "
                        + commandAccount
                        + " / "
                        + commandInstrument
                        + " does not match selected "
                        + selectedAccountName
                        + " / "
                        + selectedInstrumentName
                    );

                    return;
                }
            }

            AppendVisualLog(
                "REMOTE COMMAND RECEIVED | "
                + platformProfileId
                + " | "
                + commandType
            );

            try
            {
                switch (commandType)
                {
                    case "START_BOT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            StartBotClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "STOP_BOT":
                        StopBotClicked(
                            null,
                            null
                        );
                        break;

                    case "CLOSE_ALL":
                    {
                        Account closeAccount =
                            ResolveAccountByName(
                                commandAccount
                            );

                        Instrument closeInstrument =
                            ResolveInstrumentByName(
                                commandInstrument
                            );

                        if (
                            closeAccount == null ||
                            closeInstrument == null
                        )
                        {
                            AppendVisualLog(
                                "REMOTE CLOSE ALL REJECTED"
                                + " | Target "
                                + commandAccount
                                + " / "
                                + commandInstrument
                                + " could not be resolved."
                            );

                            break;
                        }

                        AppendVisualLog(
                            "REMOTE CLOSE ALL TARGET RESOLVED"
                            + " | "
                            + closeAccount.Name
                            + " / "
                            + closeInstrument.FullName
                        );

                        CloseAllForContext(
                            closeAccount,
                            closeInstrument,
                            "PLATFORM"
                        );

                        break;
                    }

                    case "TEST_LONG":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestLongClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "TEST_SHORT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestShortClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    default:
                        AppendVisualLog(
                            "REMOTE COMMAND IGNORED | "
                            + commandType
                        );
                        return;
                }

                PublishSharedState();
                PublishPlatformTelemetry();
            }
            catch (Exception ex)
            {
                AppendVisualLog(
                    "REMOTE COMMAND FAILED | "
                    + commandType
                    + " | "
                    + ex.Message
                );
            }
        }

        // =====================================================
        // LEARNING ENGINE HELPERS
        // =====================================================
        // =====================================================
        // V1.6.2 - LEARNING EVENT ID / OWNER
        // =====================================================
        private int GetProfileLearningPriority(
            string profileId)
        {
            if (
                string.IsNullOrWhiteSpace(profileId)
            )
            {
                return int.MaxValue;
            }

            Match match =
                Regex.Match(
                    profileId,
                    @"(\d+)$"
                );

            int value;

            if (
                match.Success &&
                int.TryParse(
                    match.Groups[1].Value,
                    out value
                )
            )
            {
                return value;
            }

            return int.MaxValue;
        }

        private string BuildSharedLearningEventKey(
            string side,
            DateTime signalTimeNy,
            string structure)
        {
            string instrumentKey =
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : "UNKNOWN";

            DateTime eventTime =
                signalTimeNy != DateTime.MinValue
                    ? signalTimeNy
                    : GetCurrentNewYorkTime();

            // One-second resolution is intentional:
            // simultaneous multi-profile fills share one event while separate
            // signals a few seconds later remain independent observations.
            string timeKey =
                new DateTime(
                    eventTime.Year,
                    eventTime.Month,
                    eventTime.Day,
                    eventTime.Hour,
                    eventTime.Minute,
                    eventTime.Second
                ).ToString(
                    "yyyyMMdd-HHmmss",
                    CultureInfo.InvariantCulture
                );

            return
                instrumentKey
                + "|"
                + (
                    string.IsNullOrWhiteSpace(side)
                        ? "UNKNOWN"
                        : side.Trim().ToUpperInvariant()
                  )
                + "|"
                + (
                    string.IsNullOrWhiteSpace(structure)
                        ? "UNKNOWN"
                        : structure.Trim().ToUpperInvariant()
                  )
                + "|"
                + timeKey;
        }

        private void ClaimSharedLearningEvent(
            string eventKey)
        {
            if (
                string.IsNullOrWhiteSpace(eventKey)
            )
            {
                return;
            }

            string contender =
                string.IsNullOrWhiteSpace(platformProfileId)
                    ? "profile-999"
                    : platformProfileId;

            string currentOwner;

            if (
                !SharedLearningEventOwners.TryGetValue(
                    eventKey,
                    out currentOwner
                ) ||
                string.IsNullOrWhiteSpace(currentOwner)
            )
            {
                SharedLearningEventOwners[eventKey] =
                    contender;

                return;
            }

            int contenderPriority =
                GetProfileLearningPriority(
                    contender
                );

            int ownerPriority =
                GetProfileLearningPriority(
                    currentOwner
                );

            if (
                contenderPriority <
                    ownerPriority
            )
            {
                SharedLearningEventOwners[eventKey] =
                    contender;
            }
        }

        private bool IsSharedLearningEventOwner(
            string eventKey)
        {
            if (
                string.IsNullOrWhiteSpace(eventKey)
            )
            {
                return true;
            }

            string owner;

            if (
                !SharedLearningEventOwners.TryGetValue(
                    eventKey,
                    out owner
                ) ||
                string.IsNullOrWhiteSpace(owner)
            )
            {
                return true;
            }

            return string.Equals(
                owner,
                platformProfileId,
                StringComparison.OrdinalIgnoreCase
            );
        }

        private void CaptureLearningSignalContext(
            string side,
            DateTime signalTimeNy,
            string structure)
        {
            pendingLearningSide =
                side ?? string.Empty;

            pendingLearningSession =
                GetBotSessionWindow(
                    signalTimeNy
                );

            pendingLearningStructure =
                structure ?? "UNKNOWN";

            pendingLearningSignalTimeNy =
                signalTimeNy;
        }

        private string GetLearningPatternKey(
            string side,
            DateTime nyTime,
            string structure)
        {
            // nyTime is intentionally retained in the signature for
            // compatibility with existing callers, but AM/PM no longer
            // fragments the learning bucket.
            return
                (
                    string.IsNullOrWhiteSpace(
                        side
                    )
                        ? "UNKNOWN"
                        : side
                )
                + "|"
                + (
                    string.IsNullOrWhiteSpace(
                        structure
                    )
                        ? "UNKNOWN"
                        : structure
                );
        }

        private JJBotLearningPattern FindLearningPattern(
            string key)
        {
            if (
                learningMemory == null
            )
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            if (
                learningMemory.Patterns == null
            )
            {
                learningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern != null &&
                    string.Equals(
                        pattern.Key,
                        key,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return pattern;
                }
            }

            return null;
        }

        private JJBotLearningPattern FindUserLearningPattern(
            string key)
        {
            if (userLearningMemory == null)
            {
                userLearningMemory =
                    new JJBotLearningMemory();
            }

            if (userLearningMemory.Patterns == null)
            {
                userLearningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            foreach (
                JJBotLearningPattern pattern
                in userLearningMemory.Patterns
            )
            {
                if (
                    pattern != null &&
                    string.Equals(
                        pattern.Key,
                        key,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return pattern;
                }
            }

            return null;
        }

        private double GetLearningRecencyDecay(
            DateTime asOfUtc,
            DateTime nowUtc)
        {
            if (asOfUtc == DateTime.MinValue || nowUtc <= asOfUtc)
            {
                return 1.0;
            }

            double ageDays =
                (nowUtc - asOfUtc).TotalDays;

            if (ageDays <= 0)
            {
                return 1.0;
            }

            return Math.Pow(
                0.5,
                ageDays / LearningRecencyHalfLifeDays
            );
        }

        private void AddRecentLearningEvidence(
            JJBotLearningPattern target,
            JJBotLearningPattern source,
            DateTime nowUtc)
        {
            if (target == null || source == null)
            {
                return;
            }

            double decay =
                GetLearningRecencyDecay(
                    source.RecentAsOfUtc,
                    nowUtc
                );

            target.RecentWeight +=
                source.RecentWeight * decay;

            target.RecentWins +=
                source.RecentWins * decay;

            target.RecentNetPnL +=
                source.RecentNetPnL * decay;

            target.RecentTotalMfe +=
                source.RecentTotalMfe * decay;

            target.RecentTotalMae +=
                source.RecentTotalMae * decay;

            target.RecentAsOfUtc =
                nowUtc;
        }

        private void UpdateRecentLearningEvidence(
            JJBotLearningPattern pattern,
            double netTradePnL,
            double mfe,
            double mae)
        {
            if (pattern == null)
            {
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;
            double decay =
                GetLearningRecencyDecay(
                    pattern.RecentAsOfUtc,
                    nowUtc
                );

            pattern.RecentWeight *= decay;
            pattern.RecentWins *= decay;
            pattern.RecentNetPnL *= decay;
            pattern.RecentTotalMfe *= decay;
            pattern.RecentTotalMae *= decay;

            pattern.RecentWeight += 1.0;
            if (netTradePnL > 0.01)
            {
                pattern.RecentWins += 1.0;
            }

            pattern.RecentNetPnL += netTradePnL;
            pattern.RecentTotalMfe += mfe;
            pattern.RecentTotalMae += mae;
            pattern.RecentAsOfUtc = nowUtc;
        }

        private double CalculateLearningConfidenceScore(
            JJBotLearningPattern pattern,
            double expectancy,
            double smoothedWinRate,
            double recentExpectancy,
            bool hasRecentEvidence)
        {
            if (pattern == null || pattern.Trades <= 0)
            {
                return 50.0;
            }

            double sampleConfidence =
                Math.Min(
                    1.0,
                    pattern.Trades / (double)LearningStrongTrades
                );

            double expectancyScore =
                Math.Max(
                    0.0,
                    Math.Min(
                        100.0,
                        50.0 + expectancy * 2.5
                    )
                );

            double winScore =
                Math.Max(
                    0.0,
                    Math.Min(100.0, smoothedWinRate)
                );

            double recentScore =
                hasRecentEvidence
                    ? Math.Max(
                        0.0,
                        Math.Min(
                            100.0,
                            50.0 + recentExpectancy * 2.5
                        )
                      )
                    : 50.0;

            double evidenceScore =
                expectancyScore * 0.40
                + winScore * 0.25
                + recentScore * 0.35;

            // With a small sample, shrink the final confidence toward neutral.
            return
                50.0
                + (evidenceScore - 50.0)
                    * sampleConfidence;
        }

        private JJBotLearningPattern BuildSpecificLearningAggregate(
            string side,
            string structure)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE_SPECIFIC";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                "*";

            aggregate.Structure =
                string.IsNullOrWhiteSpace(
                    structure
                )
                    ? "UNKNOWN"
                    : structure;

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                if (
                    !string.Equals(
                        pattern.Side ?? string.Empty,
                        side ?? string.Empty,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.Equals(
                        string.IsNullOrWhiteSpace(
                            pattern.Structure
                        )
                            ? "UNKNOWN"
                            : pattern.Structure,
                        string.IsNullOrWhiteSpace(
                            structure
                        )
                            ? "UNKNOWN"
                            : structure,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;

                AddRecentLearningEvidence(
                    aggregate,
                    pattern,
                    DateTime.UtcNow
                );
            }

            return aggregate;
        }

        private JJBotLearningPattern BuildLearningAggregate(
            string side,
            string sessionWindow)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                sessionWindow ?? string.Empty;

            aggregate.Structure =
                "*";

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        side
                    ) &&
                    !string.Equals(
                        pattern.Side,
                        side,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        sessionWindow
                    ) &&
                    !string.Equals(
                        pattern.SessionWindow,
                        sessionWindow,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;

                AddRecentLearningEvidence(
                    aggregate,
                    pattern,
                    DateTime.UtcNow
                );
            }

            return aggregate;
        }

        private bool EvaluateLearningEvidence(
            JJBotLearningPattern pattern,
            string level,
            out bool hasEvidence,
            out bool allowed,
            out string reason)
        {
            hasEvidence = false;
            allowed = true;
            reason = level + " NO DATA";

            int trades =
                pattern != null
                    ? pattern.Trades
                    : 0;

            if (pattern == null || trades < LearningObserveTrades)
            {
                reason =
                    level
                    + " OBSERVE"
                    + " | Sample: "
                    + trades
                    + "/"
                    + LearningObserveTrades
                    + " | Decision: ALLOW";

                return true;
            }

            hasEvidence = true;

            double expectancy =
                trades > 0
                    ? pattern.NetPnL / trades
                    : 0;

            double rawWinRate =
                trades > 0
                    ? ((double)pattern.Wins / trades) * 100.0
                    : 0;

            double smoothedWinRate =
                (
                    pattern.Wins
                    + LearningBayesianPriorWinRate
                        * LearningBayesianPriorStrength
                )
                /
                (trades + LearningBayesianPriorStrength)
                * 100.0;

            double avgMfe =
                trades > 0
                    ? pattern.TotalMfe / trades
                    : 0;

            double avgMae =
                trades > 0
                    ? pattern.TotalMae / trades
                    : 0;

            DateTime nowUtc = DateTime.UtcNow;
            double recentDecay =
                GetLearningRecencyDecay(
                    pattern.RecentAsOfUtc,
                    nowUtc
                );

            double recentWeight =
                pattern.RecentWeight * recentDecay;

            double recentNetPnL =
                pattern.RecentNetPnL * recentDecay;

            double recentWins =
                pattern.RecentWins * recentDecay;

            bool hasRecentEvidence =
                recentWeight >= LearningRecentMinWeight;

            double recentExpectancy =
                recentWeight > 0.001
                    ? recentNetPnL / recentWeight
                    : expectancy;

            double recentWinRate =
                recentWeight > 0.001
                    ? (recentWins / recentWeight) * 100.0
                    : rawWinRate;

            double confidenceScore =
                CalculateLearningConfidenceScore(
                    pattern,
                    expectancy,
                    smoothedWinRate,
                    recentExpectancy,
                    hasRecentEvidence
                );

            bool severeLifetimeNegative =
                expectancy <= LearningSevereExpectancy &&
                pattern.NetPnL <= LearningSevereNetPnL;

            bool moderateLifetimeNegative =
                expectancy <= LearningModerateExpectancy &&
                pattern.NetPnL <= LearningModerateNetPnL;

            bool lowWinNegative =
                smoothedWinRate < LearningMinWinRate &&
                expectancy < 0;

            bool recentNegative =
                hasRecentEvidence &&
                recentExpectancy < 0;

            bool recentSevereNegative =
                hasRecentEvidence &&
                recentExpectancy <= LearningSevereExpectancy;

            bool hardBlock = false;
            string decision = "ALLOW";

            if (trades >= LearningStrongTrades)
            {
                hardBlock =
                    (moderateLifetimeNegative &&
                        (!hasRecentEvidence || recentNegative)) ||
                    (lowWinNegative &&
                        (!hasRecentEvidence || recentNegative));
            }
            else if (trades >= LearningCautionTrades)
            {
                // 30-49 trades: only a clearly bad edge may hard-block.
                hardBlock =
                    severeLifetimeNegative &&
                    (!hasRecentEvidence || recentSevereNegative);
            }

            if (hardBlock)
            {
                allowed = false;
                decision = "BLOCK";
            }
            else
            {
                allowed = true;

                bool caution =
                    trades >= LearningCautionTrades &&
                    (
                        moderateLifetimeNegative ||
                        lowWinNegative ||
                        recentNegative ||
                        confidenceScore < 40.0
                    );

                decision =
                    caution
                        ? "CAUTION"
                        : "ALLOW";
            }

            string evidenceTier =
                trades >= LearningStrongTrades
                    ? "STRONG"
                    : trades >= LearningCautionTrades
                        ? "MEDIUM"
                        : "EARLY";

            reason =
                level
                + " "
                + evidenceTier
                + " | Trades: "
                + trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | RawWR: "
                + rawWinRate.ToString("0.0")
                + "%"
                + " | BayesianWR: "
                + smoothedWinRate.ToString("0.0")
                + "%"
                + " | Exp: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | RecentWeight: "
                + recentWeight.ToString("0.0")
                + " | RecentExp: "
                + recentExpectancy.ToString("$0.00")
                + "/trade"
                + " | RecentWR: "
                + recentWinRate.ToString("0.0")
                + "%"
                + " | AvgMFE: "
                + avgMfe.ToString("$0.00")
                + " | AvgMAE: "
                + avgMae.ToString("$0.00")
                + " | Confidence: "
                + confidenceScore.ToString("0")
                + "%"
                + " | Decision: "
                + decision;

            return true;
        }

        private bool IsLearningTradeAllowed(
            string side,
            DateTime nyTime,
            string structure,
            out string reason)
        {
            lock (SharedLearningSyncRoot)
            {
                reason =
                    "NO HISTORY - ALLOWED";

                if (selectedInstrument == null)
                {
                    return true;
                }

                if (learningMemory == null)
                {
                    LoadLearningMemory();
                }

                string normalizedSide =
                    string.IsNullOrWhiteSpace(
                        side
                    )
                        ? "UNKNOWN"
                        : side;

                string normalizedStructure =
                    string.IsNullOrWhiteSpace(
                        structure
                    )
                        ? "UNKNOWN"
                        : structure;

                // =====================================================
                // V1.6.5 - SPECIFIC-FIRST LEARNING
                // =====================================================
                // Only the exact Side + Setup bucket may hard-block an entry.
                // SIDE/GLOBAL remain advisory while the exact setup is still
                // gathering its own minimum sample. This prevents unrelated
                // Opening/Structure history from shutting down a fresh
                // Momentum setup prematurely.
                JJBotLearningPattern specific =
                    BuildSpecificLearningAggregate(
                        normalizedSide,
                        normalizedStructure
                    );

                bool specificHasEvidence;
                bool specificAllowed;
                string specificReason;

                EvaluateLearningEvidence(
                    specific,
                    "SPECIFIC",
                    out specificHasEvidence,
                    out specificAllowed,
                    out specificReason
                );

                if (specificHasEvidence)
                {
                    reason =
                        specificReason;

                    return specificAllowed;
                }

                JJBotLearningPattern sideAggregate =
                    BuildLearningAggregate(
                        normalizedSide,
                        string.Empty
                    );

                JJBotLearningPattern globalAggregate =
                    BuildLearningAggregate(
                        string.Empty,
                        string.Empty
                    );

                bool sideHasEvidence;
                bool sideAllowed;
                string sideReason;

                EvaluateLearningEvidence(
                    sideAggregate,
                    "SIDE",
                    out sideHasEvidence,
                    out sideAllowed,
                    out sideReason
                );

                bool globalHasEvidence;
                bool globalAllowed;
                string globalReason;

                EvaluateLearningEvidence(
                    globalAggregate,
                    "GLOBAL",
                    out globalHasEvidence,
                    out globalAllowed,
                    out globalReason
                );

                reason =
                    "SPECIFIC SAMPLE "
                    + specific.Trades
                    + "/"
                    + LearningObserveTrades
                    + " - OBSERVING / ALLOWED"
                    + " | SIDE advisory: "
                    + (
                        sideHasEvidence
                            ? (
                                sideAllowed
                                    ? "ALLOWED"
                                    : "NEGATIVE"
                              )
                            : "INSUFFICIENT"
                      )
                    + " | GLOBAL advisory: "
                    + (
                        globalHasEvidence
                            ? (
                                globalAllowed
                                    ? "ALLOWED"
                                    : "NEGATIVE"
                              )
                            : "INSUFFICIENT"
                      );

                return true;
            }
        }

        private void RecordLearningTradeResult(
            double netTradePnL)
        {
            lock (SharedLearningSyncRoot)
            {

            if (
                activeLearningTrade == null
            )
            {
                return;
            }

            if (
                !IsSharedLearningEventOwner(
                    activeLearningEventKey
                )
            )
            {
                string owner =
                    string.Empty;

                SharedLearningEventOwners.TryGetValue(
                    activeLearningEventKey,
                    out owner
                );

                PrintBotMessage(
                    "LEARNING DUPLICATE SKIPPED"
                    + " | "
                    + platformProfileId
                    + " | Owner: "
                    + (
                        string.IsNullOrWhiteSpace(owner)
                            ? "UNKNOWN"
                            : owner
                      )
                    + " | Event: "
                    + activeLearningEventKey
                    + " | TradeNet: "
                    + netTradePnL.ToString("$0.00")
                );

                activeLearningTrade =
                    null;

                activeLearningEventKey =
                    string.Empty;

                pendingLearningSide =
                    string.Empty;

                pendingLearningSession =
                    string.Empty;

                pendingLearningStructure =
                    string.Empty;

                pendingLearningSignalTimeNy =
                    DateTime.MinValue;

                return;
            }

            if (
                userLearningMemory == null
            )
            {
                userLearningMemory =
                    new JJBotLearningMemory();
            }

            DateTime signalNy =
                activeLearningTrade.SignalTimeNy !=
                    DateTime.MinValue
                    ? activeLearningTrade.SignalTimeNy
                    : GetCurrentNewYorkTime();

            string key =
                GetLearningPatternKey(
                    activeLearningTrade.Side,
                    signalNy,
                    activeLearningTrade.Structure
                );

            JJBotLearningPattern pattern =
                FindUserLearningPattern(
                    key
                );

            if (pattern == null)
            {
                pattern =
                    new JJBotLearningPattern();

                pattern.Key =
                    key;

                pattern.Side =
                    activeLearningTrade.Side;

                // Session remains on the live trade as metadata,
                // but the stored V3 bucket intentionally spans AM + PM.
                pattern.SessionWindow =
                    "ALL";

                pattern.Structure =
                    activeLearningTrade.Structure;

                userLearningMemory.Patterns.Add(
                    pattern
                );
            }

            pattern.Trades++;

            const double LearningPnLEpsilon = 0.01;

            if (netTradePnL > LearningPnLEpsilon)
                pattern.Wins++;
            else if (netTradePnL < -LearningPnLEpsilon)
                pattern.Losses++;
            else
                pattern.Breakevens++;

            pattern.NetPnL +=
                netTradePnL;

            // V1.6.16 - confidence calibration.
            // This is recorded only for real automatic learning trades;
            // manual test trades never create activeLearningTrade.
            if (
                activeLearningTrade.TechnicalConfidence > 0
            )
            {
                pattern.ConfidenceTrades++;

                if (netTradePnL > LearningPnLEpsilon)
                {
                    pattern.ConfidenceWins++;
                }

                pattern.TechnicalConfidenceSum +=
                    activeLearningTrade.TechnicalConfidence;

                pattern.ConfidenceNetPnL +=
                    netTradePnL;
            }

            pattern.TotalMfe +=
                activeLearningTrade.Mfe;

            pattern.TotalMae +=
                activeLearningTrade.Mae;

            UpdateRecentLearningEvidence(
                pattern,
                netTradePnL,
                activeLearningTrade.Mfe,
                activeLearningTrade.Mae
            );

            // A price-BE can still have a small negative net result once
            // commissions are present, so detect BE from gross price PnL.
            bool priceBreakevenExit =
                Math.Abs(
                    activeExitGrossPnL
                ) <= 0.01;

            if (
                priceBreakevenExit &&
                activeTargetPrice > 0 &&
                entryFillPrice > 0
            )
            {
                ArmBreakevenFollowThrough(
                    pattern.Key,
                    activeLearningEventKey,
                    activeLearningTrade.Side,
                    entryFillPrice,
                    activeTargetPrice
                );
            }

            SaveLearningMemory();

            // Log/report the effective Base + User statistics, not only
            // the local delta that was just updated.
            JJBotLearningPattern effectivePattern =
                FindLearningPattern(key);

            if (effectivePattern != null)
            {
                pattern = effectivePattern;
            }

            double winRate =
                pattern.Trades > 0
                    ? (
                        (double)pattern.Wins
                        / pattern.Trades
                    )
                    * 100.0
                    : 0;

            double expectancy =
                pattern.Trades > 0
                    ? pattern.NetPnL
                        / pattern.Trades
                    : 0;

            double averageMfe =
                pattern.Trades > 0
                    ? pattern.TotalMfe
                        / pattern.Trades
                    : 0;

            double averageMae =
                pattern.Trades > 0
                    ? pattern.TotalMae
                        / pattern.Trades
                    : 0;

            JJBotLearningPattern specificAggregate =
                BuildSpecificLearningAggregate(
                    pattern.Side,
                    pattern.Structure
                );

            JJBotLearningPattern sideAggregate =
                BuildLearningAggregate(
                    pattern.Side,
                    string.Empty
                );

            JJBotLearningPattern globalAggregate =
                BuildLearningAggregate(
                    string.Empty,
                    string.Empty
                );

            PrintBotMessage(
                "LEARNING UPDATED"
                + " | "
                + platformProfileId
                + " | "
                + key
                + " | Trades: "
                + pattern.Trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | WinRate: "
                + winRate.ToString("0.0")
                + "%"
                + " | TradeNet: "
                + netTradePnL.ToString("$0.00")
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | Expectancy: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | AvgMFE: "
                + averageMfe.ToString("$0.00")
                + " | AvgMAE: "
                + averageMae.ToString("$0.00")
                + " | BE->TP: "
                + pattern.BeFollowThroughTargetHits
                + "/"
                + pattern.BeFollowThroughResolved
                + (
                    pattern.BeFollowThroughResolved > 0
                        ? " ("
                            + (
                                (
                                    (double)pattern.BeFollowThroughTargetHits /
                                    pattern.BeFollowThroughResolved
                                ) * 100.0
                              ).ToString("0.0")
                            + "%)"
                        : string.Empty
                  )
                + " | HIERARCHY SPECIFIC: "
                + specificAggregate.Trades
                + " | SIDE: "
                + sideAggregate.Trades
                + " | GLOBAL: "
                + globalAggregate.Trades
            );

            activeLearningTrade = null;
            activeLearningEventKey = string.Empty;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;
        
            }
        }

        private void ArmBreakevenFollowThrough(
            string patternKey,
            string eventKey,
            string side,
            double entryPrice,
            double originalTargetPrice)
        {
            if (
                string.IsNullOrWhiteSpace(patternKey) ||
                string.IsNullOrWhiteSpace(side) ||
                entryPrice <= 0 ||
                originalTargetPrice <= 0
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            JJBotBreakevenFollowThrough tracker =
                new JJBotBreakevenFollowThrough();

            tracker.PatternKey =
                patternKey;

            tracker.EventKey =
                eventKey ?? string.Empty;

            tracker.Side =
                side.Trim().ToUpperInvariant();

            tracker.EntryPrice =
                entryPrice;

            tracker.OriginalTargetPrice =
                originalTargetPrice;

            tracker.ExitTimeNy =
                nowNy;

            tracker.ExpiresTimeNy =
                nowNy.AddMinutes(
                    BeFollowThroughWindowMinutes
                );

            lock (beFollowThroughLock)
            {
                // Do not arm the same Learning event twice in this profile.
                bool alreadyExists =
                    beFollowThroughTrackers.Any(
                        item =>
                            item != null &&
                            !string.IsNullOrWhiteSpace(
                                tracker.EventKey
                            ) &&
                            string.Equals(
                                item.EventKey,
                                tracker.EventKey,
                                StringComparison.OrdinalIgnoreCase
                            )
                    );

                if (alreadyExists)
                {
                    return;
                }

                beFollowThroughTrackers.Add(
                    tracker
                );
            }

            PrintBotMessage(
                "BE FOLLOW-THROUGH ARMED"
                + " | "
                + tracker.PatternKey
                + " | Side: "
                + tracker.Side
                + " | Entry: "
                + tracker.EntryPrice.ToString("0.00")
                + " | OriginalTP: "
                + tracker.OriginalTargetPrice.ToString("0.00")
                + " | Window: "
                + BeFollowThroughWindowMinutes
                + "m"
            );
        }

        private void ResolveBreakevenFollowThrough(
            JJBotBreakevenFollowThrough tracker,
            bool targetHit,
            DateTime resolvedNy)
        {
            if (
                tracker == null ||
                string.IsNullOrWhiteSpace(
                    tracker.PatternKey
                )
            )
            {
                return;
            }

            int resolvedCount = 0;
            int hitCount = 0;
            double hitRate = 0;

            lock (SharedLearningSyncRoot)
            {
                JJBotLearningPattern pattern =
                    FindUserLearningPattern(
                        tracker.PatternKey
                    );

                if (pattern != null)
                {
                    pattern.BeFollowThroughResolved++;

                    if (targetHit)
                    {
                        pattern.BeFollowThroughTargetHits++;
                    }

                    SaveLearningMemory();

                    JJBotLearningPattern effectivePattern =
                        FindLearningPattern(
                            tracker.PatternKey
                        );

                    JJBotLearningPattern reportPattern =
                        effectivePattern ?? pattern;

                    resolvedCount =
                        reportPattern.BeFollowThroughResolved;

                    hitCount =
                        reportPattern.BeFollowThroughTargetHits;

                    hitRate =
                        resolvedCount > 0
                            ? (
                                (double)hitCount /
                                resolvedCount
                              ) * 100.0
                            : 0;
                }
            }

            double minutesAfterExit =
                Math.Max(
                    0,
                    (
                        resolvedNy -
                        tracker.ExitTimeNy
                    ).TotalMinutes
                );

            PrintBotMessage(
                targetHit
                    ? "BE FOLLOW-THROUGH TARGET HIT"
                    : "BE FOLLOW-THROUGH EXPIRED"
                + " | "
                + tracker.PatternKey
                + " | Side: "
                + tracker.Side
                + " | OriginalTP: "
                + tracker.OriginalTargetPrice.ToString("0.00")
                + " | After: "
                + minutesAfterExit.ToString("0.0")
                + "m"
                + " | Resolved: "
                + resolvedCount
                + " | TP Hits: "
                + hitCount
                + " | HitRate: "
                + hitRate.ToString("0.0")
                + "%"
            );
        }

        private void UpdateBreakevenFollowThrough(
            double liveHigh,
            double liveLow,
            DateTime marketNy)
        {
            if (
                liveHigh <= 0 ||
                liveLow <= 0 ||
                marketNy == DateTime.MinValue
            )
            {
                return;
            }

            List<JJBotBreakevenFollowThrough> resolved =
                new List<JJBotBreakevenFollowThrough>();

            List<bool> results =
                new List<bool>();

            lock (beFollowThroughLock)
            {
                for (
                    int i =
                        beFollowThroughTrackers.Count - 1;
                    i >= 0;
                    i--
                )
                {
                    JJBotBreakevenFollowThrough tracker =
                        beFollowThroughTrackers[i];

                    if (tracker == null)
                    {
                        beFollowThroughTrackers.RemoveAt(i);
                        continue;
                    }

                    bool targetHit =
                        string.Equals(
                            tracker.Side,
                            "LONG",
                            StringComparison.OrdinalIgnoreCase
                        )
                            ? liveHigh >=
                                tracker.OriginalTargetPrice
                            : liveLow <=
                                tracker.OriginalTargetPrice;

                    bool expired =
                        marketNy >=
                            tracker.ExpiresTimeNy ||
                        marketNy.Date !=
                            tracker.ExitTimeNy.Date ||
                        ToTimeInt(
                            marketNy
                        ) >=
                            ForceFlatTimeNy;

                    if (
                        !targetHit &&
                        !expired
                    )
                    {
                        continue;
                    }

                    resolved.Add(
                        tracker
                    );

                    results.Add(
                        targetHit
                    );

                    beFollowThroughTrackers.RemoveAt(i);
                }
            }

            for (
                int i = 0;
                i < resolved.Count;
                i++
            )
            {
                ResolveBreakevenFollowThrough(
                    resolved[i],
                    results[i],
                    marketNy
                );
            }
        }

        private string GetLearningFolderPath()
        {
            return Path.Combine(
                stateFolderPath,
                "Learning"
            );
        }

        private string GetLearningBaseFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Base"
            );
        }

        private string GetLearningUserFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "User"
            );
        }

        private string GetLearningEffectiveFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Effective"
            );
        }

        private string GetLearningArchiveFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Archive"
            );
        }

        private string GetLearningSafeInstrument()
        {
            if (selectedInstrument == null)
            {
                return string.Empty;
            }

            return MakeSafeFileName(
                selectedInstrument.FullName
            );
        }

        // Compatibility name used by the shared-memory store.
        // From V1.6.7 onward this points to the writable USER layer.
        private string GetLearningMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningUserFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLearningBaseMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningBaseFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLearningEffectiveMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningEffectiveFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLegacyLearningMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string ReadLearningBaseVersion()
        {
            try
            {
                string versionPath =
                    Path.Combine(
                        GetLearningBaseFolderPath(),
                        "version.txt"
                    );

                if (!File.Exists(versionPath))
                {
                    return "NONE";
                }

                string value =
                    File.ReadAllText(versionPath)
                        .Trim();

                return string.IsNullOrWhiteSpace(value)
                    ? "UNKNOWN"
                    : value;
            }
            catch
            {
                return "UNKNOWN";
            }
        }

        private JJBotLearningMemory LoadLearningMemoryFile(
            string path)
        {
            JJBotLearningMemory result =
                new JJBotLearningMemory();

            if (
                string.IsNullOrWhiteSpace(path) ||
                !File.Exists(path)
            )
            {
                return result;
            }

            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(JJBotLearningMemory)
                );

            using (
                FileStream stream =
                    new FileStream(
                        path,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read
                    )
            )
            {
                JJBotLearningMemory loaded =
                    serializer.Deserialize(stream)
                        as JJBotLearningMemory;

                if (loaded != null)
                {
                    result = loaded;
                }
            }

            if (result.Patterns == null)
            {
                result.Patterns =
                    new List<JJBotLearningPattern>();
            }

            return result;
        }

        private JJBotLearningPattern CloneLearningPattern(
            JJBotLearningPattern source)
        {
            if (source == null)
            {
                return null;
            }

            return new JJBotLearningPattern
            {
                Key = source.Key ?? string.Empty,
                Side = source.Side ?? string.Empty,
                SessionWindow = source.SessionWindow ?? string.Empty,
                Structure = source.Structure ?? string.Empty,
                Trades = source.Trades,
                Wins = source.Wins,
                Losses = source.Losses,
                Breakevens = source.Breakevens,
                NetPnL = source.NetPnL,
                TotalMfe = source.TotalMfe,
                TotalMae = source.TotalMae,
                BeFollowThroughResolved =
                    source.BeFollowThroughResolved,
                BeFollowThroughTargetHits =
                    source.BeFollowThroughTargetHits,
                RecentWeight = source.RecentWeight,
                RecentWins = source.RecentWins,
                RecentNetPnL = source.RecentNetPnL,
                RecentTotalMfe = source.RecentTotalMfe,
                RecentTotalMae = source.RecentTotalMae,
                RecentAsOfUtc = source.RecentAsOfUtc,
                ConfidenceTrades = source.ConfidenceTrades,
                ConfidenceWins = source.ConfidenceWins,
                TechnicalConfidenceSum =
                    source.TechnicalConfidenceSum,
                ConfidenceNetPnL =
                    source.ConfidenceNetPnL
            };
        }

        private void AddLearningPatternInto(
            Dictionary<string, JJBotLearningPattern> map,
            JJBotLearningPattern source)
        {
            if (
                map == null ||
                source == null
            )
            {
                return;
            }

            string key =
                string.IsNullOrWhiteSpace(source.Key)
                    ? (
                        (source.Side ?? "UNKNOWN")
                        + "|"
                        + (source.Structure ?? "UNKNOWN")
                      )
                    : source.Key;

            JJBotLearningPattern target;

            if (!map.TryGetValue(key, out target))
            {
                target =
                    CloneLearningPattern(source);

                target.Key = key;
                map[key] = target;
                return;
            }

            target.Trades += source.Trades;
            target.Wins += source.Wins;
            target.Losses += source.Losses;
            target.Breakevens += source.Breakevens;
            target.NetPnL += source.NetPnL;

            target.ConfidenceTrades +=
                source.ConfidenceTrades;

            target.ConfidenceWins +=
                source.ConfidenceWins;

            target.TechnicalConfidenceSum +=
                source.TechnicalConfidenceSum;

            target.ConfidenceNetPnL +=
                source.ConfidenceNetPnL;
            target.TotalMfe += source.TotalMfe;
            target.TotalMae += source.TotalMae;
            target.BeFollowThroughResolved +=
                source.BeFollowThroughResolved;
            target.BeFollowThroughTargetHits +=
                source.BeFollowThroughTargetHits;

            // Normalize both recency accumulators to the same clock before merge.
            DateTime mergeUtc = DateTime.UtcNow;
            double targetDecay =
                GetLearningRecencyDecay(
                    target.RecentAsOfUtc,
                    mergeUtc
                );

            target.RecentWeight *= targetDecay;
            target.RecentWins *= targetDecay;
            target.RecentNetPnL *= targetDecay;
            target.RecentTotalMfe *= targetDecay;
            target.RecentTotalMae *= targetDecay;
            target.RecentAsOfUtc = mergeUtc;

            AddRecentLearningEvidence(
                target,
                source,
                mergeUtc
            );
        }

        private JJBotLearningMemory MergeLearningMemories(
            JJBotLearningMemory baseMemory,
            JJBotLearningMemory userMemory)
        {
            Dictionary<string, JJBotLearningPattern> map =
                new Dictionary<string, JJBotLearningPattern>(
                    StringComparer.OrdinalIgnoreCase
                );

            if (
                baseMemory != null &&
                baseMemory.Patterns != null
            )
            {
                foreach (
                    JJBotLearningPattern pattern
                    in baseMemory.Patterns
                )
                {
                    AddLearningPatternInto(map, pattern);
                }
            }

            if (
                userMemory != null &&
                userMemory.Patterns != null
            )
            {
                foreach (
                    JJBotLearningPattern pattern
                    in userMemory.Patterns
                )
                {
                    AddLearningPatternInto(map, pattern);
                }
            }

            JJBotLearningMemory merged =
                new JJBotLearningMemory();

            merged.Patterns =
                map.Values
                    .OrderBy(p => p.Key)
                    .ToList();

            return merged;
        }

        private void RebuildEffectiveLearningMemoryInPlace()
        {
            JJBotLearningMemory merged =
                MergeLearningMemories(
                    baseLearningMemory,
                    userLearningMemory
                );

            if (learningMemory == null)
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            if (learningMemory.Patterns == null)
            {
                learningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            learningMemory.Patterns.Clear();

            foreach (
                JJBotLearningPattern pattern
                in merged.Patterns
            )
            {
                learningMemory.Patterns.Add(pattern);
            }
        }

        private void SerializeLearningMemory(
            string path,
            JJBotLearningMemory memory)
        {
            if (
                string.IsNullOrWhiteSpace(path) ||
                memory == null
            )
            {
                return;
            }

            Directory.CreateDirectory(
                Path.GetDirectoryName(path)
            );

            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(JJBotLearningMemory)
                );

            string tempPath =
                path + ".tmp";

            using (
                FileStream stream =
                    new FileStream(
                        tempPath,
                        FileMode.Create,
                        FileAccess.Write,
                        FileShare.None
                    )
            )
            {
                serializer.Serialize(
                    stream,
                    memory
                );
            }

            if (File.Exists(path))
            {
                File.Delete(path);
            }

            File.Move(tempPath, path);
        }

        private void MigrateLegacyLearningIfNeeded(
            string basePath,
            string userPath)
        {
            if (
                string.IsNullOrWhiteSpace(userPath) ||
                File.Exists(userPath)
            )
            {
                return;
            }

            string legacyPath =
                GetLegacyLearningMemoryFilePath();

            if (
                string.IsNullOrWhiteSpace(legacyPath) ||
                !File.Exists(legacyPath)
            )
            {
                return;
            }

            bool publisherPromotion =
                File.Exists(
                    Path.Combine(
                        GetLearningFolderPath(),
                        "publisher-base-promoted.flag"
                    )
                ) &&
                !string.IsNullOrWhiteSpace(basePath) &&
                File.Exists(basePath);

            Directory.CreateDirectory(
                GetLearningArchiveFolderPath()
            );

            string archivePath =
                Path.Combine(
                    GetLearningArchiveFolderPath(),
                    Path.GetFileNameWithoutExtension(legacyPath)
                    + "_legacy_"
                    + DateTime.UtcNow.ToString("yyyyMMddHHmmss")
                    + ".xml"
                );

            if (publisherPromotion)
            {
                File.Move(legacyPath, archivePath);

                PrintBotMessage(
                    "LEARNING LEGACY ARCHIVED - OFFICIAL BASE ALREADY CONTAINS IT"
                );

                return;
            }

            Directory.CreateDirectory(
                GetLearningUserFolderPath()
            );

            File.Copy(
                legacyPath,
                userPath,
                true
            );

            File.Move(
                legacyPath,
                archivePath
            );

            PrintBotMessage(
                "LEARNING MIGRATED"
                + " | Legacy -> User"
                + " | Instrument: "
                + (
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : "UNKNOWN"
                  )
            );
        }

        private int CountLearningTrades(
            JJBotLearningMemory memory)
        {
            if (
                memory == null ||
                memory.Patterns == null
            )
            {
                return 0;
            }

            int total = 0;

            foreach (
                JJBotLearningPattern pattern
                in memory.Patterns
            )
            {
                if (pattern != null)
                {
                    total += pattern.Trades;
                }
            }

            return total;
        }

        private void LoadLearningMemory()
        {
            try
            {
                string userPath =
                    GetLearningMemoryFilePath();

                string basePath =
                    GetLearningBaseMemoryFilePath();

                if (string.IsNullOrWhiteSpace(userPath))
                {
                    baseLearningMemory =
                        new JJBotLearningMemory();
                    userLearningMemory =
                        new JJBotLearningMemory();
                    learningMemory =
                        new JJBotLearningMemory();
                    learningBaseVersion = "NONE";
                    return;
                }

                lock (SharedLearningSyncRoot)
                {
                    Directory.CreateDirectory(
                        GetLearningFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningBaseFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningUserFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningEffectiveFolderPath()
                    );

                    MigrateLegacyLearningIfNeeded(
                        basePath,
                        userPath
                    );

                    JJBotLearningMemory sharedEffective;
                    JJBotLearningMemory sharedUser;

                    bool hasEffective =
                        SharedLearningMemories.TryGetValue(
                            userPath,
                            out sharedEffective
                        ) &&
                        sharedEffective != null;

                    bool hasUser =
                        SharedUserLearningMemories.TryGetValue(
                            userPath,
                            out sharedUser
                        ) &&
                        sharedUser != null;

                    if (hasEffective && hasUser)
                    {
                        learningMemory =
                            sharedEffective;
                        userLearningMemory =
                            sharedUser;

                        // Base is read-only and can be loaded per profile;
                        // it changes only while NinjaTrader is closed.
                        baseLearningMemory =
                            LoadLearningMemoryFile(basePath);

                        learningBaseVersion =
                            ReadLearningBaseVersion();

                        return;
                    }

                    baseLearningMemory =
                        LoadLearningMemoryFile(basePath);

                    userLearningMemory =
                        LoadLearningMemoryFile(userPath);

                    learningMemory =
                        new JJBotLearningMemory();

                    RebuildEffectiveLearningMemoryInPlace();

                    SharedLearningMemories[userPath] =
                        learningMemory;

                    SharedUserLearningMemories[userPath] =
                        userLearningMemory;

                    learningBaseVersion =
                        ReadLearningBaseVersion();

                    // Effective is a read-only export/snapshot used by the
                    // publisher promotion script and diagnostics.
                    SerializeLearningMemory(
                        GetLearningEffectiveMemoryFilePath(),
                        learningMemory
                    );
                }

                PrintBotMessage(
                    "TWO-LAYER LEARNING ATTACHED"
                    + " | "
                    + platformProfileId
                    + " | Instrument: "
                    + (
                        selectedInstrument != null
                            ? selectedInstrument.FullName
                            : "UNKNOWN"
                      )
                    + " | BaseVersion: "
                    + learningBaseVersion
                    + " | BaseTrades: "
                    + CountLearningTrades(baseLearningMemory)
                    + " | UserTrades: "
                    + CountLearningTrades(userLearningMemory)
                    + " | EffectiveTrades: "
                    + CountLearningTrades(learningMemory)
                );
            }
            catch (Exception ex)
            {
                lock (SharedLearningSyncRoot)
                {
                    baseLearningMemory =
                        new JJBotLearningMemory();
                    userLearningMemory =
                        new JJBotLearningMemory();
                    learningMemory =
                        new JJBotLearningMemory();
                    learningBaseVersion = "ERROR";

                    string path =
                        GetLearningMemoryFilePath();

                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        SharedLearningMemories[path] =
                            learningMemory;
                        SharedUserLearningMemories[path] =
                            userLearningMemory;
                    }
                }

                PrintBotMessage(
                    "LEARNING LOAD ERROR: "
                    + ex.Message
                );
            }
        }

        private void SaveLearningMemory()
        {
            try
            {
                if (
                    selectedInstrument == null ||
                    userLearningMemory == null
                )
                {
                    return;
                }

                lock (SharedLearningSyncRoot)
                {
                    string userPath =
                        GetLearningMemoryFilePath();

                    if (string.IsNullOrWhiteSpace(userPath))
                    {
                        return;
                    }

                    // ONLY the User layer is writable.
                    SerializeLearningMemory(
                        userPath,
                        userLearningMemory
                    );

                    RebuildEffectiveLearningMemoryInPlace();

                    SharedLearningMemories[userPath] =
                        learningMemory;

                    SharedUserLearningMemories[userPath] =
                        userLearningMemory;

                    // Read-only merged snapshot for export/debugging.
                    SerializeLearningMemory(
                        GetLearningEffectiveMemoryFilePath(),
                        learningMemory
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING SAVE ERROR: "
                    + ex.Message
                );
            }
        }

        private void LogLearningDecision(
            DateTime decisionNyTime,
            string trend,
            string vwapSide,
            string liquidity,
            string structure,
            string setup,
            int buyScore,
            int sellScore)
        {
            try
            {
                if (
                    selectedInstrument == null
                )
                {
                    return;
                }

                Directory.CreateDirectory(
                    GetLearningFolderPath()
                );

                string safeInstrument =
                    MakeSafeFileName(
                        selectedInstrument.FullName
                    );

                string filePath =
                    Path.Combine(
                        GetLearningFolderPath(),
                        "decisions_"
                            + decisionNyTime.ToString(
                                "yyyy-MM-dd"
                            )
                            + "_"
                            + safeInstrument
                            + ".csv"
                    );

                bool writeHeader =
                    !File.Exists(
                        filePath
                    );

                using (
                    StreamWriter writer =
                        new StreamWriter(
                            filePath,
                            true
                        )
                )
                {
                    if (writeHeader)
                    {
                        writer.WriteLine(
                            "TimeNY,Session,Trend,VWAP,Sweep,Structure,Setup,BuyScore,SellScore"
                        );
                    }

                    writer.WriteLine(
                        decisionNyTime.ToString(
                            "yyyy-MM-dd HH:mm:ss"
                        )
                        + ","
                        + GetBotSessionWindow(
                            decisionNyTime
                        )
                        + ","
                        + EscapeCsv(
                            trend
                        )
                        + ","
                        + EscapeCsv(
                            vwapSide
                        )
                        + ","
                        + EscapeCsv(
                            liquidity
                        )
                        + ","
                        + EscapeCsv(
                            structure
                        )
                        + ","
                        + EscapeCsv(
                            setup
                        )
                        + ","
                        + buyScore
                        + ","
                        + sellScore
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING DECISION LOG ERROR: "
                    + ex.Message
                );
            }
        }

        private string EscapeCsv(
            string value)
        {
            if (value == null)
                return string.Empty;

            string escaped =
                value.Replace(
                    "\"",
                    "\"\""
                );

            if (
                escaped.Contains(",") ||
                escaped.Contains("\"") ||
                escaped.Contains("\n") ||
                escaped.Contains("\r")
            )
            {
                return
                    "\""
                    + escaped
                    + "\"";
            }

            return escaped;
        }

        private void PrintBotMessage(
            string message)
        {
            NinjaTrader.Code.Output.Process(
                "J&J BOT | "
                + message,
                PrintTo.OutputTab1
            );

            AppendVisualLog(
                message
            );
        }

        // =====================================================
        // VISUAL LOG
        // Thread-safe: BarsRequest, OrderUpdate and ExecutionUpdate
        // can call this method from non-UI threads.
        // =====================================================
        private void AppendVisualLog(
            string message)
        {
            if (
                string.IsNullOrWhiteSpace(
                    message
                )
            )
            {
                return;
            }

            Action appendAction =
                new Action(() =>
                {
                    if (
                        visualLogLines == null
                    )
                    {
                        visualLogLines =
                            new Queue<string>();
                    }

                    string timeStamp;

                    try
                    {
                        DateTime nyTime =
                            GetCurrentNewYorkTime();

                        timeStamp =
                            nyTime.ToString(
                                "HH:mm:ss"
                            );
                    }
                    catch
                    {
                        timeStamp =
                            DateTime.Now.ToString(
                                "HH:mm:ss"
                            );
                    }

                    visualLogLines.Enqueue(
                        "["
                        + timeStamp
                        + "] "
                        + message
                    );

                    while (
                        visualLogLines.Count >
                            MaxVisualLogLines
                    )
                    {
                        visualLogLines.Dequeue();
                    }

                    if (
                        visualLogBox != null
                    )
                    {
                        visualLogBox.Text =
                            string.Join(
                                Environment.NewLine,
                                visualLogLines.ToArray()
                            );

                        visualLogBox.CaretIndex =
                            visualLogBox.Text.Length;

                        visualLogBox.ScrollToEnd();
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                appendAction();
            }
            else
            {
                Dispatcher.BeginInvoke(
                    appendAction
                );
            }
        }

        private void ClearVisualLogClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                visualLogLines != null
            )
            {
                visualLogLines.Clear();
            }

            if (
                visualLogBox != null
            )
            {
                visualLogBox.Clear();
            }

            AppendVisualLog(
                "Log cleared."
            );
        }

        // =====================================================
        // CARD
        // =====================================================
        private Border CreateCard()
        {
            Border card =
                new Border();

            card.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        20,
                        27,
                        37
                    )
                );

            card.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            card.BorderThickness =
                new Thickness(1);

            card.CornerRadius =
                new CornerRadius(8);

            card.Padding =
                new Thickness(15);

            card.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    12
                );

            return card;
        }

        // =====================================================
        // SECTION TITLE
        // =====================================================
        private TextBlock CreateSectionTitle(
            string text)
        {
            TextBlock block =
                new TextBlock();

            block.Text = text;

            block.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            block.FontWeight =
                FontWeights.Bold;

            block.FontSize = 12;

            return block;
        }

        // =====================================================
        // SMALL STATUS TEXT
        // =====================================================
        private TextBlock CreateSmallStatusText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.Gray;

            block.FontSize = 10;

            block.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    0
                );

            return block;
        }

        // =====================================================
        // TEXTBOX
        // =====================================================
        private TextBox CreateTextBox(
            string value)
        {
            TextBox box =
                new TextBox();

            box.Text = value;

            box.Width = 110;
            box.Height = 28;

            box.TextAlignment =
                TextAlignment.Right;

            box.VerticalContentAlignment =
                VerticalAlignment.Center;

            return box;
        }

        // =====================================================
        // LABEL + CONTROL ROW
        // =====================================================
        private void AddRow(
            StackPanel panel,
            string label,
            Control control)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        new GridLength(250)
                }
            );

            TextBlock text =
                new TextBlock();

            text.Text = label;

            text.Foreground =
                Brushes.WhiteSmoke;

            text.VerticalAlignment =
                VerticalAlignment.Center;

            Grid.SetColumn(
                text,
                0
            );

            row.Children.Add(
                text
            );

            control.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                control,
                1
            );

            row.Children.Add(
                control
            );

            panel.Children.Add(
                row
            );
        }

        // =====================================================
        // INFO TEXT
        // =====================================================
        private TextBlock CreateValueText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.White;

            block.FontWeight =
                FontWeights.Bold;

            return block;
        }

        private void AddInfoRow(
            StackPanel panel,
            string label,
            TextBlock value)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            TextBlock labelBlock =
                new TextBlock();

            labelBlock.Text =
                label;

            labelBlock.Foreground =
                Brushes.LightGray;

            Grid.SetColumn(
                labelBlock,
                0
            );

            row.Children.Add(
                labelBlock
            );

            value.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                value,
                1
            );

            row.Children.Add(
                value
            );

            panel.Children.Add(
                row
            );
        }

        // =====================================================
        // BUTTON
        // =====================================================
        private Button CreateButton(
            string text)
        {
            Button button =
                new Button();

            button.Content = text;

            button.Height = 42;

            button.FontWeight =
                FontWeights.Bold;

            button.Cursor =
                System.Windows.Input.Cursors.Hand;

            return button;
        }
    }
}

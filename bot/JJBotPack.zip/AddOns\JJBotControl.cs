#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it.
// V1.6.20 + DIRECTIONAL PRESSURE ENGINE: aligned aggression scalp + counter-pressure safety gate + pullback/resumption logic.
// Trading/risk state is anchored to the CME-style NY session: a new session begins at 18:00 ET
// (Sunday-Thursday). The 16:25 ET FORCE FLAT lock is preserved only until that next session begins.
// Preserves V1.6.13 Learning Decision Engine, V1.6.12 Safety Hardening, Smart Retest, Premarket Context,
// all existing signal logic, execution protection, trailing, Smart Scale-In and telemetry behavior.
namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // SHARED STATE BRIDGE
    //
    // Lets JJBotControl publish its REAL execution state to
    // JJBotChart without the chart indicator submitting orders.
    // =========================================================
    public class JJBotControl : NinjaTrader.NinjaScript.AddOnBase
    {
        private NTMenuItem toolsMenu;
        private NTMenuItem jjBotMenuItem;

        // One persistent bot window/engine per NinjaTrader session.
        // Closing the visible window only hides it; the engine, telemetry
        // and command polling remain alive in the background.
        private JJBotWindow jjBotWindow;

        // V15 - five independent hidden bot engines.
        private readonly Dictionary<string, JJBotWindow>
            jjBotProfileWindows =
                new Dictionary<string, JJBotWindow>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly string[] BotProfileIds =
        {
            "profile-1",
            "profile-2",
            "profile-3",
            "profile-4",
            "profile-5"
        };

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "J&J NY Trading Bot Control Panel";
                Name = "JJBotControl";
            }
        }

        // =====================================================
        // ADD J&J BOT TO NINJATRADER TOOLS MENU
        // =====================================================
        protected override void OnWindowCreated(Window window)
        {
            ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            toolsMenu =
                controlCenter.FindFirst(
                    "ControlCenterMenuItemTools"
                ) as NTMenuItem;

            if (toolsMenu == null)
                return;

            jjBotMenuItem = new NTMenuItem
            {
                Header = "J&J NY Trading Bot",

                Style =
                    Application.Current.TryFindResource(
                        "MainMenuItem"
                    ) as Style
            };

            toolsMenu.Items.Add(jjBotMenuItem);
            jjBotMenuItem.Click += OnJJBotMenuClick;

            // Start the bridge/telemetry/command engine automatically.
            // IMPORTANT:
            // Create the hidden bot window on the SAME dispatcher that owns
            // NinjaTrader's Control Center. Application.Current.Dispatcher
            // is not guaranteed to be the same dispatcher in NinjaTrader.
            EnsureBackgroundBotEngine(
                controlCenter.Dispatcher
            );
        }

        private void EnsureBackgroundBotEngine(
            Dispatcher dispatcher)
        {
            if (dispatcher == null)
            {
                return;
            }

            dispatcher.BeginInvoke(
                new Action(
                    delegate
                    {
                        if (
                            jjBotWindow != null &&
                            jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        foreach (
                            string profileId
                            in BotProfileIds
                        )
                        {
                            JJBotWindow profileWindow;

                            if (
                                jjBotProfileWindows.TryGetValue(
                                    profileId,
                                    out profileWindow
                                ) &&
                                profileWindow != null &&
                                profileWindow.IsEngineWindowAlive
                            )
                            {
                                continue;
                            }

                            profileWindow =
                                new JJBotWindow(
                                    profileId,
                                    string.Equals(
                                        profileId,
                                        "profile-1",
                                        StringComparison.OrdinalIgnoreCase
                                    )
                                );

                            jjBotProfileWindows[profileId] =
                                profileWindow;

                            if (
                                string.Equals(
                                    profileId,
                                    "profile-1",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                jjBotWindow =
                                    profileWindow;
                            }
                        }

                        // Windows stay hidden. Each profile polls only
                        // its own command queue and publishes its own state.
                    }
                )
            );
        }

        // =====================================================
        // CLEANUP MENU
        // =====================================================
        protected override void OnWindowDestroyed(Window window)
        {
            if (!(window is ControlCenter))
                return;

            // NinjaTrader / Control Center is actually shutting down:
            // now the hidden engine must be allowed to close permanently.
            foreach (
                KeyValuePair<string, JJBotWindow> pair
                in jjBotProfileWindows.ToArray()
            )
            {
                try
                {
                    if (pair.Value != null)
                    {
                        pair.Value.RequestPermanentClose();
                    }
                }
                catch
                {
                }
            }

            jjBotProfileWindows.Clear();
            jjBotWindow = null;

            if (jjBotMenuItem != null)
            {
                jjBotMenuItem.Click -= OnJJBotMenuClick;

                if (
                    toolsMenu != null &&
                    toolsMenu.Items.Contains(jjBotMenuItem)
                )
                {
                    toolsMenu.Items.Remove(jjBotMenuItem);
                }

                jjBotMenuItem = null;
            }

            toolsMenu = null;
        }

        // =====================================================
        // OPEN BOT WINDOW
        // =====================================================
        private void OnJJBotMenuClick(
            object sender,
            RoutedEventArgs e)
        {
            /*
              IMPORTANT:
              If the hidden JJBotWindow already exists, the ONLY safe
              dispatcher for Show/Activate/WindowState is the dispatcher
              that owns that exact window.

              The menu/Control Center dispatcher is not guaranteed to be
              the owner of the existing hidden window.
            */
            if (
                jjBotWindow != null &&
                jjBotWindow.IsEngineWindowAlive
            )
            {
                Dispatcher windowDispatcher =
                    jjBotWindow.Dispatcher;

                if (windowDispatcher == null)
                {
                    return;
                }

                windowDispatcher.BeginInvoke(
                    new Action(() =>
                    {
                        if (
                            jjBotWindow == null ||
                            !jjBotWindow.IsEngineWindowAlive
                        )
                        {
                            return;
                        }

                        if (!jjBotWindow.IsVisible)
                        {
                            jjBotWindow.Show();
                        }

                        if (
                            jjBotWindow.WindowState ==
                                WindowState.Minimized
                        )
                        {
                            jjBotWindow.WindowState =
                                WindowState.Normal;
                        }

                        jjBotWindow.Activate();
                    })
                );

                return;
            }

            /*
              No window exists yet.
              Create + show it on the same dispatcher that owns
              NinjaTrader's menu/Control Center.
            */
            Dispatcher createDispatcher =
                jjBotMenuItem != null
                    ? jjBotMenuItem.Dispatcher
                    : (
                        toolsMenu != null
                            ? toolsMenu.Dispatcher
                            : null
                      );

            if (createDispatcher == null)
            {
                return;
            }

            createDispatcher.BeginInvoke(
                new Action(() =>
                {
                    if (
                        jjBotWindow == null ||
                        !jjBotWindow.IsEngineWindowAlive
                    )
                    {
                        jjBotWindow =
                            new JJBotWindow(
                                "profile-1",
                                true
                            );

                        jjBotProfileWindows[
                            "profile-1"
                        ] =
                            jjBotWindow;
                    }

                    if (!jjBotWindow.IsVisible)
                    {
                        jjBotWindow.Show();
                    }

                    if (
                        jjBotWindow.WindowState ==
                            WindowState.Minimized
                    )
                    {
                        jjBotWindow.WindowState =
                            WindowState.Normal;
                    }

                    jjBotWindow.Activate();
                })
            );
        }
    }

    // =========================================================
    // RUNTIME / PERSISTENCE COORDINATOR
    // =========================================================
    // - One persistence lock per Account + Instrument.
    // - One active bot lease per Account + Instrument.
    //
    // This prevents two JJBot windows from actively trading the same
    // Account + Instrument at the same time and serializes XML access.
    // =========================================================
    // =========================================================
    // PERSISTENT SESSION STATE
    // =========================================================
    [Serializable]
    public class JJBotDailyStateData
    {
        // V1.6.12 - explicit persistence schema tag.
        // 0 means legacy/unknown. New saves use schema 2.
        public int SchemaVersion
        {
            get;
            set;
        }

        public string NewYorkDate
        {
            get;
            set;
        }

        public string AccountName
        {
            get;
            set;
        }

        public string InstrumentName
        {
            get;
            set;
        }

        public int TradesToday
        {
            get;
            set;
        }

        public int AmTrades
        {
            get;
            set;
        }

        public int PmTrades
        {
            get;
            set;
        }

        // V1.6.8 - independent premarket counter.
        public int PremarketTrades
        {
            get;
            set;
        }

        // V13 - strict lunch-session counter.
        public int MiddayTrades
        {
            get;
            set;
        }

// V11 PnL accounting:
        // GrossPnL = price movement before commissions/fees.
        // Fees = entry + exit execution commissions.
        // RealizedPnL remains NET for backward compatibility.
        public double GrossPnL
        {
            get;
            set;
        }

        public double Fees
        {
            get;
            set;
        }

        public double RealizedPnL
        {
            get;
            set;
        }

        // V1.6.4 - dynamic daily/session profit protection.
        // These fields are backward compatible with older XML files.
        public double PeakTotalPnL
        {
            get;
            set;
        }

        public double ProtectedProfitFloor
        {
            get;
            set;
        }

        public bool ProfitFloorArmed
        {
            get;
            set;
        }

        public bool DailyLocked
        {
            get;
            set;
        }

        // V1.6.2 - diagnostic persistence for daily lock source.
        public string DailyLockReason
        {
            get;
            set;
        }

        public DateTime LastExecutedSignalBar
        {
            get;
            set;
        }

        // Structure setup keys are persisted so a restart cannot
        // re-trade the same already-filled sweep/BOS setup.
        public string ConsumedBullishStructureKey
        {
            get;
            set;
        }

        public string ConsumedBearishStructureKey
        {
            get;
            set;
        }

        public DateTime ConsumedBullishStructureConfirmTime
        {
            get;
            set;
        }

        public DateTime ConsumedBearishStructureConfirmTime
        {
            get;
            set;
        }

        public bool OpeningTradeTaken
        {
            get;
            set;
        }

        public JJBotDailyStateData()
        {
            SchemaVersion = 0;
            NewYorkDate = string.Empty;
            AccountName = string.Empty;
            InstrumentName = string.Empty;

            TradesToday = 0;
            AmTrades = 0;
            PmTrades = 0;
            PremarketTrades = 0;
            MiddayTrades = 0;
            GrossPnL = 0;
            Fees = 0;
            RealizedPnL = 0;
            PeakTotalPnL = 0;
            ProtectedProfitFloor = 0;
            ProfitFloorArmed = false;
            DailyLocked = false;
            DailyLockReason = string.Empty;

            LastExecutedSignalBar =
                DateTime.MinValue;

            ConsumedBullishStructureKey =
                string.Empty;

            ConsumedBearishStructureKey =
                string.Empty;

            ConsumedBullishStructureConfirmTime =
                DateTime.MinValue;

            ConsumedBearishStructureConfirmTime =
                DateTime.MinValue;

            OpeningTradeTaken = false;
        }
    }

    // =========================================================
    // J&J BOT WINDOW
    // =========================================================
    public partial class JJBotWindow : NTWindow
    {
        // =====================================================
        // LIVE DISPLAY
        // =====================================================
        private TextBlock statusText;
        private TextBlock grossPnlText;
        private TextBlock feesPnlText;
        private TextBlock pnlText;
        private TextBlock unrealizedPnlText;
        private TextBlock totalPnlText;
        private TextBlock tradesText;
        private TextBlock signalText;
        private TextBlock accountStatusText;
        private TextBlock instrumentStatusText;

        private TextBlock emaFastText;
        private TextBlock emaSlowText;
        private TextBlock lastPriceText;
        private TextBlock barTimeText;

        private TextBlock vwapText;
        private TextBlock nySessionText;
        private TextBlock trendText;
        private TextBlock setupText;

        private TextBlock liquidityText;
        private TextBlock structureText;
        private TextBlock momentumText;
        private TextBlock confirmationText;

        // Values published to JJBotChart.
        private string currentSignalState;
        private string currentSetupState;

        // =====================================================
        // EXECUTION MONITOR DISPLAY
        // =====================================================
        private TextBlock positionText;
        private TextBlock positionQtyText;
        private TextBlock entryPriceText;
        private TextBlock stopPriceText;
        private TextBlock targetPriceText;
        private TextBlock riskRewardText;
        private TextBlock orderStatusText;

        // =====================================================
        // VISUAL LOG
        // =====================================================
        private TextBox visualLogBox;
        private Button clearLogButton;
        private Queue<string> visualLogLines;

        private const int MaxVisualLogLines = 2000;

        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        // Read-only bridge:
        // JJBotControl -> localhost backend -> React platform.
        //
        // IMPORTANT:
        // This bridge NEVER submits, changes or flattens orders.
        // It only publishes the bot's current state.
        private DispatcherTimer platformTelemetryTimer;
        private bool platformTelemetryRequestInFlight;
        private string platformApiKey;
        private string platformServerUrl;
        private string platformConfigFile;

        // =====================================================
        // JJ TRADING TOOLS CLOUD LICENSE BRIDGE
        // =====================================================
        // Licensing only goes through Linux/cloud.
        // Trading execution, telemetry and commands remain LOCAL.
        private const string BotLicenseServerUrl =
            "https://jjtradingtools.ddns.net";

        private DispatcherTimer botLicenseTimer;
        private bool botLicenseValid;
        private DateTime botLicenseExpiresUtc =
            DateTime.MinValue;
        private DateTime botLicenseLastSuccessUtc =
            DateTime.MinValue;
        private string botLicenseLastStatus =
            "NOT CHECKED";

        // V15 runtime identity.
        private string platformProfileId;
        private bool primaryProfileWindow;
        private DateTime lastPlatformTelemetrySuccessUtc;

        // Platform -> JJBotControl command polling.
        // Separate timer/HTTP request from telemetry so a slow command
        // request can never block state publishing.
        private DispatcherTimer platformCommandTimer;
        private bool platformCommandRequestInFlight;
        private string lastProcessedPlatformCommandId;

        // True only while a START_BOT command from J&J Company Bro
        // is applying its Account + Instrument + risk configuration.
        // This lets StartBotClicked use the platform-selected context
        // without requiring the visible NinjaTrader bot window.
        private bool platformRemoteStartContext;

        private const int PlatformTelemetryIntervalSeconds = 3;
        private const int PlatformCommandIntervalSeconds = 1;
        // V1.6.6 - keep the local visual history large, but only publish
        // a compact tail to the platform. This prevents one noisy profile
        // from timing out its own telemetry request.
        // V1.6.24B - bound telemetry payload size per profile.
        // Keeps the UI responsive even if one profile generates many logs.
        private const int PlatformTelemetryMaxLogLines = 120;
        private const string PlatformBridgeVersion = "1.3.2";

        // =====================================================
        // CLOUD BOT LICENSE HELPERS
        // =====================================================
        private bool IsBotCloudLicenseValid()
        {
            return
                botLicenseValid &&
                DateTime.UtcNow <
                    botLicenseExpiresUtc;
        }

        private bool RefreshBotCloudLicense(
            bool showMessage)
        {
            try
            {
                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    botLicenseValid = false;
                    botLicenseLastStatus =
                        "API KEY MISSING";

                    if (showMessage)
                    {
                        PrintBotMessage("BOT LICENSE UI NOTICE | API KEY MISSING");
                    }

                    return false;
                }

                using (
                    WebClient client =
                        new WebClient()
                )
                {
                    client.Headers[
                        HttpRequestHeader.ContentType
                    ] = "application/json";

                    client.Headers[
                        "X-JJ-API-Key"
                    ] = platformApiKey;

                    string response =
                        client.UploadString(
                            BotLicenseServerUrl.TrimEnd('/')
                            + "/api/license/lease",
                            "POST",
                            "{\"product\":\"BOT\"}"
                        );

                    bool authorized =
                        Regex.IsMatch(
                            response,
                            "\"authorized\"\\s*:\\s*true",
                            RegexOptions.IgnoreCase
                        );

                    bool botFeature =
                        Regex.IsMatch(
                            response,
                            "\"bot\"\\s*:\\s*true",
                            RegexOptions.IgnoreCase
                        );

                    Match expiryMatch =
                        Regex.Match(
                            response,
                            "\"expiresAt\"\\s*:\\s*\"([^\"]+)\"",
                            RegexOptions.IgnoreCase
                        );

                    DateTime parsedExpiry;

                    if (
                        expiryMatch.Success &&
                        DateTime.TryParse(
                            expiryMatch.Groups[1].Value,
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.AdjustToUniversal |
                            DateTimeStyles.AssumeUniversal,
                            out parsedExpiry
                        )
                    )
                    {
                        botLicenseExpiresUtc =
                            parsedExpiry.ToUniversalTime();
                    }
                    else
                    {
                        // Conservative fallback if server response is malformed.
                        botLicenseExpiresUtc =
                            DateTime.UtcNow.AddMinutes(5);
                    }

                    botLicenseValid =
                        authorized &&
                        botFeature;

                    if (botLicenseValid)
                    {
                        botLicenseLastSuccessUtc =
                            DateTime.UtcNow;

                        botLicenseLastStatus =
                            "AUTHORIZED";

                        PrintBotMessage(
                            "BOT LICENSE OK"
                            + " | Expires UTC: "
                            + botLicenseExpiresUtc
                                .ToString("HH:mm:ss")
                        );
                    }
                    else
                    {
                        botLicenseLastStatus =
                            "PLAN NOT AUTHORIZED";
                    }

                    if (
                        !botLicenseValid &&
                        showMessage
                    )
                    {
                        PrintBotMessage("BOT LICENSE UI NOTICE | ELITE REQUIRED");
                    }

                    return botLicenseValid;
                }
            }
            catch (WebException ex)
            {
                HttpWebResponse errorResponse =
                    ex.Response as HttpWebResponse;

                if (
                    errorResponse != null &&
                    (
                        errorResponse.StatusCode ==
                            HttpStatusCode.Unauthorized ||
                        errorResponse.StatusCode ==
                            HttpStatusCode.Forbidden
                    )
                )
                {
                    // Explicit server denial is NOT a network outage.
                    // Revoke immediately even if an older lease has time left.
                    botLicenseValid = false;
                    botLicenseExpiresUtc =
                        DateTime.MinValue;
                    botLicenseLastStatus =
                        "SERVER DENIED";

                    PrintBotMessage(
                        "BOT LICENSE DENIED BY SERVER"
                        + " | HTTP "
                        + ((int)errorResponse.StatusCode)
                    );

                    if (showMessage)
                    {
                        PrintBotMessage("BOT LICENSE UI NOTICE | ELITE REQUIRED");
                    }

                    return false;
                }

                // Only genuine connectivity/server failures may use
                // the remainder of an already-issued lease.
                bool stillValid =
                    IsBotCloudLicenseValid();

                if (!stillValid)
                {
                    botLicenseValid = false;
                    botLicenseLastStatus =
                        "OFFLINE / EXPIRED";

                    PrintBotMessage(
                        "BOT LICENSE OFFLINE / EXPIRED"
                        + " | "
                        + ex.Message
                    );
                }

                if (
                    showMessage &&
                    !stillValid
                )
                {
                    PrintBotMessage("BOT LICENSE UI NOTICE | SERVER REQUIRED");
                }

                return stillValid;
            }
            catch (Exception ex)
            {
                bool stillValid =
                    IsBotCloudLicenseValid();

                if (!stillValid)
                {
                    botLicenseValid = false;
                    botLicenseLastStatus =
                        "LICENSE ERROR";

                    PrintBotMessage(
                        "BOT LICENSE ERROR"
                        + " | "
                        + ex.Message
                    );
                }

                if (
                    showMessage &&
                    !stillValid
                )
                {
                    PrintBotMessage("BOT LICENSE UI NOTICE | VALIDATION ERROR");
                }

                return stillValid;
            }
        }

        private void EnsureBotLicenseTimer()
        {
            if (botLicenseTimer != null)
                return;

            botLicenseTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background
                );

            botLicenseTimer.Interval =
                TimeSpan.FromMinutes(5);

            botLicenseTimer.Tick +=
                delegate
                {
                    bool ok =
                        RefreshBotCloudLicense(
                            false
                        );

                    if (
                        !ok &&
                        botRunning
                    )
                    {
                        // Do NOT flatten an existing position.
                        // Entry engine independently blocks all NEW entries.
                        PrintBotMessage(
                            "BOT LICENSE LOCKED"
                            + " | New entries disabled."
                        );
                    }
                };

            botLicenseTimer.Start();
        }

        private void StopBotLicenseTimer()
        {
            if (botLicenseTimer == null)
                return;

            try
            {
                botLicenseTimer.Stop();
            }
            catch
            {
            }

            botLicenseTimer = null;
        }

        // =====================================================
        // NINJATRADER SELECTORS
        // =====================================================
        private AccountSelector accountSelector;
        private InstrumentSelector instrumentSelector;

        private Account selectedAccount;
        private Instrument selectedInstrument;

        // =====================================================
        // SETTINGS
        // =====================================================
        private ComboBox directionCombo;
        private ComboBox strategyCombo;

        private TextBox contractsBox;
        private TextBox stopBox;
        private TextBox targetBox;
        private TextBox maxTradesBox;
        private TextBox dailyTargetBox;
        private TextBox dailyLossBox;
        private TextBox dollarRiskCapBox;

        // =====================================================
        // BUTTONS
        // =====================================================
        private Button startButton;
        private Button stopButton;
        private Button closeAllButton;

        private Button testLongButton;
        private Button testShortButton;

        // =====================================================
        // BOT ENGINE
        // =====================================================
        private bool botRunning;

        // Cached on the UI thread when START BOT is pressed.
        // BarsRequest callbacks run on a different thread, so they must
        // never read WPF controls such as directionCombo directly.
        private string activeDirection;
        private string activeStrategyMode;

        // V1.6.4 Step 5 - AUTO direction resolved by market context.
        private string autoResolvedDirection;
        private string autoDirectionReason;

        // V1.6.14 LOG FIX - telemetry/log debounce is intentionally
        // independent from the live AUTO state. Fast Range callbacks may
        // temporarily change autoResolvedDirection between evaluations;
        // that must not make identical AUTO DIRECTION messages flood the log.
        private string lastLoggedAutoDirection;
        private string lastLoggedAutoDirectionReason;
        private DateTime lastAutoDirectionLogUtc;

        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        private int activeContracts;
        private int activeStopTicks;
        private int activeTargetTicks;
        private int activeMaxTrades;
        private double activeDailyTarget;
        private double activeDailyLoss;

        // V1.6.4 Step 4 - monetary risk cap per initial entry.
        // Auto Risk Sizing reduces contracts when configured SL risk
        // would exceed this cap.
        private double activeDollarRiskCap;

        // =====================================================
        // INPUT SAFETY LIMITS
        // =====================================================
        // Conservative hard caps for the SIM-only build.
        private const int MaxContractsAllowed = 20;
        private const int MaxStopTicksAllowed = 2000;
        private const int MaxTargetTicksAllowed = 4000;
        private const int MaxTradesPerSessionAllowed = 20;
        private const double MaxDailyTargetAllowed = 10000.0;
        private const double MaxDailyLossAllowed = 10000.0;
        private const double MaxDollarRiskCapAllowed = 10000.0;

        // V1.6.14 persistence schema. Schema 1 = legacy V11-compatible,
        // schema 2 = explicit Gross/Fees/Net, schema 3 = session-date semantics
        // (18:00 ET session rollover instead of midnight/calendar-day rollover).
        private const int CurrentDailyStateSchemaVersion = 3;

        private int tradesToday;
        private int premarketTradesToday;
        private int amTradesToday;
        private int pmTradesToday;
        private int middayTradesToday;
        private string pendingEntrySession;

// Actual order quantity after Auto Risk Sizing. activeContracts remains
// the user's configured maximum quantity.
private int pendingEntryRequestedQuantity;

        // V9 - MANUAL TEST ISOLATION
        // TEST_LONG / TEST_SHORT must exercise real order/bracket/trailing
        // mechanics without contaminating official session statistics,
        // Daily PnL or Learning memory.
        private bool pendingEntryIsManualTest;
        private bool activeTradeIsManualTest;

        // V12 - Opening Mode lifecycle.
        private bool pendingEntryIsOpening;
        private bool activeTradeIsOpening;

        // V1.6.8 - identifies the active lifecycle as a premarket trade so
        // the 09:28 transition guard can flatten it before the cash open.
        private bool pendingEntryIsPremarket;
        private bool activeTradeIsPremarket;

        private bool openingTradeTakenToday;

        private bool openingRangeReady;
        private double openingRangeHigh;
        private double openingRangeLow;
        private DateTime openingRangeBarTimeNy;
        private DateTime openingRangeLoggedDate;

        // V1.6.8 - PREMARKET ENGINE V1.
        // Built from completed M5 bars. Range-20 compares the live fast
        // move against the latest completed premarket frontier.
        private bool premarketRangeReady;
        private double premarketRangeHigh;
        private double premarketRangeLow;
        private DateTime premarketRangeDateNy;
        private DateTime premarketRangeLastM5TimeNy;
        private string lastPremarketChaseBlockLogKey;

        // V1.6.4 Step 3 - pre-entry/opening guard state.
        private bool preEntryRangeReady;
        private double preEntryRangeHigh;
        private double preEntryRangeLow;
        private DateTime preEntryRangeDateNy;
        private bool openingRangeGuardBlocked;
        private string openingRangeGuardReason;
        private DateTime openingRangeGuardDateNy;
        private string lastLateEntryBlockLogKey;

        // V11 - Daily accounting.
        // botDailyPnL is NET realized PnL and remains the value used by
        // Daily Target / Daily Loss and Learning compatibility paths.
        private double botDailyGrossPnL;
        private double botDailyFees;
        private double botDailyPnL;
        private double botUnrealizedPnL;

        // V1.6.4 - DAILY / SESSION PROFIT FLOOR
        // Protects part of the best total PnL reached during the NY day.
        // The floor can only move UP; it can never loosen once armed.
        private double dailyPeakTotalPnL;
        private double dailyProtectedProfitFloor;
        private bool dailyProfitFloorArmed;
        private double lastLoggedProtectedProfitFloor;
        private DateTime activeTradingDate;

        private bool riskFlattenSent;
        private int riskFlattenStage;
        private DateTime riskFlattenLastActionUtc;
        private Order riskFlattenOrder;

        // Tracks both sides of commission so Learning NetPnL is exact.
        private double activeEntryCommission;

        // =====================================================
        // PARTIAL FILL / TRADE LIFECYCLE V1
        // =====================================================
        // Entry executions can arrive in multiple partial fills.
        // Keep one lifecycle, one learning record and one trade count.
        private int activeEffectiveTargetTicks;
        private int activeExitQuantity;
        private double activeExitGrossPnL;
        private double activeExitCommission;

        // Debounces repeated Range signal/block messages for the same Range bar.
        private string lastRangeSignalLogKey;
        private string lastRangeBlockedLogKey;
        private string lastLearningBlockedLogKey;

        // =====================================================
        // V1.6.16 - STATISTICALLY CALIBRATED CONFIDENCE
        // =====================================================
        // =====================================================
        // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE ENGINE
        // =====================================================
        // Advisory layer for MNQ/NQ. It scores confluence already calculated
        // by the bot; it does NOT add a new hard entry filter in V1.
        private string lastSetupQualityLogKey;
        private int latestSetupConfidence;
        private string latestSetupQuality;
        private string latestSetupTiming;
        private string latestManipulationState;

        // V1.6.15A - UI confidence lifecycle.
        // pending* snapshots the exact analysis at order submission.
        // active* freezes that value after the first fill so the orb
        // keeps showing the confidence that actually produced the trade.
        private int pendingTradeSetupConfidence;
        private string pendingTradeSetupQuality;
        private string pendingTradeSetupTiming;
        private string pendingTradeManipulationState;
        private int activeTradeSetupConfidence;
        private string activeTradeSetupQuality;
        private string activeTradeSetupTiming;
        private string activeTradeManipulationState;

        // V1.6.9 - aggressive expansion / exhaustion diagnostics.
        private string lastAggressionSignalLogKey;
        private string lastExhaustionBlockLogKey;
        private string lastPullbackWaitLogKey;
        private string lastStructureExhaustionLogKey;

        // V1.6.11 - pending Smart Retest entry. A stretched ordinary signal is
        // remembered for a short window instead of being forgotten. The next
        // Range bars may confirm a breakout retest, M5 structure retest or a
        // micro-pullback continuation. Aggressive Expansion still enters direct.
        private bool pendingSmartRetestActive;
        // V1.6.16B - telemetry-only dedupe. Does NOT alter Smart Retest logic.
        private string lastSmartRetestConfirmedLogKey = string.Empty;
        private bool pendingSmartRetestIsLong;
        private DateTime pendingSmartRetestCreatedNy;
        private DateTime pendingSmartRetestExpiresNy;
        private double pendingSmartRetestBreakoutLevel;
        private double pendingSmartRetestStructureLevel;
        private double pendingSmartRetestImpulseExtreme;
        private int pendingSmartRetestOriginalScore;
        private string pendingSmartRetestReason;
        private string pendingSmartRetestStructureSetupKey;
        private string lastSmartRetestLogKey;

        // Latest real M5 BOS/CHOCH break levels. These are the structural prices
        // that were actually closed through, not an EMA proxy.
        private double latestM5BullishStructureBreakLevel;
        private double latestM5BearishStructureBreakLevel;

        // V1.6.11 - PREMARKET CONTEXT ENGINE. Built continuously from completed
        // M5 bars so Opening starts with a statistical map already prepared.
        private bool premarketContextReady;
        private DateTime premarketContextDateNy;
        private double premarketContextOpen;
        private double premarketContextLastClose;
        private double premarketContextMid;
        private double premarketContextRangeTicks;
        private int premarketContextBars;
        private int premarketBullBars;
        private int premarketBearBars;
        private int premarketUpperHalfCloses;
        private int premarketLowerHalfCloses;
        private double premarketContextPosition;
        private string premarketContextBias;
        private int premarketContextBiasScore;
        private DateTime lastPremarketContextLogNy;
        private DateTime lastPremarketContextFinalLogDateNy;

        // V1.6.2 - automatic re-entry cooldown / rearm.
        private DateTime lastAutomaticTradeExitNy;
        private DateTime lastAutomaticTradeExitRangeBarTime;
        private bool lastAutomaticTradeExitWasBreakeven;
        private bool lastAutomaticTradeExitWasLoss;
        private string lastAutomaticTradeExitSide;
        private string lastReentryBlockLogKey;
        private string lastPriceChaseBlockLogKey;
        private string lastOpeningContextBlockLogKey;
        // V1.6.24B - dedupe OPENING ANTI-CHASE OVERRIDE telemetry/log spam.
        private string lastOpeningAntiChaseOverrideLogKey = string.Empty;

        private const int AutomaticReentryCooldownSeconds = 60;

        private bool entryPending;
        private Order entryOrder;
        private Order stopOrder;
        private Order targetOrder;

        private double entryFillPrice;
        private double activeStopPrice;
        private double activeTargetPrice;

        // V1.6.23 - trade outcome telemetry / learning separation.
        private double activeTradeMfeDollars;
        private double activeTradeMaeDollars;
        private double activeTradePeakPnlDollars;
        private double activeTradeCurrentPrice;

        // V1.6.23 Phase 12 - active trade PnL is independent from official
        // Daily PnL. Manual TEST trades keep official botUnrealizedPnL at 0,
        // but still expose their real active-trade PnL for telemetry/testing.
        private double activeTradeUnrealizedPnl;

        // Immutable entry bracket snapshot used by deferred Signal Outcome.
        // These values are captured when the initial protective bracket is
        // created and are never overwritten by BE / trailing / retention.
        private double activeTradeOriginalStopPrice;
        private double activeTradeOriginalTargetPrice;

        private int activeProfitRetentionStage;
        private double activeProfitRetentionFactor;
        // V1.6.23 Phase 3 - active-trade reversal protection state.
        private bool activeReversalGuardArmed;
        private string lastReversalGuardLogKey;

        // V1.6.23 Phase 9 - giveback protection state.
        private bool activeGivebackGuardArmed;
        private string lastGivebackGuardLogKey;

        private string activeTradeExitReason;
        private string activeForcedExitReason;
        private int entryQuantity;

        private MarketPosition entryMarketPosition;
        private string executionStatus;
// =====================================================
// EXECUTION STATE SYNCHRONIZATION
// =====================================================
// Protects shared execution/order state accessed from
// BarsRequest, OrderUpdate and ExecutionUpdate callbacks.
//
// IMPORTANT:
// Never call Submit(), Change() or Flatten() while holding
// this lock.
//
// V1.6.12 LOCK ORDER / DEADLOCK RULE:
// Prefer snapshot-and-release instead of nesting executionStateLock,
// marketContextLock, emaCacheLock, SharedLearningSyncRoot or persistence
// locks. If a second domain is needed, release the first lock before
// taking the next one. External NinjaTrader order/account calls always
// happen after our locks are released.
private readonly object executionStateLock =
    new object();
     // =====================================================
// TRADE PROTECTION / TRAILING STATE
// =====================================================
private bool activeEntryUsesMomentumTrailing;
private int momentumTrailingStage;
private double lastMomentumTrailingStopPrice;

// V1.6.4 Step 2 - snapshot the BE policy at entry so a later market-state
// change cannot alter the protection rules of an already-open trade.
private bool activeStrongMomentumProtection;
private int activeBreakEvenTriggerTicks;

// Prevent excessive Account.Change() requests.
private DateTime lastMomentumTrailingChangeUtc =
    DateTime.MinValue;


// =====================================================
// DAILY TARGET PROTECTION
// =====================================================
private bool dailyTargetProtectionArmed;
private double lastDailyTargetProtectionStopPrice;

// =====================================================
// V14 - SMART SCALE-IN V1
// =====================================================
private bool smartScaleInUsed;
private bool smartScaleInPending;
private Order smartScaleInOrder;
private int initialTradeQuantity;
private double initialTradeRiskDollars;
private DateTime lastSmartScaleInAttemptUtc =
    DateTime.MinValue;

private const int SmartScaleInTriggerTicks = 70;
private const int SmartScaleInContracts = 1;
private const int SmartScaleInMinMomentumScore = 4;
private const int SmartScaleInMinHtfScore = 1;
private const int SmartScaleInAttemptThrottleMs = 3000;
// V1.6.23 Phase 5 - only add size into confirmed continuation, never into range noise.
private const int SmartScaleInMaxOppMomentumScore = 1;
private string lastSmartScaleInContextBlockKey = string.Empty;


private DateTime lastDailyTargetProtectionChangeUtc =
    DateTime.MinValue;


// Minimum delay between protective order modifications.
private const int ProtectiveOrderChangeThrottleMs = 500;

// =====================================================
// UNIFIED PROTECTIVE CHANGE COORDINATOR
// =====================================================
private bool protectiveChangeInFlight;

// V7 stability guard:
// Account.CreateOrder() can raise OrderUpdate synchronously while the
// SL/TP bracket is still being constructed. Without this guard,
// OnAccountOrderUpdate -> SyncProtectiveBracketToEntry can re-enter
// SubmitProtectiveBracket before the first bracket is complete,
// creating thousands of JJ_STOP/JJ_TARGET orders and freezing NT.
private bool protectiveBracketBuildInProgress;

private long protectiveChangeSequence;
private long activeProtectiveChangeToken;
private string protectiveChangeOwner;
private DateTime protectiveChangeStartedUtc =
    DateTime.MinValue;

private const int ProtectiveChangeTimeoutMs = 3000;

        // Prop-firm end-of-day protection
        private bool forceFlatSentToday;
        private DateTime forceFlatDateNy;

        // V1.6.8 - premarket transition protection.
        private bool premarketForceFlatSentToday;
        private DateTime premarketForceFlatDateNy;

        private DateTime lastExecutedSignalBar;

        private Account subscribedAccount;

        // =====================================================
        // SESSION PERSISTENCE (legacy field names retained for compatibility)
        // =====================================================
        private bool persistentDailyLocked;

        // V1.6.2 - tells us WHY the daily lock exists.
        private string persistentDailyLockReason;

        private string stateFolderPath;

        // Prevents two windows from running the same Account + Instrument.
        private string activeRuntimeLeaseKey;

        private BarsRequest barsRequest;
        private bool barsRequestSubscribed;

        // Higher timeframe context engines.
        private BarsRequest h1BarsRequest;
        private bool h1BarsRequestSubscribed;
        private bool h1BarsReady;
        private DateTime lastH1BarTime;

        private BarsRequest h4BarsRequest;
        private bool h4BarsRequestSubscribed;
        private bool h4BarsReady;
        private DateTime lastH4BarTime;

        private DateTime lastSignalBarTime;
        private bool barsReady;

        // Internal Range series used ONLY by Momentum Engine.
        // No second chart is required.
        private BarsRequest rangeBarsRequest;
        private bool rangeBarsRequestSubscribed;
        private bool rangeBarsReady;
        private DateTime lastRangeBarTime;

        private readonly object marketContextLock =
            new object();

        // =====================================================
        // INCREMENTAL EMA CACHE
        // =====================================================
        // BarsRequest cannot be fed directly to NinjaTrader EMA.
        // Cache the EMA prefix per Bars instance + period so normal
        // updates are O(1) instead of recomputing from bar 0.
        private sealed class EmaCacheState
        {
            public DateTime FirstBarTime;
            public List<double> Values;

            public EmaCacheState()
            {
                FirstBarTime = DateTime.MinValue;
                Values = new List<double>();
            }
        }

        private readonly object emaCacheLock =
            new object();

        private readonly Dictionary<Bars, Dictionary<int, EmaCacheState>>
            emaCaches =
                new Dictionary<Bars, Dictionary<int, EmaCacheState>>();

        // Higher-timeframe context is informational/scoring only.
        // V1 does NOT use this as a hard entry filter.
        private string latestH4Trend;
        private string latestH1Trend;
        private int latestHtfLongScore;
        private int latestHtfShortScore;
        private string latestHtfContextBias;

        // Latest confirmed M5 context consumed by the Range trigger.
        private bool latestM5ContextReady;
        private bool latestM5BullishTrend;
        private bool latestM5BearishTrend;
        private bool latestM5AboveVwap;
        private bool latestM5BelowVwap;
        private bool latestM5BullishStructure;
        private bool latestM5BearishStructure;
        private string latestM5LiquidityState;
        private string latestM5StructureState;
        private DateTime latestM5DecisionNyTime;
        private double latestM5Vwap;

        // Latest confirmed Range momentum values for UI / logs.
        private int latestRangeLongScore;
        private int latestRangeShortScore;
        private double latestRangeRatio;
        private double latestRangeVolumeRatio;
        private double latestRangeBodyRatio;
        private double latestRangeEmaSlope;
        private bool latestRangeHighBreakout;
        private bool latestRangeLowBreakout;

        // =====================================================
        // V1.6.20 - DIRECTIONAL PRESSURE ENGINE
        // =====================================================
        private string latestDirectionalPressure = "NEUTRAL";
        private int latestDirectionalLongPressureScore;
        private int latestDirectionalShortPressureScore;
        private string lastDirectionalPressureLogKey;
        private string lastDirectionalSafetyBlockKey;
        private string latestRangeMomentumState;

        // =====================================================
        // STRUCTURE SETUP CONSUMPTION
        // =====================================================
        // A structure setup is identified by:
        // direction + sweep timestamp + confirmation timestamp.
        //
        // The pending key is attached to the submitted M5 structure
        // entry. It becomes consumed ONLY after the entry actually fills.
        private string pendingStructureSetupKey;
        private DateTime pendingStructureConfirmTime;

        private string consumedBullishStructureSetupKey;
        private string consumedBearishStructureSetupKey;

        // Time frontiers prevent an older already-traded setup from
        // becoming eligible again after a newer setup is consumed.
        private DateTime consumedBullishStructureConfirmTime;
        private DateTime consumedBearishStructureConfirmTime;

        private const int FastEmaPeriod = 9;
        private const int SlowEmaPeriod = 50;
        private const int BarsBack = 200;

        // Higher timeframe trend context.
        private const int HtfFastEmaPeriod = 50;
        private const int HtfSlowEmaPeriod = 200;
        private const int HtfBarsBack = 260;

        // New York session rules
        private const int RthVwapStart = 93000;

        // =====================================================
        // V1.6.8 PREMARKET ENGINE V1
        // =====================================================
        // Momentum-only window. It does NOT consume an AM slot.
        // New entries stop at 09:25 so the bot is flat-or-managed going
        // into the five minutes immediately before the 09:30 cash open.
        private const int PremarketSessionStart = 73000;
        private const int PremarketSessionEnd = 92500;
        private const int PremarketForceFlatTime = 92800;
        private const int PremarketMaxTrades = 1;
        private const int PremarketMomentumMinScore = 4;
        private const int PremarketExtremeMinScore = 3;
        private const double PremarketExtremeMinBodyRatio = 0.75;
        private const double PremarketExtremeMinSlopeTicks = 4.0;
        private const int PremarketMaxChaseTicks = 60;

        // Trading window 1: 09:30 - 11:59:59 ET
        private const int BotSession1Start = 93000;
        private const int BotSession1End = 115959;

        // V13 strict Midday: 12:00 - 13:59:59 ET
        private const int BotMiddayStart = 120000;
        private const int BotMiddayEnd = 135959;
        private const int MiddayMaxTrades = 1;
        private const int MiddayMomentumMinScore = 5;
        private const int MiddayMinHtfAlignmentScore = 1;

        // Trading window 2: 14:00 - 15:30 ET
        private const int BotSession2Start = 140000;
        private const int BotSession2End = 153000;

        // =====================================================
        // V12 OPENING MODE
        // =====================================================
        private const int OpeningRangeStart = 93000;
        private const int OpeningEntryStart = 93500;
        private const int OpeningEntryEnd = 100000;
        private const int OpeningBreakoutBufferTicks = 2;

        // =====================================================
        // V1.6.24 - OPENING SAFETY HARDENING
        // =====================================================
        // The first seconds after the 09:30 cash open are discovery/noise.
        // Automatic entries are blocked while the market establishes an
        // initial direction. Manual SIM tests remain unaffected.
        private const int OpeningStabilityGuardSeconds = 60;

        // During the opening window, a momentum impulse against the confirmed
        // M5 trend may not trade until the corresponding BOS/CHOCH confirms.
        // This prevents a strong R20 candle from overriding unresolved M5 structure.
        private const int OpeningCounterTrendVetoEnd = 100000;

        // After an automatic same-side loss during the opening window, high
        // conviction alone is NOT sufficient to re-enter. A fresh aligned
        // M5 structure confirmation is required.
        // V1.6.25 - same-side post-loss rearm protection remains active
        // through the full AM session. A loss at 10:01 must not become eligible
        // again merely because the old 10:00 opening boundary was crossed.
        private const int OpeningSameSideLossStructureRearmEnd = 113000;

        // Debounce keys for the final execution safety logs.
        private string lastOpeningStabilityBlockLogKey = string.Empty;
        private string lastOpeningCounterTrendBlockLogKey = string.Empty;
        private string lastOpeningSameSetupBlockLogKey = string.Empty;

        // V1.6.4 Step 3 - pre-entry/opening safety context.
        // Pre-entry context is measured before the cash open.
        private const int PreEntryRangeStart = 90000;
        private const int PreEntryRangeEnd = 92959;

        // Guard only pathological opening expansion.
        // If the first 5m opening range is more than 1.25x the full
        // 09:00-09:29 pre-entry range, Opening entries are skipped and
        // HYBRID may fall back to Structure/Momentum.
        private const double OpeningMaxPreEntryExpansionRatio = 1.25;

        // Late-entry tolerances. Range-20 signals are near-real-time,
        // while confirmed M5 Structure/Opening bars can naturally be
        // several minutes old because the bar timestamp is its start.
        // V1.6.23 Phase 10 - Timing Intelligence.
        // Range-20 momentum is a fast signal. Do not execute a stale bar.
        // High-conviction momentum gets a small extra grace window because
        // it may pass through additional safety / regime checks first.
        private const int MomentumLateEntryMaxSeconds = 60;
        private const int HighConvictionMomentumLateEntryMaxSeconds = 75;
        private const int StructureLateEntryMaxSeconds = 420;
        private const int OpeningLateEntryMaxSeconds = 420;

        // =====================================================
        // LIQUIDITY / STRUCTURE RULES
        // =====================================================
        private const int SweepLookback = 5;
        private const int SweepMaxAgeBars = 6;

        // Keep the structural swing anchored to the SAME reference
        // window used to define the sweep. This prevents silent
        // desynchronization if SweepLookback is changed later.
        private const int StructureLookback = SweepLookback;

        // Ignore one-tick micro sweeps/noise.
        private const int MinimumSweepTicks = 2;

        // Momentum Engine V2 rules (confirmed internal Range bars only)
        private const int MomentumAverageLookback = 10;
        private const int MomentumBreakoutLookback = 3;
        private const double MomentumRangeExpansion = 1.15;
        private const double MomentumVolumeExpansion = 1.20;
        private const double MomentumMinBodyRatio = 0.60;
        private const int MomentumMinScore = 4;

        // =====================================================
        // V1.6.9 - AGGRESSIVE EXPANSION ENGINE
        // =====================================================
        // Detects a FRESH price/volume expansion from native bar data.
        // This is not Level 2 order-flow; it is a fast aggression proxy
        // using body, range expansion, relative volume, EMA velocity,
        // breakout and multi-bar displacement.
        private const int AggressionMinScore = 4;
        private const double AggressionMinBodyRatio = 0.70;
        private const double AggressionMinRangeRatio = 1.30;
        private const double AggressionMinVolumeRatio = 1.20;
        private const double AggressionMinSlopeTicks = 5.0;
        private const int AggressionLookbackBars = 3;
        private const int AggressionMinDirectionalBars = 2;
        private const double AggressionMinDisplacementTicks = 35.0;

        // Once the directional move is already very mature, ordinary
        // Momentum entries are vetoed unless a NEW aggressive expansion
        // is actually present. 800 ticks = 200 points on MNQ/NQ.
        private const double ExhaustionMinMoveTicks = 800.0;
        private const double ExhaustionMaxWeakVolumeRatio = 1.00;
        private const double ExhaustionMaxWeakBodyRatio = 0.55;
        private const int ExhaustionSessionScanMaxBars = 240;

        // V1.6.5 - EARLY EXTREME MOMENTUM OVERRIDE.
        // This does NOT lower the normal Momentum threshold globally.
        // A 3/5 signal is actionable only when it also has breakout,
        // strong body, strong EMA slope and VWAP alignment.
        private const int ExtremeMomentumMinScore = 3;
        private const double ExtremeMomentumMinBodyRatio = 0.75;
        private const double ExtremeMomentumMinSlopeTicks = 4.0;
        // V1.6.10: the 2026-08-19 session showed that a 3/5 breakout with
        // very weak participation (example ~0.55x volume) can be a bad chase,
        // while ~1.15x still produced valid follow-through. Keep 3/5, but require
        // at least normal participation before the Extreme fast path may enter.
        private const double ExtremeMomentumMinVolumeRatio = 1.00;

        // V1.6.11 - SMART RETEST ENTRY ENGINE. EMA9 remains only one anti-chase
        // reference. Actual re-entry confirmation can come from price structure.
        private const double PullbackMaxExtensionTicks3of5 = 40.0;
        private const double PullbackMaxExtensionTicks4Plus = 60.0;
        private const int SmartRetestWindowSeconds = 300;
        private const int SmartRetestLevelToleranceTicks = 12;
        private const int SmartRetestStructureToleranceTicks = 16;
        private const int SmartRetestMinResumeScore = 2;
        private const int SmartRetestMicroPullbackLookback = 3;

        // V1.6.23 Phase 10 - retests are strongest while fresh. A retest may
        // remain alive for the full 300s window, but after 120s continuation
        // must prove itself with stronger momentum, low opposite pressure and
        // a decisive resume candle. This prevents stale "late continuation".
        private const int SmartRetestFreshWindowSeconds = 120;
        private const int SmartRetestStaleMinResumeScore = 3;
        private const int SmartRetestStaleMaxOppositeScore = 1;
        private const double SmartRetestStaleMinResumeBodyRatio = 0.55;

        // V1.6.23 Phase 11 - Entry Quality Gate.
        // Applied only to automatic MOMENTUM entries outside Opening.
        // TREND remains permissive; RANGE and TRANSITION require cleaner
        // evidence so the bot does not trade mixed/low-energy noise.
        private const int TransitionEntryMinSameSideScore = 3;
        private const int TransitionEntryMaxOppositeScore = 1;
        private const double TransitionEntryMinVolumeRatio = 0.90;
        private const double TransitionEntryMinBodyRatio = 0.50;

        private const int RangeEntryMinSameSideScore = 4;
        private const int RangeEntryMaxOppositeScore = 1;
        private const double RangeEntryMinVolumeRatio = 1.15;
        private const double RangeEntryMinBodyRatio = 0.60;

        private string lastEntryQualityBlockKey = string.Empty;

        // Premarket opening-context interpretation. Context is confirmation,
        // not a hard standalone trade trigger.
        private const double PremarketStrongBiasPosition = 0.67;
        private const double PremarketWeakBiasPosition = 0.55;
        private const int PremarketContextMinBars = 6;

        // V1.6.10 - STRUCTURE MATURE-MOVE GUARD.
        // Structure can stay 4/4 after a large move. If continuation evidence is
        // weak, do not sell/buy the tail of an already mature directional leg.
        private const double StructureExhaustionMinMoveTicks = 400.0;
        private const int StructureExhaustionMaxMomentumScore = 2;
        private const double StructureExhaustionMaxVolumeRatio = 1.00;

        // Opening breakout must still be fresh.  Once price has travelled
        // more than 50% of the opening-range width beyond the breakout
        // boundary, the Opening entry is skipped instead of chasing price.
        private const double OpeningMaxChaseRangeFraction = 0.50;
        private const int OpeningMinChaseTicks = 20;

        // A strong new Momentum signal may re-arm early after a PRICE BE
        // exit. Losses still observe the full normal cooldown.
        private const int StrongMomentumReentryMinSeconds = 20;

        private const int MomentumRangeTicks = 20;

        // Trade Capital Protection V3 - Adaptive / Staged
        // Standard setup:
        // +40 ticks  -> Break Even
        //
        // Strong Momentum setup (4/5+, aligned breakout, volume >= 1.50x):
        // +60 ticks  -> Break Even
        //
        // V1.6.10: give valid runners more room after the 2026-08-19 case
        // where +70t was locked at +30t and the market later continued strongly.
        // Both modes then use staged protection:
        // +100 ticks -> Lock +30 ticks
        // +140 ticks -> Lock +70 ticks
        // +180 ticks -> Trail 60 ticks behind price
        //
        // IMPORTANT: every stop update is still filtered by
        // EnforceNeverWorsenStop(), so protection can never move backwards.
        private const int MomentumBreakEvenTriggerTicks = 40;
        private const int StrongMomentumBreakEvenTriggerTicks = 60;
        private const int StrongMomentumMinScore = 4;
        private const double StrongMomentumMinVolumeRatio = 1.50;

        private const int MomentumLockTriggerTicks = 100;
        private const int MomentumLockProfitTicks = 30;

        private const int MomentumLock2TriggerTicks = 140;
        private const int MomentumLock2ProfitTicks = 70;

        private const int MomentumTrailTriggerTicks = 180;
        private const int MomentumTrailDistanceTicks = 60;

        // Dynamic target: the configured target is the MAXIMUM target.
        private const int DynamicTargetMinTicks = 60;
        // V1.6.23 - never let adaptive TP compress below 1.25R.
        private const double DynamicTargetMinimumRiskReward = 1.25;
        private const double DynamicTargetMediumFactor = 0.80;
        private const double DynamicTargetWeakFactor = 0.65;

        // V1.6.23 Phase 2 - per-trade profit retention.
        // This is a secondary floor layered on top of the existing staged
        // trailing. It can only IMPROVE the stop; never loosen it.
        // The tiers are expressed in R (initial trade risk) so they adapt
        // automatically to quantity and configured stop size.
        private const double ProfitRetentionStage1TriggerR = 1.20;
        private const double ProfitRetentionStage1Factor = 0.40;
        private const double ProfitRetentionStage2TriggerR = 1.40;
        private const double ProfitRetentionStage2Factor = 0.50;
        private const double ProfitRetentionStage3TriggerR = 1.80;
        private const double ProfitRetentionStage3Factor = 0.60;

        // V1.6.23 Phase 3 - Reversal Guard. Once a trade has already
        // produced useful MFE, a confirmed opposite context may tighten
        // protection. It never reverses the position and never loosens SL.
        private const double ReversalGuardMinPeakR = 0.50;
        private const int ReversalGuardMinFavorableTicks = 20;
        private const int ReversalGuardMinContextScore = 4;
        private const int ReversalGuardMinOppositeMomentumScore = 3;
        private const double ReversalGuardPeakRetentionFactor = 0.25;

        // V1.6.23 Phase 9 - Active Trade Intelligence.
        // If a trade has already produced >= 0.90R MFE and then gives back
        // >= 45% of its peak while still positive, retain at least 30% of
        // the peak. This is a secondary protection layer and can ONLY
        // improve an existing stop.
        private const double ProfitGivebackGuardMinPeakR = 0.90;
        private const double ProfitGivebackGuardTriggerPercent = 0.45;
        private const double ProfitGivebackGuardRetentionFactor = 0.30;

        // Hard anti-chase cap for an aggressive signal late in a mature leg.
        // Fresh aggressive expansion remains eligible; only a signal that is
        // BOTH deeply extended from EMA9 AND already inside a mature session
        // move is converted to Smart Retest / pullback wait.
        private const double AggressiveMatureMoveMinTicks = 800.0;
        private const double AggressiveMaxEmaExtensionTicks = 100.0;

        // Once the daily target is reached, protect most of it
        // instead of immediately flattening a profitable runner.
        private const double DailyTargetGivebackDollars = 50.0;
        private const int DailyTargetTrailDistanceTicks = 20;

        // V1.6.4 dynamic daily/session profit floor.
        // Once the day has reached at least $50 (or 20% of the configured
        // daily target, whichever is greater), retain 50% of the best
        // total PnL reached. Example: peak +$60 => protected floor +$30.
        private const double DailyProfitFloorActivationMinDollars = 50.0;
        private const double DailyProfitFloorTargetActivationFactor = 0.20;
        private const double DailyProfitFloorRetentionFactor = 0.50;
        private const double DailyProfitFloorLogStepDollars = 10.0;

        // Force flat at 16:25 ET for prop-firm safety.
        private const int ForceFlatTimeNy = 162500;
        // V1.6.14: a new CME-style trading/risk session begins at 18:00 ET.
        // FORCE FLAT and all session-scoped counters/profit protection are released here.
        private const int TradingSessionResetTimeNy = 180000;

        // =====================================================
        // BACKGROUND ENGINE WINDOW LIFECYCLE
        // =====================================================
        private bool allowPermanentClose;
        private bool engineWindowAlive;

        public bool IsEngineWindowAlive
        {
            get
            {
                return engineWindowAlive;
            }
        }

        // =====================================================
        // CONSTRUCTOR
        // =====================================================
        public JJBotWindow(
            string profileId = "profile-1",
            bool isPrimaryProfileWindow = true)
        {
            platformProfileId =
                string.IsNullOrWhiteSpace(
                    profileId
                )
                    ? "profile-1"
                    : profileId
                        .Trim()
                        .ToLowerInvariant();

            primaryProfileWindow =
                isPrimaryProfileWindow;

            Caption =
                "J&J NY Trading Bot - "
                + platformProfileId;

            allowPermanentClose = false;
            engineWindowAlive = true;

            Width = 520;
            Height = 960;

            MinWidth = 480;
            MinHeight = 720;

            botRunning = false;
            activeDirection = "BOTH";
            activeStrategyMode = "HYBRID";
            autoResolvedDirection = "BOTH";
            autoDirectionReason = "MANUAL BOTH";
            lastLoggedAutoDirection = string.Empty;
            lastLoggedAutoDirectionReason = string.Empty;
            lastAutoDirectionLogUtc = DateTime.MinValue;

            currentSignalState =
                "WAITING";

            currentSetupState =
                "WAITING";

            activeContracts = 1;
            activeStopTicks = 100;
            activeTargetTicks = 150;
            activeMaxTrades = 2;
            activeDailyTarget = 300;
            activeDailyLoss = 200;
            activeDollarRiskCap = 100;

            tradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
            pendingEntryRequestedQuantity = 0;
            pendingEntryIsManualTest = false;
            activeTradeIsManualTest = false;

            pendingEntryIsOpening = false;
            activeTradeIsOpening = false;
            pendingEntryIsPremarket = false;
            activeTradeIsPremarket = false;
            openingTradeTakenToday = false;
            openingRangeReady = false;
            openingRangeHigh = 0;
            openingRangeLow = 0;
            openingRangeBarTimeNy = DateTime.MinValue;

            premarketRangeReady = false;
            premarketRangeHigh = 0;
            premarketRangeLow = 0;
            premarketRangeDateNy = DateTime.MinValue;
            premarketRangeLastM5TimeNy = DateTime.MinValue;
            lastPremarketChaseBlockLogKey = string.Empty;
            premarketContextReady = false;
            premarketContextDateNy = DateTime.MinValue;
            premarketContextBias = "NEUTRAL";
            premarketContextBiasScore = 0;
            lastPremarketContextLogNy = DateTime.MinValue;
            lastPremarketContextFinalLogDateNy = DateTime.MinValue;
            pendingSmartRetestActive = false;
            pendingSmartRetestReason = string.Empty;
            pendingSmartRetestStructureSetupKey = string.Empty;
            lastSmartRetestLogKey = string.Empty;

            preEntryRangeReady = false;
            preEntryRangeHigh = 0;
            preEntryRangeLow = 0;
            preEntryRangeDateNy = DateTime.MinValue;
            openingRangeGuardBlocked = false;
            openingRangeGuardReason = string.Empty;
            openingRangeGuardDateNy = DateTime.MinValue;
            lastLateEntryBlockLogKey = string.Empty;
            openingRangeLoggedDate = DateTime.MinValue;

            botDailyGrossPnL = 0;
            botDailyFees = 0;
            botDailyPnL = 0;
            botUnrealizedPnL = 0;
            dailyPeakTotalPnL = 0;
            dailyProtectedProfitFloor = 0;
            dailyProfitFloorArmed = false;
            lastLoggedProtectedProfitFloor = 0;
            activeTradingDate = DateTime.MinValue;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;
            lastLearningBlockedLogKey = string.Empty;

            lastAutomaticTradeExitNy =
                DateTime.MinValue;

            lastAutomaticTradeExitRangeBarTime =
                DateTime.MinValue;

            lastAutomaticTradeExitWasBreakeven =
                false;

            lastReentryBlockLogKey =
                string.Empty;

            lastPriceChaseBlockLogKey =
                string.Empty;

            lastOpeningContextBlockLogKey =
                string.Empty;

            lastOpeningAntiChaseOverrideLogKey =
                string.Empty;

            lastOpeningStabilityBlockLogKey =
                string.Empty;

            lastOpeningCounterTrendBlockLogKey =
                string.Empty;

            lastOpeningSameSetupBlockLogKey =
                string.Empty;

            entryPending = false;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;

            activeEntryUsesMomentumTrailing = false;
            momentumTrailingStage = 0;
            lastMomentumTrailingStopPrice = 0;
            activeStrongMomentumProtection = false;
            activeBreakEvenTriggerTicks =
                MomentumBreakEvenTriggerTicks;
            lastMomentumTrailingChangeUtc = DateTime.MinValue;
			
            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;
            lastDailyTargetProtectionChangeUtc = DateTime.MinValue;

            smartScaleInUsed = false;
            smartScaleInPending = false;
            smartScaleInOrder = null;
            initialTradeQuantity = 0;
            initialTradeRiskDollars = 0;
            lastSmartScaleInAttemptUtc = DateTime.MinValue;

            protectiveChangeInFlight = false;
            protectiveBracketBuildInProgress = false;
            protectiveChangeSequence = 0;
            activeProtectiveChangeToken = 0;
            protectiveChangeOwner = string.Empty;
            protectiveChangeStartedUtc =
                DateTime.MinValue;

            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;
            premarketForceFlatSentToday = false;
            premarketForceFlatDateNy = DateTime.MinValue;

            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            activeTradeMfeDollars = 0;
            activeTradeMaeDollars = 0;
            activeTradePeakPnlDollars = 0;
            activeTradeCurrentPrice = 0;
            activeTradeUnrealizedPnl = 0;
            activeTradeOriginalStopPrice = 0;
            activeTradeOriginalTargetPrice = 0;
            activeProfitRetentionStage = 0;
            activeProfitRetentionFactor = 0;
            activeReversalGuardArmed = false;
            lastReversalGuardLogKey = string.Empty;
            activeGivebackGuardArmed = false;
            lastGivebackGuardLogKey = string.Empty;
            activeTradeExitReason = string.Empty;
            activeForcedExitReason = string.Empty;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            lastExecutedSignalBar = DateTime.MinValue;

            subscribedAccount = null;

            visualLogLines =
                new Queue<string>();

            platformTelemetryTimer = null;
            platformTelemetryRequestInFlight = false;
            platformApiKey = string.Empty;
            platformServerUrl = "http://localhost:3001";
            platformConfigFile = string.Empty;
            lastPlatformTelemetrySuccessUtc =
                DateTime.MinValue;

            platformCommandTimer = null;
            platformCommandRequestInFlight = false;
            lastProcessedPlatformCommandId =
                string.Empty;

            platformRemoteStartContext =
                false;

            PrintBotMessage(
                "PROFILE ENGINE READY"
                + " | "
                + platformProfileId
                + " | Prefix: "
                + GetProfileOrderPrefix()
            );

            persistentDailyLocked = false;
            persistentDailyLockReason = string.Empty;

            activeRuntimeLeaseKey =
                string.Empty;

            stateFolderPath =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments
                    ),
                    "NinjaTrader 8",
                    "JJBotData"
                );

            barsReady = false;
            barsRequestSubscribed = false;
            lastSignalBarTime = DateTime.MinValue;

            h1BarsReady = false;
            h1BarsRequestSubscribed = false;
            lastH1BarTime = DateTime.MinValue;

            h4BarsReady = false;
            h4BarsRequestSubscribed = false;
            lastH4BarTime = DateTime.MinValue;

            rangeBarsReady = false;
            rangeBarsRequestSubscribed = false;
            lastRangeBarTime = DateTime.MinValue;

            latestH4Trend = "WAITING";
            latestH1Trend = "WAITING";
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;
            latestHtfContextBias = "NEUTRAL 0/2";

            latestDirectionalPressure = "NEUTRAL";
            latestDirectionalLongPressureScore = 0;
            latestDirectionalShortPressureScore = 0;
            lastDirectionalPressureLogKey = string.Empty;
            lastDirectionalSafetyBlockKey = string.Empty;

            latestM5ContextReady = false;
            latestM5LiquidityState = "NONE";
            latestM5StructureState = "WAITING";
            latestRangeMomentumState = "WAITING RANGE";

            baseLearningMemory =
                new JJBotLearningMemory();

            userLearningMemory =
                new JJBotLearningMemory();

            learningMemory =
                new JJBotLearningMemory();

            learningBaseVersion =
                "NONE";

            activeLearningTrade = null;
            activeLearningEventKey = string.Empty;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            Content = BuildInterface();

            Closing += OnBotWindowClosing;
            Closed += OnBotWindowClosed;

            LoadPlatformBridgeConfig();
            StartPlatformTelemetry();
            StartPlatformCommandPolling();
        }

        // =====================================================
        // MAIN INTERFACE
        // =====================================================
        // =====================================================
        // ACCOUNT CHANGED
        // =====================================================
        // =====================================================
        // INSTRUMENT CHANGED
        // =====================================================
        // =====================================================
        // TEST LONG / SHORT
        // SIM ONLY
        // =====================================================
        // =====================================================
        // START BOT
        // =====================================================
        // =====================================================
        // START 5-MINUTE DATA ENGINE
        // =====================================================
        // =====================================================
        // INITIAL HISTORICAL BARS LOADED
        // =====================================================
        // =====================================================
        // INITIAL 1H CONTEXT BARS LOADED
        // =====================================================
        // =====================================================
        // INITIAL 4H CONTEXT BARS LOADED
        // =====================================================
        // =====================================================
        // INITIAL INTERNAL RANGE BARS LOADED
        // =====================================================
        // =====================================================
        // REAL-TIME 1H CONTEXT UPDATE EVENT
        // =====================================================
        // =====================================================
        // REAL-TIME 4H CONTEXT UPDATE EVENT
        // =====================================================
        // =====================================================
        // HIGHER-TIMEFRAME CONTEXT ENGINE
        //
        // Uses the latest CLOSED 1H / 4H bar.
        // Trend model:
        //   Strong bullish: Close > EMA50 > EMA200
        //   Strong bearish: Close < EMA50 < EMA200
        //   Weak bullish:   EMA50 > EMA200
        //   Weak bearish:   EMA50 < EMA200
        //
        // IMPORTANT: this context does NOT block entries in V1.
        // It is published visually and available to learning.
        // =====================================================
        // =====================================================
        // REAL-TIME INTERNAL RANGE UPDATE EVENT
        // =====================================================
        // =====================================================
        // REAL-TIME BAR UPDATE EVENT
        // =====================================================
        // =====================================================
        // CALCULATE EMA 9 / EMA 50
        // =====================================================
        // =====================================================
        // V12 - OPENING MODE HELPERS
        // =====================================================
        // =====================================================
        // V1.6.8 PREMARKET RANGE
        // =====================================================
        // =====================================================
        // V1.6.11 - PREMARKET CONTEXT ENGINE
        // =====================================================
        // =====================================================
        // SIM EXECUTION ENGINE
        // =====================================================
        // =====================================================
        // PERSISTENT DAILY STATE
        // =====================================================
        private JJBotDailyStateData
            LoadPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return null;
            }

            string accountName =
                selectedAccount.Name;

            string instrumentName =
                selectedInstrument.FullName;

            string filePath =
                GetPersistentStateFilePath(
                    accountName,
                    instrumentName
                );

            string backupPath =
                filePath + ".bak";

            object persistenceLock =
                JJBotRuntimeCoordinator.GetPersistenceLock(
                    accountName,
                    instrumentName
                );

            lock (persistenceLock)
            {
                if (
                    string.IsNullOrWhiteSpace(
                        filePath
                    )
                )
                {
                    return null;
                }

                // Primary file first.
                if (File.Exists(filePath))
                {
                    try
                    {
                        return DeserializeDailyStateFile(
                            filePath
                        );
                    }
                    catch (Exception primaryEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD PRIMARY ERROR: "
                            + primaryEx.Message
                            + " | TRYING BACKUP."
                        );
                    }
                }

                // Automatic recovery from last known-good backup.
                if (File.Exists(backupPath))
                {
                    try
                    {
                        JJBotDailyStateData recovered =
                            DeserializeDailyStateFile(
                                backupPath
                            );

                        PrintBotMessage(
                            "STATE RECOVERED FROM BACKUP: "
                            + backupPath
                        );

                        return recovered;
                    }
                    catch (Exception backupEx)
                    {
                        PrintBotMessage(
                            "STATE LOAD BACKUP ERROR: "
                            + backupEx.Message
                        );
                    }
                }

                return null;
            }
        }

        private JJBotDailyStateData
            DeserializeDailyStateFile(
                string filePath)
        {
            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(
                        JJBotDailyStateData
                    )
                );

            using (
                FileStream stream =
                    new FileStream(
                        filePath,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read
                    )
            )
            {
                return serializer.Deserialize(
                    stream
                ) as JJBotDailyStateData;
            }
        }

        // =====================================================
        // V1.6.14 - CME-STYLE TRADING SESSION DATE
        // =====================================================
        // Session label semantics:
        // - Sunday 18:00 ET -> Monday session
        // - Monday 18:00 ET -> Tuesday session
        // - ...
        // - Thursday 18:00 ET -> Friday session
        // - Friday after 18:00, Saturday and Sunday before 18:00 stay on
        //   the Friday session because there is no new CME equity-index session.
        //
        // This lets the 16:25 ET FORCE FLAT lock expire at the next real
        // 18:00 ET session boundary instead of waiting for midnight.
        // =====================================================
        // V15.1 - PROFILE ORDER OWNERSHIP
        // =====================================================
        // =====================================================
        // V1.6.20 - DIRECTIONAL PRESSURE ENGINE
        // =====================================================
        // 4 components: confirmed M5 trend, VWAP side, R20 advantage,
        // and HTF advantage. Strong pressure needs 3+ aligned components
        // while the opposite side has at most 1.
        // =====================================================
        // ACCOUNT ORDER UPDATE
        //
        // Keeps the monitor synchronized with the REAL working
        // stop/target orders. If the user drags SL or TP on the
        // chart, NinjaTrader raises OrderUpdate and the monitor
        // refreshes immediately.
        // =====================================================
        // =====================================================
        // DYNAMIC PROFIT TARGET
        //
        // The user configured TP is treated as the MAXIMUM.
        // Strong context keeps 100%, medium uses 80%, weak uses 65%.
        // =====================================================
        // =====================================================
        // V1.6.4 - CENTRAL NEVER-WORSEN STOP GUARD
        // =====================================================
        // Every protective module can tighten risk, but no module may
        // ever move a protected stop back toward greater risk.
        // =====================================================
        // MOMENTUM CAPITAL PROTECTION V1
        //
        // Applies ONLY to entries whose learning context contains
        // "MOMENTUM" (including STRUCTURE+MOMENTUM).
        //
        // Stage 1: +40 ticks  -> stop to break even
        // Stage 2: +70 ticks  -> lock +30 ticks
        // Stage 3: +100 ticks -> continuously trail 40 ticks
        //
        // The stop is NEVER moved backwards.
        // =====================================================
        // =====================================================
        // V14 - SMART SCALE-IN V1
        // =====================================================
        // =====================================================
        // DAILY TARGET PROTECTION
        //
        // Once total bot PnL reaches the configured daily target,
        // stop opening new trades and trail the current winner while
        // protecting approximately DailyTargetGivebackDollars.
        // =====================================================
        // =====================================================
        // PROP-FIRM FORCE FLAT
        // =====================================================
        // =====================================================
        // V1.6.4 - DYNAMIC DAILY / SESSION PROFIT FLOOR
        // =====================================================
        // Returns true when the REAL account position for the selected
        // instrument is flat. This deliberately does not rely only on the
        // bot's internal entryMarketPosition flag.
        // =====================================================
        // V1.6.14R - POSITION RECOVERY / TRAILING RESUME
        //
        // Safety goal:
        // If the app/bot is restarted while NinjaTrader still has an
        // open position for the selected Account + Instrument, adopt the
        // real account position instead of treating the bot as flat.
        //
        // The method:
        // 1) reads the REAL account position,
        // 2) re-attaches the existing profile STOP/TARGET when present,
        // 3) restores the internal entry/qty/side state,
        // 4) derives the trailing stage from the CURRENT stop so that a
        //    restart can NEVER move protection backwards,
        // 5) if no complete bracket exists, SyncProtectiveBracketToEntry
        //    rebuilds protection using the existing safety logic.
        //
        // It deliberately does NOT increment session trade counters and
        // does NOT create a new Learning trade. This is adoption of an
        // already-open position, not a new entry.
        // =====================================================
        // =====================================================
        // V1.6.14R2 - DELAYED POSITION RECOVERY RETRY
        // =====================================================
        // =====================================================
        // LIQUIDITY SWEEP + BOS / CHOCH
        //
        // LONG SEQUENCE:
        // 1) A closed bar trades below the lowest low of the
        //    previous SweepLookback bars.
        // 2) That same bar closes back ABOVE that prior low.
        //    -> LOW SWEPT
        // 3) Within SweepMaxAgeBars, price CLOSES above the
        //    pre-sweep structure high.
        //    -> BULLISH BOS / CHOCH
        //
        // SHORT is the inverse.
        // =====================================================
        // =====================================================
        // HIGHEST HIGH IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        // =====================================================
        // LOWEST LOW IN ABSOLUTE BAR INDEX RANGE
        // =====================================================
        // =====================================================
        // SESSION VWAP
        //
        // This is a 5-minute OHLCV session VWAP calculation:
        // TypicalPrice = (High + Low + Close) / 3
        // weighted by each 5-minute bar's volume.
        //
        // VWAP starts at 09:30 New York time each day.
        // =====================================================
        // =====================================================
        // RANGE MOMENTUM TRIGGER ENGINE
        // =====================================================
        // =====================================================
        // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE ENGINE
        // =====================================================
        // =====================================================
        // V1.6.11 - SMART RETEST HELPERS
        // =====================================================
        // =====================================================
        // V1.6.9 - AGGRESSION / EXHAUSTION HELPERS
        // =====================================================
        // =====================================================
        // MOMENTUM ENGINE V2 - RANGE SERIES
        // =====================================================
        // =====================================================
        // EMA CALCULATION
        //
        // BarsRequest data cannot be passed directly into
        // NinjaTrader indicators, so EMA is calculated here.
        // =====================================================
        // =====================================================
        // STOP BOT
        // =====================================================
        // =====================================================
        // V10 - REMOTE CLOSE ALL CONTEXT RESOLUTION
        // =====================================================
        // =====================================================
        // CLOSE ALL
        // TEST MODE ONLY - DOES NOT SEND ORDERS
        // =====================================================
        // =====================================================
        // STOP / DISPOSE DATA ENGINE
        // =====================================================
        // =====================================================
        // ERROR STATE
        // =====================================================
        // =====================================================
        // RESET SIGNAL DISPLAY
        // =====================================================
        // =====================================================
        // BACKGROUND MODE
        // =====================================================
        // Clicking X hides only the control panel. The bot engine,
        // BarsRequests, telemetry and remote command polling continue.
        // =====================================================
        // WINDOW CLEANUP
        // =====================================================
        // =====================================================
        // INVALID VALUE MESSAGE
        // =====================================================
        // =====================================================
        // PRICE FORMAT
        // =====================================================
        // =====================================================
        // OUTPUT
        // =====================================================
        // =====================================================
        // PUBLISH REAL ADDON STATE TO JJBotChart
        // =====================================================
        // =====================================================
        // J&J COMPANY BRO PLATFORM TELEMETRY
        // =====================================================
        // V1.6.12 - send credentials in the standard Authorization header.
        // Legacy apiKey body/query compatibility is intentionally retained
        // until the localhost backend is upgraded to accept header-only auth.
        // Removing the legacy field before that server change would break the
        // existing bridge, so this is a backward-compatible migration step.
        // =====================================================
        // J&J COMPANY BRO - REMOTE BOT COMMANDS
        // =====================================================
        // =====================================================
        // VISUAL LOG
        // Thread-safe: BarsRequest, OrderUpdate and ExecutionUpdate
        // can call this method from non-UI threads.
        // =====================================================
        // =====================================================
        // CARD
        // =====================================================
        // =====================================================
        // SECTION TITLE
        // =====================================================
        // =====================================================
        // SMALL STATUS TEXT
        // =====================================================
        // =====================================================
        // TEXTBOX
        // =====================================================
        // =====================================================
        // LABEL + CONTROL ROW
        // =====================================================
        // =====================================================
        // INFO TEXT
        // =====================================================
        // =====================================================
        // BUTTON
        // =====================================================
    }
}

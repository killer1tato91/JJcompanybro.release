#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{

    // =========================================================
    // V1.7.35 - CORE20 ZONE BUS (visual only)
    // =========================================================
    // The bot publishes the zones it actually uses and every trigger it
    // evaluated (ENTRY / SKIP + reason) so JJBotChart can draw them.
    // Read-only for the chart: it never affects trading.
    public sealed class JJCore20ZoneInfo
    {
        public string Name;
        public double Price;
        public bool IsHigh;
        public bool Swept;
        public bool SweepUsed;
        public bool BreakUsed;
    }

    public sealed class JJCore20EventInfo
    {
        public string Key;
        public DateTime BarTime;     // same time zone as chart bars
        public string Zone;
        public double ZonePrice;
        public string Trigger;       // SWEEP / BREAK
        public bool IsLong;
        public double Price;
        public double Delta;
        public string Decision;      // ENTRY / SKIP - reason
    }

    public sealed class JJCore20ZoneSnapshot
    {
        public string InstrumentName;
        public DateTime SessionDateNy;
        public List<JJCore20ZoneInfo> Zones = new List<JJCore20ZoneInfo>();
        public List<JJCore20EventInfo> Events = new List<JJCore20EventInfo>();
        public long Version;
    }

    public static class JJCore20ZoneBus
    {
        private static readonly object Sync = new object();
        private static readonly Dictionary<string, JJCore20ZoneSnapshot> ByInstrument =
            new Dictionary<string, JJCore20ZoneSnapshot>(StringComparer.OrdinalIgnoreCase);

        public static event Action<string> Changed;

        private static JJCore20ZoneSnapshot GetOrCreate(string instrument, DateTime sessionDateNy)
        {
            JJCore20ZoneSnapshot snap;
            if (!ByInstrument.TryGetValue(instrument, out snap) || snap == null || snap.SessionDateNy != sessionDateNy)
            {
                snap = new JJCore20ZoneSnapshot { InstrumentName = instrument, SessionDateNy = sessionDateNy };
                ByInstrument[instrument] = snap;
            }
            return snap;
        }

        public static void PublishZones(string instrument, DateTime sessionDateNy, IEnumerable<JJCore20ZoneInfo> zones)
        {
            if (string.IsNullOrWhiteSpace(instrument)) return;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap = GetOrCreate(instrument, sessionDateNy);
                snap.Zones = zones == null ? new List<JJCore20ZoneInfo>() : zones.ToList();
                snap.Version++;
            }
            Raise(instrument);
        }

        public static void PublishEvent(string instrument, DateTime sessionDateNy, JJCore20EventInfo ev)
        {
            if (string.IsNullOrWhiteSpace(instrument) || ev == null) return;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap = GetOrCreate(instrument, sessionDateNy);
                JJCore20EventInfo existing = snap.Events.FirstOrDefault(e => e.Key == ev.Key);
                if (existing == null)
                    snap.Events.Add(ev);
                else if (ev.Decision == "ENTRY")
                    existing.Decision = "ENTRY";   // several profiles: keep the executed view
                snap.Version++;
            }
            Raise(instrument);
        }

        public static JJCore20ZoneSnapshot GetSnapshot(string instrument)
        {
            if (string.IsNullOrWhiteSpace(instrument)) return null;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap;
                if (!ByInstrument.TryGetValue(instrument, out snap) || snap == null) return null;
                return new JJCore20ZoneSnapshot
                {
                    InstrumentName = snap.InstrumentName,
                    SessionDateNy = snap.SessionDateNy,
                    Version = snap.Version,
                    Zones = snap.Zones.Select(z => new JJCore20ZoneInfo { Name = z.Name, Price = z.Price, IsHigh = z.IsHigh, Swept = z.Swept, SweepUsed = z.SweepUsed, BreakUsed = z.BreakUsed }).ToList(),
                    Events = snap.Events.Select(e => new JJCore20EventInfo { Key = e.Key, BarTime = e.BarTime, Zone = e.Zone, ZonePrice = e.ZonePrice, Trigger = e.Trigger, IsLong = e.IsLong, Price = e.Price, Delta = e.Delta, Decision = e.Decision }).ToList()
                };
            }
        }

        private static void Raise(string instrument)
        {
            Action<string> handler = Changed;
            if (handler == null) return;
            foreach (Delegate d in handler.GetInvocationList())
            {
                try { ((Action<string>)d)(instrument); } catch { }
            }
        }
    }

    // =========================================================
    // V1.7.33 - JJ BOT CORE20 (FINAL)
    // =========================================================
    // EXECUTION: NY AM 09:30-12:00 only (max 6 trades until Daily Target, session counter).
    // V1.7.35: runs on the V1.7.31 Single Central Signal Authority. TrySubmitEntry
    // proposes the CORE20 candidate; every profile receives the SAME DecisionId
    // and applies only its own account/CORE20 rules.
    //
    // Before 09:30 the bot maps four ZONES:
    //   ONH / ONL = overnight high/low (18:00 prev day -> 09:30)
    //   PDH / PDL = prior RTH high/low (09:30 -> 16:00)
    //
    // Two triggers per zone (each used once per day), evaluated on the
    // CLOSE of every 1-minute bar:
    //   SWEEP : price traded >= 8 ticks beyond the zone and a 1m bar
    //           closes back inside           -> trade AGAINST the sweep.
    //   BREAK : a 1m bar closes >= 8 ticks beyond the zone
    //                                         -> trade WITH the break.
    // Level 2 confirmation (mandatory): net aggressive tape volume of the
    // last 60 s (Last>=Ask buys minus Last<=Bid sells) must favour the
    // trade side. Otherwise the trigger is skipped and consumed.
    //
    // MANAGEMENT (no partials, no scale-in):
    //   - Initial stop = configured Stop (recommended 60 ticks).
    //   - Profit retention: once peak MFE >= 30 ticks the stop trails at
    //     30% of the peak (never loosens).
    //   - The DAY closes when realized + open PnL reaches the Daily Target
    //     (existing Daily Target hard close, set by Mission in the app).
    //   - Time exit after 60 minutes.
    //   - Day stops after 2 losing CORE20 trades (or Daily Loss).
    //
    // OBSERVE ONLY (logged, never executed):
    //   - PM 14:00-15:45 Range-60 breakout fade.
    //   - AM continuation: Range-60 break in the direction of the day's
    //     first zone break.
    //   - AM defended zone: touch without break, close back away.
    //
    // Orders always go through TrySubmitEntry(): license, session limits,
    // Daily Target/Loss, risk cap, flat position, Final Entry Authority
    // and the atomic submit remain authoritative.
    // =========================================================
    public partial class JJBotWindow
    {
        private const string Core20StrategyName = "CORE20";
        private const int Core20ZoneTicks = 8;
        private const int Core20DefendTouchTicks = 4;
        private const int Core20DefendLookBars = 3;
        private const int Core20DeltaWindowSeconds = 60;
        private const int Core20RetentionStartTicks = 30;
        private const double Core20RetentionFactor = 0.30;
        private const int Core20MaxLossesPerDay = 2;
        private const int Core20MaxHoldMinutes = 60;
        // V1.7.48 - CORE20 AM zones use their OWN tested SL/PT (like Open Bell
        // and 15:30). The profile Stop/Target fields no longer change CORE20.
        // 50-day tick grid: SL 60t was the best of 40-160t; PT 160t.
        private const int Core20AmStopTicks = 60;
        private const int Core20AmTargetTicks = 160;
        private bool core20AmTradeActive;
        // V1.7.36 - EVAL SCALE: add (Max Contracts - Contracts) once the trade
        // is +25 ticks, then every contract is protected at entry +10 ticks.
        // Enabled with Scale-In ON and Max Contracts > Contracts.
        private const int Core20ScaleAtTicks = 25;
        private const int Core20ScaleLockTicks = 10;
        private const int Core20RangeTicks = 60;
        private const int Core20RangeLookbackBars = 20;
        private const int Core20MinuteBarsBack = 3000;
        private const int Core20RangeBarsBack = 400;
        private static readonly TimeSpan Core20AmStart = new TimeSpan(9, 30, 0);
        private static readonly TimeSpan Core20AmEnd = new TimeSpan(12, 0, 0);
		        // V1.7.37 - first RTH minute bars (close <= 09:32 NY) never open a CORE20 trade.
        private static readonly TimeSpan Core20NoEntryUntil = new TimeSpan(9, 32, 0);
        private static readonly TimeSpan Core20PmStart = new TimeSpan(14, 0, 0);
        private static readonly TimeSpan Core20PmEnd = new TimeSpan(15, 45, 59);
        private static readonly TimeSpan Core20RthEnd = new TimeSpan(16, 0, 0);
        private static readonly TimeSpan Core20LastExit = new TimeSpan(15, 55, 0);

        // V1.7.39 - CORE20 UNIFIED: AM CORE20 + 15:30 "last half hour" trade.
        // At 15:30 NY, if the Daily Target was not reached and CORE20 did not
        // already lose 2 trades, enter in the direction of the move from the
        // prior RTH close (16:00) to today's 10:00 price. Managed CAZA-style:
        // wide stop, no profit retention / scale-in; the Daily Target hard
        // close takes the profit and CORE20's 15:55 time exit closes the rest.
        // Tick backtest (50 days, 6 MNQ, target $250): CORE20 alone +$2,940,
        // 15/50 days at target; CORE20 + 15:30 (SL 30 pts, exit 15:55)
        // +$5,907, 36/50 days at target, max DD -$636.
        private const string Core20PmRoute = "CORE20_PM1530";
        private const int Core20PmStopTicks = 120;
        private static readonly int[,] Core20PmLadder = { { 40, 2 }, { 80, 40 } };
        private static readonly TimeSpan Core20PmEntryBarClose = new TimeSpan(15, 30, 0);
        private static readonly TimeSpan Core20PmDirectionTime = new TimeSpan(10, 0, 0);
        private DateTime core20PmDoneDate = DateTime.MinValue;
        private bool core20PmStopOverrideActive;
        private int core20PmSavedStopTicks;
        private DateTime core20PmOverrideUtc = DateTime.MinValue;
        private bool core20PmTradeActive;

        // V1.7.41 - OPEN BELL (Moonbound-style) bullet 0.
        // Range = high-low of 09:00:00-09:29:58 NY. At 09:29:58:
        //   range <  61 pts -> LONG,  range >= 61 pts -> SHORT.   (V1.7.49: 70 -> 61)
        // SL 134t, PT 122t (V1.7.49, = Moonbound), ladder: +20 pts -> lock +17 pts (further rungs kept
        // for larger PTs). Its result does not count as a CORE20 loss.
        // Tick backtest (50 days, 6 MNQ, target $300 / DL $400, with CORE20 +
        // 15:30): +$4,514 -> +$7,192, days at target 16 -> 30, max DD -$724 -> -$657.
        private const string Core20OpenBellRoute = "CORE20_OPENBELL";
        // V1.7.49 - threshold 70 -> 61 pts. 48-day 1-s backtest (SL134/TP122, 1c, real costs):
        // 61 -> +$1,132 (40/48 wins, PF 3.05); 70 -> +$656 (36/48, PF 1.79). The gain comes from the
        // 5 days with range 61-70 (SHORT won all 5): treat as UNVALIDATED until the 30-trade forward test.
        private const double Core20OpenBellRangeThresholdPts = 61.0;
        // V1.7.49 - fixed Open Bell size cap (eval accounts): 4 MNQ. Needs RiskCap >= ~$300 and
        // Daily Loss >= ~$300 on the account, otherwise the risk sizing cuts it below 4.
        // V1.7.60 - the fixed 4-MNQ cap is REMOVED: the Open Bell now trades the profile "Contracts"
        // value (user-configurable in the panel, up to MaxContractsAllowed). The real limits are the
        // existing safeties: Dollar Risk Cap (each contract risks 134t = $67), Daily Loss and the
        // daily profit floor. This constant is only the absolute ceiling.
        private const int Core20OpenBellMaxContracts = 20;
        // V1.7.42 - 48t (12 pts): centre of the 40-56t plateau, same net as 40t
        // with lower DD (-$459 vs -$519) and more room for live open noise/slippage.
        // V1.7.49 - SL 48t -> 134t (33.5 pts), TP 120t -> 122t: a 12-pt stop is shaken out by the
        // opening whipsaw (2026-10-01: SHORT stopped at 09:30:10, then fell 30 pts). Backtest 48 days
        // 1c: SL134/TP122 +$656 (36/48) vs SL48/TP120 +$530 (26/48) at threshold 70.
        private const int Core20OpenBellStopTicks = 134;
        // V1.7.74 - TP 122t -> 80t (20 pts): quick in/out. 119-day tick backtest, SHORT, SL134t, no averaging: win 45% -> 77%, PF 2.12 -> 1.91,
        // net $8,980 -> $8,454 (-6%). LONG with the same SL/TP: PF 1.07, net +$1,137 (weak, 1st half negative).
        private const int Core20OpenBellTargetTicks = 80;
        private static readonly int[,] Core20OpenBellLadder = { { 80, 68 }, { 132, 108 }, { 152, 140 }, { 240, 212 } };
        // V1.7.45 - INTRADAY-trailing profiles: break-even (+2t) at +12 pts first.
        // Full-bot tick backtest (4 MNQ, target $200 / DL $270, 25K / DD $1,000):
        // net +$4,290 -> +$4,616, eval burn 7.2% -> 3.2% (live at 70%).
        // V1.7.49 - the +12 pt break-even rung is REMOVED: with SL134 it halves the edge
        // (backtest 48d, thr 61: +$1,132 -> +$676, wins 40 -> 30). INTRADAY now uses the normal ladder.
        private static readonly int[,] Core20OpenBellLadderIntraday = { { 80, 68 }, { 132, 108 }, { 152, 140 }, { 240, 212 } };

        private bool IsIntradayDrawdownProfile()
        {
            return string.Equals((activeDrawdownMode ?? string.Empty).Trim(), "INTRADAY", StringComparison.OrdinalIgnoreCase);
        }
        private static readonly TimeSpan Core20OpenBellRangeStart = new TimeSpan(9, 0, 0);
        private static readonly TimeSpan Core20OpenBellEntryTime = new TimeSpan(9, 29, 58);
        private static readonly TimeSpan Core20OpenBellEntryDeadline = new TimeSpan(9, 30, 0);
        private DateTime core20ObDate = DateTime.MinValue;
        private double core20ObTickHigh = double.MinValue;
        private double core20ObTickLow = double.MaxValue;
        private TimeSpan core20ObFirstTickTod = TimeSpan.MaxValue; // V1.7.59: when the 09:00+ tick range started
        private bool core20ObFired;
        private TimeSpan core20ObLastTod = TimeSpan.MinValue;
        private bool core20ObTradeActive;

        // =====================================================================
        // V1.7.62 - OPEN BELL SHORT-ONLY + GERARD MODULE + PROMEDIADAS (all backtested)
        // Data: 253 days (Sep 2025 - Oct 2026), MNQ ticks 09:00-10:00 NY, costs and slippage included.
        //  * Open Bell: SHORT only (range >= 61). LONG (range < 61) is OFF: it lost money.
        //    One averaging (+4c, same size) at +80t, then the stop of everything goes to the
        //    combined average price (+1t). Replaces the old +80t->+68t ladder for this module.
        //    Backtest (4c): +$7,862 plain / +$7,578 ladder / +$11,718 with averaging @80t.
        //  * Gerard "acumulacion" (range 09:00-09:29:58 <= 60 pts): at 09:35 if the last price
        //    (close of the 09:30-09:35 candle) is OUTSIDE the range -> trade the break.
        //    Stop = other side of the range (10-150 pts), size = floor(RiskUSD / (stop * $/pt)),
        //    TP = 3R, ONE averaging (same size) at +1R, then stop of everything to the combined
        //    average (+1t). Backtest ($300 risk, 91 trades): +$6,645 plain / +$10,513 averaged.
        //  * Everything is flat at 10:00:00 NY. One Open Bell/Gerard trade per day.
        //  * Needs the profile Scale-in ON (the averaging uses the bot's scale-in engine).
        //  Sample caveat: ~25 variants tested, optimistic ticks - validate on demo (30 trades).
        // =====================================================================
        // V1.7.62 - CORE20 AM (sweep/break) and the 15:30 module are OFF: one trade per day is enough
        // (Open Bell or Gerard). Set to true to re-enable them. (15:30 lost in the 237-day tick test;
        // CORE20 AM could not be simulated.)
        private static readonly bool Core20AmEnabled = false;
        private static readonly bool Core20PmEnabled = false;
        // V1.7.72 - Open Bell LONG (range < 61) ENABLED by request (was SHORT-only). Set back to true to
        // return to SHORT-only. The 253-day backtest had LONG losing money - this is a forward test; the
        // OB SHADOW log keeps measuring it. Gerard may still trade the same day AFTER a closed Open Bell LONG.
        private const bool Core20OpenBellShortOnly = false;
        private bool core20ObLongToday;

        // V1.7.72 - Gerard protection before the +1R averaging: once the trade has run +0.6R the stop goes to
        // +0.1R (stops a +$150 winner from becoming a full loss, as on 2026-10-06). Backtest (96 days, ticks,
        // with the averaging): net $5,613 -> $5,973, win 39% -> 51%, max DD -$1,992 -> -$1,108.
        // Extra tiers/partials/trails were tested and LOWERED the result ($2.1k-$5.2k), so only this tier is used.
        private static readonly bool Core20GerardProtectEnabled = true;
        private const double Core20GerardProtectAtR = 0.6;
        private const double Core20GerardProtectLockR = 0.1;
        // V1.7.63 - Open Bell L2 contrary-flow veto (shared helper IsLevel2ContraryFlowVeto, same
        // definitions as the HYBRID impulse qualifier). 2026-10-05: SHORT 4 MNQ entered with tape
        // LONG / delta +205 against it and lost -$278 in 81 s. Fail-open if L2 is not ready.
        // Evidence is thin (3 days with a ready book) - set false for log-only (it still logs).
        private static readonly bool Core20OpenBellL2VetoEnabled = false;
        // V1.7.74 - averaging disabled (it sat exactly at the new 80t target); it never helped a 20-pt target.
        private const int Core20ObScaleAtTicks = 9999;
        private const string Core20GerardRoute = "CORE20_GERARD";
        private const double Core20GerardMaxRangePts = 60.0;
        private const double Core20GerardRiskUsd = 300.0;
        private const double Core20GerardMinStopPts = 10.0;
        private const double Core20GerardMaxStopPts = 150.0;
        private static readonly TimeSpan Core20GerardEvalTime = new TimeSpan(9, 35, 0);
        private static readonly TimeSpan Core20GerardLastEval = new TimeSpan(9, 40, 0);
        private static readonly TimeSpan Core20MorningFlat = new TimeSpan(10, 0, 0);
        private bool core20GdFired;
        private bool core20GdTradeActive;
        private bool core20GdHavePx35;
        private double core20GdLastPx35;
        private int core20GdStopTicks;
        private int core20GdTargetTicks;
        private int core20GdContracts;
        private bool core20DayTradeTaken;
        private bool core20TargetOverrideActive;
        private int core20SavedTargetTicks;

        private readonly object core20Sync = new object();

        private BarsRequest core20MinuteRequest;
        private DateTime core20MinuteWatchdogCheckUtc = DateTime.MinValue; // V1.7.59
        private DateTime core20MinuteRestartUtc = DateTime.MinValue;       // V1.7.59
        private BarsRequest core20RangeRequest;
        private bool core20MinuteSubscribed;
        private bool core20RangeSubscribed;
        private bool core20MinuteReady;
        private bool core20RangeReady;
        private int core20LastMinuteProcessed = -1;
        private int core20LastRangeProcessed = -1;

        private Instrument core20TapeInstrument;
        private bool core20TapeActive;
        private double core20LastBid;
        private double core20LastAsk;
        private readonly Queue<KeyValuePair<DateTime, double>> core20Tape =
            new Queue<KeyValuePair<DateTime, double>>();

        private DateTime core20LevelsDate = DateTime.MinValue;
        private readonly List<Core20Level> core20Levels = new List<Core20Level>();
        private int core20DayBreakDirection;

        // Trade tracking (losses per day, time exit, retention peak).
        private DateTime core20StatsDate = DateTime.MinValue;
        private int core20LossesToday;
        private bool core20TradeOpen;
        private double core20DayPnlAtOpen;
        private DateTime core20TradeOpenSinceNy = DateTime.MinValue;
        private double core20AnchorEntry;
        private int core20InitialQty;
        private bool core20ScaleSent;
        private double core20PeakTicks;
        private bool core20TimeExitSent;

        private string core20SetupStatus = "WAITING";
        private string core20TriggerStatus = "WAITING";

        private sealed class Core20Level
        {
            public string Name;
            public double Price;
            public bool IsHigh;
            public bool Swept;
            public bool SweepUsed;
            public bool BreakUsed;
            public int DefendTouchBar = -1;
            public bool DefendUsed;
        }

        // -----------------------------------------------------
        // Mode
        // -----------------------------------------------------
        // V1.7.75 - COMBINED profile: CORE20 (Open Bell + Gerard) owns the opening window
        // (09:00-10:00 NY, plus any CORE20 position still open) and HYBRID owns the rest of the
        // session until the Daily Target / Daily Loss. Each module keeps its own validated management:
        // IsCore20Mode() / IsEffectiveHybridMode() decide per moment which one is in charge.
        // Set the profile selector to "COMBINED" to use it; CORE20 and HYBRID profiles are unchanged.
        private const string CombinedStrategyName = "COMBINED";
        private static readonly TimeSpan CombinedCore20Start = new TimeSpan(9, 0, 0);
        private static readonly TimeSpan CombinedHybridStart = new TimeSpan(10, 0, 0);
        private static readonly TimeSpan CombinedStaleFlagGrace = new TimeSpan(0, 5, 0);

        private bool IsCombinedMode()
        {
            return string.Equals(activeStrategyMode, CombinedStrategyName, StringComparison.OrdinalIgnoreCase);
        }

        // CORE20 data engine (1m / range bars, tape, Open Bell timer) runs in CORE20 and COMBINED.
        private bool IsCore20EngineMode()
        {
            return IsCombinedMode()
                || string.Equals(activeStrategyMode, Core20StrategyName, StringComparison.OrdinalIgnoreCase);
        }

        // HYBRID signal engines (momentum / structure) run in HYBRID and COMBINED.
        private bool IsHybridFamilyMode()
        {
            return IsCombinedMode()
                || string.Equals(activeStrategyMode, "HYBRID", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsCore20TradeFlagActive()
        {
            return core20ObTradeActive || core20GdTradeActive || core20AmTradeActive || core20PmTradeActive;
        }

        // COMBINED: true while CORE20 is in charge (opening window, or a CORE20 trade still open).
        private bool Core20OwnsCombinedNow()
        {
            TimeSpan t = GetCurrentNewYorkTime().TimeOfDay;

            if (t >= CombinedCore20Start && t < CombinedHybridStart)
                return true;

            if (!IsCore20TradeFlagActive())
                return false;

            // CORE20 trade still managing right after 10:00 (e.g. Gerard flat at 10:00).
            if (t >= CombinedHybridStart && t < CombinedHybridStart + CombinedStaleFlagGrace)
                return true;

            // Stale flags never block HYBRID: outside the window CORE20 only owns an OPEN position.
            return !IsSelectedInstrumentFlat();
        }

        // True when the HYBRID module is the one in charge right now.
        private bool IsEffectiveHybridMode()
        {
            if (string.Equals(activeStrategyMode, "HYBRID", StringComparison.OrdinalIgnoreCase))
                return true;

            return IsCombinedMode() && !Core20OwnsCombinedNow();
        }

        private bool IsCore20Mode()
        {
            if (string.Equals(activeStrategyMode, Core20StrategyName, StringComparison.OrdinalIgnoreCase))
                return true;

            return IsCombinedMode() && Core20OwnsCombinedNow();
        }

        private bool IsCore20Strategy(string strategy)
        {
            return string.Equals(strategy, Core20StrategyName, StringComparison.OrdinalIgnoreCase);
        }

        private bool Core20DirectionAllows(bool isLong)
        {
            string direction = (activeDirection ?? "BOTH").Trim().ToUpperInvariant();

            if (direction == "LONG ONLY")
                return isLong;

            if (direction == "SHORT ONLY")
                return !isLong;

            return true;
        }

        private void Core20ResetDayIfNeeded(DateTime nyDate)
        {
            if (core20StatsDate == nyDate.Date)
                return;

            core20StatsDate = nyDate.Date;
            core20LossesToday = 0;
        }

        // -----------------------------------------------------
        // Start / stop (called from StartBarsEngine / StopBarsEngine)
        // -----------------------------------------------------
        private void StartCore20Engine()
        {
            StopCore20Engine();

            if (!IsCore20EngineMode() || selectedInstrument == null)
                return;

            lock (core20Sync)
            {
                core20MinuteReady = false;
                core20RangeReady = false;
                core20LastMinuteProcessed = -1;
                core20LastRangeProcessed = -1;
                core20LastBid = 0;
                core20LastAsk = 0;
                core20Tape.Clear();
            }

            core20LevelsDate = DateTime.MinValue;
            core20Levels.Clear();
            core20DayBreakDirection = 0;
            core20TradeOpen = false;
            core20TradeOpenSinceNy = DateTime.MinValue;
            core20PeakTicks = 0;
            core20TimeExitSent = false;
            core20SetupStatus = "WAITING DATA";
            core20TriggerStatus = "WAITING";

            try
            {
                core20MinuteRequest = new BarsRequest(selectedInstrument, Core20MinuteBarsBack);
                core20MinuteRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
                core20MinuteRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                core20MinuteRequest.Update += OnCore20MinuteUpdate;
                core20MinuteSubscribed = true;
                core20MinuteRequest.Request(new Action<BarsRequest, ErrorCode, string>(OnCore20MinuteCompleted));

                core20RangeRequest = new BarsRequest(selectedInstrument, Core20RangeBarsBack);
                core20RangeRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Range, Value = Core20RangeTicks };
                core20RangeRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                core20RangeRequest.Update += OnCore20RangeUpdate;
                core20RangeSubscribed = true;
                core20RangeRequest.Request(new Action<BarsRequest, ErrorCode, string>(OnCore20RangeCompleted));

                StartCore20Tape();

                PrintBotMessage(
                    "CORE20 ENGINE STARTED"
                    + " | AM 09:30-12:00: ZONE SWEEP / BREAK + DELTA " + Core20DeltaWindowSeconds + "s"
                    + " | SL " + activeStopTicks + "t | Retention " + (int)(Core20RetentionFactor * 100) + "% from +" + Core20RetentionStartTicks + "t"
                    + " | Day close: Daily Target / Daily Loss / " + Core20MaxLossesPerDay + " losses"
                    + " | PM + continuation + defended zone: OBSERVE ONLY"
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 START ERROR: " + ex.Message);
            }
        }

        private void StopCore20Engine()
        {
            StopCore20Tape();

            try
            {
                if (core20MinuteRequest != null)
                {
                    if (core20MinuteSubscribed)
                        core20MinuteRequest.Update -= OnCore20MinuteUpdate;

                    core20MinuteSubscribed = false;
                    core20MinuteRequest.Dispose();
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 MINUTE CLEANUP ERROR: " + ex.Message);
            }

            core20MinuteRequest = null;

            try
            {
                if (core20RangeRequest != null)
                {
                    if (core20RangeSubscribed)
                        core20RangeRequest.Update -= OnCore20RangeUpdate;

                    core20RangeSubscribed = false;
                    core20RangeRequest.Dispose();
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RANGE CLEANUP ERROR: " + ex.Message);
            }

            core20RangeRequest = null;

            lock (core20Sync)
            {
                core20MinuteReady = false;
                core20RangeReady = false;
            }
        }

        // -----------------------------------------------------
        // Tape (Level 2 time & sales): aggressor classification
        // -----------------------------------------------------
        private void StartCore20Tape()
        {
            core20TapeInstrument = selectedInstrument;
            core20TapeActive = true;

            Instrument instrument = core20TapeInstrument;

            instrument.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    if (core20TapeActive && core20TapeInstrument != null)
                        core20TapeInstrument.MarketData.Update += OnCore20MarketData;
                })
            );
        }

        private void StopCore20Tape()
        {
            Instrument oldInstrument = core20TapeInstrument;
            core20TapeActive = false;
            core20TapeInstrument = null;

            if (oldInstrument == null)
                return;

            oldInstrument.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    try
                    {
                        oldInstrument.MarketData.Update -= OnCore20MarketData;
                    }
                    catch
                    {
                    }
                })
            );
        }

        private void OnCore20MarketData(object sender, MarketDataEventArgs e)
        {
            if (!core20TapeActive || e == null)
                return;

            lock (core20Sync)
            {
                if (e.MarketDataType == MarketDataType.Bid)
                {
                    core20LastBid = e.Price;
                    return;
                }

                if (e.MarketDataType == MarketDataType.Ask)
                {
                    core20LastAsk = e.Price;
                    return;
                }

                if (e.MarketDataType != MarketDataType.Last)
                    return;

                double signedVolume = 0;

                if (core20LastAsk > 0 && e.Price >= core20LastAsk)
                    signedVolume = e.Volume;
                else if (core20LastBid > 0 && e.Price <= core20LastBid)
                    signedVolume = -e.Volume;

                if (signedVolume != 0)
                    core20Tape.Enqueue(new KeyValuePair<DateTime, double>(e.Time, signedVolume));

                DateTime cutoff = e.Time.AddSeconds(-(Core20DeltaWindowSeconds * 3));

                while (core20Tape.Count > 0 && core20Tape.Peek().Key < cutoff)
                    core20Tape.Dequeue();
            }

            // V1.7.41 - OPEN BELL clock (market-data time, works in Playback).
            if (e.MarketDataType == MarketDataType.Last)
                Core20OpenBellOnTick(e.Time, e.Price);
        }

        // V1.7.59 - 1m SERIES WATCHDOG
        // On 2026-10-02 the BarsRequest.Update events stopped at ~08:26 NY (after a ~90 s stall)
        // while ticks kept arriving, so every bar-driven module was blind (AM zones, Open Bell
        // range = 0 bars). If the newest 1m bar is more than 180 s behind the live tick time,
        // re-create the 1m request. Rate-limited; it does not touch orders or positions.
        private void Core20MinuteWatchdog(DateTime tickTime)
        {
            try
            {
                DateTime nowUtc = DateTime.UtcNow;

                if ((nowUtc - core20MinuteWatchdogCheckUtc).TotalSeconds < 20)
                    return;

                core20MinuteWatchdogCheckUtc = nowUtc;

                if (!core20MinuteReady || core20MinuteRequest == null)
                    return;

                if ((nowUtc - core20MinuteRestartUtc).TotalSeconds < 120)
                    return;

                Bars bars = core20MinuteRequest.Bars;

                if (bars == null || bars.Count < 3)
                    return;

                double staleSec = (ConvertToNewYorkTime(tickTime) - ConvertToNewYorkTime(bars.GetTime(bars.Count - 1))).TotalSeconds;

                if (staleSec <= 180)
                    return;

                core20MinuteRestartUtc = nowUtc;

                PrintBotMessage("CORE20 1M WATCHDOG | Series stale " + staleSec.ToString("0") + "s behind live ticks"
                    + " | Last bar NY " + ConvertToNewYorkTime(bars.GetTime(bars.Count - 1)).ToString("yyyy-MM-dd HH:mm:ss")
                    + " | Action: RE-REQUEST 1m bars");

                BarsRequest old = core20MinuteRequest;
                core20MinuteReady = false;

                try
                {
                    if (core20MinuteSubscribed)
                        old.Update -= OnCore20MinuteUpdate;

                    core20MinuteSubscribed = false;
                    old.Dispose();
                }
                catch (Exception exOld)
                {
                    PrintBotMessage("CORE20 1M WATCHDOG CLEANUP ERROR: " + exOld.Message);
                }

                BarsRequest fresh = new BarsRequest(selectedInstrument, Core20MinuteBarsBack);
                fresh.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
                fresh.TradingHours = TradingHours.Get("Default 24 x 7");
                fresh.Update += OnCore20MinuteUpdate;
                core20MinuteRequest = fresh;
                core20MinuteSubscribed = true;
                fresh.Request(new Action<BarsRequest, ErrorCode, string>(OnCore20MinuteCompleted));
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("CORE20 1M WATCHDOG ERROR (ignored): " + ex.Message); } catch { }
            }
        }

        private void Core20OpenBellOnTick(DateTime tickTime, double price)
        {
            bool fire = false;
            bool fireGd = false;
            DateTime ny = DateTime.MinValue;

            try
            {
                if (!IsCore20EngineMode() || !botRunning)
                    return;

                Core20MinuteWatchdog(tickTime);

                ny = ConvertToNewYorkTime(tickTime);
                TimeSpan tod = ny.TimeOfDay;

                lock (core20Sync)
                {
                    // V1.7.63 - also reset when the clock jumps BACK (Playback replay of the
                    // same day without closing the window): otherwise the Open Bell / Gerard
                    // "fired" flags of the previous run stayed true and nothing fired, silently.
                    bool core20ReplayRewind =
                        core20ObLastTod != TimeSpan.MinValue
                        && tod < core20ObLastTod - TimeSpan.FromMinutes(2);

                    if (core20ObDate != ny.Date || core20ReplayRewind)
                    {
                        core20ObLastTod = TimeSpan.MinValue;
                        core20ObDate = ny.Date;
                        core20ObTickHigh = double.MinValue;
                        core20ObTickLow = double.MaxValue;
                        core20ObFirstTickTod = TimeSpan.MaxValue;
                        core20ObFired = false;
                        core20GdFired = false;
                        core20GdHavePx35 = false;
                        core20GdLastPx35 = 0;
                        core20DayTradeTaken = false;
                        core20ObLongToday = false;
                    }

                    core20ObLastTod = tod;

                    // V1.7.62 - Gerard: last price up to 09:35:00 = close of the 09:30-09:35 candle.
                    if (tod >= Core20OpenBellRangeStart && tod <= Core20GerardEvalTime)
                    {
                        core20GdLastPx35 = price;
                        core20GdHavePx35 = true;
                    }

                    if (!core20GdFired && tod > Core20GerardEvalTime && tod <= Core20GerardLastEval)
                    {
                        core20GdFired = true;
                        fireGd = true;
                    }
                    else if (!core20GdFired && tod > Core20GerardLastEval)
                    {
                        core20GdFired = true;
                    }

                    if (tod >= Core20OpenBellRangeStart && tod < Core20OpenBellEntryTime)
                    {
                        if (core20ObFirstTickTod == TimeSpan.MaxValue) core20ObFirstTickTod = tod;
                        if (price > core20ObTickHigh) core20ObTickHigh = price;
                        if (price < core20ObTickLow) core20ObTickLow = price;
                    }

                    if (!core20ObFired && tod >= Core20OpenBellEntryTime && tod < Core20OpenBellEntryDeadline)
                    {
                        core20ObFired = true;
                        fire = true;
                    }
                    else if (!core20ObFired && tod >= Core20OpenBellEntryDeadline && tod < Core20AmStart.Add(TimeSpan.FromMinutes(1)))
                    {
                        // Missed the 09:29:58 window (no tick / bot started late).
                        core20ObFired = true;
                        PrintBotMessage("CORE20 OPEN BELL | SKIP - MISSED 09:29:58 WINDOW");
                    }
                }

                // V1.7.67 - feeds the log-only Open Bell shadow simulation (no orders).
                OpenBellShadowTick(ny, price);
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 OPEN BELL CLOCK ERROR: " + ex.Message);
                return;
            }

            if (fire)
                Core20TryOpenBell(tickTime, ny, price);

            if (fireGd)
                Core20TryGerard(tickTime, ny, price);
        }

        // V1.7.63 - pre-open context for the Open Bell (log only). Same features as the 277-day study:
        // PreVol (sum of 1m volume 09:01-09:29), AbsBars (volume > 1.5x mean with body < 30% of range),
        // Mom15 (price minus the 09:14 close), Delta10 (last 10 bars, close-location delta / volume),
        // Pos (price position inside the 09:00-09:29:58 range, 0 = low, 1 = high).
        private string Core20OpenBellContextSummary(Bars bars, DateTime ny, double hi, double lo, double price)
        {
            try
            {
                if (bars == null || bars.Count == 0)
                    return "CORE20 OPEN BELL CONTEXT | N/A (no 1m bars)";

                System.Collections.Generic.List<double[]> pre = new System.Collections.Generic.List<double[]>();
                TimeSpan start = Core20OpenBellRangeStart;
                TimeSpan end = new TimeSpan(9, 29, 0);

                for (int i = 0; i < bars.Count; i++)
                {
                    DateTime b = ConvertToNewYorkTime(bars.GetTime(i));
                    if (b.Date != ny.Date) continue;
                    if (b.TimeOfDay > start && b.TimeOfDay <= end)
                        pre.Add(new double[] { bars.GetOpen(i), bars.GetHigh(i), bars.GetLow(i), bars.GetClose(i), bars.GetVolume(i) });
                }

                if (pre.Count < 10)
                    return "CORE20 OPEN BELL CONTEXT | N/A (" + pre.Count + " bars)";

                double totalVol = 0.0;
                for (int i = 0; i < pre.Count; i++) totalVol += pre[i][4];
                double meanVol = totalVol / pre.Count;

                int absBars = 0;
                double delta10Num = 0.0, delta10Vol = 0.0;
                for (int i = 0; i < pre.Count; i++)
                {
                    double o = pre[i][0], h = pre[i][1], l = pre[i][2], c = pre[i][3], v = pre[i][4];
                    double r = h - l;
                    if (v > 1.5 * meanVol && r > 0.0 && Math.Abs(c - o) < 0.3 * r)
                        absBars++;
                    if (i >= pre.Count - 10)
                    {
                        if (r > 0.0) delta10Num += v * (c - o) / r;
                        delta10Vol += v;
                    }
                }

                double mom15 = pre.Count >= 15 ? price - pre[pre.Count - 15][3] : 0.0;
                double pos = hi > lo ? (price - lo) / (hi - lo) : 0.5;
                double delta10 = delta10Vol > 0.0 ? delta10Num / delta10Vol : 0.0;

                return "CORE20 OPEN BELL CONTEXT"
                    + " | PreVol " + totalVol.ToString("0")
                    + " | AbsBars " + absBars
                    + " | Mom15 " + mom15.ToString("+0.00;-0.00;0.00")
                    + " | Delta10 " + delta10.ToString("+0.00;-0.00;0.00")
                    + " | Pos " + pos.ToString("0.00")
                    + " | Bars " + pre.Count;
            }
            catch (Exception ex)
            {
                return "CORE20 OPEN BELL CONTEXT | ERROR " + ex.Message;
            }
        }

        private void Core20TryOpenBell(DateTime tickTime, DateTime ny, double price)
        {
            try
            {
                // Range from the 1m series (bars closing 09:01..09:29) plus the
                // live ticks tracked since 09:00, so a late bot start still has it.
                double hi = double.MinValue, lo = double.MaxValue;
                int minuteBars = 0;
                Bars bars = core20MinuteRequest != null ? core20MinuteRequest.Bars : null;

                if (bars != null)
                {
                    for (int i = bars.Count - 1; i >= 0; i--)
                    {
                        DateTime b = ConvertToNewYorkTime(bars.GetTime(i));

                        if (b.Date < ny.Date)
                            break;

                        if (b.Date == ny.Date && b.TimeOfDay > Core20OpenBellRangeStart && b.TimeOfDay <= new TimeSpan(9, 29, 0))
                        {
                            hi = Math.Max(hi, bars.GetHigh(i));
                            lo = Math.Min(lo, bars.GetLow(i));
                            minuteBars++;
                        }
                    }
                }

                bool tickCoverage;
                lock (core20Sync)
                {
                    if (core20ObTickHigh > double.MinValue) hi = Math.Max(hi, core20ObTickHigh);
                    if (core20ObTickLow < double.MaxValue) lo = Math.Min(lo, core20ObTickLow);

                    // V1.7.59 - the live tick range is complete when ticks were already
                    // arriving at 09:00-09:01. If the 1m series is stale/empty (it read 0 bars
                    // on 2026-10-02 although 3000 were loaded at start), the tick range alone
                    // is the full 09:00-09:29:58 range, so the Open Bell must not be skipped.
                    tickCoverage = core20ObFirstTickTod != TimeSpan.MaxValue
                        && core20ObFirstTickTod <= new TimeSpan(9, 1, 30);
                }

                if ((minuteBars < 20 && !tickCoverage) || hi <= lo || hi == double.MinValue || lo == double.MaxValue)
                {
                    string lastBarInfo = "n/a";
                    try
                    {
                        if (bars != null && bars.Count > 0)
                            lastBarInfo = ConvertToNewYorkTime(bars.GetTime(bars.Count - 1)).ToString("yyyy-MM-dd HH:mm:ss") + " (count " + bars.Count + ")";
                    }
                    catch { }

                    PrintBotMessage("CORE20 OPEN BELL | SKIP - RANGE DATA N/A | 1m bars " + minuteBars
                        + " | TickCoverage " + tickCoverage + " | LastBar NY " + lastBarInfo);
                    return;
                }

                if (minuteBars < 20)
                    PrintBotMessage("CORE20 OPEN BELL | RANGE FROM LIVE TICKS | 1m bars " + minuteBars
                        + " | Ticks since " + core20ObFirstTickTod.ToString(@"hh\:mm\:ss") + " NY");

                double rangePts = hi - lo;
                bool isLong = rangePts < Core20OpenBellRangeThresholdPts;

                // V1.7.67 - log-only shadow simulation (never touches orders): see JJBotOpenBellShadow.cs
                OpenBellShadowStart(ny, rangePts, price);

                // V1.7.63 - pre-open context log (volume / absorption-like bars / momentum / delta proxy)
                // so the backtest filters (volume ratio, absorption bars, seller exhaustion) can be
                // validated live. Log only - it never changes the decision.
                PrintBotMessage(Core20OpenBellContextSummary(bars, ny, hi, lo, price));

                // V1.7.62 - SHORT only: range < 61 (LONG) lost money in the 253-day backtest.
                // Those days are handled by the Gerard module (range <= 60) at 09:35.
                if (isLong && Core20OpenBellShortOnly)
                {
                    PrintBotMessage("CORE20 OPEN BELL | SKIP - SHORT ONLY | Range " + rangePts.ToString("0.00")
                        + " < " + Core20OpenBellRangeThresholdPts.ToString("0") + " -> LONG disabled (Gerard module decides at 09:35)");
                    return;
                }

                if (!Core20DirectionAllows(isLong))
                {
                    PrintBotMessage("CORE20 OPEN BELL | SKIP - DIRECTION SETTING | Side " + (isLong ? "LONG" : "SHORT"));
                    return;
                }

                string l2VetoSummary;
                bool l2Veto = IsLevel2ContraryFlowVeto(isLong, out l2VetoSummary);
                PrintBotMessage("CORE20 OPEN BELL L2 | " + (l2Veto ? "VETO" : "OK")
                    + " | Side " + (isLong ? "LONG" : "SHORT")
                    + " | " + l2VetoSummary
                    + " | Enforced " + Core20OpenBellL2VetoEnabled);

                if (l2Veto && Core20OpenBellL2VetoEnabled)
                {
                    PrintBotMessage("CORE20 OPEN BELL | SKIP - L2 CONTRARY FLOW | Side " + (isLong ? "LONG" : "SHORT")
                        + " | Range " + rangePts.ToString("0.00"));
                    return;
                }

                string summary =
                    "CORE20 OPEN BELL"
                    + " | Range 09:00-09:29:58 " + rangePts.ToString("0.00") + " pts (H " + hi.ToString("0.00") + " / L " + lo.ToString("0.00") + ")"
                    + " | Threshold " + Core20OpenBellRangeThresholdPts.ToString("0") + " -> " + (isLong ? "LONG" : "SHORT")
                    + " | Price " + price.ToString("0.00")
                    + " | SL " + Core20OpenBellStopTicks + "t | PT " + Core20OpenBellTargetTicks + "t | Ladder +20->+17 pts";

                DateTime pcClockNy = GetCurrentNewYorkTime();
                double clockSkewSec = (pcClockNy - ny).TotalSeconds;

                PrintBotMessage(summary + " | Decision: ENTRY"
                    + " | PC clock " + pcClockNy.ToString("HH:mm:ss.fff")
                    + " vs tick " + ny.ToString("HH:mm:ss.fff")
                    + " (" + clockSkewSec.ToString("+0.0;-0.0") + "s)");

                if (Math.Abs(clockSkewSec) > 20)
                    PrintBotMessage("CORE20 OPEN BELL WARNING | PC clock differs from exchange by "
                        + clockSkewSec.ToString("0.0") + "s - sync the Windows clock (Settings > Time > Sync now).");

                core20DayTradeTaken = true;
                core20ObLongToday = isLong;

                TrySubmitEntry(
                    isLong,
                    tickTime,
                    false,
                    null,
                    false,
                    false,
                    Core20StrategyName,
                    Core20OpenBellRoute,
                    summary
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 OPEN BELL ERROR: " + ex.Message);
            }
        }

        // V1.7.62 - GERARD ACUMULACION (09:35). See the block comment at the constants.
        private void Core20TryGerard(DateTime tickTime, DateTime ny, double price)
        {
            try
            {
                // V1.7.72 - an Open Bell LONG that is already CLOSED does not block Gerard (same range < 61 days).
                bool obLongClosed = core20ObLongToday && !core20ObTradeActive && IsSelectedInstrumentFlat();

                if (core20DayTradeTaken && !obLongClosed)
                {
                    PrintBotMessage("CORE20 GERARD | SKIP - Open Bell already traded today"
                        + (core20ObLongToday ? " (LONG still open at 09:35)" : string.Empty));
                    return;
                }

                if (core20DayTradeTaken && obLongClosed)
                    PrintBotMessage("CORE20 GERARD | Open Bell LONG already closed - Gerard evaluates");

                double hi, lo, px35;
                bool haveCover, havePx;

                lock (core20Sync)
                {
                    hi = core20ObTickHigh;
                    lo = core20ObTickLow;
                    px35 = core20GdLastPx35;
                    havePx = core20GdHavePx35;
                    haveCover = core20ObFirstTickTod != TimeSpan.MaxValue
                        && core20ObFirstTickTod <= new TimeSpan(9, 1, 30);
                }

                // V1.7.64 - same 1m-bars fallback as the Open Bell: a bot started after
                // 09:01:30 has no tick coverage of the 09:00 range, but the 1m series has it.
                int gdMinuteBars = 0;
                try
                {
                    Bars gdBars = core20MinuteRequest != null ? core20MinuteRequest.Bars : null;

                    if (gdBars != null)
                    {
                        for (int i = gdBars.Count - 1; i >= 0; i--)
                        {
                            DateTime b = ConvertToNewYorkTime(gdBars.GetTime(i));

                            if (b.Date < ny.Date)
                                break;

                            if (b.Date == ny.Date && b.TimeOfDay > Core20OpenBellRangeStart && b.TimeOfDay <= new TimeSpan(9, 29, 0))
                            {
                                hi = Math.Max(hi, gdBars.GetHigh(i));
                                lo = Math.Min(lo, gdBars.GetLow(i));
                                gdMinuteBars++;
                            }
                        }
                    }
                }
                catch (Exception exBars)
                {
                    PrintBotMessage("CORE20 GERARD | 1m bars read error: " + exBars.Message);
                }

                if ((!haveCover && gdMinuteBars < 20) || !havePx || hi <= lo || hi == double.MinValue || lo == double.MaxValue)
                {
                    PrintBotMessage("CORE20 GERARD | SKIP - RANGE DATA N/A | Coverage " + haveCover + " | 1m bars " + gdMinuteBars + " | Px35 " + havePx);
                    return;
                }

                if (!haveCover)
                    PrintBotMessage("CORE20 GERARD | RANGE FROM 1m BARS | 1m bars " + gdMinuteBars);

                double rangePts = hi - lo;

                if (rangePts > Core20GerardMaxRangePts)
                {
                    PrintBotMessage("CORE20 GERARD | SKIP - Range " + rangePts.ToString("0.00") + " > "
                        + Core20GerardMaxRangePts.ToString("0") + " pts (Open Bell zone)");
                    return;
                }

                bool isLong;
                if (px35 > hi) isLong = true;
                else if (px35 < lo) isLong = false;
                else
                {
                    PrintBotMessage("CORE20 GERARD | SKIP - 09:35 close " + px35.ToString("0.00")
                        + " inside range " + lo.ToString("0.00") + "-" + hi.ToString("0.00"));
                    return;
                }

                Instrument inst = selectedInstrument;
                double tick = inst != null ? inst.MasterInstrument.TickSize : 0.25;
                double pointValue = inst != null ? inst.MasterInstrument.PointValue : 2.0;
                if (tick <= 0) tick = 0.25;
                if (pointValue <= 0) pointValue = 2.0;

                double stopLevel = isLong ? lo : hi;
                double dist = Math.Abs(price - stopLevel);
                if (dist < Core20GerardMinStopPts) dist = Core20GerardMinStopPts;
                if (dist > Core20GerardMaxStopPts) dist = Core20GerardMaxStopPts;

                int contracts = (int)Math.Floor(Core20GerardRiskUsd / (dist * pointValue));
                if (contracts < 1)
                {
                    PrintBotMessage("CORE20 GERARD | SKIP - stop " + dist.ToString("0.0") + " pts does not fit risk $"
                        + Core20GerardRiskUsd.ToString("0"));
                    return;
                }

                int stopTicks = (int)Math.Round(dist / tick);

                lock (executionStateLock)
                {
                    core20GdStopTicks = stopTicks;
                    core20GdTargetTicks = stopTicks * 3;
                    core20GdContracts = contracts;
                }

                string summary =
                    "CORE20 GERARD"
                    + " | Range 09:00-09:29:58 " + rangePts.ToString("0.00") + " pts (H " + hi.ToString("0.00") + " / L " + lo.ToString("0.00") + ")"
                    + " | 09:35 close " + px35.ToString("0.00") + " -> " + (isLong ? "LONG" : "SHORT")
                    + " | SL " + stopTicks + "t (" + dist.ToString("0.0") + " pts) | TP " + (stopTicks * 3) + "t (3R)"
                    + " | " + contracts + "c | +1 averaging at +1R | flat 10:00";

                PrintBotMessage(summary + " | Decision: ENTRY");

                core20DayTradeTaken = true;

                TrySubmitEntry(
                    isLong,
                    tickTime,
                    false,
                    null,
                    false,
                    false,
                    Core20StrategyName,
                    Core20GerardRoute,
                    summary
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 GERARD ERROR: " + ex.Message);
            }
        }

        // Account side: Gerard stop/target before sizing.
        private void Core20ApplyGerardOverride()
        {
            int stopTicks;
            int targetTicks;

            lock (executionStateLock)
            {
                if (!core20PmStopOverrideActive)
                {
                    core20PmSavedStopTicks = activeStopTicks;
                    core20PmStopOverrideActive = true;
                }

                if (!core20TargetOverrideActive)
                {
                    core20SavedTargetTicks = activeTargetTicks;
                    core20TargetOverrideActive = true;
                }

                stopTicks = core20GdStopTicks;
                targetTicks = core20GdTargetTicks;
                activeStopTicks = stopTicks;
                activeTargetTicks = targetTicks;
                core20GdTradeActive = true;
                core20PmOverrideUtc = DateTime.UtcNow;
            }

            PrintBotMessage("CORE20 GERARD | SL " + stopTicks + "t / PT " + targetTicks + "t override");
        }

        // Session grace so 09:29:57-09:29:59 counts as AM for the CORE20
        // Open Bell only (CORE20 has no other trigger in those seconds).
        private bool IsCore20OpenBellGrace(DateTime nyTime)
        {
            if (!IsCore20Mode())
                return false;

            // V1.7.47 - the Open Bell fires on EXCHANGE tick time (09:29:58),
            // but the execution gates check the PC clock. A Windows clock a
            // few seconds behind the exchange used to see 09:29:5x as
            // PREMARKET (observe only) and block the entry. The grace now
            // starts at 09:29:30 (CORE20 has no other trigger before 09:32).
            TimeSpan t = nyTime.TimeOfDay;
            return t >= new TimeSpan(9, 29, 30) && t < Core20OpenBellEntryDeadline;
        }

        // Account side: Open Bell stop/target before sizing.
        private void Core20ApplyOpenBellOverride()
        {
            lock (executionStateLock)
            {
                if (!core20PmStopOverrideActive)
                {
                    core20PmSavedStopTicks = activeStopTicks;
                    core20PmStopOverrideActive = true;
                }

                if (!core20TargetOverrideActive)
                {
                    core20SavedTargetTicks = activeTargetTicks;
                    core20TargetOverrideActive = true;
                }

                activeStopTicks = Core20OpenBellStopTicks;
                activeTargetTicks = Core20OpenBellTargetTicks;
                core20ObTradeActive = true;
                core20PmOverrideUtc = DateTime.UtcNow;
            }

            PrintBotMessage("CORE20 OPEN BELL | SL " + Core20OpenBellStopTicks + "t / PT " + Core20OpenBellTargetTicks + "t override");
        }

        // V1.7.48 - CORE20 AM (SWEEP/BREAK): own SL 60t / PT 160t on THIS account.
        private void Core20ApplyAmOverride()
        {
            int previousStop;
            int previousTarget;

            lock (executionStateLock)
            {
                if (!core20PmStopOverrideActive)
                {
                    core20PmSavedStopTicks = activeStopTicks;
                    core20PmStopOverrideActive = true;
                }

                if (!core20TargetOverrideActive)
                {
                    core20SavedTargetTicks = activeTargetTicks;
                    core20TargetOverrideActive = true;
                }

                previousStop = core20PmSavedStopTicks;
                previousTarget = core20SavedTargetTicks;

                activeStopTicks = Core20AmStopTicks;
                activeTargetTicks = Core20AmTargetTicks;
                core20AmTradeActive = true;
                core20PmOverrideUtc = DateTime.UtcNow;
            }

            if (previousStop != Core20AmStopTicks || previousTarget != Core20AmTargetTicks)
            {
                PrintBotMessage(
                    "CORE20 AM | SL " + Core20AmStopTicks + "t / PT " + Core20AmTargetTicks + "t (strategy)"
                    + " | Profile had SL " + previousStop + "t / PT " + previousTarget + "t - ignored for CORE20");
            }
        }

        // Ladder management for the Open Bell trade (measured from the original entry).
        private void Core20ManageOpenBell(Account account, MarketPosition side, Order localStopOrder, double localActiveStop, double currentPrice, double tickSize, int[,] ladder = null, string tag = "OPEN BELL")
        {
            if (localStopOrder == null || tickSize <= 0)
                return;

            if (localStopOrder.OrderState != OrderState.Working && localStopOrder.OrderState != OrderState.Accepted)
                return;

            double anchor = core20AnchorEntry;

            if (anchor <= 0)
                return;

            double fav = side == MarketPosition.Long ? (currentPrice - anchor) / tickSize : (anchor - currentPrice) / tickSize;

            if (fav > core20PeakTicks)
                core20PeakTicks = fav;

            int lockTicks = int.MinValue;
            int[,] rungs = ladder ?? Core20OpenBellLadder;

            for (int r = 0; r < rungs.GetLength(0); r++)
            {
                if (core20PeakTicks >= rungs[r, 0])
                    lockTicks = rungs[r, 1];
            }

            if (lockTicks == int.MinValue)
                return;

            double desiredStop =
                RoundToInstrumentTick(side == MarketPosition.Long ? anchor + lockTicks * tickSize : anchor - lockTicks * tickSize);

            desiredStop = EnforceNeverWorsenStop(side, localActiveStop, desiredStop);

            bool adjusted;
            bool usedL2;
            double reference;

            desiredStop = ClampProtectiveStopToLiveMarket(side, desiredStop, currentPrice, tickSize, out adjusted, out usedL2, out reference);

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > localActiveStop + tickSize * 0.5
                    : desiredStop < localActiveStop - tickSize * 0.5;

            if (!improves)
                return;

            long token;

            if (!TryBeginProtectiveChange("CORE20_OPENBELL_LADDER", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    if (!ReferenceEquals(stopOrder, localStopOrder) || entryMarketPosition != side)
                        return;

                    activeStopPrice = desiredStop;
                    localStopOrder.StopPriceChanged = desiredStop;
                }

                account.Change(new[] { localStopOrder });

                PrintBotMessage(
                    "CORE20 " + tag + " LADDER"
                    + " | Peak +" + core20PeakTicks.ToString("0") + "t"
                    + " | Lock +" + lockTicks + "t"
                    + " | New SL " + desiredStop.ToString("0.00")
                    + (adjusted ? " | Clamped to live market" : string.Empty));
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 OPEN BELL LADDER ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }

        // Net aggressive volume (buy - sell) in (endTime - 60s, endTime].
        private double GetCore20Delta(DateTime endTime)
        {
            DateTime startTime = endTime.AddSeconds(-Core20DeltaWindowSeconds);
            double delta = 0;

            lock (core20Sync)
            {
                foreach (KeyValuePair<DateTime, double> item in core20Tape)
                {
                    if (item.Key > startTime && item.Key <= endTime)
                        delta += item.Value;
                }
            }

            return delta;
        }

        // -----------------------------------------------------
        // 1-minute series: zone map + AM triggers
        // -----------------------------------------------------
        private void OnCore20MinuteCompleted(BarsRequest request, ErrorCode errorCode, string errorMessage)
        {
            if (errorCode != ErrorCode.NoError || request == null || request.Bars == null)
            {
                PrintBotMessage("CORE20 1M DATA ERROR: " + errorCode + " | " + errorMessage);
                return;
            }

            lock (core20Sync)
            {
                core20MinuteReady = true;
                // History is used for the zone map only; never replay old signals.
                core20LastMinuteProcessed = request.Bars.Count - 2;
            }

            PrintBotMessage("CORE20 1M DATA READY | Bars: " + request.Bars.Count);
        }

        private void OnCore20MinuteUpdate(object sender, BarsUpdateEventArgs e)
        {
            if (!botRunning || !IsCore20EngineMode() || !core20MinuteReady || core20MinuteRequest == null)
                return;

            try
            {
                Bars bars = core20MinuteRequest.Bars;

                if (bars == null || bars.Count < 3)
                    return;

                int lastClosed = bars.Count - 2;

                while (true)
                {
                    int next;

                    lock (core20Sync)
                    {
                        if (core20LastMinuteProcessed >= lastClosed)
                            break;

                        core20LastMinuteProcessed++;
                        next = core20LastMinuteProcessed;
                    }

                    if (next >= 0)
                        ProcessCore20MinuteBar(bars, next);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 1M UPDATE ERROR: " + ex.Message);
            }
        }

        private void ProcessCore20MinuteBar(Bars bars, int index)
        {
            DateTime barTime = bars.GetTime(index);
            DateTime barNy = ConvertToNewYorkTime(barTime);
            TimeSpan tod = barNy.TimeOfDay;

            // V1.7.39 - 15:30 module + override housekeeping (runs all day).
            Core20PmHousekeeping();

            if (tod == Core20PmEntryBarClose)
            {
                Core20TryPm1530(bars, index, barNy, barTime);
                return;
            }

            // NinjaTrader minute bars are stamped with their CLOSE time:
            // the 09:31 bar is the first RTH minute.
            if (tod <= Core20AmStart || tod > Core20AmEnd)
            {
                if (tod <= Core20AmStart && tod >= new TimeSpan(9, 0, 0))
                    core20SetupStatus = "BUILDING ZONE MAP";

                return;
            }

            Core20ResetDayIfNeeded(barNy);
            EnsureCore20Levels(bars, index, barNy.Date);

            if (core20LevelsDate != barNy.Date || core20Levels.Count == 0)
                return;

            double tickSize = selectedInstrument.MasterInstrument.TickSize;
            double zone = Core20ZoneTicks * tickSize;
            double touch = Core20DefendTouchTicks * tickSize;

            double high = bars.GetHigh(index);
            double low = bars.GetLow(index);
            double close = bars.GetClose(index);

            bool submitted = false;

            foreach (Core20Level level in core20Levels)
            {
                // ---------- SWEEP ----------
                if (!level.SweepUsed)
                {
                    if (!level.Swept && (level.IsHigh ? high >= level.Price + zone : low <= level.Price - zone))
                    {
                        level.Swept = true;
                        core20SetupStatus = level.Name + " SWEPT @ " + level.Price.ToString("0.00");
                        PrintBotMessage("CORE20 SWEEP | " + level.Name + " " + level.Price.ToString("0.00") + " | Waiting 1m close back inside");
                        PublishCore20Zones();
                    }

                    if (level.Swept && (level.IsHigh ? close < level.Price : close > level.Price))
                    {
                        level.SweepUsed = true;
                        TryCore20Entry(!level.IsHigh, "SWEEP", level, close, barTime, ref submitted);
                    }
                }

                // ---------- BREAK ----------
                if (!level.BreakUsed && (level.IsHigh ? close >= level.Price + zone : close <= level.Price - zone))
                {
                    level.BreakUsed = true;

                    if (core20DayBreakDirection == 0)
                        core20DayBreakDirection = level.IsHigh ? 1 : -1;

                    TryCore20Entry(level.IsHigh, "BREAK", level, close, barTime, ref submitted);
                }

                // ---------- DEFENDED ZONE (observe only) ----------
                if (!level.DefendUsed)
                {
                    bool touched =
                        level.IsHigh
                            ? high >= level.Price - touch && high < level.Price + zone
                            : low <= level.Price + touch && low > level.Price - zone;

                    bool brokeThrough =
                        level.IsHigh ? high >= level.Price + zone : low <= level.Price - zone;

                    if (level.DefendTouchBar < 0 && touched)
                        level.DefendTouchBar = index;

                    if (level.DefendTouchBar >= 0)
                    {
                        if (brokeThrough || index - level.DefendTouchBar >= Core20DefendLookBars)
                        {
                            level.DefendUsed = true;
                        }
                        else if (level.IsHigh ? close < level.Price - touch : close > level.Price + touch)
                        {
                            level.DefendUsed = true;
                            bool isLong = !level.IsHigh;
                            double d = GetCore20Delta(barTime);

                            PrintBotMessage(
                                "CORE20 OBSERVE DEFENDED ZONE"
                                + " | " + level.Name + " " + level.Price.ToString("0.00")
                                + " | Side " + (isLong ? "LONG" : "SHORT")
                                + " | Close " + close.ToString("0.00")
                                + " | Delta60s " + d.ToString("+0;-0;0")
                                + " | NOT EXECUTED"
                            );
                        }
                    }
                }
            }
        }

        // V1.7.35 - price of the last traded tick (market-data time domain,
        // valid in live and Playback).  0 when unknown.
        private double GetCore20LastTradePrice()
        {
            lock (level2Sync)
            {
                return level2LastTradePrice;
            }
        }

        // V1.7.35 - account-side CORE20 authority for a CENTRAL decision.
        // The central signal is the same for every profile; this only applies
        // the rules that belong to THIS account's CORE20 day.
        private const int Core20MaxSignalDriftTicks = 20;

        private bool Core20AccountAllowsCentralSignal(JJCentralMarketDecision signal, out string reason)
        {
            reason = string.Empty;

            Core20ResetDayIfNeeded(GetCurrentNewYorkTime());

            if (core20LossesToday >= Core20MaxLossesPerDay)
            {
                reason = "CORE20 " + Core20MaxLossesPerDay + " LOSSES TODAY";
                return false;
            }

            if (!Core20DirectionAllows(signal.IsLong))
            {
                reason = "CORE20 DIRECTION SETTING";
                return false;
            }

            double tickSize =
                selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double nowPrice = GetCore20LastTradePrice();

            if (tickSize > 0 && signal.SignalPrice > 0 && nowPrice > 0)
            {
                double driftTicks = Math.Abs(nowPrice - signal.SignalPrice) / tickSize;

                if (driftTicks > Core20MaxSignalDriftTicks)
                {
                    reason = "CORE20 PRICE MOVED " + driftTicks.ToString("0") + "t SINCE SIGNAL";
                    return false;
                }
            }

            return true;
        }

        private void PublishCore20Zones()
        {
            try
            {
                if (selectedInstrument == null) return;
                JJCore20ZoneBus.PublishZones(
                    selectedInstrument.FullName,
                    core20LevelsDate,
                    core20Levels.Select(l => new JJCore20ZoneInfo
                    {
                        Name = l.Name, Price = l.Price, IsHigh = l.IsHigh,
                        Swept = l.Swept, SweepUsed = l.SweepUsed, BreakUsed = l.BreakUsed
                    }).ToList());
            }
            catch { }
        }

        private void PublishCore20Event(string trigger, Core20Level level, bool isLong, double close, DateTime barTime, double delta, string decision)
        {
            try
            {
                if (selectedInstrument == null || level == null) return;
                JJCore20ZoneBus.PublishEvent(
                    selectedInstrument.FullName,
                    core20LevelsDate,
                    new JJCore20EventInfo
                    {
                        Key = barTime.Ticks + "|" + level.Name + "|" + trigger,
                        BarTime = barTime,
                        Zone = level.Name,
                        ZonePrice = level.Price,
                        Trigger = trigger,
                        IsLong = isLong,
                        Price = close,
                        Delta = delta,
                        Decision = decision
                    });
                PublishCore20Zones();
            }
            catch { }
        }

        private string Core20L2Snapshot()
        {
            try
            {
                lock (level2Sync)
                {
                    return "Ready " + (level2BookReady ? "YES" : "WARMUP")
                        + " Bias " + level2Bias
                        + " Bid/Ask " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0")
                        + " Top10 " + level2TopBidVolume + "/" + level2TopAskVolume
                        + " Stack " + level2StackPull
                        + " Absorb " + level2Absorption
                        + " Spread " + level2SpreadTicks.ToString("0.0") + "t";
                }
            }
            catch
            {
                return "n/a";
            }
        }

        // -----------------------------------------------------
        // V1.7.39 - 15:30 LAST HALF HOUR MODULE
        // -----------------------------------------------------
        private void Core20TryPm1530(Bars bars, int index, DateTime barNy, DateTime barTime)
        {
            try
            {
                if (!IsCore20Mode() || !Core20PmEnabled)
                    return;

                if (core20PmDoneDate == barNy.Date)
                    return;

                core20PmDoneDate = barNy.Date;
                Core20ResetDayIfNeeded(barNy);

                if (core20LossesToday >= Core20MaxLossesPerDay)
                {
                    PrintBotMessage("CORE20 15:30 | SKIP - " + Core20MaxLossesPerDay + " LOSSES TODAY");
                    return;
                }

                // Price at 10:00 today (close of the bar stamped 10:00) and the
                // prior RTH close (close of the bar stamped 16:00 on an earlier day).
                double price10 = 0;
                double priorClose = 0;
                DateTime priorDate = DateTime.MinValue;

                for (int i = index; i >= 0; i--)
                {
                    DateTime ny = ConvertToNewYorkTime(bars.GetTime(i));

                    if (ny < barNy.Date.AddDays(-6))
                        break;

                    if (price10 == 0 && ny.Date == barNy.Date && ny.TimeOfDay == Core20PmDirectionTime)
                        price10 = bars.GetClose(i);

                    if (ny.Date < barNy.Date && ny.TimeOfDay > Core20AmStart && ny.TimeOfDay <= Core20RthEnd)
                    {
                        // first bar found going back = last RTH bar of the prior session
                        priorClose = bars.GetClose(i);
                        priorDate = ny.Date;
                        break;
                    }
                }

                if (price10 <= 0 || priorClose <= 0 || price10 == priorClose)
                {
                    PrintBotMessage(
                        "CORE20 15:30 | SKIP - DIRECTION DATA N/A"
                        + " | 10:00 " + price10.ToString("0.00")
                        + " | PriorClose " + priorClose.ToString("0.00"));
                    return;
                }

                bool isLong = price10 > priorClose;

                if (!Core20DirectionAllows(isLong))
                {
                    PrintBotMessage("CORE20 15:30 | SKIP - DIRECTION SETTING | Side " + (isLong ? "LONG" : "SHORT"));
                    return;
                }

                string summary =
                    "CORE20 15:30"
                    + " | Side " + (isLong ? "LONG" : "SHORT")
                    + " | PriorClose " + priorClose.ToString("0.00")
                    + (priorDate != DateTime.MinValue ? " (" + priorDate.ToString("MM-dd") + ")" : string.Empty)
                    + " | 10:00 " + price10.ToString("0.00")
                    + " | SL " + Core20PmStopTicks + "t | Exit: Daily Target or 15:55";

                PrintBotMessage(summary + " | Decision: ENTRY");

                TrySubmitEntry(
                    isLong,
                    barTime,
                    false,
                    null,
                    false,
                    false,
                    Core20StrategyName,
                    Core20PmRoute,
                    summary
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 15:30 ERROR: " + ex.Message);
            }
        }

        // Called on the ACCOUNT side right before sizing a 15:30 entry, so the
        // bracket, risk sizing and daily-loss budget all use the 15:30 stop.
        private void Core20ApplyPmStopOverride()
        {
            lock (executionStateLock)
            {
                if (!core20PmStopOverrideActive)
                {
                    core20PmSavedStopTicks = activeStopTicks;
                    core20PmStopOverrideActive = true;
                }

                activeStopTicks = Core20PmStopTicks;
                core20PmTradeActive = true;
                core20PmOverrideUtc = DateTime.UtcNow;
            }

            PrintBotMessage("CORE20 15:30 | SL override " + core20PmSavedStopTicks + "t -> " + Core20PmStopTicks + "t");
        }

        private void Core20RestorePmStopOverride(string reason)
        {
            int restored;

            int restoredTarget = -1;

            lock (executionStateLock)
            {
                core20PmTradeActive = false;
                core20ObTradeActive = false;
                core20AmTradeActive = false;
                core20GdTradeActive = false;

                if (core20TargetOverrideActive)
                {
                    activeTargetTicks = core20SavedTargetTicks;
                    core20TargetOverrideActive = false;
                    restoredTarget = activeTargetTicks;
                }

                if (!core20PmStopOverrideActive)
                    return;

                activeStopTicks = core20PmSavedStopTicks;
                core20PmStopOverrideActive = false;
                restored = activeStopTicks;
            }

            PrintBotMessage(
                "CORE20 | SL restored to " + restored + "t"
                + (restoredTarget >= 0 ? " | PT restored to " + restoredTarget + "t" : string.Empty)
                + " | " + reason);
        }

        // Restore the profile SL if the 15:30 entry was blocked / never filled.
        private void Core20PmHousekeeping()
        {
            bool stale = false;

            lock (executionStateLock)
            {
                stale =
                    core20PmStopOverrideActive &&
                    !core20TradeOpen &&
                    (DateTime.UtcNow - core20PmOverrideUtc).TotalSeconds >= 120;
            }

            if (stale && IsSelectedInstrumentFlat())
                Core20RestorePmStopOverride("NO POSITION AFTER 120s");
        }

        private void TryCore20Entry(bool isLong, string trigger, Core20Level level, double close, DateTime barTime, ref bool submitted)
        {
            if (!Core20AmEnabled)
                return;

            double delta = GetCore20Delta(barTime);
            double alignedDelta = isLong ? delta : -delta;

            string summary =
                "CORE20 " + trigger
                + " | Zone " + level.Name + " " + level.Price.ToString("0.00")
                + " | Close " + close.ToString("0.00")
                + " | Side " + (isLong ? "LONG" : "SHORT")
                + " | Delta60s " + delta.ToString("+0;-0;0")
                // V1.7.36 - Level 2 book snapshot AT the signal (recorded for
                // analysis: does the book predict which CORE20 trades fail?).
                + " | L2 " + Core20L2Snapshot();
			            // V1.7.37 - NO ENTRIES IN THE FIRST 2 MINUTES OF RTH (bars closing 09:31 and 09:32).
            TimeSpan barTod = ConvertToNewYorkTime(barTime).TimeOfDay;

            if (barTod <= Core20NoEntryUntil)
            {
                core20TriggerStatus = trigger + " " + level.Name + " - OPENING SKIP";
                PrintBotMessage(summary + " | Decision: SKIP - OPENING 09:30-09:32 (no entries)");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - OPENING");
                return;
            }

            if (alignedDelta <= 0)
            {
                core20TriggerStatus = trigger + " " + level.Name + " - DELTA AGAINST";
                PrintBotMessage(summary + " | Decision: SKIP - TAPE NOT CONFIRMING");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - TAPE");
                return;
            }

            if (core20LossesToday >= Core20MaxLossesPerDay)
            {
                PrintBotMessage(summary + " | Decision: SKIP - " + Core20MaxLossesPerDay + " LOSSES TODAY");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - 2 LOSSES");
                return;
            }

            if (!Core20DirectionAllows(isLong))
            {
                PrintBotMessage(summary + " | Decision: SKIP - DIRECTION SETTING");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - DIRECTION");
                return;
            }

            if (submitted)
            {
                PrintBotMessage(summary + " | Decision: SKIP - ONE ENTRY PER BAR");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - 1 PER BAR");
                return;
            }

            submitted = true;
            core20TriggerStatus = trigger + " " + level.Name + " - DELTA CONFIRMED";
            PrintBotMessage(summary + " | Decision: ENTRY");
            PublishCore20Event(trigger, level, isLong, close, barTime, delta, "ENTRY");

            // V1.7.36 - learning label per zone + trigger (e.g. CORE20_SWEEP_PDH)
            // so Learning shows which zone / trigger works best.
            try
            {
                CaptureLearningSignalContext(
                    isLong ? "LONG" : "SHORT",
                    ConvertToNewYorkTime(barTime),
                    "CORE20_" + trigger + "_" + level.Name);
            }
            catch
            {
            }

            TrySubmitEntry(
                isLong,
                barTime,
                false,
                null,
                false,
                false,
                Core20StrategyName,
                "CORE20_" + trigger,
                summary
            );
        }

        private void EnsureCore20Levels(Bars bars, int index, DateTime sessionDate)
        {
            if (core20LevelsDate == sessionDate)
                return;

            DateTime overnightStart = sessionDate.AddDays(-1).Add(new TimeSpan(18, 0, 0));
            DateTime rthOpen = sessionDate.Add(Core20AmStart);

            double onh = double.MinValue, onl = double.MaxValue;
            double pdh = double.MinValue, pdl = double.MaxValue;
            DateTime priorRthDate = DateTime.MinValue;
            double rthOpen930 = 0;

            for (int i = index; i >= 0; i--)
            {
                DateTime ny = ConvertToNewYorkTime(bars.GetTime(i));

                // First RTH bar of the session (closes at 09:31): its open is
                // the 09:30 opening price.
                if (ny.Date == sessionDate && ny.TimeOfDay > Core20AmStart && ny.TimeOfDay <= Core20AmStart.Add(TimeSpan.FromMinutes(1)))
                    rthOpen930 = bars.GetOpen(i);

                if (ny < sessionDate.AddDays(-6))
                    break;

                // Overnight: (18:00 previous day, 09:30]
                if (ny > overnightStart && ny <= rthOpen)
                {
                    onh = Math.Max(onh, bars.GetHigh(i));
                    onl = Math.Min(onl, bars.GetLow(i));
                }

                // Prior RTH session: (09:30, 16:00] of the most recent earlier date.
                TimeSpan t = ny.TimeOfDay;

                if (ny.Date < sessionDate && t > Core20AmStart && t <= Core20RthEnd)
                {
                    if (priorRthDate == DateTime.MinValue)
                        priorRthDate = ny.Date;

                    if (ny.Date == priorRthDate)
                    {
                        pdh = Math.Max(pdh, bars.GetHigh(i));
                        pdl = Math.Min(pdl, bars.GetLow(i));
                    }
                }
            }

            core20Levels.Clear();
            core20DayBreakDirection = 0;

            if (onh > double.MinValue && onl < double.MaxValue)
            {
                core20Levels.Add(new Core20Level { Name = "ONH", Price = onh, IsHigh = true });
                core20Levels.Add(new Core20Level { Name = "ONL", Price = onl, IsHigh = false });
            }

            if (pdh > double.MinValue && pdl < double.MaxValue)
            {
                core20Levels.Add(new Core20Level { Name = "PDH", Price = pdh, IsHigh = true });
                core20Levels.Add(new Core20Level { Name = "PDL", Price = pdl, IsHigh = false });
            }

            core20LevelsDate = sessionDate;

            // V1.7.36 - A zone that is ALREADY broken when NY opens (price opened
            // 8+ ticks beyond it) is not a fresh break: no BREAK trade on it.
            // Backtest: removes the first-bar gap "breaks" (-$25/trade) ->
            // Jun-Aug +$1,803 -> +$1,986, worst streak -$562 -> -$375; Sep +$552 -> +$705.
            // Sweeps (reclaim back inside) on those zones stay allowed.
            string gapped = string.Empty;
            double zoneTicksPx = selectedInstrument != null ? Core20ZoneTicks * selectedInstrument.MasterInstrument.TickSize : 0;

            if (rthOpen930 > 0 && zoneTicksPx > 0)
            {
                foreach (Core20Level l in core20Levels)
                {
                    bool alreadyBroken =
                        l.IsHigh
                            ? rthOpen930 >= l.Price + zoneTicksPx
                            : rthOpen930 <= l.Price - zoneTicksPx;

                    if (alreadyBroken)
                    {
                        l.BreakUsed = true;
                        gapped += (gapped.Length > 0 ? "," : string.Empty) + l.Name;
                    }
                }
            }

            // V1.7.43 - MID-SESSION START CATCH-UP.
            // 2026-09-30: the bot was (re)started at 11:49 and the fresh zone
            // map took a BREAK of ONH/PDH on the first processed bar, with price
            // already 120 pts beyond the zones (the real break happened hours
            // earlier).  Replay today's RTH bars BEFORE the current bar through
            // the same SWEEP/BREAK state machine, without trading, so signals
            // that already happened are consumed exactly as a bot running since
            // 09:30 would have consumed them.
            string caughtUp = string.Empty;

            try
            {
                double zonePx = selectedInstrument != null ? Core20ZoneTicks * selectedInstrument.MasterInstrument.TickSize : 0;
                int firstRth = -1;

                for (int i = index - 1; i >= 0; i--)
                {
                    DateTime ny = ConvertToNewYorkTime(bars.GetTime(i));

                    if (ny.Date != sessionDate || ny.TimeOfDay <= Core20AmStart)
                        break;

                    firstRth = i;
                }

                if (firstRth >= 0 && zonePx > 0)
                {
                    for (int i = firstRth; i < index; i++)
                    {
                        double h = bars.GetHigh(i), lo = bars.GetLow(i), c = bars.GetClose(i);

                        foreach (Core20Level l in core20Levels)
                        {
                            if (!l.SweepUsed)
                            {
                                if (!l.Swept && (l.IsHigh ? h >= l.Price + zonePx : lo <= l.Price - zonePx))
                                    l.Swept = true;

                                if (l.Swept && (l.IsHigh ? c < l.Price : c > l.Price))
                                {
                                    l.SweepUsed = true;
                                    caughtUp += (caughtUp.Length > 0 ? "," : string.Empty) + l.Name + " SWEEP";
                                }
                            }

                            if (!l.BreakUsed && (l.IsHigh ? c >= l.Price + zonePx : c <= l.Price - zonePx))
                            {
                                l.BreakUsed = true;
                                caughtUp += (caughtUp.Length > 0 ? "," : string.Empty) + l.Name + " BREAK";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 CATCH-UP ERROR: " + ex.Message);
            }

            if (caughtUp.Length > 0)
                PrintBotMessage("CORE20 CATCH-UP (bot started after 09:30) | Already happened today, NOT traded: " + caughtUp);

            string map =
                core20Levels.Count == 0
                    ? "NO ZONES"
                    : string.Join(" | ", core20Levels.Select(l => l.Name + " " + l.Price.ToString("0.00")));

            core20SetupStatus = "ZONE MAP READY | " + map;
            PublishCore20Zones();

            PrintBotMessage(
                "CORE20 ZONE MAP"
                + " | Session " + sessionDate.ToString("yyyy-MM-dd")
                + " | " + map
                + (priorRthDate != DateTime.MinValue ? " | PD from " + priorRthDate.ToString("yyyy-MM-dd") : " | PD: n/a")
                + (gapped.Length > 0 ? " | Already broken at open (no BREAK): " + gapped : string.Empty)
            );
        }

        // -----------------------------------------------------
        // Range-60 series: OBSERVE ONLY (PM fade, AM continuation)
        // -----------------------------------------------------
        private void OnCore20RangeCompleted(BarsRequest request, ErrorCode errorCode, string errorMessage)
        {
            if (errorCode != ErrorCode.NoError || request == null || request.Bars == null)
            {
                PrintBotMessage("CORE20 RANGE DATA ERROR: " + errorCode + " | " + errorMessage);
                return;
            }

            lock (core20Sync)
            {
                core20RangeReady = true;
                core20LastRangeProcessed = request.Bars.Count - 2;
            }

            PrintBotMessage("CORE20 RANGE-" + Core20RangeTicks + " DATA READY (observe) | Bars: " + request.Bars.Count);
        }

        private void OnCore20RangeUpdate(object sender, BarsUpdateEventArgs e)
        {
            if (!botRunning || !IsCore20EngineMode() || !core20RangeReady || core20RangeRequest == null)
                return;

            try
            {
                Bars bars = core20RangeRequest.Bars;

                if (bars == null || bars.Count < Core20RangeLookbackBars + 3)
                    return;

                int lastClosed = bars.Count - 2;

                while (true)
                {
                    int next;

                    lock (core20Sync)
                    {
                        if (core20LastRangeProcessed >= lastClosed)
                            break;

                        core20LastRangeProcessed++;
                        next = core20LastRangeProcessed;
                    }

                    if (next >= Core20RangeLookbackBars)
                        ObserveCore20RangeBar(bars, next);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RANGE UPDATE ERROR: " + ex.Message);
            }
        }

        private void ObserveCore20RangeBar(Bars bars, int index)
        {
            DateTime barTime = bars.GetTime(index);
            DateTime barNy = ConvertToNewYorkTime(barTime);
            TimeSpan tod = barNy.TimeOfDay;

            bool pm = tod >= Core20PmStart && tod <= Core20PmEnd;
            bool am = tod > Core20AmStart && tod <= Core20AmEnd;

            if (!pm && !am)
                return;

            double priorHigh = double.MinValue;
            double priorLow = double.MaxValue;

            for (int i = index - Core20RangeLookbackBars; i < index; i++)
            {
                priorHigh = Math.Max(priorHigh, bars.GetHigh(i));
                priorLow = Math.Min(priorLow, bars.GetLow(i));
            }

            double open = bars.GetOpen(index);
            double close = bars.GetClose(index);
            bool upBar = close > open;
            bool breakUp = upBar && close >= priorHigh;
            bool breakDown = !upBar && close <= priorLow;

            if (!breakUp && !breakDown)
                return;

            double delta = GetCore20Delta(barTime);

            if (pm)
            {
                PrintBotMessage(
                    "CORE20 OBSERVE PM FADE"
                    + " | Break " + (breakUp ? "UP" : "DOWN")
                    + " | Close " + close.ToString("0.00")
                    + " | Would trade " + (breakUp ? "SHORT" : "LONG")
                    + " | Delta60s " + delta.ToString("+0;-0;0")
                    + " | NOT EXECUTED"
                );
                return;
            }

            // AM continuation after the day's first zone break.
            if (core20LevelsDate == barNy.Date && core20DayBreakDirection != 0)
            {
                bool sameDirection = core20DayBreakDirection > 0 ? breakUp : breakDown;

                if (sameDirection)
                {
                    PrintBotMessage(
                        "CORE20 OBSERVE CONTINUATION"
                        + " | Side " + (core20DayBreakDirection > 0 ? "LONG" : "SHORT")
                        + " | Close " + close.ToString("0.00")
                        + " | Delta60s " + delta.ToString("+0;-0;0")
                        + " | NOT EXECUTED"
                    );
                }
            }
        }

        // -----------------------------------------------------
        // Management: profit retention + time exit + loss counter.
        // Called from UpdateMomentumTrailingStop() in CORE20 mode.
        // The Daily Target hard close (UpdateDailyTargetProtection) closes
        // the whole day when realized + open PnL reaches the target.
        // -----------------------------------------------------
        private void Core20TryScaleIn(Account account, Instrument instrument, MarketPosition side, int openQty, double favorableTicks, int triggerTicks = -1, bool equalSize = false)
        {
            int scaleTrigger = triggerTicks > 0 ? triggerTicks : Core20ScaleAtTicks;

            if (core20ScaleSent || favorableTicks < scaleTrigger || side == MarketPosition.Flat)
                return;

            int addQty;

            lock (executionStateLock)
            {
                if (!smartScaleInEnabled || smartScaleInUsed || smartScaleInPending || entryPending || dailyTargetProtectionArmed)
                    return;

                // Only on the untouched initial position (no partial exit yet).
                if (openQty != core20InitialQty || activeExitQuantity > 0)
                    return;

                int maxQty = Math.Min(MaxContractsAllowed, openingScaleInMaxContracts);
                addQty = maxQty - openQty;

                // V1.7.36 - never add more than 2/3 of the initial size.
                // Backtest: 12+6 / 12+8 / 10+6 pass evals; 10+10 and 6+14 do not
                // (the combined break-even stop ends up only a few ticks away).
                // V1.7.62 - Open Bell / Gerard averaging adds the SAME size (equalSize), as backtested.
                int addCap = equalSize ? openQty : (int)Math.Floor(openQty * 2.0 / 3.0);
                if (addQty > addCap)
                    addQty = addCap;

                if (addQty <= 0)
                {
                    core20ScaleSent = true;
                    return;
                }

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = DateTime.UtcNow;

                if (smartScaleInAnchorEntryPrice <= 0)
                    smartScaleInAnchorEntryPrice = core20AnchorEntry;
            }

            core20ScaleSent = true;

            try
            {
                OrderAction action = side == MarketPosition.Long ? OrderAction.Buy : OrderAction.SellShort;
                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument, action, OrderType.Market, OrderEntry.Automated, TimeInForce.Day,
                        addQty, 0, 0, string.Empty, orderName, NinjaTrader.Core.Globals.MaxDate, null);

                lock (executionStateLock)
                {
                    if (entryMarketPosition != side)
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(new[] { scaleOrder });

                PrintBotMessage(
                    "CORE20 SCALE-IN SUBMITTED"
                    + " | Side " + (side == MarketPosition.Long ? "LONG" : "SHORT")
                    + " | +" + favorableTicks.ToString("0") + "t"
                    + " | Add " + addQty + " (" + openQty + " -> " + (openQty + addQty) + ")"
                    + " | All contracts protected at entry +" + Core20ScaleLockTicks + "t after fill");
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage("CORE20 SCALE-IN ERROR: " + ex.Message);
            }
        }

        // V1.7.62 - shared management for the Open Bell and Gerard modules:
        // one equal-size averaging at +triggerTicks, then SL of everything = combined average +1t.
        private void Core20ManageScaleModule(Account account, Instrument instrument, MarketPosition side, int openQty,
            Order localStopOrder, double localActiveStop, double localEntry, double currentPrice, double tickSize,
            int triggerTicks, string tag)
        {
            if (tickSize <= 0 || localEntry <= 0)
                return;

            double anchor = core20AnchorEntry > 0 ? core20AnchorEntry : localEntry;

            double fav =
                side == MarketPosition.Long
                    ? (currentPrice - anchor) / tickSize
                    : (anchor - currentPrice) / tickSize;

            if (fav > core20PeakTicks)
                core20PeakTicks = fav;

            bool scaleEnabled;
            lock (executionStateLock)
            {
                scaleEnabled = smartScaleInEnabled;
            }

            if (!scaleEnabled && !core20ScaleSent && fav >= triggerTicks)
            {
                core20ScaleSent = true;
                PrintBotMessage("CORE20 " + tag + " | AVERAGING SKIPPED - Scale-in is OFF in the profile (turn it ON to match the backtest)");
            }

            Core20TryScaleIn(account, instrument, side, openQty, fav, triggerTicks, true);

            bool scaleFilled;
            lock (executionStateLock)
            {
                scaleFilled = smartScaleInUsed;
            }

            // V1.7.72 - Gerard: stop to +0.1R once the trade has run +0.6R (before the +1R averaging).
            if (!scaleFilled && Core20GerardProtectEnabled && tag == "GERARD" && localStopOrder != null
                && core20PeakTicks >= Core20GerardProtectAtR * triggerTicks)
            {
                Core20GerardProtectStop(side, account, localStopOrder, localActiveStop, anchor, currentPrice, tickSize, triggerTicks);
                return;
            }

            if (!scaleFilled || localStopOrder == null)
                return;

            if (localStopOrder.OrderState != OrderState.Working && localStopOrder.OrderState != OrderState.Accepted)
                return;

            // localEntry = combined average entry after the averaging fills.
            double desiredStop =
                RoundToInstrumentTick(side == MarketPosition.Long ? localEntry + tickSize : localEntry - tickSize);

            desiredStop = EnforceNeverWorsenStop(side, localActiveStop, desiredStop);

            bool adjusted;
            bool usedL2;
            double reference;

            desiredStop = ClampProtectiveStopToLiveMarket(side, desiredStop, currentPrice, tickSize, out adjusted, out usedL2, out reference);

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > localActiveStop + tickSize * 0.5
                    : desiredStop < localActiveStop - tickSize * 0.5;

            if (!improves)
                return;

            long token;

            if (!TryBeginProtectiveChange("CORE20_SCALE_BE", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    if (!ReferenceEquals(stopOrder, localStopOrder) || entryMarketPosition != side)
                        return;

                    activeStopPrice = desiredStop;
                    localStopOrder.StopPriceChanged = desiredStop;
                }

                account.Change(new[] { localStopOrder });

                PrintBotMessage(
                    "CORE20 " + tag + " AVERAGED"
                    + " | Combined avg " + localEntry.ToString("0.00")
                    + " | New SL (all contracts, break-even +1t) " + desiredStop.ToString("0.00")
                    + (adjusted ? " | Clamped to live market" : string.Empty));
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 " + tag + " AVERAGING STOP ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }

        // V1.7.72 - Gerard protection tier (+0.6R -> stop at +0.1R). Only ever tightens the stop.
        private void Core20GerardProtectStop(MarketPosition side, Account account, Order localStopOrder,
            double localActiveStop, double anchor, double currentPrice, double tickSize, int oneRTicks)
        {
            if (localStopOrder.OrderState != OrderState.Working && localStopOrder.OrderState != OrderState.Accepted)
                return;

            double lockTicks = Math.Max(1.0, Math.Round(Core20GerardProtectLockR * oneRTicks));

            double desiredStop =
                RoundToInstrumentTick(side == MarketPosition.Long ? anchor + lockTicks * tickSize : anchor - lockTicks * tickSize);

            desiredStop = EnforceNeverWorsenStop(side, localActiveStop, desiredStop);

            bool adjusted;
            bool usedL2;
            double reference;

            desiredStop = ClampProtectiveStopToLiveMarket(side, desiredStop, currentPrice, tickSize, out adjusted, out usedL2, out reference);

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > localActiveStop + tickSize * 0.5
                    : desiredStop < localActiveStop - tickSize * 0.5;

            if (!improves)
                return;

            long token;

            if (!TryBeginProtectiveChange("CORE20_GERARD_PROTECT", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    if (!ReferenceEquals(stopOrder, localStopOrder) || entryMarketPosition != side)
                        return;

                    activeStopPrice = desiredStop;
                    localStopOrder.StopPriceChanged = desiredStop;
                }

                account.Change(new[] { localStopOrder });

                PrintBotMessage(
                    "CORE20 GERARD PROTECT"
                    + " | Peak +" + core20PeakTicks.ToString("0") + "t (" + (core20PeakTicks / Math.Max(1, oneRTicks)).ToString("0.00") + "R)"
                    + " | New SL +" + lockTicks.ToString("0") + "t (+" + Core20GerardProtectLockR.ToString("0.0") + "R) " + desiredStop.ToString("0.00")
                    + (adjusted ? " | Clamped to live market" : string.Empty));
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 GERARD PROTECT ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }

        private void Core20ManageOpenTrade(double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (account == null || instrument == null || currentPrice <= 0)
                return;

            MarketPosition side;
            int openQty;
            Order localStopOrder;
            double localActiveStop;
            double localEntry;
            double dayPnl;
            bool dailyProtection;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                openQty = Math.Max(0, entryQuantity - activeExitQuantity);
                localStopOrder = stopOrder;
                localActiveStop = activeStopPrice;
                localEntry = entryFillPrice;
                dayPnl = botDailyPnL;
                dailyProtection = dailyTargetProtectionArmed;
            }

            DateTime nowNy = GetCurrentNewYorkTime();
            Core20ResetDayIfNeeded(nowNy);

            // ---- trade finished -> count losses ----
            if (side == MarketPosition.Flat || openQty <= 0)
            {
                if (core20TradeOpen)
                {
                    core20TradeOpen = false;
                    double tradePnl = dayPnl - core20DayPnlAtOpen;

                    // V1.7.41 - the Open Bell result is not a CORE20 loss.
                    if (tradePnl < 0 && !core20ObTradeActive && !core20GdTradeActive)
                        core20LossesToday++;

                    PrintBotMessage(
                        "CORE20 TRADE CLOSED"
                        + (core20PmTradeActive ? " | 15:30 MODULE" : string.Empty)
                        + (core20ObTradeActive ? " | OPEN BELL" : string.Empty)
                        + (core20GdTradeActive ? " | GERARD" : string.Empty)
                        + " | PnL " + tradePnl.ToString("$0.00")
                        + " | Losses today " + core20LossesToday + "/" + Core20MaxLossesPerDay
                    );

                    // V1.7.39/41 - 15:30 or Open Bell trade finished: back to profile SL/PT.
                    if (core20PmTradeActive || core20ObTradeActive || core20AmTradeActive || core20GdTradeActive)
                        Core20RestorePmStopOverride("TRADE CLOSED");
                }

                core20TradeOpenSinceNy = DateTime.MinValue;
                core20PeakTicks = 0;
                core20TimeExitSent = false;
                core20AnchorEntry = 0;
                core20InitialQty = 0;
                core20ScaleSent = false;
                return;
            }

            if (!core20TradeOpen)
            {
                core20TradeOpen = true;
                core20DayPnlAtOpen = dayPnl;
                core20TradeOpenSinceNy = nowNy;
                core20PeakTicks = 0;
                core20TimeExitSent = false;
                core20AnchorEntry = localEntry;
                core20InitialQty = openQty;
                core20ScaleSent = false;
            }

            // Daily Target protection owns the position once armed.
            if (dailyProtection)
                return;

            // ---- time exit ----
            if (
                !core20TimeExitSent &&
                (
                    (nowNy - core20TradeOpenSinceNy).TotalMinutes >= Core20MaxHoldMinutes ||
                    nowNy.TimeOfDay >= ((core20ObTradeActive || core20GdTradeActive) ? Core20MorningFlat : Core20LastExit)
                )
            )
            {
                core20TimeExitSent = true;

                try
                {
                    lock (executionStateLock)
                    {
                        activeForcedExitReason = "CORE20_TIME_EXIT";
                    }

                    PrintBotMessage(
                        "CORE20 TIME EXIT"
                        + " | Open since " + core20TradeOpenSinceNy.ToString("HH:mm:ss")
                        + " | Qty " + openQty
                    );

                    SafeFlatten(account, instrument);
                }
                catch (Exception ex)
                {
                    core20TimeExitSent = false;
                    PrintBotMessage("CORE20 TIME EXIT ERROR: " + ex.Message);
                }

                return;
            }

            // V1.7.62 - Gerard: ONE averaging at +1R (same size), then stop of everything to the
            // combined average (+1t). TP 3R and the 10:00 flat are handled elsewhere.
            if (core20GdTradeActive)
            {
                Core20ManageScaleModule(
                    account, instrument, side, openQty, localStopOrder, localActiveStop, localEntry, currentPrice,
                    instrument.MasterInstrument.TickSize, Math.Max(1, core20GdStopTicks), "GERARD");
                return;
            }

            // V1.7.62 - Open Bell: ONE averaging at +80t (same size), then stop of everything to the
            // combined average (+1t). Replaces the old ladder (backtest: +$7,578 ladder -> +$11,718).
            if (core20ObTradeActive)
            {
                Core20ManageScaleModule(
                    account, instrument, side, openQty, localStopOrder, localActiveStop, localEntry, currentPrice,
                    instrument.MasterInstrument.TickSize, Core20ObScaleAtTicks, "OPEN BELL");
                return;
            }

            // V1.7.39 - the 15:30 trade is managed CAZA-style: fixed wide
            // stop, no retention and no scale-in. Daily Target / 15:55 exit close it.
            // V1.7.44 - 15:30 trade protection for INTRADAY-trailing accounts:
            // +10 pts -> stop to +2t (fees), +20 pts -> lock +10 pts.
            // Tick backtest (46 trades, 3 MNQ): net $1,203 -> $1,228, max giveback
            // from the open-profit peak $414 -> $224 (avg $123 -> $78).
            if (core20PmTradeActive)
            {
                Core20ManageOpenBell(account, side, localStopOrder, localActiveStop, currentPrice, instrument.MasterInstrument.TickSize, Core20PmLadder, "15:30");
                return;
            }

            // ---- profit retention ----
            double tickSize = instrument.MasterInstrument.TickSize;

            if (tickSize <= 0 || localEntry <= 0)
                return;

            // All CORE20 distances are measured from the ORIGINAL entry, so a
            // scale-in (which moves the average) never changes the rules.
            double anchor = core20AnchorEntry > 0 ? core20AnchorEntry : localEntry;

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - anchor) / tickSize
                    : (anchor - currentPrice) / tickSize;

            if (favorableTicks > core20PeakTicks)
                core20PeakTicks = favorableTicks;

            // ---- eval scale-in ----
            Core20TryScaleIn(account, instrument, side, openQty, favorableTicks);

            bool scaleFilled;
            lock (executionStateLock)
            {
                scaleFilled = smartScaleInUsed;
            }

            if ((core20PeakTicks < Core20RetentionStartTicks && !scaleFilled) || localStopOrder == null)
                return;

            if (localStopOrder.OrderState != OrderState.Working && localStopOrder.OrderState != OrderState.Accepted)
                return;

            double lockTicks =
                core20PeakTicks >= Core20RetentionStartTicks
                    ? Math.Floor(core20PeakTicks * Core20RetentionFactor)
                    : 0;

            if (scaleFilled)
            {
                // Floor = the larger of +10t and the combined break-even (+1t)
                // measured from the original entry, so the scaled trade can
                // never close as a loss.
                double combinedBeTicks =
                    side == MarketPosition.Long
                        ? (localEntry - anchor) / tickSize
                        : (anchor - localEntry) / tickSize;

                double floorTicks = Math.Max(Core20ScaleLockTicks, Math.Ceiling(combinedBeTicks) + 1);

                if (lockTicks < floorTicks)
                    lockTicks = floorTicks;
            }

            double desiredStop =
                RoundToInstrumentTick(
                    side == MarketPosition.Long
                        ? anchor + lockTicks * tickSize
                        : anchor - lockTicks * tickSize
                );

            desiredStop = EnforceNeverWorsenStop(side, localActiveStop, desiredStop);

            bool adjusted;
            bool usedL2;
            double reference;

            desiredStop =
                ClampProtectiveStopToLiveMarket(
                    side,
                    desiredStop,
                    currentPrice,
                    tickSize,
                    out adjusted,
                    out usedL2,
                    out reference
                );

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > localActiveStop + tickSize * 0.5
                    : desiredStop < localActiveStop - tickSize * 0.5;

            if (!improves)
                return;

            long token;

            if (!TryBeginProtectiveChange("CORE20_RETENTION", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    if (!ReferenceEquals(stopOrder, localStopOrder) || entryMarketPosition != side)
                        return;

                    activeStopPrice = desiredStop;
                    localStopOrder.StopPriceChanged = desiredStop;
                }

                account.Change(new[] { localStopOrder });

                PrintBotMessage(
                    "CORE20 PROFIT RETENTION"
                    + " | Peak +" + core20PeakTicks.ToString("0") + "t"
                    + " | Lock +" + lockTicks.ToString("0") + "t"
                    + " | New SL " + desiredStop.ToString("0.00")
                    + (adjusted ? " | Clamped to live market" : string.Empty)
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RETENTION ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }
    }
}

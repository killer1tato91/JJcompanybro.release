#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{

    // =========================================================
    // V1.7.35 - CORE20 ZONE BUS (visual only)
    // =========================================================
    // The bot publishes the zones it actually uses and every trigger it
    // evaluated (ENTRY / SKIP + reason) so JJBotChart can draw them.
    // Read-only for the chart: it never affects trading.
    public sealed class JJCore20ZoneInfo
    {
        public string Name;
        public double Price;
        public bool IsHigh;
        public bool Swept;
        public bool SweepUsed;
        public bool BreakUsed;
    }

    public sealed class JJCore20EventInfo
    {
        public string Key;
        public DateTime BarTime;     // same time zone as chart bars
        public string Zone;
        public double ZonePrice;
        public string Trigger;       // SWEEP / BREAK
        public bool IsLong;
        public double Price;
        public double Delta;
        public string Decision;      // ENTRY / SKIP - reason
    }

    public sealed class JJCore20ZoneSnapshot
    {
        public string InstrumentName;
        public DateTime SessionDateNy;
        public List<JJCore20ZoneInfo> Zones = new List<JJCore20ZoneInfo>();
        public List<JJCore20EventInfo> Events = new List<JJCore20EventInfo>();
        public long Version;
    }

    public static class JJCore20ZoneBus
    {
        private static readonly object Sync = new object();
        private static readonly Dictionary<string, JJCore20ZoneSnapshot> ByInstrument =
            new Dictionary<string, JJCore20ZoneSnapshot>(StringComparer.OrdinalIgnoreCase);

        public static event Action<string> Changed;

        private static JJCore20ZoneSnapshot GetOrCreate(string instrument, DateTime sessionDateNy)
        {
            JJCore20ZoneSnapshot snap;
            if (!ByInstrument.TryGetValue(instrument, out snap) || snap == null || snap.SessionDateNy != sessionDateNy)
            {
                snap = new JJCore20ZoneSnapshot { InstrumentName = instrument, SessionDateNy = sessionDateNy };
                ByInstrument[instrument] = snap;
            }
            return snap;
        }

        public static void PublishZones(string instrument, DateTime sessionDateNy, IEnumerable<JJCore20ZoneInfo> zones)
        {
            if (string.IsNullOrWhiteSpace(instrument)) return;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap = GetOrCreate(instrument, sessionDateNy);
                snap.Zones = zones == null ? new List<JJCore20ZoneInfo>() : zones.ToList();
                snap.Version++;
            }
            Raise(instrument);
        }

        public static void PublishEvent(string instrument, DateTime sessionDateNy, JJCore20EventInfo ev)
        {
            if (string.IsNullOrWhiteSpace(instrument) || ev == null) return;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap = GetOrCreate(instrument, sessionDateNy);
                JJCore20EventInfo existing = snap.Events.FirstOrDefault(e => e.Key == ev.Key);
                if (existing == null)
                    snap.Events.Add(ev);
                else if (ev.Decision == "ENTRY")
                    existing.Decision = "ENTRY";   // several profiles: keep the executed view
                snap.Version++;
            }
            Raise(instrument);
        }

        public static JJCore20ZoneSnapshot GetSnapshot(string instrument)
        {
            if (string.IsNullOrWhiteSpace(instrument)) return null;
            lock (Sync)
            {
                JJCore20ZoneSnapshot snap;
                if (!ByInstrument.TryGetValue(instrument, out snap) || snap == null) return null;
                return new JJCore20ZoneSnapshot
                {
                    InstrumentName = snap.InstrumentName,
                    SessionDateNy = snap.SessionDateNy,
                    Version = snap.Version,
                    Zones = snap.Zones.Select(z => new JJCore20ZoneInfo { Name = z.Name, Price = z.Price, IsHigh = z.IsHigh, Swept = z.Swept, SweepUsed = z.SweepUsed, BreakUsed = z.BreakUsed }).ToList(),
                    Events = snap.Events.Select(e => new JJCore20EventInfo { Key = e.Key, BarTime = e.BarTime, Zone = e.Zone, ZonePrice = e.ZonePrice, Trigger = e.Trigger, IsLong = e.IsLong, Price = e.Price, Delta = e.Delta, Decision = e.Decision }).ToList()
                };
            }
        }

        private static void Raise(string instrument)
        {
            Action<string> handler = Changed;
            if (handler == null) return;
            foreach (Delegate d in handler.GetInvocationList())
            {
                try { ((Action<string>)d)(instrument); } catch { }
            }
        }
    }

    // =========================================================
    // V1.7.33 - JJ BOT CORE20 (FINAL)
    // =========================================================
    // EXECUTION: NY AM 09:30-12:00 only (max 6 trades until Daily Target, session counter).
    // V1.7.35: runs on the V1.7.31 Single Central Signal Authority. TrySubmitEntry
    // proposes the CORE20 candidate; every profile receives the SAME DecisionId
    // and applies only its own account/CORE20 rules.
    //
    // Before 09:30 the bot maps four ZONES:
    //   ONH / ONL = overnight high/low (18:00 prev day -> 09:30)
    //   PDH / PDL = prior RTH high/low (09:30 -> 16:00)
    //
    // Two triggers per zone (each used once per day), evaluated on the
    // CLOSE of every 1-minute bar:
    //   SWEEP : price traded >= 8 ticks beyond the zone and a 1m bar
    //           closes back inside           -> trade AGAINST the sweep.
    //   BREAK : a 1m bar closes >= 8 ticks beyond the zone
    //                                         -> trade WITH the break.
    // Level 2 confirmation (mandatory): net aggressive tape volume of the
    // last 60 s (Last>=Ask buys minus Last<=Bid sells) must favour the
    // trade side. Otherwise the trigger is skipped and consumed.
    //
    // MANAGEMENT (no partials, no scale-in):
    //   - Initial stop = configured Stop (recommended 60 ticks).
    //   - Profit retention: once peak MFE >= 30 ticks the stop trails at
    //     30% of the peak (never loosens).
    //   - The DAY closes when realized + open PnL reaches the Daily Target
    //     (existing Daily Target hard close, set by Mission in the app).
    //   - Time exit after 60 minutes.
    //   - Day stops after 2 losing CORE20 trades (or Daily Loss).
    //
    // OBSERVE ONLY (logged, never executed):
    //   - PM 14:00-15:45 Range-60 breakout fade.
    //   - AM continuation: Range-60 break in the direction of the day's
    //     first zone break.
    //   - AM defended zone: touch without break, close back away.
    //
    // Orders always go through TrySubmitEntry(): license, session limits,
    // Daily Target/Loss, risk cap, flat position, Final Entry Authority
    // and the atomic submit remain authoritative.
    // =========================================================
    public partial class JJBotWindow
    {
        private const string Core20StrategyName = "CORE20";
        private const int Core20ZoneTicks = 8;
        private const int Core20DefendTouchTicks = 4;
        private const int Core20DefendLookBars = 3;
        private const int Core20DeltaWindowSeconds = 60;
        private const int Core20RetentionStartTicks = 30;
        private const double Core20RetentionFactor = 0.30;
        private const int Core20MaxLossesPerDay = 2;
        private const int Core20MaxHoldMinutes = 60;
        // V1.7.36 - EVAL SCALE: add (Max Contracts - Contracts) once the trade
        // is +25 ticks, then every contract is protected at entry +10 ticks.
        // Enabled with Scale-In ON and Max Contracts > Contracts.
        private const int Core20ScaleAtTicks = 25;
        private const int Core20ScaleLockTicks = 10;
        private const int Core20RangeTicks = 60;
        private const int Core20RangeLookbackBars = 20;
        private const int Core20MinuteBarsBack = 3000;
        private const int Core20RangeBarsBack = 400;
        private static readonly TimeSpan Core20AmStart = new TimeSpan(9, 30, 0);
        private static readonly TimeSpan Core20AmEnd = new TimeSpan(12, 0, 0);
		        // V1.7.37 - first RTH minute bars (close <= 09:32 NY) never open a CORE20 trade.
        private static readonly TimeSpan Core20NoEntryUntil = new TimeSpan(9, 32, 0);
        private static readonly TimeSpan Core20PmStart = new TimeSpan(14, 0, 0);
        private static readonly TimeSpan Core20PmEnd = new TimeSpan(15, 45, 59);
        private static readonly TimeSpan Core20RthEnd = new TimeSpan(16, 0, 0);
        private static readonly TimeSpan Core20LastExit = new TimeSpan(15, 55, 0);

        private readonly object core20Sync = new object();

        private BarsRequest core20MinuteRequest;
        private BarsRequest core20RangeRequest;
        private bool core20MinuteSubscribed;
        private bool core20RangeSubscribed;
        private bool core20MinuteReady;
        private bool core20RangeReady;
        private int core20LastMinuteProcessed = -1;
        private int core20LastRangeProcessed = -1;

        private Instrument core20TapeInstrument;
        private bool core20TapeActive;
        private double core20LastBid;
        private double core20LastAsk;
        private readonly Queue<KeyValuePair<DateTime, double>> core20Tape =
            new Queue<KeyValuePair<DateTime, double>>();

        private DateTime core20LevelsDate = DateTime.MinValue;
        private readonly List<Core20Level> core20Levels = new List<Core20Level>();
        private int core20DayBreakDirection;

        // Trade tracking (losses per day, time exit, retention peak).
        private DateTime core20StatsDate = DateTime.MinValue;
        private int core20LossesToday;
        private bool core20TradeOpen;
        private double core20DayPnlAtOpen;
        private DateTime core20TradeOpenSinceNy = DateTime.MinValue;
        private double core20AnchorEntry;
        private int core20InitialQty;
        private bool core20ScaleSent;
        private double core20PeakTicks;
        private bool core20TimeExitSent;

        private string core20SetupStatus = "WAITING";
        private string core20TriggerStatus = "WAITING";

        private sealed class Core20Level
        {
            public string Name;
            public double Price;
            public bool IsHigh;
            public bool Swept;
            public bool SweepUsed;
            public bool BreakUsed;
            public int DefendTouchBar = -1;
            public bool DefendUsed;
        }

        // -----------------------------------------------------
        // Mode
        // -----------------------------------------------------
        private bool IsCore20Mode()
        {
            return string.Equals(activeStrategyMode, Core20StrategyName, StringComparison.OrdinalIgnoreCase);
        }

        private bool IsCore20Strategy(string strategy)
        {
            return string.Equals(strategy, Core20StrategyName, StringComparison.OrdinalIgnoreCase);
        }

        private bool Core20DirectionAllows(bool isLong)
        {
            string direction = (activeDirection ?? "BOTH").Trim().ToUpperInvariant();

            if (direction == "LONG ONLY")
                return isLong;

            if (direction == "SHORT ONLY")
                return !isLong;

            return true;
        }

        private void Core20ResetDayIfNeeded(DateTime nyDate)
        {
            if (core20StatsDate == nyDate.Date)
                return;

            core20StatsDate = nyDate.Date;
            core20LossesToday = 0;
        }

        // -----------------------------------------------------
        // Start / stop (called from StartBarsEngine / StopBarsEngine)
        // -----------------------------------------------------
        private void StartCore20Engine()
        {
            StopCore20Engine();

            if (!IsCore20Mode() || selectedInstrument == null)
                return;

            lock (core20Sync)
            {
                core20MinuteReady = false;
                core20RangeReady = false;
                core20LastMinuteProcessed = -1;
                core20LastRangeProcessed = -1;
                core20LastBid = 0;
                core20LastAsk = 0;
                core20Tape.Clear();
            }

            core20LevelsDate = DateTime.MinValue;
            core20Levels.Clear();
            core20DayBreakDirection = 0;
            core20TradeOpen = false;
            core20TradeOpenSinceNy = DateTime.MinValue;
            core20PeakTicks = 0;
            core20TimeExitSent = false;
            core20SetupStatus = "WAITING DATA";
            core20TriggerStatus = "WAITING";

            try
            {
                core20MinuteRequest = new BarsRequest(selectedInstrument, Core20MinuteBarsBack);
                core20MinuteRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
                core20MinuteRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                core20MinuteRequest.Update += OnCore20MinuteUpdate;
                core20MinuteSubscribed = true;
                core20MinuteRequest.Request(new Action<BarsRequest, ErrorCode, string>(OnCore20MinuteCompleted));

                core20RangeRequest = new BarsRequest(selectedInstrument, Core20RangeBarsBack);
                core20RangeRequest.BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Range, Value = Core20RangeTicks };
                core20RangeRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                core20RangeRequest.Update += OnCore20RangeUpdate;
                core20RangeSubscribed = true;
                core20RangeRequest.Request(new Action<BarsRequest, ErrorCode, string>(OnCore20RangeCompleted));

                StartCore20Tape();

                PrintBotMessage(
                    "CORE20 ENGINE STARTED"
                    + " | AM 09:30-12:00: ZONE SWEEP / BREAK + DELTA " + Core20DeltaWindowSeconds + "s"
                    + " | SL " + activeStopTicks + "t | Retention " + (int)(Core20RetentionFactor * 100) + "% from +" + Core20RetentionStartTicks + "t"
                    + " | Day close: Daily Target / Daily Loss / " + Core20MaxLossesPerDay + " losses"
                    + " | PM + continuation + defended zone: OBSERVE ONLY"
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 START ERROR: " + ex.Message);
            }
        }

        private void StopCore20Engine()
        {
            StopCore20Tape();

            try
            {
                if (core20MinuteRequest != null)
                {
                    if (core20MinuteSubscribed)
                        core20MinuteRequest.Update -= OnCore20MinuteUpdate;

                    core20MinuteSubscribed = false;
                    core20MinuteRequest.Dispose();
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 MINUTE CLEANUP ERROR: " + ex.Message);
            }

            core20MinuteRequest = null;

            try
            {
                if (core20RangeRequest != null)
                {
                    if (core20RangeSubscribed)
                        core20RangeRequest.Update -= OnCore20RangeUpdate;

                    core20RangeSubscribed = false;
                    core20RangeRequest.Dispose();
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RANGE CLEANUP ERROR: " + ex.Message);
            }

            core20RangeRequest = null;

            lock (core20Sync)
            {
                core20MinuteReady = false;
                core20RangeReady = false;
            }
        }

        // -----------------------------------------------------
        // Tape (Level 2 time & sales): aggressor classification
        // -----------------------------------------------------
        private void StartCore20Tape()
        {
            core20TapeInstrument = selectedInstrument;
            core20TapeActive = true;

            Instrument instrument = core20TapeInstrument;

            instrument.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    if (core20TapeActive && core20TapeInstrument != null)
                        core20TapeInstrument.MarketData.Update += OnCore20MarketData;
                })
            );
        }

        private void StopCore20Tape()
        {
            Instrument oldInstrument = core20TapeInstrument;
            core20TapeActive = false;
            core20TapeInstrument = null;

            if (oldInstrument == null)
                return;

            oldInstrument.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    try
                    {
                        oldInstrument.MarketData.Update -= OnCore20MarketData;
                    }
                    catch
                    {
                    }
                })
            );
        }

        private void OnCore20MarketData(object sender, MarketDataEventArgs e)
        {
            if (!core20TapeActive || e == null)
                return;

            lock (core20Sync)
            {
                if (e.MarketDataType == MarketDataType.Bid)
                {
                    core20LastBid = e.Price;
                    return;
                }

                if (e.MarketDataType == MarketDataType.Ask)
                {
                    core20LastAsk = e.Price;
                    return;
                }

                if (e.MarketDataType != MarketDataType.Last)
                    return;

                double signedVolume = 0;

                if (core20LastAsk > 0 && e.Price >= core20LastAsk)
                    signedVolume = e.Volume;
                else if (core20LastBid > 0 && e.Price <= core20LastBid)
                    signedVolume = -e.Volume;

                if (signedVolume != 0)
                    core20Tape.Enqueue(new KeyValuePair<DateTime, double>(e.Time, signedVolume));

                DateTime cutoff = e.Time.AddSeconds(-(Core20DeltaWindowSeconds * 3));

                while (core20Tape.Count > 0 && core20Tape.Peek().Key < cutoff)
                    core20Tape.Dequeue();
            }
        }

        // Net aggressive volume (buy - sell) in (endTime - 60s, endTime].
        private double GetCore20Delta(DateTime endTime)
        {
            DateTime startTime = endTime.AddSeconds(-Core20DeltaWindowSeconds);
            double delta = 0;

            lock (core20Sync)
            {
                foreach (KeyValuePair<DateTime, double> item in core20Tape)
                {
                    if (item.Key > startTime && item.Key <= endTime)
                        delta += item.Value;
                }
            }

            return delta;
        }

        // -----------------------------------------------------
        // 1-minute series: zone map + AM triggers
        // -----------------------------------------------------
        private void OnCore20MinuteCompleted(BarsRequest request, ErrorCode errorCode, string errorMessage)
        {
            if (errorCode != ErrorCode.NoError || request == null || request.Bars == null)
            {
                PrintBotMessage("CORE20 1M DATA ERROR: " + errorCode + " | " + errorMessage);
                return;
            }

            lock (core20Sync)
            {
                core20MinuteReady = true;
                // History is used for the zone map only; never replay old signals.
                core20LastMinuteProcessed = request.Bars.Count - 2;
            }

            PrintBotMessage("CORE20 1M DATA READY | Bars: " + request.Bars.Count);
        }

        private void OnCore20MinuteUpdate(object sender, BarsUpdateEventArgs e)
        {
            if (!botRunning || !IsCore20Mode() || !core20MinuteReady || core20MinuteRequest == null)
                return;

            try
            {
                Bars bars = core20MinuteRequest.Bars;

                if (bars == null || bars.Count < 3)
                    return;

                int lastClosed = bars.Count - 2;

                while (true)
                {
                    int next;

                    lock (core20Sync)
                    {
                        if (core20LastMinuteProcessed >= lastClosed)
                            break;

                        core20LastMinuteProcessed++;
                        next = core20LastMinuteProcessed;
                    }

                    if (next >= 0)
                        ProcessCore20MinuteBar(bars, next);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 1M UPDATE ERROR: " + ex.Message);
            }
        }

        private void ProcessCore20MinuteBar(Bars bars, int index)
        {
            DateTime barTime = bars.GetTime(index);
            DateTime barNy = ConvertToNewYorkTime(barTime);
            TimeSpan tod = barNy.TimeOfDay;

            // NinjaTrader minute bars are stamped with their CLOSE time:
            // the 09:31 bar is the first RTH minute.
            if (tod <= Core20AmStart || tod > Core20AmEnd)
            {
                if (tod <= Core20AmStart && tod >= new TimeSpan(9, 0, 0))
                    core20SetupStatus = "BUILDING ZONE MAP";

                return;
            }

            Core20ResetDayIfNeeded(barNy);
            EnsureCore20Levels(bars, index, barNy.Date);

            if (core20LevelsDate != barNy.Date || core20Levels.Count == 0)
                return;

            double tickSize = selectedInstrument.MasterInstrument.TickSize;
            double zone = Core20ZoneTicks * tickSize;
            double touch = Core20DefendTouchTicks * tickSize;

            double high = bars.GetHigh(index);
            double low = bars.GetLow(index);
            double close = bars.GetClose(index);

            bool submitted = false;

            foreach (Core20Level level in core20Levels)
            {
                // ---------- SWEEP ----------
                if (!level.SweepUsed)
                {
                    if (!level.Swept && (level.IsHigh ? high >= level.Price + zone : low <= level.Price - zone))
                    {
                        level.Swept = true;
                        core20SetupStatus = level.Name + " SWEPT @ " + level.Price.ToString("0.00");
                        PrintBotMessage("CORE20 SWEEP | " + level.Name + " " + level.Price.ToString("0.00") + " | Waiting 1m close back inside");
                        PublishCore20Zones();
                    }

                    if (level.Swept && (level.IsHigh ? close < level.Price : close > level.Price))
                    {
                        level.SweepUsed = true;
                        TryCore20Entry(!level.IsHigh, "SWEEP", level, close, barTime, ref submitted);
                    }
                }

                // ---------- BREAK ----------
                if (!level.BreakUsed && (level.IsHigh ? close >= level.Price + zone : close <= level.Price - zone))
                {
                    level.BreakUsed = true;

                    if (core20DayBreakDirection == 0)
                        core20DayBreakDirection = level.IsHigh ? 1 : -1;

                    TryCore20Entry(level.IsHigh, "BREAK", level, close, barTime, ref submitted);
                }

                // ---------- DEFENDED ZONE (observe only) ----------
                if (!level.DefendUsed)
                {
                    bool touched =
                        level.IsHigh
                            ? high >= level.Price - touch && high < level.Price + zone
                            : low <= level.Price + touch && low > level.Price - zone;

                    bool brokeThrough =
                        level.IsHigh ? high >= level.Price + zone : low <= level.Price - zone;

                    if (level.DefendTouchBar < 0 && touched)
                        level.DefendTouchBar = index;

                    if (level.DefendTouchBar >= 0)
                    {
                        if (brokeThrough || index - level.DefendTouchBar >= Core20DefendLookBars)
                        {
                            level.DefendUsed = true;
                        }
                        else if (level.IsHigh ? close < level.Price - touch : close > level.Price + touch)
                        {
                            level.DefendUsed = true;
                            bool isLong = !level.IsHigh;
                            double d = GetCore20Delta(barTime);

                            PrintBotMessage(
                                "CORE20 OBSERVE DEFENDED ZONE"
                                + " | " + level.Name + " " + level.Price.ToString("0.00")
                                + " | Side " + (isLong ? "LONG" : "SHORT")
                                + " | Close " + close.ToString("0.00")
                                + " | Delta60s " + d.ToString("+0;-0;0")
                                + " | NOT EXECUTED"
                            );
                        }
                    }
                }
            }
        }

        // V1.7.35 - price of the last traded tick (market-data time domain,
        // valid in live and Playback).  0 when unknown.
        private double GetCore20LastTradePrice()
        {
            lock (level2Sync)
            {
                return level2LastTradePrice;
            }
        }

        // V1.7.35 - account-side CORE20 authority for a CENTRAL decision.
        // The central signal is the same for every profile; this only applies
        // the rules that belong to THIS account's CORE20 day.
        private const int Core20MaxSignalDriftTicks = 20;

        private bool Core20AccountAllowsCentralSignal(JJCentralMarketDecision signal, out string reason)
        {
            reason = string.Empty;

            Core20ResetDayIfNeeded(GetCurrentNewYorkTime());

            if (core20LossesToday >= Core20MaxLossesPerDay)
            {
                reason = "CORE20 " + Core20MaxLossesPerDay + " LOSSES TODAY";
                return false;
            }

            if (!Core20DirectionAllows(signal.IsLong))
            {
                reason = "CORE20 DIRECTION SETTING";
                return false;
            }

            double tickSize =
                selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double nowPrice = GetCore20LastTradePrice();

            if (tickSize > 0 && signal.SignalPrice > 0 && nowPrice > 0)
            {
                double driftTicks = Math.Abs(nowPrice - signal.SignalPrice) / tickSize;

                if (driftTicks > Core20MaxSignalDriftTicks)
                {
                    reason = "CORE20 PRICE MOVED " + driftTicks.ToString("0") + "t SINCE SIGNAL";
                    return false;
                }
            }

            return true;
        }

        private void PublishCore20Zones()
        {
            try
            {
                if (selectedInstrument == null) return;
                JJCore20ZoneBus.PublishZones(
                    selectedInstrument.FullName,
                    core20LevelsDate,
                    core20Levels.Select(l => new JJCore20ZoneInfo
                    {
                        Name = l.Name, Price = l.Price, IsHigh = l.IsHigh,
                        Swept = l.Swept, SweepUsed = l.SweepUsed, BreakUsed = l.BreakUsed
                    }).ToList());
            }
            catch { }
        }

        private void PublishCore20Event(string trigger, Core20Level level, bool isLong, double close, DateTime barTime, double delta, string decision)
        {
            try
            {
                if (selectedInstrument == null || level == null) return;
                JJCore20ZoneBus.PublishEvent(
                    selectedInstrument.FullName,
                    core20LevelsDate,
                    new JJCore20EventInfo
                    {
                        Key = barTime.Ticks + "|" + level.Name + "|" + trigger,
                        BarTime = barTime,
                        Zone = level.Name,
                        ZonePrice = level.Price,
                        Trigger = trigger,
                        IsLong = isLong,
                        Price = close,
                        Delta = delta,
                        Decision = decision
                    });
                PublishCore20Zones();
            }
            catch { }
        }

        private string Core20L2Snapshot()
        {
            try
            {
                lock (level2Sync)
                {
                    return "Ready " + (level2BookReady ? "YES" : "WARMUP")
                        + " Bias " + level2Bias
                        + " Bid/Ask " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0")
                        + " Top10 " + level2TopBidVolume + "/" + level2TopAskVolume
                        + " Stack " + level2StackPull
                        + " Absorb " + level2Absorption
                        + " Spread " + level2SpreadTicks.ToString("0.0") + "t";
                }
            }
            catch
            {
                return "n/a";
            }
        }

        private void TryCore20Entry(bool isLong, string trigger, Core20Level level, double close, DateTime barTime, ref bool submitted)
        {
            double delta = GetCore20Delta(barTime);
            double alignedDelta = isLong ? delta : -delta;

            string summary =
                "CORE20 " + trigger
                + " | Zone " + level.Name + " " + level.Price.ToString("0.00")
                + " | Close " + close.ToString("0.00")
                + " | Side " + (isLong ? "LONG" : "SHORT")
                + " | Delta60s " + delta.ToString("+0;-0;0")
                // V1.7.36 - Level 2 book snapshot AT the signal (recorded for
                // analysis: does the book predict which CORE20 trades fail?).
                + " | L2 " + Core20L2Snapshot();
			            // V1.7.37 - NO ENTRIES IN THE FIRST 2 MINUTES OF RTH (bars closing 09:31 and 09:32).
            TimeSpan barTod = ConvertToNewYorkTime(barTime).TimeOfDay;

            if (barTod <= Core20NoEntryUntil)
            {
                core20TriggerStatus = trigger + " " + level.Name + " - OPENING SKIP";
                PrintBotMessage(summary + " | Decision: SKIP - OPENING 09:30-09:32 (no entries)");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - OPENING");
                return;
            }

            if (alignedDelta <= 0)
            {
                core20TriggerStatus = trigger + " " + level.Name + " - DELTA AGAINST";
                PrintBotMessage(summary + " | Decision: SKIP - TAPE NOT CONFIRMING");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - TAPE");
                return;
            }

            if (core20LossesToday >= Core20MaxLossesPerDay)
            {
                PrintBotMessage(summary + " | Decision: SKIP - " + Core20MaxLossesPerDay + " LOSSES TODAY");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - 2 LOSSES");
                return;
            }

            if (!Core20DirectionAllows(isLong))
            {
                PrintBotMessage(summary + " | Decision: SKIP - DIRECTION SETTING");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - DIRECTION");
                return;
            }

            if (submitted)
            {
                PrintBotMessage(summary + " | Decision: SKIP - ONE ENTRY PER BAR");
                PublishCore20Event(trigger, level, isLong, close, barTime, delta, "SKIP - 1 PER BAR");
                return;
            }

            submitted = true;
            core20TriggerStatus = trigger + " " + level.Name + " - DELTA CONFIRMED";
            PrintBotMessage(summary + " | Decision: ENTRY");
            PublishCore20Event(trigger, level, isLong, close, barTime, delta, "ENTRY");

            // V1.7.36 - learning label per zone + trigger (e.g. CORE20_SWEEP_PDH)
            // so Learning shows which zone / trigger works best.
            try
            {
                CaptureLearningSignalContext(
                    isLong ? "LONG" : "SHORT",
                    ConvertToNewYorkTime(barTime),
                    "CORE20_" + trigger + "_" + level.Name);
            }
            catch
            {
            }

            TrySubmitEntry(
                isLong,
                barTime,
                false,
                null,
                false,
                false,
                Core20StrategyName,
                "CORE20_" + trigger,
                summary
            );
        }

        private void EnsureCore20Levels(Bars bars, int index, DateTime sessionDate)
        {
            if (core20LevelsDate == sessionDate)
                return;

            DateTime overnightStart = sessionDate.AddDays(-1).Add(new TimeSpan(18, 0, 0));
            DateTime rthOpen = sessionDate.Add(Core20AmStart);

            double onh = double.MinValue, onl = double.MaxValue;
            double pdh = double.MinValue, pdl = double.MaxValue;
            DateTime priorRthDate = DateTime.MinValue;
            double rthOpen930 = 0;

            for (int i = index; i >= 0; i--)
            {
                DateTime ny = ConvertToNewYorkTime(bars.GetTime(i));

                // First RTH bar of the session (closes at 09:31): its open is
                // the 09:30 opening price.
                if (ny.Date == sessionDate && ny.TimeOfDay > Core20AmStart && ny.TimeOfDay <= Core20AmStart.Add(TimeSpan.FromMinutes(1)))
                    rthOpen930 = bars.GetOpen(i);

                if (ny < sessionDate.AddDays(-6))
                    break;

                // Overnight: (18:00 previous day, 09:30]
                if (ny > overnightStart && ny <= rthOpen)
                {
                    onh = Math.Max(onh, bars.GetHigh(i));
                    onl = Math.Min(onl, bars.GetLow(i));
                }

                // Prior RTH session: (09:30, 16:00] of the most recent earlier date.
                TimeSpan t = ny.TimeOfDay;

                if (ny.Date < sessionDate && t > Core20AmStart && t <= Core20RthEnd)
                {
                    if (priorRthDate == DateTime.MinValue)
                        priorRthDate = ny.Date;

                    if (ny.Date == priorRthDate)
                    {
                        pdh = Math.Max(pdh, bars.GetHigh(i));
                        pdl = Math.Min(pdl, bars.GetLow(i));
                    }
                }
            }

            core20Levels.Clear();
            core20DayBreakDirection = 0;

            if (onh > double.MinValue && onl < double.MaxValue)
            {
                core20Levels.Add(new Core20Level { Name = "ONH", Price = onh, IsHigh = true });
                core20Levels.Add(new Core20Level { Name = "ONL", Price = onl, IsHigh = false });
            }

            if (pdh > double.MinValue && pdl < double.MaxValue)
            {
                core20Levels.Add(new Core20Level { Name = "PDH", Price = pdh, IsHigh = true });
                core20Levels.Add(new Core20Level { Name = "PDL", Price = pdl, IsHigh = false });
            }

            core20LevelsDate = sessionDate;

            // V1.7.36 - A zone that is ALREADY broken when NY opens (price opened
            // 8+ ticks beyond it) is not a fresh break: no BREAK trade on it.
            // Backtest: removes the first-bar gap "breaks" (-$25/trade) ->
            // Jun-Aug +$1,803 -> +$1,986, worst streak -$562 -> -$375; Sep +$552 -> +$705.
            // Sweeps (reclaim back inside) on those zones stay allowed.
            string gapped = string.Empty;
            double zoneTicksPx = selectedInstrument != null ? Core20ZoneTicks * selectedInstrument.MasterInstrument.TickSize : 0;

            if (rthOpen930 > 0 && zoneTicksPx > 0)
            {
                foreach (Core20Level l in core20Levels)
                {
                    bool alreadyBroken =
                        l.IsHigh
                            ? rthOpen930 >= l.Price + zoneTicksPx
                            : rthOpen930 <= l.Price - zoneTicksPx;

                    if (alreadyBroken)
                    {
                        l.BreakUsed = true;
                        gapped += (gapped.Length > 0 ? "," : string.Empty) + l.Name;
                    }
                }
            }

            string map =
                core20Levels.Count == 0
                    ? "NO ZONES"
                    : string.Join(" | ", core20Levels.Select(l => l.Name + " " + l.Price.ToString("0.00")));

            core20SetupStatus = "ZONE MAP READY | " + map;
            PublishCore20Zones();

            PrintBotMessage(
                "CORE20 ZONE MAP"
                + " | Session " + sessionDate.ToString("yyyy-MM-dd")
                + " | " + map
                + (priorRthDate != DateTime.MinValue ? " | PD from " + priorRthDate.ToString("yyyy-MM-dd") : " | PD: n/a")
                + (gapped.Length > 0 ? " | Already broken at open (no BREAK): " + gapped : string.Empty)
            );
        }

        // -----------------------------------------------------
        // Range-60 series: OBSERVE ONLY (PM fade, AM continuation)
        // -----------------------------------------------------
        private void OnCore20RangeCompleted(BarsRequest request, ErrorCode errorCode, string errorMessage)
        {
            if (errorCode != ErrorCode.NoError || request == null || request.Bars == null)
            {
                PrintBotMessage("CORE20 RANGE DATA ERROR: " + errorCode + " | " + errorMessage);
                return;
            }

            lock (core20Sync)
            {
                core20RangeReady = true;
                core20LastRangeProcessed = request.Bars.Count - 2;
            }

            PrintBotMessage("CORE20 RANGE-" + Core20RangeTicks + " DATA READY (observe) | Bars: " + request.Bars.Count);
        }

        private void OnCore20RangeUpdate(object sender, BarsUpdateEventArgs e)
        {
            if (!botRunning || !IsCore20Mode() || !core20RangeReady || core20RangeRequest == null)
                return;

            try
            {
                Bars bars = core20RangeRequest.Bars;

                if (bars == null || bars.Count < Core20RangeLookbackBars + 3)
                    return;

                int lastClosed = bars.Count - 2;

                while (true)
                {
                    int next;

                    lock (core20Sync)
                    {
                        if (core20LastRangeProcessed >= lastClosed)
                            break;

                        core20LastRangeProcessed++;
                        next = core20LastRangeProcessed;
                    }

                    if (next >= Core20RangeLookbackBars)
                        ObserveCore20RangeBar(bars, next);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RANGE UPDATE ERROR: " + ex.Message);
            }
        }

        private void ObserveCore20RangeBar(Bars bars, int index)
        {
            DateTime barTime = bars.GetTime(index);
            DateTime barNy = ConvertToNewYorkTime(barTime);
            TimeSpan tod = barNy.TimeOfDay;

            bool pm = tod >= Core20PmStart && tod <= Core20PmEnd;
            bool am = tod > Core20AmStart && tod <= Core20AmEnd;

            if (!pm && !am)
                return;

            double priorHigh = double.MinValue;
            double priorLow = double.MaxValue;

            for (int i = index - Core20RangeLookbackBars; i < index; i++)
            {
                priorHigh = Math.Max(priorHigh, bars.GetHigh(i));
                priorLow = Math.Min(priorLow, bars.GetLow(i));
            }

            double open = bars.GetOpen(index);
            double close = bars.GetClose(index);
            bool upBar = close > open;
            bool breakUp = upBar && close >= priorHigh;
            bool breakDown = !upBar && close <= priorLow;

            if (!breakUp && !breakDown)
                return;

            double delta = GetCore20Delta(barTime);

            if (pm)
            {
                PrintBotMessage(
                    "CORE20 OBSERVE PM FADE"
                    + " | Break " + (breakUp ? "UP" : "DOWN")
                    + " | Close " + close.ToString("0.00")
                    + " | Would trade " + (breakUp ? "SHORT" : "LONG")
                    + " | Delta60s " + delta.ToString("+0;-0;0")
                    + " | NOT EXECUTED"
                );
                return;
            }

            // AM continuation after the day's first zone break.
            if (core20LevelsDate == barNy.Date && core20DayBreakDirection != 0)
            {
                bool sameDirection = core20DayBreakDirection > 0 ? breakUp : breakDown;

                if (sameDirection)
                {
                    PrintBotMessage(
                        "CORE20 OBSERVE CONTINUATION"
                        + " | Side " + (core20DayBreakDirection > 0 ? "LONG" : "SHORT")
                        + " | Close " + close.ToString("0.00")
                        + " | Delta60s " + delta.ToString("+0;-0;0")
                        + " | NOT EXECUTED"
                    );
                }
            }
        }

        // -----------------------------------------------------
        // Management: profit retention + time exit + loss counter.
        // Called from UpdateMomentumTrailingStop() in CORE20 mode.
        // The Daily Target hard close (UpdateDailyTargetProtection) closes
        // the whole day when realized + open PnL reaches the target.
        // -----------------------------------------------------
        private void Core20TryScaleIn(Account account, Instrument instrument, MarketPosition side, int openQty, double favorableTicks)
        {
            if (core20ScaleSent || favorableTicks < Core20ScaleAtTicks || side == MarketPosition.Flat)
                return;

            int addQty;

            lock (executionStateLock)
            {
                if (!smartScaleInEnabled || smartScaleInUsed || smartScaleInPending || entryPending || dailyTargetProtectionArmed)
                    return;

                // Only on the untouched initial position (no partial exit yet).
                if (openQty != core20InitialQty || activeExitQuantity > 0)
                    return;

                int maxQty = Math.Min(MaxContractsAllowed, openingScaleInMaxContracts);
                addQty = maxQty - openQty;

                // V1.7.36 - never add more than 2/3 of the initial size.
                // Backtest: 12+6 / 12+8 / 10+6 pass evals; 10+10 and 6+14 do not
                // (the combined break-even stop ends up only a few ticks away).
                int addCap = (int)Math.Floor(openQty * 2.0 / 3.0);
                if (addQty > addCap)
                    addQty = addCap;

                if (addQty <= 0)
                {
                    core20ScaleSent = true;
                    return;
                }

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = DateTime.UtcNow;

                if (smartScaleInAnchorEntryPrice <= 0)
                    smartScaleInAnchorEntryPrice = core20AnchorEntry;
            }

            core20ScaleSent = true;

            try
            {
                OrderAction action = side == MarketPosition.Long ? OrderAction.Buy : OrderAction.SellShort;
                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument, action, OrderType.Market, OrderEntry.Automated, TimeInForce.Day,
                        addQty, 0, 0, string.Empty, orderName, NinjaTrader.Core.Globals.MaxDate, null);

                lock (executionStateLock)
                {
                    if (entryMarketPosition != side)
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(new[] { scaleOrder });

                PrintBotMessage(
                    "CORE20 SCALE-IN SUBMITTED"
                    + " | Side " + (side == MarketPosition.Long ? "LONG" : "SHORT")
                    + " | +" + favorableTicks.ToString("0") + "t"
                    + " | Add " + addQty + " (" + openQty + " -> " + (openQty + addQty) + ")"
                    + " | All contracts protected at entry +" + Core20ScaleLockTicks + "t after fill");
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage("CORE20 SCALE-IN ERROR: " + ex.Message);
            }
        }

        private void Core20ManageOpenTrade(double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (account == null || instrument == null || currentPrice <= 0)
                return;

            MarketPosition side;
            int openQty;
            Order localStopOrder;
            double localActiveStop;
            double localEntry;
            double dayPnl;
            bool dailyProtection;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                openQty = Math.Max(0, entryQuantity - activeExitQuantity);
                localStopOrder = stopOrder;
                localActiveStop = activeStopPrice;
                localEntry = entryFillPrice;
                dayPnl = botDailyPnL;
                dailyProtection = dailyTargetProtectionArmed;
            }

            DateTime nowNy = GetCurrentNewYorkTime();
            Core20ResetDayIfNeeded(nowNy);

            // ---- trade finished -> count losses ----
            if (side == MarketPosition.Flat || openQty <= 0)
            {
                if (core20TradeOpen)
                {
                    core20TradeOpen = false;
                    double tradePnl = dayPnl - core20DayPnlAtOpen;

                    if (tradePnl < 0)
                        core20LossesToday++;

                    PrintBotMessage(
                        "CORE20 TRADE CLOSED"
                        + " | PnL " + tradePnl.ToString("$0.00")
                        + " | Losses today " + core20LossesToday + "/" + Core20MaxLossesPerDay
                    );
                }

                core20TradeOpenSinceNy = DateTime.MinValue;
                core20PeakTicks = 0;
                core20TimeExitSent = false;
                core20AnchorEntry = 0;
                core20InitialQty = 0;
                core20ScaleSent = false;
                return;
            }

            if (!core20TradeOpen)
            {
                core20TradeOpen = true;
                core20DayPnlAtOpen = dayPnl;
                core20TradeOpenSinceNy = nowNy;
                core20PeakTicks = 0;
                core20TimeExitSent = false;
                core20AnchorEntry = localEntry;
                core20InitialQty = openQty;
                core20ScaleSent = false;
            }

            // Daily Target protection owns the position once armed.
            if (dailyProtection)
                return;

            // ---- time exit ----
            if (
                !core20TimeExitSent &&
                (
                    (nowNy - core20TradeOpenSinceNy).TotalMinutes >= Core20MaxHoldMinutes ||
                    nowNy.TimeOfDay >= Core20LastExit
                )
            )
            {
                core20TimeExitSent = true;

                try
                {
                    lock (executionStateLock)
                    {
                        activeForcedExitReason = "CORE20_TIME_EXIT";
                    }

                    PrintBotMessage(
                        "CORE20 TIME EXIT"
                        + " | Open since " + core20TradeOpenSinceNy.ToString("HH:mm:ss")
                        + " | Qty " + openQty
                    );

                    account.Flatten(new[] { instrument });
                }
                catch (Exception ex)
                {
                    core20TimeExitSent = false;
                    PrintBotMessage("CORE20 TIME EXIT ERROR: " + ex.Message);
                }

                return;
            }

            // ---- profit retention ----
            double tickSize = instrument.MasterInstrument.TickSize;

            if (tickSize <= 0 || localEntry <= 0)
                return;

            // All CORE20 distances are measured from the ORIGINAL entry, so a
            // scale-in (which moves the average) never changes the rules.
            double anchor = core20AnchorEntry > 0 ? core20AnchorEntry : localEntry;

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - anchor) / tickSize
                    : (anchor - currentPrice) / tickSize;

            if (favorableTicks > core20PeakTicks)
                core20PeakTicks = favorableTicks;

            // ---- eval scale-in ----
            Core20TryScaleIn(account, instrument, side, openQty, favorableTicks);

            bool scaleFilled;
            lock (executionStateLock)
            {
                scaleFilled = smartScaleInUsed;
            }

            if ((core20PeakTicks < Core20RetentionStartTicks && !scaleFilled) || localStopOrder == null)
                return;

            if (localStopOrder.OrderState != OrderState.Working && localStopOrder.OrderState != OrderState.Accepted)
                return;

            double lockTicks =
                core20PeakTicks >= Core20RetentionStartTicks
                    ? Math.Floor(core20PeakTicks * Core20RetentionFactor)
                    : 0;

            if (scaleFilled)
            {
                // Floor = the larger of +10t and the combined break-even (+1t)
                // measured from the original entry, so the scaled trade can
                // never close as a loss.
                double combinedBeTicks =
                    side == MarketPosition.Long
                        ? (localEntry - anchor) / tickSize
                        : (anchor - localEntry) / tickSize;

                double floorTicks = Math.Max(Core20ScaleLockTicks, Math.Ceiling(combinedBeTicks) + 1);

                if (lockTicks < floorTicks)
                    lockTicks = floorTicks;
            }

            double desiredStop =
                RoundToInstrumentTick(
                    side == MarketPosition.Long
                        ? anchor + lockTicks * tickSize
                        : anchor - lockTicks * tickSize
                );

            desiredStop = EnforceNeverWorsenStop(side, localActiveStop, desiredStop);

            bool adjusted;
            bool usedL2;
            double reference;

            desiredStop =
                ClampProtectiveStopToLiveMarket(
                    side,
                    desiredStop,
                    currentPrice,
                    tickSize,
                    out adjusted,
                    out usedL2,
                    out reference
                );

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > localActiveStop + tickSize * 0.5
                    : desiredStop < localActiveStop - tickSize * 0.5;

            if (!improves)
                return;

            long token;

            if (!TryBeginProtectiveChange("CORE20_RETENTION", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    if (!ReferenceEquals(stopOrder, localStopOrder) || entryMarketPosition != side)
                        return;

                    activeStopPrice = desiredStop;
                    localStopOrder.StopPriceChanged = desiredStop;
                }

                account.Change(new[] { localStopOrder });

                PrintBotMessage(
                    "CORE20 PROFIT RETENTION"
                    + " | Peak +" + core20PeakTicks.ToString("0") + "t"
                    + " | Lock +" + lockTicks.ToString("0") + "t"
                    + " | New SL " + desiredStop.ToString("0.00")
                    + (adjusted ? " | Clamped to live market" : string.Empty)
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 RETENTION ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }
    }
}

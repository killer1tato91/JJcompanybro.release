#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private string EvaluateDirectionalPressure(
            out int longPressureScore,
            out int shortPressureScore)
        {
            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool aboveVwap;
            bool belowVwap;
            int rangeLong;
            int rangeShort;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                m5Ready = latestM5ContextReady;
                m5Bullish = latestM5BullishTrend;
                m5Bearish = latestM5BearishTrend;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            longPressureScore = 0;
            shortPressureScore = 0;

            if (m5Ready)
            {
                if (m5Bullish && !m5Bearish)
                    longPressureScore++;

                if (m5Bearish && !m5Bullish)
                    shortPressureScore++;

                if (aboveVwap && !belowVwap)
                    longPressureScore++;

                if (belowVwap && !aboveVwap)
                    shortPressureScore++;
            }

            if (rangeLong >= rangeShort + 2)
                longPressureScore++;

            if (rangeShort >= rangeLong + 2)
                shortPressureScore++;

            if (htfLong > htfShort)
                longPressureScore++;

            if (htfShort > htfLong)
                shortPressureScore++;

            string pressure =
                longPressureScore >= 3 &&
                shortPressureScore <= 1
                    ? "LONG"
                    : (
                        shortPressureScore >= 3 &&
                        longPressureScore <= 1
                            ? "SHORT"
                            : "NEUTRAL"
                      );

            latestDirectionalPressure = pressure;
            latestDirectionalLongPressureScore = longPressureScore;
            latestDirectionalShortPressureScore = shortPressureScore;

            return pressure;
        }
        private bool IsDirectionalSafetyBlocked(
            bool isLong,
            out string reason)
        {
            reason = string.Empty;

            int longPressureScore;
            int shortPressureScore;

            string pressure =
                EvaluateDirectionalPressure(
                    out longPressureScore,
                    out shortPressureScore
                );

            bool blocked =
                (
                    isLong &&
                    string.Equals(
                        pressure,
                        "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    )
                ) ||
                (
                    !isLong &&
                    string.Equals(
                        pressure,
                        "LONG",
                        StringComparison.OrdinalIgnoreCase
                    )
                );

            if (!blocked)
                return false;

            bool m5Bullish;
            bool m5Bearish;
            bool aboveVwap;
            bool belowVwap;
            int rangeLong;
            int rangeShort;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                m5Bullish = latestM5BullishTrend;
                m5Bearish = latestM5BearishTrend;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            reason =
                "Pressure=" + pressure
                + " | Score L/S=" + longPressureScore + "/" + shortPressureScore
                + " | M5="
                + (
                    m5Bullish
                        ? "BULLISH"
                        : m5Bearish
                            ? "BEARISH"
                            : "WAITING"
                  )
                + " | VWAP="
                + (
                    aboveVwap
                        ? "ABOVE"
                        : belowVwap
                            ? "BELOW"
                            : "N/A"
                  )
                + " | R20 L/S=" + rangeLong + "/" + rangeShort
                + " | HTF L/S=" + htfLong + "/" + htfShort;

            return true;
        }

    }
}

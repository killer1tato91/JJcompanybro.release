﻿#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private string EvaluateDirectionalPressure(
            out int longPressureScore,
            out int shortPressureScore)
        {
            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool aboveVwap;
            bool belowVwap;
            int rangeLong;
            int rangeShort;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                m5Ready = latestM5ContextReady;
                m5Bullish = latestM5BullishTrend;
                m5Bearish = latestM5BearishTrend;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            longPressureScore = 0;
            shortPressureScore = 0;

            if (m5Ready)
            {
                if (m5Bullish && !m5Bearish)
                    longPressureScore++;

                if (m5Bearish && !m5Bullish)
                    shortPressureScore++;

                if (aboveVwap && !belowVwap)
                    longPressureScore++;

                if (belowVwap && !aboveVwap)
                    shortPressureScore++;
            }

            if (rangeLong >= rangeShort + 2)
                longPressureScore++;

            if (rangeShort >= rangeLong + 2)
                shortPressureScore++;

            if (htfLong > htfShort)
                longPressureScore++;

            if (htfShort > htfLong)
                shortPressureScore++;

            string pressure =
                longPressureScore >= 3 &&
                shortPressureScore <= 1
                    ? "LONG"
                    : (
                        shortPressureScore >= 3 &&
                        longPressureScore <= 1
                            ? "SHORT"
                            : "NEUTRAL"
                      );

            latestDirectionalPressure = pressure;
            latestDirectionalLongPressureScore = longPressureScore;
            latestDirectionalShortPressureScore = shortPressureScore;

            return pressure;
        }
        private bool IsDirectionalSafetyBlocked(
            bool isLong,
            out string reason)
        {
            reason = string.Empty;

            int longPressureScore;
            int shortPressureScore;

            string pressure =
                EvaluateDirectionalPressure(
                    out longPressureScore,
                    out shortPressureScore
                );

            bool blocked =
                (
                    isLong &&
                    string.Equals(
                        pressure,
                        "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    )
                ) ||
                (
                    !isLong &&
                    string.Equals(
                        pressure,
                        "LONG",
                        StringComparison.OrdinalIgnoreCase
                    )
                );

            if (!blocked)
                return false;

            bool m5Bullish;
            bool m5Bearish;
            bool aboveVwap;
            bool belowVwap;
            int rangeLong;
            int rangeShort;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                m5Bullish = latestM5BullishTrend;
                m5Bearish = latestM5BearishTrend;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            reason =
                "Pressure=" + pressure
                + " | Score L/S=" + longPressureScore + "/" + shortPressureScore
                + " | M5="
                + (
                    m5Bullish
                        ? "BULLISH"
                        : m5Bearish
                            ? "BEARISH"
                            : "WAITING"
                  )
                + " | VWAP="
                + (
                    aboveVwap
                        ? "ABOVE"
                        : belowVwap
                            ? "BELOW"
                            : "N/A"
                  )
                + " | R20 L/S=" + rangeLong + "/" + rangeShort
                + " | HTF L/S=" + htfLong + "/" + htfShort;

            return true;
        }

        // =========================================================
        // V1.6.23 PHASE 4 - MARKET REGIME / RANGE-CONTROLLED AUTO
        // =========================================================
        private string latestMarketRegime = "TRANSITION";
        private string latestMarketRegimeDirection = "NEUTRAL";
        private string latestMarketRegimeReason = "INITIALIZING";
        private string lastLoggedMarketRegimeKey = string.Empty;

        private string EvaluateMarketRegime(
            out string regimeDirection,
            out string regimeReason)
        {
            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool aboveVwap;
            bool belowVwap;
            bool bullishStructure;
            bool bearishStructure;
            int rangeLong;
            int rangeShort;
            double rangeVolume;
            double rangeBody;
            bool highBreakout;
            bool lowBreakout;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                m5Ready = latestM5ContextReady;
                m5Bullish = latestM5BullishTrend;
                m5Bearish = latestM5BearishTrend;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
                bullishStructure = latestM5BullishStructure;
                bearishStructure = latestM5BearishStructure;
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                rangeVolume = latestRangeVolumeRatio;
                rangeBody = latestRangeBodyRatio;
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            int longPressure;
            int shortPressure;
            string pressure = EvaluateDirectionalPressure(
                out longPressure,
                out shortPressure
            );

            int rangeDelta = rangeLong - rangeShort;
            bool longBreakoutStrength =
                highBreakout &&
                rangeLong >= 4 &&
                rangeLong >= rangeShort + 2 &&
                rangeVolume >= 1.15 &&
                rangeBody >= 0.60;

            bool shortBreakoutStrength =
                lowBreakout &&
                rangeShort >= 4 &&
                rangeShort >= rangeLong + 2 &&
                rangeVolume >= 1.15 &&
                rangeBody >= 0.60;

            bool confirmedLongTrend =
                m5Ready &&
                m5Bullish &&
                !m5Bearish &&
                aboveVwap &&
                !belowVwap &&
                (
                    pressure == "LONG" ||
                    bullishStructure ||
                    htfLong > htfShort ||
                    rangeDelta >= 2
                );

            bool confirmedShortTrend =
                m5Ready &&
                m5Bearish &&
                !m5Bullish &&
                belowVwap &&
                !aboveVwap &&
                (
                    pressure == "SHORT" ||
                    bearishStructure ||
                    htfShort > htfLong ||
                    rangeDelta <= -2
                );

            string regime;

            if (confirmedLongTrend && !confirmedShortTrend)
            {
                regime = "TREND";
                regimeDirection = "LONG";
                regimeReason =
                    "M5+VWAP ALIGNED"
                    + " | Pressure " + pressure + " " + longPressure + "/" + shortPressure
                    + " | R20 " + rangeLong + "/" + rangeShort
                    + " | HTF " + htfLong + "/" + htfShort;
            }
            else if (confirmedShortTrend && !confirmedLongTrend)
            {
                regime = "TREND";
                regimeDirection = "SHORT";
                regimeReason =
                    "M5+VWAP ALIGNED"
                    + " | Pressure " + pressure + " " + longPressure + "/" + shortPressure
                    + " | R20 " + rangeLong + "/" + rangeShort
                    + " | HTF " + htfLong + "/" + htfShort;
            }
            else
            {
                bool lowDirectionalEnergy =
                    Math.Max(rangeLong, rangeShort) <= 2 ||
                    Math.Abs(rangeDelta) <= 1;

                bool noConfirmedBreak =
                    !highBreakout &&
                    !lowBreakout;

                bool noDirectionalStructure =
                    !bullishStructure &&
                    !bearishStructure;

                bool balancedHtf =
                    htfLong == htfShort;

                if (
                    pressure == "NEUTRAL" &&
                    lowDirectionalEnergy &&
                    noConfirmedBreak &&
                    noDirectionalStructure &&
                    balancedHtf
                )
                {
                    regime = "RANGE";
                    regimeDirection = "NEUTRAL";
                    regimeReason =
                        "BALANCED / LOW ENERGY"
                        + " | R20 " + rangeLong + "/" + rangeShort
                        + " | Vol x" + rangeVolume.ToString("0.00")
                        + " | HTF " + htfLong + "/" + htfShort;
                }
                else if (longBreakoutStrength != shortBreakoutStrength)
                {
                    regime = "TRANSITION";
                    regimeDirection = longBreakoutStrength ? "LONG" : "SHORT";
                    regimeReason =
                        "RANGE BREAKOUT DISCOVERY"
                        + " | R20 " + rangeLong + "/" + rangeShort
                        + " | Vol x" + rangeVolume.ToString("0.00")
                        + " | Body " + (rangeBody * 100.0).ToString("0") + "%";
                }
                else
                {
                    regime = "TRANSITION";
                    regimeDirection =
                        longPressure > shortPressure
                            ? "LONG"
                            : shortPressure > longPressure
                                ? "SHORT"
                                : "NEUTRAL";
                    regimeReason =
                        "MIXED CONTEXT"
                        + " | Pressure " + pressure + " " + longPressure + "/" + shortPressure
                        + " | R20 " + rangeLong + "/" + rangeShort
                        + " | HTF " + htfLong + "/" + htfShort;
                }
            }

            latestMarketRegime = regime;
            latestMarketRegimeDirection = regimeDirection;
            latestMarketRegimeReason = regimeReason;

            string logKey = regime + "|" + regimeDirection;
            if (!string.Equals(lastLoggedMarketRegimeKey, logKey, StringComparison.Ordinal))
            {
                lastLoggedMarketRegimeKey = logKey;
                PrintBotMessage(
                    "MARKET REGIME"
                    + " | " + regime
                    + " | Direction: " + regimeDirection
                    + " | " + regimeReason
                );
            }

            return regime;
        }

        private void ApplyRangeControlledAutoDirection(
            DateTime nyTime,
            string candidateDirection,
            string candidateReason,
            out string resolvedDirection,
            out string resolvedReason)
        {
            resolvedDirection = candidateDirection;
            resolvedReason = candidateReason;

            // V1.6.31R2 - OPENING AUTO DIRECTION COMPATIBILITY FIX
            // The previous branch referenced stale Opening Pressure fields
            // that are no longer part of the current modular bot.
            // During the Opening window we now resolve direction from the
            // live, existing Directional Pressure + Range-20 state.
            if (IsOpeningEntryWindow(nyTime))
            {
                int openingLongPressure;
                int openingShortPressure;

                string openingPressure =
                    EvaluateDirectionalPressure(
                        out openingLongPressure,
                        out openingShortPressure
                    );

                int openingRangeLong;
                int openingRangeShort;
                bool openingHighBreakout;
                bool openingLowBreakout;
                int openingHtfLong;
                int openingHtfShort;

                lock (marketContextLock)
                {
                    openingRangeLong = latestRangeLongScore;
                    openingRangeShort = latestRangeShortScore;
                    openingHighBreakout = latestRangeHighBreakout;
                    openingLowBreakout = latestRangeLowBreakout;
                    openingHtfLong = latestHtfLongScore;
                    openingHtfShort = latestHtfShortScore;
                }

                bool openingLongAligned =
                    string.Equals(
                        openingPressure,
                        "LONG",
                        StringComparison.OrdinalIgnoreCase
                    ) &&
                    openingRangeLong >= openingRangeShort + 1 &&
                    (
                        openingHighBreakout ||
                        openingHtfLong >= openingHtfShort
                    );

                bool openingShortAligned =
                    string.Equals(
                        openingPressure,
                        "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    ) &&
                    openingRangeShort >= openingRangeLong + 1 &&
                    (
                        openingLowBreakout ||
                        openingHtfShort >= openingHtfLong
                    );

                if (openingLongAligned && !openingShortAligned)
                {
                    resolvedDirection = "LONG ONLY";
                    resolvedReason =
                        "NY OPEN DIRECTIONAL PRESSURE LONG"
                        + " | Pressure "
                        + openingLongPressure + "/"
                        + openingShortPressure
                        + " | R20 "
                        + openingRangeLong + "/"
                        + openingRangeShort;
                }
                else if (openingShortAligned && !openingLongAligned)
                {
                    resolvedDirection = "SHORT ONLY";
                    resolvedReason =
                        "NY OPEN DIRECTIONAL PRESSURE SHORT"
                        + " | Pressure "
                        + openingLongPressure + "/"
                        + openingShortPressure
                        + " | R20 "
                        + openingRangeLong + "/"
                        + openingRangeShort;
                }
                else
                {
                    // Keep the candidate produced by the existing Opening /
                    // M5 context when pressure is not decisive.
                    resolvedDirection = candidateDirection;
                    resolvedReason =
                        candidateReason
                        + " | OPEN PRESSURE "
                        + openingPressure
                        + " "
                        + openingLongPressure + "/"
                        + openingShortPressure;
                }

                return;
            }

            string regimeDirection;
            string regimeReason;
            string regime = EvaluateMarketRegime(
                out regimeDirection,
                out regimeReason
            );

            int rangeLong;
            int rangeShort;
            double rangeVolume;
            double rangeBody;
            bool highBreakout;
            bool lowBreakout;
            int htfLong;
            int htfShort;

            lock (marketContextLock)
            {
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                rangeVolume = latestRangeVolumeRatio;
                rangeBody = latestRangeBodyRatio;
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
                htfLong = latestHtfLongScore;
                htfShort = latestHtfShortScore;
            }

            bool strongRangeBreakLong =
                highBreakout &&
                rangeLong >= 4 &&
                rangeLong >= rangeShort + 2 &&
                rangeVolume >= 1.15 &&
                rangeBody >= 0.60;

            bool strongRangeBreakShort =
                lowBreakout &&
                rangeShort >= 4 &&
                rangeShort >= rangeLong + 2 &&
                rangeVolume >= 1.15 &&
                rangeBody >= 0.60;

            if (regime == "TREND")
            {
                string trendDirection =
                    regimeDirection == "LONG"
                        ? "LONG ONLY"
                        : regimeDirection == "SHORT"
                            ? "SHORT ONLY"
                            : "NONE";

                if (trendDirection != "NONE")
                {
                    resolvedDirection = trendDirection;
                    resolvedReason =
                        "REGIME TREND " + regimeDirection
                        + " | " + regimeReason;
                }
                return;
            }

            if (regime == "RANGE")
            {
                // A quiet range is not a reason to guess direction.
                // AUTO waits until a real breakout has enough speed/volume.
                if (strongRangeBreakLong != strongRangeBreakShort)
                {
                    resolvedDirection = strongRangeBreakLong
                        ? "LONG ONLY"
                        : "SHORT ONLY";
                    resolvedReason =
                        "REGIME RANGE -> CONFIRMED BREAKOUT "
                        + (strongRangeBreakLong ? "LONG" : "SHORT")
                        + " | R20 " + rangeLong + "/" + rangeShort
                        + " | Vol x" + rangeVolume.ToString("0.00");
                }
                else
                {
                    resolvedDirection = "NONE";
                    resolvedReason =
                        "REGIME RANGE - WAIT BREAKOUT / NO DIRECTIONAL CHASE";
                }
                return;
            }

            // TRANSITION: do not flip AUTO merely because M5 crossed VWAP.
            // Require one extra independent confirmation from HTF or R20.
            if (candidateDirection == "LONG ONLY")
            {
                bool extraLongConfirmation =
                    htfLong > htfShort ||
                    rangeLong >= rangeShort + 2 ||
                    strongRangeBreakLong;

                if (!extraLongConfirmation)
                {
                    resolvedDirection = "NONE";
                    resolvedReason =
                        "REGIME TRANSITION - LONG WAIT CONFIRMATION"
                        + " | " + regimeReason;
                }
                else
                {
                    resolvedReason =
                        "REGIME TRANSITION CONFIRMED LONG | " + candidateReason;
                }
            }
            else if (candidateDirection == "SHORT ONLY")
            {
                bool extraShortConfirmation =
                    htfShort > htfLong ||
                    rangeShort >= rangeLong + 2 ||
                    strongRangeBreakShort;

                if (!extraShortConfirmation)
                {
                    resolvedDirection = "NONE";
                    resolvedReason =
                        "REGIME TRANSITION - SHORT WAIT CONFIRMATION"
                        + " | " + regimeReason;
                }
                else
                {
                    resolvedReason =
                        "REGIME TRANSITION CONFIRMED SHORT | " + candidateReason;
                }
            }
            else if (strongRangeBreakLong != strongRangeBreakShort)
            {
                resolvedDirection = strongRangeBreakLong
                    ? "LONG ONLY"
                    : "SHORT ONLY";
                resolvedReason =
                    "REGIME TRANSITION BREAKOUT DISCOVERY "
                    + (strongRangeBreakLong ? "LONG" : "SHORT");
            }
        }

        // =========================================================
        // V1.6.23 PHASE 11 - ENTRY QUALITY GATE
        // =========================================================
        private bool IsMomentumEntryQualityBlocked(
            bool isLong,
            bool highConvictionMomentum,
            out string reason)
        {
            reason = string.Empty;

            string regimeDirection;
            string regimeReason;
            string regime = EvaluateMarketRegime(
                out regimeDirection,
                out regimeReason
            );

            int rangeLong;
            int rangeShort;
            double rangeVolume;
            double rangeBody;
            bool highBreakout;
            bool lowBreakout;

            lock (marketContextLock)
            {
                rangeLong = latestRangeLongScore;
                rangeShort = latestRangeShortScore;
                rangeVolume = latestRangeVolumeRatio;
                rangeBody = latestRangeBodyRatio;
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
            }

            int sameSide = isLong ? rangeLong : rangeShort;
            int opposite = isLong ? rangeShort : rangeLong;
            bool sideBreakout = isLong ? highBreakout : lowBreakout;

            // A confirmed TREND is already protected by Directional Pressure,
            // M5/VWAP context and the existing momentum qualification.
            if (regime == "TREND")
                return false;

            if (regime == "RANGE")
            {
                bool cleanRangeBreak =
                    sideBreakout &&
                    sameSide >= RangeEntryMinSameSideScore &&
                    opposite <= RangeEntryMaxOppositeScore &&
                    rangeVolume >= RangeEntryMinVolumeRatio &&
                    rangeBody >= RangeEntryMinBodyRatio;

                if (!cleanRangeBreak)
                {
                    reason =
                        "REGIME RANGE - BREAKOUT QUALITY INSUFFICIENT"
                        + " | Side: " + (isLong ? "LONG" : "SHORT")
                        + " | R20: " + sameSide + "/5"
                        + " | Opp: " + opposite + "/5"
                        + " | Breakout: " + (sideBreakout ? "YES" : "NO")
                        + " | Vol x" + rangeVolume.ToString("0.00")
                        + " | Body " + (rangeBody * 100.0).ToString("0") + "%";
                    return true;
                }

                return false;
            }

            // TRANSITION is where whipsaws are most likely. Require a clean
            // directional imbalance. High conviction may relax volume/body
            // slightly, but it never relaxes same-side/opposite momentum.
            bool scoreQuality =
                sameSide >= TransitionEntryMinSameSideScore &&
                opposite <= TransitionEntryMaxOppositeScore;

            double requiredVolume =
                highConvictionMomentum
                    ? Math.Max(0.80, TransitionEntryMinVolumeRatio - 0.10)
                    : TransitionEntryMinVolumeRatio;

            double requiredBody =
                highConvictionMomentum
                    ? Math.Max(0.45, TransitionEntryMinBodyRatio - 0.05)
                    : TransitionEntryMinBodyRatio;

            bool energyQuality =
                rangeVolume >= requiredVolume &&
                rangeBody >= requiredBody;

            bool regimeSideContradiction =
                (regimeDirection == "LONG" && !isLong) ||
                (regimeDirection == "SHORT" && isLong);

            if (
                regimeSideContradiction ||
                !scoreQuality ||
                !energyQuality
            )
            {
                reason =
                    "REGIME TRANSITION - ENTRY QUALITY WAIT"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | RegimeDir: " + regimeDirection
                    + " | R20: " + sameSide + "/5"
                    + " | Opp: " + opposite + "/5"
                    + " | Vol x" + rangeVolume.ToString("0.00")
                    + " | Body " + (rangeBody * 100.0).ToString("0") + "%"
                    + " | HighConviction: "
                    + (highConvictionMomentum ? "YES" : "NO");
                return true;
            }

            return false;
        }

    }
}

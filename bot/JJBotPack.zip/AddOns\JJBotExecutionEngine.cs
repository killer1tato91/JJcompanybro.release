#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT EXECUTION ENGINE
    // Stage 9 structural extraction only.
    //
    // Existing entry submission and protective bracket creation
    // are moved exactly as-is. No order type, price, quantity,
    // OCO, risk, timing, or safety behavior is changed.
    // =========================================================
    public partial class JJBotWindow
    {
       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null,
            bool openingEntry = false,
            bool highConvictionMomentum = false)
        {
            if (!botRunning)
                return;

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            if (
                !IsSimulationAccount(
                    account
                )
            )
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - ACCOUNT IS NOT SIM."
                );

                return;
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // Automatic entries MUST obey NY session.
            // Manual SIM tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            // V1.6.20 - UNIVERSAL DIRECTIONAL SAFETY GATE.
            // Every automatic entry path must pass this final check.
            if (!manualTest)
            {
                string directionalBlockReason;

                if (
                    IsDirectionalSafetyBlocked(
                        isLong,
                        out directionalBlockReason
                    )
                )
                {
                    string pressureBlockKey =
                        "DIRECTIONAL_PRESSURE|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|" + latestDirectionalPressure
                        + "|" + latestDirectionalLongPressureScore
                        + "/" + latestDirectionalShortPressureScore;

                    if (
                        pressureBlockKey !=
                            lastDirectionalSafetyBlockKey
                    )
                    {
                        lastDirectionalSafetyBlockKey =
                            pressureBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER PRESSURE"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | " + directionalBlockReason
                            + " | Action: TREAT AS PULLBACK / WAIT RESUMPTION"
                        );
                    }

                    return;
                }
            }

            bool momentumEntry =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(
                    structureSetupKey
                );

            if (!manualTest)
            {
                int lateEntryAgeSeconds;
                int lateEntryMaxSeconds;

                if (
                    IsLateAutomaticEntry(
                        signalNyTime,
                        momentumEntry,
                        openingEntry,
                        out lateEntryAgeSeconds,
                        out lateEntryMaxSeconds
                    )
                )
                {
                    string lateEntryKey =
                        signalBarTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + (
                            openingEntry
                                ? "OPENING"
                                : momentumEntry
                                    ? "MOMENTUM"
                                    : "STRUCTURE"
                          );

                    if (
                        lateEntryKey !=
                            lastLateEntryBlockLogKey
                    )
                    {
                        lastLateEntryBlockLogKey =
                            lateEntryKey;

                        PrintBotMessage(
                            "SKIP TRADE - LATE ENTRY"
                            + " | Type: "
                            + (
                                openingEntry
                                    ? "OPENING"
                                    : momentumEntry
                                        ? "MOMENTUM"
                                        : "STRUCTURE"
                              )
                            + " | Age: "
                            + lateEntryAgeSeconds
                            + "s"
                            + " | Max: "
                            + lateEntryMaxSeconds
                            + "s"
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | StrategyClock: "
                            + GetCurrentNewYorkTime()
                                .ToString(
                                    "HH:mm:ss"
                                )
                            + " ET"
                        );
                    }

                    return;
                }

                string reentryReason;

                if (
                    IsAutomaticReentryBlocked(
                        isLong,
                        signalBarTime,
                        momentumEntry,
                        highConvictionMomentum,
                        out reentryReason
                    )
                )
                {
                    // V1.6.6 - one reentry-block log per cooldown cycle
                    // and side. Do not create a new key every second as the
                    // remaining cooldown text changes.
                    string reentryBlockKey =
                        "REENTRY|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + lastAutomaticTradeExitNy.ToString(
                            "yyyyMMddHHmmss"
                        );

                    if (
                        reentryBlockKey !=
                            lastReentryBlockLogKey
                    )
                    {
                        lastReentryBlockLogKey =
                            reentryBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - REENTRY REARM"
                            + " | "
                            + reentryReason
                            + " | Side: "
                            + (
                                isLong
                                    ? "LONG"
                                    : "SHORT"
                              )
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                        );
                    }

                    return;
                }
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                // V1.6.6 - session limit is a persistent state, not a
                // per-Range-bar event. Log it once until the state changes.
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + GetSessionTradeCount(
                        signalSession
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        signalSession
                    );

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + GetSessionTradeLimit(
                            signalSession
                        )
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !manualTest &&
                positionRecoveryPending
            )
            {
                string recoveryBlockedKey =
                    "POSITION_RECOVERY_PENDING|"
                    + signalBarTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (
                    recoveryBlockedKey !=
                        lastRangeBlockedLogKey
                )
                {
                    lastRangeBlockedLogKey =
                        recoveryBlockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION RECOVERY PENDING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | Waiting for NinjaTrader account sync."
                    );
                }

                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | SignalBar: "
                        + ConvertToNewYorkTime(
                            signalBarTime
                          ).ToString(
                            "HH:mm:ss"
                          )
                        + " ET"
                    );
                }

                return;
            }

            double riskPerContract;
            double configuredRisk;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    activeStopTicks,
                    activeDollarRiskCap,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DOLLAR RISK CAP"
                    + " | ConfigQty: "
                    + activeContracts
                    + " | SL: "
                    + activeStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );

                return;
            }

            if (
                effectiveEntryContracts <
                    activeContracts
            )
            {
                PrintBotMessage(
                    "AUTO RISK SIZING"
                    + " | ConfigQty: "
                    + activeContracts
                    + " -> EffectiveQty: "
                    + effectiveEntryContracts
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | ConfigRisk: "
                    + configuredRisk.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );
            }

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            openingEntry &&
                            openingTradeTakenToday
                        ) ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    pendingEntrySession =
                        signalSession;

                    pendingEntryRequestedQuantity =
                        effectiveEntryContracts;

                    pendingEntryIsManualTest =
                        manualTest;

                    pendingEntryIsOpening =
                        openingEntry;

                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence =
                        manualTest
                            ? 0
                            : latestSetupConfidence;

                    pendingTradeSetupQuality =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupQuality
                                )
                                    ? "ANALYZING"
                                    : latestSetupQuality
                              );

                    pendingTradeSetupTiming =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupTiming
                                )
                                    ? "ANALYZING"
                                    : latestSetupTiming
                              );

                    pendingTradeManipulationState =
                        manualTest
                            ? "NONE"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestManipulationState
                                )
                                    ? "NONE"
                                    : latestManipulationState
                              );

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    if (!manualTest)
                    {
                        lastExecutedSignalBar =
                            signalBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;
                    }
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + effectiveEntryContracts
                    + (
                        effectiveEntryContracts != activeContracts
                            ? " (Configured "
                                + activeContracts
                                + ")"
                            : string.Empty
                      )
                    + " | Risk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + "/"
                    + activeDollarRiskCap.ToString("$0.00")
                    + " | "
                    + instrument.FullName
                    + (
                        openingEntry
                            ? " | Setup: OPENING"
                            : string.Empty
                    )
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingEntryRequestedQuantity =
                        0;

                    pendingEntryIsManualTest =
                        false;

                    pendingEntryIsOpening =
                        false;

                    pendingEntryIsPremarket =
                        false;

                    pendingTradeSetupConfidence =
                        0;

                    pendingTradeSetupQuality =
                        string.Empty;

                    pendingTradeSetupTiming =
                        string.Empty;

                    pendingTradeManipulationState =
                        string.Empty;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }
        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int effectiveTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    GetProfileOrderPrefix()
                    + "JJ_OCO_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        GetProfileOrderName("JJ_STOP"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        GetProfileOrderName("JJ_TARGET"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }
        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }
        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }
        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

    }
}

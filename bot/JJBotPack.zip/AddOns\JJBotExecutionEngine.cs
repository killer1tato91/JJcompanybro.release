#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT EXECUTION ENGINE
    // Stage 9 structural extraction only.
    //
    // Existing entry submission and protective bracket creation
    // are moved exactly as-is. No order type, price, quantity,
    // OCO, risk, timing, or safety behavior is changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.28 - Debounce repeated identical Learning veto logs.
        private string lastLearningQualityBucketBlockKey = string.Empty;
        private DateTime lastLearningQualityBucketBlockLogUtc = DateTime.MinValue;

        // V1.6.56 - ultra-short exact-call dedupe. This is intentionally
        // limited to 75 ms so a later intrabar reevaluation with fresher
        // Level2/Tape can still become eligible. It only suppresses duplicate
        // invocations of the exact same entry candidate.
        private string lastEntryEvaluationFingerprint = string.Empty;
        private DateTime lastEntryEvaluationFingerprintUtc = DateTime.MinValue;
        private string lastEntryEvaluationDedupeLogKey = string.Empty;


        // V1.6.64 - Explosion execution authority (legacy field names retained for compatibility).
        // Soft context layers add/subtract weight; they are no longer all
        // independent binary vetoes. Hard safety gates remain authoritative.
        private const int WeightedExecutionAuthorityThreshold = 68;
        private const double WeightedExecutionSoftMaxExtensionTicks = 96.0;

        // V1.6.70 - COUNTERTREND EXPLOSION QUALITY GATE.
        // Explosion Edge may still capture a true reversal against legacy
        // context, but it must be exceptional when M5/HTF/VWAP/structure
        // materially oppose the intended side.
        private const int CounterTrendExplosionMinScore = 90;
        private const int CounterTrendExplosionCandidateAbsMinScore = 95;
        private const double CounterTrendExplosionMinVolumeRatio = 2.00;
        private const double CounterTrendExplosionMinBodyRatio = 0.70;
        private const int CounterTrendExplosionMinPersistence = 4;
        // V1.6.71 SMALL ADJUSTMENT: an opposing absorption CANDIDATE is
        // caution, not a hard veto. Require only 3/6 same-side persistence
        // before allowing the exceptional countertrend burst to proceed.
        // This delays weak 0/0-2/6 entries without closing the bot too much.
        private const int CounterTrendCandidateAbsMinPersistence = 3;
        private const double CounterTrendExplosionMinDelta = 70.0;

        // V1.6.72 - RECENT OPPOSING ABSORPTION MEMORY. A confirmed Heavy
        // Absorption event remains relevant briefly after the visible L2
        // state returns to NONE. It is not a permanent veto: fresh same-side
        // flow or fresh price displacement can re-authorize the explosion.
        private const double RecentOpposingAbsorptionMemorySeconds = 8.0;
        private const int RecentOpposingAbsorptionReclaimPersistence = 3;
        private const double RecentOpposingAbsorptionReclaimDelta = 35.0;
        private const double RecentOpposingAbsorptionFreshDisplacementTicks = 18.0;

        // V1.6.75 - Candidate absorption remains caution, not a permanent veto.
        // Weak persistence + poor/marginal efficiency must HOLD, while a
        // genuinely healthy/aligned burst can still capture the good move.
        private const int OpposingCandidateWeakPersistenceMin = 3;

        // V1.6.75 - When BUY and SELL Heavy Absorption have both confirmed in
        // a short window, treat the zone as contested/rotational. Strong
        // aligned live flow may still re-authorize an entry.
        private const double AbsorptionContestedWindowSeconds = 12.0;
        private const int AbsorptionContestedReclaimPersistence = 4;
        private const double AbsorptionContestedReclaimDelta = 35.0;

        // V1.6.75 - Structure-location fence. A POOR-location block may not
        // disappear on the very next callback merely because the structure
        // snapshot rolled. It must either age out or be explicitly revalidated
        // by the existing confirmed Liquidity Break Acceptance path.
        private const double StructureLocationBlockFenceSeconds = 3.0;

        // =====================================================
        // V1.6.99 - LOCATION / RECENT EXTREME AWARENESS
        // =====================================================
        // Narrow purpose: prevent a fresh Momentum DIRECT candidate from
        // treating a rebound back toward a just-rejected high/low as though
        // it were a clean new expansion from open space.
        //
        // This is NOT a directional engine and Level2 never creates a trade.
        // It only delays MOMENTUM DIRECT/BREAKOUT_CONTINUATION while price is
        // still on the rejected side of a meaningful recent extreme that had
        // confirmed opposing Heavy Absorption.
        private const double RecentExtremeAwarenessSeconds = 180.0;
        private const double RecentExtremeMaxEntryDistanceTicks = 120.0;
        private const double RecentExtremeLevelMatchTicks = 32.0;
        private const double RecentExtremeAcceptanceBufferTicks = 4.0;

        // =====================================================
        // V1.7.00 - REVERSAL HANDOFF
        // =====================================================
        // This is NOT an additional entry filter.
        // It is a side-transfer mechanism that only becomes eligible when
        // Recent Extreme Awareness has already proven that the ORIGINAL
        // Momentum side is trying to trade back into a recently rejected
        // high/low.
        //
        // The handoff never fires from Level2 alone. It requires:
        //   - Recent Extreme rejection on the original side
        //   - opposite R20 development OR strong opposite price slope
        //   - fresh opposite tape/persistence/confluence
        //   - price still on the rejected side of the extreme
        //
        // A real reclaim automatically cancels the premise because
        // TryGetRecentExtremeLocationRisk() returns false.
        private const int ReversalHandoffMinOppositeR20Score = 3;
        private const int ReversalHandoffMinPersistence = 4;
        private const double ReversalHandoffMinDirectionalSlopeTicks = 1.5;
        private const double ReversalHandoffCooldownSeconds = 3.0;

        private DateTime lastReversalHandoffUtc = DateTime.MinValue;
        private string lastReversalHandoffSide = string.Empty;

        private bool recentStructureLocationBlockActive = false;
        private bool recentStructureLocationBlockIsLong = false;
        private double recentStructureLocationBlockLevel = 0.0;
        private string recentStructureLocationBlockReference = string.Empty;
        private DateTime recentStructureLocationBlockUtc = DateTime.MinValue;

        private string lastWeightedExecutionAuthorityLogKey = string.Empty;
        private DateTime lastWeightedExecutionAuthorityLogUtc = DateTime.MinValue;
        private string lastWeightedExecutionAuthoritySide = string.Empty;
        private int lastWeightedExecutionAuthorityScore = -1;

        // V1.6.63 UI telemetry bridge - the platform should display the
        // Unified Edge decision as the current execution authority instead
        // of presenting legacy M5/Structure fields as the bot's main status.
        // This is display telemetry only; it does not change trade logic.
        private DateTime lastUnifiedEdgeTelemetryUtc = DateTime.MinValue;
        private string lastUnifiedEdgeTelemetrySide = "NONE";
        private int lastUnifiedEdgeTelemetryHistoricalScore = 0;
        private int lastUnifiedEdgeTelemetryLiveScore = 0;
        private int lastUnifiedEdgeTelemetryTotalScore = 0;
        private int lastUnifiedEdgeTelemetryR20Score = 0;
        private string lastUnifiedEdgeTelemetryTiming = "ANALYZING";
        private string lastUnifiedEdgeTelemetryFlow = "NEUTRAL";
        private string lastUnifiedEdgeTelemetryVwap = "MIXED";
        private string lastUnifiedEdgeTelemetryAbsorption = "NONE";
        private string lastUnifiedEdgeTelemetryStatus = "WAITING NEW SETUP";

        // =====================================================
        // V1.6.68 - EXPLOSION QUALITY GATE / EARLY FAILURE
        // =====================================================
        // Prevent raw aggression from inflating Explosion to 90-100 when
        // price makes poor progress. Also release an existing commitment
        // early when price has failed AND opposite flow becomes persistent.

        // =====================================================
        // V1.6.65 - EXPLOSION DIRECTION COMMITMENT / ANTI-FLIP
        // =====================================================
        // Once a clean explosion qualifies, keep that side authoritative for
        // a short window. A single Tape/Delta/Book flicker cannot flip side.
        // The opposite side must prove BOTH price failure of the committed
        // thesis and a stronger independent explosion. A short neutral
        // cooldown follows an invalidation so LONG/SHORT cannot ping-pong.
        private const int ExplosionDirectionCommitmentSeconds = 12;
        private const int ExplosionFlipCooldownSeconds = 3;
        private const int ExplosionFlipScorePremium = 8;
        private const double ExplosionFailureProgressTicks = 2.0;
        private const double ExplosionFlipMinDisplacementTicks = 18.0;
        private const double ExplosionFlipMinDelta = 35.0;
        private const int ExplosionFlipMinPersistence = 4;

        private string explosionCommittedSide = "NONE";
        private DateTime explosionCommitmentUntilUtc = DateTime.MinValue;
        private DateTime explosionCommitmentArmedUtc = DateTime.MinValue;
        private double explosionCommitmentAnchorPrice = 0.0;
        private DateTime explosionFlipCooldownUntilUtc = DateTime.MinValue;
        private string lastExplosionCommitmentLogKey = string.Empty;

        private void ClearExplosionDirectionCommitment(string reason, bool startFlipCooldown)
        {
            string prior = explosionCommittedSide;
            explosionCommittedSide = "NONE";
            explosionCommitmentUntilUtc = DateTime.MinValue;
            explosionCommitmentArmedUtc = DateTime.MinValue;
            explosionCommitmentAnchorPrice = 0.0;

            if (startFlipCooldown)
                explosionFlipCooldownUntilUtc = DateTime.UtcNow.AddSeconds(ExplosionFlipCooldownSeconds);

            string key = "EXPLOSION_COMMIT_CLEAR|" + prior + "|" + reason;
            if (key != lastExplosionCommitmentLogKey)
            {
                lastExplosionCommitmentLogKey = key;
                PrintBotMessage(
                    "EXPLOSION DIRECTION COMMITMENT CLEARED"
                    + " | Prior: " + prior
                    + " | Reason: " + reason
                    + (startFlipCooldown
                        ? " | FlipCooldown: " + ExplosionFlipCooldownSeconds + "s"
                        : string.Empty)
                    + " | Action: WAIT FOR FRESH EXPLOSION"
                );
            }
        }

        private void ArmExplosionDirectionCommitment(bool isLong, double anchorPrice)
        {
            string side = isLong ? "LONG" : "SHORT";
            DateTime nowUtc = DateTime.UtcNow;

            bool alreadyActive =
                string.Equals(explosionCommittedSide, side, StringComparison.OrdinalIgnoreCase) &&
                explosionCommitmentUntilUtc != DateTime.MinValue &&
                nowUtc <= explosionCommitmentUntilUtc;

            // Do not extend the window forever on every callback. The first
            // qualifying explosion owns a fixed short commitment window.
            if (alreadyActive)
                return;

            explosionCommittedSide = side;
            explosionCommitmentArmedUtc = nowUtc;
            explosionCommitmentUntilUtc = nowUtc.AddSeconds(ExplosionDirectionCommitmentSeconds);
            explosionCommitmentAnchorPrice = anchorPrice;

            string key = "EXPLOSION_COMMIT_ARM|" + side + "|" + nowUtc.ToString("HHmmssfff");
            if (key != lastExplosionCommitmentLogKey)
            {
                lastExplosionCommitmentLogKey = key;
                PrintBotMessage(
                    "EXPLOSION DIRECTION COMMITMENT ARMED"
                    + " | Side: " + side
                    + " | Hold: " + ExplosionDirectionCommitmentSeconds + "s"
                    + " | Anchor: " + anchorPrice.ToString("0.00")
                    + " | Action: IGNORE SINGLE-SNAPSHOT FLIPS"
                );
            }
        }

        private bool TryEarlyInvalidateExplosionCommitment(
            bool isLong,
            string reason)
        {
            DateTime nowUtc = DateTime.UtcNow;
            string side = isLong ? "LONG" : "SHORT";

            bool sameActiveSide =
                string.Equals(explosionCommittedSide, side, StringComparison.OrdinalIgnoreCase) &&
                explosionCommitmentUntilUtc != DateTime.MinValue &&
                nowUtc <= explosionCommitmentUntilUtc;

            if (!sameActiveSide || explosionCommitmentArmedUtc == DateTime.MinValue)
                return false;

            double tickSize =
                selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0.0;
            double currentPrice = GetEntryLocationPriceProxy(isLong);
            double ageSeconds = Math.Max(0.0, (nowUtc - explosionCommitmentArmedUtc).TotalSeconds);
            double progressTicks = 0.0;

            if (tickSize > 0 && explosionCommitmentAnchorPrice > 0 && currentPrice > 0)
            {
                progressTicks = isLong
                    ? (currentPrice - explosionCommitmentAnchorPrice) / tickSize
                    : (explosionCommitmentAnchorPrice - currentPrice) / tickSize;
            }

            if (ageSeconds < 2.0 || progressTicks > ExplosionFailureProgressTicks)
                return false;

            ClearExplosionDirectionCommitment(
                "EARLY FAILURE | " + reason
                + " | PriceProgress " + progressTicks.ToString("0.0") + "t",
                true
            );
            return true;
        }

        private bool ApplyExplosionDirectionCommitment(
            bool isLong,
            int explosionScore,
            double displacementTicks,
            double signedDelta,
            int desiredPersistence,
            bool tapeAligned,
            bool confluenceAligned,
            double tickSize,
            out string commitmentSummary)
        {
            DateTime nowUtc = DateTime.UtcNow;
            string candidateSide = isLong ? "LONG" : "SHORT";
            commitmentSummary = "NO COMMITMENT";

            if (explosionFlipCooldownUntilUtc != DateTime.MinValue && nowUtc < explosionFlipCooldownUntilUtc)
            {
                double remaining = Math.Max(0.0, (explosionFlipCooldownUntilUtc - nowUtc).TotalSeconds);
                commitmentSummary =
                    "FLIP COOLDOWN " + remaining.ToString("0.0") + "s"
                    + " | Candidate " + candidateSide;
                return false;
            }

            if (explosionCommitmentUntilUtc != DateTime.MinValue && nowUtc > explosionCommitmentUntilUtc)
                ClearExplosionDirectionCommitment("TTL EXPIRED", false);

            double currentPrice = GetEntryLocationPriceProxy(isLong);

            if (string.Equals(explosionCommittedSide, "NONE", StringComparison.OrdinalIgnoreCase))
            {
                ArmExplosionDirectionCommitment(isLong, currentPrice);
                commitmentSummary = "ARMED " + candidateSide;
                return true;
            }

            if (string.Equals(explosionCommittedSide, candidateSide, StringComparison.OrdinalIgnoreCase))
            {
                double remaining = Math.Max(0.0, (explosionCommitmentUntilUtc - nowUtc).TotalSeconds);
                commitmentSummary =
                    "HELD " + candidateSide
                    + " | Remaining " + remaining.ToString("0.0") + "s";
                return true;
            }

            // Candidate is opposite to the committed side. Do not flip because
            // TapeBias/Delta changed once. First prove the committed direction
            // failed to make meaningful price progress from its anchor.
            bool committedWasLong =
                string.Equals(explosionCommittedSide, "LONG", StringComparison.OrdinalIgnoreCase);

            double committedProgressTicks = 0.0;
            if (tickSize > 0 && explosionCommitmentAnchorPrice > 0 && currentPrice > 0)
            {
                committedProgressTicks = committedWasLong
                    ? (currentPrice - explosionCommitmentAnchorPrice) / tickSize
                    : (explosionCommitmentAnchorPrice - currentPrice) / tickSize;
            }

            double ageSeconds = explosionCommitmentArmedUtc == DateTime.MinValue
                ? 0.0
                : Math.Max(0.0, (nowUtc - explosionCommitmentArmedUtc).TotalSeconds);

            bool committedPriceFailed =
                ageSeconds >= 2.0 &&
                committedProgressTicks <= ExplosionFailureProgressTicks;

            bool independentOppositeExplosion =
                explosionScore >= WeightedExecutionAuthorityThreshold + ExplosionFlipScorePremium &&
                displacementTicks >= ExplosionFlipMinDisplacementTicks &&
                signedDelta >= ExplosionFlipMinDelta &&
                desiredPersistence >= ExplosionFlipMinPersistence &&
                (tapeAligned || confluenceAligned);

            if (committedPriceFailed && independentOppositeExplosion)
            {
                string priorSide = explosionCommittedSide;
                ClearExplosionDirectionCommitment(
                    "PRICE FAILED " + committedProgressTicks.ToString("0.0")
                    + "t + OPPOSITE EXPLOSION " + explosionScore + "/100",
                    true
                );

                commitmentSummary =
                    "FLIP VALIDATED " + priorSide + " -> " + candidateSide
                    + " | PriceProgress " + committedProgressTicks.ToString("0.0") + "t"
                    + " | OppExplosion " + explosionScore + "/100"
                    + " | Cooldown " + ExplosionFlipCooldownSeconds + "s";

                // Important: the first opposite snapshot NEVER executes. It
                // only invalidates the old thesis. The new side must still be
                // qualified after the cooldown, proving persistence.
                return false;
            }

            commitmentSummary =
                "ANTI-FLIP HOLD " + explosionCommittedSide
                + " | Candidate " + candidateSide
                + " | PriceProgress " + committedProgressTicks.ToString("0.0") + "t"
                + " | OppExplosion " + explosionScore + "/100"
                + " | NeedScore " + (WeightedExecutionAuthorityThreshold + ExplosionFlipScorePremium)
                + " | Action: NO PING-PONG";
            return false;
        }

        // =====================================================
        // V1.6.65 - EXPLOSION EDGE + DIRECTION COMMITMENT
        // =====================================================
        // One momentum decision: historical edge is primary; current price
        // action is mandatory; VWAP/timing/flow/M5/HTF/absorption are weights.
        // Risk/session/license/startup guards remain outside this score and
        // keep hard authority.
        private bool TryGetWeightedExecutionAuthority(
            bool isLong,
            DateTime signalNyTime,
            out int totalScore,
            out string summary)
        {
            // =====================================================
            // V1.6.64 - MICROSTRUCTURE EXPLOSION ENGINE
            // =====================================================
            // The execution decision is based on the CURRENT explosion only:
            // R20 breakout, volume/body/slope acceleration, price displacement,
            // executed aggression, tape delta, persistence and absorption.
            //
            // M5 / VWAP / Structure / HTF / historical Learning are explicitly
            // NOT execution authority here. They can remain in telemetry and
            // Learning after the trade, but they cannot manufacture or veto an
            // Explosion entry.
            totalScore = 0;
            summary = "EXPLOSION NOT READY";

            int longScore;
            int shortScore;
            bool highBreakout;
            bool lowBreakout;
            double bodyRatio;
            double volumeRatio;
            double emaSlope;
            double longDisplacementTicks;
            double shortDisplacementTicks;
            int longAggressionScore;
            int shortAggressionScore;
            bool m5BullishTrendSnapshot;
            bool m5BearishTrendSnapshot;
            bool m5AboveVwapSnapshot;
            bool m5BelowVwapSnapshot;
            bool m5BullishStructureSnapshot;
            bool m5BearishStructureSnapshot;
            int htfLongScoreSnapshot;
            int htfShortScoreSnapshot;

            lock (marketContextLock)
            {
                longScore = latestRangeLongScore;
                shortScore = latestRangeShortScore;
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
                bodyRatio = latestRangeBodyRatio;
                volumeRatio = latestRangeVolumeRatio;
                emaSlope = latestRangeEmaSlope;
                longDisplacementTicks = latestExplosionLongDisplacementTicks;
                shortDisplacementTicks = latestExplosionShortDisplacementTicks;
                longAggressionScore = latestExplosionLongAggressionScore;
                shortAggressionScore = latestExplosionShortAggressionScore;
                m5BullishTrendSnapshot = latestM5BullishTrend;
                m5BearishTrendSnapshot = latestM5BearishTrend;
                m5AboveVwapSnapshot = latestM5AboveVwap;
                m5BelowVwapSnapshot = latestM5BelowVwap;
                m5BullishStructureSnapshot = latestM5BullishStructure;
                m5BearishStructureSnapshot = latestM5BearishStructure;
                htfLongScoreSnapshot = latestHtfLongScore;
                htfShortScoreSnapshot = latestHtfShortScore;
            }

            int sameSideScore = isLong ? longScore : shortScore;
            int oppositeScore = isLong ? shortScore : longScore;
            bool breakoutAligned = isLong ? highBreakout : lowBreakout;
            double displacementTicks =
                isLong ? longDisplacementTicks : shortDisplacementTicks;
            int aggressionScore =
                isLong ? longAggressionScore : shortAggressionScore;

            double tickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0.0;

            double slopeTicks =
                tickSize > 0 ? emaSlope / tickSize : 0.0;

            double directionalSlopeTicks =
                isLong ? slopeTicks : -slopeTicks;

            int opposingContextVotes = 0;

            if (isLong)
            {
                if (m5BearishTrendSnapshot) opposingContextVotes++;
                if (m5BelowVwapSnapshot) opposingContextVotes++;
                if (m5BearishStructureSnapshot) opposingContextVotes++;
                if (htfShortScoreSnapshot > htfLongScoreSnapshot) opposingContextVotes++;
            }
            else
            {
                if (m5BullishTrendSnapshot) opposingContextVotes++;
                if (m5AboveVwapSnapshot) opposingContextVotes++;
                if (m5BullishStructureSnapshot) opposingContextVotes++;
                if (htfLongScoreSnapshot > htfShortScoreSnapshot) opposingContextVotes++;
            }

            bool counterTrendExplosion =
                opposingContextVotes >= 2;

            // ----- Fresh Level II snapshot -----
            bool l2Ready = false;
            double desiredAgg = 0.0;
            double oppositeAgg = 0.0;
            double signedDelta = 0.0;
            int desiredPersistence = 0;
            int oppositePersistence = 0;
            bool tapeAligned = false;
            bool tapeOpposed = false;
            bool confluenceAligned = false;
            bool confluenceOpposed = false;
            bool bookAligned = false;
            bool opposingAbsorption = false;
            bool opposingAbsorptionCandidate = false;
            bool supportiveAbsorption = false;
            string absorptionState = "NONE";
            bool recentOpposingConfirmedAbsorption = false;
            double recentOpposingConfirmedAbsorptionAgeSeconds = double.MaxValue;
            string recentConfirmedAbsorptionMemorySide = "NONE";
            bool absorptionContested = false;
            double spreadTicks = 0.0;

            lock (level2Sync)
            {
                l2Ready =
                    level2ObserveActive &&
                    level2BookReady &&
                    level2LastCalcUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds <= 2.0 &&
                    level2SpreadTicks > 0 &&
                    level2SpreadTicks <= 8.0;

                if (l2Ready)
                {
                    string desired = isLong ? "LONG" : "SHORT";
                    string opposite = isLong ? "SHORT" : "LONG";

                    desiredAgg = isLong ? level2AggBuy : level2AggSell;
                    oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                    signedDelta = isLong ? level2TapeDelta : -level2TapeDelta;
                    desiredPersistence =
                        isLong ? level2LongPersistence : level2ShortPersistence;
                    oppositePersistence =
                        isLong ? level2ShortPersistence : level2LongPersistence;
                    spreadTicks = level2SpreadTicks;
                    absorptionState = level2Absorption ?? "NONE";

                    tapeAligned =
                        string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);
                    tapeOpposed =
                        string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                    confluenceAligned =
                        string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);
                    confluenceOpposed =
                        string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                    bookAligned =
                        string.Equals(level2Bias, desired, StringComparison.OrdinalIgnoreCase);

                    opposingAbsorption =
                        isLong
                            ? string.Equals(absorptionState, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                            : string.Equals(absorptionState, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                    opposingAbsorptionCandidate =
                        isLong
                            ? string.Equals(absorptionState, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase)
                            : string.Equals(absorptionState, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase);

                    supportiveAbsorption =
                        isLong
                            ? string.Equals(absorptionState, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                            : string.Equals(absorptionState, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                    // V1.6.72 - consult the most recent confirmed event even
                    // if the 4s visible CONFIRMED state has already expired.
                    recentConfirmedAbsorptionMemorySide =
                        level2LastConfirmedAbsorptionMemorySide ?? "NONE";

                    if (level2LastConfirmedAbsorptionMemoryUtc != DateTime.MinValue)
                    {
                        recentOpposingConfirmedAbsorptionAgeSeconds =
                            (DateTime.UtcNow - level2LastConfirmedAbsorptionMemoryUtc).TotalSeconds;

                        string opposingAbsorptionSide = isLong ? "SELL" : "BUY";
                        recentOpposingConfirmedAbsorption =
                            recentOpposingConfirmedAbsorptionAgeSeconds >= 0.0 &&
                            recentOpposingConfirmedAbsorptionAgeSeconds <= RecentOpposingAbsorptionMemorySeconds &&
                            string.Equals(
                                recentConfirmedAbsorptionMemorySide,
                                opposingAbsorptionSide,
                                StringComparison.OrdinalIgnoreCase
                            );
                    }

                    if (
                        level2LastBuyConfirmedAbsorptionUtc != DateTime.MinValue &&
                        level2LastSellConfirmedAbsorptionUtc != DateTime.MinValue
                    )
                    {
                        double buyAge =
                            (DateTime.UtcNow - level2LastBuyConfirmedAbsorptionUtc).TotalSeconds;
                        double sellAge =
                            (DateTime.UtcNow - level2LastSellConfirmedAbsorptionUtc).TotalSeconds;

                        absorptionContested =
                            buyAge >= 0.0 &&
                            sellAge >= 0.0 &&
                            buyAge <= AbsorptionContestedWindowSeconds &&
                            sellAge <= AbsorptionContestedWindowSeconds;
                    }
                }
            }

            // ----- Mandatory explosion shape -----
            // No breakout = no explosion. No meaningful body/slope/participation
            // = no trade. This is deliberately independent of M5/VWAP/Structure.
            bool basicExplosionShape =
                breakoutAligned &&
                sameSideScore >= 3 &&
                oppositeScore <= 1 &&
                bodyRatio >= 0.65 &&
                volumeRatio >= 1.00 &&
                directionalSlopeTicks >= 3.0;

            if (!basicExplosionShape)
            {
                summary =
                    "EXPLOSION SHAPE NOT READY"
                    + " | R20 " + sameSideScore + "/5"
                    + " | Opp " + oppositeScore + "/5"
                    + " | Breakout " + (breakoutAligned ? "YES" : "NO")
                    + " | Vol x" + volumeRatio.ToString("0.00")
                    + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                    + " | Slope " + directionalSlopeTicks.ToString("0.0") + "t";
                return false;
            }

            // Current flow cannot be unavailable for an automatic explosion.
            if (!l2Ready)
            {
                summary = "EXPLOSION WAIT | L2 NOT FRESH/READY";
                return false;
            }

            // A confirmed absorption against the intended explosion means heavy
            // aggression is failing to make progress. Do not enter that burst.
            if (opposingAbsorption)
            {
                summary =
                    "EXPLOSION VETO | OPPOSING ABSORPTION"
                    + " | Abs " + absorptionState
                    + " | Disp " + displacementTicks.ToString("0") + "t"
                    + " | Agg " + desiredAgg.ToString("0") + "/" + oppositeAgg.ToString("0");
                return false;
            }

            // V1.6.72 - A just-confirmed opposing absorption cannot disappear
            // from execution authority merely because its visible 4s TTL
            // rolled back to NONE. Hold the entry for up to 8s unless the
            // intended side proves itself again with fresh live flow OR a
            // genuinely fresh displacement. This is deliberately a delay /
            // revalidation gate, not a permanent hard block.
            if (recentOpposingConfirmedAbsorption)
            {
                bool sameSideFlowRevalidated =
                    desiredPersistence >= RecentOpposingAbsorptionReclaimPersistence &&
                    signedDelta >= RecentOpposingAbsorptionReclaimDelta &&
                    (tapeAligned || confluenceAligned);

                bool freshPriceRevalidated =
                    displacementTicks >= RecentOpposingAbsorptionFreshDisplacementTicks &&
                    sameSideScore >= 4 &&
                    directionalSlopeTicks >= 5.0;

                if (!sameSideFlowRevalidated && !freshPriceRevalidated)
                {
                    summary =
                        "EXPLOSION HOLD | RECENT OPPOSING ABSORPTION"
                        + " | Recent " + recentConfirmedAbsorptionMemorySide
                        + " CONFIRMED "
                        + recentOpposingConfirmedAbsorptionAgeSeconds.ToString("0.0") + "s ago"
                        + " | Persist " + desiredPersistence + "/" + oppositePersistence
                        + " | Delta " + signedDelta.ToString("0")
                        + " | Disp " + displacementTicks.ToString("0") + "t"
                        + " | Need: Persist>=" + RecentOpposingAbsorptionReclaimPersistence
                        + "/6 + Delta>=" + RecentOpposingAbsorptionReclaimDelta.ToString("0")
                        + " OR fresh Disp>=" + RecentOpposingAbsorptionFreshDisplacementTicks.ToString("0") + "t";
                    return false;
                }
            }

            // V1.6.75 - CONTESTED ABSORPTION ZONE.
            // BUY and SELL confirmations alternating in a short window mean
            // two-sided trapping/rotation. Do not chase it unless the intended
            // side has rebuilt strong, current live-flow authority.
            if (absorptionContested)
            {
                bool contestedFlowRevalidated =
                    desiredPersistence >= AbsorptionContestedReclaimPersistence &&
                    signedDelta >= AbsorptionContestedReclaimDelta &&
                    (tapeAligned || confluenceAligned);

                if (!contestedFlowRevalidated)
                {
                    summary =
                        "EXPLOSION HOLD | ABSORPTION CONTESTED"
                        + " | Persist " + desiredPersistence + "/" + oppositePersistence
                        + " | Delta " + signedDelta.ToString("0")
                        + " | Abs " + absorptionState
                        + " | Need: Persist>=" + AbsorptionContestedReclaimPersistence
                        + "/6 + Delta>=" + AbsorptionContestedReclaimDelta.ToString("0")
                        + " + aligned Tape/Confluence";
                    return false;
                }
            }

            bool clearOppositeFlow =
                oppositePersistence >= 4 &&
                (tapeOpposed || confluenceOpposed) &&
                signedDelta <= -25.0;

            if (clearOppositeFlow)
            {
                bool commitmentReleased =
                    TryEarlyInvalidateExplosionCommitment(
                        isLong,
                        "OPPOSITE FLOW | Delta " + signedDelta.ToString("0")
                        + " | OppPersist " + oppositePersistence
                    );

                summary =
                    "EXPLOSION VETO | FLOW OPPOSITE"
                    + " | Delta " + signedDelta.ToString("0")
                    + " | Persist " + desiredPersistence + "/" + oppositePersistence
                    + " | Abs " + absorptionState
                    + (commitmentReleased ? " | COMMITMENT RELEASED" : "");
                return false;
            }

            int explosionScore = 0;

            // Price explosion: 55 points max.
            explosionScore += sameSideScore >= 5 ? 18 : sameSideScore == 4 ? 15 : 10;
            explosionScore += 10; // real breakout already mandatory

            if (volumeRatio >= 2.00) explosionScore += 12;
            else if (volumeRatio >= 1.50) explosionScore += 10;
            else if (volumeRatio >= 1.25) explosionScore += 8;
            else if (volumeRatio >= 1.10) explosionScore += 5;
            else explosionScore += 2;

            if (bodyRatio >= 0.90) explosionScore += 10;
            else if (bodyRatio >= 0.80) explosionScore += 8;
            else if (bodyRatio >= 0.70) explosionScore += 6;
            else explosionScore += 3;

            if (directionalSlopeTicks >= 8.0) explosionScore += 10;
            else if (directionalSlopeTicks >= 5.0) explosionScore += 8;
            else explosionScore += 5;

            if (displacementTicks >= 80.0) explosionScore += 10;
            else if (displacementTicks >= 50.0) explosionScore += 8;
            else if (displacementTicks >= 30.0) explosionScore += 6;
            else if (displacementTicks >= 15.0) explosionScore += 3;

            // Executed microstructure: 45+ points max.
            double aggressionRatio =
                desiredAgg / Math.Max(1.0, oppositeAgg);

            if (desiredAgg >= 40.0)
            {
                if (aggressionRatio >= 2.00) explosionScore += 12;
                else if (aggressionRatio >= 1.50) explosionScore += 10;
                else if (aggressionRatio >= 1.25) explosionScore += 7;
                else if (aggressionRatio >= 1.10) explosionScore += 3;
            }

            if (signedDelta >= 120.0) explosionScore += 10;
            else if (signedDelta >= 70.0) explosionScore += 8;
            else if (signedDelta >= 35.0) explosionScore += 6;
            else if (signedDelta >= 15.0) explosionScore += 3;

            if (desiredPersistence >= 6) explosionScore += 8;
            else if (desiredPersistence >= 4) explosionScore += 6;
            else if (desiredPersistence >= 2) explosionScore += 3;

            if (tapeAligned) explosionScore += 6;
            if (confluenceAligned) explosionScore += 5;
            if (bookAligned) explosionScore += 2;
            if (supportiveAbsorption) explosionScore += 5;

            // Aggression vs price progress. Lots of aggression with almost no
            // displacement is absorption/stalling, not an explosion.
            double progressPer100Agg =
                desiredAgg > 0
                    ? displacementTicks / desiredAgg * 100.0
                    : 0.0;

            bool aggressionStalled =
                desiredAgg >= 100.0 &&
                displacementTicks < 12.0;

            // V1.6.68 QUALITY GATE:
            // High aggression with weak price efficiency must NOT create a
            // 90-100 Explosion score. The 15:42:59 PM case printed 100/100
            // with only 7.1t progress per 100 aggressive contracts and an
            // opposing absorption candidate. That is potential trapping, not
            // a clean expansion.
            const double ExplosionEfficiencyMinAggressionSample = 80.0;

            bool insufficientAggressionSample =
                desiredAgg < ExplosionEfficiencyMinAggressionSample;

            bool poorAggressionEfficiency =
                !insufficientAggressionSample &&
                progressPer100Agg < 8.0;

            bool marginalAggressionEfficiency =
                !insufficientAggressionSample &&
                progressPer100Agg >= 8.0 &&
                progressPer100Agg < 15.0;

            if (aggressionStalled)
                explosionScore -= 18;

            if (poorAggressionEfficiency)
            {
                explosionScore -= opposingAbsorptionCandidate ? 25 : 18;

                // Candidate absorption + <8t/100Agg can never authorize the
                // trade by score alone. Keep it below the execution threshold.
                if (opposingAbsorptionCandidate)
                    explosionScore = Math.Min(explosionScore, 65);
            }
            else if (marginalAggressionEfficiency)
            {
                explosionScore -= opposingAbsorptionCandidate ? 12 : 8;
            }
            else if (!insufficientAggressionSample && progressPer100Agg >= 15.0)
            {
                explosionScore += progressPer100Agg >= 25.0 ? 7 : 4;
            }

            // V1.6.69: a tiny aggression denominator can produce absurd
            // Progress/100Agg values (e.g. 2100t from Agg 2/5). Treat that
            // ratio as unavailable and prevent a low-sample callback from
            // becoming a 90-100 score solely through unstable L2.
            if (insufficientAggressionSample)
                explosionScore = Math.Min(explosionScore, 79);

            // Internal aggression score is current-price evidence only.
            if (aggressionScore >= 4) explosionScore += 4;
            else if (aggressionScore >= 3) explosionScore += 2;

            explosionScore = Math.Max(0, Math.Min(100, explosionScore));
            totalScore = explosionScore;

            // V1.6.75 - OPPOSING ABSORPTION CANDIDATE + WEAK MICROFLOW.
            // Candidate remains a delay/revalidation condition, never a blanket
            // veto. Healthy efficiency with genuinely aligned flow may still
            // capture a fast move; weak persistence plus POOR/MARGINAL
            // efficiency must wait.
            bool weakOpposingCandidateMicroflow =
                opposingAbsorptionCandidate &&
                desiredPersistence < OpposingCandidateWeakPersistenceMin &&
                (
                    poorAggressionEfficiency ||
                    marginalAggressionEfficiency ||
                    (!tapeAligned && !confluenceAligned)
                );

            if (weakOpposingCandidateMicroflow)
            {
                summary =
                    "EXPLOSION HOLD | OPPOSING ABS CAND + WEAK MICROFLOW"
                    + " | Persist " + desiredPersistence + "/" + oppositePersistence
                    + " | Delta " + signedDelta.ToString("0")
                    + " | Flow "
                    + (tapeAligned || confluenceAligned ? "SUPPORTED" : "NEUTRAL/OPPOSED")
                    + " | Efficiency "
                    + (poorAggressionEfficiency
                        ? "POOR"
                        : marginalAggressionEfficiency
                            ? "MARGINAL"
                            : "HEALTHY")
                    + " | Action: WAIT FOR >= "
                    + OpposingCandidateWeakPersistenceMin
                    + "/6 OR CLEANER FLOW";
                return false;
            }

            // V1.6.70 - A countertrend burst is allowed, but only when the
            // live explosion itself is exceptional. This preserves the good
            // 20:30 LONG (99/100, Vol x2.46, healthy progress, Delta +84)
            // while preventing a merely local reversal from overruling a
            // clearly opposing M5/HTF/VWAP/structure backdrop.
            bool counterTrendFlowProof =
                desiredPersistence >= CounterTrendExplosionMinPersistence ||
                signedDelta >= CounterTrendExplosionMinDelta ||
                (tapeAligned && confluenceAligned);

            bool counterTrendBaseQuality =
                !counterTrendExplosion ||
                (
                    explosionScore >= CounterTrendExplosionMinScore &&
                    sameSideScore >= 4 &&
                    volumeRatio >= CounterTrendExplosionMinVolumeRatio &&
                    bodyRatio >= CounterTrendExplosionMinBodyRatio &&
                    counterTrendFlowProof
                );

            bool counterTrendCandidateAbsQuality =
                !counterTrendExplosion ||
                !opposingAbsorptionCandidate ||
                (
                    explosionScore >= CounterTrendExplosionCandidateAbsMinScore &&
                    !poorAggressionEfficiency &&
                    !marginalAggressionEfficiency &&
                    signedDelta >= CounterTrendExplosionMinDelta &&
                    desiredPersistence >= CounterTrendCandidateAbsMinPersistence
                );

            if (
                counterTrendExplosion &&
                (!counterTrendBaseQuality || !counterTrendCandidateAbsQuality)
            )
            {
                summary =
                    "COUNTERTREND EXPLOSION VETO"
                    + " | Score " + explosionScore + "/100"
                    + " | ContextOpp " + opposingContextVotes + "/4"
                    + " | R20 " + sameSideScore + "/5"
                    + " | Vol x" + volumeRatio.ToString("0.00")
                    + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                    + " | Delta " + signedDelta.ToString("0")
                    + " | Persist " + desiredPersistence + "/" + oppositePersistence
                    + " | Abs " + absorptionState
                    + (opposingAbsorptionCandidate
                        ? " | CandidateNeedsPersist " + CounterTrendCandidateAbsMinPersistence + "/6"
                        : "")
                    + " | Need: exceptional live proof";
                return false;
            }

            // 3/5 is allowed only when the explosion is exceptionally clean.
            bool threeOfFiveExtraGate =
                sameSideScore > 3 ||
                (
                    explosionScore >= 78 &&
                    volumeRatio >= 1.25 &&
                    displacementTicks >= 30.0 &&
                    desiredPersistence >= 3 &&
                    (tapeAligned || confluenceAligned) &&
                    signedDelta >= 25.0
                );

            // Historical Learning is OBSERVE ONLY in V1.6.64. Keep the value
            // in logs so we can compare live explosion quality against history.
            bool learningWouldBlock;
            string historyReason;
            int historicalObservation =
                GetHistoricalExecutionEdgeScore(
                    isLong ? "LONG" : "SHORT",
                    signalNyTime,
                    "R20 EXPLOSION " + sameSideScore + "/5",
                    out learningWouldBlock,
                    out historyReason
                );

            string flowState =
                tapeAligned && desiredPersistence >= 4
                    ? "ALIGNED"
                    : (confluenceAligned || signedDelta >= 25.0 || desiredPersistence >= 2)
                        ? "SUPPORTED"
                        : "NEUTRAL";

            lock (executionStateLock)
            {
                lastUnifiedEdgeTelemetryUtc = DateTime.UtcNow;
                lastUnifiedEdgeTelemetrySide = isLong ? "LONG" : "SHORT";
                lastUnifiedEdgeTelemetryHistoricalScore = historicalObservation;
                lastUnifiedEdgeTelemetryLiveScore = explosionScore;
                lastUnifiedEdgeTelemetryTotalScore = explosionScore;
                lastUnifiedEdgeTelemetryR20Score = sameSideScore;
                lastUnifiedEdgeTelemetryTiming = "EXPLOSION";
                lastUnifiedEdgeTelemetryFlow = flowState;
                lastUnifiedEdgeTelemetryVwap = "IGNORED";
                lastUnifiedEdgeTelemetryAbsorption =
                    supportiveAbsorption ? "SUPPORT" : "NONE";
                lastUnifiedEdgeTelemetryStatus =
                    explosionScore >= WeightedExecutionAuthorityThreshold &&
                    threeOfFiveExtraGate &&
                    counterTrendBaseQuality &&
                    counterTrendCandidateAbsQuality
                        ? "EXPLOSION ENTRY AUTHORIZED"
                        : "WAIT EXPLOSION";
            }

            summary =
                "Explosion " + explosionScore + "/100"
                + " | Threshold " + WeightedExecutionAuthorityThreshold
                + " | R20 " + sameSideScore + "/5"
                + " | Disp " + displacementTicks.ToString("0") + "t"
                + " | Vol x" + volumeRatio.ToString("0.00")
                + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                + " | Slope " + directionalSlopeTicks.ToString("0.0") + "t"
                + " | Agg " + desiredAgg.ToString("0") + "/" + oppositeAgg.ToString("0")
                + " | AggRatio " + aggressionRatio.ToString("0.00")
                + " | Delta " + signedDelta.ToString("0")
                + " | Persist " + desiredPersistence + "/" + oppositePersistence
                + " | Flow " + flowState
                + " | Abs " + absorptionState
                + " | Progress/100Agg " + progressPer100Agg.ToString("0.0") + "t"
                + " | Efficiency "
                + (
                    insufficientAggressionSample
                        ? "INSUFFICIENT SAMPLE"
                        : poorAggressionEfficiency
                            ? "POOR"
                            : marginalAggressionEfficiency
                                ? "MARGINAL"
                                : "HEALTHY"
                  )
                + (opposingAbsorptionCandidate ? " + OPP ABS CAND" : "")
                + " | HistoricalObs " + historicalObservation + "/100"
                + (learningWouldBlock ? " BLOCK-WOULD-HAVE-FIRED" : "")
                + (counterTrendExplosion ? " | COUNTERTREND EXCEPTION ACTIVE" : " | LEGACY CONTEXT WEIGHT");

            bool rawExplosionAuthorized =
                explosionScore >= WeightedExecutionAuthorityThreshold &&
                threeOfFiveExtraGate &&
                counterTrendBaseQuality &&
                counterTrendCandidateAbsQuality;

            if (!rawExplosionAuthorized)
                return false;

            string directionCommitmentSummary;
            bool directionCommitmentAllows =
                ApplyExplosionDirectionCommitment(
                    isLong,
                    explosionScore,
                    displacementTicks,
                    signedDelta,
                    desiredPersistence,
                    tapeAligned,
                    confluenceAligned,
                    tickSize,
                    out directionCommitmentSummary
                );

            if (!directionCommitmentAllows)
            {
                summary += " | " + directionCommitmentSummary;
                lock (executionStateLock)
                {
                    lastUnifiedEdgeTelemetryStatus = "WAIT - DIRECTION COMMITMENT";
                }
                return false;
            }

            summary += " | " + directionCommitmentSummary;
            return true;
        }

        private void LogWeightedExecutionAuthority(
            bool isLong,
            DateTime nyTime,
            int totalScore,
            string summary,
            string action)
        {
            string key =
                nyTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (isLong ? "LONG" : "SHORT")
                + "|"
                + totalScore
                + "|"
                + action;

            string side = isLong ? "LONG" : "SHORT";
            bool sameSide =
                string.Equals(
                    side,
                    lastWeightedExecutionAuthoritySide,
                    StringComparison.Ordinal
                );
            bool tinyScoreChange =
                lastWeightedExecutionAuthorityScore >= 0 &&
                Math.Abs(totalScore - lastWeightedExecutionAuthorityScore) < 3;
            bool recent =
                lastWeightedExecutionAuthorityLogUtc != DateTime.MinValue &&
                (DateTime.UtcNow - lastWeightedExecutionAuthorityLogUtc).TotalSeconds < 2.0;

            // Suppress callback spam while preserving meaningful score/side
            // changes and at least one refresh every two seconds.
            if (
                recent &&
                sameSide &&
                tinyScoreChange
            )
            {
                return;
            }

            if (
                string.Equals(
                    key,
                    lastWeightedExecutionAuthorityLogKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastWeightedExecutionAuthorityLogKey = key;
            lastWeightedExecutionAuthorityLogUtc = DateTime.UtcNow;
            lastWeightedExecutionAuthoritySide = side;
            lastWeightedExecutionAuthorityScore = totalScore;

            PrintBotMessage(
                "EXPLOSION EDGE EXECUTION"
                + " | Side: "
                + (isLong ? "LONG" : "SHORT")
                + " | "
                + summary
                + " | Action: "
                + action
            );
        }

        // =====================================================
        // V1.6.32 - FAST OPEN EXTREME CANDIDATE
        // =====================================================
        // This helper intentionally evaluates ONLY the price-action side
        // of the future Fast Open + Level II confirmation path.
        //
        // IMPORTANT: it is NOT wired to bypass an execution guard yet.
        // The actual Level II engine that produces BOOK/TAPE/PERSISTENCE/
        // ABSORPTION telemetry was not part of the supplied source set.
        // We will combine this candidate with that engine's real snapshot
        // before allowing any early entry.
        private bool IsFastOpenExtremePriceCandidate(
            bool isLong)
        {
            int longScore;
            int shortScore;
            bool highBreakout;
            bool lowBreakout;
            double bodyRatio;
            double volumeRatio;
            double emaSlope;

            lock (marketContextLock)
            {
                longScore =
                    latestRangeLongScore;

                shortScore =
                    latestRangeShortScore;

                highBreakout =
                    latestRangeHighBreakout;

                lowBreakout =
                    latestRangeLowBreakout;

                bodyRatio =
                    latestRangeBodyRatio;

                volumeRatio =
                    latestRangeVolumeRatio;

                emaSlope =
                    latestRangeEmaSlope;
            }

            int sameSideScore =
                isLong
                    ? longScore
                    : shortScore;

            int oppositeScore =
                isLong
                    ? shortScore
                    : longScore;

            bool breakoutAligned =
                isLong
                    ? highBreakout
                    : lowBreakout;

            double slopeTicks =
                0;

            if (
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null &&
                selectedInstrument.MasterInstrument.TickSize > 0
            )
            {
                slopeTicks =
                    emaSlope /
                    selectedInstrument.MasterInstrument.TickSize;
            }

            bool slopeAligned =
                isLong
                    ? slopeTicks >=
                        AggressionMinSlopeTicks
                    : slopeTicks <=
                        -AggressionMinSlopeTicks;

            return
                sameSideScore >= 4 &&
                oppositeScore <= 1 &&
                breakoutAligned &&
                bodyRatio >= 0.75 &&
                volumeRatio >= 1.50 &&
                slopeAligned;
        }

        // =====================================================
        // V1.6.30 - STRUCTURE LOCATION / ROOM ENGINE
        // =====================================================
        // Returns true only when a structural barrier is still AHEAD of price
        // and the available room is pathologically small. Broken levels behind
        // price are not treated as resistance/support.
        private bool TryGetEntryLocationRoom(
            bool isLong,
            double signalPrice,
            double tickSize,
            out double roomTicks,
            out string referenceName,
            out double referencePrice)
        {
            roomTicks = 0;
            referenceName = "NONE";
            referencePrice = 0;

            if (signalPrice <= 0 || tickSize <= 0)
                return false;

            double recentHigh;
            double recentLow;

            lock (marketContextLock)
            {
                recentHigh = latestM5RecentStructureHigh;
                recentLow = latestM5RecentStructureLow;
            }

            if (isLong)
            {
                double nearest = double.MaxValue;

                if (recentHigh > signalPrice && recentHigh < nearest)
                {
                    nearest = recentHigh;
                    referenceName = "M5 RECENT HIGH";
                }

                if (openingRangeReady && openingRangeHigh > signalPrice && openingRangeHigh < nearest)
                {
                    nearest = openingRangeHigh;
                    referenceName = "OPENING RANGE HIGH";
                }

                if (premarketRangeReady && premarketRangeHigh > signalPrice && premarketRangeHigh < nearest)
                {
                    nearest = premarketRangeHigh;
                    referenceName = "PREMARKET HIGH";
                }

                if (nearest == double.MaxValue)
                    return false;

                referencePrice = nearest;
                roomTicks = (nearest - signalPrice) / tickSize;
                return roomTicks >= 0;
            }

            double nearestSupport = double.MinValue;

            if (recentLow > 0 && recentLow < signalPrice && recentLow > nearestSupport)
            {
                nearestSupport = recentLow;
                referenceName = "M5 RECENT LOW";
            }

            if (openingRangeReady && openingRangeLow > 0 && openingRangeLow < signalPrice && openingRangeLow > nearestSupport)
            {
                nearestSupport = openingRangeLow;
                referenceName = "OPENING RANGE LOW";
            }

            if (premarketRangeReady && premarketRangeLow > 0 && premarketRangeLow < signalPrice && premarketRangeLow > nearestSupport)
            {
                nearestSupport = premarketRangeLow;
                referenceName = "PREMARKET LOW";
            }

            if (nearestSupport == double.MinValue)
                return false;

            referencePrice = nearestSupport;
            roomTicks = (signalPrice - nearestSupport) / tickSize;
            return roomTicks >= 0;
        }

        // =====================================================
        // V1.6.37 - EXECUTABLE PRICE PROXY FOR LOCATION CHECKS
        // =====================================================
        // Prefer fresh bid/ask from the Level II subscription so Structural
        // Room is evaluated near the price an order can actually fill at.
        private double GetEntryLocationPriceProxy(bool isLong)
        {
            lock (level2Sync)
            {
                bool freshL2 =
                    level2BookReady &&
                    level2LastCalcUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds <= 2.0;

                if (freshL2)
                {
                    double executable = isLong ? level2LastAskPrice : level2LastBidPrice;
                    if (executable > 0)
                        return executable;
                }
            }

            lock (marketContextLock)
            {
                return latestRangeClosePrice > 0
                    ? latestRangeClosePrice
                    : latestM5DecisionPrice;
            }
        }

        private void ArmLiquidityBreakAcceptanceLevel(
            bool isLong,
            double level,
            string referenceName,
            DateTime signalNyTime)
        {
            if (level <= 0)
                return;

            pendingLiquidityBreakActive = true;
            pendingLiquidityBreakIsLong = isLong;
            pendingLiquidityBreakLevel = level;
            pendingLiquidityBreakReference = referenceName ?? "STRUCTURE";
            pendingLiquidityBreakArmedNy = signalNyTime;
            pendingLiquidityBreakCrossedNy = DateTime.MinValue;
        }

        // =====================================================
        // V1.6.99 - RECENT EXTREME LOCATION CHECK
        // =====================================================
        private bool TryGetRecentExtremeLocationRisk(
            bool isLong,
            double currentPrice,
            double tickSize,
            out string summary)
        {
            summary = "LOCATION CLEAR";

            if (
                currentPrice <= 0 ||
                tickSize <= 0
            )
            {
                return false;
            }

            DateTime opposingAbsorptionUtc;
            double opposingAbsorptionExtreme;
            double recentStructureHigh;
            double recentStructureLow;

            lock (level2Sync)
            {
                opposingAbsorptionUtc =
                    isLong
                        ? level2LastSellConfirmedAbsorptionUtc
                        : level2LastBuyConfirmedAbsorptionUtc;

                opposingAbsorptionExtreme =
                    isLong
                        ? level2LastSellConfirmedAbsorptionExtremePrice
                        : level2LastBuyConfirmedAbsorptionExtremePrice;
            }

            lock (marketContextLock)
            {
                recentStructureHigh =
                    latestM5RecentStructureHigh;

                recentStructureLow =
                    latestM5RecentStructureLow;
            }

            if (
                opposingAbsorptionUtc ==
                    DateTime.MinValue ||
                opposingAbsorptionExtreme <= 0
            )
            {
                return false;
            }

            double ageSeconds =
                (DateTime.UtcNow -
                    opposingAbsorptionUtc).TotalSeconds;

            if (
                ageSeconds < 0 ||
                ageSeconds >
                    RecentExtremeAwarenessSeconds
            )
            {
                return false;
            }

            // Select a meaningful structural/session extreme that matches
            // the Heavy Absorption event. We do not block merely because an
            // absorption occurred somewhere in open space.
            double referencePrice = 0.0;
            string referenceName = "NONE";
            double bestMatchTicks = double.MaxValue;

            Action<double, string> considerReference =
                (candidatePrice, candidateName) =>
                {
                    if (candidatePrice <= 0)
                        return;

                    double matchTicks =
                        Math.Abs(
                            candidatePrice -
                            opposingAbsorptionExtreme
                        ) / tickSize;

                    if (
                        matchTicks <=
                            RecentExtremeLevelMatchTicks &&
                        matchTicks < bestMatchTicks
                    )
                    {
                        bestMatchTicks =
                            matchTicks;

                        referencePrice =
                            candidatePrice;

                        referenceName =
                            candidateName;
                    }
                };

            if (isLong)
            {
                considerReference(
                    recentStructureHigh,
                    "M5 RECENT HIGH"
                );

                if (openingRangeReady)
                {
                    considerReference(
                        openingRangeHigh,
                        "OPENING RANGE HIGH"
                    );
                }

                if (premarketRangeReady)
                {
                    considerReference(
                        premarketRangeHigh,
                        "PREMARKET HIGH"
                    );
                }
            }
            else
            {
                considerReference(
                    recentStructureLow,
                    "M5 RECENT LOW"
                );

                if (openingRangeReady)
                {
                    considerReference(
                        openingRangeLow,
                        "OPENING RANGE LOW"
                    );
                }

                if (premarketRangeReady)
                {
                    considerReference(
                        premarketRangeLow,
                        "PREMARKET LOW"
                    );
                }
            }

            if (
                referencePrice <= 0 ||
                string.Equals(
                    referenceName,
                    "NONE",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return false;
            }

            // Once price has actually reclaimed the rejected extreme by a
            // small acceptance buffer, this specific location risk is gone.
            double signedBeyondReferenceTicks =
                isLong
                    ? (
                        currentPrice -
                        referencePrice
                      ) / tickSize
                    : (
                        referencePrice -
                        currentPrice
                      ) / tickSize;

            if (
                signedBeyondReferenceTicks >=
                    RecentExtremeAcceptanceBufferTicks
            )
            {
                summary =
                    "EXTREME RECLAIMED"
                    + " | Ref: "
                    + referenceName
                    + " @ "
                    + referencePrice.ToString("0.00")
                    + " | Acceptance: +"
                    + signedBeyondReferenceTicks.ToString("0.0")
                    + "t";

                return false;
            }

            double distanceToReferenceTicks =
                isLong
                    ? (
                        referencePrice -
                        currentPrice
                      ) / tickSize
                    : (
                        currentPrice -
                        referencePrice
                      ) / tickSize;

            // If the level is already materially behind price, it is not an
            // obstacle. If it is too far away, this entry is not "near" the
            // rejected extreme and normal authority remains unchanged.
            if (
                distanceToReferenceTicks < 0 ||
                distanceToReferenceTicks >
                    RecentExtremeMaxEntryDistanceTicks
            )
            {
                return false;
            }

            summary =
                "RECENT EXTREME REJECTION"
                + " | Ref: "
                + referenceName
                + " @ "
                + referencePrice.ToString("0.00")
                + " | OppAbs: "
                + (isLong ? "SELL" : "BUY")
                + " @ "
                + opposingAbsorptionExtreme.ToString("0.00")
                + " | Age: "
                + ageSeconds.ToString("0.0")
                + "s"
                + " | Distance: "
                + distanceToReferenceTicks.ToString("0.0")
                + "t"
                + " | Acceptance: NO"
                + " | Action: WAIT RETEST / RECLAIM";

            return true;
        }

        // =====================================================
        // V1.7.00 - REVERSAL HANDOFF EVALUATOR
        // =====================================================
        private bool TryEvaluateReversalHandoff(
            bool originalIsLong,
            double currentPrice,
            double tickSize,
            out bool handoffIsLong,
            out string summary)
        {
            handoffIsLong =
                !originalIsLong;

            summary =
                "REVERSAL HANDOFF NOT READY";

            if (
                currentPrice <= 0 ||
                tickSize <= 0
            )
            {
                return false;
            }

            // The original side must FIRST be rejected by the exact
            // Recent Extreme logic added in V1.6.99. This prevents the
            // handoff from becoming a general-purpose flip engine.
            string originalLocationSummary;

            if (
                !TryGetRecentExtremeLocationRisk(
                    originalIsLong,
                    currentPrice,
                    tickSize,
                    out originalLocationSummary
                )
            )
            {
                return false;
            }

            int longScore;
            int shortScore;
            double emaSlope;

            lock (marketContextLock)
            {
                longScore =
                    latestRangeLongScore;

                shortScore =
                    latestRangeShortScore;

                emaSlope =
                    latestRangeEmaSlope;
            }

            int oppositeR20Score =
                originalIsLong
                    ? shortScore
                    : longScore;

            int originalR20Score =
                originalIsLong
                    ? longScore
                    : shortScore;

            double slopeTicks =
                emaSlope / tickSize;

            double oppositeDirectionalSlopeTicks =
                originalIsLong
                    ? -slopeTicks
                    : slopeTicks;

            bool l2Ready;
            int oppositePersistence;
            int originalPersistence;
            string tapeBias;
            string confluence;
            string absorption;
            double signedOppositeDelta;

            lock (level2Sync)
            {
                l2Ready =
                    level2ObserveActive &&
                    level2BookReady &&
                    level2LastCalcUtc !=
                        DateTime.MinValue &&
                    (
                        DateTime.UtcNow -
                        level2LastCalcUtc
                    ).TotalSeconds <= 2.0 &&
                    level2SpreadTicks > 0 &&
                    level2SpreadTicks <= 8.0;

                oppositePersistence =
                    originalIsLong
                        ? level2ShortPersistence
                        : level2LongPersistence;

                originalPersistence =
                    originalIsLong
                        ? level2LongPersistence
                        : level2ShortPersistence;

                tapeBias =
                    level2TapeBias ?? "NEUTRAL";

                confluence =
                    level2Confluence ?? "NEUTRAL";

                absorption =
                    level2Absorption ?? "NONE";

                signedOppositeDelta =
                    originalIsLong
                        ? -level2TapeDelta
                        : level2TapeDelta;
            }

            if (!l2Ready)
            {
                summary =
                    "REVERSAL HANDOFF WAIT"
                    + " | Reason: LEVEL2 NOT FRESH";

                return false;
            }

            string oppositeSide =
                originalIsLong
                    ? "SHORT"
                    : "LONG";

            bool tapeOpposite =
                string.Equals(
                    tapeBias,
                    oppositeSide,
                    StringComparison.OrdinalIgnoreCase
                );

            bool confluenceOpposite =
                string.Equals(
                    confluence,
                    "LEAN " + oppositeSide,
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    confluence,
                    "STRONG " + oppositeSide,
                    StringComparison.OrdinalIgnoreCase
                );

            bool confirmedOppositeAbsorption =
                originalIsLong
                    ? string.Equals(
                        absorption,
                        "SELL ABSORPTION CONFIRMED",
                        StringComparison.OrdinalIgnoreCase
                      )
                    : string.Equals(
                        absorption,
                        "BUY ABSORPTION CONFIRMED",
                        StringComparison.OrdinalIgnoreCase
                      );

            bool oppositePriceDeveloping =
                oppositeR20Score >=
                    ReversalHandoffMinOppositeR20Score;

            bool oppositeSlopeDeveloping =
                oppositeDirectionalSlopeTicks >=
                    ReversalHandoffMinDirectionalSlopeTicks;

            bool oppositeFlowPersistent =
                oppositePersistence >=
                    ReversalHandoffMinPersistence &&
                oppositePersistence >
                    originalPersistence;

            // Two valid handoff confirmations:
            //
            // A) PRICE LED:
            //    R20 has already rotated 3/5 and fresh L2 agrees.
            //
            // B) FLOW LED:
            //    price slope has turned, persistence is strong and we have
            //    either confirmed absorption or strong opposite confluence.
            //
            // Level2 alone is never sufficient.
            bool priceLedHandoff =
                oppositePriceDeveloping &&
                oppositeFlowPersistent &&
                (
                    tapeOpposite ||
                    confluenceOpposite
                );

            bool flowLedHandoff =
                oppositeSlopeDeveloping &&
                oppositeFlowPersistent &&
                signedOppositeDelta > 0 &&
                (
                    confirmedOppositeAbsorption ||
                    (
                        tapeOpposite &&
                        confluenceOpposite
                    )
                );

            if (
                !priceLedHandoff &&
                !flowLedHandoff
            )
            {
                summary =
                    "REVERSAL HANDOFF ARMED / WAIT"
                    + " | From: "
                    + (
                        originalIsLong
                            ? "LONG"
                            : "SHORT"
                      )
                    + " | To: "
                    + oppositeSide
                    + " | OppR20: "
                    + oppositeR20Score
                    + "/5"
                    + " | OrigR20: "
                    + originalR20Score
                    + "/5"
                    + " | OppPersist: "
                    + oppositePersistence
                    + "/6"
                    + " | Slope: "
                    + oppositeDirectionalSlopeTicks.ToString("0.0")
                    + "t"
                    + " | Tape: "
                    + tapeBias
                    + " | Confluence: "
                    + confluence
                    + " | Action: WAIT PRICE CONFIRMATION";

                return false;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            string newSide =
                handoffIsLong
                    ? "LONG"
                    : "SHORT";

            bool sameSideCooldown =
                string.Equals(
                    lastReversalHandoffSide,
                    newSide,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                lastReversalHandoffUtc !=
                    DateTime.MinValue &&
                (
                    nowUtc -
                    lastReversalHandoffUtc
                ).TotalSeconds <
                    ReversalHandoffCooldownSeconds;

            if (sameSideCooldown)
            {
                summary =
                    "REVERSAL HANDOFF COOLDOWN"
                    + " | Side: "
                    + newSide;

                return false;
            }

            lastReversalHandoffUtc =
                nowUtc;

            lastReversalHandoffSide =
                newSide;

            summary =
                "REVERSAL HANDOFF CONFIRMED"
                + " | From: "
                + (
                    originalIsLong
                        ? "LONG"
                        : "SHORT"
                  )
                + " | To: "
                + newSide
                + " | OppR20: "
                + oppositeR20Score
                + "/5"
                + " | OppPersist: "
                + oppositePersistence
                + "/6"
                + " | Slope: "
                + oppositeDirectionalSlopeTicks.ToString("0.0")
                + "t"
                + " | Delta: "
                + signedOppositeDelta.ToString("0")
                + " | Tape: "
                + tapeBias
                + " | Confluence: "
                + confluence
                + " | Abs: "
                + absorption
                + " | Source: "
                + (
                    priceLedHandoff
                        ? "PRICE+FLOW"
                        : "SLOPE+FLOW"
                  )
                + " | Location: "
                + originalLocationSummary;

            return true;
        }

        // =====================================================
        // V1.7.04P - FINAL ENTRY PERSISTENCE GUARD
        // =====================================================
        // Minimal last-snapshot safety check only.
        // It does NOT create signals and does NOT change Explosion/R20/
        // Structure/Learning/Auto Direction. It only asks whether the
        // desired Level II direction is still alive immediately before
        // Final Entry Authority returns EXECUTE.
        private const int FinalEntryPersistenceNormalMin = 4;
        private const int FinalEntryPersistenceFastMin = 2;
        private const int FinalEntryPersistenceOppositeMax = 2;

        // =====================================================
        // V1.6.80 - SINGLE FINAL ENTRY AUTHORITY
        // =====================================================
        // Candidate engines may describe an opportunity, but only this
        // authority may approve the route immediately before order creation.
        // Quality / Confidence / Unified Edge are intentionally absent here.
        private sealed class FinalEntryDecision
        {
            public bool Execute;
            public string Decision;
            public string Strategy;
            public string Route;
            public string Reason;
        }

        private bool PassFinalEntryPersistenceGuard(
            bool isLong,
            string normalizedStrategy,
            string route,
            bool breakoutNow,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            out string reason)
        {
            reason =
                "PERSISTENCE NOT AVAILABLE";

            bool l2Ready = false;
            int desiredPersistence = 0;
            int oppositePersistence = 0;
            bool flowAligned = false;
            bool flowOpposed = false;
            string tapeBias = "NEUTRAL";
            string confluence = "NEUTRAL";

            lock (level2Sync)
            {
                l2Ready =
                    level2ObserveActive &&
                    level2BookReady &&
                    level2LastCalcUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds <= 2.0 &&
                    level2SpreadTicks > 0 &&
                    level2SpreadTicks <= 8.0;

                if (l2Ready)
                {
                    string desired =
                        isLong
                            ? "LONG"
                            : "SHORT";

                    string opposite =
                        isLong
                            ? "SHORT"
                            : "LONG";

                    desiredPersistence =
                        isLong
                            ? level2LongPersistence
                            : level2ShortPersistence;

                    oppositePersistence =
                        isLong
                            ? level2ShortPersistence
                            : level2LongPersistence;

                    tapeBias =
                        level2TapeBias
                        ?? "NEUTRAL";

                    confluence =
                        level2Confluence
                        ?? "NEUTRAL";

                    flowAligned =
                        string.Equals(
                            tapeBias,
                            desired,
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            confluence,
                            "STRONG " + desired,
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            confluence,
                            "LEAN " + desired,
                            StringComparison.OrdinalIgnoreCase
                        );

                    flowOpposed =
                        string.Equals(
                            tapeBias,
                            opposite,
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            confluence,
                            "STRONG " + opposite,
                            StringComparison.OrdinalIgnoreCase
                        );
                }
            }

            // Preserve the bot's existing behavior when Level II is not
            // currently usable. This guard is not allowed to become a new
            // "no Level II = no trade" hard dependency.
            if (!l2Ready)
            {
                reason =
                    "L2 NOT READY | EXISTING AUTHORITY PRESERVED";

                return true;
            }

            // Hard contradiction at the exact final snapshot.
            if (
                oppositePersistence >
                    FinalEntryPersistenceOppositeMax &&
                flowOpposed
            )
            {
                reason =
                    "OPPOSITE FLOW PERSISTENT"
                    + " | Persist "
                    + desiredPersistence
                    + "/"
                    + oppositePersistence
                    + " | Tape "
                    + tapeBias
                    + " | Confluence "
                    + confluence;

                return false;
            }

            // Fast expansion exception:
            // preserve JJ's ability to react to genuine NY/open-style
            // displacement without waiting for a full 4/6 persistence build.
            bool fastExpansion =
                breakoutNow &&
                volumeRatio >= 1.50 &&
                bodyRatio >= 0.75 &&
                (
                    isLong
                        ? slopeTicks >= 4.0
                        : slopeTicks <= -4.0
                ) &&
                flowAligned;

            int requiredPersistence =
                (
                    string.Equals(
                        route,
                        "FAST_OPEN",
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    fastExpansion
                )
                    ? FinalEntryPersistenceFastMin
                    : FinalEntryPersistenceNormalMin;

            if (
                desiredPersistence <
                    requiredPersistence
            )
            {
                reason =
                    "DESIRED PERSISTENCE TOO LOW"
                    + " | Need "
                    + requiredPersistence
                    + "/6"
                    + " | Persist "
                    + desiredPersistence
                    + "/"
                    + oppositePersistence
                    + " | FastExpansion "
                    + (
                        fastExpansion
                            ? "YES"
                            : "NO"
                      )
                    + " | Tape "
                    + tapeBias
                    + " | Confluence "
                    + confluence;

                return false;
            }

            reason =
                "PERSISTENCE CONFIRMED"
                + " | Need "
                + requiredPersistence
                + "/6"
                + " | Persist "
                + desiredPersistence
                + "/"
                + oppositePersistence
                + " | FastExpansion "
                + (
                    fastExpansion
                        ? "YES"
                        : "NO"
                  );

            return true;
        }

        private FinalEntryDecision EvaluateFinalEntryAuthority(
            bool isLong,
            DateTime signalNyTime,
            string strategy,
            string requestedRoute,
            bool manualTest)
        {
            string normalizedStrategy =
                string.IsNullOrWhiteSpace(strategy)
                    ? "MOMENTUM"
                    : strategy.Trim().ToUpperInvariant();

            string route =
                string.IsNullOrWhiteSpace(requestedRoute)
                    ? "DIRECT"
                    : requestedRoute.Trim().ToUpperInvariant();

            FinalEntryDecision result = new FinalEntryDecision
            {
                Execute = false,
                Decision = "WAIT",
                Strategy = normalizedStrategy,
                Route = route,
                Reason = "ROUTE NOT APPROVED"
            };

            if (manualTest)
            {
                result.Execute = true;
                result.Decision = "EXECUTE";
                result.Route = "DIRECT";
                result.Reason = "MANUAL TEST";
                return result;
            }

            // SMART_RETEST is a waiting route. Its own engine must create a
            // fresh candidate after the retest; it can never submit directly.
            if (route == "SMART_RETEST")
            {
                result.Reason = "WAIT SMART RETEST";
                return result;
            }

            // Route ownership is explicit. FAST_OPEN belongs only to OPENING.
            if (route == "FAST_OPEN" && normalizedStrategy != "OPENING")
            {
                result.Decision = "REJECT";
                result.Reason = "FAST_OPEN IS OPENING-ONLY";
                return result;
            }

            // Revalidate the premise at the executable-price snapshot.
            double currentPrice = GetEntryLocationPriceProxy(isLong);
            bool highBreakout;
            bool lowBreakout;
            double volumeRatio;
            double bodyRatio;
            double emaSlope;
            lock (marketContextLock)
            {
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
                volumeRatio = latestRangeVolumeRatio;
                bodyRatio = latestRangeBodyRatio;
                emaSlope = latestRangeEmaSlope;
            }

            bool breakoutNow = isLong ? highBreakout : lowBreakout;
            double tickSize =
                selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;
            double slopeTicks = tickSize > 0 ? emaSlope / tickSize : 0;

            // V1.6.99 - Location / Recent Extreme Awareness.
            // Keep this deliberately narrow: the evidence that motivated this
            // change was a Momentum rebound that looked powerful in R20 but
            // was still below a recently rejected high. Structure/Openings
            // keep their existing behavior until their own data proves a need.
            bool recentExtremeAwareRoute =
                normalizedStrategy == "MOMENTUM" &&
                (
                    route == "DIRECT" ||
                    route == "BREAKOUT_CONTINUATION"
                );

            if (recentExtremeAwareRoute)
            {
                string recentExtremeSummary;

                if (
                    TryGetRecentExtremeLocationRisk(
                        isLong,
                        currentPrice,
                        tickSize,
                        out recentExtremeSummary
                    )
                )
                {
                    result.Route =
                        "SMART_RETEST";

                    result.Reason =
                        recentExtremeSummary;

                    return result;
                }
            }

            if (route == "BREAKOUT_CONTINUATION")
            {
                bool displacementAlive =
                    breakoutNow &&
                    bodyRatio >= 0.60 &&
                    (volumeRatio >= 1.10 || bodyRatio >= 0.78) &&
                    (isLong ? slopeTicks >= 2.0 : slopeTicks <= -2.0);

                if (!displacementAlive)
                {
                    result.Reason = "BREAKOUT CONTINUATION PREMISE NO LONGER ACTIVE";
                    return result;
                }
            }

            if (route == "FAST_OPEN")
            {
                string ignitionReason;
                if (!TryEvaluateFastOpenIgnition(
                    isLong,
                    signalNyTime,
                    currentPrice,
                    out ignitionReason))
                {
                    result.Reason = "FAST OPEN INVALIDATED | " + ignitionReason;
                    return result;
                }
            }

            string persistenceReason;

            if (
                !PassFinalEntryPersistenceGuard(
                    isLong,
                    normalizedStrategy,
                    route,
                    breakoutNow,
                    volumeRatio,
                    bodyRatio,
                    slopeTicks,
                    out persistenceReason
                )
            )
            {
                result.Reason =
                    "ENTRY PERSISTENCE WAIT | "
                    + persistenceReason;

                return result;
            }

            result.Execute = true;
            result.Decision = "EXECUTE";
            result.Reason =
                "ROUTE PREMISE VALID AT FINAL SNAPSHOT"
                + " | "
                + persistenceReason;
            return result;
        }

       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null,
            bool openingEntry = false,
            bool highConvictionMomentum = false,
            string entryStrategy = "MOMENTUM",
            string entryRoute = "DIRECT",
            string entryRouteReason = null)
        {
            if (!botRunning)
                return;

            // FINAL LICENSE GATE.
            // This is intentionally inside the execution engine so every
            // automatic path and manual test is protected even if another
            // caller bypasses the UI Start button.
            if (!IsBotCloudLicenseValid())
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - BOT LICENSE EXPIRED"
                );

                return;
            }

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            // =====================================================
            // V1.7.00 - REVERSAL HANDOFF SIDE TRANSFER
            // =====================================================
            // This happens BEFORE the duplicate fingerprint and all normal
            // entry/risk guards so the transferred side goes through the
            // exact same authority chain as any native candidate.
            //
            // Only pure Momentum candidates are eligible. Structure,
            // Opening, Fast Open and manual tests are unchanged.
            bool reversalHandoffEligibleCandidate =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(
                    structureSetupKey
                ) &&
                string.Equals(
                    entryStrategy ?? "MOMENTUM",
                    "MOMENTUM",
                    StringComparison.OrdinalIgnoreCase
                );

            if (reversalHandoffEligibleCandidate)
            {
                double handoffTickSize =
                    instrument.MasterInstrument != null
                        ? instrument.MasterInstrument.TickSize
                        : 0.0;

                double handoffCurrentPrice =
                    GetEntryLocationPriceProxy(
                        isLong
                    );

                bool transferredIsLong;
                string handoffSummary;

                if (
                    TryEvaluateReversalHandoff(
                        isLong,
                        handoffCurrentPrice,
                        handoffTickSize,
                        out transferredIsLong,
                        out handoffSummary
                    )
                )
                {
                    string originalSide =
                        isLong
                            ? "LONG"
                            : "SHORT";

                    string transferredSide =
                        transferredIsLong
                            ? "LONG"
                            : "SHORT";

                    PrintBotMessage(
                        "REVERSAL HANDOFF"
                        + " | "
                        + originalSide
                        + " -> "
                        + transferredSide
                        + " | "
                        + handoffSummary
                        + " | Action: TRANSFER CANDIDATE / NORMAL FINAL AUTHORITY"
                    );

                    isLong =
                        transferredIsLong;

                    entryRoute =
                        "DIRECT";

                    entryRouteReason =
                        handoffSummary;
                }
            }

            if (!manualTest)
            {
                string entryEvaluationFingerprint =
                    (instrument.FullName ?? string.Empty)
                    + "|" + (isLong ? "LONG" : "SHORT")
                    + "|" + signalBarTime.Ticks
                    + "|" + (structureSetupKey ?? string.Empty)
                    + "|" + openingEntry
                    + "|" + highConvictionMomentum;

                DateTime fingerprintNowUtc = DateTime.UtcNow;
                bool duplicateEvaluation = false;

                lock (executionStateLock)
                {
                    duplicateEvaluation =
                        string.Equals(
                            entryEvaluationFingerprint,
                            lastEntryEvaluationFingerprint,
                            StringComparison.Ordinal)
                        &&
                        (fingerprintNowUtc - lastEntryEvaluationFingerprintUtc)
                            .TotalMilliseconds <= 75.0;

                    if (!duplicateEvaluation)
                    {
                        lastEntryEvaluationFingerprint =
                            entryEvaluationFingerprint;

                        lastEntryEvaluationFingerprintUtc =
                            fingerprintNowUtc;
                    }
                }

                if (duplicateEvaluation)
                {
                    if (!string.Equals(
                        lastEntryEvaluationDedupeLogKey,
                        entryEvaluationFingerprint,
                        StringComparison.Ordinal))
                    {
                        lastEntryEvaluationDedupeLogKey =
                            entryEvaluationFingerprint;

                        PrintBotMessage(
                            "DUPLICATE SIGNAL EVALUATION SKIPPED"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | Signal: " + signalBarTime.ToString("HH:mm:ss.fff")
                        );
                    }

                    return;
                }
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // =====================================================
            // V1.6.74 - PREMARKET 03:15 HARD EXECUTION GATE
            // =====================================================
            // 03:00-03:14:59 ET remains fully active for frontier, Level 2,
            // momentum, structure and Unified Edge analysis, but NO automatic
            // route may submit an order.  This lives in TrySubmitEntry so
            // Momentum / Structure / Smart Retest / Explosion / Unified Edge
            // all share the same final authority.  Manual Test remains manual.
            if (!manualTest)
            {
                DateTime executionClockNy =
                    GetCurrentNewYorkTime();

                if (IsPremarketExecutionGuardActive(executionClockNy))
                {
                    string guardKey =
                        executionClockNy.ToString("yyyyMMddHHmm");

                    if (!string.Equals(
                        lastPremarketExecutionGuardLogKey,
                        guardKey,
                        StringComparison.Ordinal))
                    {
                        lastPremarketExecutionGuardLogKey =
                            guardKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - PREMARKET GUARD"
                            + " | WAIT UNTIL 03:15 ET"
                            + " | Clock: "
                            + executionClockNy.ToString("HH:mm:ss")
                            + " ET"
                            + " | Signal: "
                            + signalNyTime.ToString("HH:mm:ss")
                            + " ET"
                            + " | Analysis: ACTIVE"
                        );
                    }

                    return;
                }

                // Once the hard gate is open, allow a future day/minute to
                // log normally without retaining a stale guard key.
                lastPremarketExecutionGuardLogKey =
                    string.Empty;
            }

            // Automatic entries MUST obey NY session.
            // Manual tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            // =====================================================
            // V1.7.01 - ASIA LOSS -> PRESERVE NY RISK BULLET
            // =====================================================
            // Keep all PREMARKET analysis active, but do not submit another
            // automatic trade after an official ASIA net loss.  Manual tests
            // remain diagnostic and are not affected.
            if (
                !manualTest &&
                string.Equals(
                    signalSession,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                double asiaLossNet;

                if (
                    IsPremarketSuppressedByAsiaLoss(
                        out asiaLossNet
                    )
                )
                {
                    string preserveKey =
                        signalNyTime.ToString("yyyyMMdd")
                        + "|ASIA_LOSS_PRE_SUPPRESS";

                    if (
                        !string.Equals(
                            lastAsiaLossPremarketBlockLogKey,
                            preserveKey,
                            StringComparison.Ordinal
                        )
                    )
                    {
                        lastAsiaLossPremarketBlockLogKey =
                            preserveKey;

                        PrintBotMessage(
                            "SESSION CAPITAL PRESERVATION"
                            + " | Asia Result: "
                            + asiaLossNet.ToString("$0.00")
                            + " NET"
                            + " | Premarket: OBSERVE ONLY"
                            + " | Reason: ASIA LOSS - PRESERVE NEXT TRADE FOR NY"
                            + " | NY Bullet: RESERVED"
                        );
                    }

                    return;
                }
            }

            // =====================================================
            // V1.6.36 - STARTUP MARKET WARMUP GUARD
            // =====================================================
            // Starting/restarting in the middle of an existing impulse must
            // not immediately inherit that move as a fresh entry. Analysis,
            // recovery, learning context and Level2 continue normally.
            if (
                !manualTest &&
                automaticEntryWarmupUntilNy != DateTime.MinValue &&
                GetCurrentNewYorkTime() < automaticEntryWarmupUntilNy
            )
            {
                int remainingWarmupSeconds =
                    Math.Max(
                        1,
                        (int)Math.Ceiling(
                            (automaticEntryWarmupUntilNy - GetCurrentNewYorkTime()).TotalSeconds
                        )
                    );

                string startupWarmupKey =
                    automaticEntryWarmupUntilNy.ToString("yyyyMMddHHmmss");

                if (startupWarmupKey != lastStartupWarmupBlockLogKey)
                {
                    lastStartupWarmupBlockLogKey = startupWarmupKey;
                    PrintBotMessage(
                        "ENTRY BLOCKED - STARTUP MARKET WARMUP"
                        + " | Remaining: " + remainingWarmupSeconds + "s"
                        + " | Context/L2/Learning: ACTIVE"
                        + " | Action: WAIT FRESH SIGNAL"
                    );
                }

                return;
            }

            bool momentumEntry =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(structureSetupKey);

            bool unifiedMomentumAuthority = false;
            int unifiedMomentumScore = 0;
            string unifiedMomentumSummary = string.Empty;

            // =====================================================
            // V1.6.62 - SINGLE MOMENTUM DECISION GATE
            // =====================================================
            // Momentum no longer needs to survive a chain of independent
            // M5/pressure/absorption/retest vetoes. It must pass one unified
            // history-led score. Legacy context remains available as weight.
            if (momentumEntry)
            {
                unifiedMomentumAuthority =
                    TryGetWeightedExecutionAuthority(
                        isLong,
                        signalNyTime,
                        out unifiedMomentumScore,
                        out unifiedMomentumSummary
                    );

                LogWeightedExecutionAuthority(
                    isLong,
                    signalNyTime,
                    unifiedMomentumScore,
                    unifiedMomentumSummary,
                    unifiedMomentumAuthority
                        ? "EXPLOSION EXECUTION AUTHORITY"
                        : "WAIT - EXPLOSION NOT READY"
                );

                if (!unifiedMomentumAuthority)
                    return;
            }

            // =====================================================
            // V1.6.35 - PREMARKET KNOWN-LOSS CLUSTER GUARD
            // =====================================================
            // Repeated losses have been observed around ~07:40 ET.
            // Keep market context and learning active, but do not allow an
            // automatic entry during this narrow window until the data says
            // the cluster has recovered. Manual TEST orders are unaffected.
            if (!manualTest && !unifiedMomentumAuthority && signalSession == "PREMARKET")
            {
                int premarketSignalTimeInt = ToTimeInt(signalNyTime);

                if (
                    premarketSignalTimeInt >= PremarketLossClusterStart &&
                    premarketSignalTimeInt <= PremarketLossClusterEnd
                )
                {
                    string lossClusterKey =
                        "PREMARKET_LOSS_CLUSTER|" +
                        signalNyTime.ToString("yyyyMMddHHmm");

                    if (lossClusterKey != lastRangeBlockedLogKey)
                    {
                        lastRangeBlockedLogKey = lossClusterKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - PREMARKET 07:40 LOSS CLUSTER"
                            + " | Window: 07:35-07:50 ET"
                            + " | Signal: "
                            + signalNyTime.ToString("HH:mm:ss")
                            + " ET"
                            + " | Context/Learning: ACTIVE"
                        );
                    }

                    return;
                }
            }

            // =====================================================
            // V1.6.24 - OPENING SAFETY HARDENING
            // =====================================================
            // These are FINAL execution gates. They live here so every
            // automatic path (Momentum / Opening / Structure) is protected
            // even if an upstream signal engine temporarily resolves AUTO.
            if (!manualTest)
            {
                int signalTimeInt =
                    ToTimeInt(signalNyTime);

                // -------------------------------------------------
                // 1) OPENING STABILITY GUARD
                // -------------------------------------------------
                // Do not trade the first 60 seconds after 09:30 ET.
                // The fast Range engine may flip LONG/SHORT/NONE several
                // times during price discovery; analysis continues, execution
                // waits until the first minute is complete.
                DateTime openingStartNy =
                    signalNyTime.Date
                        .AddHours(9)
                        .AddMinutes(30);

                double secondsFromOpen =
                    (
                        signalNyTime -
                        openingStartNy
                    ).TotalSeconds;

                bool fastOpenPriceCandidate =
                    IsFastOpenExtremePriceCandidate(
                        isLong
                    );

                string fastOpenLevel2Summary =
                    "L2 NOT CHECKED";

                bool fastOpenLevel2Confirmed =
                    fastOpenPriceCandidate &&
                    TryGetFastOpenLevel2Support(
                        isLong,
                        out fastOpenLevel2Summary
                    );

                string fastOpenIgnitionReason;
                bool fastOpenIgnition =
                    fastOpenPriceCandidate &&
                    TryEvaluateFastOpenIgnition(
                        isLong,
                        signalNyTime,
                        GetEntryLocationPriceProxy(isLong),
                        out fastOpenIgnitionReason
                    );

                // Level2 is context, not a mandatory key. A genuine 09:30
                // price/volume ignition may proceed with neutral L2.
                bool fastOpenOverride = fastOpenIgnition;

                if (fastOpenOverride && !fastOpenLevel2Confirmed)
                {
                    fastOpenLevel2Summary =
                        "L2 CONTEXT ONLY | " + fastOpenLevel2Summary;
                }

                if (
                    secondsFromOpen >= 0 &&
                    secondsFromOpen <
                        OpeningStabilityGuardSeconds &&
                    !fastOpenOverride
                )
                {
                    string openingStabilityKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT");

                    if (
                        openingStabilityKey !=
                            lastOpeningStabilityBlockLogKey
                    )
                    {
                        lastOpeningStabilityBlockLogKey =
                            openingStabilityKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - OPENING STABILITY GUARD"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | OpenAge: "
                            + Math.Max(
                                0,
                                (int)Math.Floor(
                                    secondsFromOpen
                                )
                              )
                            + "s/"
                            + OpeningStabilityGuardSeconds
                            + "s"
                            + " | Action: BUILD OPENING DIRECTION"
                        );
                    }

                    return;
                }

                if (
                    secondsFromOpen >= 0 &&
                    secondsFromOpen <
                        OpeningStabilityGuardSeconds &&
                    fastOpenOverride
                )
                {
                    PrintBotMessage(
                        "FAST OPEN ENTRY OVERRIDE"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | OpenAge: "
                        + Math.Max(
                            0,
                            (int)Math.Floor(
                                secondsFromOpen
                            )
                          )
                        + "s"
                        + " | R20/Expansion: EXTREME"
                        + " | "
                        + fastOpenLevel2Summary
                    );
                }

                bool m5BullishSnapshot;
                bool m5BearishSnapshot;
                string m5StructureSnapshot;

                lock (marketContextLock)
                {
                    m5BullishSnapshot =
                        latestM5BullishTrend;

                    m5BearishSnapshot =
                        latestM5BearishTrend;

                    m5StructureSnapshot =
                        latestM5StructureState;
                }

                bool trendOpposesEntry =
                    (
                        isLong &&
                        m5BearishSnapshot
                    ) ||
                    (
                        !isLong &&
                        m5BullishSnapshot
                    );

                bool structureAlignedForEntry =
                    IsStructureAlignedForSetup(
                        isLong,
                        m5StructureSnapshot
                    );

                bool insideOpeningSafetyWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningCounterTrendVetoEnd;

                // V1.6.31R3 - CURRENT OPENING PRESSURE COMPATIBILITY
                // The old dedicated latestOpeningPressure* snapshot fields
                // no longer exist in the current modular bot. Re-evaluate the
                // live directional pressure now, using the same M5/VWAP/R20/HTF
                // evidence used by the current Directional Pressure engine.
                int openingLongPressureScore;
                int openingShortPressureScore;

                string currentOpeningPressure =
                    EvaluateDirectionalPressure(
                        out openingLongPressureScore,
                        out openingShortPressureScore
                    );

                bool freshStrongOpeningPressureSupportsEntry =
                    string.Equals(
                        currentOpeningPressure,
                        isLong ? "LONG" : "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    ) &&
                    (
                        isLong
                            ? (
                                openingLongPressureScore >= 3 &&
                                openingShortPressureScore <= 1
                              )
                            : (
                                openingShortPressureScore >= 3 &&
                                openingLongPressureScore <= 1
                              )
                    );

                // -------------------------------------------------
                // 2) COUNTER-TREND OPENING VETO
                // -------------------------------------------------
                // Strong R20 / aggressive expansion may not override an
                // opposite confirmed M5 trend while structure is still
                // WAITING. A real BOS/CHOCH in the entry direction must
                // appear first.
                if (
                    insideOpeningSafetyWindow &&
                    trendOpposesEntry &&
                    !structureAlignedForEntry &&
                    !freshStrongOpeningPressureSupportsEntry &&
                    !fastOpenOverride &&
                    !unifiedMomentumAuthority
                )
                {
                    string counterTrendKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|"
                        + (m5StructureSnapshot ?? "NONE");

                    if (
                        counterTrendKey !=
                            lastOpeningCounterTrendBlockLogKey
                    )
                    {
                        lastOpeningCounterTrendBlockLogKey =
                            counterTrendKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER-TREND OPENING VETO"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | M5 Trend: "
                            + (
                                m5BullishSnapshot
                                    ? "BULLISH"
                                    : m5BearishSnapshot
                                        ? "BEARISH"
                                        : "NEUTRAL"
                              )
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | Action: WAIT BOS/CHOCH"
                        );
                    }

                    return;
                }

                if (
                    insideOpeningSafetyWindow &&
                    trendOpposesEntry &&
                    !structureAlignedForEntry &&
                    !freshStrongOpeningPressureSupportsEntry &&
                    fastOpenOverride
                )
                {
                    PrintBotMessage(
                        "FAST OPEN M5 VETO OVERRIDE"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | M5: "
                        + (
                            m5BullishSnapshot
                                ? "BULLISH"
                                : m5BearishSnapshot
                                    ? "BEARISH"
                                    : "NEUTRAL"
                          )
                        + " | "
                        + fastOpenLevel2Summary
                    );
                }

                // -------------------------------------------------
                // 3) SAME-SETUP REENTRY LOCK AFTER LOSS
                // -------------------------------------------------
                // Existing code allows a same-side loss to rearm after the
                // cooldown when high-conviction momentum returns. During
                // the opening window that is too permissive. After a loss,
                // the same side must produce fresh aligned M5 structure.
                string requestedSide =
                    isLong
                        ? "LONG"
                        : "SHORT";

                bool sameSideLoss =
                    lastAutomaticTradeExitWasLoss &&
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedSide,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool insideSameSetupRearmWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningSameSideLossStructureRearmEnd;

                bool freshM5ContextAfterLoss =
                    latestM5DecisionNyTime != DateTime.MinValue &&
                    latestM5DecisionNyTime >
                        lastAutomaticTradeExitNy;

                if (
                    sameSideLoss &&
                    insideSameSetupRearmWindow &&
                    !unifiedMomentumAuthority &&
                    (
                        !structureAlignedForEntry ||
                        !freshM5ContextAfterLoss
                    )
                )
                {
                    string sameSetupKey =
                        lastAutomaticTradeExitNy
                            .ToString("yyyyMMddHHmmss")
                        + "|"
                        + requestedSide;

                    if (
                        sameSetupKey !=
                            lastOpeningSameSetupBlockLogKey
                    )
                    {
                        lastOpeningSameSetupBlockLogKey =
                            sameSetupKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - SAME-SETUP LOSS REARM"
                            + " | Side: "
                            + requestedSide
                            + " | PriorLoss: YES"
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | FreshM5AfterLoss: "
                            + freshM5ContextAfterLoss
                            + " | Action: REQUIRE FRESH M5 + BOS/CHOCH"
                        );
                    }

                    return;
                }
            }

            // V1.6.20 - UNIVERSAL DIRECTIONAL SAFETY GATE.
            // Every automatic entry path must pass this final check.
            if (!manualTest && !unifiedMomentumAuthority)
            {
                string directionalBlockReason;

                if (
                    IsDirectionalSafetyBlocked(
                        isLong,
                        out directionalBlockReason
                    )
                )
                {
                    DateTime directionalGateNyTime =
                        ConvertToNewYorkTime(signalBarTime);

                    bool openingAuthorityOverride = false;
                    string openingAuthoritySummary = string.Empty;

                    int directionalSameSideScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    if (IsOpeningEntryWindow(directionalGateNyTime))
                    {
                        openingAuthorityOverride =
                            TryGetOpeningCounterM5ReversalSupport(
                                isLong,
                                directionalSameSideScore,
                                out openingAuthoritySummary
                            );
                    }

                    // V1.6.56 - UNIVERSAL exceptional microstructure authority.
                    // Outside Opening, or when Opening's own override is not
                    // available, a fresh 3/5+ breakout with high-conviction
                    // price action may outrank lagging directional pressure only
                    // when executed Level II flow confirms the same side.
                    if (!openingAuthorityOverride && highConvictionMomentum && directionalSameSideScore >= 3)
                    {
                        string universalFlowSummary;
                        bool universalFlowConfirmed =
                            TryGetEarlyAggressionFlowSupport(
                                isLong,
                                out universalFlowSummary
                            );

                        if (universalFlowConfirmed)
                        {
                            openingAuthorityOverride = true;
                            openingAuthoritySummary =
                                "UNIVERSAL EXCEPTIONAL FLOW | " + universalFlowSummary;
                        }
                    }

                    // V1.6.57 - A previously-qualified exceptional trigger may
                    // survive brief L2 flicker for the short commitment window.
                    // It may NOT override a currently strongly-opposed L2 state.
                    if (!openingAuthorityOverride)
                    {
                        string commitmentSummary;
                        bool commitmentActive =
                            IsExceptionalCommitmentActive(
                                isLong,
                                directionalGateNyTime,
                                out commitmentSummary
                            );

                        if (commitmentActive)
                        {
                            string opposedSummary;
                            bool stronglyOpposed =
                                IsInitialEntryLevel2StronglyOpposed(
                                    isLong,
                                    out opposedSummary
                                );

                            if (!stronglyOpposed)
                            {
                                openingAuthorityOverride = true;
                                openingAuthoritySummary =
                                    "EXCEPTIONAL COMMITMENT | " + commitmentSummary;
                            }
                        }
                    }

                    if (
                        !openingAuthorityOverride &&
                        !openingEntry &&
                        string.IsNullOrWhiteSpace(structureSetupKey)
                    )
                    {
                        int weightedDirectionalScore;
                        string weightedDirectionalSummary;

                        bool weightedDirectionalAuthority =
                            TryGetWeightedExecutionAuthority(
                                isLong,
                                directionalGateNyTime,
                                out weightedDirectionalScore,
                                out weightedDirectionalSummary
                            );

                        if (weightedDirectionalAuthority)
                        {
                            openingAuthorityOverride = true;
                            openingAuthoritySummary =
                                "HISTORICAL EDGE AUTHORITY | "
                                + weightedDirectionalSummary;

                            LogWeightedExecutionAuthority(
                                isLong,
                                directionalGateNyTime,
                                weightedDirectionalScore,
                                weightedDirectionalSummary,
                                "SOFT DIRECTIONAL PRESSURE OVERRIDE"
                            );
                        }
                    }

                    if (openingAuthorityOverride)
                    {
                        string overrideKey =
                            "DIRECTIONAL_PRESSURE_OVERRIDE|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|"
                            + directionalGateNyTime.ToString("yyyyMMddHHmmss");

                        if (overrideKey != lastDirectionalSafetyBlockKey)
                        {
                            lastDirectionalSafetyBlockKey = overrideKey;
                            PrintBotMessage(
                                "OPENING DIRECTIONAL PRESSURE OVERRIDE"
                                + " | Side: " + (isLong ? "LONG" : "SHORT")
                                + " | " + openingAuthoritySummary
                                + " | Action: CURRENT REVERSAL OUTRANKS LAGGING PRESSURE"
                            );
                        }
                    }
                    else
                    {
                        string pressureBlockKey =
                            "DIRECTIONAL_PRESSURE|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|" + latestDirectionalPressure
                            + "|" + latestDirectionalLongPressureScore
                            + "/" + latestDirectionalShortPressureScore;

                        if (
                            pressureBlockKey !=
                                lastDirectionalSafetyBlockKey
                        )
                        {
                            lastDirectionalSafetyBlockKey =
                                pressureBlockKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - COUNTER PRESSURE"
                                + " | Side: "
                                + (isLong ? "LONG" : "SHORT")
                                + " | " + directionalBlockReason
                                + " | Action: TREAT AS PULLBACK / WAIT RESUMPTION"
                            );
                        }

                        return;
                    }
                }
            }

            // =====================================================
            // V1.6.38 - COUNTER-M5 MOMENTUM HARD GATE
            // =====================================================
            // A standard 3/5 Momentum entry may not trade directly against
            // confirmed M5 trend. Counter-M5 entries require BOTH high
            // conviction price action and strongly aligned fresh Level II flow.
            if (momentumEntry && !unifiedMomentumAuthority)
            {
                bool m5Opposed =
                    (isLong && latestM5BearishTrend) ||
                    (!isLong && latestM5BullishTrend);

                if (m5Opposed)
                {
                    int sameSideScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string counterM5FlowSummary =
                        "L2 FLOW NOT CONFIRMED";

                    // V1.6.49 - M5 is context, not an absolute prison.
                    // A 3/5+ high-conviction price setup may execute before
                    // M5 flips only when fresh executed aggression already
                    // confirms the same direction.  The stricter legacy flow
                    // confirmation remains as a fallback.
                    bool earlyAggressionConfirmed = false;
                    bool strongLegacyFlowConfirmed = false;

                    if (highConvictionMomentum && sameSideScore >= 3)
                    {
                        earlyAggressionConfirmed =
                            TryGetEarlyAggressionFlowSupport(
                                isLong,
                                out counterM5FlowSummary
                            );

                        if (!earlyAggressionConfirmed)
                        {
                            strongLegacyFlowConfirmed =
                                TryGetLiquidityBreakFlowSupport(
                                    isLong,
                                    out counterM5FlowSummary
                                );
                        }
                    }

                    bool counterM5FlowConfirmed =
                        earlyAggressionConfirmed ||
                        strongLegacyFlowConfirmed;

                    // V1.6.57 - Preserve a fully-qualified exceptional thesis
                    // through a few noisy callbacks. The hold does not defeat
                    // the fresh-flow conflict veto: a strongly opposed current
                    // L2 snapshot still blocks the entry.
                    if (!counterM5FlowConfirmed)
                    {
                        DateTime counterM5NyTime =
                            ConvertToNewYorkTime(signalBarTime);
                        string commitmentSummary;
                        bool commitmentActive =
                            IsExceptionalCommitmentActive(
                                isLong,
                                counterM5NyTime,
                                out commitmentSummary
                            );

                        if (commitmentActive)
                        {
                            string opposedSummary;
                            bool stronglyOpposed =
                                IsInitialEntryLevel2StronglyOpposed(
                                    isLong,
                                    out opposedSummary
                                );

                            if (!stronglyOpposed)
                            {
                                counterM5FlowConfirmed = true;
                                counterM5FlowSummary =
                                    "EXCEPTIONAL COMMITMENT | " + commitmentSummary;
                            }
                        }
                    }

                    if (!counterM5FlowConfirmed)
                    {
                        int weightedCounterM5Score;
                        string weightedCounterM5Summary;

                        bool weightedCounterM5Authority =
                            TryGetWeightedExecutionAuthority(
                                isLong,
                                ConvertToNewYorkTime(signalBarTime),
                                out weightedCounterM5Score,
                                out weightedCounterM5Summary
                            );

                        if (weightedCounterM5Authority)
                        {
                            counterM5FlowConfirmed = true;
                            counterM5FlowSummary =
                                "HISTORICAL EDGE AUTHORITY | "
                                + weightedCounterM5Summary;

                            LogWeightedExecutionAuthority(
                                isLong,
                                ConvertToNewYorkTime(signalBarTime),
                                weightedCounterM5Score,
                                weightedCounterM5Summary,
                                "COUNTER-M5 SOFT CONTEXT OVERRIDE"
                            );
                        }
                    }

                    if (!counterM5FlowConfirmed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER M5 MOMENTUM"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | R20: " + sameSideScore + "/5"
                            + " | HighConviction: " + (highConvictionMomentum ? "YES" : "NO")
                            + " | M5: " + (latestM5BullishTrend ? "BULLISH" : latestM5BearishTrend ? "BEARISH" : "NEUTRAL")
                            + " | Flow: " + counterM5FlowSummary
                            + " | Action: WAIT FRESH AGGRESSION / NO M5 CHASE"
                        );

                        return;
                    }
                }
            }

            bool confirmedStructureRetest =
                !manualTest &&
                !openingEntry &&
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                ) &&
                string.Equals(
                    latestSetupTiming,
                    "CONFIRMED RETEST",
                    StringComparison.OrdinalIgnoreCase
                );

            // V1.6.33 - Smart Retest timing refinement.
            // Price/structure already confirmed the setup, but do not submit
            // into clearly opposing immediate Level II flow. The pending retest
            // remains alive, so a later Range bar may still enter after L2
            // neutralizes or aligns.
            if (confirmedStructureRetest)
            {
                string retestLevel2Summary;

                if (
                    IsSmartRetestLevel2Opposed(
                        isLong,
                        out retestLevel2Summary
                    )
                )
                {
                    PrintBotMessage(
                        "SMART RETEST WAIT - LEVEL2 OPPOSING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | "
                        + retestLevel2Summary
                        + " | Action: KEEP RETEST ARMED"
                    );

                    return;
                }
            }

            // =====================================================
            // V1.6.25 - FINAL LEARNING EXECUTION VETO
            // =====================================================
            // Upstream UI/scoring can never bypass a negative exact learning
            // bucket. Prefer the context captured by the signal source. For
            // momentum, derive the exact R20 key when no pending label exists.
            if (!manualTest && !unifiedMomentumAuthority)
            {
                string executionLearningContext =
                    pendingLearningStructure;

                if (
                    string.IsNullOrWhiteSpace(
                        executionLearningContext
                    ) &&
                    momentumEntry
                )
                {
                    int executionMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    executionLearningContext =
                        "R20 MOMENTUM "
                        + executionMomentumScore
                        + "/5";
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        executionLearningContext
                    )
                )
                {
                    string executionLearningReason;

                    bool executionLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            executionLearningContext,
                            out executionLearningReason
                        );

                    if (!executionLearningAllowed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEARNING"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | Setup: "
                            + executionLearningContext
                            + " | "
                            + executionLearningReason
                        );

                        return;
                    }
                }

                // V1.6.33 - confirmed structure retest semantics.
                // The generic R20 bucket describes EARLY momentum behavior.
                // A confirmed BOS/CHOCH retest is a different execution path.
                // We keep the exact structure learning gate above authoritative,
                // while making any generic R20 disagreement explicit in logs.
                if (confirmedStructureRetest)
                {
                    int retestMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string retestGenericContext =
                        "R20 MOMENTUM "
                        + retestMomentumScore
                        + "/5";

                    string retestGenericReason;

                    bool retestGenericAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            retestGenericContext,
                            out retestGenericReason
                        );

                    if (!retestGenericAllowed)
                    {
                        PrintBotMessage(
                            "LEARNING EARLY BUCKET OVERRIDDEN BY CONFIRMED RETEST"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | EarlyBucket: "
                            + retestGenericContext
                            + " | "
                            + retestGenericReason
                            + " | StructureSetup: "
                            + structureSetupKey
                        );
                    }
                }

                // =================================================
                // V1.6.27 - QUALITY/EXECUTION LEARNING CONSISTENCY
                // =================================================
                // The Nasdaq quality layer evaluates the generic R20
                // score bucket ("R20 MOMENTUM N/5").  Previously an
                // aggressive/extreme exact bucket could pass while that
                // generic bucket was already BLOCK, producing the
                // contradictory log:
                //     SETUP QUALITY ... Learning BLOCK
                //     SIM ENTRY SUBMITTED
                //
                // For automatic Momentum entries, BOTH the exact setup
                // bucket and the generic R20 quality bucket must allow.
                if (momentumEntry)
                {
                    int genericMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string genericLearningContext =
                        "R20 MOMENTUM "
                        + genericMomentumScore
                        + "/5";

                    string genericLearningReason;

                    bool genericLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            genericLearningContext,
                            out genericLearningReason
                        );

                    if (!genericLearningAllowed)
                    {
                        // V1.6.43 - CONTEXTUAL LEARNING AUTHORITY.
                        // Reaching this point means the exact signal-context bucket
                        // above has already PASSED. A negative generic R20 bucket
                        // may therefore be downgraded from BLOCK to CAUTION only
                        // when the CURRENT setup is exceptional and live order flow
                        // strongly confirms it. This is intentionally narrow:
                        // 4/5+, real breakout, strong body/volume, high-conviction
                        // price path, fresh L2 persistence/aggression/delta alignment,
                        // and no adverse absorption. All downstream risk/location/
                        // anti-chase/session guards remain authoritative.
                        bool breakoutAligned =
                            isLong
                                ? latestRangeHighBreakout
                                : latestRangeLowBreakout;

                        int sameSideScore =
                            isLong
                                ? latestRangeLongScore
                                : latestRangeShortScore;

                        bool exceptionalPriceContext =
                            highConvictionMomentum &&
                            sameSideScore >= 4 &&
                            breakoutAligned &&
                            latestRangeVolumeRatio >= 1.15 &&
                            latestRangeBodyRatio >= 0.68;

                        string exceptionalFlowSummary = string.Empty;
                        bool exceptionalFlowConfirmed = false;
                        bool freshAuthorityNotOpposed = false;

                        if (exceptionalPriceContext)
                        {
                            exceptionalFlowConfirmed =
                                TryGetLiquidityBreakFlowSupport(
                                    isLong,
                                    out exceptionalFlowSummary
                                );

                            if (!exceptionalFlowConfirmed)
                            {
                                string opposedSummary;
                                bool stronglyOpposed =
                                    IsInitialEntryLevel2StronglyOpposed(
                                        isLong,
                                        out opposedSummary
                                    );

                                freshAuthorityNotOpposed = !stronglyOpposed;

                                if (string.IsNullOrWhiteSpace(exceptionalFlowSummary))
                                    exceptionalFlowSummary = opposedSummary;
                            }
                        }

                        if (exceptionalFlowConfirmed || freshAuthorityNotOpposed)
                        {
                            PrintBotMessage(
                                "LEARNING QUALITY BUCKET OVERRIDE - EXCEPTIONAL FLOW"
                                + " | Side: "
                                + (isLong ? "LONG" : "SHORT")
                                + " | Generic: "
                                + genericLearningContext
                                + " | Exact: "
                                + (
                                    string.IsNullOrWhiteSpace(executionLearningContext)
                                        ? "N/A"
                                        : executionLearningContext
                                  )
                                + " | R20: "
                                + sameSideScore
                                + "/5"
                                + " | Vol x"
                                + latestRangeVolumeRatio.ToString("0.00")
                                + " | Body "
                                + (latestRangeBodyRatio * 100.0).ToString("0")
                                + "% | "
                                + exceptionalFlowSummary
                                + " | Action: GENERIC BLOCK -> CAUTION / FRESH AUTHORITY"
                            );
                        }
                        else
                        {
                            string learningBlockKey =
                                (isLong ? "LONG" : "SHORT")
                                + "|"
                                + genericLearningContext
                                + "|"
                                + genericLearningReason;

                            DateTime nowUtc = DateTime.UtcNow;

                            if (
                                learningBlockKey !=
                                    lastLearningQualityBucketBlockKey ||
                                (
                                    nowUtc -
                                    lastLearningQualityBucketBlockLogUtc
                                ).TotalSeconds >= 15
                            )
                            {
                                lastLearningQualityBucketBlockKey =
                                    learningBlockKey;

                                lastLearningQualityBucketBlockLogUtc =
                                    nowUtc;

                                PrintBotMessage(
                                    "ENTRY BLOCKED - LEARNING QUALITY BUCKET"
                                    + " | Side: "
                                    + (isLong ? "LONG" : "SHORT")
                                    + " | Setup: "
                                    + genericLearningContext
                                    + " | "
                                    + genericLearningReason
                                    + " | ExceptionalPrice: "
                                    + (exceptionalPriceContext ? "YES" : "NO")
                                    + " | Flow: "
                                    + (
                                        string.IsNullOrWhiteSpace(exceptionalFlowSummary)
                                            ? "NOT CONFIRMED"
                                            : exceptionalFlowSummary
                                      )
                                );
                            }

                            return;
                        }
                    }
                }
            }

            // V1.6.23 Phase 11 - final quality gate for MOMENTUM entries.
            // Opening and confirmed structure setups keep their own engines.
            if (
                momentumEntry &&
                !unifiedMomentumAuthority &&
                !IsOpeningEntryWindow(signalNyTime)
            )
            {
                string entryQualityReason;

                if (
                    IsMomentumEntryQualityBlocked(
                        isLong,
                        highConvictionMomentum,
                        out entryQualityReason
                    )
                )
                {
                    int weightedQualityScore;
                    string weightedQualitySummary;

                    bool weightedQualityAuthority =
                        TryGetWeightedExecutionAuthority(
                            isLong,
                            signalNyTime,
                            out weightedQualityScore,
                            out weightedQualitySummary
                        );

                    if (weightedQualityAuthority)
                    {
                        LogWeightedExecutionAuthority(
                            isLong,
                            signalNyTime,
                            weightedQualityScore,
                            weightedQualitySummary,
                            "QUALITY/REGIME SOFT BLOCK OVERRIDE"
                        );
                    }
                    else
                    {
                        string qualityBlockKey =
                            "ENTRY_QUALITY|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|" + latestMarketRegime
                            + "|" + latestMarketRegimeDirection
                            + "|" + latestRangeLongScore
                            + "/" + latestRangeShortScore;

                        if (
                            qualityBlockKey !=
                                lastEntryQualityBlockKey
                        )
                        {
                            lastEntryQualityBlockKey =
                                qualityBlockKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - QUALITY / REGIME"
                                + " | " + entryQualityReason
                                + " | Action: WAIT CLEAN CONTINUATION"
                            );
                        }

                        return;
                    }
                }
            }

            if (!manualTest)
            {
                int lateEntryAgeSeconds;
                int lateEntryMaxSeconds;

                if (
                    IsLateAutomaticEntry(
                        signalNyTime,
                        momentumEntry,
                        openingEntry,
                        highConvictionMomentum,
                        out lateEntryAgeSeconds,
                        out lateEntryMaxSeconds
                    )
                )
                {
                    string lateEntryKey =
                        signalBarTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + (
                            openingEntry
                                ? "OPENING"
                                : momentumEntry
                                    ? "MOMENTUM"
                                    : "STRUCTURE"
                          );

                    if (
                        lateEntryKey !=
                            lastLateEntryBlockLogKey
                    )
                    {
                        lastLateEntryBlockLogKey =
                            lateEntryKey;

                        PrintBotMessage(
                            "SKIP TRADE - LATE ENTRY"
                            + " | Type: "
                            + (
                                openingEntry
                                    ? "OPENING"
                                    : momentumEntry
                                        ? "MOMENTUM"
                                        : "STRUCTURE"
                              )
                            + " | Age: "
                            + lateEntryAgeSeconds
                            + "s"
                            + " | Max: "
                            + lateEntryMaxSeconds
                            + "s"
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | StrategyClock: "
                            + GetCurrentNewYorkTime()
                                .ToString(
                                    "HH:mm:ss"
                                )
                            + " ET"
                            + (
                                momentumEntry
                                    ? " | HighConviction: "
                                        + (highConvictionMomentum ? "YES" : "NO")
                                    : string.Empty
                              )
                            + " | Action: NO CHASE"
                        );
                    }

                    return;
                }

                string reentryReason;

                if (
                    IsAutomaticReentryBlocked(
                        isLong,
                        signalBarTime,
                        momentumEntry,
                        highConvictionMomentum,
                        out reentryReason
                    )
                )
                {
                    // V1.6.6 - one reentry-block log per cooldown cycle
                    // and side. Do not create a new key every second as the
                    // remaining cooldown text changes.
                    string reentryBlockKey =
                        "REENTRY|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + lastAutomaticTradeExitNy.ToString(
                            "yyyyMMddHHmmss"
                        );

                    if (
                        reentryBlockKey !=
                            lastReentryBlockLogKey
                    )
                    {
                        lastReentryBlockLogKey =
                            reentryBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - REENTRY REARM"
                            + " | "
                            + reentryReason
                            + " | Side: "
                            + (
                                isLong
                                    ? "LONG"
                                    : "SHORT"
                              )
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                        );
                    }

                    return;
                }
            }

            // =====================================================
            // V1.6.36 - SAME-SIDE REENTRY RESET GUARD
            // =====================================================
            // A timer + a few ticks of pullback is not a new market cycle.
            // After ANY automatic exit, another entry in the same direction
            // must wait for fresh completed M5 context after the exit AND an
            // aligned BOS/CHOCH structure state. This protects winning trades
            // from being immediately recycled into a late continuation chase.
            if (!manualTest && !unifiedMomentumAuthority && lastAutomaticTradeExitNy != DateTime.MinValue)
            {
                string requestedResetSide = isLong ? "LONG" : "SHORT";
                bool sameSideResetRequired =
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedResetSide,
                        StringComparison.OrdinalIgnoreCase
                    );

                if (sameSideResetRequired)
                {
                    string reentryStructureState;
                    DateTime reentryM5DecisionNy;

                    lock (marketContextLock)
                    {
                        reentryStructureState = latestM5StructureState;
                        reentryM5DecisionNy = latestM5DecisionNyTime;
                    }

                    bool freshM5AfterExit =
                        reentryM5DecisionNy != DateTime.MinValue &&
                        reentryM5DecisionNy > lastAutomaticTradeExitNy;

                    bool alignedResetStructure =
                        IsStructureAlignedForSetup(
                            isLong,
                            reentryStructureState
                        );

                    if (!freshM5AfterExit || !alignedResetStructure)
                    {
                        string resetKey =
                            "REENTRY_RESET|"
                            + requestedResetSide
                            + "|"
                            + lastAutomaticTradeExitNy.ToString("yyyyMMddHHmmss");

                        if (resetKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = resetKey;
                            PrintBotMessage(
                                "ENTRY BLOCKED - SAME-SIDE REENTRY RESET"
                                + " | Side: " + requestedResetSide
                                + " | FreshM5AfterExit: " + freshM5AfterExit
                                + " | Structure: "
                                + (string.IsNullOrWhiteSpace(reentryStructureState)
                                    ? "WAITING"
                                    : reentryStructureState)
                                + " | Action: REQUIRE FRESH M5 + ALIGNED BOS/CHOCH"
                            );
                        }

                        return;
                    }
                }
            }

            // V1.6.35 - LEVEL 2 SAME-SIDE REENTRY VETO.
            // Level 2 remains observe-only for initial entries. For a same-side
            // reentry, however, persistent opposite tape/order-flow may veto a
            // late continuation attempt. It never creates an entry by itself.
            if (!manualTest && !unifiedMomentumAuthority && lastAutomaticTradeExitNy != DateTime.MinValue)
            {
                string requestedReentrySide = isLong ? "LONG" : "SHORT";
                bool sameSideReentry =
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedReentrySide,
                        StringComparison.OrdinalIgnoreCase
                    );

                if (sameSideReentry && level2BookReady)
                {
                    int oppositePersistence =
                        isLong
                            ? level2ShortPersistence
                            : level2LongPersistence;

                    string oppositeSide = isLong ? "SHORT" : "LONG";
                    bool oppositeTape =
                        string.Equals(
                            level2TapeBias,
                            oppositeSide,
                            StringComparison.OrdinalIgnoreCase
                        );

                    if (oppositePersistence >= 5 && oppositeTape)
                    {
                        string l2ReentryKey =
                            "REENTRY_L2_VETO|"
                            + requestedReentrySide
                            + "|"
                            + lastAutomaticTradeExitNy.ToString("yyyyMMddHHmmss");

                        if (l2ReentryKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = l2ReentryKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - REENTRY LEVEL2 VETO"
                                + " | Side: " + requestedReentrySide
                                + " | TapeBias: " + level2TapeBias
                                + " | OppPersistence: "
                                + oppositePersistence
                                + "/6"
                                + " | Level2 remains OBSERVE-ONLY for initial entries"
                            );
                        }

                        return;
                    }
                }
            }

            // =====================================================
            // V1.6.37 - INITIAL ENTRY LEVEL II STRONG-CONTRARY VETO
            // =====================================================
            // Level II still never creates the initial setup. It can only
            // delay an otherwise-valid entry when immediate aggressive flow
            // is exceptionally contrary to the requested side.
            if (!manualTest && !unifiedMomentumAuthority)
            {
                string initialL2Summary;
                bool initialL2Opposed =
                    IsInitialEntryLevel2StronglyOpposed(
                        isLong,
                        out initialL2Summary
                    );

                if (initialL2Opposed)
                {
                    string initialL2Key =
                        "INITIAL_L2_VETO|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|"
                        + signalNyTime.ToString("yyyyMMddHHmmss");

                    if (initialL2Key != lastRangeBlockedLogKey)
                    {
                        lastRangeBlockedLogKey = initialL2Key;
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEVEL2 STRONG CONTRARY FLOW"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | " + initialL2Summary
                            + " | Action: WAIT FLOW NEUTRALIZE / ALIGN"
                        );
                    }

                    return;
                }
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                // V1.6.6 - session limit is a persistent state, not a
                // per-Range-bar event. Log it once until the state changes.
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + GetSessionTradeCount(
                        signalSession
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        signalSession
                    );

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + GetSessionTradeLimit(
                            signalSession
                        )
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !manualTest &&
                positionRecoveryPending
            )
            {
                string recoveryBlockedKey =
                    "POSITION_RECOVERY_PENDING|"
                    + signalBarTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (
                    recoveryBlockedKey !=
                        lastRangeBlockedLogKey
                )
                {
                    lastRangeBlockedLogKey =
                        recoveryBlockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION RECOVERY PENDING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | Waiting for NinjaTrader account sync."
                    );
                }

                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | SignalBar: "
                        + ConvertToNewYorkTime(
                            signalBarTime
                          ).ToString(
                            "HH:mm:ss"
                          )
                        + " ET"
                    );
                }

                return;
            }

            // =====================================================
            // V1.6.30 - PRE-ENTRY STRUCTURE LOCATION GUARD
            // =====================================================
            // Freeze/reset the location snapshot only after FLAT is confirmed.
            // Subsequent signals while a trade is open therefore cannot erase
            // the location context of the active trade.
            activeEntryRoomTicks = 0;
            activeEntryLocationState = openingEntry ? "OPENING" : "OPEN";
            activeEntryLocationReference = openingEntry ? "OPENING BREAKOUT" : "OPEN SPACE";
            activeEntryLocationReferencePrice = 0;

            // Opening breakouts are excluded because crossing the OR boundary
            // is the setup itself. Manual tests are never filtered.
            double locationTickSize =
                instrument.MasterInstrument != null
                    ? instrument.MasterInstrument.TickSize
                    : 0;

            double locationSignalPrice =
                GetEntryLocationPriceProxy(isLong);

            if (!manualTest && !openingEntry)
            {
                double tickSize = locationTickSize;
                double signalPrice = locationSignalPrice;

                double roomTicks;
                string locationReference;
                double locationReferencePrice;

                bool hasBarrier =
                    TryGetEntryLocationRoom(
                        isLong,
                        signalPrice,
                        tickSize,
                        out roomTicks,
                        out locationReference,
                        out locationReferencePrice
                    );

                // Use the same structural safety buffer used by the
                // structure-aware target. RR eligibility must be based on the
                // room we can actually monetize BEFORE the barrier, not the raw
                // distance to the barrier itself.
                int rawAvailableRoomTicks =
                    hasBarrier
                        ? Math.Max(1, (int)Math.Floor(roomTicks))
                        : 0;

                int structuralBufferTicks =
                    hasBarrier
                        ? Math.Min(
                            StructureTargetMaxBufferTicks,
                            Math.Max(1, rawAvailableRoomTicks / 5)
                          )
                        : 0;

                double effectiveRoomTicks =
                    hasBarrier
                        ? Math.Max(0, rawAvailableRoomTicks - structuralBufferTicks)
                        : 0;

                activeEntryRoomTicks = hasBarrier ? effectiveRoomTicks : 0;
                activeEntryLocationReference = hasBarrier ? locationReference : "OPEN SPACE";
                activeEntryLocationReferencePrice = hasBarrier ? locationReferencePrice : 0;
                bool sameSideReentryLocationCheck =
                    lastAutomaticTradeExitNy != DateTime.MinValue &&
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        isLong ? "LONG" : "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    );

                double minimumStructuralR =
                    sameSideReentryLocationCheck
                        ? ReentryMinimumStructuralR
                        : InitialMinimumStructuralR;

                double minimumRequiredRoomTicks =
                    Math.Max(
                        EntryLocationMinRoomTicks,
                        activeStopTicks * minimumStructuralR
                    );

                activeEntryLocationState =
                    !hasBarrier
                        ? "OPEN"
                        : effectiveRoomTicks < minimumRequiredRoomTicks
                            ? "POOR"
                            : effectiveRoomTicks < minimumRequiredRoomTicks * 1.5
                                ? "FAIR"
                                : "GOOD";

                // V1.6.41 - STRUCTURE LOCATION remains the normal authority,
                // but a barrier that has ACTUALLY been consumed with fresh,
                // aligned aggressive flow is no longer treated as intact
                // resistance/support. This closes the dead zone seen on 09/03:
                // block below liquidity -> break liquidity -> anti-chase too late.
                //
                // IMPORTANT: confluence alone can never bypass a POOR location.
                // The exception requires the existing Liquidity Break Acceptance
                // window, which itself requires a real cross, proximity to the
                // broken level and strong symmetric Level II confirmation.
                bool exceptionalLiquidityBreakLocation = false;
                string exceptionalLiquidityBreakSummary = string.Empty;

                if (hasBarrier && effectiveRoomTicks < minimumRequiredRoomTicks)
                {
                    bool liquidityBreakSessionEligible =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            signalSession,
                            "AM",
                            StringComparison.OrdinalIgnoreCase
                        );

                    // First sighting of a nearby barrier: arm it, but DO NOT enter.
                    // This preserves protection from buying under a high / selling
                    // above a low merely because momentum looks strong.
                    if (
                        highConvictionMomentum &&
                        liquidityBreakSessionEligible
                    )
                    {
                        bool samePendingBarrier =
                            pendingLiquidityBreakActive &&
                            pendingLiquidityBreakIsLong == isLong &&
                            Math.Abs(
                                pendingLiquidityBreakLevel - locationReferencePrice
                            ) <= Math.Max(tickSize, 0.0000001);

                        if (!samePendingBarrier)
                        {
                            ArmLiquidityBreakAcceptanceLevel(
                                isLong,
                                locationReferencePrice,
                                locationReference,
                                signalNyTime
                            );
                        }

                        // Only a previously armed level that is now genuinely
                        // crossed and flow-confirmed may bypass this stale barrier.
                        exceptionalLiquidityBreakLocation =
                            TryGetLiquidityBreakAcceptanceOverride(
                                isLong,
                                signalNyTime,
                                signalPrice,
                                tickSize,
                                true,
                                out exceptionalLiquidityBreakSummary
                            );
                    }

                    if (exceptionalLiquidityBreakLocation)
                    {
                        activeEntryLocationState = "EXCEPTIONAL";

                        recentStructureLocationBlockActive = false;
                        recentStructureLocationBlockUtc = DateTime.MinValue;

                        PrintBotMessage(
                            "STRUCTURE LOCATION REVALIDATED"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | FormerBarrier: " + locationReference
                            + " @ " + locationReferencePrice.ToString("0.00")
                            + " | " + exceptionalLiquidityBreakSummary
                            + " | Action: ENTRY AUTHORITY RESTORED"
                        );
                        activeEntryLocationReference =
                            "BROKEN " + locationReference;

                        string exceptionKey =
                            "LOCATION_BREAK|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|"
                            + pendingLiquidityBreakLevel.ToString("0.00")
                            + "|"
                            + signalBarTime.ToString("yyyyMMddHHmmss");

                        if (exceptionKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = exceptionKey;

                            PrintBotMessage(
                                "STRUCTURE LOCATION OVERRIDE - CONFIRMED LIQUIDITY BREAK"
                                + " | Side: " + (isLong ? "LONG" : "SHORT")
                                + " | Price: " + signalPrice.ToString("0.00")
                                + " | FormerBarrier: " + locationReference
                                + " @ " + locationReferencePrice.ToString("0.00")
                                + " | " + exceptionalLiquidityBreakSummary
                                + " | Action: ALLOW EARLY ENTRY NEAR CONSUMED LIQUIDITY"
                            );
                        }
                    }
                    else
                    {
                        string locationKey =
                            "LOCATION|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|"
                            + signalBarTime.ToString("yyyyMMddHHmmss")
                            + "|"
                            + locationReference;

                        recentStructureLocationBlockActive = true;
                        recentStructureLocationBlockIsLong = isLong;
                        recentStructureLocationBlockLevel = locationReferencePrice;
                        recentStructureLocationBlockReference = locationReference ?? "STRUCTURE";
                        recentStructureLocationBlockUtc = DateTime.UtcNow;

                        if (locationKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = locationKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - STRUCTURE LOCATION"
                                + " | Side: " + (isLong ? "LONG" : "SHORT")
                                + " | Price: " + signalPrice.ToString("0.00")
                                + " | Next: " + locationReference
                                + " @ " + locationReferencePrice.ToString("0.00")
                                + " | RawRoom: " + roomTicks.ToString("0") + "t"
                                + " | Buffer: " + structuralBufferTicks + "t"
                                + " | EffectiveRoom: " + effectiveRoomTicks.ToString("0") + "t"
                                + " | Min: " + minimumRequiredRoomTicks.ToString("0") + "t"
                                + " | MinR: " + minimumStructuralR.ToString("0.00")
                                + (sameSideReentryLocationCheck
                                    ? " | Reentry: YES"
                                    : " | Reentry: NO")
                                + " | Action: WAIT BREAK + AGGRESSIVE FLOW OR BETTER LOCATION / RETEST"
                            );
                        }

                        return;
                    }
                }

                if (hasBarrier)
                {
                    PrintBotMessage(
                        "ENTRY LOCATION"
                        + " | " + activeEntryLocationState
                        + " | Side: " + (isLong ? "LONG" : "SHORT")
                        + " | Room: " + effectiveRoomTicks.ToString("0") + "t"
                        + " | RawRoom: " + roomTicks.ToString("0") + "t"
                        + " | Next: " + locationReference
                        + " @ " + locationReferencePrice.ToString("0.00")
                    );
                }
            }

            // V1.6.75 - FINAL LOCATION BLOCK FENCE.
            // If a POOR location was blocked moments ago, a rolling structure
            // snapshot is not enough to silently erase that decision. Require
            // the existing Liquidity Break Acceptance revalidation, or wait for
            // the short fence to expire. This preserves fast breakouts because
            // a real, flow-confirmed break releases the fence immediately.
            if (
                !manualTest &&
                recentStructureLocationBlockActive &&
                recentStructureLocationBlockIsLong == isLong &&
                recentStructureLocationBlockUtc != DateTime.MinValue
            )
            {
                double locationFenceAgeSeconds =
                    (DateTime.UtcNow - recentStructureLocationBlockUtc).TotalSeconds;

                if (
                    locationFenceAgeSeconds >= 0.0 &&
                    locationFenceAgeSeconds <= StructureLocationBlockFenceSeconds
                )
                {
                    string locationRevalidationSummary;
                    bool locationRevalidated =
                        TryGetLiquidityBreakAcceptanceOverride(
                            isLong,
                            signalNyTime,
                            locationSignalPrice,
                            locationTickSize,
                            true,
                            out locationRevalidationSummary
                        );

                    if (!locationRevalidated)
                    {
                        PrintBotMessage(
                            "ENTRY HOLD - RECENT STRUCTURE LOCATION BLOCK"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | FormerBarrier: "
                            + recentStructureLocationBlockReference
                            + " @ " + recentStructureLocationBlockLevel.ToString("0.00")
                            + " | Age: " + locationFenceAgeSeconds.ToString("0.0") + "s"
                            + " | Action: REQUIRE EXPLICIT BREAK ACCEPTANCE"
                        );
                        return;
                    }

                    recentStructureLocationBlockActive = false;
                    recentStructureLocationBlockUtc = DateTime.MinValue;

                    PrintBotMessage(
                        "STRUCTURE LOCATION REVALIDATED"
                        + " | Side: " + (isLong ? "LONG" : "SHORT")
                        + " | FormerBarrier: "
                        + recentStructureLocationBlockReference
                        + " @ " + recentStructureLocationBlockLevel.ToString("0.00")
                        + " | " + locationRevalidationSummary
                        + " | Action: ENTRY AUTHORITY RESTORED"
                    );
                }
                else if (locationFenceAgeSeconds > StructureLocationBlockFenceSeconds)
                {
                    recentStructureLocationBlockActive = false;
                    recentStructureLocationBlockUtc = DateTime.MinValue;
                }
            }

            double riskPerContract;
            double configuredRisk;

            // =====================================================
            // V1.7.01 - ADAPTIVE BREATHING + FIXED DOLLAR RISK
            // =====================================================
            // Decide stop distance BEFORE submission. The user's configured
            // stop remains the floor. If structure/context needs more room,
            // widen the stop for this trade only and reduce quantity so the
            // ORIGINAL configured dollar risk is not increased.
            double fixedEntryRiskBudget;
            string adaptiveStopReason;

            int effectiveEntryStopTicks =
                GetAdaptiveEntryStopTicks(
                    isLong,
                    instrument,
                    locationSignalPrice,
                    activeStopTicks,
                    activeContracts,
                    activeDollarRiskCap,
                    out fixedEntryRiskBudget,
                    out adaptiveStopReason
                );

            double sizingRiskBudget =
                fixedEntryRiskBudget > 0
                    ? fixedEntryRiskBudget
                    : activeDollarRiskCap;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    effectiveEntryStopTicks,
                    sizingRiskBudget,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DOLLAR RISK CAP"
                    + " | ConfigQty: "
                    + activeContracts
                    + " | SL: "
                    + effectiveEntryStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | RiskBudget: "
                    + sizingRiskBudget.ToString("$0.00")
                );

                return;
            }

            if (
                effectiveEntryContracts <
                    activeContracts
            )
            {
                PrintBotMessage(
                    "AUTO RISK SIZING"
                    + " | ConfigQty: "
                    + activeContracts
                    + " -> EffectiveQty: "
                    + effectiveEntryContracts
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | ConfigRisk: "
                    + configuredRisk.ToString("$0.00")
                    + " | RiskBudget: "
                    + sizingRiskBudget.ToString("$0.00")
                );
            }

            if (
                effectiveEntryStopTicks >
                    activeStopTicks
            )
            {
                PrintBotMessage(
                    "ADAPTIVE BREATHING"
                    + " | Side: "
                    + (isLong ? "LONG" : "SHORT")
                    + " | Qty: "
                    + activeContracts
                    + " -> "
                    + effectiveEntryContracts
                    + " | SL: "
                    + activeStopTicks
                    + "t -> "
                    + effectiveEntryStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | FixedRiskBudget: "
                    + sizingRiskBudget.ToString("$0.00")
                    + " | "
                    + adaptiveStopReason
                );
            }

            // V1.6.40 - DAILY PROFIT FLOOR PRE-ENTRY RISK GATE.
            // Do not allow a new trade whose initial stop risk can consume
            // an already protected portion of the day's realized profit.
            double floorRealizedPnL;
            double floorProtectedPnL;
            double floorAvailableGiveback;
            double floorSafeRiskBudget;

            int floorLimitedContracts =
                ApplyDailyProfitFloorEntryRiskBudget(
                    effectiveEntryContracts,
                    riskPerContract,
                    out floorRealizedPnL,
                    out floorProtectedPnL,
                    out floorAvailableGiveback,
                    out floorSafeRiskBudget
                );

            if (floorLimitedContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DAILY PROFIT FLOOR RISK"
                    + " | Realized: "
                    + floorRealizedPnL.ToString("$0.00")
                    + " | Protected: "
                    + floorProtectedPnL.ToString("$0.00")
                    + " | AvailableGiveback: "
                    + floorAvailableGiveback.ToString("$0.00")
                    + " | SafeRiskBudget: "
                    + floorSafeRiskBudget.ToString("$0.00")
                    + " | ProposedRisk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + " | Action: PRESERVE PROFIT"
                );

                return;
            }

            if (floorLimitedContracts < effectiveEntryContracts)
            {
                PrintBotMessage(
                    "DAILY PROFIT FLOOR AUTO RISK SIZING"
                    + " | Qty: "
                    + effectiveEntryContracts
                    + " -> "
                    + floorLimitedContracts
                    + " | Realized: "
                    + floorRealizedPnL.ToString("$0.00")
                    + " | Protected: "
                    + floorProtectedPnL.ToString("$0.00")
                    + " | AvailableGiveback: "
                    + floorAvailableGiveback.ToString("$0.00")
                    + " | SafeRiskBudget: "
                    + floorSafeRiskBudget.ToString("$0.00")
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                );

                effectiveEntryContracts =
                    floorLimitedContracts;
            }

            // V1.6.75 - REMAINING DAILY LOSS RISK CAP.
            // Final quantity may not expose more initial stop risk than the
            // remaining distance to the configured daily-loss boundary.
            double dailyRiskRealizedPnL;
            double dailyRiskLossLimit;
            double remainingDailyRiskBudget;

            int dailyLossLimitedContracts =
                ApplyRemainingDailyLossEntryRiskBudget(
                    effectiveEntryContracts,
                    riskPerContract,
                    out dailyRiskRealizedPnL,
                    out dailyRiskLossLimit,
                    out remainingDailyRiskBudget
                );

            if (dailyLossLimitedContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - REMAINING DAILY RISK"
                    + " | Realized: " + dailyRiskRealizedPnL.ToString("$0.00")
                    + " | DailyLoss: " + dailyRiskLossLimit.ToString("$0.00")
                    + " | RemainingBudget: " + remainingDailyRiskBudget.ToString("$0.00")
                    + " | Risk/Contract: " + riskPerContract.ToString("$0.00")
                );
                return;
            }

            if (dailyLossLimitedContracts < effectiveEntryContracts)
            {
                PrintBotMessage(
                    "REMAINING DAILY RISK AUTO SIZING"
                    + " | Qty: " + effectiveEntryContracts
                    + " -> " + dailyLossLimitedContracts
                    + " | Realized: " + dailyRiskRealizedPnL.ToString("$0.00")
                    + " | DailyLoss: " + dailyRiskLossLimit.ToString("$0.00")
                    + " | RemainingBudget: " + remainingDailyRiskBudget.ToString("$0.00")
                    + " | Risk/Contract: " + riskPerContract.ToString("$0.00")
                );

                effectiveEntryContracts = dailyLossLimitedContracts;
            }

            FinalEntryDecision finalAuthority =
                EvaluateFinalEntryAuthority(
                    isLong,
                    signalNyTime,
                    entryStrategy,
                    entryRoute,
                    manualTest
                );

            PrintBotMessage(
                "FINAL ENTRY AUTHORITY"
                + " | Strategy: " + finalAuthority.Strategy
                + " | Route: " + finalAuthority.Route
                + " | Decision: " + finalAuthority.Decision
                + " | Side: " + (isLong ? "LONG" : "SHORT")
                + " | L2: " + GetLevel2AuthorityContext(isLong)
                + " | Reason: " + finalAuthority.Reason
                + (
                    string.IsNullOrWhiteSpace(entryRouteReason)
                        ? string.Empty
                        : " | Candidate: " + entryRouteReason
                  )
            );

            if (!string.IsNullOrWhiteSpace(pendingShadowSignalId))
            {
                UpdateShadowSignalDecision(
                    pendingShadowSignalId,
                    finalAuthority.Decision,
                    "STRATEGY=" + finalAuthority.Strategy
                    + " | ROUTE=" + finalAuthority.Route
                    + " | " + finalAuthority.Reason
                );
            }

            if (!finalAuthority.Execute)
                return;

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            openingEntry &&
                            openingTradeTakenToday
                        ) ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    if (
                        !manualTest &&
                        pendingLiquidityBreakActive &&
                        pendingLiquidityBreakIsLong == isLong
                    )
                    {
                        pendingLiquidityBreakActive = false;
                        pendingLiquidityBreakCrossedNy = DateTime.MinValue;
                    }

                    pendingEntrySession =
                        signalSession;

                    pendingEntryRequestedQuantity =
                        effectiveEntryContracts;

                    pendingEntryEffectiveStopTicks =
                        effectiveEntryStopTicks;

                    pendingEntryIsManualTest =
                        manualTest;

                    pendingEntryIsOpening =
                        openingEntry;

                    pendingEntryRoute =
                        finalAuthority.Route ?? string.Empty;

                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence =
                        manualTest
                            ? 0
                            : latestSetupConfidence;

                    pendingTradeSetupQuality =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupQuality
                                )
                                    ? "ANALYZING"
                                    : latestSetupQuality
                              );

                    pendingTradeSetupTiming =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupTiming
                                )
                                    ? "ANALYZING"
                                    : latestSetupTiming
                              );

                    pendingTradeManipulationState =
                        manualTest
                            ? "NONE"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestManipulationState
                                )
                                    ? "NONE"
                                    : latestManipulationState
                              );

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    if (!manualTest)
                    {
                        lastExecutedSignalBar =
                            signalBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;
                    }
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                // =====================================================
                // V1.7.03 - SHARED MARKET BRAIN PUBLISH
                // =====================================================
                // Publish ONLY after this profile has passed the COMPLETE
                // existing JJ market logic AND its Account.Submit call was sent.
                // The first valid EXECUTE for the instrument becomes the single
                // authoritative signal that all other profiles may obey.
                if (!manualTest)
                {
                    JJBotSharedMarketBrain.TryPublishExecute(
                        new JJBotSharedMarketSignal
                        {
                            InstrumentName = instrument.FullName,
                            SourceProfileId = platformProfileId,
                            IsLong = isLong,
                            SignalBarTime = signalBarTime,
                            Strategy = finalAuthority.Strategy ?? entryStrategy,
                            Route = finalAuthority.Route ?? entryRoute,
                            RouteReason = entryRouteReason ?? finalAuthority.Reason,
                            StructureSetupKey = structureSetupKey ?? string.Empty,
                            OpeningEntry = openingEntry
                        }
                    );
                }

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + effectiveEntryContracts
                    + (
                        effectiveEntryContracts != activeContracts
                            ? " (Configured "
                                + activeContracts
                                + ")"
                            : string.Empty
                      )
                    + " | Risk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + "/"
                    + activeDollarRiskCap.ToString("$0.00")
                    + " | "
                    + instrument.FullName
                    + (
                        openingEntry
                            ? " | Setup: OPENING"
                            : string.Empty
                    )
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingEntryRequestedQuantity =
                        0;

                    pendingEntryIsManualTest =
                        false;

                    pendingEntryIsOpening =
                        false;

                    pendingEntryEffectiveStopTicks =
                        0;

                    pendingEntryIsPremarket =
                        false;

                    pendingTradeSetupConfidence =
                        0;

                    pendingTradeSetupQuality =
                        string.Empty;

                    pendingTradeSetupTiming =
                        string.Empty;

                    pendingTradeManipulationState =
                        string.Empty;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }
        // =========================================================
        // V1.7.03 - SHARED MARKET BRAIN FOLLOWER EXECUTION
        // =========================================================
        // IMPORTANT:
        // This method DOES NOT re-run Momentum/R20/Structure/VWAP/Level2/
        // Absorption/Recent-Extreme/Reversal/Final-Entry logic.
        // That decision was already made once and published by the shared
        // per-instrument market brain.
        //
        // Followers keep ONLY their own account authority:
        // license, enabled/running state, direction permission, session,
        // session trade count, Daily Target/Loss, recovery/flat state,
        // Adaptive SL, Dollar Risk Cap, profit-floor risk and live qty.
        private void OnSharedMarketBrainExecuteSignal(
            JJBotSharedMarketSignal signal)
        {
            if (signal == null || !engineWindowAlive)
                return;

            try
            {
                if (!Dispatcher.CheckAccess())
                {
                    Dispatcher.BeginInvoke(
                        new Action(() =>
                        {
                            OnSharedMarketBrainExecuteSignal(signal);
                        })
                    );
                    return;
                }
            }
            catch
            {
                return;
            }

            if (!botRunning || selectedInstrument == null)
                return;

            if (!string.Equals(
                selectedInstrument.FullName,
                signal.InstrumentName,
                StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            if (string.Equals(
                platformProfileId,
                signal.SourceProfileId,
                StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            double ageSeconds =
                (DateTime.UtcNow - signal.PublishedUtc).TotalSeconds;

            if (ageSeconds < 0 || ageSeconds > 2.0)
                return;

            PrintBotMessage(
                "SHARED BRAIN FOLLOW"
                + " | Signal: " + signal.SignalId
                + " | SourceDecision: " + (signal.IsLong ? "LONG" : "SHORT")
                + " EXECUTE"
                + " | Strategy: " + (signal.Strategy ?? "MOMENTUM")
                + " | Route: " + (signal.Route ?? "DIRECT")
                + " | Action: ACCOUNT AUTHORITY ONLY"
            );

            TrySubmitSharedBrainFollowerEntry(signal);
        }

        private void TrySubmitSharedBrainFollowerEntry(
            JJBotSharedMarketSignal signal)
        {
            if (signal == null || !botRunning)
                return;

            if (!IsBotCloudLicenseValid())
            {
                PrintBotMessage(
                    "SHARED BRAIN BLOCK - BOT LICENSE EXPIRED"
                );
                return;
            }

            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (account == null || instrument == null)
                return;

            if (!string.Equals(
                instrument.FullName,
                signal.InstrumentName,
                StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            bool isLong = signal.IsLong;

            // Per-profile user direction remains an account permission,
            // not a second market opinion.
            if (
                string.Equals(activeDirection, "LONG", StringComparison.OrdinalIgnoreCase) &&
                !isLong
            )
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: PROFILE DIRECTION LONG ONLY"
                );
                return;
            }

            if (
                string.Equals(activeDirection, "SHORT", StringComparison.OrdinalIgnoreCase) &&
                isLong
            )
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: PROFILE DIRECTION SHORT ONLY"
                );
                return;
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(signal.SignalBarTime);

            string signalSession =
                GetBotSessionWindow(signalNyTime);

            if (signalSession == "OUTSIDE")
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: OUTSIDE ACTIVE SESSION"
                );
                return;
            }

            if (IsPremarketExecutionGuardActive(GetCurrentNewYorkTime()))
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: PREMARKET 03:15 EXECUTION GUARD"
                );
                return;
            }

            if (string.Equals(
                signalSession,
                "PREMARKET",
                StringComparison.OrdinalIgnoreCase))
            {
                double asiaLossNet;
                if (IsPremarketSuppressedByAsiaLoss(out asiaLossNet))
                {
                    PrintBotMessage(
                        "SHARED BRAIN ACCOUNT BLOCK"
                        + " | Reason: ASIA LOSS / PREMARKET OBSERVE ONLY"
                        + " | AsiaNet: " + asiaLossNet.ToString("$0.00")
                    );
                    return;
                }
            }

            if (IsSessionTradeLimitReached(signalSession))
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: " + signalSession + " SESSION TRADE LIMIT"
                    + " | " + GetSessionTradeCount(signalSession)
                    + "/" + GetSessionTradeLimit(signalSession)
                );
                return;
            }

            double totalBotPnL;
            bool alreadyPending;

            lock (executionStateLock)
            {
                totalBotPnL = botDailyPnL + botUnrealizedPnL;
                alreadyPending = entryPending;
            }

            if (alreadyPending)
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK | Reason: ENTRY ALREADY PENDING"
                );
                return;
            }

            if (
                persistentDailyLocked ||
                totalBotPnL >= activeDailyTarget ||
                totalBotPnL <= -activeDailyLoss
            )
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: DAILY CAPITAL LIMIT"
                    + " | PnL: " + totalBotPnL.ToString("$0.00")
                );
                return;
            }

            if (positionRecoveryPending)
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: POSITION RECOVERY PENDING"
                );
                return;
            }

            if (!IsSelectedInstrumentFlat())
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK"
                    + " | Reason: POSITION IS NOT FLAT"
                );
                return;
            }

            // Do NOT evaluate local Structure Location / Level2 / Momentum /
            // Final Entry Authority here. The shared brain already decided.
            double entryPriceProxy = GetEntryLocationPriceProxy(isLong);

            double riskPerContract;
            double configuredRisk;
            double fixedEntryRiskBudget;
            string adaptiveStopReason;

            int effectiveEntryStopTicks =
                GetAdaptiveEntryStopTicks(
                    isLong,
                    instrument,
                    entryPriceProxy,
                    activeStopTicks,
                    activeContracts,
                    activeDollarRiskCap,
                    out fixedEntryRiskBudget,
                    out adaptiveStopReason
                );

            double sizingRiskBudget =
                fixedEntryRiskBudget > 0
                    ? fixedEntryRiskBudget
                    : activeDollarRiskCap;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    effectiveEntryStopTicks,
                    sizingRiskBudget,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK - DOLLAR RISK CAP"
                    + " | Risk/Contract: " + riskPerContract.ToString("$0.00")
                    + " | Budget: " + sizingRiskBudget.ToString("$0.00")
                );
                return;
            }

            double floorRealizedPnL;
            double floorProtectedPnL;
            double floorAvailableGiveback;
            double floorSafeRiskBudget;

            int floorLimitedContracts =
                ApplyDailyProfitFloorEntryRiskBudget(
                    effectiveEntryContracts,
                    riskPerContract,
                    out floorRealizedPnL,
                    out floorProtectedPnL,
                    out floorAvailableGiveback,
                    out floorSafeRiskBudget
                );

            if (floorLimitedContracts <= 0)
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK - DAILY PROFIT FLOOR RISK"
                );
                return;
            }

            effectiveEntryContracts =
                Math.Min(effectiveEntryContracts, floorLimitedContracts);

            double dailyRiskRealizedPnL;
            double dailyRiskLossLimit;
            double remainingDailyRiskBudget;

            int dailyLossLimitedContracts =
                ApplyRemainingDailyLossEntryRiskBudget(
                    effectiveEntryContracts,
                    riskPerContract,
                    out dailyRiskRealizedPnL,
                    out dailyRiskLossLimit,
                    out remainingDailyRiskBudget
                );

            if (dailyLossLimitedContracts <= 0)
            {
                PrintBotMessage(
                    "SHARED BRAIN ACCOUNT BLOCK - REMAINING DAILY RISK"
                    + " | Remaining: " + remainingDailyRiskBudget.ToString("$0.00")
                    + " | Risk/Contract: " + riskPerContract.ToString("$0.00")
                );
                return;
            }

            effectiveEntryContracts =
                Math.Min(effectiveEntryContracts, dailyLossLimitedContracts);

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    double latestTotalPnL = botDailyPnL + botUnrealizedPnL;

                    if (
                        entryPending ||
                        persistentDailyLocked ||
                        latestTotalPnL >= activeDailyTarget ||
                        latestTotalPnL <= -activeDailyLoss ||
                        !IsSelectedInstrumentFlat()
                    )
                    {
                        return;
                    }

                    entryOrder = newEntryOrder;
                    entryPending = true;

                    pendingEntrySession = signalSession;
                    pendingEntryRequestedQuantity = effectiveEntryContracts;
                    pendingEntryEffectiveStopTicks = effectiveEntryStopTicks;
                    pendingEntryIsManualTest = false;
                    pendingEntryIsOpening = signal.OpeningEntry;
                    pendingEntryRoute = signal.Route ?? "DIRECT";
                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence = latestSetupConfidence;
                    pendingTradeSetupQuality =
                        string.IsNullOrWhiteSpace(latestSetupQuality)
                            ? "SHARED BRAIN"
                            : latestSetupQuality;
                    pendingTradeSetupTiming =
                        string.IsNullOrWhiteSpace(latestSetupTiming)
                            ? "SHARED BRAIN"
                            : latestSetupTiming;
                    pendingTradeManipulationState =
                        string.IsNullOrWhiteSpace(latestManipulationState)
                            ? "NONE"
                            : latestManipulationState;

                    pendingStructureSetupKey =
                        signal.StructureSetupKey ?? string.Empty;
                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(pendingStructureSetupKey);

                    executionStatus = "SHARED BRAIN ENTRY SUBMITTED";
                    lastExecutedSignalBar = signal.SignalBarTime;
                    lastReentryBlockLogKey = string.Empty;
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                account.Submit(new[] { newEntryOrder });

                PrintBotMessage(
                    "SHARED BRAIN ENTRY SUBMITTED"
                    + " | Signal: " + signal.SignalId
                    + " | " + (isLong ? "LONG" : "SHORT")
                    + " | Qty: " + effectiveEntryContracts
                    + " | SL: " + effectiveEntryStopTicks + "t"
                    + " | Risk: "
                    + (effectiveEntryContracts * riskPerContract).ToString("$0.00")
                    + " | SourceProfile: " + signal.SourceProfileId
                    + " | MarketDecision: SHARED"
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending = false;
                    entryOrder = null;
                    pendingEntryRequestedQuantity = 0;
                    pendingEntryEffectiveStopTicks = 0;
                    pendingEntryIsManualTest = false;
                    pendingEntryIsOpening = false;
                    pendingEntryIsPremarket = false;
                    pendingEntryRoute = string.Empty;
                    pendingStructureSetupKey = string.Empty;
                    pendingStructureConfirmTime = DateTime.MinValue;
                    executionStatus = "SHARED BRAIN ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "SHARED BRAIN ENTRY ERROR: " + ex.Message
                );
            }
        }

        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int tradeStopTicks =
                    GetActiveTradeStopTicks();

                int dynamicTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                int effectiveTargetTicks =
                    GetStructureAwareTargetTicks(
                        marketPosition,
                        fillPrice,
                        tickSize,
                        dynamicTargetTicks
                    );

                int minimumRiskRewardTicks =
                    Math.Max(
                        DynamicTargetMinTicks,
                        (int)Math.Ceiling(
                            tradeStopTicks *
                            DynamicTargetMinimumRiskReward
                        )
                    );

                if (
                    effectiveTargetTicks <
                        minimumRiskRewardTicks
                )
                {
                    // V1.6.37 - structural authority wins. Never manufacture
                    // target room after a fill by pushing TP through a known
                    // barrier. The pre-entry guard should normally prevent this;
                    // this branch protects against fast price movement/fill races.
                    PrintBotMessage(
                        "TARGET RR FLOOR NOT APPLIED - STRUCTURE AUTHORITY"
                        + " | StructureTarget: "
                        + effectiveTargetTicks
                        + "t"
                        + " | RR Floor: "
                        + minimumRiskRewardTicks
                        + "t"
                        + " | SL: "
                        + tradeStopTicks
                        + "t"
                        + " | MinRR: 1:"
                        + DynamicTargetMinimumRiskReward
                            .ToString("0.00")
                        + " | Action: KEEP TP BEFORE BARRIER"
                    );
                }

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - tradeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + tradeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    GetProfileOrderPrefix()
                    + "JJ_OCO_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        GetProfileOrderName("JJ_STOP"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        GetProfileOrderName("JJ_TARGET"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }
        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }
        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }
        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT EXECUTION ENGINE
    // Stage 9 structural extraction only.
    //
    // Existing entry submission and protective bracket creation
    // are moved exactly as-is. No order type, price, quantity,
    // OCO, risk, timing, or safety behavior is changed.
    // =========================================================
    public partial class JJBotWindow
    {
       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null,
            bool openingEntry = false,
            bool highConvictionMomentum = false)
        {
            if (!botRunning)
                return;

            // FINAL LICENSE GATE.
            // This is intentionally inside the execution engine so every
            // automatic path and manual test is protected even if another
            // caller bypasses the UI Start button.
            if (!IsBotCloudLicenseValid())
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - BOT LICENSE EXPIRED"
                );

                return;
            }

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            if (
                !IsSimulationAccount(
                    account
                )
            )
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - ACCOUNT IS NOT SIM."
                );

                return;
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // Automatic entries MUST obey NY session.
            // Manual SIM tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            // =====================================================
            // V1.6.24 - OPENING SAFETY HARDENING
            // =====================================================
            // These are FINAL execution gates. They live here so every
            // automatic path (Momentum / Opening / Structure) is protected
            // even if an upstream signal engine temporarily resolves AUTO.
            if (!manualTest)
            {
                int signalTimeInt =
                    ToTimeInt(signalNyTime);

                // -------------------------------------------------
                // 1) OPENING STABILITY GUARD
                // -------------------------------------------------
                // Do not trade the first 60 seconds after 09:30 ET.
                // The fast Range engine may flip LONG/SHORT/NONE several
                // times during price discovery; analysis continues, execution
                // waits until the first minute is complete.
                DateTime openingStartNy =
                    signalNyTime.Date
                        .AddHours(9)
                        .AddMinutes(30);

                double secondsFromOpen =
                    (
                        signalNyTime -
                        openingStartNy
                    ).TotalSeconds;

                if (
                    secondsFromOpen >= 0 &&
                    secondsFromOpen <
                        OpeningStabilityGuardSeconds
                )
                {
                    string openingStabilityKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT");

                    if (
                        openingStabilityKey !=
                            lastOpeningStabilityBlockLogKey
                    )
                    {
                        lastOpeningStabilityBlockLogKey =
                            openingStabilityKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - OPENING STABILITY GUARD"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | OpenAge: "
                            + Math.Max(
                                0,
                                (int)Math.Floor(
                                    secondsFromOpen
                                )
                              )
                            + "s/"
                            + OpeningStabilityGuardSeconds
                            + "s"
                            + " | Action: BUILD OPENING DIRECTION"
                        );
                    }

                    return;
                }

                bool m5BullishSnapshot;
                bool m5BearishSnapshot;
                string m5StructureSnapshot;

                lock (marketContextLock)
                {
                    m5BullishSnapshot =
                        latestM5BullishTrend;

                    m5BearishSnapshot =
                        latestM5BearishTrend;

                    m5StructureSnapshot =
                        latestM5StructureState;
                }

                bool trendOpposesEntry =
                    (
                        isLong &&
                        m5BearishSnapshot
                    ) ||
                    (
                        !isLong &&
                        m5BullishSnapshot
                    );

                bool structureAlignedForEntry =
                    IsStructureAlignedForSetup(
                        isLong,
                        m5StructureSnapshot
                    );

                bool insideOpeningSafetyWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningCounterTrendVetoEnd;

                // -------------------------------------------------
                // 2) COUNTER-TREND OPENING VETO
                // -------------------------------------------------
                // Strong R20 / aggressive expansion may not override an
                // opposite confirmed M5 trend while structure is still
                // WAITING. A real BOS/CHOCH in the entry direction must
                // appear first.
                if (
                    insideOpeningSafetyWindow &&
                    trendOpposesEntry &&
                    !structureAlignedForEntry
                )
                {
                    string counterTrendKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|"
                        + (m5StructureSnapshot ?? "NONE");

                    if (
                        counterTrendKey !=
                            lastOpeningCounterTrendBlockLogKey
                    )
                    {
                        lastOpeningCounterTrendBlockLogKey =
                            counterTrendKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER-TREND OPENING VETO"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | M5 Trend: "
                            + (
                                m5BullishSnapshot
                                    ? "BULLISH"
                                    : m5BearishSnapshot
                                        ? "BEARISH"
                                        : "NEUTRAL"
                              )
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | Action: WAIT BOS/CHOCH"
                        );
                    }

                    return;
                }

                // -------------------------------------------------
                // 3) SAME-SETUP REENTRY LOCK AFTER LOSS
                // -------------------------------------------------
                // Existing code allows a same-side loss to rearm after the
                // cooldown when high-conviction momentum returns. During
                // the opening window that is too permissive. After a loss,
                // the same side must produce fresh aligned M5 structure.
                string requestedSide =
                    isLong
                        ? "LONG"
                        : "SHORT";

                bool sameSideLoss =
                    lastAutomaticTradeExitWasLoss &&
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedSide,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool insideSameSetupRearmWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningSameSideLossStructureRearmEnd;

                bool freshM5ContextAfterLoss =
                    latestM5DecisionNyTime != DateTime.MinValue &&
                    latestM5DecisionNyTime >
                        lastAutomaticTradeExitNy;

                if (
                    sameSideLoss &&
                    insideSameSetupRearmWindow &&
                    (
                        !structureAlignedForEntry ||
                        !freshM5ContextAfterLoss
                    )
                )
                {
                    string sameSetupKey =
                        lastAutomaticTradeExitNy
                            .ToString("yyyyMMddHHmmss")
                        + "|"
                        + requestedSide;

                    if (
                        sameSetupKey !=
                            lastOpeningSameSetupBlockLogKey
                    )
                    {
                        lastOpeningSameSetupBlockLogKey =
                            sameSetupKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - SAME-SETUP LOSS REARM"
                            + " | Side: "
                            + requestedSide
                            + " | PriorLoss: YES"
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | FreshM5AfterLoss: "
                            + freshM5ContextAfterLoss
                            + " | Action: REQUIRE FRESH M5 + BOS/CHOCH"
                        );
                    }

                    return;
                }
            }

            // V1.6.20 - UNIVERSAL DIRECTIONAL SAFETY GATE.
            // Every automatic entry path must pass this final check.
            if (!manualTest)
            {
                string directionalBlockReason;

                if (
                    IsDirectionalSafetyBlocked(
                        isLong,
                        out directionalBlockReason
                    )
                )
                {
                    string pressureBlockKey =
                        "DIRECTIONAL_PRESSURE|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|" + latestDirectionalPressure
                        + "|" + latestDirectionalLongPressureScore
                        + "/" + latestDirectionalShortPressureScore;

                    if (
                        pressureBlockKey !=
                            lastDirectionalSafetyBlockKey
                    )
                    {
                        lastDirectionalSafetyBlockKey =
                            pressureBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER PRESSURE"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | " + directionalBlockReason
                            + " | Action: TREAT AS PULLBACK / WAIT RESUMPTION"
                        );
                    }

                    return;
                }
            }

            bool momentumEntry =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(
                    structureSetupKey
                );

            // =====================================================
            // V1.6.25 - FINAL LEARNING EXECUTION VETO
            // =====================================================
            // Upstream UI/scoring can never bypass a negative exact learning
            // bucket. Prefer the context captured by the signal source. For
            // momentum, derive the exact R20 key when no pending label exists.
            if (!manualTest)
            {
                string executionLearningContext =
                    pendingLearningStructure;

                if (
                    string.IsNullOrWhiteSpace(
                        executionLearningContext
                    ) &&
                    momentumEntry
                )
                {
                    int executionMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    executionLearningContext =
                        "R20 MOMENTUM "
                        + executionMomentumScore
                        + "/5";
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        executionLearningContext
                    )
                )
                {
                    string executionLearningReason;

                    bool executionLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            executionLearningContext,
                            out executionLearningReason
                        );

                    if (!executionLearningAllowed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEARNING"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | Setup: "
                            + executionLearningContext
                            + " | "
                            + executionLearningReason
                        );

                        return;
                    }
                }

                // =================================================
                // V1.6.27 - QUALITY/EXECUTION LEARNING CONSISTENCY
                // =================================================
                // The Nasdaq quality layer evaluates the generic R20
                // score bucket ("R20 MOMENTUM N/5").  Previously an
                // aggressive/extreme exact bucket could pass while that
                // generic bucket was already BLOCK, producing the
                // contradictory log:
                //     SETUP QUALITY ... Learning BLOCK
                //     SIM ENTRY SUBMITTED
                //
                // For automatic Momentum entries, BOTH the exact setup
                // bucket and the generic R20 quality bucket must allow.
                if (momentumEntry)
                {
                    int genericMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string genericLearningContext =
                        "R20 MOMENTUM "
                        + genericMomentumScore
                        + "/5";

                    string genericLearningReason;

                    bool genericLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            genericLearningContext,
                            out genericLearningReason
                        );

                    if (!genericLearningAllowed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEARNING QUALITY BUCKET"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | Setup: "
                            + genericLearningContext
                            + " | "
                            + genericLearningReason
                        );

                        return;
                    }
                }
            }

            // V1.6.23 Phase 11 - final quality gate for MOMENTUM entries.
            // Opening and confirmed structure setups keep their own engines.
            if (
                momentumEntry &&
                !IsOpeningEntryWindow(signalNyTime)
            )
            {
                string entryQualityReason;

                if (
                    IsMomentumEntryQualityBlocked(
                        isLong,
                        highConvictionMomentum,
                        out entryQualityReason
                    )
                )
                {
                    string qualityBlockKey =
                        "ENTRY_QUALITY|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|" + latestMarketRegime
                        + "|" + latestMarketRegimeDirection
                        + "|" + latestRangeLongScore
                        + "/" + latestRangeShortScore;

                    if (
                        qualityBlockKey !=
                            lastEntryQualityBlockKey
                    )
                    {
                        lastEntryQualityBlockKey =
                            qualityBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - QUALITY / REGIME"
                            + " | " + entryQualityReason
                            + " | Action: WAIT CLEAN CONTINUATION"
                        );
                    }

                    return;
                }
            }

            if (!manualTest)
            {
                int lateEntryAgeSeconds;
                int lateEntryMaxSeconds;

                if (
                    IsLateAutomaticEntry(
                        signalNyTime,
                        momentumEntry,
                        openingEntry,
                        highConvictionMomentum,
                        out lateEntryAgeSeconds,
                        out lateEntryMaxSeconds
                    )
                )
                {
                    string lateEntryKey =
                        signalBarTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + (
                            openingEntry
                                ? "OPENING"
                                : momentumEntry
                                    ? "MOMENTUM"
                                    : "STRUCTURE"
                          );

                    if (
                        lateEntryKey !=
                            lastLateEntryBlockLogKey
                    )
                    {
                        lastLateEntryBlockLogKey =
                            lateEntryKey;

                        PrintBotMessage(
                            "SKIP TRADE - LATE ENTRY"
                            + " | Type: "
                            + (
                                openingEntry
                                    ? "OPENING"
                                    : momentumEntry
                                        ? "MOMENTUM"
                                        : "STRUCTURE"
                              )
                            + " | Age: "
                            + lateEntryAgeSeconds
                            + "s"
                            + " | Max: "
                            + lateEntryMaxSeconds
                            + "s"
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | StrategyClock: "
                            + GetCurrentNewYorkTime()
                                .ToString(
                                    "HH:mm:ss"
                                )
                            + " ET"
                            + (
                                momentumEntry
                                    ? " | HighConviction: "
                                        + (highConvictionMomentum ? "YES" : "NO")
                                    : string.Empty
                              )
                            + " | Action: NO CHASE"
                        );
                    }

                    return;
                }

                string reentryReason;

                if (
                    IsAutomaticReentryBlocked(
                        isLong,
                        signalBarTime,
                        momentumEntry,
                        highConvictionMomentum,
                        out reentryReason
                    )
                )
                {
                    // V1.6.6 - one reentry-block log per cooldown cycle
                    // and side. Do not create a new key every second as the
                    // remaining cooldown text changes.
                    string reentryBlockKey =
                        "REENTRY|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + lastAutomaticTradeExitNy.ToString(
                            "yyyyMMddHHmmss"
                        );

                    if (
                        reentryBlockKey !=
                            lastReentryBlockLogKey
                    )
                    {
                        lastReentryBlockLogKey =
                            reentryBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - REENTRY REARM"
                            + " | "
                            + reentryReason
                            + " | Side: "
                            + (
                                isLong
                                    ? "LONG"
                                    : "SHORT"
                              )
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                        );
                    }

                    return;
                }
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                // V1.6.6 - session limit is a persistent state, not a
                // per-Range-bar event. Log it once until the state changes.
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + GetSessionTradeCount(
                        signalSession
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        signalSession
                    );

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + GetSessionTradeLimit(
                            signalSession
                        )
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !manualTest &&
                positionRecoveryPending
            )
            {
                string recoveryBlockedKey =
                    "POSITION_RECOVERY_PENDING|"
                    + signalBarTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (
                    recoveryBlockedKey !=
                        lastRangeBlockedLogKey
                )
                {
                    lastRangeBlockedLogKey =
                        recoveryBlockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION RECOVERY PENDING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | Waiting for NinjaTrader account sync."
                    );
                }

                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | SignalBar: "
                        + ConvertToNewYorkTime(
                            signalBarTime
                          ).ToString(
                            "HH:mm:ss"
                          )
                        + " ET"
                    );
                }

                return;
            }

            double riskPerContract;
            double configuredRisk;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    activeStopTicks,
                    activeDollarRiskCap,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DOLLAR RISK CAP"
                    + " | ConfigQty: "
                    + activeContracts
                    + " | SL: "
                    + activeStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );

                return;
            }

            if (
                effectiveEntryContracts <
                    activeContracts
            )
            {
                PrintBotMessage(
                    "AUTO RISK SIZING"
                    + " | ConfigQty: "
                    + activeContracts
                    + " -> EffectiveQty: "
                    + effectiveEntryContracts
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | ConfigRisk: "
                    + configuredRisk.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );
            }

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            openingEntry &&
                            openingTradeTakenToday
                        ) ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    pendingEntrySession =
                        signalSession;

                    pendingEntryRequestedQuantity =
                        effectiveEntryContracts;

                    pendingEntryIsManualTest =
                        manualTest;

                    pendingEntryIsOpening =
                        openingEntry;

                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence =
                        manualTest
                            ? 0
                            : latestSetupConfidence;

                    pendingTradeSetupQuality =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupQuality
                                )
                                    ? "ANALYZING"
                                    : latestSetupQuality
                              );

                    pendingTradeSetupTiming =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupTiming
                                )
                                    ? "ANALYZING"
                                    : latestSetupTiming
                              );

                    pendingTradeManipulationState =
                        manualTest
                            ? "NONE"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestManipulationState
                                )
                                    ? "NONE"
                                    : latestManipulationState
                              );

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    if (!manualTest)
                    {
                        lastExecutedSignalBar =
                            signalBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;
                    }
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + effectiveEntryContracts
                    + (
                        effectiveEntryContracts != activeContracts
                            ? " (Configured "
                                + activeContracts
                                + ")"
                            : string.Empty
                      )
                    + " | Risk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + "/"
                    + activeDollarRiskCap.ToString("$0.00")
                    + " | "
                    + instrument.FullName
                    + (
                        openingEntry
                            ? " | Setup: OPENING"
                            : string.Empty
                    )
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingEntryRequestedQuantity =
                        0;

                    pendingEntryIsManualTest =
                        false;

                    pendingEntryIsOpening =
                        false;

                    pendingEntryIsPremarket =
                        false;

                    pendingTradeSetupConfidence =
                        0;

                    pendingTradeSetupQuality =
                        string.Empty;

                    pendingTradeSetupTiming =
                        string.Empty;

                    pendingTradeManipulationState =
                        string.Empty;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }
        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int effectiveTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    GetProfileOrderPrefix()
                    + "JJ_OCO_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        GetProfileOrderName("JJ_STOP"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        GetProfileOrderName("JJ_TARGET"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }
        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }
        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }
        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

    }
}

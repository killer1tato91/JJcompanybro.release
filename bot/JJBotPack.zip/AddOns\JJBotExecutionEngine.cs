﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT EXECUTION ENGINE
    // Stage 9 structural extraction only.
    //
    // Existing entry submission and protective bracket creation
    // are moved exactly as-is. No order type, price, quantity,
    // OCO, risk, timing, or safety behavior is changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.28 - Debounce repeated identical Learning veto logs.
        private string lastLearningQualityBucketBlockKey = string.Empty;
        private DateTime lastLearningQualityBucketBlockLogUtc = DateTime.MinValue;

        // =====================================================
        // V1.6.32 - FAST OPEN EXTREME CANDIDATE
        // =====================================================
        // This helper intentionally evaluates ONLY the price-action side
        // of the future Fast Open + Level II confirmation path.
        //
        // IMPORTANT: it is NOT wired to bypass an execution guard yet.
        // The actual Level II engine that produces BOOK/TAPE/PERSISTENCE/
        // ABSORPTION telemetry was not part of the supplied source set.
        // We will combine this candidate with that engine's real snapshot
        // before allowing any early entry.
        private bool IsFastOpenExtremePriceCandidate(
            bool isLong)
        {
            int longScore;
            int shortScore;
            bool highBreakout;
            bool lowBreakout;
            double bodyRatio;
            double volumeRatio;
            double emaSlope;

            lock (marketContextLock)
            {
                longScore =
                    latestRangeLongScore;

                shortScore =
                    latestRangeShortScore;

                highBreakout =
                    latestRangeHighBreakout;

                lowBreakout =
                    latestRangeLowBreakout;

                bodyRatio =
                    latestRangeBodyRatio;

                volumeRatio =
                    latestRangeVolumeRatio;

                emaSlope =
                    latestRangeEmaSlope;
            }

            int sameSideScore =
                isLong
                    ? longScore
                    : shortScore;

            int oppositeScore =
                isLong
                    ? shortScore
                    : longScore;

            bool breakoutAligned =
                isLong
                    ? highBreakout
                    : lowBreakout;

            double slopeTicks =
                0;

            if (
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null &&
                selectedInstrument.MasterInstrument.TickSize > 0
            )
            {
                slopeTicks =
                    emaSlope /
                    selectedInstrument.MasterInstrument.TickSize;
            }

            bool slopeAligned =
                isLong
                    ? slopeTicks >=
                        AggressionMinSlopeTicks
                    : slopeTicks <=
                        -AggressionMinSlopeTicks;

            return
                sameSideScore >= 4 &&
                oppositeScore <= 1 &&
                breakoutAligned &&
                bodyRatio >= 0.75 &&
                volumeRatio >= 1.50 &&
                slopeAligned;
        }

        // =====================================================
        // V1.6.30 - STRUCTURE LOCATION / ROOM ENGINE
        // =====================================================
        // Returns true only when a structural barrier is still AHEAD of price
        // and the available room is pathologically small. Broken levels behind
        // price are not treated as resistance/support.
        private bool TryGetEntryLocationRoom(
            bool isLong,
            double signalPrice,
            double tickSize,
            out double roomTicks,
            out string referenceName,
            out double referencePrice)
        {
            roomTicks = 0;
            referenceName = "NONE";
            referencePrice = 0;

            if (signalPrice <= 0 || tickSize <= 0)
                return false;

            double recentHigh;
            double recentLow;

            lock (marketContextLock)
            {
                recentHigh = latestM5RecentStructureHigh;
                recentLow = latestM5RecentStructureLow;
            }

            if (isLong)
            {
                double nearest = double.MaxValue;

                if (recentHigh > signalPrice && recentHigh < nearest)
                {
                    nearest = recentHigh;
                    referenceName = "M5 RECENT HIGH";
                }

                if (openingRangeReady && openingRangeHigh > signalPrice && openingRangeHigh < nearest)
                {
                    nearest = openingRangeHigh;
                    referenceName = "OPENING RANGE HIGH";
                }

                if (premarketRangeReady && premarketRangeHigh > signalPrice && premarketRangeHigh < nearest)
                {
                    nearest = premarketRangeHigh;
                    referenceName = "PREMARKET HIGH";
                }

                if (nearest == double.MaxValue)
                    return false;

                referencePrice = nearest;
                roomTicks = (nearest - signalPrice) / tickSize;
                return roomTicks >= 0;
            }

            double nearestSupport = double.MinValue;

            if (recentLow > 0 && recentLow < signalPrice && recentLow > nearestSupport)
            {
                nearestSupport = recentLow;
                referenceName = "M5 RECENT LOW";
            }

            if (openingRangeReady && openingRangeLow > 0 && openingRangeLow < signalPrice && openingRangeLow > nearestSupport)
            {
                nearestSupport = openingRangeLow;
                referenceName = "OPENING RANGE LOW";
            }

            if (premarketRangeReady && premarketRangeLow > 0 && premarketRangeLow < signalPrice && premarketRangeLow > nearestSupport)
            {
                nearestSupport = premarketRangeLow;
                referenceName = "PREMARKET LOW";
            }

            if (nearestSupport == double.MinValue)
                return false;

            referencePrice = nearestSupport;
            roomTicks = (signalPrice - nearestSupport) / tickSize;
            return roomTicks >= 0;
        }

        // =====================================================
        // V1.6.37 - EXECUTABLE PRICE PROXY FOR LOCATION CHECKS
        // =====================================================
        // Prefer fresh bid/ask from the Level II subscription so Structural
        // Room is evaluated near the price an order can actually fill at.
        private double GetEntryLocationPriceProxy(bool isLong)
        {
            lock (level2Sync)
            {
                bool freshL2 =
                    level2BookReady &&
                    level2LastCalcUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds <= 2.0;

                if (freshL2)
                {
                    double executable = isLong ? level2LastAskPrice : level2LastBidPrice;
                    if (executable > 0)
                        return executable;
                }
            }

            lock (marketContextLock)
            {
                return latestRangeClosePrice > 0
                    ? latestRangeClosePrice
                    : latestM5DecisionPrice;
            }
        }

        private void ArmLiquidityBreakAcceptanceLevel(
            bool isLong,
            double level,
            string referenceName,
            DateTime signalNyTime)
        {
            if (level <= 0)
                return;

            pendingLiquidityBreakActive = true;
            pendingLiquidityBreakIsLong = isLong;
            pendingLiquidityBreakLevel = level;
            pendingLiquidityBreakReference = referenceName ?? "STRUCTURE";
            pendingLiquidityBreakArmedNy = signalNyTime;
            pendingLiquidityBreakCrossedNy = DateTime.MinValue;
        }

       private void TrySubmitEntry(
            bool isLong,
            DateTime signalBarTime,
            bool manualTest = false,
            string structureSetupKey = null,
            bool openingEntry = false,
            bool highConvictionMomentum = false)
        {
            if (!botRunning)
                return;

            // FINAL LICENSE GATE.
            // This is intentionally inside the execution engine so every
            // automatic path and manual test is protected even if another
            // caller bypasses the UI Start button.
            if (!IsBotCloudLicenseValid())
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - BOT LICENSE EXPIRED"
                );

                return;
            }

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            // A filled M5 structure setup may never be traded twice.
            // Momentum/manual entries pass no structureSetupKey and
            // are unaffected by this guard.
            if (
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                )
            )
            {
                lock (executionStateLock)
                {
                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime setupConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        string.Equals(
                            structureSetupKey,
                            consumedKey,
                            StringComparison.Ordinal
                        ) ||
                        (
                            setupConfirmTime !=
                                DateTime.MinValue &&
                            consumedConfirmTime !=
                                DateTime.MinValue &&
                            setupConfirmTime <=
                                consumedConfirmTime
                        )
                    )
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - STRUCTURE SETUP ALREADY CONSUMED"
                            + " | "
                            + structureSetupKey
                        );

                        return;
                    }
                }
            }

            lock (executionStateLock)
            {
                if (
                    entryPending ||
                    signalBarTime ==
                        lastExecutedSignalBar ||
                    (
                        !manualTest &&
                        persistentDailyLocked
                    )
                )
                {
                    return;
                }
            }

            DateTime signalNyTime =
                ConvertToNewYorkTime(
                    signalBarTime
                );

            string signalSession =
                GetBotSessionWindow(
                    signalNyTime
                );

            // Automatic entries MUST obey NY session.
            // Manual tests may bypass ONLY the session filter.
            if (
                signalSession == "OUTSIDE"
            )
            {
                if (!manualTest)
                {
                    PrintBotMessage(
                        "ENTRY BLOCKED - OUTSIDE ACTIVE SESSION."
                    );

                    return;
                }

                signalSession =
                    "TEST";

                PrintBotMessage(
                    "MANUAL TEST - SESSION FILTER BYPASSED."
                );
            }

            // =====================================================
            // V1.6.36 - STARTUP MARKET WARMUP GUARD
            // =====================================================
            // Starting/restarting in the middle of an existing impulse must
            // not immediately inherit that move as a fresh entry. Analysis,
            // recovery, learning context and Level2 continue normally.
            if (
                !manualTest &&
                automaticEntryWarmupUntilNy != DateTime.MinValue &&
                GetCurrentNewYorkTime() < automaticEntryWarmupUntilNy
            )
            {
                int remainingWarmupSeconds =
                    Math.Max(
                        1,
                        (int)Math.Ceiling(
                            (automaticEntryWarmupUntilNy - GetCurrentNewYorkTime()).TotalSeconds
                        )
                    );

                string startupWarmupKey =
                    automaticEntryWarmupUntilNy.ToString("yyyyMMddHHmmss");

                if (startupWarmupKey != lastStartupWarmupBlockLogKey)
                {
                    lastStartupWarmupBlockLogKey = startupWarmupKey;
                    PrintBotMessage(
                        "ENTRY BLOCKED - STARTUP MARKET WARMUP"
                        + " | Remaining: " + remainingWarmupSeconds + "s"
                        + " | Context/L2/Learning: ACTIVE"
                        + " | Action: WAIT FRESH SIGNAL"
                    );
                }

                return;
            }

            // =====================================================
            // V1.6.35 - PREMARKET KNOWN-LOSS CLUSTER GUARD
            // =====================================================
            // Repeated losses have been observed around ~07:40 ET.
            // Keep market context and learning active, but do not allow an
            // automatic entry during this narrow window until the data says
            // the cluster has recovered. Manual TEST orders are unaffected.
            if (!manualTest && signalSession == "PREMARKET")
            {
                int premarketSignalTimeInt = ToTimeInt(signalNyTime);

                if (
                    premarketSignalTimeInt >= PremarketLossClusterStart &&
                    premarketSignalTimeInt <= PremarketLossClusterEnd
                )
                {
                    string lossClusterKey =
                        "PREMARKET_LOSS_CLUSTER|" +
                        signalNyTime.ToString("yyyyMMddHHmm");

                    if (lossClusterKey != lastRangeBlockedLogKey)
                    {
                        lastRangeBlockedLogKey = lossClusterKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - PREMARKET 07:40 LOSS CLUSTER"
                            + " | Window: 07:35-07:50 ET"
                            + " | Signal: "
                            + signalNyTime.ToString("HH:mm:ss")
                            + " ET"
                            + " | Context/Learning: ACTIVE"
                        );
                    }

                    return;
                }
            }

            // =====================================================
            // V1.6.24 - OPENING SAFETY HARDENING
            // =====================================================
            // These are FINAL execution gates. They live here so every
            // automatic path (Momentum / Opening / Structure) is protected
            // even if an upstream signal engine temporarily resolves AUTO.
            if (!manualTest)
            {
                int signalTimeInt =
                    ToTimeInt(signalNyTime);

                // -------------------------------------------------
                // 1) OPENING STABILITY GUARD
                // -------------------------------------------------
                // Do not trade the first 60 seconds after 09:30 ET.
                // The fast Range engine may flip LONG/SHORT/NONE several
                // times during price discovery; analysis continues, execution
                // waits until the first minute is complete.
                DateTime openingStartNy =
                    signalNyTime.Date
                        .AddHours(9)
                        .AddMinutes(30);

                double secondsFromOpen =
                    (
                        signalNyTime -
                        openingStartNy
                    ).TotalSeconds;

                bool fastOpenPriceCandidate =
                    IsFastOpenExtremePriceCandidate(
                        isLong
                    );

                string fastOpenLevel2Summary =
                    "L2 NOT CHECKED";

                bool fastOpenLevel2Confirmed =
                    fastOpenPriceCandidate &&
                    TryGetFastOpenLevel2Support(
                        isLong,
                        out fastOpenLevel2Summary
                    );

                bool fastOpenOverride =
                    fastOpenPriceCandidate &&
                    fastOpenLevel2Confirmed;

                if (
                    secondsFromOpen >= 0 &&
                    secondsFromOpen <
                        OpeningStabilityGuardSeconds &&
                    !fastOpenOverride
                )
                {
                    string openingStabilityKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT");

                    if (
                        openingStabilityKey !=
                            lastOpeningStabilityBlockLogKey
                    )
                    {
                        lastOpeningStabilityBlockLogKey =
                            openingStabilityKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - OPENING STABILITY GUARD"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | OpenAge: "
                            + Math.Max(
                                0,
                                (int)Math.Floor(
                                    secondsFromOpen
                                )
                              )
                            + "s/"
                            + OpeningStabilityGuardSeconds
                            + "s"
                            + " | Action: BUILD OPENING DIRECTION"
                        );
                    }

                    return;
                }

                if (
                    secondsFromOpen >= 0 &&
                    secondsFromOpen <
                        OpeningStabilityGuardSeconds &&
                    fastOpenOverride
                )
                {
                    PrintBotMessage(
                        "FAST OPEN ENTRY OVERRIDE"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | OpenAge: "
                        + Math.Max(
                            0,
                            (int)Math.Floor(
                                secondsFromOpen
                            )
                          )
                        + "s"
                        + " | R20/Expansion: EXTREME"
                        + " | "
                        + fastOpenLevel2Summary
                    );
                }

                bool m5BullishSnapshot;
                bool m5BearishSnapshot;
                string m5StructureSnapshot;

                lock (marketContextLock)
                {
                    m5BullishSnapshot =
                        latestM5BullishTrend;

                    m5BearishSnapshot =
                        latestM5BearishTrend;

                    m5StructureSnapshot =
                        latestM5StructureState;
                }

                bool trendOpposesEntry =
                    (
                        isLong &&
                        m5BearishSnapshot
                    ) ||
                    (
                        !isLong &&
                        m5BullishSnapshot
                    );

                bool structureAlignedForEntry =
                    IsStructureAlignedForSetup(
                        isLong,
                        m5StructureSnapshot
                    );

                bool insideOpeningSafetyWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningCounterTrendVetoEnd;

                // V1.6.31R3 - CURRENT OPENING PRESSURE COMPATIBILITY
                // The old dedicated latestOpeningPressure* snapshot fields
                // no longer exist in the current modular bot. Re-evaluate the
                // live directional pressure now, using the same M5/VWAP/R20/HTF
                // evidence used by the current Directional Pressure engine.
                int openingLongPressureScore;
                int openingShortPressureScore;

                string currentOpeningPressure =
                    EvaluateDirectionalPressure(
                        out openingLongPressureScore,
                        out openingShortPressureScore
                    );

                bool freshStrongOpeningPressureSupportsEntry =
                    string.Equals(
                        currentOpeningPressure,
                        isLong ? "LONG" : "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    ) &&
                    (
                        isLong
                            ? (
                                openingLongPressureScore >= 3 &&
                                openingShortPressureScore <= 1
                              )
                            : (
                                openingShortPressureScore >= 3 &&
                                openingLongPressureScore <= 1
                              )
                    );

                // -------------------------------------------------
                // 2) COUNTER-TREND OPENING VETO
                // -------------------------------------------------
                // Strong R20 / aggressive expansion may not override an
                // opposite confirmed M5 trend while structure is still
                // WAITING. A real BOS/CHOCH in the entry direction must
                // appear first.
                if (
                    insideOpeningSafetyWindow &&
                    trendOpposesEntry &&
                    !structureAlignedForEntry &&
                    !freshStrongOpeningPressureSupportsEntry &&
                    !fastOpenOverride
                )
                {
                    string counterTrendKey =
                        signalNyTime.Date
                            .ToString("yyyyMMdd")
                        + "|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|"
                        + (m5StructureSnapshot ?? "NONE");

                    if (
                        counterTrendKey !=
                            lastOpeningCounterTrendBlockLogKey
                    )
                    {
                        lastOpeningCounterTrendBlockLogKey =
                            counterTrendKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER-TREND OPENING VETO"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | M5 Trend: "
                            + (
                                m5BullishSnapshot
                                    ? "BULLISH"
                                    : m5BearishSnapshot
                                        ? "BEARISH"
                                        : "NEUTRAL"
                              )
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | Action: WAIT BOS/CHOCH"
                        );
                    }

                    return;
                }

                if (
                    insideOpeningSafetyWindow &&
                    trendOpposesEntry &&
                    !structureAlignedForEntry &&
                    !freshStrongOpeningPressureSupportsEntry &&
                    fastOpenOverride
                )
                {
                    PrintBotMessage(
                        "FAST OPEN M5 VETO OVERRIDE"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | M5: "
                        + (
                            m5BullishSnapshot
                                ? "BULLISH"
                                : m5BearishSnapshot
                                    ? "BEARISH"
                                    : "NEUTRAL"
                          )
                        + " | "
                        + fastOpenLevel2Summary
                    );
                }

                // -------------------------------------------------
                // 3) SAME-SETUP REENTRY LOCK AFTER LOSS
                // -------------------------------------------------
                // Existing code allows a same-side loss to rearm after the
                // cooldown when high-conviction momentum returns. During
                // the opening window that is too permissive. After a loss,
                // the same side must produce fresh aligned M5 structure.
                string requestedSide =
                    isLong
                        ? "LONG"
                        : "SHORT";

                bool sameSideLoss =
                    lastAutomaticTradeExitWasLoss &&
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedSide,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool insideSameSetupRearmWindow =
                    signalTimeInt >=
                        OpeningRangeStart &&
                    signalTimeInt <=
                        OpeningSameSideLossStructureRearmEnd;

                bool freshM5ContextAfterLoss =
                    latestM5DecisionNyTime != DateTime.MinValue &&
                    latestM5DecisionNyTime >
                        lastAutomaticTradeExitNy;

                if (
                    sameSideLoss &&
                    insideSameSetupRearmWindow &&
                    (
                        !structureAlignedForEntry ||
                        !freshM5ContextAfterLoss
                    )
                )
                {
                    string sameSetupKey =
                        lastAutomaticTradeExitNy
                            .ToString("yyyyMMddHHmmss")
                        + "|"
                        + requestedSide;

                    if (
                        sameSetupKey !=
                            lastOpeningSameSetupBlockLogKey
                    )
                    {
                        lastOpeningSameSetupBlockLogKey =
                            sameSetupKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - SAME-SETUP LOSS REARM"
                            + " | Side: "
                            + requestedSide
                            + " | PriorLoss: YES"
                            + " | Structure: "
                            + (
                                string.IsNullOrWhiteSpace(
                                    m5StructureSnapshot
                                )
                                    ? "WAITING"
                                    : m5StructureSnapshot
                              )
                            + " | FreshM5AfterLoss: "
                            + freshM5ContextAfterLoss
                            + " | Action: REQUIRE FRESH M5 + BOS/CHOCH"
                        );
                    }

                    return;
                }
            }

            // V1.6.20 - UNIVERSAL DIRECTIONAL SAFETY GATE.
            // Every automatic entry path must pass this final check.
            if (!manualTest)
            {
                string directionalBlockReason;

                if (
                    IsDirectionalSafetyBlocked(
                        isLong,
                        out directionalBlockReason
                    )
                )
                {
                    string pressureBlockKey =
                        "DIRECTIONAL_PRESSURE|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|" + latestDirectionalPressure
                        + "|" + latestDirectionalLongPressureScore
                        + "/" + latestDirectionalShortPressureScore;

                    if (
                        pressureBlockKey !=
                            lastDirectionalSafetyBlockKey
                    )
                    {
                        lastDirectionalSafetyBlockKey =
                            pressureBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER PRESSURE"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | " + directionalBlockReason
                            + " | Action: TREAT AS PULLBACK / WAIT RESUMPTION"
                        );
                    }

                    return;
                }
            }

            bool momentumEntry =
                !manualTest &&
                !openingEntry &&
                string.IsNullOrWhiteSpace(
                    structureSetupKey
                );

            // =====================================================
            // V1.6.38 - COUNTER-M5 MOMENTUM HARD GATE
            // =====================================================
            // A standard 3/5 Momentum entry may not trade directly against
            // confirmed M5 trend. Counter-M5 entries require BOTH high
            // conviction price action and strongly aligned fresh Level II flow.
            if (momentumEntry)
            {
                bool m5Opposed =
                    (isLong && latestM5BearishTrend) ||
                    (!isLong && latestM5BullishTrend);

                if (m5Opposed)
                {
                    int sameSideScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string counterM5FlowSummary =
                        "L2 FLOW NOT CONFIRMED";

                    // V1.6.49 - M5 is context, not an absolute prison.
                    // A 4/5+ high-conviction price setup may execute before
                    // M5 flips only when fresh executed aggression already
                    // confirms the same direction.  The stricter legacy flow
                    // confirmation remains as a fallback.
                    bool earlyAggressionConfirmed = false;
                    bool strongLegacyFlowConfirmed = false;

                    if (highConvictionMomentum && sameSideScore >= 4)
                    {
                        earlyAggressionConfirmed =
                            TryGetEarlyAggressionFlowSupport(
                                isLong,
                                out counterM5FlowSummary
                            );

                        if (!earlyAggressionConfirmed)
                        {
                            strongLegacyFlowConfirmed =
                                TryGetLiquidityBreakFlowSupport(
                                    isLong,
                                    out counterM5FlowSummary
                                );
                        }
                    }

                    bool counterM5FlowConfirmed =
                        earlyAggressionConfirmed ||
                        strongLegacyFlowConfirmed;

                    if (!counterM5FlowConfirmed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - COUNTER M5 MOMENTUM"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | R20: " + sameSideScore + "/5"
                            + " | HighConviction: " + (highConvictionMomentum ? "YES" : "NO")
                            + " | M5: " + (latestM5BullishTrend ? "BULLISH" : latestM5BearishTrend ? "BEARISH" : "NEUTRAL")
                            + " | Flow: " + counterM5FlowSummary
                            + " | Action: WAIT FRESH AGGRESSION / NO M5 CHASE"
                        );

                        return;
                    }
                }
            }

            bool confirmedStructureRetest =
                !manualTest &&
                !openingEntry &&
                !string.IsNullOrWhiteSpace(
                    structureSetupKey
                ) &&
                string.Equals(
                    latestSetupTiming,
                    "CONFIRMED RETEST",
                    StringComparison.OrdinalIgnoreCase
                );

            // V1.6.33 - Smart Retest timing refinement.
            // Price/structure already confirmed the setup, but do not submit
            // into clearly opposing immediate Level II flow. The pending retest
            // remains alive, so a later Range bar may still enter after L2
            // neutralizes or aligns.
            if (confirmedStructureRetest)
            {
                string retestLevel2Summary;

                if (
                    IsSmartRetestLevel2Opposed(
                        isLong,
                        out retestLevel2Summary
                    )
                )
                {
                    PrintBotMessage(
                        "SMART RETEST WAIT - LEVEL2 OPPOSING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | "
                        + retestLevel2Summary
                        + " | Action: KEEP RETEST ARMED"
                    );

                    return;
                }
            }

            // =====================================================
            // V1.6.25 - FINAL LEARNING EXECUTION VETO
            // =====================================================
            // Upstream UI/scoring can never bypass a negative exact learning
            // bucket. Prefer the context captured by the signal source. For
            // momentum, derive the exact R20 key when no pending label exists.
            if (!manualTest)
            {
                string executionLearningContext =
                    pendingLearningStructure;

                if (
                    string.IsNullOrWhiteSpace(
                        executionLearningContext
                    ) &&
                    momentumEntry
                )
                {
                    int executionMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    executionLearningContext =
                        "R20 MOMENTUM "
                        + executionMomentumScore
                        + "/5";
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        executionLearningContext
                    )
                )
                {
                    string executionLearningReason;

                    bool executionLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            executionLearningContext,
                            out executionLearningReason
                        );

                    if (!executionLearningAllowed)
                    {
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEARNING"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | Setup: "
                            + executionLearningContext
                            + " | "
                            + executionLearningReason
                        );

                        return;
                    }
                }

                // V1.6.33 - confirmed structure retest semantics.
                // The generic R20 bucket describes EARLY momentum behavior.
                // A confirmed BOS/CHOCH retest is a different execution path.
                // We keep the exact structure learning gate above authoritative,
                // while making any generic R20 disagreement explicit in logs.
                if (confirmedStructureRetest)
                {
                    int retestMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string retestGenericContext =
                        "R20 MOMENTUM "
                        + retestMomentumScore
                        + "/5";

                    string retestGenericReason;

                    bool retestGenericAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            retestGenericContext,
                            out retestGenericReason
                        );

                    if (!retestGenericAllowed)
                    {
                        PrintBotMessage(
                            "LEARNING EARLY BUCKET OVERRIDDEN BY CONFIRMED RETEST"
                            + " | Side: "
                            + (isLong ? "LONG" : "SHORT")
                            + " | EarlyBucket: "
                            + retestGenericContext
                            + " | "
                            + retestGenericReason
                            + " | StructureSetup: "
                            + structureSetupKey
                        );
                    }
                }

                // =================================================
                // V1.6.27 - QUALITY/EXECUTION LEARNING CONSISTENCY
                // =================================================
                // The Nasdaq quality layer evaluates the generic R20
                // score bucket ("R20 MOMENTUM N/5").  Previously an
                // aggressive/extreme exact bucket could pass while that
                // generic bucket was already BLOCK, producing the
                // contradictory log:
                //     SETUP QUALITY ... Learning BLOCK
                //     SIM ENTRY SUBMITTED
                //
                // For automatic Momentum entries, BOTH the exact setup
                // bucket and the generic R20 quality bucket must allow.
                if (momentumEntry)
                {
                    int genericMomentumScore =
                        isLong
                            ? latestRangeLongScore
                            : latestRangeShortScore;

                    string genericLearningContext =
                        "R20 MOMENTUM "
                        + genericMomentumScore
                        + "/5";

                    string genericLearningReason;

                    bool genericLearningAllowed =
                        IsLearningTradeAllowed(
                            isLong ? "LONG" : "SHORT",
                            signalNyTime,
                            genericLearningContext,
                            out genericLearningReason
                        );

                    if (!genericLearningAllowed)
                    {
                        // V1.6.43 - CONTEXTUAL LEARNING AUTHORITY.
                        // Reaching this point means the exact signal-context bucket
                        // above has already PASSED. A negative generic R20 bucket
                        // may therefore be downgraded from BLOCK to CAUTION only
                        // when the CURRENT setup is exceptional and live order flow
                        // strongly confirms it. This is intentionally narrow:
                        // 4/5+, real breakout, strong body/volume, high-conviction
                        // price path, fresh L2 persistence/aggression/delta alignment,
                        // and no adverse absorption. All downstream risk/location/
                        // anti-chase/session guards remain authoritative.
                        bool breakoutAligned =
                            isLong
                                ? latestRangeHighBreakout
                                : latestRangeLowBreakout;

                        int sameSideScore =
                            isLong
                                ? latestRangeLongScore
                                : latestRangeShortScore;

                        bool exceptionalPriceContext =
                            highConvictionMomentum &&
                            sameSideScore >= 4 &&
                            breakoutAligned &&
                            latestRangeVolumeRatio >= 1.50 &&
                            latestRangeBodyRatio >= 0.70;

                        string exceptionalFlowSummary = string.Empty;
                        bool exceptionalFlowConfirmed = false;

                        if (exceptionalPriceContext)
                        {
                            exceptionalFlowConfirmed =
                                TryGetLiquidityBreakFlowSupport(
                                    isLong,
                                    out exceptionalFlowSummary
                                );
                        }

                        if (exceptionalFlowConfirmed)
                        {
                            PrintBotMessage(
                                "LEARNING QUALITY BUCKET OVERRIDE - EXCEPTIONAL FLOW"
                                + " | Side: "
                                + (isLong ? "LONG" : "SHORT")
                                + " | Generic: "
                                + genericLearningContext
                                + " | Exact: "
                                + (
                                    string.IsNullOrWhiteSpace(executionLearningContext)
                                        ? "N/A"
                                        : executionLearningContext
                                  )
                                + " | R20: "
                                + sameSideScore
                                + "/5"
                                + " | Vol x"
                                + latestRangeVolumeRatio.ToString("0.00")
                                + " | Body "
                                + (latestRangeBodyRatio * 100.0).ToString("0")
                                + "% | "
                                + exceptionalFlowSummary
                                + " | Action: GENERIC BLOCK -> CAUTION"
                            );
                        }
                        else
                        {
                            string learningBlockKey =
                                (isLong ? "LONG" : "SHORT")
                                + "|"
                                + genericLearningContext
                                + "|"
                                + genericLearningReason;

                            DateTime nowUtc = DateTime.UtcNow;

                            if (
                                learningBlockKey !=
                                    lastLearningQualityBucketBlockKey ||
                                (
                                    nowUtc -
                                    lastLearningQualityBucketBlockLogUtc
                                ).TotalSeconds >= 15
                            )
                            {
                                lastLearningQualityBucketBlockKey =
                                    learningBlockKey;

                                lastLearningQualityBucketBlockLogUtc =
                                    nowUtc;

                                PrintBotMessage(
                                    "ENTRY BLOCKED - LEARNING QUALITY BUCKET"
                                    + " | Side: "
                                    + (isLong ? "LONG" : "SHORT")
                                    + " | Setup: "
                                    + genericLearningContext
                                    + " | "
                                    + genericLearningReason
                                    + " | ExceptionalPrice: "
                                    + (exceptionalPriceContext ? "YES" : "NO")
                                    + " | Flow: "
                                    + (
                                        string.IsNullOrWhiteSpace(exceptionalFlowSummary)
                                            ? "NOT CONFIRMED"
                                            : exceptionalFlowSummary
                                      )
                                );
                            }

                            return;
                        }
                    }
                }
            }

            // V1.6.23 Phase 11 - final quality gate for MOMENTUM entries.
            // Opening and confirmed structure setups keep their own engines.
            if (
                momentumEntry &&
                !IsOpeningEntryWindow(signalNyTime)
            )
            {
                string entryQualityReason;

                if (
                    IsMomentumEntryQualityBlocked(
                        isLong,
                        highConvictionMomentum,
                        out entryQualityReason
                    )
                )
                {
                    string qualityBlockKey =
                        "ENTRY_QUALITY|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|" + latestMarketRegime
                        + "|" + latestMarketRegimeDirection
                        + "|" + latestRangeLongScore
                        + "/" + latestRangeShortScore;

                    if (
                        qualityBlockKey !=
                            lastEntryQualityBlockKey
                    )
                    {
                        lastEntryQualityBlockKey =
                            qualityBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - QUALITY / REGIME"
                            + " | " + entryQualityReason
                            + " | Action: WAIT CLEAN CONTINUATION"
                        );
                    }

                    return;
                }
            }

            if (!manualTest)
            {
                int lateEntryAgeSeconds;
                int lateEntryMaxSeconds;

                if (
                    IsLateAutomaticEntry(
                        signalNyTime,
                        momentumEntry,
                        openingEntry,
                        highConvictionMomentum,
                        out lateEntryAgeSeconds,
                        out lateEntryMaxSeconds
                    )
                )
                {
                    string lateEntryKey =
                        signalBarTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + (
                            openingEntry
                                ? "OPENING"
                                : momentumEntry
                                    ? "MOMENTUM"
                                    : "STRUCTURE"
                          );

                    if (
                        lateEntryKey !=
                            lastLateEntryBlockLogKey
                    )
                    {
                        lastLateEntryBlockLogKey =
                            lateEntryKey;

                        PrintBotMessage(
                            "SKIP TRADE - LATE ENTRY"
                            + " | Type: "
                            + (
                                openingEntry
                                    ? "OPENING"
                                    : momentumEntry
                                        ? "MOMENTUM"
                                        : "STRUCTURE"
                              )
                            + " | Age: "
                            + lateEntryAgeSeconds
                            + "s"
                            + " | Max: "
                            + lateEntryMaxSeconds
                            + "s"
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | StrategyClock: "
                            + GetCurrentNewYorkTime()
                                .ToString(
                                    "HH:mm:ss"
                                )
                            + " ET"
                            + (
                                momentumEntry
                                    ? " | HighConviction: "
                                        + (highConvictionMomentum ? "YES" : "NO")
                                    : string.Empty
                              )
                            + " | Action: NO CHASE"
                        );
                    }

                    return;
                }

                string reentryReason;

                if (
                    IsAutomaticReentryBlocked(
                        isLong,
                        signalBarTime,
                        momentumEntry,
                        highConvictionMomentum,
                        out reentryReason
                    )
                )
                {
                    // V1.6.6 - one reentry-block log per cooldown cycle
                    // and side. Do not create a new key every second as the
                    // remaining cooldown text changes.
                    string reentryBlockKey =
                        "REENTRY|"
                        + (
                            isLong
                                ? "LONG"
                                : "SHORT"
                          )
                        + "|"
                        + lastAutomaticTradeExitNy.ToString(
                            "yyyyMMddHHmmss"
                        );

                    if (
                        reentryBlockKey !=
                            lastReentryBlockLogKey
                    )
                    {
                        lastReentryBlockLogKey =
                            reentryBlockKey;

                        PrintBotMessage(
                            "ENTRY BLOCKED - REENTRY REARM"
                            + " | "
                            + reentryReason
                            + " | Side: "
                            + (
                                isLong
                                    ? "LONG"
                                    : "SHORT"
                              )
                            + " | SignalBar: "
                            + signalNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                        );
                    }

                    return;
                }
            }

            // =====================================================
            // V1.6.36 - SAME-SIDE REENTRY RESET GUARD
            // =====================================================
            // A timer + a few ticks of pullback is not a new market cycle.
            // After ANY automatic exit, another entry in the same direction
            // must wait for fresh completed M5 context after the exit AND an
            // aligned BOS/CHOCH structure state. This protects winning trades
            // from being immediately recycled into a late continuation chase.
            if (!manualTest && lastAutomaticTradeExitNy != DateTime.MinValue)
            {
                string requestedResetSide = isLong ? "LONG" : "SHORT";
                bool sameSideResetRequired =
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedResetSide,
                        StringComparison.OrdinalIgnoreCase
                    );

                if (sameSideResetRequired)
                {
                    string reentryStructureState;
                    DateTime reentryM5DecisionNy;

                    lock (marketContextLock)
                    {
                        reentryStructureState = latestM5StructureState;
                        reentryM5DecisionNy = latestM5DecisionNyTime;
                    }

                    bool freshM5AfterExit =
                        reentryM5DecisionNy != DateTime.MinValue &&
                        reentryM5DecisionNy > lastAutomaticTradeExitNy;

                    bool alignedResetStructure =
                        IsStructureAlignedForSetup(
                            isLong,
                            reentryStructureState
                        );

                    if (!freshM5AfterExit || !alignedResetStructure)
                    {
                        string resetKey =
                            "REENTRY_RESET|"
                            + requestedResetSide
                            + "|"
                            + lastAutomaticTradeExitNy.ToString("yyyyMMddHHmmss");

                        if (resetKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = resetKey;
                            PrintBotMessage(
                                "ENTRY BLOCKED - SAME-SIDE REENTRY RESET"
                                + " | Side: " + requestedResetSide
                                + " | FreshM5AfterExit: " + freshM5AfterExit
                                + " | Structure: "
                                + (string.IsNullOrWhiteSpace(reentryStructureState)
                                    ? "WAITING"
                                    : reentryStructureState)
                                + " | Action: REQUIRE FRESH M5 + ALIGNED BOS/CHOCH"
                            );
                        }

                        return;
                    }
                }
            }

            // V1.6.35 - LEVEL 2 SAME-SIDE REENTRY VETO.
            // Level 2 remains observe-only for initial entries. For a same-side
            // reentry, however, persistent opposite tape/order-flow may veto a
            // late continuation attempt. It never creates an entry by itself.
            if (!manualTest && lastAutomaticTradeExitNy != DateTime.MinValue)
            {
                string requestedReentrySide = isLong ? "LONG" : "SHORT";
                bool sameSideReentry =
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        requestedReentrySide,
                        StringComparison.OrdinalIgnoreCase
                    );

                if (sameSideReentry && level2BookReady)
                {
                    int oppositePersistence =
                        isLong
                            ? level2ShortPersistence
                            : level2LongPersistence;

                    string oppositeSide = isLong ? "SHORT" : "LONG";
                    bool oppositeTape =
                        string.Equals(
                            level2TapeBias,
                            oppositeSide,
                            StringComparison.OrdinalIgnoreCase
                        );

                    if (oppositePersistence >= 5 && oppositeTape)
                    {
                        string l2ReentryKey =
                            "REENTRY_L2_VETO|"
                            + requestedReentrySide
                            + "|"
                            + lastAutomaticTradeExitNy.ToString("yyyyMMddHHmmss");

                        if (l2ReentryKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = l2ReentryKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - REENTRY LEVEL2 VETO"
                                + " | Side: " + requestedReentrySide
                                + " | TapeBias: " + level2TapeBias
                                + " | OppPersistence: "
                                + oppositePersistence
                                + "/6"
                                + " | Level2 remains OBSERVE-ONLY for initial entries"
                            );
                        }

                        return;
                    }
                }
            }

            // =====================================================
            // V1.6.37 - INITIAL ENTRY LEVEL II STRONG-CONTRARY VETO
            // =====================================================
            // Level II still never creates the initial setup. It can only
            // delay an otherwise-valid entry when immediate aggressive flow
            // is exceptionally contrary to the requested side.
            if (!manualTest)
            {
                string initialL2Summary;
                bool initialL2Opposed =
                    IsInitialEntryLevel2StronglyOpposed(
                        isLong,
                        out initialL2Summary
                    );

                if (initialL2Opposed)
                {
                    string initialL2Key =
                        "INITIAL_L2_VETO|"
                        + (isLong ? "LONG" : "SHORT")
                        + "|"
                        + signalNyTime.ToString("yyyyMMddHHmmss");

                    if (initialL2Key != lastRangeBlockedLogKey)
                    {
                        lastRangeBlockedLogKey = initialL2Key;
                        PrintBotMessage(
                            "ENTRY BLOCKED - LEVEL2 STRONG CONTRARY FLOW"
                            + " | Side: " + (isLong ? "LONG" : "SHORT")
                            + " | " + initialL2Summary
                            + " | Action: WAIT FLOW NEUTRALIZE / ALIGN"
                        );
                    }

                    return;
                }
            }

            if (
                !manualTest &&
                IsSessionTradeLimitReached(
                    signalSession
                )
            )
            {
                // V1.6.6 - session limit is a persistent state, not a
                // per-Range-bar event. Log it once until the state changes.
                string blockedKey =
                    "SESSION_LIMIT|"
                    + signalSession
                    + "|"
                    + GetSessionTradeCount(
                        signalSession
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        signalSession
                    );

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - "
                        + signalSession
                        + " SESSION TRADE LIMIT "
                        + GetSessionTradeCount(
                            signalSession
                        )
                        + "/"
                        + GetSessionTradeLimit(
                            signalSession
                        )
                    );
                }

                return;
            }

            double totalBotPnL;

            lock (executionStateLock)
            {
                totalBotPnL =
                    botDailyPnL +
                    botUnrealizedPnL;
            }

            if (
                !manualTest &&
                (
                    totalBotPnL >=
                        activeDailyTarget ||
                    totalBotPnL <=
                        -activeDailyLoss
                )
            )
            {
                return;
            }

            if (
                !manualTest &&
                positionRecoveryPending
            )
            {
                string recoveryBlockedKey =
                    "POSITION_RECOVERY_PENDING|"
                    + signalBarTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (
                    recoveryBlockedKey !=
                        lastRangeBlockedLogKey
                )
                {
                    lastRangeBlockedLogKey =
                        recoveryBlockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION RECOVERY PENDING"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | Waiting for NinjaTrader account sync."
                    );
                }

                return;
            }

            if (
                !IsSelectedInstrumentFlat()
            )
            {
                string blockedKey =
                    "POSITION|"
                    + signalBarTime.ToString("yyyyMMddHHmmss")
                    + "|"
                    + (isLong ? "LONG" : "SHORT");

                if (blockedKey != lastRangeBlockedLogKey)
                {
                    lastRangeBlockedLogKey = blockedKey;

                    PrintBotMessage(
                        "ENTRY BLOCKED - POSITION IS NOT FLAT"
                        + " | Side: "
                        + (isLong ? "LONG" : "SHORT")
                        + " | SignalBar: "
                        + ConvertToNewYorkTime(
                            signalBarTime
                          ).ToString(
                            "HH:mm:ss"
                          )
                        + " ET"
                    );
                }

                return;
            }

            // =====================================================
            // V1.6.30 - PRE-ENTRY STRUCTURE LOCATION GUARD
            // =====================================================
            // Freeze/reset the location snapshot only after FLAT is confirmed.
            // Subsequent signals while a trade is open therefore cannot erase
            // the location context of the active trade.
            activeEntryRoomTicks = 0;
            activeEntryLocationState = openingEntry ? "OPENING" : "OPEN";
            activeEntryLocationReference = openingEntry ? "OPENING BREAKOUT" : "OPEN SPACE";
            activeEntryLocationReferencePrice = 0;

            // Opening breakouts are excluded because crossing the OR boundary
            // is the setup itself. Manual tests are never filtered.
            if (!manualTest && !openingEntry)
            {
                double tickSize =
                    instrument.MasterInstrument != null
                        ? instrument.MasterInstrument.TickSize
                        : 0;

                double signalPrice =
                    GetEntryLocationPriceProxy(isLong);

                double roomTicks;
                string locationReference;
                double locationReferencePrice;

                bool hasBarrier =
                    TryGetEntryLocationRoom(
                        isLong,
                        signalPrice,
                        tickSize,
                        out roomTicks,
                        out locationReference,
                        out locationReferencePrice
                    );

                // Use the same structural safety buffer used by the
                // structure-aware target. RR eligibility must be based on the
                // room we can actually monetize BEFORE the barrier, not the raw
                // distance to the barrier itself.
                int rawAvailableRoomTicks =
                    hasBarrier
                        ? Math.Max(1, (int)Math.Floor(roomTicks))
                        : 0;

                int structuralBufferTicks =
                    hasBarrier
                        ? Math.Min(
                            StructureTargetMaxBufferTicks,
                            Math.Max(1, rawAvailableRoomTicks / 5)
                          )
                        : 0;

                double effectiveRoomTicks =
                    hasBarrier
                        ? Math.Max(0, rawAvailableRoomTicks - structuralBufferTicks)
                        : 0;

                activeEntryRoomTicks = hasBarrier ? effectiveRoomTicks : 0;
                activeEntryLocationReference = hasBarrier ? locationReference : "OPEN SPACE";
                activeEntryLocationReferencePrice = hasBarrier ? locationReferencePrice : 0;
                bool sameSideReentryLocationCheck =
                    lastAutomaticTradeExitNy != DateTime.MinValue &&
                    string.Equals(
                        lastAutomaticTradeExitSide,
                        isLong ? "LONG" : "SHORT",
                        StringComparison.OrdinalIgnoreCase
                    );

                double minimumStructuralR =
                    sameSideReentryLocationCheck
                        ? ReentryMinimumStructuralR
                        : InitialMinimumStructuralR;

                double minimumRequiredRoomTicks =
                    Math.Max(
                        EntryLocationMinRoomTicks,
                        activeStopTicks * minimumStructuralR
                    );

                activeEntryLocationState =
                    !hasBarrier
                        ? "OPEN"
                        : effectiveRoomTicks < minimumRequiredRoomTicks
                            ? "POOR"
                            : effectiveRoomTicks < minimumRequiredRoomTicks * 1.5
                                ? "FAIR"
                                : "GOOD";

                // V1.6.41 - STRUCTURE LOCATION remains the normal authority,
                // but a barrier that has ACTUALLY been consumed with fresh,
                // aligned aggressive flow is no longer treated as intact
                // resistance/support. This closes the dead zone seen on 09/03:
                // block below liquidity -> break liquidity -> anti-chase too late.
                //
                // IMPORTANT: confluence alone can never bypass a POOR location.
                // The exception requires the existing Liquidity Break Acceptance
                // window, which itself requires a real cross, proximity to the
                // broken level and strong symmetric Level II confirmation.
                bool exceptionalLiquidityBreakLocation = false;
                string exceptionalLiquidityBreakSummary = string.Empty;

                if (hasBarrier && effectiveRoomTicks < minimumRequiredRoomTicks)
                {
                    bool liquidityBreakSessionEligible =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            signalSession,
                            "AM",
                            StringComparison.OrdinalIgnoreCase
                        );

                    // First sighting of a nearby barrier: arm it, but DO NOT enter.
                    // This preserves protection from buying under a high / selling
                    // above a low merely because momentum looks strong.
                    if (
                        highConvictionMomentum &&
                        liquidityBreakSessionEligible
                    )
                    {
                        bool samePendingBarrier =
                            pendingLiquidityBreakActive &&
                            pendingLiquidityBreakIsLong == isLong &&
                            Math.Abs(
                                pendingLiquidityBreakLevel - locationReferencePrice
                            ) <= Math.Max(tickSize, 0.0000001);

                        if (!samePendingBarrier)
                        {
                            ArmLiquidityBreakAcceptanceLevel(
                                isLong,
                                locationReferencePrice,
                                locationReference,
                                signalNyTime
                            );
                        }

                        // Only a previously armed level that is now genuinely
                        // crossed and flow-confirmed may bypass this stale barrier.
                        exceptionalLiquidityBreakLocation =
                            TryGetLiquidityBreakAcceptanceOverride(
                                isLong,
                                signalNyTime,
                                signalPrice,
                                tickSize,
                                true,
                                out exceptionalLiquidityBreakSummary
                            );
                    }

                    if (exceptionalLiquidityBreakLocation)
                    {
                        activeEntryLocationState = "EXCEPTIONAL";
                        activeEntryLocationReference =
                            "BROKEN " + locationReference;

                        string exceptionKey =
                            "LOCATION_BREAK|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|"
                            + pendingLiquidityBreakLevel.ToString("0.00")
                            + "|"
                            + signalBarTime.ToString("yyyyMMddHHmmss");

                        if (exceptionKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = exceptionKey;

                            PrintBotMessage(
                                "STRUCTURE LOCATION OVERRIDE - CONFIRMED LIQUIDITY BREAK"
                                + " | Side: " + (isLong ? "LONG" : "SHORT")
                                + " | Price: " + signalPrice.ToString("0.00")
                                + " | FormerBarrier: " + locationReference
                                + " @ " + locationReferencePrice.ToString("0.00")
                                + " | " + exceptionalLiquidityBreakSummary
                                + " | Action: ALLOW EARLY ENTRY NEAR CONSUMED LIQUIDITY"
                            );
                        }
                    }
                    else
                    {
                        string locationKey =
                            "LOCATION|"
                            + (isLong ? "LONG" : "SHORT")
                            + "|"
                            + signalBarTime.ToString("yyyyMMddHHmmss")
                            + "|"
                            + locationReference;

                        if (locationKey != lastRangeBlockedLogKey)
                        {
                            lastRangeBlockedLogKey = locationKey;

                            PrintBotMessage(
                                "ENTRY BLOCKED - STRUCTURE LOCATION"
                                + " | Side: " + (isLong ? "LONG" : "SHORT")
                                + " | Price: " + signalPrice.ToString("0.00")
                                + " | Next: " + locationReference
                                + " @ " + locationReferencePrice.ToString("0.00")
                                + " | RawRoom: " + roomTicks.ToString("0") + "t"
                                + " | Buffer: " + structuralBufferTicks + "t"
                                + " | EffectiveRoom: " + effectiveRoomTicks.ToString("0") + "t"
                                + " | Min: " + minimumRequiredRoomTicks.ToString("0") + "t"
                                + " | MinR: " + minimumStructuralR.ToString("0.00")
                                + (sameSideReentryLocationCheck
                                    ? " | Reentry: YES"
                                    : " | Reentry: NO")
                                + " | Action: WAIT BREAK + AGGRESSIVE FLOW OR BETTER LOCATION / RETEST"
                            );
                        }

                        return;
                    }
                }

                if (hasBarrier)
                {
                    PrintBotMessage(
                        "ENTRY LOCATION"
                        + " | " + activeEntryLocationState
                        + " | Side: " + (isLong ? "LONG" : "SHORT")
                        + " | Room: " + effectiveRoomTicks.ToString("0") + "t"
                        + " | RawRoom: " + roomTicks.ToString("0") + "t"
                        + " | Next: " + locationReference
                        + " @ " + locationReferencePrice.ToString("0.00")
                    );
                }
            }

            double riskPerContract;
            double configuredRisk;

            int effectiveEntryContracts =
                GetAutoRiskSizedContracts(
                    instrument,
                    activeContracts,
                    activeStopTicks,
                    activeDollarRiskCap,
                    out riskPerContract,
                    out configuredRisk
                );

            if (effectiveEntryContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DOLLAR RISK CAP"
                    + " | ConfigQty: "
                    + activeContracts
                    + " | SL: "
                    + activeStopTicks
                    + "t"
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );

                return;
            }

            if (
                effectiveEntryContracts <
                    activeContracts
            )
            {
                PrintBotMessage(
                    "AUTO RISK SIZING"
                    + " | ConfigQty: "
                    + activeContracts
                    + " -> EffectiveQty: "
                    + effectiveEntryContracts
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                    + " | ConfigRisk: "
                    + configuredRisk.ToString("$0.00")
                    + " | RiskCap: "
                    + activeDollarRiskCap.ToString("$0.00")
                );
            }

            // V1.6.40 - DAILY PROFIT FLOOR PRE-ENTRY RISK GATE.
            // Do not allow a new trade whose initial stop risk can consume
            // an already protected portion of the day's realized profit.
            double floorRealizedPnL;
            double floorProtectedPnL;
            double floorAvailableGiveback;
            double floorSafeRiskBudget;

            int floorLimitedContracts =
                ApplyDailyProfitFloorEntryRiskBudget(
                    effectiveEntryContracts,
                    riskPerContract,
                    out floorRealizedPnL,
                    out floorProtectedPnL,
                    out floorAvailableGiveback,
                    out floorSafeRiskBudget
                );

            if (floorLimitedContracts <= 0)
            {
                PrintBotMessage(
                    "ENTRY BLOCKED - DAILY PROFIT FLOOR RISK"
                    + " | Realized: "
                    + floorRealizedPnL.ToString("$0.00")
                    + " | Protected: "
                    + floorProtectedPnL.ToString("$0.00")
                    + " | AvailableGiveback: "
                    + floorAvailableGiveback.ToString("$0.00")
                    + " | SafeRiskBudget: "
                    + floorSafeRiskBudget.ToString("$0.00")
                    + " | ProposedRisk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + " | Action: PRESERVE PROFIT"
                );

                return;
            }

            if (floorLimitedContracts < effectiveEntryContracts)
            {
                PrintBotMessage(
                    "DAILY PROFIT FLOOR AUTO RISK SIZING"
                    + " | Qty: "
                    + effectiveEntryContracts
                    + " -> "
                    + floorLimitedContracts
                    + " | Realized: "
                    + floorRealizedPnL.ToString("$0.00")
                    + " | Protected: "
                    + floorProtectedPnL.ToString("$0.00")
                    + " | AvailableGiveback: "
                    + floorAvailableGiveback.ToString("$0.00")
                    + " | SafeRiskBudget: "
                    + floorSafeRiskBudget.ToString("$0.00")
                    + " | Risk/Contract: "
                    + riskPerContract.ToString("$0.00")
                );

                effectiveEntryContracts =
                    floorLimitedContracts;
            }

            try
            {
                OrderAction action =
                    isLong
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string name =
                    isLong
                        ? GetProfileOrderName("JJ_ENTRY_LONG")
                        : GetProfileOrderName("JJ_ENTRY_SHORT");

                Order newEntryOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        effectiveEntryContracts,
                        0,
                        0,
                        string.Empty,
                        name,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                // Reserve the entry atomically. This is the final
                // gate before Account.Submit().
                lock (executionStateLock)
                {
                    double latestTotalPnL =
                        botDailyPnL +
                        botUnrealizedPnL;

                    string consumedKey =
                        isLong
                            ? consumedBullishStructureSetupKey
                            : consumedBearishStructureSetupKey;

                    DateTime structureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            structureSetupKey
                        );

                    DateTime consumedConfirmTime =
                        isLong
                            ? consumedBullishStructureConfirmTime
                            : consumedBearishStructureConfirmTime;

                    if (
                        entryPending ||
                        signalBarTime ==
                            lastExecutedSignalBar ||
                        (
                            openingEntry &&
                            openingTradeTakenToday
                        ) ||
                        (
                            !manualTest &&
                            (
                                persistentDailyLocked ||
                                latestTotalPnL >=
                                    activeDailyTarget ||
                                latestTotalPnL <=
                                    -activeDailyLoss
                            )
                        ) ||
                        (
                            !string.IsNullOrWhiteSpace(
                                structureSetupKey
                            ) &&
                            (
                                string.Equals(
                                    structureSetupKey,
                                    consumedKey,
                                    StringComparison.Ordinal
                                ) ||
                                (
                                    structureConfirmTime !=
                                        DateTime.MinValue &&
                                    consumedConfirmTime !=
                                        DateTime.MinValue &&
                                    structureConfirmTime <=
                                        consumedConfirmTime
                                )
                            )
                        )
                    )
                    {
                        return;
                    }

                    entryOrder =
                        newEntryOrder;

                    entryPending =
                        true;

                    if (
                        !manualTest &&
                        pendingLiquidityBreakActive &&
                        pendingLiquidityBreakIsLong == isLong
                    )
                    {
                        pendingLiquidityBreakActive = false;
                        pendingLiquidityBreakCrossedNy = DateTime.MinValue;
                    }

                    pendingEntrySession =
                        signalSession;

                    pendingEntryRequestedQuantity =
                        effectiveEntryContracts;

                    pendingEntryIsManualTest =
                        manualTest;

                    pendingEntryIsOpening =
                        openingEntry;

                    pendingEntryIsPremarket =
                        string.Equals(
                            signalSession,
                            "PREMARKET",
                            StringComparison.OrdinalIgnoreCase
                        );

                    pendingTradeSetupConfidence =
                        manualTest
                            ? 0
                            : latestSetupConfidence;

                    pendingTradeSetupQuality =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupQuality
                                )
                                    ? "ANALYZING"
                                    : latestSetupQuality
                              );

                    pendingTradeSetupTiming =
                        manualTest
                            ? "TEST"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestSetupTiming
                                )
                                    ? "ANALYZING"
                                    : latestSetupTiming
                              );

                    pendingTradeManipulationState =
                        manualTest
                            ? "NONE"
                            : (
                                string.IsNullOrWhiteSpace(
                                    latestManipulationState
                                )
                                    ? "NONE"
                                    : latestManipulationState
                              );

                    pendingStructureSetupKey =
                        string.IsNullOrWhiteSpace(
                            structureSetupKey
                        )
                            ? string.Empty
                            : structureSetupKey;

                    pendingStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            pendingStructureSetupKey
                        );

                    executionStatus =
                        "ENTRY SUBMITTED";

                    if (!manualTest)
                    {
                        lastExecutedSignalBar =
                            signalBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;
                    }
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newEntryOrder
                    }
                );

                PrintBotMessage(
                    "SIM ENTRY SUBMITTED"
                    + " | "
                    + (
                        isLong
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Qty: "
                    + effectiveEntryContracts
                    + (
                        effectiveEntryContracts != activeContracts
                            ? " (Configured "
                                + activeContracts
                                + ")"
                            : string.Empty
                      )
                    + " | Risk: "
                    + (
                        effectiveEntryContracts *
                        riskPerContract
                      ).ToString("$0.00")
                    + "/"
                    + activeDollarRiskCap.ToString("$0.00")
                    + " | "
                    + instrument.FullName
                    + (
                        openingEntry
                            ? " | Setup: OPENING"
                            : string.Empty
                    )
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    entryPending =
                        false;

                    entryOrder =
                        null;

                    pendingEntryRequestedQuantity =
                        0;

                    pendingEntryIsManualTest =
                        false;

                    pendingEntryIsOpening =
                        false;

                    pendingEntryIsPremarket =
                        false;

                    pendingTradeSetupConfidence =
                        0;

                    pendingTradeSetupQuality =
                        string.Empty;

                    pendingTradeSetupTiming =
                        string.Empty;

                    pendingTradeManipulationState =
                        string.Empty;

                    pendingStructureSetupKey =
                        string.Empty;

                    pendingStructureConfirmTime =
                        DateTime.MinValue;

                    executionStatus =
                        "ENTRY ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "ENTRY SUBMIT ERROR: "
                    + ex.Message
                );
            }
        }
        private void SubmitProtectiveBracket(
            double fillPrice,
            int quantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                quantity <= 0
            )
            {
                return;
            }

            // IMPORTANT:
            // CreateOrder may synchronously fire OrderUpdate before this
            // method has finished creating both protective orders.
            // Only one bracket-construction pass may exist at a time.
            lock (executionStateLock)
            {
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                protectiveBracketBuildInProgress =
                    true;
            }

            try
            {
                double tickSize =
                    instrument
                        .MasterInstrument
                        .TickSize;

                int dynamicTargetTicks =
                    GetDynamicTargetTicks(
                        marketPosition
                    );

                int effectiveTargetTicks =
                    GetStructureAwareTargetTicks(
                        marketPosition,
                        fillPrice,
                        tickSize,
                        dynamicTargetTicks
                    );

                int minimumRiskRewardTicks =
                    Math.Max(
                        DynamicTargetMinTicks,
                        (int)Math.Ceiling(
                            activeStopTicks *
                            DynamicTargetMinimumRiskReward
                        )
                    );

                if (
                    effectiveTargetTicks <
                        minimumRiskRewardTicks
                )
                {
                    // V1.6.37 - structural authority wins. Never manufacture
                    // target room after a fill by pushing TP through a known
                    // barrier. The pre-entry guard should normally prevent this;
                    // this branch protects against fast price movement/fill races.
                    PrintBotMessage(
                        "TARGET RR FLOOR NOT APPLIED - STRUCTURE AUTHORITY"
                        + " | StructureTarget: "
                        + effectiveTargetTicks
                        + "t"
                        + " | RR Floor: "
                        + minimumRiskRewardTicks
                        + "t"
                        + " | SL: "
                        + activeStopTicks
                        + "t"
                        + " | MinRR: 1:"
                        + DynamicTargetMinimumRiskReward
                            .ToString("0.00")
                        + " | Action: KEEP TP BEFORE BARRIER"
                    );
                }

                double stopPrice;
                double targetPrice;
                OrderAction exitAction;

                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    stopPrice =
                        fillPrice
                        - activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        + effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.Sell;
                }
                else
                {
                    stopPrice =
                        fillPrice
                        + activeStopTicks
                        * tickSize;

                    targetPrice =
                        fillPrice
                        - effectiveTargetTicks
                        * tickSize;

                    exitAction =
                        OrderAction.BuyToCover;
                }

                stopPrice =
                    RoundToInstrumentTick(
                        stopPrice
                    );

                targetPrice =
                    RoundToInstrumentTick(
                        targetPrice
                    );

                string ocoId =
                    GetProfileOrderPrefix()
                    + "JJ_OCO_"
                    + Guid.NewGuid()
                        .ToString("N");

                Order newStopOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.StopMarket,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        stopPrice,
                        ocoId,
                        GetProfileOrderName("JJ_STOP"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                Order newTargetOrder =
                    account.CreateOrder(
                        instrument,
                        exitAction,
                        OrderType.Limit,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        targetPrice,
                        0,
                        ocoId,
                        GetProfileOrderName("JJ_TARGET"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    // Do not attach a bracket to a trade that has
                    // already been flattened by another callback.
                    if (
                        entryMarketPosition !=
                            marketPosition ||
                        entryFillPrice <= 0 ||
                        entryQuantity <= 0
                    )
                    {
                        return;
                    }

                    stopOrder =
                        newStopOrder;

                    targetOrder =
                        newTargetOrder;

                    activeStopPrice =
                        stopPrice;

                    activeTargetPrice =
                        targetPrice;

                    activeEffectiveTargetTicks =
                        effectiveTargetTicks;

                    executionStatus =
                        "WAITING PROTECTION";
                }

                UpdateExecutionMonitor();

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Submit(
                    new[]
                    {
                        newStopOrder,
                        newTargetOrder
                    }
                );

                PrintBotMessage(
                    "OCO BRACKET SUBMITTED"
                    + " | SL: "
                    + stopPrice.ToString("0.00")
                    + " | TP: "
                    + targetPrice.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION ERROR";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "PROTECTIVE ORDER ERROR: "
                    + ex.Message
                    + " | FLATTENING SIM POSITION."
                );

                try
                {
                    // Never call Flatten while holding executionStateLock.
                    account.Flatten(
                        new[]
                        {
                            instrument
                        }
                    );
                }
                catch (
                    Exception flattenEx
                )
                {
                    PrintBotMessage(
                        "EMERGENCY FLATTEN ERROR: "
                        + flattenEx.Message
                    );
                }
            }
            finally
            {
                lock (executionStateLock)
                {
                    protectiveBracketBuildInProgress =
                        false;
                }
            }
        }
        private bool TryBeginProtectiveChange(
            string owner,
            out long token)
        {
            token = 0;

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (
                    protectiveChangeInFlight &&
                    protectiveChangeStartedUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        protectiveChangeStartedUtc
                    ).TotalMilliseconds >
                        ProtectiveChangeTimeoutMs
                )
                {
                    protectiveChangeInFlight =
                        false;

                    activeProtectiveChangeToken =
                        0;

                    protectiveChangeOwner =
                        string.Empty;

                    protectiveChangeStartedUtc =
                        DateTime.MinValue;
                }

                if (protectiveChangeInFlight)
                {
                    return false;
                }

                protectiveChangeSequence++;

                token =
                    protectiveChangeSequence;

                protectiveChangeInFlight =
                    true;

                activeProtectiveChangeToken =
                    token;

                protectiveChangeOwner =
                    owner ?? string.Empty;

                protectiveChangeStartedUtc =
                    nowUtc;

                return true;
            }
        }
        private void EndProtectiveChange(
            long token)
        {
            if (token <= 0)
                return;

            lock (executionStateLock)
            {
                if (
                    !protectiveChangeInFlight ||
                    activeProtectiveChangeToken !=
                        token
                )
                {
                    return;
                }

                protectiveChangeInFlight =
                    false;

                activeProtectiveChangeToken =
                    0;

                protectiveChangeOwner =
                    string.Empty;

                protectiveChangeStartedUtc =
                    DateTime.MinValue;
            }
        }
        private bool IsOrderChangeable(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState ==
                    OrderState.Working ||
                order.OrderState ==
                    OrderState.Accepted;
        }

    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.07 - HARD PROTECTION WATCHDOG
    // =========================================================
    // Safety invariant:
    // A non-flat JJ profile may never remain exposed without a confirmed
    // protective STOP. A missing TARGET is also treated as an incomplete
    // bracket, but the STOP has absolute priority.
    //
    // The watchdog is independent of entry/order callbacks so it also covers
    // missed callbacks, race conditions, cancelled/rejected brackets and
    // temporary NinjaTrader order-state desynchronization.
    // =========================================================
    public partial class JJBotWindow
    {
        private DispatcherTimer hardProtectionWatchdogTimer;
        private DateTime hardProtectionMissingSinceUtc = DateTime.MinValue;
        private DateTime hardProtectionLastRetryUtc = DateTime.MinValue;
        private DateTime hardProtectionLastFlattenUtc = DateTime.MinValue;
        private int hardProtectionRetryCount;
        private bool hardProtectionEmergencyActive;
        // Independent of the completed trade's Flat/reset state.
        private volatile bool lateProtectiveFillEmergencyPending;
        private bool lateProtectiveFillObservedPosition;
        private string hardProtectionLastLogKey = string.Empty;
        private DateTime hardProtectionLastLogUtc = DateTime.MinValue;

        private const int HardProtectionWatchdogMilliseconds = 250;
        private const int HardProtectionInitialGraceMilliseconds = 500;
        // V1.7.111 - 3 s: the stop normally confirms in ~0.35 s, also at the open.
        private const int HardProtectionStopFailMilliseconds = 3000;
        private const int HardProtectionBracketFailMilliseconds = 3500;
        private const int HardProtectionRetryThrottleMilliseconds = 500;
        private const int HardProtectionLogThrottleMilliseconds = 750;
        private const int HardProtectionFlattenRetryMilliseconds = 1000;

        // V1.7.111 - this watchdog existed but nothing ever started it.
        // Started once per profile window, next to the orphan guard timer.
        private void V1111EnsureHardProtectionWatchdog()
        {
            if (v186IsDedicatedBrain || hardProtectionWatchdogTimer != null)
                return;

            try
            {
                StartHardProtectionWatchdog();
            }
            catch (Exception ex)
            {
                PrintBotMessage("HARD PROTECTION WATCHDOG START ERROR: " + ex.Message);
            }
        }

        private void StartHardProtectionWatchdog()
        {
            StopHardProtectionWatchdog();

            hardProtectionMissingSinceUtc = DateTime.MinValue;
            hardProtectionLastRetryUtc = DateTime.MinValue;
            hardProtectionLastFlattenUtc = DateTime.MinValue;
            hardProtectionRetryCount = 0;
            hardProtectionEmergencyActive = false;
            hardProtectionLastLogKey = string.Empty;
            hardProtectionLastLogUtc = DateTime.MinValue;

            hardProtectionWatchdogTimer =
                new DispatcherTimer(
                    DispatcherPriority.Send,
                    Dispatcher
                );

            hardProtectionWatchdogTimer.Interval =
                TimeSpan.FromMilliseconds(
                    HardProtectionWatchdogMilliseconds
                );

            hardProtectionWatchdogTimer.Tick +=
                HardProtectionWatchdogTimerTick;

            hardProtectionWatchdogTimer.Start();

            PrintBotMessage(
                "HARD PROTECTION WATCHDOG ARMED"
                + " | Every: "
                + HardProtectionWatchdogMilliseconds
                + "ms"
                + " | StopFail: "
                + HardProtectionStopFailMilliseconds
                + "ms"
                + " | BracketFail: "
                + HardProtectionBracketFailMilliseconds
                + "ms"
            );
        }

        private void StopHardProtectionWatchdog()
        {
            DispatcherTimer timer =
                hardProtectionWatchdogTimer;

            hardProtectionWatchdogTimer = null;

            if (timer == null)
                return;

            try
            {
                timer.Stop();
                timer.Tick -=
                    HardProtectionWatchdogTimerTick;
            }
            catch
            {
            }
        }

        private bool IsHardProtectionConfirmedState(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState == OrderState.Accepted ||
                order.OrderState == OrderState.Working ||
                order.OrderState == OrderState.PartFilled ||
                order.OrderState == OrderState.TriggerPending ||
                order.OrderState == OrderState.ChangePending ||
                order.OrderState == OrderState.ChangeSubmitted;
        }

        private void ScanHardProtectionOrders(
            Account account,
            Instrument instrument,
            int openQuantity,
            out bool stopLive,
            out bool targetLive,
            out int stopCoveredQty,
            out int targetCoveredQty)
        {
            stopLive = false;
            targetLive = false;
            stopCoveredQty = 0;
            targetCoveredQty = 0;

            if (
                account == null ||
                instrument == null ||
                openQuantity <= 0
            )
            {
                return;
            }

            string expectedStopName =
                GetProfileOrderName("JJ_STOP");

            string expectedTargetName =
                GetProfileOrderName("JJ_TARGET");

            try
            {
                lock (account.Orders)
                {
                    foreach (Order order in account.Orders)
                    {
                        if (
                            order == null ||
                            order.Instrument == null ||
                            order.Instrument.FullName !=
                                instrument.FullName ||
                            !IsHardProtectionConfirmedState(order)
                        )
                        {
                            continue;
                        }

                        int remainingQty =
                            Math.Max(
                                0,
                                Math.Abs(order.Quantity) -
                                Math.Abs(order.Filled)
                            );

                        if (remainingQty <= 0)
                            continue;

                        string orderName =
                            order.Name ?? string.Empty;

                        if (
                            string.Equals(
                                orderName,
                                expectedStopName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.StopPrice > 0
                        )
                        {
                            stopCoveredQty += remainingQty;
                        }
                        else if (
                            string.Equals(
                                orderName,
                                expectedTargetName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.LimitPrice > 0
                        )
                        {
                            targetCoveredQty += remainingQty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "HARD PROTECTION ORDER SCAN ERROR: "
                    + ex.Message
                );
            }

            stopLive =
                stopCoveredQty >= openQuantity;

            targetLive =
                targetCoveredQty >= openQuantity;
        }

        private void HardProtectionWatchdogTimerTick(
            object sender,
            EventArgs e)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat;

            try
            {
                isFlat =
                    TryGetSelectedInstrumentPosition(
                        out actualSide,
                        out actualQty,
                        out actualAverage
                    );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "HARD PROTECTION POSITION SCAN ERROR: "
                    + ex.Message
                );
                return;
            }

            if (
                isFlat ||
                actualSide == MarketPosition.Flat ||
                actualQty <= 0
            )
            {
                // A stale Flat snapshot must not disarm the pending emergency.
                if (lateProtectiveFillEmergencyPending && lateProtectiveFillObservedPosition)
                {
                    lateProtectiveFillEmergencyPending = false;
                    lateProtectiveFillObservedPosition = false;
                }
                hardProtectionMissingSinceUtc = DateTime.MinValue;
                hardProtectionLastRetryUtc = DateTime.MinValue;
                hardProtectionRetryCount = 0;
                hardProtectionEmergencyActive = false;
                hardProtectionLastLogKey = string.Empty;
                return;
            }

            // =====================================================
            // V1.7.30 - UNEXPECTED POSITION REVERSAL FAIL-SAFE
            // =====================================================
            // A protective stop/target/partial must only REDUCE the active
            // position. If the live account side ever flips to the opposite
            // side while JJ still owns an active trade lifecycle, treat it as
            // a protective overfill / stale-quantity emergency. Never allow
            // that accidental opposite position to become a new trade.
            MarketPosition trackedSide;

            lock (executionStateLock)
            {
                trackedSide = entryMarketPosition;
            }

            if (
                lateProtectiveFillEmergencyPending ||
                (trackedSide != MarketPosition.Flat && actualSide != trackedSide)
            )
            {
                if (lateProtectiveFillEmergencyPending && !lateProtectiveFillObservedPosition)
                {
                    lateProtectiveFillObservedPosition = true;
                    hardProtectionLastFlattenUtc = DateTime.MinValue;
                }
                DateTime reversalNowUtc = DateTime.UtcNow;

                if (!hardProtectionEmergencyActive)
                {
                    hardProtectionEmergencyActive = true;
                    SetPersistentDailyLock(
                        "UNEXPECTED POSITION REVERSAL"
                    );

                    lock (executionStateLock)
                    {
                        executionStatus =
                            "UNEXPECTED REVERSAL - FLATTENING";
                    }

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "CRITICAL UNEXPECTED POSITION REVERSAL"
                        + " | Tracked: " + trackedSide
                        + " | Actual: " + actualSide
                        + " " + actualQty
                        + " | Action: EMERGENCY FLATTEN + DAILY SAFETY LOCK"
                    );
                }

                if (
                    hardProtectionLastFlattenUtc == DateTime.MinValue ||
                    (reversalNowUtc - hardProtectionLastFlattenUtc)
                        .TotalMilliseconds >=
                        HardProtectionFlattenRetryMilliseconds
                )
                {
                    hardProtectionLastFlattenUtc = reversalNowUtc;

                    try
                    {
                        FlattenExecutionAccount(account, instrument);

                        PrintBotMessage(
                            "UNEXPECTED REVERSAL FLATTEN SENT"
                            + " | Account: " + account.Name
                            + " | Instrument: " + instrument.FullName
                        );
                    }
                    catch (Exception ex)
                    {
                        PrintBotMessage(
                            "UNEXPECTED REVERSAL FLATTEN ERROR: "
                            + ex.Message
                        );
                    }
                }

                return;
            }

            // V1.7.111 - only trades owned by the bot. A manual position with the bot
            // tracking nothing is the trader's own decision and is never touched.
            if (trackedSide == MarketPosition.Flat)
            {
                hardProtectionMissingSinceUtc = DateTime.MinValue;
                hardProtectionLastRetryUtc = DateTime.MinValue;
                hardProtectionRetryCount = 0;
                hardProtectionEmergencyActive = false;
                hardProtectionLastLogKey = string.Empty;
                return;
            }

            bool stopLive;
            bool targetLive;
            int stopCoveredQty;
            int targetCoveredQty;

            ScanHardProtectionOrders(
                account,
                instrument,
                actualQty,
                out stopLive,
                out targetLive,
                out stopCoveredQty,
                out targetCoveredQty
            );

            // V1.7.30 - protective orders must never cover MORE contracts
            // than the live position. Over-coverage can reverse the account if
            // a stop/target fills after a partial exit. Ask the existing bracket
            // synchronizer to resize immediately before declaring protection OK.
            bool protectiveOverCoverage =
                stopCoveredQty > actualQty ||
                targetCoveredQty > actualQty;

            if (protectiveOverCoverage)
            {
                // V1.7.111 - at most once per second.
                if (
                    hardProtectionLastRetryUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - hardProtectionLastRetryUtc).TotalMilliseconds < 1000
                )
                {
                    return;
                }

                hardProtectionLastRetryUtc = DateTime.UtcNow;

                PrintBotMessage(
                    "PROTECTIVE OVER-COVERAGE DETECTED"
                    + " | PositionQty: " + actualQty
                    + " | StopQty: " + stopCoveredQty
                    + " | TargetQty: " + targetCoveredQty
                    + " | Action: RESYNC BEFORE CONTINUING"
                );

                SyncProtectiveBracketToEntry(
                    actualAverage > 0
                        ? actualAverage
                        : entryFillPrice,
                    actualQty,
                    actualSide
                );

                return;
            }

            // V1.7.111 - the rule is the STOP. With partials the TARGET covers fewer contracts
            // than the position by design, so a short target must never close a winner.
            if (stopLive)
            {
                hardProtectionMissingSinceUtc = DateTime.MinValue;
                hardProtectionLastRetryUtc = DateTime.MinValue;
                hardProtectionRetryCount = 0;
                hardProtectionEmergencyActive = false;
                hardProtectionLastLogKey = string.Empty;
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;

            if (
                hardProtectionMissingSinceUtc ==
                    DateTime.MinValue
            )
            {
                hardProtectionMissingSinceUtc = nowUtc;
            }

            double missingMs =
                (nowUtc - hardProtectionMissingSinceUtc)
                    .TotalMilliseconds;

            string stateKey =
                (stopLive ? "S1" : "S0")
                + "|"
                + (targetLive ? "T1" : "T0")
                + "|Q"
                + actualQty
                + "|SQ"
                + stopCoveredQty
                + "|TQ"
                + targetCoveredQty;

            if (
                !string.Equals(
                    stateKey,
                    hardProtectionLastLogKey,
                    StringComparison.Ordinal
                ) ||
                hardProtectionLastLogUtc == DateTime.MinValue ||
                (nowUtc - hardProtectionLastLogUtc)
                    .TotalMilliseconds >=
                    HardProtectionLogThrottleMilliseconds
            )
            {
                hardProtectionLastLogKey = stateKey;
                hardProtectionLastLogUtc = nowUtc;

                PrintBotMessage(
                    "HARD PROTECTION WATCHDOG"
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                    + " | StopLive: "
                    + stopLive
                    + " (" + stopCoveredQty + "/" + actualQty + ")"
                    + " | TargetLive: "
                    + targetLive
                    + " (" + targetCoveredQty + "/" + actualQty + ")"
                    + " | MissingFor: "
                    + missingMs.ToString("0")
                    + "ms"
                );
            }

            // Give the normal fill -> OCO path a very short chance to finish.
            if (
                missingMs >=
                    HardProtectionInitialGraceMilliseconds &&
                !hardProtectionEmergencyActive &&
                (
                    hardProtectionLastRetryUtc == DateTime.MinValue ||
                    (nowUtc - hardProtectionLastRetryUtc)
                        .TotalMilliseconds >=
                        HardProtectionRetryThrottleMilliseconds
                )
            )
            {
                hardProtectionLastRetryUtc = nowUtc;
                hardProtectionRetryCount++;

                PrintBotMessage(
                    "HARD PROTECTION RETRY"
                    + " | Attempt: "
                    + hardProtectionRetryCount
                    + " | StopLive: "
                    + stopLive
                    + " | TargetLive: "
                    + targetLive
                    + " | Qty: "
                    + actualQty
                );

                // Only ask the existing bracket synchronizer to repair the
                // position. It owns all price/risk/never-worsen rules.
                SyncProtectiveBracketToEntry(
                    actualAverage > 0
                        ? actualAverage
                        : entryFillPrice,
                    actualQty,
                    actualSide
                );
            }

            bool stopFailure =
                !stopLive &&
                missingMs >=
                    HardProtectionStopFailMilliseconds;

            if (
                !stopFailure &&
                !hardProtectionEmergencyActive
            )
            {
                return;
            }

            if (!hardProtectionEmergencyActive)
            {
                hardProtectionEmergencyActive = true;

                SetPersistentDailyLock(
                    "PROTECTION FAILURE"
                );

                lock (executionStateLock)
                {
                    executionStatus =
                        "PROTECTION FAILURE - FLATTENING";
                }

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "CRITICAL PROTECTION FAILURE"
                    + " | StopLive: "
                    + stopLive
                    + " | TargetLive: "
                    + targetLive
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                    + " | Action: EMERGENCY FLATTEN + DAILY SAFETY LOCK"
                );
            }

            if (
                hardProtectionLastFlattenUtc != DateTime.MinValue &&
                (nowUtc - hardProtectionLastFlattenUtc)
                    .TotalMilliseconds <
                    HardProtectionFlattenRetryMilliseconds
            )
            {
                return;
            }

            try
            {
                // V1.7.111 - SafeFlatten keeps the double-close and exit-settle guards;
                // if it holds the close back, the next tick tries again.
                if (!SafeFlatten(account, instrument))
                    return;

                hardProtectionLastFlattenUtc = nowUtc;

                PrintBotMessage(
                    "HARD PROTECTION EMERGENCY FLATTEN SENT"
                    + " | Account: "
                    + account.Name
                    + " | Instrument: "
                    + instrument.FullName
                );
            }
            catch (Exception flattenEx)
            {
                PrintBotMessage(
                    "HARD PROTECTION FLATTEN ERROR: "
                    + flattenEx.Message
                    + " | Watchdog will retry while position remains open."
                );
            }
        }
    }
}

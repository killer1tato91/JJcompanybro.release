#region Using declarations
using System;
using System.Collections.Generic;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.36 - ANTI-HEDGING GUARD (prop-firm rule)
    // =========================================================
    // Prop firms forbid holding opposite positions on the same market across
    // accounts. Before any automatic entry, this profile checks:
    //   1. every connected account's OPEN position on the same underlying
    //      (MNQ and NQ count as the same market, MES/ES, etc.);
    //   2. entries just submitted by other JJ profiles (reserved intent, 10 s),
    //      which covers the instant before the fill appears as a position.
    // If anything is open or in flight in the OPPOSITE direction, the entry is
    // blocked ("HEDGE GUARD"). Same-direction positions are allowed.
    public partial class JJBotWindow
    {
        private static readonly object HedgeIntentSync = new object();

        private sealed class HedgeIntent
        {
            public bool IsLong;
            public DateTime UntilUtc;
            public string Profile;
        }

        private static readonly Dictionary<string, HedgeIntent> HedgeIntents =
            new Dictionary<string, HedgeIntent>(StringComparer.OrdinalIgnoreCase);

        private static string HedgeMarketKey(Instrument instrument)
        {
            if (instrument == null || instrument.MasterInstrument == null)
                return string.Empty;

            string n = (instrument.MasterInstrument.Name ?? string.Empty).Trim().ToUpperInvariant();

            switch (n)
            {
                case "MNQ": return "NQ";
                case "MES": return "ES";
                case "MYM": return "YM";
                case "M2K": return "RTY";
                case "MGC": return "GC";
                case "MCL": return "CL";
                default: return n;
            }
        }

        // Check + reserve are ONE atomic step under HedgeIntentSync, so two
        // profiles receiving opposite signals at the same instant can never
        // both pass.
        private bool IsHedgeBlocked(Instrument instrument, bool isLong, out string reason)
        {
            reason = string.Empty;
            string key = HedgeMarketKey(instrument);

            if (string.IsNullOrEmpty(key))
                return false;

            lock (HedgeIntentSync)
            {
                // 1) In-flight entries from other JJ profiles.
                HedgeIntent intent;

                if (HedgeIntents.TryGetValue(key, out intent) && intent != null)
                {
                    if (DateTime.UtcNow > intent.UntilUtc)
                    {
                        HedgeIntents.Remove(key);
                    }
                    else if (intent.IsLong != isLong &&
                             !string.Equals(intent.Profile, platformProfileId, StringComparison.OrdinalIgnoreCase))
                    {
                        reason = "OPPOSITE ENTRY IN FLIGHT | Profile " + intent.Profile;
                        return true;
                    }
                }

                // 2) Open positions in every connected account.
                try
                {
                    lock (Account.All)
                    {
                        foreach (Account a in Account.All)
                        {
                            if (a == null || ReferenceEquals(a, selectedAccount))
                                continue;

                            foreach (Position p in a.Positions)
                            {
                                if (p == null || p.Instrument == null || p.MarketPosition == MarketPosition.Flat)
                                    continue;

                                if (!string.Equals(HedgeMarketKey(p.Instrument), key, StringComparison.OrdinalIgnoreCase))
                                    continue;

                                bool positionLong = p.MarketPosition == MarketPosition.Long;

                                if (positionLong != isLong)
                                {
                                    reason = "OPPOSITE POSITION OPEN | Account " + a.Name + " " + p.MarketPosition + " " + p.Quantity;
                                    return true;
                                }
                            }
                        }
                    }
                }
                catch
                {
                    // If positions cannot be read, fail safe: block.
                    reason = "POSITIONS UNREADABLE (fail-safe)";
                    return true;
                }

                // 3) Clear: reserve this direction for 10 s.
                HedgeIntents[key] = new HedgeIntent
                {
                    IsLong = isLong,
                    UntilUtc = DateTime.UtcNow.AddSeconds(10),
                    Profile = platformProfileId ?? string.Empty
                };
            }

            return false;
        }

        private void ReserveHedgeIntent(Instrument instrument, bool isLong)
        {
            string key = HedgeMarketKey(instrument);

            if (string.IsNullOrEmpty(key))
                return;

            lock (HedgeIntentSync)
            {
                HedgeIntents[key] = new HedgeIntent
                {
                    IsLong = isLong,
                    UntilUtc = DateTime.UtcNow.AddSeconds(10),
                    Profile = platformProfileId ?? string.Empty
                };
            }
        }
    }
}

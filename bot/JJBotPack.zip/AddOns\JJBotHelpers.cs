﻿#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT HELPERS / MARKET UTILITIES
    // Stage 21 structural extraction only.
    //
    // Existing confidence calibration, direction resolution,
    // file/account/order helpers, re-entry guard, EMA/high-low,
    // market-state labels, platform helper calls and logging
    // utilities are moved exactly as-is.
    //
    // No thresholds, formulas, trading rules, timing, risk,
    // order behavior or execution behavior was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private int GetCalibratedSetupConfidence(
            string side,
            string structure,
            int technicalConfidence,
            out int sampleTrades,
            out double observedWinRate)
        {
            double historicalProbability;
            string reliability;
            int forcedResolved;
            double historicalWeight;

            return GetCalibratedSetupConfidence(
                side,
                structure,
                technicalConfidence,
                out sampleTrades,
                out observedWinRate,
                out historicalProbability,
                out reliability,
                out forcedResolved,
                out historicalWeight
            );
        }

        // =========================================================
        // V1.6.23 PHASE 8 - CONFIDENCE CALIBRATION V2
        //
        // Keep TECHNICAL SETUP QUALITY separate from historical
        // probability.  Historical evidence is deliberately shrunk toward
        // neutral when the sample is small.  Deferred forced-exit outcomes
        // can contribute only as low-weight supplemental evidence and can
        // never dominate real completed learning trades.
        // =========================================================
        private int GetCalibratedSetupConfidence(
            string side,
            string structure,
            int technicalConfidence,
            out int sampleTrades,
            out double observedWinRate,
            out double historicalProbability,
            out string reliability,
            out int forcedResolved,
            out double historicalWeight)
        {
            sampleTrades = 0;
            observedWinRate = 0;
            historicalProbability = 50.0;
            reliability = "TECHNICAL ONLY";
            forcedResolved = 0;
            historicalWeight = 0.0;

            int technical =
                Math.Max(
                    0,
                    Math.Min(99, technicalConfidence)
                );

            if (
                string.IsNullOrWhiteSpace(side) ||
                string.IsNullOrWhiteSpace(structure)
            )
            {
                return technical;
            }

            string key =
                GetLearningPatternKey(
                    side,
                    GetCurrentNewYorkTime(),
                    structure
                );

            JJBotLearningPattern pattern =
                FindLearningPattern(key);

            if (pattern == null)
            {
                return technical;
            }

            sampleTrades =
                Math.Max(0, pattern.ConfidenceTrades);

            forcedResolved =
                Math.Max(
                    0,
                    pattern.ForcedSignalWins +
                    pattern.ForcedSignalLosses
                );

            if (sampleTrades > 0)
            {
                observedWinRate =
                    (
                        (double)pattern.ConfidenceWins /
                        Math.Max(1, sampleTrades)
                    ) * 100.0;
            }

            // Bayesian shrinkage: 5 pseudo wins + 5 pseudo losses keeps
            // tiny samples from showing extreme "probabilities".
            const double PriorWins = 5.0;
            const double PriorLosses = 5.0;
            const double ForcedOutcomeWeight = 0.25;

            double weightedForcedWins = 0.0;
            double weightedForcedLosses = 0.0;

            // Require a meaningful forced-outcome sample before it can
            // influence calibration at all.
            if (forcedResolved >= 8)
            {
                weightedForcedWins =
                    pattern.ForcedSignalWins *
                    ForcedOutcomeWeight;

                weightedForcedLosses =
                    pattern.ForcedSignalLosses *
                    ForcedOutcomeWeight;
            }

            double effectiveWins =
                Math.Max(0, pattern.ConfidenceWins) +
                weightedForcedWins;

            double effectiveLosses =
                Math.Max(
                    0,
                    sampleTrades - pattern.ConfidenceWins
                ) +
                weightedForcedLosses;

            historicalProbability =
                (
                    PriorWins + effectiveWins
                ) /
                Math.Max(
                    1.0,
                    PriorWins + PriorLosses +
                    effectiveWins + effectiveLosses
                ) * 100.0;

            // Same evidence tiers already used by J&J, now surfaced as a
            // reliability label.  Below 15 real trades we do not alter the
            // displayed calibrated score at all.
            if (sampleTrades >= 50)
            {
                historicalWeight = 0.70;
                reliability = "STRONG";
            }
            else if (sampleTrades >= 30)
            {
                historicalWeight = 0.50;
                reliability = "CAUTION";
            }
            else if (sampleTrades >= 15)
            {
                historicalWeight = 0.30;
                reliability = "OBSERVE";
            }
            else
            {
                historicalWeight = 0.0;
                reliability = "TECHNICAL ONLY";
            }

            if (historicalWeight <= 0)
            {
                return technical;
            }

            double expectancy =
                pattern.ConfidenceNetPnL /
                Math.Max(1, sampleTrades);

            // PnL is a small tie-breaker only.  It cannot turn a weak
            // historical hit-rate into a high-probability setup.
            double expectancyAdjustment =
                Math.Max(
                    -3.0,
                    Math.Min(
                        3.0,
                        expectancy / 15.0
                    )
                );

            double calibrated =
                (
                    technical *
                    (1.0 - historicalWeight)
                ) +
                (
                    historicalProbability *
                    historicalWeight
                ) +
                expectancyAdjustment;

            return
                Math.Max(
                    0,
                    Math.Min(
                        99,
                        (int)Math.Round(calibrated)
                    )
                );
        }
        private bool IsLateAutomaticEntry(
            DateTime signalNyTime,
            bool momentumEntry,
            bool openingEntry,
            bool highConvictionMomentum,
            out int ageSeconds,
            out int maxSeconds)
        {
            ageSeconds = 0;
            maxSeconds =
                momentumEntry
                    ? (
                        highConvictionMomentum
                            ? HighConvictionMomentumLateEntryMaxSeconds
                            : MomentumLateEntryMaxSeconds
                      )
                    : openingEntry
                        ? OpeningLateEntryMaxSeconds
                        : StructureLateEntryMaxSeconds;

            DateTime strategyClockNy =
                GetCurrentNewYorkTime();

            double rawAgeSeconds =
                (
                    strategyClockNy -
                    signalNyTime
                ).TotalSeconds;

            // A bar timestamp can be a few seconds ahead because of feed/
            // scheduler timing. Never classify a future timestamp as late.
            ageSeconds =
                Math.Max(
                    0,
                    (int)Math.Floor(
                        rawAgeSeconds
                    )
                );

            return
                ageSeconds >
                    maxSeconds;
        }
        private string ResolveEffectiveDirection(
            DateTime nyTime,
            double referencePrice,
            bool bullishTrend,
            bool bearishTrend,
            bool aboveVwap,
            bool belowVwap)
        {
            if (
                !string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                autoResolvedDirection =
                    activeDirection;

                autoDirectionReason =
                    "MANUAL "
                    + activeDirection;

                return activeDirection;
            }

            string resolved =
                "NONE";

            string reason =
                "NO CLEAR CONTEXT";

            if (
                IsOpeningEntryWindow(nyTime) &&
                premarketContextReady &&
                premarketContextDateNy == nyTime.Date
            )
            {
                bool pmBull = premarketContextBiasScore >= 2;
                bool pmBear = premarketContextBiasScore <= -2;

                if (pmBull && bullishTrend && aboveVwap && referencePrice >= premarketContextMid)
                {
                    resolved = "LONG ONLY";
                    reason = "PREMARKET " + premarketContextBias
                        + " + ABOVE PM MID + BULLISH + ABOVE VWAP";
                }
                else if (pmBear && bearishTrend && belowVwap && referencePrice <= premarketContextMid)
                {
                    resolved = "SHORT ONLY";
                    reason = "PREMARKET " + premarketContextBias
                        + " + BELOW PM MID + BEARISH + BELOW VWAP";
                }
            }

            if (
                resolved == "NONE" &&
                IsOpeningEntryWindow(
                    nyTime
                ) &&
                preEntryRangeReady &&
                preEntryRangeHigh >
                    preEntryRangeLow
            )
            {
                double midpoint =
                    (
                        preEntryRangeHigh +
                        preEntryRangeLow
                    ) / 2.0;

                if (
                    referencePrice > midpoint &&
                    bullishTrend &&
                    aboveVwap
                )
                {
                    resolved =
                        "LONG ONLY";

                    reason =
                        "PRE-ENTRY ABOVE MID + BULLISH + ABOVE VWAP";
                }
                else if (
                    referencePrice < midpoint &&
                    bearishTrend &&
                    belowVwap
                )
                {
                    resolved =
                        "SHORT ONLY";

                    reason =
                        "PRE-ENTRY BELOW MID + BEARISH + BELOW VWAP";
                }
            }

            if (resolved == "NONE")
            {
                if (
                    bullishTrend &&
                    aboveVwap &&
                    !bearishTrend
                )
                {
                    resolved =
                        "LONG ONLY";

                    reason =
                        "M5 BULLISH + ABOVE VWAP";
                }
                else if (
                    bearishTrend &&
                    belowVwap &&
                    !bullishTrend
                )
                {
                    resolved =
                        "SHORT ONLY";

                    reason =
                        "M5 BEARISH + BELOW VWAP";
                }
            }

            // V1.6.23 PHASE 4 - regime-aware AUTO.
            // Opening resolutions are preserved inside the helper.
            string regimeResolvedDirection;
            string regimeResolvedReason;

            ApplyRangeControlledAutoDirection(
                nyTime,
                resolved,
                reason,
                out regimeResolvedDirection,
                out regimeResolvedReason
            );

            resolved = regimeResolvedDirection;
            reason = regimeResolvedReason;

            // V1.6.14 LOG FIX
            // IMPORTANT: compare against the LAST LOGGED state, not against
            // autoResolvedDirection. The fast Range engine is allowed to set
            // autoResolvedDirection temporarily (for Aggressive/Extreme R20),
            // so comparing against the live state caused repeated
            // "Resolved: NONE" messages in the same second.
            bool directionChanged =
                !string.Equals(
                    lastLoggedAutoDirection,
                    resolved,
                    StringComparison.OrdinalIgnoreCase
                );

            autoResolvedDirection =
                resolved;

            autoDirectionReason =
                reason;

            if (directionChanged)
            {
                lastLoggedAutoDirection =
                    resolved;

                lastLoggedAutoDirectionReason =
                    reason;

                lastAutoDirectionLogUtc =
                    DateTime.UtcNow;

                PrintBotMessage(
                    "AUTO DIRECTION"
                    + " | Resolved: "
                    + autoResolvedDirection
                    + " | Reason: "
                    + autoDirectionReason
                );
            }

            return resolved;
        }
        private string MakeSafeFileName(
            string value)
        {
            if (
                string.IsNullOrWhiteSpace(
                    value
                )
            )
            {
                return "unknown";
            }

            char[] invalidChars =
                Path.GetInvalidFileNameChars();

            foreach (
                char invalidChar
                in invalidChars
            )
            {
                value =
                    value.Replace(
                        invalidChar,
                        '_'
                    );
            }

            value =
                value.Replace(
                    ' ',
                    '_'
                );

            return value;
        }
        private void EnsureTradingDay(
            DateTime nyTime)
        {
            // =====================================================
            // WEEKEND HISTORICAL-CALLBACK GUARD
            // =====================================================
            // On Saturday / Sunday before the 18:00 ET futures reopen,
            // NinjaTrader can still deliver historical Friday bars while
            // the data engine initializes. Those old bar timestamps must
            // NEVER resurrect Friday as the active runtime session after
            // JJBotPersistence has intentionally cleared weekend state.
            //
            // Use the REAL current NY clock for this guard, not nyTime,
            // because nyTime may belong to a historical Friday bar.
            DateTime currentNy =
                GetCurrentNewYorkTime();

            if (IsWeekendMarketClosed(currentNy))
            {
                return;
            }

            DateTime sessionDate =
                GetTradingSessionDate(
                    nyTime
                );
            // Prevent older/historical callbacks from moving the
            // active NY trading day backwards and resetting counters.
            if (
                activeTradingDate !=
                    DateTime.MinValue &&
                sessionDate <=
                    activeTradingDate
            )
            {
                return;
            }

            activeTradingDate =
                sessionDate;

            tradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                pendingEntrySession = "OUTSIDE";
            botDailyGrossPnL = 0;
            botDailyFees = 0;
            botDailyPnL = 0;
            botUnrealizedPnL = 0;
            dailyPeakTotalPnL = 0;
            dailyProtectedProfitFloor = 0;
            dailyProfitFloorArmed = false;
            lastLoggedProtectedProfitFloor = 0;

            persistentDailyLocked =
                false;

            persistentDailyLockReason =
                string.Empty;

            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;

            dailyTargetProtectionArmed = false;
            lastDailyTargetProtectionStopPrice = 0;

            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;
            premarketForceFlatSentToday = false;
            premarketForceFlatDateNy = DateTime.MinValue;

            lastExecutedSignalBar =
                DateTime.MinValue;

            consumedBullishStructureSetupKey =
                string.Empty;

            consumedBearishStructureSetupKey =
                string.Empty;

            consumedBullishStructureConfirmTime =
                DateTime.MinValue;

            consumedBearishStructureConfirmTime =
                DateTime.MinValue;

            pendingStructureSetupKey =
                string.Empty;

            pendingStructureConfirmTime =
                DateTime.MinValue;

            pendingEntryIsOpening = false;
            activeTradeIsOpening = false;
            pendingEntryIsPremarket = false;
            activeTradeIsPremarket = false;
            openingTradeTakenToday = false;
            openingRangeReady = false;
            openingRangeHigh = 0;
            openingRangeLow = 0;
            openingRangeBarTimeNy = DateTime.MinValue;

            premarketRangeReady = false;
            premarketRangeHigh = 0;
            premarketRangeLow = 0;
            premarketRangeDateNy = DateTime.MinValue;
            premarketRangeLastM5TimeNy = DateTime.MinValue;
            lastPremarketChaseBlockLogKey = string.Empty;

            preEntryRangeReady = false;
            preEntryRangeHigh = 0;
            preEntryRangeLow = 0;
            preEntryRangeDateNy = DateTime.MinValue;
            openingRangeGuardBlocked = false;
            openingRangeGuardReason = string.Empty;
            openingRangeGuardDateNy = DateTime.MinValue;
            lastLateEntryBlockLogKey = string.Empty;
            openingRangeLoggedDate = DateTime.MinValue;

            lastAutomaticTradeExitNy =
                DateTime.MinValue;

            lastAutomaticTradeExitRangeBarTime =
                DateTime.MinValue;

            lastAutomaticTradeExitWasBreakeven =
                false;

            lastReentryBlockLogKey =
                string.Empty;

            lastPriceChaseBlockLogKey =
                string.Empty;

            lastOpeningContextBlockLogKey =
                string.Empty;

            lastFreshFlowConflictLogKey =
                string.Empty;

            SavePersistentDailyState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (grossPnlText != null)
                        grossPnlText.Text = "$0.00";

                    if (feesPnlText != null)
                        feesPnlText.Text = "$0.00";

                    if (pnlText != null)
                        pnlText.Text = "$0.00";

                    if (unrealizedPnlText != null)
                        unrealizedPnlText.Text = "$0.00";

                    if (totalPnlText != null)
                        totalPnlText.Text = "$0.00";

                    if (tradesText != null)
                        tradesText.Text =
                            "AM 0/"
                            + activeMaxTrades
                            + " | PM 0/"
                            + activeMaxTrades;
                })
            );

            PrintBotMessage(
                "NEW NY TRADING SESSION: "
                + sessionDate.ToString(
                    "yyyy-MM-dd"
                )
            );
        }
        private bool IsSelectedInstrumentFlat()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return false;
            }

            lock (
                selectedAccount.Positions
            )
            {
                foreach (
                    Position position
                    in selectedAccount.Positions
                )
                {
                    if (
                        position == null ||
                        position.Instrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        position.Instrument.FullName ==
                            selectedInstrument.FullName
                    )
                    {
                        return
                            position.MarketPosition ==
                            MarketPosition.Flat;
                    }
                }
            }

            // No position object for this instrument means flat.
            return true;
        }
        private string GetProfileOrderPrefix()
        {
            int profileNumber = 1;

            if (
                !string.IsNullOrWhiteSpace(
                    platformProfileId
                )
            )
            {
                Match match =
                    Regex.Match(
                        platformProfileId,
                        @"profile-(\d+)",
                        RegexOptions.IgnoreCase
                    );

                int parsed;

                if (
                    match.Success &&
                    int.TryParse(
                        match.Groups[1].Value,
                        out parsed
                    ) &&
                    parsed >= 1 &&
                    parsed <= 5
                )
                {
                    profileNumber = parsed;
                }
            }

            return "P" + profileNumber + "_";
        }
        private string GetProfileOrderName(
            string baseName)
        {
            return
                GetProfileOrderPrefix()
                + (baseName ?? string.Empty);
        }
        private bool IsAnyProfileBotOrder(
            string orderName)
        {
            return
                !string.IsNullOrWhiteSpace(orderName) &&
                Regex.IsMatch(
                    orderName,
                    @"^P[1-5]_JJ_",
                    RegexOptions.IgnoreCase
                );
        }
        private bool IsOwnProfileBotOrder(
            string orderName)
        {
            return
                !string.IsNullOrWhiteSpace(orderName) &&
                orderName.StartsWith(
                    GetProfileOrderPrefix() + "JJ_",
                    StringComparison.OrdinalIgnoreCase
                );
        }
        private bool IsAutomaticReentryBlocked(
            bool isLong,
            DateTime signalBarTime,
            bool momentumEntry,
            bool highConvictionMomentum,
            out string reason)
        {
            reason =
                string.Empty;

            if (
                lastAutomaticTradeExitNy ==
                    DateTime.MinValue
            )
            {
                return false;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            double elapsedSeconds =
                (
                    nowNy -
                    lastAutomaticTradeExitNy
                ).TotalSeconds;

            if (
                elapsedSeconds <
                    AutomaticReentryCooldownSeconds
            )
            {
                bool strongBeReentryAllowed =
                    momentumEntry &&
                    highConvictionMomentum &&
                    lastAutomaticTradeExitWasBreakeven &&
                    elapsedSeconds >=
                        StrongMomentumReentryMinSeconds;

                if (!strongBeReentryAllowed)
                {
                    int remaining =
                        Math.Max(
                            1,
                            AutomaticReentryCooldownSeconds -
                            (int)Math.Floor(
                                Math.Max(
                                    0,
                                    elapsedSeconds
                                )
                            )
                        );

                    reason =
                        "COOLDOWN "
                        + remaining
                        + "s";

                    return true;
                }

                PrintBotMessage(
                    "REENTRY EARLY REARM"
                    + " | Prior exit: PRICE BE"
                    + " | Strong momentum: YES"
                    + " | Elapsed: "
                    + ((int)elapsedSeconds)
                    + "s"
                );
            }

            // V1.6.10 - SAME-SIDE LOSS REARM.
            // A simple 60-second timer is not enough after a true loss. The
            // same direction must return with high-conviction momentum. This
            // still allows a real second impulse (for example the valid 3/5
            // with normal volume seen on 2026-08-19), but blocks weak repeats.
            string requestedSide =
                isLong
                    ? "LONG"
                    : "SHORT";

            if (
                lastAutomaticTradeExitWasLoss &&
                string.Equals(
                    lastAutomaticTradeExitSide,
                    requestedSide,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                !highConvictionMomentum
            )
            {
                reason =
                    "SAME-SIDE LOSS - WAIT FRESH HIGH-CONVICTION EXPANSION";

                return true;
            }

            // Momentum must additionally wait for a Range-20 signal bar
            // strictly newer than the Range bar active when the prior
            // automatic trade closed.
            if (
                momentumEntry &&
                lastAutomaticTradeExitRangeBarTime !=
                    DateTime.MinValue &&
                signalBarTime <=
                    lastAutomaticTradeExitRangeBarTime
            )
            {
                reason =
                    "WAIT NEW RANGE BAR";

                return true;
            }

            return false;
        }
        private double RoundToInstrumentTick(
            double price)
        {
            if (
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return price;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return price;

            return
                Math.Round(
                    price / tickSize,
                    0,
                    MidpointRounding.AwayFromZero
                )
                * tickSize;
        }
        private bool TryGetSelectedInstrumentPosition(
            out MarketPosition marketPosition,
            out int quantity,
            out double averagePrice)
        {
            marketPosition = MarketPosition.Flat;
            quantity = 0;
            averagePrice = 0;

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return true;
            }

            lock (selectedAccount.Positions)
            {
                foreach (Position position in selectedAccount.Positions)
                {
                    if (
                        position == null ||
                        position.Instrument == null ||
                        position.Instrument.FullName !=
                            selectedInstrument.FullName
                    )
                    {
                        continue;
                    }

                    marketPosition = position.MarketPosition;
                    quantity = position.Quantity;
                    averagePrice = position.AveragePrice;

                    return
                        marketPosition == MarketPosition.Flat ||
                        quantity <= 0;
                }
            }

            return true;
        }
        private void ResetExecutionMonitor()
        {
            lock (executionStateLock)
            {
                entryFillPrice = 0;
                activeStopPrice = 0;
                activeTargetPrice = 0;
                entryQuantity = 0;
                activeEffectiveTargetTicks = 0;
                activeExitQuantity = 0;
                activeExitGrossPnL = 0;
                activeExitCommission = 0;
                activeEntryCommission = 0;

                pendingTradeSetupConfidence = 0;
                pendingTradeSetupQuality = string.Empty;
                pendingTradeSetupTiming = string.Empty;
                pendingTradeManipulationState = string.Empty;
                activeTradeSetupConfidence = 0;
                activeTradeSetupQuality = string.Empty;
                activeTradeSetupTiming = string.Empty;
                activeTradeManipulationState = string.Empty;

                protectiveChangeInFlight = false;
                activeProtectiveChangeToken = 0;
                protectiveChangeOwner =
                    string.Empty;
                protectiveChangeStartedUtc =
                    DateTime.MinValue;

                botUnrealizedPnL = 0;
                riskFlattenSent = false;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                entryMarketPosition =
                    MarketPosition.Flat;

                executionStatus =
                    "WAITING";

                activeEntryUsesMomentumTrailing =
                    false;

                momentumTrailingStage =
                    0;

                lastMomentumTrailingStopPrice =
                    0;

                activeStrongMomentumProtection =
                    false;

                activeBreakEvenTriggerTicks =
                    MomentumBreakEvenTriggerTicks;

                lastMomentumTrailingChangeUtc =
                    DateTime.MinValue;

                dailyTargetProtectionArmed =
                    false;

                lastDailyTargetProtectionStopPrice =
                    0;

                lastDailyTargetProtectionChangeUtc =
                    DateTime.MinValue;
            }

            UpdateExecutionMonitor();
        }
        private double GetHighestHigh(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double highest =
                bars.GetHigh(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetHigh(i);

                if (
                    value > highest
                )
                {
                    highest =
                        value;
                }
            }

            return highest;
        }
        private double GetLowestLow(
            Bars bars,
            int startIndex,
            int endIndex)
        {
            if (
                bars == null ||
                startIndex < 0 ||
                endIndex < startIndex ||
                endIndex >= bars.Count
            )
            {
                return 0;
            }

            double lowest =
                bars.GetLow(
                    startIndex
                );

            for (
                int i =
                    startIndex + 1;
                i <= endIndex;
                i++
            )
            {
                double value =
                    bars.GetLow(i);

                if (
                    value < lowest
                )
                {
                    lowest =
                        value;
                }
            }

            return lowest;
        }
        private string GetManipulationState(
            bool isLong,
            string liquidityState,
            string structureState)
        {
            string liquidity =
                (liquidityState ?? string.Empty)
                    .ToUpperInvariant();

            string structure =
                (structureState ?? string.Empty)
                    .ToUpperInvariant();

            bool bullishStructure =
                structure.Contains("BULLISH");

            bool bearishStructure =
                structure.Contains("BEARISH");

            // Liquidity sweep + reversal structure in the same direction
            // is treated as manipulation confirmation, not a standalone trigger.
            if (
                isLong &&
                liquidity.Contains("LOW SWEPT") &&
                bullishStructure
            )
            {
                return "CONFIRMED WITH SETUP";
            }

            if (
                !isLong &&
                liquidity.Contains("HIGH SWEPT") &&
                bearishStructure
            )
            {
                return "CONFIRMED WITH SETUP";
            }

            // Opposite sweep/reversal combination is a warning only in V1.
            if (
                isLong &&
                liquidity.Contains("HIGH SWEPT") &&
                bearishStructure
            )
            {
                return "OPPOSING RISK";
            }

            if (
                !isLong &&
                liquidity.Contains("LOW SWEPT") &&
                bullishStructure
            )
            {
                return "OPPOSING RISK";
            }

            return "NONE";
        }
        private void CalculateAggressionState(
            Bars bars,
            int closedBarIndex,
            double tickSize,
            double rangeRatio,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            bool highBreakout,
            bool lowBreakout,
            out int longAggressionScore,
            out int shortAggressionScore,
            out int longDirectionalBars,
            out int shortDirectionalBars,
            out double longDisplacementTicks,
            out double shortDisplacementTicks)
        {
            longAggressionScore = 0;
            shortAggressionScore = 0;
            longDirectionalBars = 0;
            shortDirectionalBars = 0;
            longDisplacementTicks = 0;
            shortDisplacementTicks = 0;

            if (
                bars == null ||
                tickSize <= 0 ||
                closedBarIndex <
                    AggressionLookbackBars + 1
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            bool bullishBody =
                close > open &&
                bodyRatio >=
                    AggressionMinBodyRatio;

            bool bearishBody =
                close < open &&
                bodyRatio >=
                    AggressionMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    AggressionMinRangeRatio;

            bool volumeExpanded =
                volumeRatio >=
                    AggressionMinVolumeRatio;

            bool slopeUp =
                slopeTicks >=
                    AggressionMinSlopeTicks;

            bool slopeDown =
                slopeTicks <=
                    -AggressionMinSlopeTicks;

            if (bullishBody)
                longAggressionScore++;

            if (bearishBody)
                shortAggressionScore++;

            if (rangeExpanded)
            {
                longAggressionScore++;
                shortAggressionScore++;
            }

            if (volumeExpanded)
            {
                longAggressionScore++;
                shortAggressionScore++;
            }

            if (slopeUp)
                longAggressionScore++;

            if (slopeDown)
                shortAggressionScore++;

            if (highBreakout)
                longAggressionScore++;

            if (lowBreakout)
                shortAggressionScore++;

            int startIndex =
                Math.Max(
                    1,
                    closedBarIndex -
                        AggressionLookbackBars + 1
                );

            for (
                int i = startIndex;
                i <= closedBarIndex;
                i++
            )
            {
                double currentClose =
                    bars.GetClose(i);

                double previousClose =
                    bars.GetClose(i - 1);

                if (
                    currentClose >
                        previousClose
                )
                {
                    longDirectionalBars++;
                }
                else if (
                    currentClose <
                        previousClose
                )
                {
                    shortDirectionalBars++;
                }
            }

            int displacementStart =
                Math.Max(
                    0,
                    closedBarIndex -
                        AggressionLookbackBars
                );

            double displacement =
                close -
                bars.GetClose(
                    displacementStart
                );

            longDisplacementTicks =
                Math.Max(
                    0,
                    displacement /
                        tickSize
                );

            shortDisplacementTicks =
                Math.Max(
                    0,
                    -displacement /
                        tickSize
                );
        }
        private void CalculateSessionMoveExtensionTicks(
            Bars bars,
            int closedBarIndex,
            DateTime currentNyTime,
            double tickSize,
            out double upMoveTicks,
            out double downMoveTicks)
        {
            upMoveTicks = 0;
            downMoveTicks = 0;

            if (
                bars == null ||
                tickSize <= 0 ||
                closedBarIndex < 0
            )
            {
                return;
            }

            double sessionHigh =
                double.MinValue;

            double sessionLow =
                double.MaxValue;

            int firstIndex =
                Math.Max(
                    0,
                    closedBarIndex -
                        ExhaustionSessionScanMaxBars
                );

            for (
                int i = closedBarIndex;
                i >= firstIndex;
                i--
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date !=
                        currentNyTime.Date
                )
                {
                    break;
                }

                int timeInt =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeInt <
                        PremarketSessionStart
                )
                {
                    break;
                }

                sessionHigh =
                    Math.Max(
                        sessionHigh,
                        bars.GetHigh(i)
                    );

                sessionLow =
                    Math.Min(
                        sessionLow,
                        bars.GetLow(i)
                    );
            }

            if (
                sessionHigh ==
                    double.MinValue ||
                sessionLow ==
                    double.MaxValue
            )
            {
                return;
            }

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            upMoveTicks =
                Math.Max(
                    0,
                    (close - sessionLow) /
                        tickSize
                );

            downMoveTicks =
                Math.Max(
                    0,
                    (sessionHigh - close) /
                        tickSize
                );
        }
        private void LogPostMoveExhaustionBlock(
            bool isLong,
            DateTime nyTime,
            double moveTicks,
            double volumeRatio,
            double bodyRatio,
            int momentumScore)
        {
            string side =
                isLong
                    ? "LONG"
                    : "SHORT";

            string key =
                side
                + "|"
                + nyTime.ToString(
                    "yyyyMMddHHmm"
                )
                + "|"
                + Math.Floor(
                    moveTicks / 100.0
                  ).ToString(
                    CultureInfo.InvariantCulture
                  );

            if (
                string.Equals(
                    key,
                    lastExhaustionBlockLogKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastExhaustionBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - POST-MOVE EXHAUSTION"
                + " | Side: "
                + side
                + " | Move: "
                + moveTicks.ToString("0")
                + "t"
                + " | R20: "
                + momentumScore
                + "/5"
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | Body "
                + (bodyRatio * 100.0).ToString("0")
                + "%"
                + " | Reason: mature move without fresh aggression"
            );
        }
        private void LogPullbackWait(
            bool isLong,
            DateTime nyTime,
            double extensionTicks,
            double maxExtensionTicks,
            int momentumScore)
        {
            string side = isLong ? "LONG" : "SHORT";
            string key =
                side + "|" + nyTime.ToString("yyyyMMddHHmmss") + "|" + momentumScore;

            if (string.Equals(key, lastPullbackWaitLogKey, StringComparison.Ordinal))
                return;

            lastPullbackWaitLogKey = key;

            PrintBotMessage(
                "WAIT PULLBACK - ENTRY EXTENDED"
                + " | Side: " + side
                + " | R20: " + momentumScore + "/5"
                + " | EMA9 Extension: " + extensionTicks.ToString("0") + "t"
                + " | Max: " + maxExtensionTicks.ToString("0") + "t"
                + " | Action: do not chase; wait later valid signal"
            );
        }
        private double CalculateEma(
            Bars bars,
            int period,
            int endIndex)
        {
            if (
                bars == null ||
                period <= 0 ||
                endIndex < 0 ||
                bars.Count <= 0
            )
            {
                return 0;
            }

            int safeEndIndex =
                Math.Min(
                    endIndex,
                    bars.Count - 1
                );

            if (safeEndIndex < 0)
                return 0;

            DateTime firstBarTime;

            try
            {
                firstBarTime =
                    bars.GetTime(0);
            }
            catch
            {
                firstBarTime =
                    DateTime.MinValue;
            }

            double multiplier =
                2.0 / (period + 1.0);

            lock (emaCacheLock)
            {
                Dictionary<int, EmaCacheState> periodCaches;

                if (
                    !emaCaches.TryGetValue(
                        bars,
                        out periodCaches
                    ) ||
                    periodCaches == null
                )
                {
                    periodCaches =
                        new Dictionary<int, EmaCacheState>();

                    emaCaches[bars] =
                        periodCaches;
                }

                EmaCacheState cache;

                if (
                    !periodCaches.TryGetValue(
                        period,
                        out cache
                    ) ||
                    cache == null
                )
                {
                    cache =
                        new EmaCacheState();

                    periodCaches[period] =
                        cache;
                }

                // BarsRequest may roll its internal history window.
                // If bar zero changes, discard the old EMA seed and
                // rebuild once from the new window.
                if (
                    cache.FirstBarTime !=
                        firstBarTime ||
                    cache.Values.Count >
                        bars.Count
                )
                {
                    cache.FirstBarTime =
                        firstBarTime;

                    cache.Values.Clear();
                }

                while (
                    cache.Values.Count <=
                        safeEndIndex
                )
                {
                    int index =
                        cache.Values.Count;

                    double close =
                        bars.GetClose(
                            index
                        );

                    if (index == 0)
                    {
                        cache.Values.Add(
                            close
                        );
                    }
                    else
                    {
                        double previousEma =
                            cache.Values[
                                index - 1
                            ];

                        double ema =
                            (
                                close -
                                previousEma
                            )
                            * multiplier
                            + previousEma;

                        cache.Values.Add(
                            ema
                        );
                    }
                }

                return cache.Values[
                    safeEndIndex
                ];
            }
        }
        private void ClearEmaCaches()
        {
            lock (emaCacheLock)
            {
                emaCaches.Clear();
            }
        }
        private void ReadPlatformCommandRequest(
            string endpoint,
            bool useLocalResultRoute)
        {
            string responseText =
                string.Empty;

            try
            {
                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "GET";

                ApplyPlatformAuthorizationHeader(
                    request
                );

                request.Accept =
                    "application/json";

                request.Timeout =
                    2000;

                request.ReadWriteTimeout =
                    2000;

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                using (
                    Stream stream =
                        response.GetResponseStream()
                )
                using (
                    StreamReader reader =
                        new StreamReader(
                            stream,
                            Encoding.UTF8
                        )
                )
                {
                    responseText =
                        reader.ReadToEnd();
                }

                if (
                    string.IsNullOrWhiteSpace(
                        responseText
                    ) ||
                    responseText.Trim() == "[]"
                )
                {
                    return;
                }

                string commandId =
                    ExtractJsonStringValue(
                        responseText,
                        "id"
                    );

                string commandType =
                    ExtractJsonStringValue(
                        responseText,
                        "type"
                    )
                        .Trim()
                        .ToUpperInvariant();

                string commandAccount =
                    ExtractJsonStringValue(
                        responseText,
                        "account"
                    );

                string commandInstrument =
                    ExtractJsonStringValue(
                        responseText,
                        "instrument"
                    );

                string commandQuery =
                    ExtractJsonStringValue(
                        responseText,
                        "query"
                    );

                string commandStrategy =
                    ExtractJsonStringValue(
                        responseText,
                        "strategy"
                    );

                string commandDirection =
                    ExtractJsonStringValue(
                        responseText,
                        "direction"
                    );

                int commandContracts =
                    ExtractJsonIntValue(
                        responseText,
                        "contracts",
                        1
                    );

                int commandStopTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "stopTicks",
                        100
                    );

                int commandTargetTicks =
                    ExtractJsonIntValue(
                        responseText,
                        "targetTicks",
                        150
                    );

                int commandMaxTrades =
                    ExtractJsonIntValue(
                        responseText,
                        "maxTradesPerSession",
                        2
                    );

                double commandDailyTarget =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyTarget",
                        300
                    );

                double commandDailyLoss =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dailyLoss",
                        200
                    );

                double commandDollarRiskCap =
                    ExtractJsonDoubleValue(
                        responseText,
                        "dollarRiskCap",
                        100
                    );

                if (
                    string.IsNullOrWhiteSpace(
                        commandId
                    ) ||
                    string.IsNullOrWhiteSpace(
                        commandType
                    )
                )
                {
                    return;
                }

                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            ExecutePlatformCommand(
                                commandId,
                                commandType,
                                commandAccount,
                                commandInstrument,
                                commandQuery,
                                commandStrategy,
                                commandDirection,
                                commandContracts,
                                commandStopTicks,
                                commandTargetTicks,
                                commandMaxTrades,
                                commandDailyTarget,
                                commandDailyLoss,
                                commandDollarRiskCap,
                                useLocalResultRoute
                            );
                        }
                    )
                );
            }
            catch (WebException)
            {
                // Backend may be restarting. Telemetry heartbeat already
                // exposes the disconnected state, so do not spam the log.
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "BOT COMMAND ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformCommandRequestInFlight =
                    false;
            }
        }
        private string[] SearchNinjaInstruments(
            string query)
        {
            string normalizedQuery =
                (query ?? string.Empty)
                    .Trim();

            if (
                string.IsNullOrWhiteSpace(
                    normalizedQuery
                )
            )
            {
                return new string[0];
            }

            string upperQuery =
                normalizedQuery
                    .ToUpperInvariant();

            string masterQuery =
                upperQuery
                    .Split(
                        new char[]
                        {
                            ' ',
                            '\t'
                        },
                        StringSplitOptions
                            .RemoveEmptyEntries
                    )
                    .FirstOrDefault()
                ?? upperQuery;

            List<string> results =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            Action<string> addMatch =
                delegate(
                    string fullName)
                {
                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        return;
                    }

                    if (
                        fullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0 &&
                        fullName.IndexOf(
                            masterQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) < 0
                    )
                    {
                        return;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        results.Add(
                            fullName
                        );
                    }
                };

            // 1) Search instruments already materialized in NinjaTrader.
            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string masterName =
                        instrument
                            .MasterInstrument
                            .Name
                        ?? string.Empty;

                    string description =
                        instrument
                            .MasterInstrument
                            .Description
                        ?? string.Empty;

                    if (
                        instrument.FullName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        masterName.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0 ||
                        description.IndexOf(
                            normalizedQuery,
                            StringComparison.OrdinalIgnoreCase
                        ) >= 0
                    )
                    {
                        addMatch(
                            instrument.FullName
                        );
                    }
                }
            }
            catch
            {
            }

            // 2) Ask NinjaTrader for the master instrument directly.
            //    This is the important path for symbols such as MNQ that
            //    may not yet exist in Instrument.All for this session.
            try
            {
                Instrument masterInstrument =
                    Instrument.GetInstrument(
                        masterQuery
                    );

                if (
                    masterInstrument != null &&
                    masterInstrument.MasterInstrument != null &&
                    masterInstrument
                        .MasterInstrument
                        .InstrumentType ==
                    InstrumentType.Future
                )
                {
                    DateTime minimumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(-3);

                    DateTime maximumMonth =
                        DateTime.Now
                            .Date
                            .AddMonths(24);

                    foreach (
                        var rollover
                        in masterInstrument
                            .MasterInstrument
                            .RolloverCollection
                    )
                    {
                        DateTime contractMonth =
                            rollover.ContractMonth;

                        if (
                            contractMonth <
                                minimumMonth ||
                            contractMonth >
                                maximumMonth
                        )
                        {
                            continue;
                        }

                        string candidate =
                            masterInstrument
                                .MasterInstrument
                                .Name
                            + " "
                            + contractMonth
                                .ToString(
                                    "MM-yy",
                                    CultureInfo.InvariantCulture
                                );

                        Instrument contract =
                            Instrument.GetInstrument(
                                candidate
                            );

                        if (
                            contract != null
                        )
                        {
                            addMatch(
                                contract.FullName
                            );
                        }
                    }
                }
            }
            catch
            {
            }

            results =
                results
                    .OrderBy(
                        value =>
                            value.StartsWith(
                                masterQuery,
                                StringComparison.OrdinalIgnoreCase
                            )
                                ? 0
                                : 1
                    )
                    .ThenBy(
                        value =>
                            value,
                        StringComparer.OrdinalIgnoreCase
                    )
                    .Take(120)
                    .ToList();

            return results.ToArray();
        }
        private void PostPlatformInstrumentSearchResult(
            string requestId,
            string query,
            string[] instruments,
            bool useLocalResultRoute)
        {
            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                return;
            }

            // JJ_COMMAND_DUAL_ROUTE_V3
            string resultServerUrl =
                useLocalResultRoute
                    ? platformServerUrl
                    : "https://jjtradingtools.ddns.net";

            string endpoint =
                resultServerUrl
                    .TrimEnd('/')
                + "/api/bot/instruments/search-result";
            StringBuilder searchJson =
                new StringBuilder();

            searchJson.Append("{");

            AppendJsonStringProperty(
                searchJson,
                "apiKey",
                platformApiKey,
                false
            );

            AppendJsonStringProperty(
                searchJson,
                "requestId",
                requestId,
                true
            );

            AppendJsonStringProperty(
                searchJson,
                "query",
                query,
                true
            );

            AppendJsonStringArrayProperty(
                searchJson,
                "instruments",
                instruments,
                true
            );

            searchJson.Append("}");

            string payload =
                searchJson.ToString();

            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    try
                    {
                        byte[] bytes =
                            Encoding.UTF8
                                .GetBytes(
                                    payload
                                );

                        HttpWebRequest request =
                            (HttpWebRequest)
                            WebRequest.Create(
                                endpoint
                            );

                        request.Method =
                            "POST";

                        ApplyPlatformAuthorizationHeader(
                            request
                        );

                        request.ContentType =
                            "application/json";

                        request.Timeout =
                            2500;

                        request.ReadWriteTimeout =
                            2500;

                        request.ContentLength =
                            bytes.Length;

                        using (
                            Stream requestStream =
                                request.GetRequestStream()
                        )
                        {
                            requestStream.Write(
                                bytes,
                                0,
                                bytes.Length
                            );
                        }

                        using (
                            HttpWebResponse response =
                                (HttpWebResponse)
                                request.GetResponse()
                        )
                        {
                        }
                    }
                    catch
                    {
                    }
                }
            );
        }
        private bool ApplyPlatformStartConfiguration(
            string accountName,
            string instrumentName,
            string strategy,
            string direction,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss,
            double dollarRiskCap)
        {
            Account resolvedAccount =
                null;

            try
            {
                resolvedAccount =
                    Account.All.FirstOrDefault(
                        account =>
                            account != null &&
                            string.Equals(
                                account.Name,
                                accountName,
                                StringComparison.OrdinalIgnoreCase
                            )
                    );
            }
            catch
            {
            }

            if (resolvedAccount == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Account not found: "
                    + accountName
                );

                return false;
            }

            if (
                !IsSimulationAccount(
                    resolvedAccount
                )
            )
            {
                AppendVisualLog(
                    "REMOTE START BLOCKED | LIVE ACCOUNT: "
                    + resolvedAccount.Name
                );

                return false;
            }

            Instrument resolvedInstrument =
                null;

            try
            {
                resolvedInstrument =
                    Instrument.GetInstrument(
                        instrumentName
                    );
            }
            catch
            {
            }

            if (resolvedInstrument == null)
            {
                AppendVisualLog(
                    "REMOTE START REJECTED | Instrument not found: "
                    + instrumentName
                );

                return false;
            }

            selectedAccount =
                resolvedAccount;

            selectedInstrument =
                resolvedInstrument;

            if (accountStatusText != null)
            {
                accountStatusText.Text =
                    "Account: "
                    + selectedAccount.Name;

                accountStatusText.Foreground =
                    Brushes.LightGreen;
            }

            if (instrumentStatusText != null)
            {
                instrumentStatusText.Text =
                    "Instrument: "
                    + selectedInstrument.FullName;

                instrumentStatusText.Foreground =
                    Brushes.LightGreen;
            }

            // InstrumentSelector.Instrument is a writable property in
            // NinjaTrader. Keep its UI synchronized when the hidden
            // control panel is later opened.
            if (instrumentSelector != null)
            {
                try
                {
                    instrumentSelector.Instrument =
                        resolvedInstrument;
                }
                catch
                {
                }
            }

            string normalizedStrategy =
                string.IsNullOrWhiteSpace(
                    strategy
                )
                    ? "HYBRID"
                    : strategy
                        .Trim()
                        .ToUpperInvariant();

            string normalizedDirection =
                string.IsNullOrWhiteSpace(
                    direction
                )
                    ? "BOTH"
                    : direction
                        .Trim()
                        .ToUpperInvariant();

            if (
                strategyCombo != null &&
                strategyCombo.Items.Contains(
                    normalizedStrategy
                )
            )
            {
                strategyCombo.SelectedItem =
                    normalizedStrategy;
            }

            if (
                directionCombo != null &&
                directionCombo.Items.Contains(
                    normalizedDirection
                )
            )
            {
                directionCombo.SelectedItem =
                    normalizedDirection;
            }

            if (contractsBox != null)
                contractsBox.Text =
                    contracts.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (stopBox != null)
                stopBox.Text =
                    stopTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (targetBox != null)
                targetBox.Text =
                    targetTicks.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (maxTradesBox != null)
                maxTradesBox.Text =
                    maxTrades.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyTargetBox != null)
                dailyTargetBox.Text =
                    dailyTarget.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dailyLossBox != null)
                dailyLossBox.Text =
                    dailyLoss.ToString(
                        CultureInfo.InvariantCulture
                    );

            if (dollarRiskCapBox != null)
                dollarRiskCapBox.Text =
                    Math.Max(
                        1.0,
                        dollarRiskCap
                    ).ToString(
                        CultureInfo.InvariantCulture
                    );

            AppendVisualLog(
                "REMOTE CONFIG APPLIED | "
                + selectedAccount.Name
                + " | "
                + selectedInstrument.FullName
                + " | "
                + normalizedStrategy
                + " | "
                + normalizedDirection
                + " | Qty "
                + contracts
                + " | SL "
                + stopTicks
                + " | TP "
                + targetTicks
                + " | RiskCap $"
                + Math.Max(
                    1.0,
                    dollarRiskCap
                  ).ToString("0.00")
            );

            return true;
        }
        private void PrintBotMessage(
            string message)
        {
            // V1.6.43 - FINAL ENTRY DECISION / BLOCK REASON telemetry.
            // Centralized here so every existing execution guard remains intact.
            // This records decisions only; it never changes whether an order runs.
            if (!string.IsNullOrWhiteSpace(message))
            {
                if (
                    message.StartsWith("ENTRY BLOCKED -", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("OPENING FAST PATH BLOCKED -", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("LEARNING BLOCK RANGE", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("SMART RETEST WAIT -", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("WAIT PULLBACK - ENTRY EXTENDED", StringComparison.OrdinalIgnoreCase)
                )
                {
                    lastFinalEntryDecision = "BLOCK";
                    lastFinalBlockReason = message;
                }
                else if (
                    message.StartsWith("SIM ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("LIVE ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase) ||
                    message.StartsWith("ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase)
                )
                {
                    lastFinalEntryDecision = "ALLOW";
                    lastFinalBlockReason = "NONE";
                }
            }

            NinjaTrader.Code.Output.Process(
                "J&J BOT | "
                + message,
                PrintTo.OutputTab1
            );

            AppendVisualLog(
                message
            );

            // V1.6.35 - Opening diagnostic trace. Observational only.
            AppendOpeningDiagnosticMessage(
                message
            );
        }

    }
}

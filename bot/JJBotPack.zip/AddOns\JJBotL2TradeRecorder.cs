#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.58 - L2 TRADE RECORDER (PASIVO)
    // Solo REGISTRA. No cambia entradas, TP, SL, tamano, filtros ni
    // ninguna decision. Todo va dentro de try/catch: si algo falla,
    // el bot sigue igual.
    //
    // Por cada entrada guarda una foto del libro Level 2 (paredes
    // grandes a favor y en contra, desequilibrio, spread, absorcion,
    // delta) y por cada cierre guarda el resultado. Se unen por TradeId.
    //
    // Archivos (Documents\NinjaTrader 8\JJBotData\L2Recorder\):
    //   L2_ENTRIES.csv   una fila por entrada
    //   L2_EXITS.csv     una fila por cierre (mismo TradeId)
    //
    // Pared = fila del libro con volumen >= max(20, 3 x mediana de ese
    // lado). El libro visible tiene como maximo 50 filas por lado:
    // BookDepthFav/Adv dicen cuantos ticks alcanza a ver el bot.
    // =========================================================
    public partial class JJBotWindow
    {
        private sealed class L2TradeRecord
        {
            public string TradeId;
            public string Module;
            public DateTime EntryNy;
            public bool IsLong;
            public int Qty;
            public double Entry;
            public double TickSize;
            public double PointValue;
        }

        private L2TradeRecord l2RecOpen;
        private readonly object l2RecLock = new object();

        private const string L2RecEntriesHeader =
            "TradeId,Date,EntryNy,Module,Side,Qty,Entry,SlTicks,TpTicks," +
            "BookReady,SpreadT,BidPct,AskPct,Top10Bid,Top10Ask,Bias,StackPull,Absorption," +
            "TapeBias,Confluence,AlignedPersist,TapeDelta,TapeTrades," +
            "FavWall1T,FavWall1Vol,FavWall2T,FavWall2Vol,AdvWall1T,AdvWall1Vol,AdvWall2T,AdvWall2Vol," +
            "FavVolToTp,AdvVolToSl,BookDepthFavT,BookDepthAdvT,FavMedianVol,AdvMedianVol";

        private const string L2RecExitsHeader =
            "TradeId,Date,ExitNy,Module,Side,Qty,Entry,Exit,Ticks,NetPnl,MfeUsd,MaeUsd,ExitReason,SecondsInTrade";

        private string L2RecFolder()
        {
            string root = stateFolderPath;

            if (string.IsNullOrWhiteSpace(root))
            {
                root = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    "NinjaTrader 8",
                    "JJBotData");
            }

            string folder = Path.Combine(root, "L2Recorder");
            Directory.CreateDirectory(folder);
            return folder;
        }

        private void L2RecAppend(string fileName, string header, string line)
        {
            string path = Path.Combine(L2RecFolder(), fileName);
            bool exists = File.Exists(path);

            using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
            {
                if (!exists)
                    sw.WriteLine(header);
                sw.WriteLine(line);
            }
        }

        private static string L2N(double v, string fmt = "0.##")
        {
            return v.ToString(fmt, CultureInfo.InvariantCulture);
        }

        private static string L2S(string s)
        {
            return string.IsNullOrEmpty(s) ? "" : s.Replace(",", ";").Replace("\r", " ").Replace("\n", " ");
        }

        // ---- resumen de un lado del libro --------------------------------
        private static void L2SideStats(
            List<JJLevel2Row> rows,
            double entry,
            double tick,
            bool favorable,
            bool isLong,
            int limitTicks,
            out double w1T, out double w1V,
            out double w2T, out double w2V,
            out double volToLimit,
            out double depthT,
            out double medianVol)
        {
            w1T = w1V = w2T = w2V = 0;
            volToLimit = 0;
            depthT = 0;
            medianVol = 0;

            if (rows == null || rows.Count == 0 || tick <= 0)
                return;

            List<long> vols = rows.Select(r => r.Volume).OrderBy(v => v).ToList();
            medianVol = vols[vols.Count / 2];
            double threshold = Math.Max(20.0, 3.0 * medianVol);

            int found = 0;

            foreach (JJLevel2Row r in rows)
            {
                double dist;
                if (favorable)
                    dist = isLong ? (r.Price - entry) / tick : (entry - r.Price) / tick;
                else
                    dist = isLong ? (entry - r.Price) / tick : (r.Price - entry) / tick;

                if (dist < 0)
                    continue; // fila del otro lado del precio de entrada

                if (dist > depthT)
                    depthT = dist;

                if (dist <= limitTicks)
                    volToLimit += r.Volume;

                if (r.Volume >= threshold)
                {
                    if (found == 0) { w1T = dist; w1V = r.Volume; found = 1; }
                    else if (found == 1) { w2T = dist; w2V = r.Volume; found = 2; }
                }
            }
        }

        // ---- ENTRADA ------------------------------------------------------
        private void L2RecorderOnEntry(bool isLong, double entryPrice, int qty, bool manualTest)
        {
            try
            {
                if (manualTest)
                    return;

                lock (l2RecLock)
                {
                    if (l2RecOpen != null)
                        return; // ya hay un trade abierto registrado

                    Instrument inst = selectedInstrument;
                    double tick = (inst != null && inst.MasterInstrument != null)
                        ? inst.MasterInstrument.TickSize : 0.25;
                    double pv = (inst != null && inst.MasterInstrument != null)
                        ? inst.MasterInstrument.PointValue : 2.0;

                    string module =
                        core20ObTradeActive ? "OPEN_BELL" :
                        core20PmTradeActive ? "PM1530" :
                        core20AmTradeActive ? "AM" : "OTHER";

                    DateTime nowNy = GetCurrentNewYorkTime();

                    L2TradeRecord rec = new L2TradeRecord
                    {
                        TradeId = nowNy.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + "_" + (isLong ? "L" : "S"),
                        Module = module,
                        EntryNy = nowNy,
                        IsLong = isLong,
                        Qty = qty,
                        Entry = entryPrice,
                        TickSize = tick,
                        PointValue = pv
                    };

                    int sl = activeStopTicks;
                    int tp = activeTargetTicks;

                    double fw1T, fw1V, fw2T, fw2V, fVol, fDepth, fMed;
                    double aw1T, aw1V, aw2T, aw2V, aVol, aDepth, aMed;
                    string row;

                    lock (level2Sync)
                    {
                        List<JJLevel2Row> fav = new List<JJLevel2Row>(isLong ? level2AskRows : level2BidRows);
                        List<JJLevel2Row> adv = new List<JJLevel2Row>(isLong ? level2BidRows : level2AskRows);

                        L2SideStats(fav, entryPrice, tick, true, isLong, tp,
                            out fw1T, out fw1V, out fw2T, out fw2V, out fVol, out fDepth, out fMed);
                        L2SideStats(adv, entryPrice, tick, false, isLong, sl,
                            out aw1T, out aw1V, out aw2T, out aw2V, out aVol, out aDepth, out aMed);

                        int alignedPersist = isLong ? level2LongPersistence : level2ShortPersistence;

                        row = string.Join(",", new string[]
                        {
                            rec.TradeId,
                            nowNy.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                            nowNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                            module,
                            isLong ? "LONG" : "SHORT",
                            qty.ToString(CultureInfo.InvariantCulture),
                            L2N(entryPrice, "0.00"),
                            sl.ToString(CultureInfo.InvariantCulture),
                            tp.ToString(CultureInfo.InvariantCulture),
                            level2BookReady ? "1" : "0",
                            L2N(level2SpreadTicks, "0.0"),
                            L2N(level2BidPct, "0"),
                            L2N(level2AskPct, "0"),
                            level2TopBidVolume.ToString(CultureInfo.InvariantCulture),
                            level2TopAskVolume.ToString(CultureInfo.InvariantCulture),
                            L2S(level2Bias),
                            L2S(level2StackPull),
                            L2S(level2Absorption),
                            L2S(level2TapeBias),
                            L2S(level2Confluence),
                            alignedPersist.ToString(CultureInfo.InvariantCulture),
                            L2N(level2AggBuy - level2AggSell, "0"),
                            level2TapeTrades.ToString(CultureInfo.InvariantCulture),
                            L2N(fw1T, "0"), L2N(fw1V, "0"), L2N(fw2T, "0"), L2N(fw2V, "0"),
                            L2N(aw1T, "0"), L2N(aw1V, "0"), L2N(aw2T, "0"), L2N(aw2V, "0"),
                            L2N(fVol, "0"), L2N(aVol, "0"),
                            L2N(fDepth, "0"), L2N(aDepth, "0"),
                            L2N(fMed, "0"), L2N(aMed, "0")
                        });
                    }

                    l2RecOpen = rec;
                    L2RecAppend("L2_ENTRIES.csv", L2RecEntriesHeader, row);

                    PrintBotMessage(
                        "L2 RECORDER ENTRY | " + module
                        + " | " + (isLong ? "LONG" : "SHORT")
                        + " | FavWall " + L2N(fw1T, "0") + "t/" + L2N(fw1V, "0")
                        + " | AdvWall " + L2N(aw1T, "0") + "t/" + L2N(aw1V, "0")
                        + " | Book " + L2N(level2BidPct, "0") + "/" + L2N(level2AskPct, "0")
                        + " | PASSIVE LOG ONLY");
                }
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("L2 RECORDER ENTRY ERROR (ignored): " + ex.Message); } catch { }
            }
        }

        // ---- CIERRE -------------------------------------------------------
        private void L2RecorderOnExit(double exitPrice, string reason, double mfeUsd, double maeUsd, double netPnl)
        {
            try
            {
                lock (l2RecLock)
                {
                    L2TradeRecord rec = l2RecOpen;
                    if (rec == null)
                        return;

                    l2RecOpen = null;

                    DateTime nowNy = GetCurrentNewYorkTime();
                    double ticks = rec.TickSize > 0
                        ? (rec.IsLong ? (exitPrice - rec.Entry) : (rec.Entry - exitPrice)) / rec.TickSize
                        : 0;

                    string row = string.Join(",", new string[]
                    {
                        rec.TradeId,
                        nowNy.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        nowNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                        rec.Module,
                        rec.IsLong ? "LONG" : "SHORT",
                        rec.Qty.ToString(CultureInfo.InvariantCulture),
                        L2N(rec.Entry, "0.00"),
                        L2N(exitPrice, "0.00"),
                        L2N(ticks, "0.0"),
                        L2N(netPnl, "0.00"),
                        L2N(mfeUsd, "0.00"),
                        L2N(maeUsd, "0.00"),
                        L2S(reason),
                        L2N((nowNy - rec.EntryNy).TotalSeconds, "0")
                    });

                    L2RecAppend("L2_EXITS.csv", L2RecExitsHeader, row);
                }
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("L2 RECORDER EXIT ERROR (ignored): " + ex.Message); } catch { }
            }
        }
    }
}

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // Evaluate the execution's resulting position, not the account snapshot:
        // PositionUpdate can arrive AFTER ExecutionUpdate during an OCO race.
        public static bool IsLateProtectiveOverfill(bool ownProtectiveExit,
            int remainingTrackedQuantity, int filledQuantity, int resultingPosition)
        {
            return ownProtectiveExit && filledQuantity > 0 && resultingPosition != 0
                && (remainingTrackedQuantity <= 0 || filledQuantity > remainingTrackedQuantity);
        }
    }
}

﻿#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // LEARNING ENGINE - PERSISTENT MEMORY
    // =========================================================
    [Serializable]
    public class JJBotLearningPattern
    {
        public string Key { get; set; }
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public int Trades { get; set; }
        public int Wins { get; set; }
        public int Losses { get; set; }
        public int Breakevens { get; set; }

        public double NetPnL { get; set; }
        public double TotalMfe { get; set; }
        public double TotalMae { get; set; }

        // V1.6.30 - entry-location learning.
        public int LocationSamples { get; set; }
        public int PoorLocationTrades { get; set; }
        public double TotalEntryRoomTicks { get; set; }
        public double TotalEntryEfficiency { get; set; }

        // V1.6.23 Phase 7 - management learning / forced-exit adjudication.
        // These are advisory counters and do NOT rewrite the financial PnL
        // actually produced by the execution engine.
        public double TotalPeakPnl { get; set; }
        public double TotalProfitGiveback { get; set; }
        public int ForcedSignalResolved { get; set; }
        public int ForcedSignalWins { get; set; }
        public int ForcedSignalLosses { get; set; }
        public int ForcedSignalAmbiguous { get; set; }
        public int ForcedSignalExpired { get; set; }

        // V1.6.4 Step 6 - resolved BE follow-through observations.
        // These fields are XML-persisted with the existing Learning memory.
        public int BeFollowThroughResolved { get; set; }
        public int BeFollowThroughTargetHits { get; set; }

        // V1.6.13 - RECENCY-WEIGHTED EVIDENCE.
        // These accumulators decay with time so newer market behavior matters
        // more than old regimes, while lifetime totals remain untouched.
        public double RecentWeight { get; set; }
        public double RecentWins { get; set; }
        public double RecentNetPnL { get; set; }
        public double RecentTotalMfe { get; set; }
        public double RecentTotalMae { get; set; }
        public DateTime RecentAsOfUtc { get; set; }

        // V1.6.16 - calibration evidence for the confidence shown at entry.
        public int ConfidenceTrades { get; set; }
        public int ConfidenceWins { get; set; }
        public double TechnicalConfidenceSum { get; set; }
        public double ConfidenceNetPnL { get; set; }

        public JJBotLearningPattern()
        {
            Key = string.Empty;
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
        }
    }

    [Serializable]
    public class JJBotLearningMemory
    {
        public List<JJBotLearningPattern> Patterns { get; set; }

        public JJBotLearningMemory()
        {
            Patterns =
                new List<JJBotLearningPattern>();
        }
    }

    [Serializable]
    public class JJBotLearningTrade
    {
        public string Side { get; set; }
        public string SessionWindow { get; set; }
        public string Structure { get; set; }

        public DateTime SignalTimeNy { get; set; }
        public double EntryPrice { get; set; }

        public double Mfe { get; set; }
        public double Mae { get; set; }

        // V1.6.16 - exact confidence context at the moment of entry.
        public int TechnicalConfidence { get; set; }
        public string SetupQuality { get; set; }
        public string SetupTiming { get; set; }
        public string ManipulationState { get; set; }

        public JJBotLearningTrade()
        {
            Side = string.Empty;
            SessionWindow = string.Empty;
            Structure = string.Empty;
            SetupQuality = string.Empty;
            SetupTiming = string.Empty;
            ManipulationState = string.Empty;
        }
    }

    // =========================================================
    // V1.6.4 STEP 6 - BREAKEVEN FOLLOW-THROUGH TRACKER
    // =========================================================
    public class JJBotBreakevenFollowThrough
    {
        public string PatternKey { get; set; }
        public string EventKey { get; set; }
        public string Side { get; set; }

        public double EntryPrice { get; set; }
        public double OriginalTargetPrice { get; set; }

        public DateTime ExitTimeNy { get; set; }
        public DateTime ExpiresTimeNy { get; set; }

        public JJBotBreakevenFollowThrough()
        {
            PatternKey = string.Empty;
            EventKey = string.Empty;
            Side = string.Empty;
            ExitTimeNy = DateTime.MinValue;
            ExpiresTimeNy = DateTime.MinValue;
        }
    }


    internal sealed class JJBotDeferredSignalOutcome
    {
        public string EventKey;
        public JJBotLearningTrade Trade;
        public string ExitReason;
        public double ExecutionNet;
        public DateTime ExitTimeNy;
        public double EntryPrice;
        public double OriginalStopPrice;
        public double OriginalTargetPrice;
        public int Quantity;
        public double PointValue;
        public bool Resolved;
    }

    // =========================================================
    // JJ BOT LEARNING ENGINE
    // Extracted from JJBotControl v1.6.20 during segmentation.
    //
    // IMPORTANT:
    // Structural refactor only.
    // No thresholds, hierarchy, expectancy, recency weighting,
    // persistence behavior, trade accounting, or decision logic changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =====================================================
        // LEARNING ENGINE
        // =====================================================
        // V1.6.7 - TWO-LAYER LEARNING
        // Base = official J&J learning distributed by the app updater.
        // User = only this installation's new observations.
        // learningMemory = effective read model (Base + User).
        private JJBotLearningMemory baseLearningMemory;
        private JJBotLearningMemory userLearningMemory;
        private JJBotLearningMemory learningMemory;
        private string learningBaseVersion;
        private JJBotLearningTrade activeLearningTrade;

        // =====================================================
        // V16 - SHARED LEARNING STORE
        // =====================================================
        // All five profile engines share one in-process memory per
        // instrument. The existing pattern key (SIDE + STRUCTURE/SETUP)
        // keeps OPENING, MOMENTUM and STRUCTURE evidence separated.
        private static readonly object SharedLearningSyncRoot =
            new object();

        private static readonly Dictionary<string, JJBotLearningMemory>
            SharedLearningMemories =
                new Dictionary<string, JJBotLearningMemory>(
                    StringComparer.OrdinalIgnoreCase
                );

        // User layer is shared independently so all profiles on the same
        // instrument append to one local delta without ever writing Base.
        private static readonly Dictionary<string, JJBotLearningMemory>
            SharedUserLearningMemories =
                new Dictionary<string, JJBotLearningMemory>(
                    StringComparer.OrdinalIgnoreCase
                );

        // =====================================================
        // V1.6.2 - SHARED LEARNING EVENT DEDUPLICATION
        // =====================================================
        // Several profiles can execute the same market signal on the same
        // instrument. The accounts still trade independently, but the shared
        // Learning memory must count that market event only once.
        //
        // Ownership is deterministic:
        // the lowest participating profile number wins (P1 before P2, etc.).
        // If profile-1 is not participating, the next lowest profile records it.
        private static readonly Dictionary<string, string>
            SharedLearningEventOwners =
                new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase
                );

        private string activeLearningEventKey;

        private string pendingLearningSide;
        private string pendingLearningSession;
        private string pendingLearningStructure;
        private DateTime pendingLearningSignalTimeNy;

        // V1.6.4 Step 6 - after a price-BE exit, keep watching the
        // original TP without sending any order. Multiple trackers may
        // coexist if more than one BE occurs within the observation window.
        private readonly object beFollowThroughLock =
            new object();

        private readonly List<JJBotBreakevenFollowThrough>
            beFollowThroughTrackers =
                new List<JJBotBreakevenFollowThrough>();

        private const int BeFollowThroughWindowMinutes = 30;


        // =====================================================
        // V1.6.13 - LEARNING DECISION ENGINE
        // =====================================================
        // Existing SIDE + STRUCTURE buckets are preserved. The new layer adds:
        //   1) confidence tiers instead of a single N=15 hard threshold,
        //   2) Bayesian win-rate shrinkage for small samples,
        //   3) recency-weighted evidence (30-day half-life), and
        //   4) ALLOW / CAUTION / BLOCK decisions.
        //
        // Safety rule: learning can only hard-block after a stronger sample.
        // 0-14 = observe, 15-29 = advisory, 30-49 = caution/severe block only,
        // 50+ = full evidence. Existing signal logic, SL/TP and trailing are unchanged.
        private const int LearningObserveTrades = 15;
        private const int LearningCautionTrades = 30;
        private const int LearningStrongTrades = 50;
        private const double LearningSevereExpectancy = -12.00;
        private const double LearningModerateExpectancy = -8.00;
        private const double LearningSevereNetPnL = -180.00;
        private const double LearningModerateNetPnL = -120.00;
        private const double LearningMinWinRate = 30.0;
        private const double LearningBayesianPriorWinRate = 0.50;
        private const double LearningBayesianPriorStrength = 20.0;
        private const double LearningRecencyHalfLifeDays = 30.0;
        private const double LearningRecentMinWeight = 8.0;

        // Compatibility aliases retained for existing UI/log text paths.
        private const int LearningMinTrades = LearningObserveTrades;
        private const int DeferredSignalOutcomeMaxSeconds = 300;
        private readonly object deferredSignalOutcomeLock = new object();
        private readonly List<JJBotDeferredSignalOutcome> deferredSignalOutcomes =
            new List<JJBotDeferredSignalOutcome>();

        private const double LearningMinExpectancy = LearningModerateExpectancy;
        private const double LearningMinNetPnL = LearningModerateNetPnL;


        // =====================================================
        // LEARNING ENGINE HELPERS
        // =====================================================
        // =====================================================
        // V1.6.2 - LEARNING EVENT ID / OWNER
        // =====================================================
        private int GetProfileLearningPriority(
            string profileId)
        {
            if (
                string.IsNullOrWhiteSpace(profileId)
            )
            {
                return int.MaxValue;
            }

            Match match =
                Regex.Match(
                    profileId,
                    @"(\d+)$"
                );

            int value;

            if (
                match.Success &&
                int.TryParse(
                    match.Groups[1].Value,
                    out value
                )
            )
            {
                return value;
            }

            return int.MaxValue;
        }

        private string BuildSharedLearningEventKey(
            string side,
            DateTime signalTimeNy,
            string structure)
        {
            string instrumentKey =
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : "UNKNOWN";

            DateTime eventTime =
                signalTimeNy != DateTime.MinValue
                    ? signalTimeNy
                    : GetCurrentNewYorkTime();

            // One-second resolution is intentional:
            // simultaneous multi-profile fills share one event while separate
            // signals a few seconds later remain independent observations.
            string timeKey =
                new DateTime(
                    eventTime.Year,
                    eventTime.Month,
                    eventTime.Day,
                    eventTime.Hour,
                    eventTime.Minute,
                    eventTime.Second
                ).ToString(
                    "yyyyMMdd-HHmmss",
                    CultureInfo.InvariantCulture
                );

            return
                instrumentKey
                + "|"
                + (
                    string.IsNullOrWhiteSpace(side)
                        ? "UNKNOWN"
                        : side.Trim().ToUpperInvariant()
                  )
                + "|"
                + (
                    string.IsNullOrWhiteSpace(structure)
                        ? "UNKNOWN"
                        : structure.Trim().ToUpperInvariant()
                  )
                + "|"
                + timeKey;
        }

        private void ClaimSharedLearningEvent(
            string eventKey)
        {
            if (
                string.IsNullOrWhiteSpace(eventKey)
            )
            {
                return;
            }

            string contender =
                string.IsNullOrWhiteSpace(platformProfileId)
                    ? "profile-999"
                    : platformProfileId;

            string currentOwner;

            if (
                !SharedLearningEventOwners.TryGetValue(
                    eventKey,
                    out currentOwner
                ) ||
                string.IsNullOrWhiteSpace(currentOwner)
            )
            {
                SharedLearningEventOwners[eventKey] =
                    contender;

                return;
            }

            int contenderPriority =
                GetProfileLearningPriority(
                    contender
                );

            int ownerPriority =
                GetProfileLearningPriority(
                    currentOwner
                );

            if (
                contenderPriority <
                    ownerPriority
            )
            {
                SharedLearningEventOwners[eventKey] =
                    contender;
            }
        }

        private bool IsSharedLearningEventOwner(
            string eventKey)
        {
            if (
                string.IsNullOrWhiteSpace(eventKey)
            )
            {
                return true;
            }

            string owner;

            if (
                !SharedLearningEventOwners.TryGetValue(
                    eventKey,
                    out owner
                ) ||
                string.IsNullOrWhiteSpace(owner)
            )
            {
                return true;
            }

            return string.Equals(
                owner,
                platformProfileId,
                StringComparison.OrdinalIgnoreCase
            );
        }

        private void CaptureLearningSignalContext(
            string side,
            DateTime signalTimeNy,
            string structure)
        {
            pendingLearningSide =
                side ?? string.Empty;

            pendingLearningSession =
                GetBotSessionWindow(
                    signalTimeNy
                );

            pendingLearningStructure =
                structure ?? "UNKNOWN";

            pendingLearningSignalTimeNy =
                signalTimeNy;
        }

        private string GetLearningPatternKey(
            string side,
            DateTime nyTime,
            string structure)
        {
            // nyTime is intentionally retained in the signature for
            // compatibility with existing callers, but AM/PM no longer
            // fragments the learning bucket.
            return
                (
                    string.IsNullOrWhiteSpace(
                        side
                    )
                        ? "UNKNOWN"
                        : side
                )
                + "|"
                + (
                    string.IsNullOrWhiteSpace(
                        structure
                    )
                        ? "UNKNOWN"
                        : structure
                );
        }

        private string GetSessionLearningPatternKey(
            string side,
            string sessionWindow,
            string structure)
        {
            return
                "SESSION|"
                + (string.IsNullOrWhiteSpace(sessionWindow) ? "UNKNOWN" : sessionWindow)
                + "|"
                + (string.IsNullOrWhiteSpace(side) ? "UNKNOWN" : side)
                + "|"
                + (string.IsNullOrWhiteSpace(structure) ? "UNKNOWN" : structure);
        }

        private JJBotLearningPattern FindLearningPattern(
            string key)
        {
            if (
                learningMemory == null
            )
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            if (
                learningMemory.Patterns == null
            )
            {
                learningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern != null &&
                    string.Equals(
                        pattern.Key,
                        key,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return pattern;
                }
            }

            return null;
        }

        private JJBotLearningPattern FindUserLearningPattern(
            string key)
        {
            if (userLearningMemory == null)
            {
                userLearningMemory =
                    new JJBotLearningMemory();
            }

            if (userLearningMemory.Patterns == null)
            {
                userLearningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            foreach (
                JJBotLearningPattern pattern
                in userLearningMemory.Patterns
            )
            {
                if (
                    pattern != null &&
                    string.Equals(
                        pattern.Key,
                        key,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    return pattern;
                }
            }

            return null;
        }

        private double GetLearningRecencyDecay(
            DateTime asOfUtc,
            DateTime nowUtc)
        {
            if (asOfUtc == DateTime.MinValue || nowUtc <= asOfUtc)
            {
                return 1.0;
            }

            double ageDays =
                (nowUtc - asOfUtc).TotalDays;

            if (ageDays <= 0)
            {
                return 1.0;
            }

            return Math.Pow(
                0.5,
                ageDays / LearningRecencyHalfLifeDays
            );
        }

        private void AddRecentLearningEvidence(
            JJBotLearningPattern target,
            JJBotLearningPattern source,
            DateTime nowUtc)
        {
            if (target == null || source == null)
            {
                return;
            }

            double decay =
                GetLearningRecencyDecay(
                    source.RecentAsOfUtc,
                    nowUtc
                );

            target.RecentWeight +=
                source.RecentWeight * decay;

            target.RecentWins +=
                source.RecentWins * decay;

            target.RecentNetPnL +=
                source.RecentNetPnL * decay;

            target.RecentTotalMfe +=
                source.RecentTotalMfe * decay;

            target.RecentTotalMae +=
                source.RecentTotalMae * decay;

            target.RecentAsOfUtc =
                nowUtc;
        }

        private void UpdateRecentLearningEvidence(
            JJBotLearningPattern pattern,
            double netTradePnL,
            double mfe,
            double mae)
        {
            if (pattern == null)
            {
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;
            double decay =
                GetLearningRecencyDecay(
                    pattern.RecentAsOfUtc,
                    nowUtc
                );

            pattern.RecentWeight *= decay;
            pattern.RecentWins *= decay;
            pattern.RecentNetPnL *= decay;
            pattern.RecentTotalMfe *= decay;
            pattern.RecentTotalMae *= decay;

            pattern.RecentWeight += 1.0;
            if (netTradePnL > 0.01)
            {
                pattern.RecentWins += 1.0;
            }

            pattern.RecentNetPnL += netTradePnL;
            pattern.RecentTotalMfe += mfe;
            pattern.RecentTotalMae += mae;
            pattern.RecentAsOfUtc = nowUtc;
        }

        private double CalculateLearningConfidenceScore(
            JJBotLearningPattern pattern,
            double expectancy,
            double smoothedWinRate,
            double recentExpectancy,
            bool hasRecentEvidence)
        {
            if (pattern == null || pattern.Trades <= 0)
            {
                return 50.0;
            }

            double sampleConfidence =
                Math.Min(
                    1.0,
                    pattern.Trades / (double)LearningStrongTrades
                );

            double expectancyScore =
                Math.Max(
                    0.0,
                    Math.Min(
                        100.0,
                        50.0 + expectancy * 2.5
                    )
                );

            double winScore =
                Math.Max(
                    0.0,
                    Math.Min(100.0, smoothedWinRate)
                );

            double recentScore =
                hasRecentEvidence
                    ? Math.Max(
                        0.0,
                        Math.Min(
                            100.0,
                            50.0 + recentExpectancy * 2.5
                        )
                      )
                    : 50.0;

            double evidenceScore =
                expectancyScore * 0.40
                + winScore * 0.25
                + recentScore * 0.35;

            // With a small sample, shrink the final confidence toward neutral.
            return
                50.0
                + (evidenceScore - 50.0)
                    * sampleConfidence;
        }

        private JJBotLearningPattern BuildSpecificLearningAggregate(
            string side,
            string structure)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE_SPECIFIC";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                "*";

            aggregate.Structure =
                string.IsNullOrWhiteSpace(
                    structure
                )
                    ? "UNKNOWN"
                    : structure;

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                // Session-specific V1.6.30 patterns are shadow analytics.
                // They must not double-count the legacy ALL bucket used by
                // the existing Learning decision hierarchy.
                if (!string.IsNullOrWhiteSpace(pattern.SessionWindow) &&
                    !string.Equals(pattern.SessionWindow, "ALL", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(pattern.SessionWindow, "*", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (
                    !string.Equals(
                        pattern.Side ?? string.Empty,
                        side ?? string.Empty,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.Equals(
                        string.IsNullOrWhiteSpace(
                            pattern.Structure
                        )
                            ? "UNKNOWN"
                            : pattern.Structure,
                        string.IsNullOrWhiteSpace(
                            structure
                        )
                            ? "UNKNOWN"
                            : structure,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;

                AddRecentLearningEvidence(
                    aggregate,
                    pattern,
                    DateTime.UtcNow
                );
            }

            return aggregate;
        }

        private JJBotLearningPattern BuildLearningAggregate(
            string side,
            string sessionWindow)
        {
            JJBotLearningPattern aggregate =
                new JJBotLearningPattern();

            aggregate.Key =
                "AGGREGATE";

            aggregate.Side =
                side ?? string.Empty;

            aggregate.SessionWindow =
                sessionWindow ?? string.Empty;

            aggregate.Structure =
                "*";

            if (
                learningMemory == null ||
                learningMemory.Patterns == null
            )
            {
                return aggregate;
            }

            foreach (
                JJBotLearningPattern pattern
                in learningMemory.Patterns
            )
            {
                if (
                    pattern == null ||
                    pattern.Trades <= 0
                )
                {
                    continue;
                }

                if (
                    string.IsNullOrWhiteSpace(sessionWindow) &&
                    !string.IsNullOrWhiteSpace(pattern.SessionWindow) &&
                    !string.Equals(pattern.SessionWindow, "ALL", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(pattern.SessionWindow, "*", StringComparison.OrdinalIgnoreCase)
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        side
                    ) &&
                    !string.Equals(
                        pattern.Side,
                        side,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        sessionWindow
                    ) &&
                    !string.Equals(
                        pattern.SessionWindow,
                        sessionWindow,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                aggregate.Trades +=
                    pattern.Trades;

                aggregate.Wins +=
                    pattern.Wins;

                aggregate.Losses +=
                    pattern.Losses;

                aggregate.Breakevens +=
                    pattern.Breakevens;

                aggregate.NetPnL +=
                    pattern.NetPnL;

                aggregate.TotalMfe +=
                    pattern.TotalMfe;

                aggregate.TotalMae +=
                    pattern.TotalMae;

                AddRecentLearningEvidence(
                    aggregate,
                    pattern,
                    DateTime.UtcNow
                );
            }

            return aggregate;
        }

        private bool EvaluateLearningEvidence(
            JJBotLearningPattern pattern,
            string level,
            out bool hasEvidence,
            out bool allowed,
            out string reason)
        {
            hasEvidence = false;
            allowed = true;
            reason = level + " NO DATA";

            int trades =
                pattern != null
                    ? pattern.Trades
                    : 0;

            if (pattern == null || trades < LearningObserveTrades)
            {
                reason =
                    level
                    + " OBSERVE"
                    + " | Sample: "
                    + trades
                    + "/"
                    + LearningObserveTrades
                    + " | Decision: ALLOW";

                return true;
            }

            hasEvidence = true;

            double expectancy =
                trades > 0
                    ? pattern.NetPnL / trades
                    : 0;

            double rawWinRate =
                trades > 0
                    ? ((double)pattern.Wins / trades) * 100.0
                    : 0;

            double smoothedWinRate =
                (
                    pattern.Wins
                    + LearningBayesianPriorWinRate
                        * LearningBayesianPriorStrength
                )
                /
                (trades + LearningBayesianPriorStrength)
                * 100.0;

            double avgMfe =
                trades > 0
                    ? pattern.TotalMfe / trades
                    : 0;

            double avgMae =
                trades > 0
                    ? pattern.TotalMae / trades
                    : 0;

            DateTime nowUtc = DateTime.UtcNow;
            double recentDecay =
                GetLearningRecencyDecay(
                    pattern.RecentAsOfUtc,
                    nowUtc
                );

            double recentWeight =
                pattern.RecentWeight * recentDecay;

            double recentNetPnL =
                pattern.RecentNetPnL * recentDecay;

            double recentWins =
                pattern.RecentWins * recentDecay;

            bool hasRecentEvidence =
                recentWeight >= LearningRecentMinWeight;

            double recentExpectancy =
                recentWeight > 0.001
                    ? recentNetPnL / recentWeight
                    : expectancy;

            double recentWinRate =
                recentWeight > 0.001
                    ? (recentWins / recentWeight) * 100.0
                    : rawWinRate;

            double confidenceScore =
                CalculateLearningConfidenceScore(
                    pattern,
                    expectancy,
                    smoothedWinRate,
                    recentExpectancy,
                    hasRecentEvidence
                );

            bool severeLifetimeNegative =
                expectancy <= LearningSevereExpectancy &&
                pattern.NetPnL <= LearningSevereNetPnL;

            bool moderateLifetimeNegative =
                expectancy <= LearningModerateExpectancy &&
                pattern.NetPnL <= LearningModerateNetPnL;

            bool lowWinNegative =
                smoothedWinRate < LearningMinWinRate &&
                expectancy < 0;

            bool recentNegative =
                hasRecentEvidence &&
                recentExpectancy < 0;

            bool recentSevereNegative =
                hasRecentEvidence &&
                recentExpectancy <= LearningSevereExpectancy;

            bool hardBlock = false;
            string decision = "ALLOW";

            // V1.6.25 - EARLY SEVERE EDGE VETO.
            // Once the exact setup has reached the observation threshold,
            // an obviously destructive edge no longer has to wait for 30/50
            // trades before Learning can protect the account.
            //
            // Example observed live:
            // 16 trades | Exp -$25.84 | Net -$413.50.
            // This satisfies the severe lifetime criteria by a wide margin.
            bool earlySevereBlock =
                trades >= LearningObserveTrades &&
                severeLifetimeNegative &&
                rawWinRate <= 35.0 &&
                (
                    !hasRecentEvidence ||
                    recentExpectancy < 0
                );

            if (earlySevereBlock)
            {
                hardBlock = true;
            }
            else if (trades >= LearningStrongTrades)
            {
                hardBlock =
                    (moderateLifetimeNegative &&
                        (!hasRecentEvidence || recentNegative)) ||
                    (lowWinNegative &&
                        (!hasRecentEvidence || recentNegative));
            }
            else if (trades >= LearningCautionTrades)
            {
                // 30-49 trades: only a clearly bad edge may hard-block.
                hardBlock =
                    severeLifetimeNegative &&
                    (!hasRecentEvidence || recentSevereNegative);
            }

            if (hardBlock)
            {
                allowed = false;
                decision = "BLOCK";
            }
            else
            {
                allowed = true;

                bool caution =
                    trades >= LearningCautionTrades &&
                    (
                        moderateLifetimeNegative ||
                        lowWinNegative ||
                        recentNegative ||
                        confidenceScore < 40.0
                    );

                decision =
                    caution
                        ? "CAUTION"
                        : "ALLOW";
            }

            string evidenceTier =
                trades >= LearningStrongTrades
                    ? "STRONG"
                    : trades >= LearningCautionTrades
                        ? "MEDIUM"
                        : "EARLY";

            reason =
                level
                + " "
                + evidenceTier
                + " | Trades: "
                + trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | RawWR: "
                + rawWinRate.ToString("0.0")
                + "%"
                + " | BayesianWR: "
                + smoothedWinRate.ToString("0.0")
                + "%"
                + " | Exp: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | RecentWeight: "
                + recentWeight.ToString("0.0")
                + " | RecentExp: "
                + recentExpectancy.ToString("$0.00")
                + "/trade"
                + " | RecentWR: "
                + recentWinRate.ToString("0.0")
                + "%"
                + " | AvgMFE: "
                + avgMfe.ToString("$0.00")
                + " | AvgMAE: "
                + avgMae.ToString("$0.00")
                + " | Confidence: "
                + confidenceScore.ToString("0")
                + "%"
                + " | Decision: "
                + decision;

            return true;
        }

        // =====================================================
        // V1.6.25 - LEARNING -> QUALITY BRIDGE
        // =====================================================
        // Returns a confidence penalty for the exact Side + Setup bucket.
        // A hard-blocked bucket receives the maximum penalty and is still
        // independently rejected again by the final execution gate.
        private int GetLearningQualityPenalty(
            string side,
            DateTime nyTime,
            string structure,
            out bool learningBlocked,
            out string learningReason)
        {
            lock (SharedLearningSyncRoot)
            {
                learningBlocked = false;
                learningReason = "NO HISTORY";

                if (selectedInstrument == null)
                {
                    return 0;
                }

                if (learningMemory == null)
                {
                    LoadLearningMemory();
                }

                JJBotLearningPattern specific =
                    BuildSpecificLearningAggregate(
                        string.IsNullOrWhiteSpace(side)
                            ? "UNKNOWN"
                            : side,
                        string.IsNullOrWhiteSpace(structure)
                            ? "UNKNOWN"
                            : structure
                    );

                bool hasEvidence;
                bool allowed;
                string reason;

                EvaluateLearningEvidence(
                    specific,
                    "SPECIFIC",
                    out hasEvidence,
                    out allowed,
                    out reason
                );

                learningReason = reason;

                if (!hasEvidence)
                {
                    return 0;
                }

                if (!allowed)
                {
                    learningBlocked = true;
                    return 40;
                }

                double expectancy =
                    specific.Trades > 0
                        ? specific.NetPnL / specific.Trades
                        : 0;

                double rawWinRate =
                    specific.Trades > 0
                        ? ((double)specific.Wins / specific.Trades) * 100.0
                        : 50.0;

                int penalty = 0;

                if (
                    expectancy <= LearningModerateExpectancy &&
                    specific.NetPnL <= LearningModerateNetPnL
                )
                {
                    penalty += 18;
                }

                if (rawWinRate < 35.0 && expectancy < 0)
                {
                    penalty += 10;
                }

                return Math.Min(30, penalty);
            }
        }

        private bool IsLearningTradeAllowed(
            string side,
            DateTime nyTime,
            string structure,
            out string reason)
        {
            lock (SharedLearningSyncRoot)
            {
                reason =
                    "NO HISTORY - ALLOWED";

                if (selectedInstrument == null)
                {
                    return true;
                }

                if (learningMemory == null)
                {
                    LoadLearningMemory();
                }

                string normalizedSide =
                    string.IsNullOrWhiteSpace(
                        side
                    )
                        ? "UNKNOWN"
                        : side;

                string normalizedStructure =
                    string.IsNullOrWhiteSpace(
                        structure
                    )
                        ? "UNKNOWN"
                        : structure;

                // =====================================================
                // V1.6.5 - SPECIFIC-FIRST LEARNING
                // =====================================================
                // Only the exact Side + Setup bucket may hard-block an entry.
                // SIDE/GLOBAL remain advisory while the exact setup is still
                // gathering its own minimum sample. This prevents unrelated
                // Opening/Structure history from shutting down a fresh
                // Momentum setup prematurely.
                JJBotLearningPattern specific =
                    BuildSpecificLearningAggregate(
                        normalizedSide,
                        normalizedStructure
                    );

                bool specificHasEvidence;
                bool specificAllowed;
                string specificReason;

                EvaluateLearningEvidence(
                    specific,
                    "SPECIFIC",
                    out specificHasEvidence,
                    out specificAllowed,
                    out specificReason
                );

                if (specificHasEvidence)
                {
                    reason =
                        specificReason;

                    return specificAllowed;
                }

                JJBotLearningPattern sideAggregate =
                    BuildLearningAggregate(
                        normalizedSide,
                        string.Empty
                    );

                JJBotLearningPattern globalAggregate =
                    BuildLearningAggregate(
                        string.Empty,
                        string.Empty
                    );

                bool sideHasEvidence;
                bool sideAllowed;
                string sideReason;

                EvaluateLearningEvidence(
                    sideAggregate,
                    "SIDE",
                    out sideHasEvidence,
                    out sideAllowed,
                    out sideReason
                );

                bool globalHasEvidence;
                bool globalAllowed;
                string globalReason;

                EvaluateLearningEvidence(
                    globalAggregate,
                    "GLOBAL",
                    out globalHasEvidence,
                    out globalAllowed,
                    out globalReason
                );

                reason =
                    "SPECIFIC SAMPLE "
                    + specific.Trades
                    + "/"
                    + LearningObserveTrades
                    + " - OBSERVING / ALLOWED"
                    + " | SIDE advisory: "
                    + (
                        sideHasEvidence
                            ? (
                                sideAllowed
                                    ? "ALLOWED"
                                    : "NEGATIVE"
                              )
                            : "INSUFFICIENT"
                      )
                    + " | GLOBAL advisory: "
                    + (
                        globalHasEvidence
                            ? (
                                globalAllowed
                                    ? "ALLOWED"
                                    : "NEGATIVE"
                              )
                            : "INSUFFICIENT"
                      );

                return true;
            }
        }

        private void ApplyLearningTradeMetrics(
            JJBotLearningPattern pattern,
            double netTradePnL,
            double mfe,
            double mae)
        {
            if (pattern == null)
                return;

            pattern.Trades++;

            const double LearningPnLEpsilon = 0.01;
            if (netTradePnL > LearningPnLEpsilon)
                pattern.Wins++;
            else if (netTradePnL < -LearningPnLEpsilon)
                pattern.Losses++;
            else
                pattern.Breakevens++;

            pattern.NetPnL += netTradePnL;
            pattern.TotalMfe += mfe;
            pattern.TotalMae += mae;

            if (activeEntryRoomTicks > 0)
            {
                pattern.LocationSamples++;
                pattern.TotalEntryRoomTicks += activeEntryRoomTicks;
                if (string.Equals(activeEntryLocationState, "POOR", StringComparison.OrdinalIgnoreCase))
                    pattern.PoorLocationTrades++;
            }

            double pathDenominator = Math.Max(0, mfe) + Math.Abs(Math.Min(0, mae));
            if (pathDenominator > 0.01)
            {
                double efficiency = Math.Max(0, mfe) / pathDenominator * 100.0;
                pattern.TotalEntryEfficiency += efficiency;
            }

            UpdateRecentLearningEvidence(pattern, netTradePnL, mfe, mae);
        }

        private void RecordLearningTradeResult(
            double netTradePnL,
            string exitReason,
            double frozenTradePeakPnlDollars)
        {
            lock (SharedLearningSyncRoot)
            {

            if (
                activeLearningTrade == null
            )
            {
                return;
            }

            string normalizedExitReason =
                string.IsNullOrWhiteSpace(exitReason)
                    ? "UNKNOWN"
                    : exitReason.Trim().ToUpperInvariant();

            bool forcedExecutionExit =
                normalizedExitReason == "DAILY_LOSS" ||
                normalizedExitReason == "PROFIT_FLOOR" ||
                normalizedExitReason == "SESSION_FORCE_FLAT" ||
                normalizedExitReason == "RISK_FLATTEN" ||
                normalizedExitReason == "MANUAL_OR_EXTERNAL";

            // V1.6.23 - execution result is NOT automatically signal result.
            // Forced exits remain valid financial PnL, but are excluded from
            // directional/setup W-L learning until post-exit signal adjudication
            // is available. This prevents a risk/session flatten from teaching
            // the bot that a technically valid setup was necessarily wrong.
            if (forcedExecutionExit)
            {
                ArmDeferredSignalOutcome(
                    activeLearningTrade,
                    activeLearningEventKey,
                    normalizedExitReason,
                    netTradePnL
                );

                PrintBotMessage(
                    "LEARNING SIGNAL OUTCOME DEFERRED"
                    + " | ExitReason: " + normalizedExitReason
                    + " | ExecutionNet: " + netTradePnL.ToString("$0.00")
                    + " | OriginalSL: " + activeStopPrice.ToString("0.00")
                    + " | OriginalTP: " + activeTargetPrice.ToString("0.00")
                    + " | Horizon: " + DeferredSignalOutcomeMaxSeconds + "s"
                    + " | Financial PnL unchanged; setup outcome pending."
                );

                if (!string.IsNullOrWhiteSpace(activeLearningEventKey))
                {
                    SharedLearningEventOwners.Remove(
                        activeLearningEventKey
                    );
                }

                activeLearningTrade = null;
                activeLearningEventKey = string.Empty;
                pendingLearningSide = string.Empty;
                pendingLearningSession = string.Empty;
                pendingLearningStructure = string.Empty;
                pendingLearningSignalTimeNy = DateTime.MinValue;
                return;
            }

            if (
                !IsSharedLearningEventOwner(
                    activeLearningEventKey
                )
            )
            {
                string owner =
                    string.Empty;

                SharedLearningEventOwners.TryGetValue(
                    activeLearningEventKey,
                    out owner
                );

                PrintBotMessage(
                    "LEARNING DUPLICATE SKIPPED"
                    + " | "
                    + platformProfileId
                    + " | Owner: "
                    + (
                        string.IsNullOrWhiteSpace(owner)
                            ? "UNKNOWN"
                            : owner
                      )
                    + " | Event: "
                    + activeLearningEventKey
                    + " | TradeNet: "
                    + netTradePnL.ToString("$0.00")
                );

                activeLearningTrade =
                    null;

                activeLearningEventKey =
                    string.Empty;

                pendingLearningSide =
                    string.Empty;

                pendingLearningSession =
                    string.Empty;

                pendingLearningStructure =
                    string.Empty;

                pendingLearningSignalTimeNy =
                    DateTime.MinValue;

                return;
            }

            if (
                userLearningMemory == null
            )
            {
                userLearningMemory =
                    new JJBotLearningMemory();
            }

            DateTime signalNy =
                activeLearningTrade.SignalTimeNy !=
                    DateTime.MinValue
                    ? activeLearningTrade.SignalTimeNy
                    : GetCurrentNewYorkTime();

            string key =
                GetLearningPatternKey(
                    activeLearningTrade.Side,
                    signalNy,
                    activeLearningTrade.Structure
                );

            JJBotLearningPattern pattern =
                FindUserLearningPattern(
                    key
                );

            if (pattern == null)
            {
                pattern =
                    new JJBotLearningPattern();

                pattern.Key =
                    key;

                pattern.Side =
                    activeLearningTrade.Side;

                // Session remains on the live trade as metadata,
                // but the stored V3 bucket intentionally spans AM + PM.
                pattern.SessionWindow =
                    "ALL";

                pattern.Structure =
                    activeLearningTrade.Structure;

                userLearningMemory.Patterns.Add(
                    pattern
                );
            }

            const double LearningPnLEpsilon = 0.01;

            ApplyLearningTradeMetrics(
                pattern,
                netTradePnL,
                activeLearningTrade.Mfe,
                activeLearningTrade.Mae
            );

            // V1.6.16 - confidence calibration.
            // This is recorded only for real automatic learning trades;
            // manual test trades never create activeLearningTrade.
            if (
                activeLearningTrade.TechnicalConfidence > 0
            )
            {
                pattern.ConfidenceTrades++;

                if (netTradePnL > LearningPnLEpsilon)
                {
                    pattern.ConfidenceWins++;
                }

                pattern.TechnicalConfidenceSum +=
                    activeLearningTrade.TechnicalConfidence;

                pattern.ConfidenceNetPnL +=
                    netTradePnL;
            }

            // V1.6.36 - use the peak snapshot frozen by OrderLifecycle at the
            // instant the trade becomes flat. The live field can be cleared by
            // asynchronous flat/risk callbacks before Learning persists.
            double learningPeakPnl =
                Math.Max(0, frozenTradePeakPnlDollars);

            pattern.TotalPeakPnl += learningPeakPnl;

            pattern.TotalProfitGiveback +=
                Math.Max(
                    0,
                    learningPeakPnl - Math.Max(0, netTradePnL)
                );

            // A price-BE can still have a small negative net result once
            // commissions are present, so detect BE from gross price PnL.
            bool priceBreakevenExit =
                Math.Abs(
                    activeExitGrossPnL
                ) <= 0.01;

            if (
                priceBreakevenExit &&
                activeTargetPrice > 0 &&
                entryFillPrice > 0
            )
            {
                ArmBreakevenFollowThrough(
                    pattern.Key,
                    activeLearningEventKey,
                    activeLearningTrade.Side,
                    entryFillPrice,
                    activeTargetPrice
                );
            }

            // V1.6.30 - parallel session-specific learning bucket.
            // This collects AM / MIDDAY / PM edge without changing the
            // existing ALL-session hard-block hierarchy yet.
            string sessionWindow =
                string.IsNullOrWhiteSpace(activeLearningTrade.SessionWindow)
                    ? GetBotSessionWindow(signalNy)
                    : activeLearningTrade.SessionWindow;

            string sessionKey = GetSessionLearningPatternKey(
                activeLearningTrade.Side,
                sessionWindow,
                activeLearningTrade.Structure
            );

            JJBotLearningPattern sessionPattern =
                FindUserLearningPattern(sessionKey);

            if (sessionPattern == null)
            {
                sessionPattern = new JJBotLearningPattern
                {
                    Key = sessionKey,
                    Side = activeLearningTrade.Side,
                    SessionWindow = sessionWindow,
                    Structure = activeLearningTrade.Structure
                };

                userLearningMemory.Patterns.Add(sessionPattern);
            }

            ApplyLearningTradeMetrics(
                sessionPattern,
                netTradePnL,
                activeLearningTrade.Mfe,
                activeLearningTrade.Mae
            );

            SaveLearningMemory();

            // Log/report the effective Base + User statistics, not only
            // the local delta that was just updated.
            JJBotLearningPattern effectivePattern =
                FindLearningPattern(key);

            if (effectivePattern != null)
            {
                pattern = effectivePattern;
            }

            double winRate =
                pattern.Trades > 0
                    ? (
                        (double)pattern.Wins
                        / pattern.Trades
                    )
                    * 100.0
                    : 0;

            double expectancy =
                pattern.Trades > 0
                    ? pattern.NetPnL
                        / pattern.Trades
                    : 0;

            double averageMfe =
                pattern.Trades > 0
                    ? pattern.TotalMfe
                        / pattern.Trades
                    : 0;

            double averageMae =
                pattern.Trades > 0
                    ? pattern.TotalMae
                        / pattern.Trades
                    : 0;

            double averagePeakPnl =
                pattern.Trades > 0
                    ? pattern.TotalPeakPnl / pattern.Trades
                    : 0;

            double averageProfitGiveback =
                pattern.Trades > 0
                    ? pattern.TotalProfitGiveback / pattern.Trades
                    : 0;

            JJBotLearningPattern specificAggregate =
                BuildSpecificLearningAggregate(
                    pattern.Side,
                    pattern.Structure
                );

            JJBotLearningPattern sideAggregate =
                BuildLearningAggregate(
                    pattern.Side,
                    string.Empty
                );

            JJBotLearningPattern globalAggregate =
                BuildLearningAggregate(
                    string.Empty,
                    string.Empty
                );

            PrintBotMessage(
                "LEARNING UPDATED"
                + " | "
                + platformProfileId
                + " | "
                + key
                + " | Trades: "
                + pattern.Trades
                + " | W/L/BE: "
                + pattern.Wins
                + "/"
                + pattern.Losses
                + "/"
                + pattern.Breakevens
                + " | WinRate: "
                + winRate.ToString("0.0")
                + "%"
                + " | TradeNet: "
                + netTradePnL.ToString("$0.00")
                + " | Net: "
                + pattern.NetPnL.ToString("$0.00")
                + " | Expectancy: "
                + expectancy.ToString("$0.00")
                + "/trade"
                + " | AvgMFE: "
                + averageMfe.ToString("$0.00")
                + " | AvgMAE: "
                + averageMae.ToString("$0.00")
                + " | AvgPeak: "
                + averagePeakPnl.ToString("$0.00")
                + " | AvgGiveback: "
                + averageProfitGiveback.ToString("$0.00")
                + " | ForcedSignal W/L: "
                + pattern.ForcedSignalWins
                + "/"
                + pattern.ForcedSignalLosses
                + " | BE->TP: "
                + pattern.BeFollowThroughTargetHits
                + "/"
                + pattern.BeFollowThroughResolved
                + (
                    pattern.BeFollowThroughResolved > 0
                        ? " ("
                            + (
                                (
                                    (double)pattern.BeFollowThroughTargetHits /
                                    pattern.BeFollowThroughResolved
                                ) * 100.0
                              ).ToString("0.0")
                            + "%)"
                        : string.Empty
                  )
                + " | HIERARCHY SPECIFIC: "
                + specificAggregate.Trades
                + " | SIDE: "
                + sideAggregate.Trades
                + " | GLOBAL: "
                + globalAggregate.Trades
            );

            double sessionExpectancy =
                sessionPattern.Trades > 0
                    ? sessionPattern.NetPnL / sessionPattern.Trades
                    : 0;

            double sessionWinRate =
                sessionPattern.Trades > 0
                    ? ((double)sessionPattern.Wins / sessionPattern.Trades) * 100.0
                    : 0;

            double avgRoomTicks =
                sessionPattern.LocationSamples > 0
                    ? sessionPattern.TotalEntryRoomTicks / sessionPattern.LocationSamples
                    : 0;

            double avgEntryEfficiency =
                sessionPattern.Trades > 0
                    ? sessionPattern.TotalEntryEfficiency / sessionPattern.Trades
                    : 0;

            PrintBotMessage(
                "SESSION LEARNING"
                + " | " + sessionWindow
                + " | " + activeLearningTrade.Side
                + " | " + activeLearningTrade.Structure
                + " | Trades: " + sessionPattern.Trades
                + " | WR: " + sessionWinRate.ToString("0.0") + "%"
                + " | Exp: " + sessionExpectancy.ToString("$0.00") + "/trade"
                + " | Location: " + activeEntryLocationState
                + " | Room: " + activeEntryRoomTicks.ToString("0") + "t"
                + " | AvgRoom: " + avgRoomTicks.ToString("0") + "t"
                + " | EntryEfficiency: " + avgEntryEfficiency.ToString("0.0") + "%"
            );

            activeLearningTrade = null;
            activeLearningEventKey = string.Empty;

            pendingLearningSide =
                string.Empty;

            pendingLearningSession =
                string.Empty;

            pendingLearningStructure =
                string.Empty;

            pendingLearningSignalTimeNy =
                DateTime.MinValue;
        
            }
        }

        private JJBotLearningTrade CloneLearningTrade(JJBotLearningTrade source)
        {
            if (source == null)
                return null;

            return new JJBotLearningTrade
            {
                Side = source.Side,
                SessionWindow = source.SessionWindow,
                Structure = source.Structure,
                SignalTimeNy = source.SignalTimeNy,
                EntryPrice = source.EntryPrice,
                Mfe = source.Mfe,
                Mae = source.Mae,
                TechnicalConfidence = source.TechnicalConfidence,
                SetupQuality = source.SetupQuality,
                SetupTiming = source.SetupTiming,
                ManipulationState = source.ManipulationState
            };
        }

        private void ArmDeferredSignalOutcome(
            JJBotLearningTrade trade,
            string eventKey,
            string exitReason,
            double executionNet)
        {
            if (
                trade == null ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                trade.EntryPrice <= 0 ||
                activeTradeOriginalStopPrice <= 0 ||
                activeTradeOriginalTargetPrice <= 0
            )
            {
                PrintBotMessage(
                    "DEFERRED SIGNAL OUTCOME NOT ARMED"
                    + " | Missing original bracket/context."
                );
                return;
            }

            JJBotDeferredSignalOutcome item =
                new JJBotDeferredSignalOutcome
                {
                    EventKey = eventKey ?? string.Empty,
                    Trade = CloneLearningTrade(trade),
                    ExitReason = exitReason ?? "UNKNOWN",
                    ExecutionNet = executionNet,
                    ExitTimeNy = GetCurrentNewYorkTime(),
                    EntryPrice = trade.EntryPrice,
                    OriginalStopPrice = activeTradeOriginalStopPrice,
                    OriginalTargetPrice = activeTradeOriginalTargetPrice,
                    Quantity = Math.Max(1, entryQuantity),
                    PointValue = selectedInstrument.MasterInstrument.PointValue,
                    Resolved = false
                };

            lock (deferredSignalOutcomeLock)
            {
                deferredSignalOutcomes.Add(item);
            }
        }

        private void UpdateDeferredLearningSignalOutcomes(
            DateTime currentTimeNy,
            double currentHigh,
            double currentLow)
        {
            List<Tuple<JJBotDeferredSignalOutcome, string>> resolutions =
                new List<Tuple<JJBotDeferredSignalOutcome, string>>();

            lock (deferredSignalOutcomeLock)
            {
                for (int i = deferredSignalOutcomes.Count - 1; i >= 0; i--)
                {
                    JJBotDeferredSignalOutcome item = deferredSignalOutcomes[i];
                    if (item == null || item.Trade == null)
                    {
                        deferredSignalOutcomes.RemoveAt(i);
                        continue;
                    }

                    bool isLong = string.Equals(
                        item.Trade.Side,
                        "LONG",
                        StringComparison.OrdinalIgnoreCase
                    );

                    bool targetHit = isLong
                        ? currentHigh >= item.OriginalTargetPrice
                        : currentLow <= item.OriginalTargetPrice;

                    bool stopHit = isLong
                        ? currentLow <= item.OriginalStopPrice
                        : currentHigh >= item.OriginalStopPrice;

                    string result = string.Empty;

                    if (targetHit && stopHit)
                        result = "AMBIGUOUS";
                    else if (targetHit)
                        result = "WIN";
                    else if (stopHit)
                        result = "LOSS";
                    else if (
                        (currentTimeNy - item.ExitTimeNy).TotalSeconds >=
                        DeferredSignalOutcomeMaxSeconds
                    )
                        result = "EXPIRED";

                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        deferredSignalOutcomes.RemoveAt(i);
                        resolutions.Add(Tuple.Create(item, result));
                    }
                }
            }

            for (int i = 0; i < resolutions.Count; i++)
            {
                RecordDeferredSignalResolution(
                    resolutions[i].Item1,
                    resolutions[i].Item2
                );
            }
        }

        private void RecordDeferredSignalResolution(
            JJBotDeferredSignalOutcome item,
            string result)
        {
            if (item == null || item.Trade == null)
                return;

            lock (SharedLearningSyncRoot)
            {
                if (userLearningMemory == null)
                    userLearningMemory = new JJBotLearningMemory();

                DateTime signalNy = item.Trade.SignalTimeNy != DateTime.MinValue
                    ? item.Trade.SignalTimeNy
                    : item.ExitTimeNy;

                string key = GetLearningPatternKey(
                    item.Trade.Side,
                    signalNy,
                    item.Trade.Structure
                );

                JJBotLearningPattern pattern = FindUserLearningPattern(key);
                if (pattern == null)
                {
                    pattern = new JJBotLearningPattern
                    {
                        Key = key,
                        Side = item.Trade.Side,
                        SessionWindow = "ALL",
                        Structure = item.Trade.Structure
                    };
                    userLearningMemory.Patterns.Add(pattern);
                }

                if (result == "WIN")
                {
                    pattern.ForcedSignalResolved++;
                    pattern.ForcedSignalWins++;
                }
                else if (result == "LOSS")
                {
                    pattern.ForcedSignalResolved++;
                    pattern.ForcedSignalLosses++;
                }
                else if (result == "AMBIGUOUS")
                {
                    pattern.ForcedSignalAmbiguous++;
                }
                else
                {
                    pattern.ForcedSignalExpired++;
                }

                SaveLearningMemory();

                double hypotheticalGross = 0;
                if (result == "WIN")
                {
                    hypotheticalGross =
                        Math.Abs(item.OriginalTargetPrice - item.EntryPrice) *
                        item.PointValue * item.Quantity;
                }
                else if (result == "LOSS")
                {
                    hypotheticalGross =
                        -Math.Abs(item.EntryPrice - item.OriginalStopPrice) *
                        item.PointValue * item.Quantity;
                }

                PrintBotMessage(
                    "DEFERRED SIGNAL OUTCOME RESOLVED"
                    + " | " + item.Trade.Side
                    + " | Result: " + result
                    + " | ForcedExit: " + item.ExitReason
                    + " | ExecutionNet: " + item.ExecutionNet.ToString("$0.00")
                    + " | HypotheticalSignalGross: " + hypotheticalGross.ToString("$0.00")
                    + " | OriginalSL: " + item.OriginalStopPrice.ToString("0.00")
                    + " | OriginalTP: " + item.OriginalTargetPrice.ToString("0.00")
                    + " | ForcedSignal W/L: " + pattern.ForcedSignalWins
                    + "/" + pattern.ForcedSignalLosses
                    + " | NOTE: advisory signal learning only; financial expectancy not rewritten."
                );
            }
        }

        private void ArmBreakevenFollowThrough(
            string patternKey,
            string eventKey,
            string side,
            double entryPrice,
            double originalTargetPrice)
        {
            if (
                string.IsNullOrWhiteSpace(patternKey) ||
                string.IsNullOrWhiteSpace(side) ||
                entryPrice <= 0 ||
                originalTargetPrice <= 0
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            JJBotBreakevenFollowThrough tracker =
                new JJBotBreakevenFollowThrough();

            tracker.PatternKey =
                patternKey;

            tracker.EventKey =
                eventKey ?? string.Empty;

            tracker.Side =
                side.Trim().ToUpperInvariant();

            tracker.EntryPrice =
                entryPrice;

            tracker.OriginalTargetPrice =
                originalTargetPrice;

            tracker.ExitTimeNy =
                nowNy;

            tracker.ExpiresTimeNy =
                nowNy.AddMinutes(
                    BeFollowThroughWindowMinutes
                );

            lock (beFollowThroughLock)
            {
                // Do not arm the same Learning event twice in this profile.
                bool alreadyExists =
                    beFollowThroughTrackers.Any(
                        item =>
                            item != null &&
                            !string.IsNullOrWhiteSpace(
                                tracker.EventKey
                            ) &&
                            string.Equals(
                                item.EventKey,
                                tracker.EventKey,
                                StringComparison.OrdinalIgnoreCase
                            )
                    );

                if (alreadyExists)
                {
                    return;
                }

                beFollowThroughTrackers.Add(
                    tracker
                );
            }

            PrintBotMessage(
                "BE FOLLOW-THROUGH ARMED"
                + " | "
                + tracker.PatternKey
                + " | Side: "
                + tracker.Side
                + " | Entry: "
                + tracker.EntryPrice.ToString("0.00")
                + " | OriginalTP: "
                + tracker.OriginalTargetPrice.ToString("0.00")
                + " | Window: "
                + BeFollowThroughWindowMinutes
                + "m"
            );
        }

        private void ResolveBreakevenFollowThrough(
            JJBotBreakevenFollowThrough tracker,
            bool targetHit,
            DateTime resolvedNy)
        {
            if (
                tracker == null ||
                string.IsNullOrWhiteSpace(
                    tracker.PatternKey
                )
            )
            {
                return;
            }

            int resolvedCount = 0;
            int hitCount = 0;
            double hitRate = 0;

            lock (SharedLearningSyncRoot)
            {
                JJBotLearningPattern pattern =
                    FindUserLearningPattern(
                        tracker.PatternKey
                    );

                if (pattern != null)
                {
                    pattern.BeFollowThroughResolved++;

                    if (targetHit)
                    {
                        pattern.BeFollowThroughTargetHits++;
                    }

                    SaveLearningMemory();

                    JJBotLearningPattern effectivePattern =
                        FindLearningPattern(
                            tracker.PatternKey
                        );

                    JJBotLearningPattern reportPattern =
                        effectivePattern ?? pattern;

                    resolvedCount =
                        reportPattern.BeFollowThroughResolved;

                    hitCount =
                        reportPattern.BeFollowThroughTargetHits;

                    hitRate =
                        resolvedCount > 0
                            ? (
                                (double)hitCount /
                                resolvedCount
                              ) * 100.0
                            : 0;
                }
            }

            double minutesAfterExit =
                Math.Max(
                    0,
                    (
                        resolvedNy -
                        tracker.ExitTimeNy
                    ).TotalMinutes
                );

            PrintBotMessage(
                targetHit
                    ? "BE FOLLOW-THROUGH TARGET HIT"
                    : "BE FOLLOW-THROUGH EXPIRED"
                + " | "
                + tracker.PatternKey
                + " | Side: "
                + tracker.Side
                + " | OriginalTP: "
                + tracker.OriginalTargetPrice.ToString("0.00")
                + " | After: "
                + minutesAfterExit.ToString("0.0")
                + "m"
                + " | Resolved: "
                + resolvedCount
                + " | TP Hits: "
                + hitCount
                + " | HitRate: "
                + hitRate.ToString("0.0")
                + "%"
            );
        }

        private void UpdateBreakevenFollowThrough(
            double liveHigh,
            double liveLow,
            DateTime marketNy)
        {
            if (
                liveHigh <= 0 ||
                liveLow <= 0 ||
                marketNy == DateTime.MinValue
            )
            {
                return;
            }

            List<JJBotBreakevenFollowThrough> resolved =
                new List<JJBotBreakevenFollowThrough>();

            List<bool> results =
                new List<bool>();

            lock (beFollowThroughLock)
            {
                for (
                    int i =
                        beFollowThroughTrackers.Count - 1;
                    i >= 0;
                    i--
                )
                {
                    JJBotBreakevenFollowThrough tracker =
                        beFollowThroughTrackers[i];

                    if (tracker == null)
                    {
                        beFollowThroughTrackers.RemoveAt(i);
                        continue;
                    }

                    bool targetHit =
                        string.Equals(
                            tracker.Side,
                            "LONG",
                            StringComparison.OrdinalIgnoreCase
                        )
                            ? liveHigh >=
                                tracker.OriginalTargetPrice
                            : liveLow <=
                                tracker.OriginalTargetPrice;

                    bool expired =
                        marketNy >=
                            tracker.ExpiresTimeNy ||
                        marketNy.Date !=
                            tracker.ExitTimeNy.Date ||
                        ToTimeInt(
                            marketNy
                        ) >=
                            ForceFlatTimeNy;

                    if (
                        !targetHit &&
                        !expired
                    )
                    {
                        continue;
                    }

                    resolved.Add(
                        tracker
                    );

                    results.Add(
                        targetHit
                    );

                    beFollowThroughTrackers.RemoveAt(i);
                }
            }

            for (
                int i = 0;
                i < resolved.Count;
                i++
            )
            {
                ResolveBreakevenFollowThrough(
                    resolved[i],
                    results[i],
                    marketNy
                );
            }
        }

        private string GetLearningFolderPath()
        {
            return Path.Combine(
                stateFolderPath,
                "Learning"
            );
        }

        private string GetLearningBaseFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Base"
            );
        }

        private string GetLearningUserFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "User"
            );
        }

        private string GetLearningEffectiveFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Effective"
            );
        }

        private string GetLearningArchiveFolderPath()
        {
            return Path.Combine(
                GetLearningFolderPath(),
                "Archive"
            );
        }

        private string GetLearningSafeInstrument()
        {
            if (selectedInstrument == null)
            {
                return string.Empty;
            }

            return MakeSafeFileName(
                selectedInstrument.FullName
            );
        }

        // Compatibility name used by the shared-memory store.
        // From V1.6.7 onward this points to the writable USER layer.
        private string GetLearningMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningUserFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLearningBaseMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningBaseFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLearningEffectiveMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningEffectiveFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string GetLegacyLearningMemoryFilePath()
        {
            string safeInstrument =
                GetLearningSafeInstrument();

            if (string.IsNullOrWhiteSpace(safeInstrument))
            {
                return string.Empty;
            }

            return Path.Combine(
                GetLearningFolderPath(),
                "memory_" + safeInstrument + ".xml"
            );
        }

        private string ReadLearningBaseVersion()
        {
            try
            {
                string versionPath =
                    Path.Combine(
                        GetLearningBaseFolderPath(),
                        "version.txt"
                    );

                if (!File.Exists(versionPath))
                {
                    return "NONE";
                }

                string value =
                    File.ReadAllText(versionPath)
                        .Trim();

                return string.IsNullOrWhiteSpace(value)
                    ? "UNKNOWN"
                    : value;
            }
            catch
            {
                return "UNKNOWN";
            }
        }

        private JJBotLearningMemory LoadLearningMemoryFile(
            string path)
        {
            JJBotLearningMemory result =
                new JJBotLearningMemory();

            if (
                string.IsNullOrWhiteSpace(path) ||
                !File.Exists(path)
            )
            {
                return result;
            }

            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(JJBotLearningMemory)
                );

            using (
                FileStream stream =
                    new FileStream(
                        path,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read
                    )
            )
            {
                JJBotLearningMemory loaded =
                    serializer.Deserialize(stream)
                        as JJBotLearningMemory;

                if (loaded != null)
                {
                    result = loaded;
                }
            }

            if (result.Patterns == null)
            {
                result.Patterns =
                    new List<JJBotLearningPattern>();
            }

            return result;
        }

        private JJBotLearningPattern CloneLearningPattern(
            JJBotLearningPattern source)
        {
            if (source == null)
            {
                return null;
            }

            return new JJBotLearningPattern
            {
                Key = source.Key ?? string.Empty,
                Side = source.Side ?? string.Empty,
                SessionWindow = source.SessionWindow ?? string.Empty,
                Structure = source.Structure ?? string.Empty,
                Trades = source.Trades,
                Wins = source.Wins,
                Losses = source.Losses,
                Breakevens = source.Breakevens,
                NetPnL = source.NetPnL,
                TotalMfe = source.TotalMfe,
                TotalMae = source.TotalMae,
                LocationSamples = source.LocationSamples,
                PoorLocationTrades = source.PoorLocationTrades,
                TotalEntryRoomTicks = source.TotalEntryRoomTicks,
                TotalEntryEfficiency = source.TotalEntryEfficiency,
                BeFollowThroughResolved =
                    source.BeFollowThroughResolved,
                BeFollowThroughTargetHits =
                    source.BeFollowThroughTargetHits,
                RecentWeight = source.RecentWeight,
                RecentWins = source.RecentWins,
                RecentNetPnL = source.RecentNetPnL,
                RecentTotalMfe = source.RecentTotalMfe,
                RecentTotalMae = source.RecentTotalMae,
                RecentAsOfUtc = source.RecentAsOfUtc,
                ConfidenceTrades = source.ConfidenceTrades,
                ConfidenceWins = source.ConfidenceWins,
                TechnicalConfidenceSum =
                    source.TechnicalConfidenceSum,
                ConfidenceNetPnL =
                    source.ConfidenceNetPnL
            };
        }

        private void AddLearningPatternInto(
            Dictionary<string, JJBotLearningPattern> map,
            JJBotLearningPattern source)
        {
            if (
                map == null ||
                source == null
            )
            {
                return;
            }

            string key =
                string.IsNullOrWhiteSpace(source.Key)
                    ? (
                        (source.Side ?? "UNKNOWN")
                        + "|"
                        + (source.Structure ?? "UNKNOWN")
                      )
                    : source.Key;

            JJBotLearningPattern target;

            if (!map.TryGetValue(key, out target))
            {
                target =
                    CloneLearningPattern(source);

                target.Key = key;
                map[key] = target;
                return;
            }

            target.Trades += source.Trades;
            target.Wins += source.Wins;
            target.Losses += source.Losses;
            target.Breakevens += source.Breakevens;
            target.NetPnL += source.NetPnL;

            target.ConfidenceTrades +=
                source.ConfidenceTrades;

            target.ConfidenceWins +=
                source.ConfidenceWins;

            target.TechnicalConfidenceSum +=
                source.TechnicalConfidenceSum;

            target.ConfidenceNetPnL +=
                source.ConfidenceNetPnL;
            target.TotalMfe += source.TotalMfe;
            target.TotalMae += source.TotalMae;
            target.LocationSamples += source.LocationSamples;
            target.PoorLocationTrades += source.PoorLocationTrades;
            target.TotalEntryRoomTicks += source.TotalEntryRoomTicks;
            target.TotalEntryEfficiency += source.TotalEntryEfficiency;
            target.BeFollowThroughResolved +=
                source.BeFollowThroughResolved;
            target.BeFollowThroughTargetHits +=
                source.BeFollowThroughTargetHits;

            // Normalize both recency accumulators to the same clock before merge.
            DateTime mergeUtc = DateTime.UtcNow;
            double targetDecay =
                GetLearningRecencyDecay(
                    target.RecentAsOfUtc,
                    mergeUtc
                );

            target.RecentWeight *= targetDecay;
            target.RecentWins *= targetDecay;
            target.RecentNetPnL *= targetDecay;
            target.RecentTotalMfe *= targetDecay;
            target.RecentTotalMae *= targetDecay;
            target.RecentAsOfUtc = mergeUtc;

            AddRecentLearningEvidence(
                target,
                source,
                mergeUtc
            );
        }

        private JJBotLearningMemory MergeLearningMemories(
            JJBotLearningMemory baseMemory,
            JJBotLearningMemory userMemory)
        {
            Dictionary<string, JJBotLearningPattern> map =
                new Dictionary<string, JJBotLearningPattern>(
                    StringComparer.OrdinalIgnoreCase
                );

            if (
                baseMemory != null &&
                baseMemory.Patterns != null
            )
            {
                foreach (
                    JJBotLearningPattern pattern
                    in baseMemory.Patterns
                )
                {
                    AddLearningPatternInto(map, pattern);
                }
            }

            if (
                userMemory != null &&
                userMemory.Patterns != null
            )
            {
                foreach (
                    JJBotLearningPattern pattern
                    in userMemory.Patterns
                )
                {
                    AddLearningPatternInto(map, pattern);
                }
            }

            JJBotLearningMemory merged =
                new JJBotLearningMemory();

            merged.Patterns =
                map.Values
                    .OrderBy(p => p.Key)
                    .ToList();

            return merged;
        }

        private void RebuildEffectiveLearningMemoryInPlace()
        {
            JJBotLearningMemory merged =
                MergeLearningMemories(
                    baseLearningMemory,
                    userLearningMemory
                );

            if (learningMemory == null)
            {
                learningMemory =
                    new JJBotLearningMemory();
            }

            if (learningMemory.Patterns == null)
            {
                learningMemory.Patterns =
                    new List<JJBotLearningPattern>();
            }

            learningMemory.Patterns.Clear();

            foreach (
                JJBotLearningPattern pattern
                in merged.Patterns
            )
            {
                learningMemory.Patterns.Add(pattern);
            }
        }

        private void SerializeLearningMemory(
            string path,
            JJBotLearningMemory memory)
        {
            if (
                string.IsNullOrWhiteSpace(path) ||
                memory == null
            )
            {
                return;
            }

            Directory.CreateDirectory(
                Path.GetDirectoryName(path)
            );

            XmlSerializer serializer =
                new XmlSerializer(
                    typeof(JJBotLearningMemory)
                );

            string tempPath =
                path + ".tmp";

            using (
                FileStream stream =
                    new FileStream(
                        tempPath,
                        FileMode.Create,
                        FileAccess.Write,
                        FileShare.None
                    )
            )
            {
                serializer.Serialize(
                    stream,
                    memory
                );
            }

            if (File.Exists(path))
            {
                File.Delete(path);
            }

            File.Move(tempPath, path);
        }

        private void MigrateLegacyLearningIfNeeded(
            string basePath,
            string userPath)
        {
            if (
                string.IsNullOrWhiteSpace(userPath) ||
                File.Exists(userPath)
            )
            {
                return;
            }

            string legacyPath =
                GetLegacyLearningMemoryFilePath();

            if (
                string.IsNullOrWhiteSpace(legacyPath) ||
                !File.Exists(legacyPath)
            )
            {
                return;
            }

            bool publisherPromotion =
                File.Exists(
                    Path.Combine(
                        GetLearningFolderPath(),
                        "publisher-base-promoted.flag"
                    )
                ) &&
                !string.IsNullOrWhiteSpace(basePath) &&
                File.Exists(basePath);

            Directory.CreateDirectory(
                GetLearningArchiveFolderPath()
            );

            string archivePath =
                Path.Combine(
                    GetLearningArchiveFolderPath(),
                    Path.GetFileNameWithoutExtension(legacyPath)
                    + "_legacy_"
                    + DateTime.UtcNow.ToString("yyyyMMddHHmmss")
                    + ".xml"
                );

            if (publisherPromotion)
            {
                File.Move(legacyPath, archivePath);

                PrintBotMessage(
                    "LEARNING LEGACY ARCHIVED - OFFICIAL BASE ALREADY CONTAINS IT"
                );

                return;
            }

            Directory.CreateDirectory(
                GetLearningUserFolderPath()
            );

            File.Copy(
                legacyPath,
                userPath,
                true
            );

            File.Move(
                legacyPath,
                archivePath
            );

            PrintBotMessage(
                "LEARNING MIGRATED"
                + " | Legacy -> User"
                + " | Instrument: "
                + (
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : "UNKNOWN"
                  )
            );
        }

        private int CountLearningTrades(
            JJBotLearningMemory memory)
        {
            if (
                memory == null ||
                memory.Patterns == null
            )
            {
                return 0;
            }

            int total = 0;

            foreach (
                JJBotLearningPattern pattern
                in memory.Patterns
            )
            {
                if (pattern != null)
                {
                    total += pattern.Trades;
                }
            }

            return total;
        }

        private void LoadLearningMemory()
        {
            try
            {
                string userPath =
                    GetLearningMemoryFilePath();

                string basePath =
                    GetLearningBaseMemoryFilePath();

                if (string.IsNullOrWhiteSpace(userPath))
                {
                    baseLearningMemory =
                        new JJBotLearningMemory();
                    userLearningMemory =
                        new JJBotLearningMemory();
                    learningMemory =
                        new JJBotLearningMemory();
                    learningBaseVersion = "NONE";
                    return;
                }

                lock (SharedLearningSyncRoot)
                {
                    Directory.CreateDirectory(
                        GetLearningFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningBaseFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningUserFolderPath()
                    );
                    Directory.CreateDirectory(
                        GetLearningEffectiveFolderPath()
                    );

                    MigrateLegacyLearningIfNeeded(
                        basePath,
                        userPath
                    );

                    JJBotLearningMemory sharedEffective;
                    JJBotLearningMemory sharedUser;

                    bool hasEffective =
                        SharedLearningMemories.TryGetValue(
                            userPath,
                            out sharedEffective
                        ) &&
                        sharedEffective != null;

                    bool hasUser =
                        SharedUserLearningMemories.TryGetValue(
                            userPath,
                            out sharedUser
                        ) &&
                        sharedUser != null;

                    if (hasEffective && hasUser)
                    {
                        learningMemory =
                            sharedEffective;
                        userLearningMemory =
                            sharedUser;

                        // Base is read-only and can be loaded per profile;
                        // it changes only while NinjaTrader is closed.
                        baseLearningMemory =
                            LoadLearningMemoryFile(basePath);

                        learningBaseVersion =
                            ReadLearningBaseVersion();

                        return;
                    }

                    baseLearningMemory =
                        LoadLearningMemoryFile(basePath);

                    userLearningMemory =
                        LoadLearningMemoryFile(userPath);

                    learningMemory =
                        new JJBotLearningMemory();

                    RebuildEffectiveLearningMemoryInPlace();

                    SharedLearningMemories[userPath] =
                        learningMemory;

                    SharedUserLearningMemories[userPath] =
                        userLearningMemory;

                    learningBaseVersion =
                        ReadLearningBaseVersion();

                    // Effective is a read-only export/snapshot used by the
                    // publisher promotion script and diagnostics.
                    SerializeLearningMemory(
                        GetLearningEffectiveMemoryFilePath(),
                        learningMemory
                    );
                }

                PrintBotMessage(
                    "TWO-LAYER LEARNING ATTACHED"
                    + " | "
                    + platformProfileId
                    + " | Instrument: "
                    + (
                        selectedInstrument != null
                            ? selectedInstrument.FullName
                            : "UNKNOWN"
                      )
                    + " | BaseVersion: "
                    + learningBaseVersion
                    + " | BaseTrades: "
                    + CountLearningTrades(baseLearningMemory)
                    + " | UserTrades: "
                    + CountLearningTrades(userLearningMemory)
                    + " | EffectiveTrades: "
                    + CountLearningTrades(learningMemory)
                );
            }
            catch (Exception ex)
            {
                lock (SharedLearningSyncRoot)
                {
                    baseLearningMemory =
                        new JJBotLearningMemory();
                    userLearningMemory =
                        new JJBotLearningMemory();
                    learningMemory =
                        new JJBotLearningMemory();
                    learningBaseVersion = "ERROR";

                    string path =
                        GetLearningMemoryFilePath();

                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        SharedLearningMemories[path] =
                            learningMemory;
                        SharedUserLearningMemories[path] =
                            userLearningMemory;
                    }
                }

                PrintBotMessage(
                    "LEARNING LOAD ERROR: "
                    + ex.Message
                );
            }
        }

        private void SaveLearningMemory()
        {
            try
            {
                if (
                    selectedInstrument == null ||
                    userLearningMemory == null
                )
                {
                    return;
                }

                lock (SharedLearningSyncRoot)
                {
                    string userPath =
                        GetLearningMemoryFilePath();

                    if (string.IsNullOrWhiteSpace(userPath))
                    {
                        return;
                    }

                    // ONLY the User layer is writable.
                    SerializeLearningMemory(
                        userPath,
                        userLearningMemory
                    );

                    RebuildEffectiveLearningMemoryInPlace();

                    SharedLearningMemories[userPath] =
                        learningMemory;

                    SharedUserLearningMemories[userPath] =
                        userLearningMemory;

                    // Read-only merged snapshot for export/debugging.
                    SerializeLearningMemory(
                        GetLearningEffectiveMemoryFilePath(),
                        learningMemory
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING SAVE ERROR: "
                    + ex.Message
                );
            }
        }

        private void LogLearningDecision(
            DateTime decisionNyTime,
            string trend,
            string vwapSide,
            string liquidity,
            string structure,
            string setup,
            int buyScore,
            int sellScore)
        {
            try
            {
                if (
                    selectedInstrument == null
                )
                {
                    return;
                }

                Directory.CreateDirectory(
                    GetLearningFolderPath()
                );

                string safeInstrument =
                    MakeSafeFileName(
                        selectedInstrument.FullName
                    );

                string filePath =
                    Path.Combine(
                        GetLearningFolderPath(),
                        "decisions_"
                            + decisionNyTime.ToString(
                                "yyyy-MM-dd"
                            )
                            + "_"
                            + safeInstrument
                            + ".csv"
                    );

                bool writeHeader =
                    !File.Exists(
                        filePath
                    );

                using (
                    StreamWriter writer =
                        new StreamWriter(
                            filePath,
                            true
                        )
                )
                {
                    if (writeHeader)
                    {
                        writer.WriteLine(
                            "TimeNY,Session,Trend,VWAP,Sweep,Structure,Setup,BuyScore,SellScore"
                        );
                    }

                    writer.WriteLine(
                        decisionNyTime.ToString(
                            "yyyy-MM-dd HH:mm:ss"
                        )
                        + ","
                        + GetBotSessionWindow(
                            decisionNyTime
                        )
                        + ","
                        + EscapeCsv(
                            trend
                        )
                        + ","
                        + EscapeCsv(
                            vwapSide
                        )
                        + ","
                        + EscapeCsv(
                            liquidity
                        )
                        + ","
                        + EscapeCsv(
                            structure
                        )
                        + ","
                        + EscapeCsv(
                            setup
                        )
                        + ","
                        + buyScore
                        + ","
                        + sellScore
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "LEARNING DECISION LOG ERROR: "
                    + ex.Message
                );
            }
        }

        private string EscapeCsv(
            string value)
        {
            if (value == null)
                return string.Empty;

            string escaped =
                value.Replace(
                    "\"",
                    "\"\""
                );

            if (
                escaped.Contains(",") ||
                escaped.Contains("\"") ||
                escaped.Contains("\n") ||
                escaped.Contains("\r")
            )
            {
                return
                    "\""
                    + escaped
                    + "\"";
            }

            return escaped;
        }


    }
}

#region Using declarations
using System;
using System.Globalization;
using System.IO;
using System.Text;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.76 - LONDON RECORDER (LOG ONLY, NEVER TRADES)
    // Records the market-data stream around the London open so the 03:00 NY pattern can be
    // studied offline with real bid/ask data. It never sends, changes or cancels orders and
    // it does not read or change any bot state.
    //   20:00-02:30 NY : one row per 60 s   (builds the Asia range)
    //   02:30-04:00 NY : one row per 1 s    (London open, first-candle volume)
    // File: Documents\NinjaTrader 8\JJBotData\London\london_<yyyyMMdd>.csv  (date = London morning)
    // Columns: Time,Sec,Open,High,Low,Last,Vol,BuyVol,SellVol,UnkVol,Trades,Bid,Ask,BidSz,AskSz
    //   BuyVol  = trades at/above the ask, SellVol = trades at/below the bid, UnkVol = inside the spread.
    //   BidSz/AskSz = size at the best bid / best ask at the end of the bucket.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool LondonRecorderEnabled = true;
        private static readonly TimeSpan LondonFastStart = new TimeSpan(2, 30, 0);
        private static readonly TimeSpan LondonEnd = new TimeSpan(4, 0, 0);
        private static readonly TimeSpan LondonSlowStart = new TimeSpan(20, 0, 0);

        private readonly object londonSync = new object();
        private double londonBid, londonAsk, londonBidSz, londonAskSz;
        private bool londonHave;
        private DateTime londonBucketStart = DateTime.MinValue;
        private int londonBucketSec;
        private string londonFileDate = string.Empty;
        private double lOpen, lHigh, lLow, lLast, lVol, lBuy, lSell, lUnk;
        private int lTrades;
        private readonly StringBuilder londonBuffer = new StringBuilder();
        private DateTime londonLastFlushUtc = DateTime.MinValue;
        private string londonPath = string.Empty;

        private void LondonRecorderOnMarketData(MarketDataEventArgs e)
        {
            if (!LondonRecorderEnabled || e == null)
                return;

            try
            {
                lock (londonSync)
                {
                    if (e.MarketDataType == MarketDataType.Bid)
                    {
                        londonBid = e.Price;
                        londonBidSz = e.Volume;
                        return;
                    }

                    if (e.MarketDataType == MarketDataType.Ask)
                    {
                        londonAsk = e.Price;
                        londonAskSz = e.Volume;
                        return;
                    }

                    if (e.MarketDataType != MarketDataType.Last)
                        return;

                    DateTime ny = ConvertToNewYorkTime(e.Time);
                    TimeSpan tod = ny.TimeOfDay;
                    bool fast = tod >= LondonFastStart && tod < LondonEnd;
                    bool slow = tod >= LondonSlowStart || tod < LondonFastStart;

                    if (!fast && !slow)
                    {
                        // outside the window: write what is pending and stop
                        CloseLondonBucket();
                        FlushLondon(true);
                        return;
                    }

                    int sec = fast ? 1 : 60;
                    long totalSec = (long)Math.Floor(ny.TimeOfDay.TotalSeconds);
                    long b = (totalSec / sec) * sec;
                    DateTime start = ny.Date.AddSeconds(b);

                    if (londonBucketStart != DateTime.MinValue && (start != londonBucketStart || sec != londonBucketSec))
                        CloseLondonBucket();

                    double p = e.Price;
                    double v = e.Volume;

                    if (londonBucketStart == DateTime.MinValue)
                    {
                        londonBucketStart = start;
                        londonBucketSec = sec;
                        lOpen = p; lHigh = p; lLow = p; lLast = p;
                        lVol = 0; lBuy = 0; lSell = 0; lUnk = 0; lTrades = 0;
                    }

                    if (p > lHigh) lHigh = p;
                    if (p < lLow) lLow = p;
                    lLast = p;
                    lVol += v;
                    lTrades++;

                    if (londonAsk > 0 && p >= londonAsk) lBuy += v;
                    else if (londonBid > 0 && p <= londonBid) lSell += v;
                    else lUnk += v;
                }
            }
            catch
            {
                // log-only module: never let it affect the bot
            }
        }

        // Called with londonSync held.
        private void CloseLondonBucket()
        {
            if (londonBucketStart == DateTime.MinValue)
                return;

            DateTime s = londonBucketStart;
            // the file date is the London morning: evening rows (>= 20:00) belong to the next day
            DateTime fileDay = s.TimeOfDay >= LondonSlowStart ? s.Date.AddDays(1) : s.Date;
            string fd = fileDay.ToString("yyyyMMdd", CultureInfo.InvariantCulture);

            if (fd != londonFileDate)
            {
                FlushLondon(true);
                londonFileDate = fd;
                londonPath = string.Empty;
            }

            CultureInfo ci = CultureInfo.InvariantCulture;
            londonBuffer.Append(s.ToString("HH:mm:ss", ci)).Append(',')
                .Append(londonBucketSec.ToString(ci)).Append(',')
                .Append(lOpen.ToString("0.00", ci)).Append(',')
                .Append(lHigh.ToString("0.00", ci)).Append(',')
                .Append(lLow.ToString("0.00", ci)).Append(',')
                .Append(lLast.ToString("0.00", ci)).Append(',')
                .Append(lVol.ToString("0", ci)).Append(',')
                .Append(lBuy.ToString("0", ci)).Append(',')
                .Append(lSell.ToString("0", ci)).Append(',')
                .Append(lUnk.ToString("0", ci)).Append(',')
                .Append(lTrades.ToString(ci)).Append(',')
                .Append(londonBid.ToString("0.00", ci)).Append(',')
                .Append(londonAsk.ToString("0.00", ci)).Append(',')
                .Append(londonBidSz.ToString("0", ci)).Append(',')
                .Append(londonAskSz.ToString("0", ci))
                .Append(Environment.NewLine);

            londonBucketStart = DateTime.MinValue;

            if (londonBuffer.Length > 6000 || (DateTime.UtcNow - londonLastFlushUtc).TotalSeconds > 20)
                FlushLondon(false);
        }

        // Called with londonSync held.
        private void FlushLondon(bool force)
        {
            if (londonBuffer.Length == 0)
                return;

            try
            {
                if (string.IsNullOrEmpty(londonFileDate))
                {
                    londonBuffer.Clear();
                    return;
                }

                if (string.IsNullOrEmpty(londonPath))
                {
                    string root = stateFolderPath;

                    if (string.IsNullOrWhiteSpace(root))
                    {
                        root = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                            "NinjaTrader 8",
                            "JJBotData");
                    }

                    string dir = Path.Combine(root, "London");
                    Directory.CreateDirectory(dir);

                    string inst = selectedInstrument != null && selectedInstrument.MasterInstrument != null
                        ? selectedInstrument.MasterInstrument.Name
                        : "NOINST";

                    londonPath = Path.Combine(dir, "london_" + inst + "_" + londonFileDate + ".csv");

                    if (!File.Exists(londonPath))
                    {
                        File.WriteAllText(
                            londonPath,
                            "Time,Sec,Open,High,Low,Last,Vol,BuyVol,SellVol,UnkVol,Trades,Bid,Ask,BidSz,AskSz"
                            + Environment.NewLine);
                    }
                }

                File.AppendAllText(londonPath, londonBuffer.ToString());
                londonBuffer.Clear();
                londonLastFlushUtc = DateTime.UtcNow;
            }
            catch
            {
                // keep the buffer bounded if the disk is not writable
                if (londonBuffer.Length > 200000)
                    londonBuffer.Clear();
            }
        }
    }
}

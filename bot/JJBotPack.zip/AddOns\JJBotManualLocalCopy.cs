// JJ_MANUAL_LOCAL_COPY_V1 (2026-11-16)
//
// Copia LOCAL de los trades MANUALES de una cuenta master a sus slaves.
//
// Por que existe:
//   Hasta hoy toda copia daba la vuelta por el Linux: la master se llenaba -> Ninja
//   posteaba a /api/trades/record -> el backend encolaba un COPY_TRADE -> Ninja lo
//   recogia en el poll de /api/ninja/commands (cada 100 ms) -> recien ahi mandaba la
//   orden a la slave. Eso son cientos de ms justo al entrar y al salir, y ademas el
//   backend nunca generaba COPY_TRADE para un fill manual, asi que el manual no se
//   copiaba nunca.
//
//   Aqui la master le habla a la slave directamente, sin red de por medio. El mapa de
//   grupos ya esta en memoria (JJBotCopySyncGuard lo refresca cada 3 s), asi que no
//   hace falta preguntarle nada al servidor en el momento del fill.
//
// Alcance de esta version (V1):
//   - SOLO ejecuciones MANUALES. Las del bot (P<n>_JJ_*) siguen por el camino del
//     servidor, intacto. Si esto sale bien unos dias, se mueven tambien.
//   - Cantidad: la que puso el usuario (espejo), topada por MaxContracts del grupo.
//   - Entradas y salidas: ExecuteCopyTrade ya maneja ambas con la cantidad exacta.
//   - Respeta Reverse y el lock diario (JJ_SLAVE_DAILY_GUARD_V1) del grupo.
//   - Si la ruta tiene Micro activo, NO copia y lo registra: esa conversion la hace
//     el backend y aqui no se replica a ciegas.
//
// Lo que NO hace todavia (pendiente, ver chat 2026-11-16):
//   - Replicar las distancias exactas de stop/target del ATM del usuario. La slave
//     queda con la proteccion que tenga configurada el grupo.
//   - Guard bot-vs-manual fino: falta decidir con que marca se distingue una posicion
//     abierta por el bot de una abierta por el copiador en la slave.
//
// Apagar: JJManualLocalCopyEnabled = false.

using System;
using System.Collections.Generic;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJCompanyBroAddon
    {
        private static readonly bool JJManualLocalCopyEnabled = false;   // REVERTIDO 2026-11-16: duplicaba la copia (ver chat). No reactivar sin revisar server.js.

        // Las ordenes del bot se llaman P<n>_JJ_ENTRY_LONG / P<n>_JJ_STOP / etc.
        // (GetProfileOrderName -> "P" + profileNumber + "_"). Todo lo que NO empieza
        // asi y no trae JJ_COPY lo tratamos como manual.
        private static bool JJManualLocalCopyIsBotOrderName(string orderName)
        {
            if (string.IsNullOrEmpty(orderName))
                return false;

            if (orderName[0] != 'P' && orderName[0] != 'p')
                return false;

            int i = 1;
            while (i < orderName.Length && orderName[i] >= '0' && orderName[i] <= '9')
                i++;

            if (i == 1)
                return false; // "P" sin numero: no es del bot

            return i < orderName.Length && orderName[i] == '_';
        }

        // Llamado desde OnAccountExecutionUpdate (JJCompanyBroAddOn.cs), justo despues
        // de SendTrade. Nunca lanza: una excepcion aqui no debe tocar el journal.
        private void JJManualLocalCopyOnExecution(
            string masterAccountName,
            string symbol,
            string orderName,
            string orderAction,
            int executionQuantity)
        {
            try
            {
                if (!JJManualLocalCopyEnabled)
                    return;

                if (string.IsNullOrWhiteSpace(masterAccountName) ||
                    string.IsNullOrWhiteSpace(symbol) ||
                    string.IsNullOrWhiteSpace(orderAction) ||
                    executionQuantity <= 0)
                    return;

                // Red de seguridad: una copia nunca puede generar otra copia.
                if (!string.IsNullOrEmpty(orderName) &&
                    orderName.IndexOf("JJ_COPY", StringComparison.OrdinalIgnoreCase) >= 0)
                    return;

                // V1: los trades del bot siguen por el servidor.
                if (JJManualLocalCopyIsBotOrderName(orderName))
                    return;

                if (!copySyncCopierEnabled)
                    return;

                List<CopySyncRoute> routes = copySyncRoutes;

                if (routes == null || routes.Count == 0)
                    return;

                foreach (CopySyncRoute route in routes)
                {
                    if (route == null ||
                        string.IsNullOrWhiteSpace(route.Master) ||
                        string.IsNullOrWhiteSpace(route.Slave))
                        continue;

                    if (!string.Equals(route.Master, masterAccountName, StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (route.Locked)
                    {
                        Print("JJ MANUAL COPY: " + route.Slave + " bloqueada hoy por su limite diario. No se copia.");
                        continue;
                    }

                    if (route.Micro)
                    {
                        Print("JJ MANUAL COPY: " + route.Slave + " tiene Micro activo. V1 no convierte micros, no se copia.");
                        continue;
                    }

                    int qty = executionQuantity;

                    if (route.MaxContracts > 0 && qty > route.MaxContracts)
                    {
                        Print("JJ MANUAL COPY: " + route.Slave + " topada a " + route.MaxContracts +
                              " contratos (la master puso " + executionQuantity + ").");
                        qty = route.MaxContracts;
                    }

                    string action = orderAction.ToUpperInvariant();

                    if (route.Reverse)
                    {
                        if (action == "BUY") action = "SELLSHORT";
                        else if (action == "SELLSHORT") action = "BUY";
                        else if (action == "SELL") action = "BUYTOCOVER";
                        else if (action == "BUYTOCOVER") action = "SELL";
                    }

                    Print("JJ MANUAL COPY LOCAL: " + masterAccountName + " -> " + route.Slave +
                          " | " + action + " x" + qty + " " + symbol +
                          (route.Reverse ? " | REVERSE" : "") + " | orden: " + (orderName ?? "(sin nombre)"));

                    ExecuteCopyTrade(route.Slave, symbol, action, qty);
                }
            }
            catch (Exception ex)
            {
                Print("ERROR JJManualLocalCopyOnExecution: " + ex.Message);
            }
        }
    }
}

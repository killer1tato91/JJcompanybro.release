#region Using declarations
using System;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT HIGHER-TIMEFRAME MARKET CONTEXT
    // Stage 5 segmentation from JJBotControl v1.6.20.
    //
    // Structural refactor only:
    // - 1H context loading/update
    // - 4H context loading/update
    // - HTF trend classification
    // - HTF LONG/SHORT scores
    //
    // No entry, momentum, risk, learning, or order logic changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void OnH1BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "1H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 1H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h1BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "1H",
                false
            );

            PrintBotMessage(
                "1H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }
        private void OnH4BarsRequestCompleted(
            BarsRequest request,
            ErrorCode errorCode,
            string errorMessage)
        {
            if (
                errorCode != ErrorCode.NoError
            )
            {
                PrintBotMessage(
                    "4H CONTEXT REQUEST ERROR: "
                    + errorCode
                    + " | "
                    + errorMessage
                );

                return;
            }

            if (
                request == null ||
                request.Bars == null ||
                request.Bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                PrintBotMessage(
                    "NOT ENOUGH 4H BARS FOR EMA 200 CONTEXT."
                );

                return;
            }

            h4BarsReady = true;

            UpdateHigherTimeframeContext(
                request.Bars,
                "4H",
                false
            );

            PrintBotMessage(
                "4H CONTEXT DATA READY | BARS: "
                + request.Bars.Count
            );
        }
        private void OnH1BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h1BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h1BarsRequest == null ||
                    h1BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h1BarsRequest.Bars,
                    "1H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "1H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void OnH4BarsRequestUpdate(
            object sender,
            BarsUpdateEventArgs e)
        {
            try
            {
                if (
                    !botRunning ||
                    !h4BarsReady ||
                    e == null ||
                    e.BarsSeries == null
                )
                {
                    return;
                }

                if (
                    h4BarsRequest == null ||
                    h4BarsRequest.Bars == null
                )
                {
                    return;
                }

                UpdateHigherTimeframeContext(
                    h4BarsRequest.Bars,
                    "4H",
                    true
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "4H CONTEXT UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void UpdateHigherTimeframeContext(
            Bars bars,
            string timeframe,
            bool realTimeUpdate)
        {
            if (
                bars == null ||
                bars.Count <
                    HtfSlowEmaPeriod + 2
            )
            {
                return;
            }

            int closedIndex =
                bars.Count - 2;

            if (
                closedIndex <
                    HtfSlowEmaPeriod
            )
            {
                return;
            }

            DateTime closedTime =
                bars.GetTime(
                    closedIndex
                );

            if (
                timeframe == "1H" &&
                closedTime ==
                    lastH1BarTime
            )
            {
                return;
            }

            if (
                timeframe == "4H" &&
                closedTime ==
                    lastH4BarTime
            )
            {
                return;
            }

            double ema50 =
                CalculateEma(
                    bars,
                    HtfFastEmaPeriod,
                    closedIndex
                );

            double ema200 =
                CalculateEma(
                    bars,
                    HtfSlowEmaPeriod,
                    closedIndex
                );

            double close =
                bars.GetClose(
                    closedIndex
                );

            string trend =
                close > ema50 &&
                ema50 > ema200
                    ? "BULLISH"
                    : close < ema50 &&
                      ema50 < ema200
                        ? "BEARISH"
                        : ema50 > ema200
                            ? "BULLISH WEAK"
                            : ema50 < ema200
                                ? "BEARISH WEAK"
                                : "NEUTRAL";

            lock (marketContextLock)
            {
                if (timeframe == "1H")
                {
                    latestH1Trend =
                        trend;

                    lastH1BarTime =
                        closedTime;
                }
                else
                {
                    latestH4Trend =
                        trend;

                    lastH4BarTime =
                        closedTime;
                }

                RecalculateHigherTimeframeScores();
            }

            PrintBotMessage(
                "HTF CONTEXT "
                + timeframe
                + " | "
                + trend
                + " | Close: "
                + close.ToString("0.00")
                + " | EMA50: "
                + ema50.ToString("0.00")
                + " | EMA200: "
                + ema200.ToString("0.00")
                + " | LONG "
                + latestHtfLongScore
                + "/2"
                + " | SHORT "
                + latestHtfShortScore
                + "/2"
            );

            PublishSharedState();
        }
        private void RecalculateHigherTimeframeScores()
        {
            latestHtfLongScore = 0;
            latestHtfShortScore = 0;

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BULLISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfLongScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH4Trend
                ) &&
                latestH4Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            if (
                !string.IsNullOrWhiteSpace(
                    latestH1Trend
                ) &&
                latestH1Trend.StartsWith(
                    "BEARISH",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                latestHtfShortScore++;
            }

            latestHtfContextBias =
                latestHtfLongScore >
                    latestHtfShortScore
                    ? "LONG "
                        + latestHtfLongScore
                        + "/2"
                    : latestHtfShortScore >
                        latestHtfLongScore
                        ? "SHORT "
                            + latestHtfShortScore
                            + "/2"
                        : "NEUTRAL "
                            + latestHtfLongScore
                            + "/2";
        }

    }
}

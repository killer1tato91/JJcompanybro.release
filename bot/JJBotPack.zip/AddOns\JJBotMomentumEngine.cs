﻿#region Using declarations
using System;
using System.Globalization;
using System.Windows.Media;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // V1.6.28 - EARLY TREND CAPTURE / PERSISTENT DIRECTION BIAS
        // Keeps a clean aligned directional read alive briefly through
        // Range/Transition noise. It is not a standalone entry trigger.
        private string persistentDirectionBias = "NONE";
        private DateTime persistentDirectionBiasUntilNy = DateTime.MinValue;
        private DateTime persistentDirectionBiasLastConfirmedNy = DateTime.MinValue;
        private const int PersistentDirectionBiasSeconds = 75;

        // V1.6.29 - short memory of a VALID aligned 3/5 impulse.
        // Allows the next 2/5 continuation to stay actionable briefly
        // instead of forgetting the impulse on the next Range callback.
        private const int PersistentMomentumContinuationSeconds = 30;

        // =====================================================
        // V1.6.58 - EXCEPTIONAL COMMITMENT DIRECT-ENTRY GRACE
        // =====================================================
        // A fully-qualified exceptional microstructure trigger is allowed to
        // survive a few noisy callbacks instead of being forgotten instantly.
        // This is NOT a standalone signal and does NOT bypass risk, session,
        // anti-chase, flow-conflict or confirmed opposite-absorption guards.
        // The window is intentionally short and is cancelled immediately by
        // a confirmed opposite absorption or a real opposite breakout.
        private const int ExceptionalCommitmentSeconds = 20;

        // =====================================================
        // V1.6.69 - EXCEPTIONAL AUTHORITY HARDENING
        // =====================================================
        // Exceptional authority must be genuinely exceptional.  It may not
        // arm from a weak 2/5-3/5 impulse or from a tiny Level II sample that
        // makes efficiency ratios look artificially huge.
        private const int ExceptionalMinR20Score = 4;
        private const double ExceptionalMinVolumeRatio = 1.50;
        private const double ExceptionalMinDesiredAggression = 80.0;
        private const long ExceptionalMinTapeTrades = 120;
        private const int ExceptionalAuthorityLogThrottleMs = 500;
        private DateTime lastExceptionalAuthorityLogUtc = DateTime.MinValue;
        private string lastExceptionalAuthorityLogState = string.Empty;

        // V1.6.75 - telemetry debounce only; trading logic is unchanged.
        private string lastDegradedMomentumBlockedLogKey = string.Empty;
        private DateTime lastDegradedMomentumBlockedLogUtc = DateTime.MinValue;
        private const int DegradedMomentumBlockedLogThrottleMs = 2000;

        // =====================================================
        // V1.6.64 - EXPLOSION ENGINE SNAPSHOT
        // =====================================================
        // Current Range-20 aggression displacement is exposed to the
        // execution scorer. M5/VWAP/Structure do not participate in
        // Explosion authority; these values measure only current impulse.
        private double latestExplosionLongDisplacementTicks = 0.0;
        private double latestExplosionShortDisplacementTicks = 0.0;
        private int latestExplosionLongAggressionScore = 0;
        private int latestExplosionShortAggressionScore = 0;

        private double hybridScalpRefClosePrice = 0.0; // V1.7.51
        private const int HybridScalpMinPersistence = 2; // V1.7.56 (was 4: vetoed fast moves)
        private string hybridFlowHeldSide = string.Empty; // V1.7.55
        private DateTime hybridFlowHeldUtc = DateTime.MinValue; // V1.7.55
        private string exceptionalCommitmentSide = "NONE";
        private DateTime exceptionalCommitmentUntilUtc = DateTime.MinValue;
        private DateTime exceptionalCommitmentArmedUtc = DateTime.MinValue;
        private string lastExceptionalCommitmentLogKey = string.Empty;

        // =====================================================
        // JJ HYBRID IMPULSE LIVE FLOW V2
        // Real order-flow PARTICIPATION check; not a standalone setup.
        // Use tape delta + executed aggression + tape/confluence/persistence.
        // Snapshot atomically to avoid mixed-time Level 2 decisions.
        // =====================================================
        private bool TryGetHybridImpulseLiveFlow(bool isLong, out string summary)
        {
            summary = "L2 UNAVAILABLE";
            lock (level2Sync)
            {
                double age = level2LastCalcUtc == DateTime.MinValue
                    ? 999.0
                    : (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds;

                // V1.7.55 - the tape counters (TapeTrades / AggBuy / AggSell) are zeroed after
                // every Level 2 context print, so for a few seconds the window is "empty" and the
                // old check returned L2 NOT READY exactly at the start of a move (2026-10-01 20:11:35:
                // R20 4/1, Vol x2.0, TapeTrades 6). If the book is healthy and the SAME side was
                // fully accepted <= 6 s ago, keep that verdict unless a CONFIRMED opposing
                // absorption is present. Never creates a first qualification by itself.
                if (level2ObserveActive && level2BookReady &&
                    age >= 0.0 && age <= 2.0 &&
                    level2SpreadTicks > 0.0 && level2SpreadTicks <= 4.0 &&
                    level2TapeTrades < 12 &&
                    string.Equals(hybridFlowHeldSide, isLong ? "LONG" : "SHORT", StringComparison.OrdinalIgnoreCase) &&
                    (DateTime.UtcNow - hybridFlowHeldUtc).TotalSeconds <= 6.0 &&
                    !string.Equals(level2Absorption, isLong ? "SELL ABSORPTION CONFIRMED" : "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase))
                {
                    summary = "HybridFlow HELD " + (isLong ? "LONG" : "SHORT")
                        + " | Window reset (TapeTrades " + level2TapeTrades + ") | Held "
                        + (DateTime.UtcNow - hybridFlowHeldUtc).TotalSeconds.ToString("0.0") + "s";
                    return true;
                }

                if (!level2ObserveActive || !level2BookReady ||
                    age < 0.0 || age > 2.0 ||
                    level2SpreadTicks <= 0.0 || level2SpreadTicks > 4.0 ||
                    level2TapeTrades < 12)
                {
                    summary = "L2 NOT READY | Age " + age.ToString("0.0")
                        + "s | Spread " + level2SpreadTicks.ToString("0.0")
                        + "t | TapeTrades " + level2TapeTrades;
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                double alignedDelta = isLong ? level2TapeDelta : -level2TapeDelta;
                double alignedAgg = isLong ? level2AggBuy : level2AggSell;
                double contraryAgg = isLong ? level2AggSell : level2AggBuy;
                int alignedPersistence = isLong ? level2LongPersistence : level2ShortPersistence;
                int contraryPersistence = isLong ? level2ShortPersistence : level2LongPersistence;

                bool tapeAligned = string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);
                bool tapeOpposed = string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);
                bool confluenceAligned =
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase);
                // V1.7.52 - ASIA SCALP: only a CONFIRMED opposing absorption cancels the
                // flow. "CANDIDATE" fires on almost every burst (13 of 16 on 2026-10-01) and
                // blocked a 5/5 flow + Explosion 97/100 setup. NY/CORE20 keep the old rule.
                bool strictAsiaFlow = IsHybridAsiaExecutionEnabled() &&
                    IsAsiaSession(GetCurrentNewYorkTime());
                bool opposingAbsorptionConfirmed = isLong
                    ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                    : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);
                bool opposingAbsorptionCandidate = isLong
                    ? string.Equals(level2Absorption, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase)
                    : string.Equals(level2Absorption, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase);
                bool opposingAbsorption =
                    opposingAbsorptionConfirmed ||
                    (!strictAsiaFlow && opposingAbsorptionCandidate);

                bool deltaSupport = alignedDelta >= 12.0;
                bool aggressionSupport = alignedAgg >= 20.0 &&
                    alignedAgg >= Math.Max(1.0, contraryAgg) * 1.18;
                int evidence = (deltaSupport ? 1 : 0) +
                    (aggressionSupport ? 1 : 0) +
                    (tapeAligned ? 1 : 0) +
                    (confluenceAligned ? 1 : 0) +
                    (alignedPersistence >= 2 ? 1 : 0);

                // Distinguish a genuine impulse from an opposing absorption or
                // apparently positive tape that is overwhelmed by opposing flow.
                bool contraryDominates =
                    (tapeOpposed && alignedDelta <= -12.0) ||
                    (contraryPersistence >= 5 && alignedDelta < 0.0) ||
                    (contraryAgg >= Math.Max(1.0, alignedAgg) * 1.65 && alignedDelta < 0.0);
                // JJ HYBRID ASIA IMPULSE QUALITY V3: Asia is NOT an order-frequency mode.
                // Require stronger executed-flow consensus for each independent setup.
                // CORE20 and NY retain their previous flow thresholds.
                bool accepted = !opposingAbsorption && !contraryDominates &&
                    evidence >= (strictAsiaFlow ? 4 : 3) &&
                    (deltaSupport || aggressionSupport) &&
                    (!strictAsiaFlow || (alignedDelta > 0.0 && alignedAgg > contraryAgg)) &&
                    // V1.7.54 - ASIA SCALP: sustained participation. Tick backtest (11 nights):
                    // the only combo above zero needed same-side delta persisting ~30 s + volume.
                    (!strictAsiaFlow || alignedPersistence >= HybridScalpMinPersistence);

                summary = "HybridFlow " + desired + " " + evidence + "/5"
                    + " | Delta " + level2TapeDelta.ToString("0")
                    + " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0")
                    + " | Tape " + level2TapeBias
                    + " | Confluence " + level2Confluence
                    + " | Persist " + alignedPersistence + "/" + contraryPersistence
                    + " | Abs " + level2Absorption
                    + " | Age " + age.ToString("0.0") + "s";
                if (accepted)
                {
                    hybridFlowHeldSide = desired;
                    hybridFlowHeldUtc = DateTime.UtcNow;
                }
                else if (string.Equals(hybridFlowHeldSide, desired, StringComparison.OrdinalIgnoreCase) &&
                         (opposingAbsorptionConfirmed || contraryDominates))
                {
                    hybridFlowHeldSide = string.Empty;
                }

                return accepted;
            }
        }

        private bool HasConfirmedOpposingAbsorption(bool isLong)
        {
            lock (level2Sync)
            {
                return isLong
                    ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                    : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);
            }
        }

        private bool HasExceptionalMinimumLevel2Sample(bool isLong, out string summary)
        {
            summary = "EXCEPTIONAL L2 SAMPLE NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0 ||
                    level2SpreadTicks <= 0.0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary = "EXCEPTIONAL L2 STALE/INVALID";
                    return false;
                }

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;

                bool enoughSample =
                    desiredAgg >= ExceptionalMinDesiredAggression &&
                    level2TapeTrades >= ExceptionalMinTapeTrades;

                summary =
                    "Agg " + desiredAgg.ToString("0") + "/" + oppositeAgg.ToString("0")
                    + " | TapeTrades " + level2TapeTrades
                    + " | MinAgg " + ExceptionalMinDesiredAggression.ToString("0")
                    + " | MinTape " + ExceptionalMinTapeTrades;

                return enoughSample;
            }
        }

        private bool ShouldHardInvalidateExceptionalCommitment(
            bool isLong,
            out string reason)
        {
            reason = string.Empty;

            int sameScore = isLong ? latestRangeLongScore : latestRangeShortScore;
            int oppositeScore = isLong ? latestRangeShortScore : latestRangeLongScore;

            // A thesis that has degraded all the way to 2/5 is no longer
            // "exceptional"; do not let the 20-second TTL keep it alive.
            if (sameScore <= 2)
            {
                reason = "R20 DEGRADED TO " + sameScore + "/5";
                return true;
            }

            lock (level2Sync)
            {
                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                int oppositePersistence =
                    isLong ? level2ShortPersistence : level2LongPersistence;
                double signedOppositeDelta =
                    isLong ? -level2TapeDelta : level2TapeDelta;
                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;

                bool tapeOpposite =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool confluenceOpposite =
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase);

                bool aggressionOpposite =
                    oppositeAgg >= ExceptionalMinDesiredAggression &&
                    oppositeAgg >= Math.Max(1.0, desiredAgg) * 1.35;

                bool strongOppositeFlow =
                    tapeOpposite &&
                    oppositePersistence >= 5 &&
                    signedOppositeDelta >= 40.0 &&
                    aggressionOpposite &&
                    confluenceOpposite;

                if (strongOppositeFlow)
                {
                    reason =
                        "STRONG OPPOSITE FLOW"
                        + " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0")
                        + " | Persist L/S " + level2LongPersistence + "/" + level2ShortPersistence
                        + " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0");
                    return true;
                }
            }

            return false;
        }

        private bool ShouldLogExceptionalAuthority(string stateKey)
        {
            DateTime nowUtc = DateTime.UtcNow;
            bool stateChanged =
                !string.Equals(
                    stateKey,
                    lastExceptionalAuthorityLogState,
                    StringComparison.Ordinal
                );

            bool throttleElapsed =
                lastExceptionalAuthorityLogUtc == DateTime.MinValue ||
                (nowUtc - lastExceptionalAuthorityLogUtc).TotalMilliseconds >=
                    ExceptionalAuthorityLogThrottleMs;

            if (!stateChanged && !throttleElapsed)
                return false;

            lastExceptionalAuthorityLogState = stateKey;
            lastExceptionalAuthorityLogUtc = nowUtc;
            return true;
        }

        private void ClearExceptionalCommitment(DateTime nyTime, string reason)
        {
            if (string.Equals(exceptionalCommitmentSide, "NONE", StringComparison.OrdinalIgnoreCase))
                return;

            string priorSide = exceptionalCommitmentSide;
            exceptionalCommitmentSide = "NONE";
            exceptionalCommitmentUntilUtc = DateTime.MinValue;
            exceptionalCommitmentArmedUtc = DateTime.MinValue;

            string key = "CLEAR|" + priorSide + "|" + reason;
            if (key != lastExceptionalCommitmentLogKey)
            {
                lastExceptionalCommitmentLogKey = key;
                PrintBotMessage(
                    "EXCEPTIONAL COMMITMENT CLEARED"
                    + " | Side: " + priorSide
                    + " | Reason: " + reason
                    + " | Action: RETURN TO NORMAL DECISION FLOW"
                );
            }
        }

        private void ArmExceptionalCommitment(bool isLong, DateTime nyTime)
        {
            string side = isLong ? "LONG" : "SHORT";
            DateTime nowUtc = DateTime.UtcNow;
            bool alreadyActive =
                string.Equals(exceptionalCommitmentSide, side, StringComparison.OrdinalIgnoreCase) &&
                exceptionalCommitmentUntilUtc != DateTime.MinValue &&
                nowUtc <= exceptionalCommitmentUntilUtc;

            exceptionalCommitmentSide = side;
            exceptionalCommitmentArmedUtc = nowUtc;
            exceptionalCommitmentUntilUtc = nowUtc.AddSeconds(ExceptionalCommitmentSeconds);

            // Refresh the TTL silently while the LIVE exceptional condition
            // remains qualified. Log only the transition into commitment.
            if (alreadyActive)
                return;

            string key = "ARM|" + side + "|" + nyTime.ToString("yyyyMMddHHmmss");
            if (key != lastExceptionalCommitmentLogKey)
            {
                lastExceptionalCommitmentLogKey = key;
                PrintBotMessage(
                    "EXCEPTIONAL COMMITMENT ARMED"
                    + " | Side: " + side
                    + " | Hold: " + ExceptionalCommitmentSeconds + "s"
                    + " | Action: IGNORE SINGLE-SNAPSHOT NOISE / HARD INVALIDATION STILL ACTIVE"
                );
            }
        }

        private bool IsExceptionalCommitmentActive(bool isLong, DateTime nyTime, out string summary)
        {
            string side = isLong ? "LONG" : "SHORT";
            summary = "NO EXCEPTIONAL COMMITMENT";

            if (!string.Equals(exceptionalCommitmentSide, side, StringComparison.OrdinalIgnoreCase))
                return false;

            DateTime nowUtc = DateTime.UtcNow;
            if (exceptionalCommitmentUntilUtc == DateTime.MinValue || nowUtc > exceptionalCommitmentUntilUtc)
            {
                ClearExceptionalCommitment(nyTime, "TTL EXPIRED");
                return false;
            }

            if (HasConfirmedOpposingAbsorption(isLong))
            {
                ClearExceptionalCommitment(nyTime, "CONFIRMED OPPOSING ABSORPTION");
                return false;
            }

            string hardInvalidationReason;
            if (ShouldHardInvalidateExceptionalCommitment(isLong, out hardInvalidationReason))
            {
                ClearExceptionalCommitment(
                    nyTime,
                    "EARLY FAILURE | " + hardInvalidationReason
                );
                return false;
            }

            double remaining = Math.Max(0.0, (exceptionalCommitmentUntilUtc - nowUtc).TotalSeconds);
            summary =
                "HELD " + side
                + " | Remaining " + remaining.ToString("0.0") + "s"
                + " | ArmedUtc "
                + (exceptionalCommitmentArmedUtc == DateTime.MinValue
                    ? "N/A"
                    : exceptionalCommitmentArmedUtc.ToString("HH:mm:ss"));
            return true;
        }

        // =====================================================
        // V1.6.32 - MOVE PHASE / ENTRY TIMING ENGINE
        // =====================================================
        // Context/direction is NOT the same as permission to enter.
        // Direct Momentum entries are allowed only while the current move
        // is in IGNITION or healthy EXPANSION. Mature/exhausted moves are
        // converted to Smart Retest; developing moves simply keep waiting.
        private string lastMovePhaseLogKey = string.Empty;
        private DateTime lastMovePhaseLogUtc = DateTime.MinValue;
        private const int MovePhaseLogThrottleMs = 5000;

        private string EvaluateMovePhase(
            bool isLong,
            int sideScore,
            int oppositeScore,
            bool breakout,
            bool aggressiveExpansion,
            double aggressiveDisplacementTicks,
            double emaExtensionTicks,
            double sessionMoveTicks,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks)
        {
            double directionalSlopeTicks =
                isLong
                    ? slopeTicks
                    : -slopeTicks;

            // V1.6.49 - AGGRESSION BURST CAPTURE / GLOBAL FRESHNESS
            // The bot is designed to capture the beginning of an aggressive
            // displacement, not the final acceleration of a move that has
            // already travelled a large distance.  SessionMove is measured
            // from the current NY-session extreme, so it protects both LONG
            // and SHORT entries from chasing a mature directional leg.
            bool exhaustion =
                emaExtensionTicks >= 36.0 &&
                (
                    oppositeScore >= 2 ||
                    directionalSlopeTicks <= 1.0 ||
                    bodyRatio < 0.45
                );

            if (exhaustion)
                return "EXHAUSTION";

            bool mature =
                emaExtensionTicks > 40.0 ||
                aggressiveDisplacementTicks >= 80.0 ||
                sessionMoveTicks >= 320.0 ||
                (
                    sessionMoveTicks >= 220.0 &&
                    emaExtensionTicks >= 24.0
                );

            if (mature)
                return "MATURE";

            bool ignition =
                breakout &&
                sideScore >= 4 &&
                oppositeScore <= 1 &&
                directionalSlopeTicks >= 3.0 &&
                bodyRatio >= 0.70 &&
                volumeRatio >= 1.15 &&
                emaExtensionTicks <= 28.0 &&
                sessionMoveTicks < 220.0 &&
                (
                    aggressiveExpansion ||
                    aggressiveDisplacementTicks >=
                        AggressionMinDisplacementTicks
                );

            if (ignition)
                return "IGNITION";

            bool expansion =
                sideScore >= 3 &&
                oppositeScore <= 1 &&
                directionalSlopeTicks > 0 &&
                bodyRatio >= 0.55 &&
                volumeRatio >= 0.90 &&
                emaExtensionTicks <= 36.0 &&
                sessionMoveTicks < 260.0;

            if (expansion)
                return "EXPANSION";

            return "DEVELOPING";
        }

        private void LogMovePhase(
            bool isLong,
            DateTime nyTime,
            string phase,
            int sideScore,
            int oppositeScore,
            double emaExtensionTicks,
            double sessionMoveTicks,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            string action)
        {
            string key =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + phase
                + "|"
                + action
                + "|"
                + sideScore.ToString()
                + "/"
                + oppositeScore.ToString();

            DateTime movePhaseNowUtc = DateTime.UtcNow;

            if (
                key == lastMovePhaseLogKey &&
                lastMovePhaseLogUtc != DateTime.MinValue &&
                (movePhaseNowUtc - lastMovePhaseLogUtc).TotalMilliseconds < MovePhaseLogThrottleMs
            )
            {
                return;
            }

            // JJ_MOVE_PHASE_GLOBAL_THROTTLE_REMOVED
            // A meaningful key change (Side + Phase + Action + R20) logs immediately.
            // Only an identical telemetry state is cooled down; trading evaluation
            // itself continues on every callback exactly as before.

            lastMovePhaseLogKey = key;
            lastMovePhaseLogUtc = movePhaseNowUtc;

            PrintBotMessage(
                "MOVE PHASE"
                + " | Side: " + (isLong ? "LONG" : "SHORT")
                + " | Phase: " + phase
                + " | R20: " + sideScore + "/" + oppositeScore
                + " | EMA9Ext: " + emaExtensionTicks.ToString("0") + "t"
                + " | SessionMove: " + sessionMoveTicks.ToString("0") + "t"
                + " | Vol x" + volumeRatio.ToString("0.00")
                + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                + " | Slope: " + slopeTicks.ToString("0.0") + "t"
                + " | Action: " + action
            );
        }

        private void UpdateMomentumFromRangeBars(
            Bars bars,
            bool evaluateClosedRangeBar)
        {
            if (
                bars == null ||
                bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            long scoreStarted = System.Diagnostics.Stopwatch.GetTimestamp();
            var scoreKey = new JJRangeMomentumKey(bars, bars.Count, closedBarIndex,
                bars.GetTime(0), bars.GetTime(closedBarIndex),
                bars.GetOpen(closedBarIndex), bars.GetHigh(closedBarIndex),
                bars.GetLow(closedBarIndex), bars.GetClose(closedBarIndex),
                bars.GetVolume(closedBarIndex));
            JJRangeMomentumValues scoreValues;
            bool reusedScore = rangeMomentumCache.TryGet(scoreKey, evaluateClosedRangeBar, out scoreValues);
            if (!reusedScore)
            {
                scoreValues.Ema = CalculateEma(bars, FastEmaPeriod, closedBarIndex);
                CalculateMomentumScores(bars, closedBarIndex, scoreValues.Ema,
                    out scoreValues.LongScore, out scoreValues.ShortScore,
                    out scoreValues.RangeRatio, out scoreValues.VolumeRatio,
                    out scoreValues.BodyRatio, out scoreValues.EmaSlope,
                    out scoreValues.HighBreakout, out scoreValues.LowBreakout);
                rangeMomentumCache.Store(scoreKey, scoreValues);
            }
            rangeFeedDiagnostic.RecordScoreWork(reusedScore,
                (System.Diagnostics.Stopwatch.GetTimestamp() - scoreStarted) * 1000.0
                / System.Diagnostics.Stopwatch.Frequency);
            double emaFastCurrent = scoreValues.Ema;
            int longScore = scoreValues.LongScore;
            int shortScore = scoreValues.ShortScore;
            double rangeRatio = scoreValues.RangeRatio;
            double volumeRatio = scoreValues.VolumeRatio;
            double bodyRatio = scoreValues.BodyRatio;
            double emaSlope = scoreValues.EmaSlope;
            bool highBreakout = scoreValues.HighBreakout;
            bool lowBreakout = scoreValues.LowBreakout;

            bool bullishMomentum =
                longScore >= MomentumMinScore;

            bool bearishMomentum =
                shortScore >= MomentumMinScore;

            string momentumState =
                bullishMomentum &&
                !bearishMomentum
                    ? "BULLISH "
                        + longScore
                        + "/5"
                    : bearishMomentum &&
                        !bullishMomentum
                        ? "BEARISH "
                            + shortScore
                            + "/5"
                        : "L "
                            + longScore
                            + "/5 | S "
                            + shortScore
                            + "/5";

            // V1.7.87 - hidden window: refresh its text at most every 5 s (UI thread load)
            bool v187PostMomentumUi = V187ShouldPostUi(2);

            lock (marketContextLock)
            {
                latestRangeLongScore =
                    longScore;
                latestRangeShortScore =
                    shortScore;
                latestRangeRatio =
                    rangeRatio;
                latestRangeVolumeRatio =
                    volumeRatio;
                latestRangeBodyRatio =
                    bodyRatio;
                latestRangeEmaSlope =
                    emaSlope;
                latestRangeHighBreakout =
                    highBreakout;
                latestRangeLowBreakout =
                    lowBreakout;
                latestRangeMomentumState =
                    momentumState;
            }

            // Diagnostic only: record after the shared momentum snapshot is updated.
            rangeFeedDiagnostic.RecordCalculation(DateTime.UtcNow, bars.Count,
                bars.GetTime(lastIndex), bars.GetTime(closedBarIndex), longScore, shortScore);

            if (v187PostMomentumUi)
            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (
                        !botRunning ||
                        momentumText == null
                    )
                    {
                        return;
                    }

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        bullishMomentum
                            ? Brushes.LimeGreen
                            : bearishMomentum
                                ? Brushes.OrangeRed
                                : Brushes.Goldenrod;
                })
            );

            if (!evaluateClosedRangeBar)
                return;

            DateTime closedRangeTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime rangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            EnsureTradingDay(
                rangeNyTime
            );

            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool m5AboveVwap;
            bool m5BelowVwap;
            string m5Structure;
            string m5Liquidity;
            int htfLongScore;
            int htfShortScore;
            double m5BullishBreakLevel;
            double m5BearishBreakLevel;

            lock (marketContextLock)
            {
                m5Ready =
                    latestM5ContextReady;
                m5Bullish =
                    latestM5BullishTrend;
                m5Bearish =
                    latestM5BearishTrend;
                m5AboveVwap =
                    latestM5AboveVwap;
                m5BelowVwap =
                    latestM5BelowVwap;
                m5Structure =
                    latestM5StructureState;

                m5Liquidity =
                    latestM5LiquidityState;

                htfLongScore =
                    latestHtfLongScore;

                htfShortScore =
                    latestHtfShortScore;
                m5BullishBreakLevel =
                    latestM5BullishStructureBreakLevel;
                m5BearishBreakLevel =
                    latestM5BearishStructureBreakLevel;
            }

            if (!m5Ready)
                return;

            bool nySessionActive =
                IsBotNySessionActive(
                    rangeNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    rangeNyTime
                );

            bool allowMomentumMode =
                activeStrategyMode == "MOMENTUM SCALP" ||
                IsHybridFamilyMode();

            bool openingPriority =
                IsOpeningPriorityActive(
                    rangeNyTime
                );

            bool openingBuildLock =
                IsOpeningBuildWindow(
                    rangeNyTime
                );

            // V1.6.2:
            // 09:30-09:35: Momentum is blocked while the opening range forms.
            // 09:35-10:00: Momentum is fallback only. If price is currently
            // presenting a valid Opening breakout, Opening gets first priority.
            double rangeClose =
                bars.GetClose(
                    closedBarIndex
                );

            // V1.7.51 - reference close for the Asia scalp no-chase guard.
            lock (marketContextLock)
            {
                hybridScalpRefClosePrice = rangeClose;
            }

            double openingBuffer =
                selectedInstrument != null
                    ? selectedInstrument
                        .MasterInstrument
                        .TickSize
                        * OpeningBreakoutBufferTicks
                    : 0;

            bool openingLongCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bullish &&
                m5AboveVwap &&
                rangeClose >=
                    openingRangeHigh +
                    openingBuffer;

            bool openingShortCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bearish &&
                m5BelowVwap &&
                rangeClose <=
                    openingRangeLow -
                    openingBuffer;

            // =====================================================
            // V1.6.5 - EARLY EXTREME MOMENTUM DETECTION
            // =====================================================
            double momentumTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double slopeTicks =
                momentumTickSize > 0
                    ? emaSlope /
                        momentumTickSize
                    : 0;

            // V1.6.18 - advance previously-recorded shadow candidates using
            // only completed Range bars. This has no execution side effects.
            double completedRangeHigh = bars.GetHigh(closedBarIndex);
            double completedRangeLow = bars.GetLow(closedBarIndex);

            UpdateShadowSignalOutcomes(
                rangeNyTime,
                rangeClose,
                completedRangeHigh,
                completedRangeLow,
                momentumTickSize
            );

            // V1.6.23 Phase 7 - continue adjudicating the ORIGINAL signal
            // after a forced financial/session exit. This never submits orders.
            UpdateDeferredLearningSignalOutcomes(
                rangeNyTime,
                completedRangeHigh,
                completedRangeLow
            );

            bool extremeLongMomentum =
                longScore >=
                    ExtremeMomentumMinScore &&
                highBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    ExtremeMomentumMinSlopeTicks &&
                m5AboveVwap;

            bool extremeShortMomentum =
                shortScore >=
                    ExtremeMomentumMinScore &&
                lowBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -ExtremeMomentumMinSlopeTicks &&
                m5BelowVwap;

            // Premarket has no RTH VWAP yet, so its fast path uses the
            // completed premarket frontier + M5 direction instead.
            bool premarketRangeValid =
                premarketSession &&
                premarketRangeReady &&
                premarketRangeDateNy ==
                    rangeNyTime.Date;

            bool premarketHighBreakout =
                premarketRangeValid &&
                rangeClose >
                    premarketRangeHigh;

            bool premarketLowBreakout =
                premarketRangeValid &&
                rangeClose <
                    premarketRangeLow;

            bool premarketExtremeLong =
                premarketHighBreakout &&
                longScore >=
                    PremarketExtremeMinScore &&
                highBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    PremarketExtremeMinSlopeTicks &&
                (
                    m5Bullish || (!m5Bearish && htfLongScore >= 2)
                );

            bool premarketExtremeShort =
                premarketLowBreakout &&
                shortScore >=
                    PremarketExtremeMinScore &&
                lowBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -PremarketExtremeMinSlopeTicks &&
                (
                    m5Bearish || (!m5Bullish && htfShortScore >= 2)
                );

            bool premarketLongBias =
                premarketHighBreakout &&
                (
                    (
                        m5Bullish &&
                        longScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeLong
                );

            bool premarketShortBias =
                premarketLowBreakout &&
                (
                    (
                        m5Bearish &&
                        shortScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeShort
                );

            // =====================================================
            // V1.6.50 - PREMARKET EARLY AGGRESSION TRIGGER
            // =====================================================
            // Premarket is intentionally momentum-only.  A fresh 03:00 break
            // must not wait for BOS/CHOCH, VWAP or a perfect 4/5 Range score.
            // A 3/5 impulse (or an exceptional 2/5 price impulse) may become
            // actionable only when fresh Level II executed aggression confirms
            // the same direction and there is no opposing absorption.
            string premarketEarlyLongFlowSummary = string.Empty;
            string premarketEarlyShortFlowSummary = string.Empty;

            bool premarketEarlyLongPriceImpulse =
                premarketRangeValid &&
                premarketHighBreakout &&
                highBreakout &&
                !m5Bearish &&
                (
                    longScore >= 3 ||
                    (
                        longScore >= 2 &&
                        bodyRatio >= 0.70 &&
                        volumeRatio >= 1.10 &&
                        slopeTicks >= 2.0
                    )
                );

            bool premarketEarlyShortPriceImpulse =
                premarketRangeValid &&
                premarketLowBreakout &&
                lowBreakout &&
                !m5Bullish &&
                (
                    shortScore >= 3 ||
                    (
                        shortScore >= 2 &&
                        bodyRatio >= 0.70 &&
                        volumeRatio >= 1.10 &&
                        slopeTicks <= -2.0
                    )
                );

            bool premarketEarlyLongAggression =
                premarketSession &&
                premarketEarlyLongPriceImpulse &&
                TryGetEarlyAggressionFlowSupport(
                    true,
                    out premarketEarlyLongFlowSummary
                );

            bool premarketEarlyShortAggression =
                premarketSession &&
                premarketEarlyShortPriceImpulse &&
                TryGetEarlyAggressionFlowSupport(
                    false,
                    out premarketEarlyShortFlowSummary
                );

            if (premarketEarlyLongAggression || premarketEarlyShortAggression)
            {
                bool earlyLong = premarketEarlyLongAggression;

                PrintBotMessage(
                    "PREMARKET EARLY AGGRESSION TRIGGER"
                    + " | Side: "
                    + (earlyLong ? "LONG" : "SHORT")
                    + " | R20: "
                    + (earlyLong ? longScore : shortScore)
                    + "/5"
                    + " | Body "
                    + (bodyRatio * 100.0).ToString("0")
                    + "%"
                    + " | Vol x"
                    + volumeRatio.ToString("0.00")
                    + " | Slope "
                    + slopeTicks.ToString("0.0")
                    + "t"
                    + " | "
                    + (
                        earlyLong
                            ? premarketEarlyLongFlowSummary
                            : premarketEarlyShortFlowSummary
                      )
                    + " | Action: FRESH ENTRY ELIGIBLE"
                );
            }

            // =====================================================
            // V1.6.9 - FRESH AGGRESSIVE EXPANSION DETECTION
            // =====================================================
            int aggressiveLongScore;
            int aggressiveShortScore;
            int aggressiveLongDirectionalBars;
            int aggressiveShortDirectionalBars;
            double aggressiveLongDisplacementTicks;
            double aggressiveShortDisplacementTicks;

            CalculateAggressionState(
                bars,
                closedBarIndex,
                momentumTickSize,
                rangeRatio,
                volumeRatio,
                bodyRatio,
                slopeTicks,
                highBreakout,
                lowBreakout,
                out aggressiveLongScore,
                out aggressiveShortScore,
                out aggressiveLongDirectionalBars,
                out aggressiveShortDirectionalBars,
                out aggressiveLongDisplacementTicks,
                out aggressiveShortDisplacementTicks
            );

            // V1.6.64 - publish fresh impulse displacement for Explosion Engine.
            lock (marketContextLock)
            {
                latestExplosionLongDisplacementTicks =
                    aggressiveLongDisplacementTicks;
                latestExplosionShortDisplacementTicks =
                    aggressiveShortDisplacementTicks;
                latestExplosionLongAggressionScore =
                    aggressiveLongScore;
                latestExplosionShortAggressionScore =
                    aggressiveShortScore;
            }

            bool aggressiveLongExpansion =
                aggressiveLongScore >= AggressionMinScore &&
                highBreakout &&
                aggressiveLongDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveLongDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketHighBreakout &&
                            (
                                m5Bullish || (!m5Bearish && htfLongScore >= 2)
                            )
                          )
                        : m5AboveVwap
                );

            bool aggressiveShortExpansion =
                aggressiveShortScore >= AggressionMinScore &&
                lowBreakout &&
                aggressiveShortDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveShortDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketLowBreakout &&
                            (
                                m5Bearish || (!m5Bullish && htfShortScore >= 2)
                            )
                          )
                        : m5BelowVwap
                );

            // =====================================================
            // V1.6.56 - UNIVERSAL EXCEPTIONAL MICROSTRUCTURE ENTRY
            // =====================================================
            // Across every ACTIVE automatic session, M5 / Structure / VWAP are
            // context rather than hard vetoes when price expansion is already
            // real AND fresh executed Level II flow confirms the same side.
            // This path is intentionally narrow: real breakout, >=3/5 R20,
            // strong body/participation/slope, low opposite score, fresh tape
            // aggression, persistence and NO opposing absorption.
            string exceptionalLongFlowSummary = string.Empty;
            string exceptionalShortFlowSummary = string.Empty;

            bool exceptionalLongPriceImpulse =
                nySessionActive &&
                highBreakout &&
                longScore >= ExceptionalMinR20Score &&
                shortScore <= 2 &&
                bodyRatio >= 0.70 &&
                volumeRatio >= ExceptionalMinVolumeRatio &&
                slopeTicks >= 3.0;

            bool exceptionalShortPriceImpulse =
                nySessionActive &&
                lowBreakout &&
                shortScore >= ExceptionalMinR20Score &&
                longScore <= 2 &&
                bodyRatio >= 0.70 &&
                volumeRatio >= ExceptionalMinVolumeRatio &&
                slopeTicks <= -3.0;

            string exceptionalLongSampleSummary = string.Empty;
            string exceptionalShortSampleSummary = string.Empty;

            bool exceptionalLongSampleReady =
                exceptionalLongPriceImpulse &&
                HasExceptionalMinimumLevel2Sample(
                    true,
                    out exceptionalLongSampleSummary
                );

            bool exceptionalShortSampleReady =
                exceptionalShortPriceImpulse &&
                HasExceptionalMinimumLevel2Sample(
                    false,
                    out exceptionalShortSampleSummary
                );

            bool liveExceptionalMicrostructureLong =
                exceptionalLongSampleReady &&
                TryGetEarlyAggressionFlowSupport(
                    true,
                    out exceptionalLongFlowSummary
                );

            bool liveExceptionalMicrostructureShort =
                exceptionalShortSampleReady &&
                TryGetEarlyAggressionFlowSupport(
                    false,
                    out exceptionalShortFlowSummary
                );

            // Never grant simultaneous live authority. A conflicted tape
            // remains a WAIT, not a coin flip.
            if (liveExceptionalMicrostructureLong && liveExceptionalMicrostructureShort)
            {
                liveExceptionalMicrostructureLong = false;
                liveExceptionalMicrostructureShort = false;
            }

            // V1.6.57 - Once a LIVE exceptional trigger is fully qualified,
            // keep that directional thesis alive for a very short commitment
            // window. A confirmed opposite absorption or actual opposite
            // breakout cancels it immediately. Ordinary L2 flicker does not.
            if (liveExceptionalMicrostructureLong)
            {
                if (string.Equals(exceptionalCommitmentSide, "SHORT", StringComparison.OrdinalIgnoreCase))
                    ClearExceptionalCommitment(rangeNyTime, "NEW LIVE LONG AUTHORITY");
                ArmExceptionalCommitment(true, rangeNyTime);
            }
            else if (liveExceptionalMicrostructureShort)
            {
                if (string.Equals(exceptionalCommitmentSide, "LONG", StringComparison.OrdinalIgnoreCase))
                    ClearExceptionalCommitment(rangeNyTime, "NEW LIVE SHORT AUTHORITY");
                ArmExceptionalCommitment(false, rangeNyTime);
            }

            bool heldExceptionalLong = false;
            bool heldExceptionalShort = false;
            string heldExceptionalSummary = string.Empty;

            if (!liveExceptionalMicrostructureLong && !liveExceptionalMicrostructureShort)
            {
                if (string.Equals(exceptionalCommitmentSide, "LONG", StringComparison.OrdinalIgnoreCase))
                {
                    if (longScore <= 2)
                        ClearExceptionalCommitment(rangeNyTime, "R20 DEGRADED TO " + longScore + "/5");
                    else if (lowBreakout)
                        ClearExceptionalCommitment(rangeNyTime, "OPPOSITE LOW BREAKOUT");
                    else if (shortScore >= 4 && longScore <= 1 && slopeTicks <= -3.0)
                        ClearExceptionalCommitment(rangeNyTime, "OPPOSITE PRICE IMPULSE");
                    else
                        heldExceptionalLong = IsExceptionalCommitmentActive(true, rangeNyTime, out heldExceptionalSummary);
                }
                else if (string.Equals(exceptionalCommitmentSide, "SHORT", StringComparison.OrdinalIgnoreCase))
                {
                    if (shortScore <= 2)
                        ClearExceptionalCommitment(rangeNyTime, "R20 DEGRADED TO " + shortScore + "/5");
                    else if (highBreakout)
                        ClearExceptionalCommitment(rangeNyTime, "OPPOSITE HIGH BREAKOUT");
                    else if (longScore >= 4 && shortScore <= 1 && slopeTicks >= 3.0)
                        ClearExceptionalCommitment(rangeNyTime, "OPPOSITE PRICE IMPULSE");
                    else
                        heldExceptionalShort = IsExceptionalCommitmentActive(false, rangeNyTime, out heldExceptionalSummary);
                }
            }

            bool exceptionalMicrostructureLong =
                liveExceptionalMicrostructureLong || heldExceptionalLong;
            bool exceptionalMicrostructureShort =
                liveExceptionalMicrostructureShort || heldExceptionalShort;

            if (heldExceptionalLong || heldExceptionalShort)
            {
                string holdKey =
                    "HOLD|"
                    + (heldExceptionalLong ? "LONG" : "SHORT")
                    + "|" + rangeNyTime.ToString("yyyyMMddHHmmss");

                if (holdKey != lastExceptionalCommitmentLogKey)
                {
                    lastExceptionalCommitmentLogKey = holdKey;
                    PrintBotMessage(
                        "EXCEPTIONAL COMMITMENT HOLD"
                        + " | Side: " + (heldExceptionalLong ? "LONG" : "SHORT")
                        + " | " + heldExceptionalSummary
                        + " | R20 L/S: " + longScore + "/" + shortScore
                        + " | Action: THESIS PRESERVED / FINAL FLOW-RISK GATES STILL APPLY"
                    );
                }
            }

            if (exceptionalMicrostructureLong || exceptionalMicrostructureShort)
            {
                bool exceptionalLong = exceptionalMicrostructureLong;
                bool liveExceptional =
                    exceptionalLong
                        ? liveExceptionalMicrostructureLong
                        : liveExceptionalMicrostructureShort;

                string flowSummary =
                    exceptionalLong
                        ? exceptionalLongFlowSummary
                        : exceptionalShortFlowSummary;

                if (string.IsNullOrWhiteSpace(flowSummary))
                    flowSummary =
                        liveExceptional
                            ? "LIVE FLOW QUALIFIED"
                            : "HELD COMMITMENT / LIVE FLOW NOT CURRENTLY QUALIFIED";

                string stateKey =
                    (exceptionalLong ? "LONG" : "SHORT")
                    + "|" + (exceptionalLong ? longScore : shortScore)
                    + "|" + (liveExceptional ? "LIVE" : "HELD");

                if (ShouldLogExceptionalAuthority(stateKey))
                {
                    PrintBotMessage(
                        "EXCEPTIONAL MICROSTRUCTURE AUTHORITY"
                        + " | Session: " + GetBotSessionWindow(rangeNyTime)
                        + " | Side: " + (exceptionalLong ? "LONG" : "SHORT")
                        + " | R20: " + (exceptionalLong ? longScore : shortScore) + "/5"
                        + " | Vol x" + volumeRatio.ToString("0.00")
                        + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                        + " | Slope " + slopeTicks.ToString("0.0") + "t"
                        + " | " + flowSummary
                        + " | Action: EXPLOSION CANDIDATE / M5-VWAP-STRUCTURE IGNORED FOR AUTHORITY"
                    );
                }
            }

            // =====================================================
            // V1.6.53 - REMEMBER ONLY A REAL FRESH 4/5 TRIGGER
            // =====================================================
            // This memory exists solely so a following 3/5 bar cannot be
            // mislabeled as stale if the original 4/5 breakout is still alive.
            // It requires actual price breakout + strong candle + current flow.
            string freshLongTriggerFlowSummary;
            bool freshLongTriggerFlow =
                TryGetFreshMomentumContinuationFlowSupport(
                    true,
                    out freshLongTriggerFlowSummary
                );

            string freshShortTriggerFlowSummary;
            bool freshShortTriggerFlow =
                TryGetFreshMomentumContinuationFlowSupport(
                    false,
                    out freshShortTriggerFlowSummary
                );

            if (
                longScore >= 4 &&
                highBreakout &&
                bodyRatio >= 0.65 &&
                volumeRatio >= 1.00 &&
                slopeTicks >= 3.5 &&
                freshLongTriggerFlow
            )
            {
                freshMomentumLongTriggerNy = rangeNyTime;
                freshMomentumLongTriggerPrice = rangeClose;
            }

            if (
                shortScore >= 4 &&
                lowBreakout &&
                bodyRatio >= 0.65 &&
                volumeRatio >= 1.00 &&
                slopeTicks <= -3.5 &&
                freshShortTriggerFlow
            )
            {
                freshMomentumShortTriggerNy = rangeNyTime;
                freshMomentumShortTriggerPrice = rangeClose;
            }

            // V1.6.20: Aggressive expansion may resolve AUTO early only
            // when aligned with pressure or while pressure is neutral.
            // An opposite impulse is interpreted as a pullback.
            if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                aggressiveLongExpansion !=
                    aggressiveShortExpansion
            )
            {
                bool aggressiveResolveLong =
                    aggressiveLongExpansion;

                int pressureLongScore;
                int pressureShortScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out pressureLongScore,
                        out pressureShortScore
                    );

                bool counterPressure =
                    (
                        aggressiveResolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !aggressiveResolveLong &&
                        pressure == "LONG"
                    );

                if (!counterPressure)
                {
                    autoResolvedDirection =
                        aggressiveResolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoDirectionReason =
                        (
                            aggressiveResolveLong
                                ? "FRESH AGGRESSIVE EXPANSION LONG"
                                : "FRESH AGGRESSIVE EXPANSION SHORT"
                        )
                        + (
                            pressure == "NEUTRAL"
                                ? " | NEUTRAL DISCOVERY"
                                : " | ALIGNED PRESSURE"
                          );
                }
            }

            // Do not let an already over-extended Opening candidate suppress
            // a fresh Range momentum signal.
            if (openingLongCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingLongCandidate =
                        false;
                }
            }

            if (openingShortCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingShortCandidate =
                        false;
                }
            }

            // =====================================================
            // V1.6.38 - LIQUIDITY BREAK EARLY TRIGGER (PREMARKET + AM)
            // =====================================================
            // If a structural liquidity level was previously blocked and is
            // now being crossed near the level with aligned aggressive flow,
            // promote that break to a valid Momentum candidate. This is the
            // missing bridge between STRUCTURE LOCATION and ANTI-CHASE.
            string liquidityBreakLongSummary = string.Empty;
            string liquidityBreakShortSummary = string.Empty;

            string liquidityBreakSession =
                GetBotSessionWindow(rangeNyTime);

            bool liquidityBreakSessionEligible =
                premarketSession ||
                string.Equals(
                    liquidityBreakSession,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                );

            bool liquidityBreakLongSignal =
                liquidityBreakSessionEligible &&
                (
                    premarketSession
                        ? !m5Bearish
                        : (m5AboveVwap && !m5Bearish)
                ) &&
                longScore >= 3 &&
                TryGetLiquidityBreakAcceptanceOverride(
                    true,
                    rangeNyTime,
                    rangeClose,
                    momentumTickSize,
                    aggressiveLongExpansion ||
                    extremeLongMomentum ||
                    (
                        highBreakout &&
                        bodyRatio >= 0.60 &&
                        volumeRatio >= 1.20
                    ),
                    out liquidityBreakLongSummary
                );

            bool liquidityBreakShortSignal =
                liquidityBreakSessionEligible &&
                (
                    premarketSession
                        ? !m5Bullish
                        : (m5BelowVwap && !m5Bullish)
                ) &&
                shortScore >= 3 &&
                TryGetLiquidityBreakAcceptanceOverride(
                    false,
                    rangeNyTime,
                    rangeClose,
                    momentumTickSize,
                    aggressiveShortExpansion ||
                    extremeShortMomentum ||
                    (
                        lowBreakout &&
                        bodyRatio >= 0.60 &&
                        volumeRatio >= 1.20
                    ),
                    out liquidityBreakShortSummary
                );

            if (liquidityBreakLongSignal || liquidityBreakShortSignal)
            {
                string side = liquidityBreakLongSignal ? "LONG" : "SHORT";
                string summary = liquidityBreakLongSignal
                    ? liquidityBreakLongSummary
                    : liquidityBreakShortSummary;

                string triggerKey =
                    rangeNyTime.ToString("yyyyMMddHHmmss")
                    + "|EARLY|" + side;

                if (triggerKey != lastLiquidityBreakWindowLogKey)
                {
                    lastLiquidityBreakWindowLogKey = triggerKey;
                    PrintBotMessage(
                        "LIQUIDITY BREAK + AGGRESSIVE FLOW TRIGGER"
                        + " | Side: " + side
                        + " | " + summary
                        + " | Action: EARLY ENTRY CANDIDATE"
                    );
                }
            }

            bool openingCandidatePresent =
                (openingLongCandidate || openingShortCandidate) &&
                !liquidityBreakLongSignal &&
                !liquidityBreakShortSignal &&
                !exceptionalMicrostructureLong &&
                !exceptionalMicrostructureShort;

            bool extremeOpeningOverride =
                openingBuildLock &&
                (
                    extremeLongMomentum ||
                    extremeShortMomentum ||
                    aggressiveLongExpansion ||
                    aggressiveShortExpansion ||
                    exceptionalMicrostructureLong ||
                    exceptionalMicrostructureShort
                );

            if (
                !nySessionActive ||
                !allowMomentumMode ||
                (
                    openingBuildLock &&
                    !extremeOpeningOverride
                ) ||
                openingCandidatePresent
            )
            {
                return;
            }

            string effectiveRangeDirection;

            // Premarket AUTO is resolved from the premarket frontier because
            // the regular-session VWAP intentionally does not exist yet.
            if (
                premarketSession &&
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                bool premarketAutoLong =
                    premarketLongBias ||
                    aggressiveLongExpansion ||
                    premarketEarlyLongAggression ||
                    exceptionalMicrostructureLong;

                bool premarketAutoShort =
                    premarketShortBias ||
                    aggressiveShortExpansion ||
                    premarketEarlyShortAggression ||
                    exceptionalMicrostructureShort;

                if (
                    premarketAutoLong !=
                        premarketAutoShort
                )
                {
                    effectiveRangeDirection =
                        premarketAutoLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        exceptionalMicrostructureLong ||
                        exceptionalMicrostructureShort
                            ? (
                                premarketAutoLong
                                    ? "PREMARKET EXCEPTIONAL MICROSTRUCTURE LONG"
                                    : "PREMARKET EXCEPTIONAL MICROSTRUCTURE SHORT"
                              )
                            : premarketEarlyLongAggression ||
                              premarketEarlyShortAggression
                            ? (
                                premarketAutoLong
                                    ? "PREMARKET EARLY AGGRESSION LONG"
                                    : "PREMARKET EARLY AGGRESSION SHORT"
                              )
                            : aggressiveLongExpansion ||
                              aggressiveShortExpansion
                                ? (
                                    premarketAutoLong
                                        ? "PREMARKET FRESH AGGRESSIVE EXPANSION LONG"
                                        : "PREMARKET FRESH AGGRESSIVE EXPANSION SHORT"
                                  )
                                : (
                                    premarketAutoLong
                                        ? "PREMARKET HIGH BREAKOUT + MOMENTUM"
                                        : "PREMARKET LOW BREAKOUT + MOMENTUM"
                                  );
                }
                else
                {
                    effectiveRangeDirection =
                        "NONE";

                    autoResolvedDirection =
                        "NONE";

                    autoDirectionReason =
                        "PREMARKET WAITING FOR RANGE BREAKOUT";
                }
            }
            // V1.6.20 RTH AUTO:
            // ALIGNED pressure -> preserve direct scalp entry.
            // NEUTRAL pressure -> fast impulse may discover direction.
            // COUNTER pressure -> classify as pullback; do not flip AUTO.
            else if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                (
                    exceptionalMicrostructureLong !=
                        exceptionalMicrostructureShort ||
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion ||
                    extremeLongMomentum !=
                        extremeShortMomentum
                )
            )
            {
                bool resolveLong =
                    exceptionalMicrostructureLong !=
                        exceptionalMicrostructureShort
                        ? exceptionalMicrostructureLong
                        : aggressiveLongExpansion !=
                            aggressiveShortExpansion
                            ? aggressiveLongExpansion
                            : extremeLongMomentum;

                int longPressureScore;
                int shortPressureScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out longPressureScore,
                        out shortPressureScore
                    );

                bool counterPressure =
                    (
                        resolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !resolveLong &&
                        pressure == "LONG"
                    );

                bool universalExceptionalResolve =
                    exceptionalMicrostructureLong !=
                        exceptionalMicrostructureShort;

                if (universalExceptionalResolve)
                {
                    effectiveRangeDirection =
                        resolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        "EXCEPTIONAL MICROSTRUCTURE "
                        + (resolveLong ? "LONG" : "SHORT")
                        + " | M5/STRUCTURE/PRESSURE CONTEXT ONLY"
                        + " | Pressure: " + pressure
                        + " " + longPressureScore + "/" + shortPressureScore;
                }
                else if (counterPressure)
                {
                    effectiveRangeDirection =
                        pressure == "LONG"
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        "COUNTER-PRESSURE FAST IMPULSE BLOCKED"
                        + " | Pressure: " + pressure
                        + " " + longPressureScore + "/" + shortPressureScore
                        + " | FastSide: " + (resolveLong ? "LONG" : "SHORT")
                        + " | WAIT RESUMPTION";

                    string pressureLogKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|" + pressure
                        + "|" + (resolveLong ? "LONG" : "SHORT")
                        + "|" + longPressureScore
                        + "/" + shortPressureScore;

                    if (
                        pressureLogKey !=
                            lastDirectionalPressureLogKey
                    )
                    {
                        lastDirectionalPressureLogKey =
                            pressureLogKey;

                        PrintBotMessage(
                            "COUNTER-PRESSURE MOMENTUM"
                            + " | FastSide: "
                            + (resolveLong ? "LONG" : "SHORT")
                            + " | GeneralPressure: " + pressure
                            + " | Score L/S: "
                            + longPressureScore + "/" + shortPressureScore
                            + " | Action: PULLBACK - NO COUNTER ENTRY"
                        );
                    }
                }
                else
                {
                    effectiveRangeDirection =
                        resolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    string pressureTag =
                        pressure == "NEUTRAL"
                            ? "NEUTRAL DISCOVERY"
                            : "ALIGNED PRESSURE";

                    autoDirectionReason =
                        (
                            aggressiveLongExpansion ||
                            aggressiveShortExpansion
                                ? (
                                    resolveLong
                                        ? "FRESH AGGRESSIVE EXPANSION LONG"
                                        : "FRESH AGGRESSIVE EXPANSION SHORT"
                                  )
                                : (
                                    resolveLong
                                        ? "EXTREME R20 LONG + BREAKOUT + VWAP"
                                        : "EXTREME R20 SHORT + BREAKOUT + VWAP"
                                  )
                        )
                        + " | " + pressureTag
                        + " " + longPressureScore + "/" + shortPressureScore;
                }
            }
            else
            {
                effectiveRangeDirection =
                    ResolveEffectiveDirection(
                        rangeNyTime,
                        rangeClose,
                        m5Bullish,
                        m5Bearish,
                        m5AboveVwap,
                        m5BelowVwap
                    );
            }

            bool allowLong =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "LONG ONLY";

            bool allowShort =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "SHORT ONLY";


            // V1.6.56 - A confirmed exceptional microstructure impulse may
            // reopen the intended side even while the slower Direction Engine
            // is still neutral/opposed. Final execution safety gates still run.
            if (exceptionalMicrostructureLong)
                allowLong = true;

            if (exceptionalMicrostructureShort)
                allowShort = true;

            // =====================================================
            // V1.6.55 - CONFIRMED ABSORPTION REVERSAL AUTHORITY
            // =====================================================
            // Level2 never creates a trade from aggression alone. A reversal
            // becomes eligible only AFTER heavy absorption is confirmed by
            // failure-to-progress + reclaim, and the 20-tick price engine is
            // already turning in the same direction.
            string absorptionLongSummary;
            string absorptionShortSummary;

            bool absorptionLongFlow =
                TryGetConfirmedAbsorptionReversalSupport(
                    true,
                    out absorptionLongSummary
                );

            bool absorptionShortFlow =
                TryGetConfirmedAbsorptionReversalSupport(
                    false,
                    out absorptionShortSummary
                );

            bool absorptionReversalLong =
                absorptionLongFlow &&
                longScore >= 2 &&
                shortScore <= 2 &&
                emaSlope >= 1.5 &&
                bodyRatio >= 0.50;

            bool absorptionReversalShort =
                absorptionShortFlow &&
                shortScore >= 2 &&
                longScore <= 2 &&
                emaSlope <= -1.5 &&
                bodyRatio >= 0.50;

            if (absorptionReversalLong)
                allowLong = true;

            if (absorptionReversalShort)
                allowShort = true;

            string momentumSession =
                GetBotSessionWindow(
                    rangeNyTime
                );

            bool strictMiddayMomentum =
                string.Equals(
                    momentumSession,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            // =====================================================
            // V1.6.28 - EARLY TREND CAPTURE V1
            // =====================================================
            // 3/5 may enter early only when M5 + VWAP + breakout are aligned.
            // A plain 3/5 against confirmed M5 is not allowed.
            bool earlyAlignedLong =
                !premarketSession &&
                allowLong &&
                m5Bullish &&
                m5AboveVwap &&
                longScore >= 3 &&
                shortScore <= 1 &&
                highBreakout;

            bool earlyAlignedShort =
                !premarketSession &&
                allowShort &&
                m5Bearish &&
                m5BelowVwap &&
                shortScore >= 3 &&
                longScore <= 1 &&
                lowBreakout;

            if (earlyAlignedLong)
            {
                persistentDirectionBias = "LONG ONLY";
                persistentDirectionBiasLastConfirmedNy = rangeNyTime;
                persistentDirectionBiasUntilNy =
                    rangeNyTime.AddSeconds(
                        PersistentDirectionBiasSeconds
                    );
            }
            else if (earlyAlignedShort)
            {
                persistentDirectionBias = "SHORT ONLY";
                persistentDirectionBiasLastConfirmedNy = rangeNyTime;
                persistentDirectionBiasUntilNy =
                    rangeNyTime.AddSeconds(
                        PersistentDirectionBiasSeconds
                    );
            }
            else if (
                persistentDirectionBiasUntilNy != DateTime.MinValue &&
                rangeNyTime > persistentDirectionBiasUntilNy
            )
            {
                persistentDirectionBias = "NONE";
                persistentDirectionBiasUntilNy = DateTime.MinValue;
                persistentDirectionBiasLastConfirmedNy = DateTime.MinValue;
            }

            bool persistentLongBias =
                string.Equals(
                    persistentDirectionBias,
                    "LONG ONLY",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                rangeNyTime <= persistentDirectionBiasUntilNy &&
                m5Bullish &&
                m5AboveVwap;

            bool persistentShortBias =
                string.Equals(
                    persistentDirectionBias,
                    "SHORT ONLY",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                rangeNyTime <= persistentDirectionBiasUntilNy &&
                m5Bearish &&
                m5BelowVwap;

            // =====================================================
            // V1.6.29 - PERSISTENT MOMENTUM CONFIRMATION
            // =====================================================
            // A valid aligned 3/5 impulse can decay to 2/5 on the next
            // Range callback simply because volume/breakout is no longer
            // counted. Keep that impulse alive for 30 seconds ONLY while:
            // - M5 and VWAP remain aligned,
            // - opposite momentum stays <= 1,
            // - EMA9 slope still points in the trade direction.
            bool persistentLongContinuation =
                persistentLongBias &&
                persistentDirectionBiasLastConfirmedNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    persistentDirectionBiasLastConfirmedNy
                ).TotalSeconds <=
                    PersistentMomentumContinuationSeconds &&
                longScore >= 2 &&
                shortScore <= 1 &&
                emaSlope > 0;

            bool persistentShortContinuation =
                persistentShortBias &&
                persistentDirectionBiasLastConfirmedNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    persistentDirectionBiasLastConfirmedNy
                ).TotalSeconds <=
                    PersistentMomentumContinuationSeconds &&
                shortScore >= 2 &&
                longScore <= 1 &&
                emaSlope < 0;

            bool rawLongReady =
                premarketSession
                    ? (
                        allowLong &&
                        (
                            premarketLongBias ||
                            aggressiveLongExpansion ||
                            premarketEarlyLongAggression ||
                            exceptionalMicrostructureLong
                        )
                      )
                    : (
                        allowLong &&
                        (
                            absorptionReversalLong ||
                            exceptionalMicrostructureLong ||
                            (
                                m5AboveVwap &&
                                (
                                    (m5Bullish && bullishMomentum) ||
                                    earlyAlignedLong ||
                                    (
                                        persistentLongBias &&
                                        longScore >= 3 &&
                                        shortScore <= 1 &&
                                        highBreakout
                                    ) ||
                                    persistentLongContinuation ||
                                    extremeLongMomentum ||
                                    aggressiveLongExpansion
                                )
                            )
                        )
                      );

            if (liquidityBreakLongSignal && allowLong)
                rawLongReady = true;

            bool rawShortReady =
                premarketSession
                    ? (
                        allowShort &&
                        (
                            premarketShortBias ||
                            aggressiveShortExpansion ||
                            premarketEarlyShortAggression ||
                            exceptionalMicrostructureShort
                        )
                      )
                    : (
                        allowShort &&
                        (
                            absorptionReversalShort ||
                            exceptionalMicrostructureShort ||
                            (
                                m5BelowVwap &&
                                (
                                    (m5Bearish && bearishMomentum) ||
                                    earlyAlignedShort ||
                                    (
                                        persistentShortBias &&
                                        shortScore >= 3 &&
                                        longScore <= 1 &&
                                        lowBreakout
                                    ) ||
                                    persistentShortContinuation ||
                                    extremeShortMomentum ||
                                    aggressiveShortExpansion
                                )
                            )
                        )
                      );

            if (liquidityBreakShortSignal && allowShort)
                rawShortReady = true;

            // =====================================================
            // =====================================================
            // V1.6.80 - UNIFIED EDGE OBSERVATIONAL CONTEXT
            // =====================================================
            // Keep the weighted calculation and telemetry, but it no longer
            // changes raw readiness or side. Strategy evidence must create the
            // candidate; Final Entry Authority owns execution.
            int weightedLongScore = 0;
            int weightedShortScore = 0;
            string weightedLongSummary = string.Empty;
            string weightedShortSummary = string.Empty;

            bool weightedLongAuthority =
                TryGetWeightedExecutionAuthority(
                    true,
                    rangeNyTime,
                    out weightedLongScore,
                    out weightedLongSummary
                );

            bool weightedShortAuthority =
                TryGetWeightedExecutionAuthority(
                    false,
                    rangeNyTime,
                    out weightedShortScore,
                    out weightedShortSummary
                );

            if (weightedLongAuthority && !weightedShortAuthority)
            {
                LogWeightedExecutionAuthority(
                    true,
                    rangeNyTime,
                    weightedLongScore,
                    weightedLongSummary,
                    "OBSERVATIONAL CONTEXT | NO EXECUTION BYPASS"
                );
            }
            else if (weightedShortAuthority && !weightedLongAuthority)
            {
                LogWeightedExecutionAuthority(
                    false,
                    rangeNyTime,
                    weightedShortScore,
                    weightedShortSummary,
                    "OBSERVATIONAL CONTEXT | NO EXECUTION BYPASS"
                );
            }

            // Never let an ordinary 3/5 trade directly against confirmed M5.
            // Extreme/Aggressive paths keep their existing special handling.
            if (
                rawLongReady &&
                longScore == 3 &&
                m5Bearish &&
                !extremeLongMomentum &&
                !aggressiveLongExpansion &&
                !absorptionReversalLong &&
                !weightedLongAuthority &&
                !openingPriority
            )
            {
                rawLongReady = false;
            }

            if (
                rawShortReady &&
                shortScore == 3 &&
                m5Bullish &&
                !extremeShortMomentum &&
                !aggressiveShortExpansion &&
                !absorptionReversalShort &&
                !weightedShortAuthority &&
                !openingPriority
            )
            {
                rawShortReady = false;
            }

            if (strictMiddayMomentum)
            {
                // V1.6.29:
                // Keep the original strict midday path for ordinary signals,
                // but do NOT kill a clean V1 aligned early impulse or its
                // 30-second continuation memory. This fixes the case where
                // MIDDAY demanded 5/5 + HTF and discarded a valid 3/5 trend
                // even while M5 + VWAP + breakout were aligned.
                rawLongReady =
                    rawLongReady &&
                    (
                        weightedLongAuthority ||
                        absorptionReversalLong ||
                        earlyAlignedLong ||
                        persistentLongContinuation ||
                        (
                            longScore >=
                                MiddayMomentumMinScore &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveLongExpansion &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );

                rawShortReady =
                    rawShortReady &&
                    (
                        weightedShortAuthority ||
                        absorptionReversalShort ||
                        earlyAlignedShort ||
                        persistentShortContinuation ||
                        (
                            shortScore >=
                                MiddayMomentumMinScore &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveShortExpansion &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );
            }

            if (premarketSession)
            {
                if (!premarketRangeValid)
                {
                    return;
                }

                if (rawLongReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            true,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        bool weightedSoftChaseOverride =
                            weightedLongAuthority &&
                            extensionTicks <=
                                WeightedExecutionSoftMaxExtensionTicks &&
                            !HasConfirmedOpposingAbsorption(true);

                        if (weightedSoftChaseOverride)
                        {
                            LogWeightedExecutionAuthority(
                                true,
                                rangeNyTime,
                                weightedLongScore,
                                weightedLongSummary,
                                "PREMARKET SOFT CHASE OVERRIDE | Extension "
                                    + extensionTicks.ToString("0")
                                    + "t/"
                                    + WeightedExecutionSoftMaxExtensionTicks.ToString("0")
                                    + "t"
                            );
                        }
                        else
                        {
                            LogPremarketPriceChaseBlock(
                                true,
                                rangeNyTime,
                                rangeClose,
                                extensionTicks
                            );

                            rawLongReady =
                                false;
                        }
                    }
                }

                if (rawShortReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            false,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        bool weightedSoftChaseOverride =
                            weightedShortAuthority &&
                            extensionTicks <=
                                WeightedExecutionSoftMaxExtensionTicks &&
                            !HasConfirmedOpposingAbsorption(false);

                        if (weightedSoftChaseOverride)
                        {
                            LogWeightedExecutionAuthority(
                                false,
                                rangeNyTime,
                                weightedShortScore,
                                weightedShortSummary,
                                "PREMARKET SOFT CHASE OVERRIDE | Extension "
                                    + extensionTicks.ToString("0")
                                    + "t/"
                                    + WeightedExecutionSoftMaxExtensionTicks.ToString("0")
                                    + "t"
                            );
                        }
                        else
                        {
                            LogPremarketPriceChaseBlock(
                                false,
                                rangeNyTime,
                                rangeClose,
                                extensionTicks
                            );

                            rawShortReady =
                                false;
                        }
                    }
                }
            }

            // =====================================================
            // OPENING SAFETY PATCH - UNIVERSAL CONTEXT / ANTI-CHASE
            // =====================================================
            // During the Opening fallback window, fast-path Momentum cannot
            // enter directly against M5 or beyond the Opening anti-chase limit.
            // Instead, the candidate is converted into a pending Smart Retest.
            if (openingPriority && !premarketSession)
            {
                if (rawLongReady && m5Bearish && !absorptionReversalLong && !exceptionalMicrostructureLong)
                {
                    string reversalSummary;
                    bool reversalOverride =
                        TryGetOpeningCounterM5ReversalSupport(
                            true,
                            longScore,
                            out reversalSummary
                        );

                    if (reversalOverride)
                    {
                        string overrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|LONG";

                        if (overrideKey != lastOpeningCounterM5OverrideLogKey)
                        {
                            lastOpeningCounterM5OverrideLogKey = overrideKey;
                            PrintBotMessage(
                                "OPENING COUNTER-M5 REVERSAL OVERRIDE"
                                + " | Side: LONG"
                                + " | M5: BEARISH"
                                + " | R20: " + longScore + "/5"
                                + " | " + reversalSummary
                                + " | Action: FAST PATH REMAINS ELIGIBLE"
                            );
                        }
                    }
                    else
                    {
                        double breakoutLevel =
                            openingRangeReady
                                ? openingRangeHigh
                                : GetHighestHigh(
                                    bars,
                                    Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                    closedBarIndex - 1
                                  );

                        ArmSmartRetest(
                            true,
                            rangeNyTime,
                            breakoutLevel,
                            m5BullishBreakLevel,
                            rangeClose,
                            longScore,
                            "OPENING COUNTERTREND LONG"
                        );

                        string blockKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|LONG|M5_BEARISH";

                        if (blockKey != lastOpeningContextBlockLogKey)
                        {
                            lastOpeningContextBlockLogKey = blockKey;
                            PrintBotMessage(
                                "OPENING FAST PATH BLOCKED - COUNTERTREND"
                                + " | Side: LONG"
                                + " | M5: BEARISH"
                                + " | " + reversalSummary
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawLongReady = false;
                    }
                }

                if (rawShortReady && m5Bullish && !absorptionReversalShort && !exceptionalMicrostructureShort)
                {
                    string reversalSummary;
                    bool reversalOverride =
                        TryGetOpeningCounterM5ReversalSupport(
                            false,
                            shortScore,
                            out reversalSummary
                        );

                    if (reversalOverride)
                    {
                        string overrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|SHORT";

                        if (overrideKey != lastOpeningCounterM5OverrideLogKey)
                        {
                            lastOpeningCounterM5OverrideLogKey = overrideKey;
                            PrintBotMessage(
                                "OPENING COUNTER-M5 REVERSAL OVERRIDE"
                                + " | Side: SHORT"
                                + " | M5: BULLISH"
                                + " | R20: " + shortScore + "/5"
                                + " | " + reversalSummary
                                + " | Action: FAST PATH REMAINS ELIGIBLE"
                            );
                        }
                    }
                    else
                    {
                        double breakoutLevel =
                            openingRangeReady
                                ? openingRangeLow
                                : GetLowestLow(
                                    bars,
                                    Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                    closedBarIndex - 1
                                  );

                        ArmSmartRetest(
                            false,
                            rangeNyTime,
                            breakoutLevel,
                            m5BearishBreakLevel,
                            rangeClose,
                            shortScore,
                            "OPENING COUNTERTREND SHORT"
                        );

                        string blockKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|SHORT|M5_BULLISH";

                        if (blockKey != lastOpeningContextBlockLogKey)
                        {
                            lastOpeningContextBlockLogKey = blockKey;
                            PrintBotMessage(
                                "OPENING FAST PATH BLOCKED - COUNTERTREND"
                                + " | Side: SHORT"
                                + " | M5: BULLISH"
                                + " | " + reversalSummary
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawShortReady = false;
                    }
                }

                if (rawLongReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        string liquidityBreakSummary;
                        bool liquidityBreakOverride =
                            TryGetLiquidityBreakAcceptanceOverride(
                                true,
                                rangeNyTime,
                                rangeClose,
                                momentumTickSize,
                                aggressiveLongExpansion || extremeLongMomentum,
                                out liquidityBreakSummary
                            );

                        if (liquidityBreakOverride)
                        {
                            string windowKey =
                                rangeNyTime.ToString("yyyyMMddHHmmss")
                                + "|LONG|"
                                + pendingLiquidityBreakLevel.ToString("0.00", CultureInfo.InvariantCulture);

                            if (windowKey != lastLiquidityBreakWindowLogKey)
                            {
                                lastLiquidityBreakWindowLogKey = windowKey;
                                PrintBotMessage(
                                    "LIQUIDITY BREAK ACCEPTANCE ENTRY WINDOW"
                                    + " | Side: LONG"
                                    + " | " + liquidityBreakSummary
                                    + " | Action: ANTI-CHASE BYPASS NEAR BROKEN LEVEL"
                                );
                            }
                        }
                        else
                        {
                        LogOpeningPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            true,
                            rangeNyTime,
                            openingRangeReady ? openingRangeHigh : rangeClose,
                            m5BullishBreakLevel,
                            rangeClose,
                            longScore,
                            "OPENING PRICE EXTENDED LONG"
                        );

                        string antiChaseOverrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmm")
                            + "|LONG";

                        if (
                            antiChaseOverrideKey !=
                                lastOpeningAntiChaseOverrideLogKey
                        )
                        {
                            lastOpeningAntiChaseOverrideLogKey =
                                antiChaseOverrideKey;

                            PrintBotMessage(
                                "OPENING ANTI-CHASE OVERRIDE"
                                + " | Side: LONG"
                                + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                                + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                                + " | Aggressive: " + aggressiveLongExpansion
                                + " | Extreme: " + extremeLongMomentum
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawLongReady = false;
                        }
                    }
                }

                if (rawShortReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        string liquidityBreakSummary;
                        bool liquidityBreakOverride =
                            TryGetLiquidityBreakAcceptanceOverride(
                                false,
                                rangeNyTime,
                                rangeClose,
                                momentumTickSize,
                                aggressiveShortExpansion || extremeShortMomentum,
                                out liquidityBreakSummary
                            );

                        if (liquidityBreakOverride)
                        {
                            string windowKey =
                                rangeNyTime.ToString("yyyyMMddHHmmss")
                                + "|SHORT|"
                                + pendingLiquidityBreakLevel.ToString("0.00", CultureInfo.InvariantCulture);

                            if (windowKey != lastLiquidityBreakWindowLogKey)
                            {
                                lastLiquidityBreakWindowLogKey = windowKey;
                                PrintBotMessage(
                                    "LIQUIDITY BREAK ACCEPTANCE ENTRY WINDOW"
                                    + " | Side: SHORT"
                                    + " | " + liquidityBreakSummary
                                    + " | Action: ANTI-CHASE BYPASS NEAR BROKEN LEVEL"
                                );
                            }
                        }
                        else
                        {
                        LogOpeningPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            false,
                            rangeNyTime,
                            openingRangeReady ? openingRangeLow : rangeClose,
                            m5BearishBreakLevel,
                            rangeClose,
                            shortScore,
                            "OPENING PRICE EXTENDED SHORT"
                        );

                        string antiChaseOverrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmm")
                            + "|SHORT";

                        if (
                            antiChaseOverrideKey !=
                                lastOpeningAntiChaseOverrideLogKey
                        )
                        {
                            lastOpeningAntiChaseOverrideLogKey =
                                antiChaseOverrideKey;

                            PrintBotMessage(
                                "OPENING ANTI-CHASE OVERRIDE"
                                + " | Side: SHORT"
                                + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                                + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                                + " | Aggressive: " + aggressiveShortExpansion
                                + " | Extreme: " + extremeShortMomentum
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawShortReady = false;
                        }
                    }
                }
            }

            // =====================================================
            // V1.6.9 - POST-MOVE EXHAUSTION GUARD
            // =====================================================
            // A mature directional move may keep producing ordinary Momentum
            // scores even after the best expansion is gone. If price is already
            // far from the session opposite extreme and current flow is weak,
            // do not keep chasing that same direction. A genuinely NEW
            // aggressive expansion is allowed through.
            double sessionUpMoveTicks;
            double sessionDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                out sessionUpMoveTicks,
                out sessionDownMoveTicks
            );

            bool weakCurrentExpansion =
                volumeRatio <=
                    ExhaustionMaxWeakVolumeRatio ||
                bodyRatio <=
                    ExhaustionMaxWeakBodyRatio;

            if (
                rawLongReady &&
                !aggressiveLongExpansion &&
                !absorptionReversalLong &&
                sessionUpMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    true,
                    rangeNyTime,
                    sessionUpMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    longScore
                );

                rawLongReady =
                    false;
            }

            if (
                rawShortReady &&
                !aggressiveShortExpansion &&
                !absorptionReversalShort &&
                sessionDownMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    false,
                    rangeNyTime,
                    sessionDownMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    shortScore
                );

                rawShortReady =
                    false;
            }

            // =====================================================
            // V1.6.11 - SMART RETEST / NO-CHASE ENTRY ENGINE
            // =====================================================
            // Extended ordinary signals arm a short-lived pending setup instead
            // of being forgotten. Aggressive Expansion may enter immediately only
            // when the higher-priority Opening safety guards above allow it.
            if (rawLongReady && !aggressiveLongExpansion && !absorptionReversalLong)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = longScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double freshAgeSeconds =
                        freshMomentumLongTriggerNy == DateTime.MinValue
                            ? 999.0
                            : (rangeNyTime - freshMomentumLongTriggerNy).TotalSeconds;

                    double freshProgressTicks =
                        momentumTickSize > 0 &&
                        freshMomentumLongTriggerPrice > 0
                            ? (rangeClose - freshMomentumLongTriggerPrice) / momentumTickSize
                            : 0.0;

                    string continuationFlowSummary;
                    bool continuationFlow =
                        TryGetFreshMomentumContinuationFlowSupport(
                            true,
                            out continuationFlowSummary
                        );

                    bool freshContinuationGrace =
                        longScore >= 3 &&
                        freshAgeSeconds >= 0 &&
                        freshAgeSeconds <= FreshMomentumGraceSeconds &&
                        extensionTicks <= FreshMomentumGraceMaxExtensionTicks &&
                        freshProgressTicks >= FreshMomentumMinProgressTicks &&
                        continuationFlow;

                    bool weightedExtensionOverride =
                        weightedLongAuthority &&
                        extensionTicks <=
                            WeightedExecutionSoftMaxExtensionTicks;

                    if (freshContinuationGrace || weightedExtensionOverride)
                    {
                        if (weightedExtensionOverride && !freshContinuationGrace)
                        {
                            LogWeightedExecutionAuthority(
                                true,
                                rangeNyTime,
                                weightedLongScore,
                                weightedLongSummary,
                                "EMA9 SOFT EXTENSION OVERRIDE | Extension "
                                    + extensionTicks.ToString("0")
                                    + "t/"
                                    + WeightedExecutionSoftMaxExtensionTicks.ToString("0")
                                    + "t"
                            );
                        }
                        else
                        {
                            string graceKey =
                                rangeNyTime.ToString("yyyyMMddHHmmss") + "|LONG";

                            if (graceKey != lastFreshMomentumExtensionOverrideLogKey)
                            {
                                lastFreshMomentumExtensionOverrideLogKey = graceKey;
                                PrintBotMessage(
                                    "FRESH MOMENTUM EXTENSION OVERRIDE"
                                    + " | Side: LONG"
                                    + " | R20: " + longScore + "/5"
                                    + " | TriggerAge: " + freshAgeSeconds.ToString("0.0") + "s"
                                    + " | Progress: " + freshProgressTicks.ToString("0") + "t"
                                    + " | EMA9Ext: " + extensionTicks.ToString("0") + "t"
                                    + " | NormalMax: " + maxExtensionTicks.ToString("0") + "t"
                                    + " | GraceMax: " + FreshMomentumGraceMaxExtensionTicks.ToString("0") + "t"
                                    + " | " + continuationFlowSummary
                                    + " | Action: DIRECT ENTRY REMAINS ELIGIBLE"
                                );
                            }
                        }
                    }
                    else
                    {
                        double breakoutLevel = GetHighestHigh(
                            bars,
                            Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                            closedBarIndex - 1
                        );
                        ArmSmartRetest(
                            true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                            rangeClose, longScore, "EXTENDED LONG SIGNAL"
                        );
                        LogPullbackWait(true, rangeNyTime, extensionTicks, maxExtensionTicks, longScore);
                        rawLongReady = false;
                    }
                }
            }

            if (rawShortReady && !aggressiveShortExpansion && !absorptionReversalShort)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = shortScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double freshAgeSeconds =
                        freshMomentumShortTriggerNy == DateTime.MinValue
                            ? 999.0
                            : (rangeNyTime - freshMomentumShortTriggerNy).TotalSeconds;

                    double freshProgressTicks =
                        momentumTickSize > 0 &&
                        freshMomentumShortTriggerPrice > 0
                            ? (freshMomentumShortTriggerPrice - rangeClose) / momentumTickSize
                            : 0.0;

                    string continuationFlowSummary;
                    bool continuationFlow =
                        TryGetFreshMomentumContinuationFlowSupport(
                            false,
                            out continuationFlowSummary
                        );

                    bool freshContinuationGrace =
                        shortScore >= 3 &&
                        freshAgeSeconds >= 0 &&
                        freshAgeSeconds <= FreshMomentumGraceSeconds &&
                        extensionTicks <= FreshMomentumGraceMaxExtensionTicks &&
                        freshProgressTicks >= FreshMomentumMinProgressTicks &&
                        continuationFlow;

                    bool weightedExtensionOverride =
                        weightedShortAuthority &&
                        extensionTicks <=
                            WeightedExecutionSoftMaxExtensionTicks;

                    if (freshContinuationGrace || weightedExtensionOverride)
                    {
                        if (weightedExtensionOverride && !freshContinuationGrace)
                        {
                            LogWeightedExecutionAuthority(
                                false,
                                rangeNyTime,
                                weightedShortScore,
                                weightedShortSummary,
                                "EMA9 SOFT EXTENSION OVERRIDE | Extension "
                                    + extensionTicks.ToString("0")
                                    + "t/"
                                    + WeightedExecutionSoftMaxExtensionTicks.ToString("0")
                                    + "t"
                            );
                        }
                        else
                        {
                            string graceKey =
                                rangeNyTime.ToString("yyyyMMddHHmmss") + "|SHORT";

                            if (graceKey != lastFreshMomentumExtensionOverrideLogKey)
                            {
                                lastFreshMomentumExtensionOverrideLogKey = graceKey;
                                PrintBotMessage(
                                    "FRESH MOMENTUM EXTENSION OVERRIDE"
                                    + " | Side: SHORT"
                                    + " | R20: " + shortScore + "/5"
                                    + " | TriggerAge: " + freshAgeSeconds.ToString("0.0") + "s"
                                    + " | Progress: " + freshProgressTicks.ToString("0") + "t"
                                    + " | EMA9Ext: " + extensionTicks.ToString("0") + "t"
                                    + " | NormalMax: " + maxExtensionTicks.ToString("0") + "t"
                                    + " | GraceMax: " + FreshMomentumGraceMaxExtensionTicks.ToString("0") + "t"
                                    + " | " + continuationFlowSummary
                                    + " | Action: DIRECT ENTRY REMAINS ELIGIBLE"
                                );
                            }
                        }
                    }
                    else
                    {
                        double breakoutLevel = GetLowestLow(
                            bars,
                            Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                            closedBarIndex - 1
                        );
                        ArmSmartRetest(
                            false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                            rangeClose, shortScore, "EXTENDED SHORT SIGNAL"
                        );
                        LogPullbackWait(false, rangeNyTime, extensionTicks, maxExtensionTicks, shortScore);
                        rawShortReady = false;
                    }
                }
            }

            // V1.6.23 Phase 3 - AGGRESSIVE MATURE-MOVE HARD CAP.
            // Aggressive Expansion keeps its fast-entry privilege while fresh.
            // But if price is already extremely stretched from EMA9 AND the
            // directional session leg is mature, do not buy/sell the tail.
            // Convert it into the existing Smart Retest workflow instead.
            if (rawLongReady && aggressiveLongExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize);

                if (
                    sessionUpMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks &&
                    (!weightedLongAuthority ||
                     aggressiveExtensionTicks > WeightedExecutionSoftMaxExtensionTicks)
                )
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "MATURE AGGRESSIVE LONG"
                    );

                    LogPullbackWait(
                        true, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, longScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: LONG"
                        + " | SessionMove: " + sessionUpMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawLongReady = false;
                }
            }

            if (rawShortReady && aggressiveShortExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize);

                if (
                    sessionDownMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks &&
                    (!weightedShortAuthority ||
                     aggressiveExtensionTicks > WeightedExecutionSoftMaxExtensionTicks)
                )
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "MATURE AGGRESSIVE SHORT"
                    );

                    LogPullbackWait(
                        false, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, shortScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: SHORT"
                        + " | SessionMove: " + sessionDownMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawShortReady = false;
                }
            }

            string recorderLongMovePhase = "NOT_EVALUATED";
            string recorderShortMovePhase = "NOT_EVALUATED";

            string momentumEntryRoute = "DIRECT";
            string momentumEntryRouteReason = "FRESH/DEVELOPING MOMENTUM";

            // =====================================================
            // V1.6.32 - MOVE PHASE ENTRY GATE
            // =====================================================
            // Preserve fresh EARLY entries only while the move is genuinely
            // igniting/expanding. A high confidence score by itself is not
            // permission to enter a mature or exhausting directional leg.
            if (rawLongReady && momentumTickSize > 0)
            {
                double longEmaExtensionTicks =
                    Math.Max(
                        0,
                        (rangeClose - emaFastCurrent) /
                            momentumTickSize
                    );

                string longMovePhase =
                    EvaluateMovePhase(
                        true,
                        longScore,
                        shortScore,
                        highBreakout,
                        aggressiveLongExpansion,
                        aggressiveLongDisplacementTicks,
                        longEmaExtensionTicks,
                        sessionUpMoveTicks,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks
                    );

                recorderLongMovePhase = longMovePhase;

                if (
                    longMovePhase == "MATURE" ||
                    longMovePhase == "EXHAUSTION"
                )
                {
                    // V1.6.51 - FRESH CONTINUATION OVERRIDE
                    // A session can be mature while a NEW opening leg is
                    // genuinely fresh.  Do not force Smart Retest when price
                    // is still displacing with a 4/5 impulse, strong body /
                    // volume / slope and fresh aligned order-flow.  Never
                    // override EXHAUSTION.
                    string freshContinuationFlowSummary;
                    bool freshContinuationFlow =
                        TryGetEarlyAggressionFlowSupport(
                            true,
                            out freshContinuationFlowSummary
                        );

                    bool freshContinuationOverride =
                        longMovePhase == "MATURE" &&
                        openingPriority &&
                        highBreakout &&
                        longScore >= 4 &&
                        shortScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.75 &&
                        slopeTicks >= 3.0 &&
                        (
                            aggressiveLongExpansion ||
                            aggressiveLongDisplacementTicks >=
                                AggressionMinDisplacementTicks
                        ) &&
                        freshContinuationFlow;

                    // V1.6.58 - A freshly armed exceptional thesis may bypass
                    // MATURE -> Smart Retest only while price is still close
                    // enough to EMA9 to be executable.  EXHAUSTION never gets
                    // this privilege.  Confirmed opposite absorption and a
                    // strongly opposed current L2 snapshot remain hard vetoes.
                    string longCommitmentSummary;
                    bool longCommitmentActive =
                        IsExceptionalCommitmentActive(
                            true, rangeNyTime, out longCommitmentSummary
                        );
                    string longOpposedSummary = string.Empty;
                    bool longStronglyOpposed =
                        longCommitmentActive &&
                        IsInitialEntryLevel2StronglyOpposed(
                            true, out longOpposedSummary
                        );
                    bool exceptionalMatureDirectLong =
                        longMovePhase == "MATURE" &&
                        longCommitmentActive &&
                        !longStronglyOpposed &&
                        !HasConfirmedOpposingAbsorption(true) &&
                        highBreakout &&
                        longScore >= 4 &&
                        shortScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.75 &&
                        slopeTicks >= 3.0 &&
                        longEmaExtensionTicks <=
                            FreshMomentumGraceMaxExtensionTicks;

                    bool breakoutContinuationLong =
                        longMovePhase == "MATURE" &&
                        highBreakout &&
                        longScore >= 4 &&
                        shortScore <= 1 &&
                        aggressiveLongExpansion &&
                        volumeRatio >= 1.25 &&
                        bodyRatio >= 0.68 &&
                        slopeTicks >= 3.0 &&
                        freshContinuationFlow &&
                        !HasConfirmedOpposingAbsorption(true) &&
                        longEmaExtensionTicks <= FreshMomentumGraceMaxExtensionTicks;

                    // V1.6.81 - PREMARKET SECOND-LEG RE-ACCELERATION
                    // A mature SESSION move must not automatically force a second
                    // Smart Retest after price has already cooled back near EMA9
                    // and a new, independently confirmed premarket impulse appears.
                    // Final Entry Authority still owns the actual order decision.
                    bool premarketSecondLegLong =
                        longMovePhase == "MATURE" &&
                        premarketSession &&
                        premarketEarlyLongAggression &&
                        weightedLongAuthority &&
                        highBreakout &&
                        longScore >= 4 &&
                        shortScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.60 &&
                        slopeTicks >= 3.0 &&
                        longEmaExtensionTicks <= 40.0 &&
                        !HasConfirmedOpposingAbsorption(true);

                    if (premarketSecondLegLong)
                    {
                        momentumEntryRoute = "BREAKOUT_CONTINUATION";
                        momentumEntryRouteReason =
                            "PREMARKET_SECOND_LEG | SECOND LEG RE-ACCELERATION AFTER HEALTHY EMA9 RESET";

                        LogMovePhase(
                            true,
                            rangeNyTime,
                            "PREMARKET_SECOND_LEG",
                            longScore,
                            shortScore,
                            longEmaExtensionTicks,
                            sessionUpMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "SECOND LEG RE-ACCELERATION | FINAL AUTHORITY REQUIRED"
                        );
                    }
                    else if (breakoutContinuationLong)
                    {
                        momentumEntryRoute = "BREAKOUT_CONTINUATION";
                        momentumEntryRouteReason =
                            "MATURE + REAL BREAKOUT + LIVE DISPLACEMENT + ACCEPTANCE";

                        LogMovePhase(
                            true,
                            rangeNyTime,
                            "MATURE_BREAKOUT_CONTINUATION",
                            longScore,
                            shortScore,
                            longEmaExtensionTicks,
                            sessionUpMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "BREAKOUT_CONTINUATION | FINAL AUTHORITY REQUIRED"
                        );
                    }
                    else
                    {
                        double breakoutLevel =
                            GetHighestHigh(
                                bars,
                                Math.Max(
                                    0,
                                    closedBarIndex -
                                        MomentumBreakoutLookback
                                ),
                                closedBarIndex - 1
                            );

                        ArmSmartRetest(
                            true,
                            rangeNyTime,
                            breakoutLevel,
                            m5BullishBreakLevel,
                            rangeClose,
                            longScore,
                            "MOVE PHASE " + longMovePhase + " LONG"
                        );

                        LogMovePhase(
                            true,
                            rangeNyTime,
                            longMovePhase,
                            longScore,
                            shortScore,
                            longEmaExtensionTicks,
                            sessionUpMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "WAIT SMART RETEST"
                        );

                        rawLongReady = false;
                    }
                }
                else if (longMovePhase == "DEVELOPING")
                {
                    if (weightedLongAuthority)
                    {
                        LogWeightedExecutionAuthority(
                            true,
                            rangeNyTime,
                            weightedLongScore,
                            weightedLongSummary,
                            "DEVELOPING MOVE -> DIRECT EXECUTION ELIGIBLE"
                        );

                        LogMovePhase(
                            true,
                            rangeNyTime,
                            "DEVELOPING_EDGE_AUTHORITY",
                            longScore,
                            shortScore,
                            longEmaExtensionTicks,
                            sessionUpMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "UNIFIED EDGE AUTHORITY / LEGACY CONTEXT IS WEIGHT ONLY"
                        );
                    }
                    else
                    {
                        LogMovePhase(
                            true,
                            rangeNyTime,
                            longMovePhase,
                            longScore,
                            shortScore,
                            longEmaExtensionTicks,
                            sessionUpMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "WAIT CONFIRMATION"
                        );

                        rawLongReady = false;
                    }
                }
                else
                {
                    LogMovePhase(
                        true,
                        rangeNyTime,
                        longMovePhase,
                        longScore,
                        shortScore,
                        longEmaExtensionTicks,
                        sessionUpMoveTicks,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        "DIRECT ENTRY ALLOWED"
                    );
                }
            }

            if (rawShortReady && momentumTickSize > 0)
            {
                double shortEmaExtensionTicks =
                    Math.Max(
                        0,
                        (emaFastCurrent - rangeClose) /
                            momentumTickSize
                    );

                string shortMovePhase =
                    EvaluateMovePhase(
                        false,
                        shortScore,
                        longScore,
                        lowBreakout,
                        aggressiveShortExpansion,
                        aggressiveShortDisplacementTicks,
                        shortEmaExtensionTicks,
                        sessionDownMoveTicks,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks
                    );

                recorderShortMovePhase = shortMovePhase;

                if (
                    shortMovePhase == "MATURE" ||
                    shortMovePhase == "EXHAUSTION"
                )
                {
                    // V1.6.51 - FRESH CONTINUATION OVERRIDE
                    // Same logic as LONG, mirrored for a fresh bearish leg.
                    // SessionMove / EMA extension alone may not turn a live
                    // opening displacement into a mandatory Smart Retest.
                    string freshContinuationFlowSummary;
                    bool freshContinuationFlow =
                        TryGetEarlyAggressionFlowSupport(
                            false,
                            out freshContinuationFlowSummary
                        );

                    bool freshContinuationOverride =
                        shortMovePhase == "MATURE" &&
                        openingPriority &&
                        lowBreakout &&
                        shortScore >= 4 &&
                        longScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.75 &&
                        slopeTicks <= -3.0 &&
                        (
                            aggressiveShortExpansion ||
                            aggressiveShortDisplacementTicks >=
                                AggressionMinDisplacementTicks
                        ) &&
                        freshContinuationFlow;

                    // V1.6.58 - Mirrored exceptional MATURE bypass for SHORT.
                    // Only a fresh commitment with a real low breakout, 4/5+
                    // impulse and acceptable EMA9 extension may skip Smart Retest.
                    string shortCommitmentSummary;
                    bool shortCommitmentActive =
                        IsExceptionalCommitmentActive(
                            false, rangeNyTime, out shortCommitmentSummary
                        );
                    string shortOpposedSummary = string.Empty;
                    bool shortStronglyOpposed =
                        shortCommitmentActive &&
                        IsInitialEntryLevel2StronglyOpposed(
                            false, out shortOpposedSummary
                        );
                    bool exceptionalMatureDirectShort =
                        shortMovePhase == "MATURE" &&
                        shortCommitmentActive &&
                        !shortStronglyOpposed &&
                        !HasConfirmedOpposingAbsorption(false) &&
                        lowBreakout &&
                        shortScore >= 4 &&
                        longScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.75 &&
                        slopeTicks <= -3.0 &&
                        shortEmaExtensionTicks <=
                            FreshMomentumGraceMaxExtensionTicks;

                    bool breakoutContinuationShort =
                        shortMovePhase == "MATURE" &&
                        lowBreakout &&
                        shortScore >= 4 &&
                        longScore <= 1 &&
                        aggressiveShortExpansion &&
                        volumeRatio >= 1.25 &&
                        bodyRatio >= 0.68 &&
                        slopeTicks <= -3.0 &&
                        freshContinuationFlow &&
                        !HasConfirmedOpposingAbsorption(false) &&
                        shortEmaExtensionTicks <= FreshMomentumGraceMaxExtensionTicks;

                    // V1.6.81 - PREMARKET SECOND-LEG RE-ACCELERATION (SHORT)
                    // Mirror LONG: a mature session move can re-enter eligibility
                    // after EMA9 extension resets and fresh bearish order-flow
                    // confirms a new leg. Final Entry Authority remains mandatory.
                    bool premarketSecondLegShort =
                        shortMovePhase == "MATURE" &&
                        premarketSession &&
                        premarketEarlyShortAggression &&
                        weightedShortAuthority &&
                        lowBreakout &&
                        shortScore >= 4 &&
                        longScore <= 1 &&
                        volumeRatio >= 1.50 &&
                        bodyRatio >= 0.60 &&
                        slopeTicks <= -3.0 &&
                        shortEmaExtensionTicks <= 40.0 &&
                        !HasConfirmedOpposingAbsorption(false);

                    if (premarketSecondLegShort)
                    {
                        momentumEntryRoute = "BREAKOUT_CONTINUATION";
                        momentumEntryRouteReason =
                            "PREMARKET_SECOND_LEG | SECOND LEG RE-ACCELERATION AFTER HEALTHY EMA9 RESET";

                        LogMovePhase(
                            false,
                            rangeNyTime,
                            "PREMARKET_SECOND_LEG",
                            shortScore,
                            longScore,
                            shortEmaExtensionTicks,
                            sessionDownMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "SECOND LEG RE-ACCELERATION | FINAL AUTHORITY REQUIRED"
                        );
                    }
                    else if (breakoutContinuationShort)
                    {
                        momentumEntryRoute = "BREAKOUT_CONTINUATION";
                        momentumEntryRouteReason =
                            "MATURE + REAL BREAKOUT + LIVE DISPLACEMENT + ACCEPTANCE";

                        LogMovePhase(
                            false,
                            rangeNyTime,
                            "MATURE_BREAKOUT_CONTINUATION",
                            shortScore,
                            longScore,
                            shortEmaExtensionTicks,
                            sessionDownMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "BREAKOUT_CONTINUATION | FINAL AUTHORITY REQUIRED"
                        );
                    }
                    else
                    {
                        double breakoutLevel =
                            GetLowestLow(
                                bars,
                                Math.Max(
                                    0,
                                    closedBarIndex -
                                        MomentumBreakoutLookback
                                ),
                                closedBarIndex - 1
                            );

                        ArmSmartRetest(
                            false,
                            rangeNyTime,
                            breakoutLevel,
                            m5BearishBreakLevel,
                            rangeClose,
                            shortScore,
                            "MOVE PHASE " + shortMovePhase + " SHORT"
                        );

                        LogMovePhase(
                            false,
                            rangeNyTime,
                            shortMovePhase,
                            shortScore,
                            longScore,
                            shortEmaExtensionTicks,
                            sessionDownMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "WAIT SMART RETEST"
                        );

                        rawShortReady = false;
                    }
                }
                else if (shortMovePhase == "DEVELOPING")
                {
                    if (weightedShortAuthority)
                    {
                        LogWeightedExecutionAuthority(
                            false,
                            rangeNyTime,
                            weightedShortScore,
                            weightedShortSummary,
                            "DEVELOPING MOVE -> DIRECT EXECUTION ELIGIBLE"
                        );

                        LogMovePhase(
                            false,
                            rangeNyTime,
                            "DEVELOPING_EDGE_AUTHORITY",
                            shortScore,
                            longScore,
                            shortEmaExtensionTicks,
                            sessionDownMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "UNIFIED EDGE AUTHORITY / LEGACY CONTEXT IS WEIGHT ONLY"
                        );
                    }
                    else
                    {
                        LogMovePhase(
                            false,
                            rangeNyTime,
                            shortMovePhase,
                            shortScore,
                            longScore,
                            shortEmaExtensionTicks,
                            sessionDownMoveTicks,
                            volumeRatio,
                            bodyRatio,
                            slopeTicks,
                            "WAIT CONFIRMATION"
                        );

                        rawShortReady = false;
                    }
                }
                else
                {
                    LogMovePhase(
                        false,
                        rangeNyTime,
                        shortMovePhase,
                        shortScore,
                        longScore,
                        shortEmaExtensionTicks,
                        sessionDownMoveTicks,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        "DIRECT ENTRY ALLOWED"
                    );
                }
            }

            // A pending setup may now be confirmed even though the original
            // breakout bar is gone. This is the actual pullback-entry layer.
            bool smartRetestLong = false;
            bool smartRetestShort = false;
            string smartRetestPattern = string.Empty;
            string smartRetestStructureSetupKey = string.Empty;

            bool smartRetestWasPending =
                pendingSmartRetestActive;

            bool smartRetestPendingWasLong =
                pendingSmartRetestIsLong;

            TryConfirmSmartRetest(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                rangeClose,
                longScore,
                shortScore,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                out smartRetestLong,
                out smartRetestShort,
                out smartRetestPattern,
                out smartRetestStructureSetupKey
            );

            // V1.6.30 - RETEST QUARANTINE.
            // Once anti-chase/mature-move protection arms a Smart Retest,
            // Opening fallback cannot bypass it on a later callback simply
            // because price is back inside the chase threshold.
            if (
                smartRetestWasPending &&
                !smartRetestLong &&
                !smartRetestShort
            )
            {
                if (smartRetestPendingWasLong)
                    rawLongReady = false;
                else
                    rawShortReady = false;
            }

            if (smartRetestLong)
            {
                rawLongReady = true;
                rawShortReady = false;
                PrintSmartRetestConfirmed(true, rangeNyTime, smartRetestPattern, rangeClose, longScore);
            }
            else if (smartRetestShort)
            {
                rawShortReady = true;
                rawLongReady = false;
                PrintSmartRetestConfirmed(false, rangeNyTime, smartRetestPattern, rangeClose, shortScore);
            }

            // =====================================================
            // JJ HYBRID IMPULSE QUALIFIER V2 - LIVE LEVEL 2 + DELTA + ASIA
            // =====================================================
            // HYBRID direct Range-20 entries must represent a fresh,
            // directional impulse, not a direction-only continuation or
            // a late large candle. Structure/Opening live in their own
            // engines. Exceptionally confirmed live Level-II authority
            // and a newly confirmed Smart Retest retain their original
            // paths; this guard does not create an entry on its own.
            if (IsHybridFamilyMode())
            {
                bool asiaImpulseSession = IsAsiaSession(rangeNyTime);
                string longFlowSummary;
                string shortFlowSummary;
                bool longFlow = TryGetHybridImpulseLiveFlow(true, out longFlowSummary);
                bool shortFlow = TryGetHybridImpulseLiveFlow(false, out shortFlowSummary);

                // Asia: no blind price-only impulse when real order flow is missing.
                // NY: keep the proven price-only fallback if L2 is unavailable,
                // but veto direct impulses when a fresh opposing L2 snapshot exists.
                bool validLiveBook;
                lock (level2Sync)
                {
                    validLiveBook = level2ObserveActive && level2BookReady &&
                        level2LastCalcUtc != DateTime.MinValue &&
                        (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds <= 2.0 &&
                        level2SpreadTicks > 0.0 && level2SpreadTicks <= 4.0 &&
                        level2TapeTrades >= 12;
                }
                bool impulseLong =
                    highBreakout &&
                    longScore >= (asiaImpulseSession ? 4 : 3) &&
                    shortScore <= 1 &&
                    slopeTicks >= 2.0 &&
                    bodyRatio >= (asiaImpulseSession ? 0.65 : 0.62) &&
                    volumeRatio >= (asiaImpulseSession ? 1.20 : 1.15) &&
                    rangeRatio >= (asiaImpulseSession ? 1.15 : 1.10) &&
                    (
                        aggressiveLongExpansion ||
                        (
                            extremeLongMomentum &&
                            volumeRatio >= 1.20
                        ) ||
                        (
                            longScore >= 4 &&
                            volumeRatio >= 1.35 &&
                            bodyRatio >= 0.70
                        )
                    ) &&
                    !HasConfirmedOpposingAbsorption(true);

                bool impulseShort =
                    lowBreakout &&
                    shortScore >= (asiaImpulseSession ? 4 : 3) &&
                    longScore <= 1 &&
                    slopeTicks <= -2.0 &&
                    bodyRatio >= (asiaImpulseSession ? 0.65 : 0.62) &&
                    volumeRatio >= (asiaImpulseSession ? 1.20 : 1.15) &&
                    rangeRatio >= (asiaImpulseSession ? 1.15 : 1.10) &&
                    (
                        aggressiveShortExpansion ||
                        (
                            extremeShortMomentum &&
                            volumeRatio >= 1.20
                        ) ||
                        (
                            shortScore >= 4 &&
                            volumeRatio >= 1.35 &&
                            bodyRatio >= 0.70
                        )
                    ) &&
                    !HasConfirmedOpposingAbsorption(false);

                bool preserveLong =
                    smartRetestLong ||
                    exceptionalMicrostructureLong ||
                    absorptionReversalLong;

                bool preserveShort =
                    smartRetestShort ||
                    exceptionalMicrostructureShort ||
                    absorptionReversalShort;

                // A live order-flow contradiction is relevant even for a strong
                // price bar. Confirmed absorption reversals remain separate setups;
                // the final execution gate still rechecks fresh flow in Asia.
                if (rawLongReady && !preserveLong &&
                    (asiaImpulseSession || validLiveBook) && !longFlow)
                    rawLongReady = false;

                if (rawShortReady && !preserveShort &&
                    (asiaImpulseSession || validLiveBook) && !shortFlow)
                    rawShortReady = false;

                if (rawLongReady && !impulseLong && !preserveLong)
                {
                    rawLongReady = false;
                    // Passive: the existing Shadow recorder still captures
                    // the rejected setup for comparison in Playback.
                }
                if (rawShortReady && !impulseShort && !preserveShort)
                {
                    rawShortReady = false;
                }
            }

            // =====================================================
            // V1.6.18 - SHADOW SIGNAL DATASET
            // =====================================================
            // Capture meaningful candidates even when a later guard rejects
            // the trade. This is intentionally observational only.
            bool shadowLongCandidate =
                longScore >= MomentumMinScore ||
                extremeLongMomentum ||
                aggressiveLongExpansion ||
                highBreakout ||
                smartRetestLong;

            bool shadowShortCandidate =
                shortScore >= MomentumMinScore ||
                extremeShortMomentum ||
                aggressiveShortExpansion ||
                lowBreakout ||
                smartRetestShort;

            string shadowLongId = string.Empty;
            string shadowShortId = string.Empty;

            if (shadowLongCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    true,
                    longScore,
                    aggressiveLongExpansion,
                    extremeLongMomentum,
                    smartRetestLong,
                    highBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfLongScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        true,
                        rawLongReady,
                        allowLong,
                        premarketSession,
                        m5AboveVwap,
                        m5Bullish,
                        strictMiddayMomentum,
                        longScore,
                        htfLongScore,
                        aggressiveLongExpansion,
                        sessionUpMoveTicks,
                        weakCurrentExpansion
                    );

                shadowLongId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        true,
                        momentumSession,
                        rawLongReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        longScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        highBreakout,
                        aggressiveLongScore,
                        aggressiveLongExpansion,
                        extremeLongMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfLongScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            if (shadowShortCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    false,
                    shortScore,
                    aggressiveShortExpansion,
                    extremeShortMomentum,
                    smartRetestShort,
                    lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfShortScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        false,
                        rawShortReady,
                        allowShort,
                        premarketSession,
                        m5BelowVwap,
                        m5Bearish,
                        strictMiddayMomentum,
                        shortScore,
                        htfShortScore,
                        aggressiveShortExpansion,
                        sessionDownMoveTicks,
                        weakCurrentExpansion
                    );

                shadowShortId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        false,
                        momentumSession,
                        rawShortReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        shortScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        lowBreakout,
                        aggressiveShortScore,
                        aggressiveShortExpansion,
                        extremeShortMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfShortScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            // =====================================================
            // V1.6.52 - FRESH FLOW CONFLICT VETO
            // =====================================================
            // Do not allow a price/R20 candidate to fire into exceptionally
            // strong fresh opposite aggression. This is the protection that
            // keeps earlier capture from becoming "enter every breakout".
            // It does not require flow alignment for ordinary trades; it only
            // vetoes a clearly contradictory tape/aggression snapshot.
            if (rawLongReady || rawShortReady)
            {
                bool candidateIsLong = rawLongReady;
                bool unifiedAuthorityActive =
                    candidateIsLong
                        ? (weightedLongAuthority && !weightedShortAuthority)
                        : (weightedShortAuthority && !weightedLongAuthority);
                bool flowAligned;
                bool flowStronglyOpposed;
                string flowAuthoritySummary;

                GetFreshDirectionalFlowAuthority(
                    candidateIsLong,
                    out flowAligned,
                    out flowStronglyOpposed,
                    out flowAuthoritySummary
                );

                // V1.6.63 - Unified Edge is the primary Momentum authority.
                // The flow helper now reserves stronglyOpposed for a true
                // multi-factor contradiction (not absorption by itself), so a
                // Unified candidate may only be vetoed by that catastrophic
                // opposite-flow state.
                if (flowStronglyOpposed)
                {
                    string flowVetoKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|"
                        + (candidateIsLong ? "LONG" : "SHORT");

                    if (flowVetoKey != lastFreshFlowConflictLogKey)
                    {
                        lastFreshFlowConflictLogKey = flowVetoKey;
                        PrintBotMessage(
                            "ENTRY FLOW CONFLICT VETO"
                            + " | Side: " + (candidateIsLong ? "LONG" : "SHORT")
                            + " | R20: " + (candidateIsLong ? longScore : shortScore) + "/5"
                            + " | " + flowAuthoritySummary
                            + " | UnifiedAuthority: " + (unifiedAuthorityActive ? "YES" : "NO")
                            + " | Action: HARD MULTI-FACTOR FLOW CONTRADICTION / WAIT RE-ALIGN"
                        );
                    }

                    rawLongReady = false;
                    rawShortReady = false;
                }
            }

            // =====================================================
            // V1.6.15A - LIVE ANALYSIS CONFIDENCE
            // =====================================================
            // Keep an advisory percentage alive while the bot is still
            // analyzing. This does NOT authorize or block entries.
            if (
                !rawLongReady &&
                !rawShortReady
            )
            {
                bool analysisIsLong;

                if (
                    string.Equals(
                        autoResolvedDirection,
                        "LONG ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = true;
                }
                else if (
                    string.Equals(
                        autoResolvedDirection,
                        "SHORT ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = false;
                }
                else
                {
                    analysisIsLong =
                        longScore >= shortScore;
                }

                int analysisConfidence;
                string analysisQuality;
                string analysisTiming;
                string analysisManipulation;
                string analysisReason;

                EvaluateNasdaqSetupQuality(
                    analysisIsLong,
                    analysisIsLong
                        ? longScore
                        : shortScore,
                    analysisIsLong
                        ? aggressiveLongExpansion
                        : aggressiveShortExpansion,
                    analysisIsLong
                        ? extremeLongMomentum
                        : extremeShortMomentum,
                    false,
                    analysisIsLong
                        ? highBreakout
                        : lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    analysisIsLong
                        ? htfLongScore
                        : htfShortScore,
                    out analysisConfidence,
                    out analysisQuality,
                    out analysisTiming,
                    out analysisManipulation,
                    out analysisReason
                );

                latestSetupConfidence =
                    analysisConfidence;

                latestSetupQuality =
                    analysisConfidence >= 70
                        ? analysisQuality
                        : "ANALYZING";

                latestSetupTiming =
                    "ANALYZING";

                latestManipulationState =
                    analysisManipulation;

                RecordOpeningR20Decision(
                    rangeNyTime,
                    rangeClose,
                    longScore,
                    shortScore,
                    highBreakout,
                    lowBreakout,
                    rangeRatio,
                    volumeRatio,
                    bodyRatio,
                    slopeTicks,
                    aggressiveLongExpansion,
                    aggressiveShortExpansion,
                    extremeLongMomentum,
                    extremeShortMomentum,
                    recorderLongMovePhase,
                    recorderShortMovePhase,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    rawLongReady,
                    rawShortReady,
                    analysisConfidence,
                    analysisQuality,
                    analysisTiming,
                    analysisManipulation,
                    "WAIT",
                    analysisReason
                );

                return;
            }

            bool selectedAggressiveExpansion =
                rawLongReady
                    ? aggressiveLongExpansion
                    : aggressiveShortExpansion;

            if (selectedAggressiveExpansion)
            {
                string aggressionLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT");

                if (
                    aggressionLogKey !=
                        lastAggressionSignalLogKey
                )
                {
                    lastAggressionSignalLogKey =
                        aggressionLogKey;

                    PrintBotMessage(
                        "AGGRESSIVE EXPANSION DETECTED"
                        + " | Side: "
                        + (rawLongReady ? "LONG" : "SHORT")
                        + " | Aggression: "
                        + (
                            rawLongReady
                                ? aggressiveLongScore
                                : aggressiveShortScore
                          )
                        + "/5"
                        + " | R20: "
                        + (
                            rawLongReady
                                ? longScore
                                : shortScore
                          )
                        + "/5"
                        + " | Displacement: "
                        + (
                            rawLongReady
                                ? aggressiveLongDisplacementTicks
                                : aggressiveShortDisplacementTicks
                          ).ToString("0")
                        + "t"
                        + " | Range x"
                        + rangeRatio.ToString("0.00")
                        + " | Volume x"
                        + volumeRatio.ToString("0.00")
                        + " | Body "
                        + (bodyRatio * 100.0).ToString("0")
                        + "%"
                        + " | EMA Slope "
                        + slopeTicks.ToString("0.0")
                        + "t"
                    );
                }
            }

            bool selectedAbsorptionReversal =
                rawLongReady ? absorptionReversalLong : absorptionReversalShort;

            if (selectedAbsorptionReversal)
            {
                PrintBotMessage(
                    "ABSORPTION REVERSAL ENTRY WINDOW"
                    + " | Side: " + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20: " + (rawLongReady ? longScore : shortScore) + "/5"
                    + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                    + " | Slope " + slopeTicks.ToString("0.0") + "t"
                    + " | " + (rawLongReady ? absorptionLongSummary : absorptionShortSummary)
                    + " | Action: CONFIRMED TRAPPED TRADERS / ENTRY ELIGIBLE"
                );
            }

            bool highConvictionMomentum =
                selectedAggressiveExpansion ||
                exceptionalMicrostructureLong ||
                exceptionalMicrostructureShort ||
                absorptionReversalLong ||
                absorptionReversalShort ||
                liquidityBreakLongSignal ||
                liquidityBreakShortSignal ||
                (
                rawLongReady
                    ? (
                        (
                            premarketSession &&
                            premarketExtremeLong
                        ) ||
                        extremeLongMomentum ||
                        (
                            longScore >= 4 &&
                            highBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                    : (
                        (
                            premarketSession &&
                            premarketExtremeShort
                        ) ||
                        extremeShortMomentum ||
                        (
                            shortScore >= 4 &&
                            lowBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                );

            bool effectiveExtremeMomentum =
                premarketSession
                    ? (
                        rawLongReady
                            ? premarketExtremeLong
                            : premarketExtremeShort
                      )
                    : (
                        rawLongReady
                            ? extremeLongMomentum
                            : extremeShortMomentum
                      );

            // =====================================================
            // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE
            // =====================================================
            int setupConfidence;
            string setupQuality;
            string setupTiming;
            string manipulationState;
            string setupQualityReason;

            EvaluateNasdaqSetupQuality(
                rawLongReady,
                rawLongReady ? longScore : shortScore,
                selectedAggressiveExpansion,
                effectiveExtremeMomentum,
                !string.IsNullOrWhiteSpace(smartRetestPattern),
                rawLongReady ? highBreakout : lowBreakout,
                bodyRatio,
                volumeRatio,
                slopeTicks,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                m5Structure,
                m5Liquidity,
                rawLongReady ? htfLongScore : htfShortScore,
                out setupConfidence,
                out setupQuality,
                out setupTiming,
                out manipulationState,
                out setupQualityReason
            );

            latestSetupConfidence =
                setupConfidence;
            latestSetupQuality =
                setupQuality;
            latestSetupTiming =
                setupTiming;
            latestManipulationState =
                manipulationState;

            RecordOpeningR20Decision(
                rangeNyTime,
                rangeClose,
                longScore,
                shortScore,
                highBreakout,
                lowBreakout,
                rangeRatio,
                volumeRatio,
                bodyRatio,
                slopeTicks,
                aggressiveLongExpansion,
                aggressiveShortExpansion,
                extremeLongMomentum,
                extremeShortMomentum,
                recorderLongMovePhase,
                recorderShortMovePhase,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                m5Structure,
                m5Liquidity,
                rawLongReady,
                rawShortReady,
                setupConfidence,
                setupQuality,
                setupTiming,
                manipulationState,
                rawLongReady ? "ELIGIBLE_LONG" : "ELIGIBLE_SHORT",
                setupQualityReason
            );

            string setupQualityLogKey =
                closedRangeTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + setupConfidence
                + "|"
                + setupQuality
                + "|"
                + setupTiming
                + "|"
                + manipulationState;

            if (
                setupQualityLogKey !=
                    lastSetupQualityLogKey
            )
            {
                lastSetupQualityLogKey =
                    setupQualityLogKey;

                PrintBotMessage(
                    "SETUP QUALITY"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | "
                    + setupQuality
                    + " | Confidence: "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                    + " | "
                    + setupQualityReason
                );
            }

            currentSetupState =
                setupQuality
                + " "
                + setupConfidence
                + "% | "
                + setupTiming;

            string learningContext =
                (
                    !string.IsNullOrWhiteSpace(smartRetestPattern)
                        ? "SMART RETEST " + smartRetestPattern + " "
                        : (rawLongReady ? absorptionReversalLong : absorptionReversalShort)
                        ? "ABSORPTION REVERSAL "
                        : selectedAggressiveExpansion
                        ? (
                            premarketSession
                                ? "PREMARKET AGGRESSIVE EXPANSION "
                                : "R20 AGGRESSIVE EXPANSION "
                          )
                        : (
                            premarketSession
                                ? (
                                    effectiveExtremeMomentum
                                        ? "PREMARKET R20 EXTREME MOMENTUM "
                                        : "PREMARKET R20 MOMENTUM "
                                  )
                                : (
                                    effectiveExtremeMomentum
                                        ? "R20 EXTREME MOMENTUM "
                                        : "R20 MOMENTUM "
                                  )
                          )
                )
                + (
                    rawLongReady
                        ? longScore
                        : shortScore
                )
                + "/5";

            string learningReason;

            bool learningAllowed =
                IsLearningTradeAllowed(
                    rawLongReady
                        ? "LONG"
                        : "SHORT",
                    rangeNyTime,
                    learningContext,
                    out learningReason
                );

            DateTime closedRangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            string rangeSignalLogKey =
                closedRangeTime.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + (rawLongReady ? longScore : shortScore);

            if (rangeSignalLogKey != lastRangeSignalLogKey)
            {
                lastRangeSignalLogKey = rangeSignalLogKey;

                PrintBotMessage(
                    "RANGE MOMENTUM SIGNAL"
                    + (
                        premarketSession
                            ? " | PREMARKET"
                            : (
                                openingPriority
                                    ? " | OPENING FALLBACK"
                                    : string.Empty
                              )
                      )
                    + " | Bar: "
                    + closedRangeNyTime.ToString("HH:mm:ss")
                    + " ET"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20 Score: "
                    + (rawLongReady ? longScore : shortScore)
                    + "/5"
                    + " | M5 Trend: "
                    + (
                        m5Bullish
                            ? "BULLISH"
                            : m5Bearish
                                ? "BEARISH"
                                : "NEUTRAL"
                    )
                    + " | M5 VWAP: "
                    + (
                        m5AboveVwap
                            ? "ABOVE"
                            : m5BelowVwap
                                ? "BELOW"
                                : "AT"
                    )
                    + " | M5 Structure: "
                    + m5Structure
                    + " | Quality: "
                    + setupQuality
                    + " "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                );
            }

            bool explosionAuthorityActive =
                rawLongReady
                    ? (weightedLongAuthority && !weightedShortAuthority)
                    : (weightedShortAuthority && !weightedLongAuthority);

            // V1.6.64 - In Explosion Mode, Learning observes outcomes but
            // cannot veto a live explosion that already passed the current
            // microstructure authority. Historical buckets are no longer an
            // entry engine.
            if (!learningAllowed && !explosionAuthorityActive)
            {
                // =====================================================
                // V1.6.54 - FRESH IGNITION AUTHORITY OVER LEARNING
                // =====================================================
                // Learning remains authoritative for ordinary/late setups, but
                // it may not kill a genuinely fresh 4/5 ignition simply because
                // the historical bucket is weak. The 2026-09-08 session showed
                // that doing so can reject the best early signal and later allow
                // a degraded 3/5 tail entry. This override is deliberately narrow:
                // real breakout, strong candle, normal+ participation, strong
                // slope, high-conviction price path, and NO strongly-opposed L2.
                int authorityScore = rawLongReady ? longScore : shortScore;
                bool authorityBreakout = rawLongReady ? highBreakout : lowBreakout;
                bool authoritySlope = rawLongReady ? slopeTicks >= 4.0 : slopeTicks <= -4.0;
                string authorityOpposedSummary;
                bool authorityFlowOpposed =
                    IsInitialEntryLevel2StronglyOpposed(
                        rawLongReady,
                        out authorityOpposedSummary
                    );

                bool freshIgnitionLearningOverride =
                    authorityScore >= 4 &&
                    authorityBreakout &&
                    bodyRatio >= 0.68 &&
                    volumeRatio >= 1.15 &&
                    authoritySlope &&
                    highConvictionMomentum &&
                    !authorityFlowOpposed;

                if (freshIgnitionLearningOverride)
                {
                    PrintBotMessage(
                        "LEARNING FRESH IGNITION OVERRIDE"
                        + " | Side: " + (rawLongReady ? "LONG" : "SHORT")
                        + " | R20: " + authorityScore + "/5"
                        + " | Vol x" + volumeRatio.ToString("0.00")
                        + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                        + " | Slope " + slopeTicks.ToString("0.0") + "t"
                        + " | Breakout: YES"
                        + " | Learning: " + learningReason
                        + " | L2Opposed: NO"
                        + " | Action: BLOCK -> CAUTION / KEEP EARLY ENTRY ELIGIBLE"
                    );

                    UpdateShadowSignalDecision(
                        rawLongReady ? shadowLongId : shadowShortId,
                        "LEARNING_CAUTION_OVERRIDE",
                        "FRESH 4/5 IGNITION + NO STRONG OPPOSING FLOW"
                    );
                }
                else
                {
                    UpdateShadowSignalDecision(
                        rawLongReady
                            ? shadowLongId
                            : shadowShortId,
                        "LEARNING_BLOCKED",
                        learningReason
                    );

                    string learningBlockedLogKey =
                        closedRangeTime.ToString(
                            "yyyyMMddHHmmss"
                        )
                        + "|"
                        + (rawLongReady ? "LONG" : "SHORT")
                        + "|"
                        + learningContext
                        + "|"
                        + learningReason;

                    if (
                        learningBlockedLogKey !=
                            lastLearningBlockedLogKey
                    )
                    {
                        lastLearningBlockedLogKey =
                            learningBlockedLogKey;

                        PrintBotMessage(
                            "LEARNING BLOCK RANGE"
                            + " | Bar: "
                            + closedRangeNyTime.ToString(
                                "HH:mm:ss"
                            )
                            + " ET"
                            + " | "
                            + learningReason
                        );
                    }

                    return;
                }
            }

            lastLearningBlockedLogKey =
                string.Empty;

            // =====================================================
            // V1.6.63 - NO DEGRADED / LATE 3/5 RESURRECTION (LEGACY ONLY)
            // =====================================================
            // Outside the dedicated Premarket/Opening engines, an ordinary 3/5
            // Momentum signal may not enter merely because an earlier 4/5 impulse
            // was missed. It must either still belong to the tiny fresh-trigger
            // window with confirmed continuation flow, or prove itself as a NEW
            // clean 3/5 breakout with stronger participation. This prevents the
            // exact 4/5 EARLY -> wait -> 3/5 DEVELOPING/Aggression NO -> SL pattern.
            int selectedScore = rawLongReady ? longScore : shortScore;
            bool selectedBreakout = rawLongReady ? highBreakout : lowBreakout;

            if (
                selectedScore == 3 &&
                !premarketSession &&
                !openingPriority &&
                string.IsNullOrWhiteSpace(smartRetestPattern) &&
                !selectedAggressiveExpansion &&
                !(rawLongReady
                    ? (weightedLongAuthority && !weightedShortAuthority)
                    : (weightedShortAuthority && !weightedLongAuthority))
            )
            {
                DateTime selectedFreshTriggerNy =
                    rawLongReady ? freshMomentumLongTriggerNy : freshMomentumShortTriggerNy;

                double selectedFreshAgeSeconds =
                    selectedFreshTriggerNy == DateTime.MinValue
                        ? 999.0
                        : (rangeNyTime - selectedFreshTriggerNy).TotalSeconds;

                string selectedFlowSummary;
                bool selectedFreshFlow =
                    TryGetFreshMomentumContinuationFlowSupport(
                        rawLongReady,
                        out selectedFlowSummary
                    );

                bool stillSameFreshImpulse =
                    selectedFreshAgeSeconds >= 0 &&
                    selectedFreshAgeSeconds <= FreshMomentumGraceSeconds &&
                    selectedFreshFlow;

                bool newCleanThreeOfFive =
                    selectedBreakout &&
                    bodyRatio >= 0.75 &&
                    volumeRatio >= 1.05 &&
                    (rawLongReady ? slopeTicks >= 4.0 : slopeTicks <= -4.0) &&
                    selectedFreshFlow;

                if (!stillSameFreshImpulse && !newCleanThreeOfFive)
                {
                    string degradedLogKey =
                        (rawLongReady ? "LONG" : "SHORT")
                        + "|" + selectedBreakout
                        + "|" + selectedFlowSummary;

                    DateTime degradedNowUtc = DateTime.UtcNow;

                    if (
                        !string.Equals(
                            degradedLogKey,
                            lastDegradedMomentumBlockedLogKey,
                            StringComparison.Ordinal
                        ) ||
                        lastDegradedMomentumBlockedLogUtc == DateTime.MinValue ||
                        (degradedNowUtc - lastDegradedMomentumBlockedLogUtc)
                            .TotalMilliseconds >= DegradedMomentumBlockedLogThrottleMs
                    )
                    {
                        lastDegradedMomentumBlockedLogKey = degradedLogKey;
                        lastDegradedMomentumBlockedLogUtc = degradedNowUtc;

                        PrintBotMessage(
                            "DEGRADED MOMENTUM ENTRY BLOCKED"
                            + " | Side: " + (rawLongReady ? "LONG" : "SHORT")
                            + " | R20: 3/5"
                            + " | TriggerAge: " + selectedFreshAgeSeconds.ToString("0.0") + "s"
                            + " | Vol x" + volumeRatio.ToString("0.00")
                            + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                            + " | Breakout: " + (selectedBreakout ? "YES" : "NO")
                            + " | " + selectedFlowSummary
                            + " | Action: EXPIRE OLD IMPULSE / WAIT NEW EXPANSION"
                        );
                    }

                    UpdateShadowSignalDecision(
                        rawLongReady ? shadowLongId : shadowShortId,
                        "DEGRADED_SIGNAL_EXPIRED",
                        "3/5 signal did not prove fresh continuation"
                    );

                    return;
                }
            }

            CaptureLearningSignalContext(
                rawLongReady
                    ? "LONG"
                    : "SHORT",
                rangeNyTime,
                learningContext
            );

            pendingShadowSignalId =
                rawLongReady
                    ? shadowLongId
                    : shadowShortId;

            UpdateShadowSignalDecision(
                pendingShadowSignalId,
                "ENTRY_ATTEMPT",
                "PASSED SIGNAL + LEARNING GATES"
            );

            string finalEntryStrategy = "MOMENTUM";
            string finalEntryRoute = momentumEntryRoute;
            string finalEntryRouteReason = momentumEntryRouteReason;

            string fastOpenIgnitionReason = string.Empty;
            bool fastOpenCandidate =
                openingBuildLock &&
                TryEvaluateFastOpenIgnition(
                    rawLongReady,
                    rangeNyTime,
                    rangeClose,
                    out fastOpenIgnitionReason
                );

            if (fastOpenCandidate)
            {
                finalEntryStrategy = "OPENING";
                finalEntryRoute = "FAST_OPEN";
                finalEntryRouteReason = fastOpenIgnitionReason;
            }

            TrySubmitEntry(
                rawLongReady,
                closedRangeTime,
                false,
                string.IsNullOrWhiteSpace(smartRetestStructureSetupKey)
                    ? null
                    : smartRetestStructureSetupKey,
                fastOpenCandidate,
                highConvictionMomentum,
                finalEntryStrategy,
                finalEntryRoute,
                finalEntryRouteReason
            );
        }
        // =====================================================
        // V1.6.38 - BREAKOUT ACCEPTANCE WINDOW (PREMARKET + AM)
        // =====================================================
        private bool TryGetLiquidityBreakAcceptanceOverride(
            bool isLong,
            DateTime nyTime,
            double currentPrice,
            double tickSize,
            bool priceAggressionQualified,
            out string summary)
        {
            summary = "NO PENDING LIQUIDITY BREAK";

            if (
                !pendingLiquidityBreakActive ||
                pendingLiquidityBreakIsLong != isLong ||
                pendingLiquidityBreakLevel <= 0 ||
                tickSize <= 0 ||
                !priceAggressionQualified
            )
            {
                return false;
            }

            if (
                pendingLiquidityBreakArmedNy == DateTime.MinValue ||
                pendingLiquidityBreakArmedNy.Date != nyTime.Date
            )
            {
                pendingLiquidityBreakActive = false;
                pendingLiquidityBreakCrossedNy = DateTime.MinValue;
                return false;
            }

            string liquidityBreakSession =
                GetBotSessionWindow(nyTime);

            bool sessionEligible =
                IsPremarketSession(nyTime) ||
                string.Equals(
                    liquidityBreakSession,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                );

            if (!sessionEligible)
            {
                pendingLiquidityBreakActive = false;
                return false;
            }

            double crossedTicks =
                isLong
                    ? (currentPrice - pendingLiquidityBreakLevel) / tickSize
                    : (pendingLiquidityBreakLevel - currentPrice) / tickSize;

            if (crossedTicks < LiquidityBreakMinCrossTicks)
                return false;

            if (pendingLiquidityBreakCrossedNy == DateTime.MinValue)
                pendingLiquidityBreakCrossedNy = nyTime;

            double ageSeconds =
                (nyTime - pendingLiquidityBreakCrossedNy).TotalSeconds;

            if (
                ageSeconds < 0 ||
                ageSeconds > LiquidityBreakAcceptanceSeconds ||
                crossedTicks > LiquidityBreakMaxDistanceTicks
            )
            {
                if (
                    ageSeconds > LiquidityBreakAcceptanceSeconds ||
                    crossedTicks > LiquidityBreakMaxDistanceTicks
                )
                {
                    pendingLiquidityBreakActive = false;
                }
                return false;
            }

            string flowSummary;
            bool flowConfirmed =
                TryGetLiquidityBreakFlowSupport(
                    isLong,
                    out flowSummary
                );

            if (!flowConfirmed)
            {
                summary =
                    "LEVEL " + pendingLiquidityBreakLevel.ToString("0.00")
                    + " | Cross " + crossedTicks.ToString("0") + "t"
                    + " | " + flowSummary;
                return false;
            }

            summary =
                "Level " + pendingLiquidityBreakReference
                + " @ " + pendingLiquidityBreakLevel.ToString("0.00")
                + " | Cross " + crossedTicks.ToString("0") + "t"
                + " | Age " + ageSeconds.ToString("0") + "s"
                + " | " + flowSummary;

            return true;
        }

        private void CalculateMomentumScores(
            Bars bars,
            int closedBarIndex,
            double emaFastCurrent,
            out int longScore,
            out int shortScore,
            out double rangeRatio,
            out double volumeRatio,
            out double bodyRatio,
            out double emaFastSlope,
            out bool highBreakout,
            out bool lowBreakout)
        {
            longScore = 0;
            shortScore = 0;
            rangeRatio = 0;
            volumeRatio = 0;
            bodyRatio = 0;
            emaFastSlope = 0;
            highBreakout = false;
            lowBreakout = false;

            if (
                bars == null ||
                closedBarIndex <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 2
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            double high =
                bars.GetHigh(
                    closedBarIndex
                );

            double low =
                bars.GetLow(
                    closedBarIndex
                );

            double currentRange =
                Math.Max(
                    0,
                    high - low
                );

            double currentBody =
                Math.Abs(
                    close - open
                );

            bodyRatio =
                currentRange > 0
                    ? currentBody /
                        currentRange
                    : 0;

            double averageRange = 0;
            double averageVolume = 0;

            for (
                int i = closedBarIndex -
                    MomentumAverageLookback;
                i < closedBarIndex;
                i++
            )
            {
                averageRange +=
                    Math.Max(
                        0,
                        bars.GetHigh(i) -
                        bars.GetLow(i)
                    );

                averageVolume +=
                    bars.GetVolume(i);
            }

            averageRange /=
                MomentumAverageLookback;

            averageVolume /=
                MomentumAverageLookback;

            rangeRatio =
                averageRange > 0
                    ? currentRange /
                        averageRange
                    : 0;

            double currentVolume =
                bars.GetVolume(
                    closedBarIndex
                );

            volumeRatio =
                averageVolume > 0
                    ? currentVolume /
                        averageVolume
                    : 0;

            double emaFastPrevious =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex - 1
                );

            emaFastSlope =
                emaFastCurrent -
                emaFastPrevious;

            double previousHighest =
                double.MinValue;

            double previousLowest =
                double.MaxValue;

            for (
                int i = closedBarIndex -
                    MomentumBreakoutLookback;
                i < closedBarIndex;
                i++
            )
            {
                previousHighest =
                    Math.Max(
                        previousHighest,
                        bars.GetHigh(i)
                    );

                previousLowest =
                    Math.Min(
                        previousLowest,
                        bars.GetLow(i)
                    );
            }

            highBreakout =
                close > previousHighest;

            lowBreakout =
                close < previousLowest;

            bool bullishCandle =
                close > open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool bearishCandle =
                close < open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    MomentumRangeExpansion;

            bool volumeExpanded =
                volumeRatio >=
                    MomentumVolumeExpansion;

            bool emaRising =
                emaFastSlope > 0;

            bool emaFalling =
                emaFastSlope < 0;

            // Five independent components:
            // 1) strong directional body
            // 2) EMA9 slope
            // 3) range expansion
            // 4) relative volume expansion
            // 5) close breakout of recent bars
            if (bullishCandle)
                longScore++;

            if (emaRising)
                longScore++;

            if (rangeExpanded)
                longScore++;

            if (volumeExpanded)
                longScore++;

            if (highBreakout)
                longScore++;

            if (bearishCandle)
                shortScore++;

            if (emaFalling)
                shortScore++;

            if (rangeExpanded)
                shortScore++;

            if (volumeExpanded)
                shortScore++;

            if (lowBreakout)
                shortScore++;
        }

    }
}


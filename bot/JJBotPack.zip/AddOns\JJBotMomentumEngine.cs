﻿#region Using declarations
using System;
using System.Globalization;
using System.Windows.Media;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // V1.6.28 - EARLY TREND CAPTURE / PERSISTENT DIRECTION BIAS
        // Keeps a clean aligned directional read alive briefly through
        // Range/Transition noise. It is not a standalone entry trigger.
        private string persistentDirectionBias = "NONE";
        private DateTime persistentDirectionBiasUntilNy = DateTime.MinValue;
        private DateTime persistentDirectionBiasLastConfirmedNy = DateTime.MinValue;
        private const int PersistentDirectionBiasSeconds = 75;

        // V1.6.29 - short memory of a VALID aligned 3/5 impulse.
        // Allows the next 2/5 continuation to stay actionable briefly
        // instead of forgetting the impulse on the next Range callback.
        private const int PersistentMomentumContinuationSeconds = 30;

        // V1.6.31 - NY OPENING PRESSURE ENGINE.
        // Range bars are the primary discovery layer at the cash open.
        // M5/structure remain context; HTF is a soft modifier, never a hard veto.
        private string latestOpeningPressureDirection = "NEUTRAL";
        private int latestOpeningPressureConfidence = 0;
        private DateTime latestOpeningPressureNy = DateTime.MinValue;
        private string latestOpeningPressureReason = string.Empty;
        private string lastOpeningPressureLogKey = string.Empty;
        private const int OpeningPressureFreshSeconds = 90;
        private const int OpeningPressureMinDirectionalScore = 3;
        private const int OpeningPressureStrongDirectionalScore = 4;
        private const int OpeningPressureMinQualityPoints = 1;
        private const int OpeningPressureStrongQualityPoints = 2;
        private const int OpeningPressureMinConfidence = 70;
        private const int OpeningPressureStrongConfidence = 82;

        private void UpdateMomentumFromRangeBars(
            Bars bars,
            bool evaluateClosedRangeBar)
        {
            if (
                bars == null ||
                bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            int longScore;
            int shortScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaSlope;
            bool highBreakout;
            bool lowBreakout;

            CalculateMomentumScores(
                bars,
                closedBarIndex,
                emaFastCurrent,
                out longScore,
                out shortScore,
                out rangeRatio,
                out volumeRatio,
                out bodyRatio,
                out emaSlope,
                out highBreakout,
                out lowBreakout
            );

            bool bullishMomentum =
                longScore >= MomentumMinScore;

            bool bearishMomentum =
                shortScore >= MomentumMinScore;

            string momentumState =
                bullishMomentum &&
                !bearishMomentum
                    ? "BULLISH "
                        + longScore
                        + "/5"
                    : bearishMomentum &&
                        !bullishMomentum
                        ? "BEARISH "
                            + shortScore
                            + "/5"
                        : "L "
                            + longScore
                            + "/5 | S "
                            + shortScore
                            + "/5";

            lock (marketContextLock)
            {
                latestRangeLongScore =
                    longScore;
                latestRangeShortScore =
                    shortScore;
                latestRangeRatio =
                    rangeRatio;
                latestRangeVolumeRatio =
                    volumeRatio;
                latestRangeBodyRatio =
                    bodyRatio;
                latestRangeEmaSlope =
                    emaSlope;
                latestRangeHighBreakout =
                    highBreakout;
                latestRangeLowBreakout =
                    lowBreakout;
                latestRangeMomentumState =
                    momentumState;
                latestRangeClosePrice =
                    bars.GetClose(closedBarIndex);
            }

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (
                        !botRunning ||
                        momentumText == null
                    )
                    {
                        return;
                    }

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        bullishMomentum
                            ? Brushes.LimeGreen
                            : bearishMomentum
                                ? Brushes.OrangeRed
                                : Brushes.Goldenrod;
                })
            );

            if (!evaluateClosedRangeBar)
                return;

            DateTime closedRangeTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime rangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            EnsureTradingDay(
                rangeNyTime
            );

            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool m5AboveVwap;
            bool m5BelowVwap;
            string m5Structure;
            string m5Liquidity;
            int htfLongScore;
            int htfShortScore;
            double m5BullishBreakLevel;
            double m5BearishBreakLevel;

            lock (marketContextLock)
            {
                m5Ready =
                    latestM5ContextReady;
                m5Bullish =
                    latestM5BullishTrend;
                m5Bearish =
                    latestM5BearishTrend;
                m5AboveVwap =
                    latestM5AboveVwap;
                m5BelowVwap =
                    latestM5BelowVwap;
                m5Structure =
                    latestM5StructureState;

                m5Liquidity =
                    latestM5LiquidityState;

                htfLongScore =
                    latestHtfLongScore;

                htfShortScore =
                    latestHtfShortScore;
                m5BullishBreakLevel =
                    latestM5BullishStructureBreakLevel;
                m5BearishBreakLevel =
                    latestM5BearishStructureBreakLevel;
            }

            if (!m5Ready)
                return;

            bool nySessionActive =
                IsBotNySessionActive(
                    rangeNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    rangeNyTime
                );

            bool allowMomentumMode =
                activeStrategyMode == "MOMENTUM SCALP" ||
                activeStrategyMode == "HYBRID";

            bool openingPriority =
                IsOpeningPriorityActive(
                    rangeNyTime
                );

            bool openingBuildLock =
                IsOpeningBuildWindow(
                    rangeNyTime
                );

            // V1.6.2:
            // 09:30-09:35: Momentum is blocked while the opening range forms.
            // 09:35-10:00: Momentum is fallback only. If price is currently
            // presenting a valid Opening breakout, Opening gets first priority.
            double rangeClose =
                bars.GetClose(
                    closedBarIndex
                );

            double openingBuffer =
                selectedInstrument != null
                    ? selectedInstrument
                        .MasterInstrument
                        .TickSize
                        * OpeningBreakoutBufferTicks
                    : 0;

            bool openingLongCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bullish &&
                m5AboveVwap &&
                rangeClose >=
                    openingRangeHigh +
                    openingBuffer;

            bool openingShortCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bearish &&
                m5BelowVwap &&
                rangeClose <=
                    openingRangeLow -
                    openingBuffer;

            // =====================================================
            // V1.6.5 - EARLY EXTREME MOMENTUM DETECTION
            // =====================================================
            double momentumTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double slopeTicks =
                momentumTickSize > 0
                    ? emaSlope /
                        momentumTickSize
                    : 0;

            // =====================================================
            // V1.6.31 - NY OPENING PRESSURE ENGINE (RANGE PRIMARY)
            // =====================================================
            bool openingPressureWindow =
                IsOpeningBuildWindow(rangeNyTime) ||
                IsOpeningEntryWindow(rangeNyTime);

            int openingQualityPoints = 0;
            if (rangeRatio >= MomentumRangeExpansion)
                openingQualityPoints++;
            if (volumeRatio >= MomentumVolumeExpansion)
                openingQualityPoints++;

            bool openingPressureLongBase =
                openingPressureWindow &&
                longScore >= OpeningPressureMinDirectionalScore &&
                longScore >= shortScore + 2 &&
                highBreakout &&
                slopeTicks > 0 &&
                openingQualityPoints >= OpeningPressureMinQualityPoints;

            bool openingPressureShortBase =
                openingPressureWindow &&
                shortScore >= OpeningPressureMinDirectionalScore &&
                shortScore >= longScore + 2 &&
                lowBreakout &&
                slopeTicks < 0 &&
                openingQualityPoints >= OpeningPressureMinQualityPoints;

            bool htfStrongAgainstLong =
                htfShortScore >= 2 &&
                htfLongScore == 0;

            bool htfStrongAgainstShort =
                htfLongScore >= 2 &&
                htfShortScore == 0;

            // HTF is intentionally SOFT. Against a clean 2/2 HTF bias,
            // demand stronger Range evidence rather than hard-blocking.
            bool openingPressureLong =
                openingPressureLongBase &&
                (
                    !htfStrongAgainstLong ||
                    (
                        longScore >= OpeningPressureStrongDirectionalScore &&
                        openingQualityPoints >= OpeningPressureStrongQualityPoints
                    )
                );

            bool openingPressureShort =
                openingPressureShortBase &&
                (
                    !htfStrongAgainstShort ||
                    (
                        shortScore >= OpeningPressureStrongDirectionalScore &&
                        openingQualityPoints >= OpeningPressureStrongQualityPoints
                    )
                );

            if (openingPressureLong != openingPressureShort)
            {
                bool pressureIsLong = openingPressureLong;
                int directionalScore =
                    pressureIsLong
                        ? longScore
                        : shortScore;

                int oppositeScore =
                    pressureIsLong
                        ? shortScore
                        : longScore;

                int confidence =
                    50
                    + Math.Min(20, directionalScore * 5)
                    + Math.Min(10, openingQualityPoints * 5)
                    + Math.Min(8, Math.Max(0, directionalScore - oppositeScore) * 2)
                    + (bodyRatio >= 0.70 ? 4 : 0)
                    + (Math.Abs(slopeTicks) >= ExtremeMomentumMinSlopeTicks ? 4 : 0);

                bool htfAligned =
                    pressureIsLong
                        ? htfLongScore > htfShortScore
                        : htfShortScore > htfLongScore;

                bool htfOpposed =
                    pressureIsLong
                        ? htfShortScore > htfLongScore
                        : htfLongScore > htfShortScore;

                if (htfAligned)
                    confidence += 4;
                else if (htfOpposed)
                    confidence -= 4;

                confidence =
                    Math.Max(
                        0,
                        Math.Min(95, confidence)
                    );

                latestOpeningPressureDirection =
                    pressureIsLong
                        ? "LONG"
                        : "SHORT";

                latestOpeningPressureConfidence =
                    confidence;

                latestOpeningPressureNy =
                    rangeNyTime;

                latestOpeningPressureReason =
                    "R20 "
                    + directionalScore
                    + "/5 vs "
                    + oppositeScore
                    + "/5"
                    + " | Quality "
                    + openingQualityPoints
                    + "/2"
                    + " | Range x"
                    + rangeRatio.ToString("0.00")
                    + " | Vol x"
                    + volumeRatio.ToString("0.00")
                    + " | Body "
                    + (bodyRatio * 100.0).ToString("0")
                    + "%"
                    + " | HTF "
                    + htfLongScore
                    + "/"
                    + htfShortScore;

                string pressureLogKey =
                    latestOpeningPressureDirection
                    + "|"
                    + latestOpeningPressureConfidence
                    + "|"
                    + rangeNyTime.ToString("HHmmss");

                if (pressureLogKey != lastOpeningPressureLogKey)
                {
                    lastOpeningPressureLogKey =
                        pressureLogKey;

                    PrintBotMessage(
                        "NY OPEN PRESSURE"
                        + " | Direction: "
                        + latestOpeningPressureDirection
                        + " | Confidence: "
                        + latestOpeningPressureConfidence
                        + "%"
                        + " | "
                        + latestOpeningPressureReason
                    );
                }
            }
            else if (
                openingPressureWindow &&
                latestOpeningPressureNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    latestOpeningPressureNy
                ).TotalSeconds >
                    OpeningPressureFreshSeconds
            )
            {
                latestOpeningPressureDirection =
                    "NEUTRAL";
                latestOpeningPressureConfidence = 0;
                latestOpeningPressureReason =
                    "NO FRESH RANGE PRESSURE";
            }

            bool freshOpeningPressure =
                openingPressureWindow &&
                latestOpeningPressureNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    latestOpeningPressureNy
                ).TotalSeconds >= 0 &&
                (
                    rangeNyTime -
                    latestOpeningPressureNy
                ).TotalSeconds <=
                    OpeningPressureFreshSeconds;

            bool strongOpeningPressureLong =
                freshOpeningPressure &&
                string.Equals(
                    latestOpeningPressureDirection,
                    "LONG",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                latestOpeningPressureConfidence >=
                    OpeningPressureMinConfidence;

            bool strongOpeningPressureShort =
                freshOpeningPressure &&
                string.Equals(
                    latestOpeningPressureDirection,
                    "SHORT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                latestOpeningPressureConfidence >=
                    OpeningPressureMinConfidence;

            // V1.6.18 - advance previously-recorded shadow candidates using
            // only completed Range bars. This has no execution side effects.
            double completedRangeHigh = bars.GetHigh(closedBarIndex);
            double completedRangeLow = bars.GetLow(closedBarIndex);

            UpdateShadowSignalOutcomes(
                rangeNyTime,
                rangeClose,
                completedRangeHigh,
                completedRangeLow,
                momentumTickSize
            );

            // V1.6.23 Phase 7 - continue adjudicating the ORIGINAL signal
            // after a forced financial/session exit. This never submits orders.
            UpdateDeferredLearningSignalOutcomes(
                rangeNyTime,
                completedRangeHigh,
                completedRangeLow
            );

            bool extremeLongMomentum =
                longScore >=
                    ExtremeMomentumMinScore &&
                highBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    ExtremeMomentumMinSlopeTicks &&
                m5AboveVwap;

            bool extremeShortMomentum =
                shortScore >=
                    ExtremeMomentumMinScore &&
                lowBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -ExtremeMomentumMinSlopeTicks &&
                m5BelowVwap;

            // Premarket has no RTH VWAP yet, so its fast path uses the
            // completed premarket frontier + M5 direction instead.
            bool premarketRangeValid =
                premarketSession &&
                premarketRangeReady &&
                premarketRangeDateNy ==
                    rangeNyTime.Date;

            bool premarketHighBreakout =
                premarketRangeValid &&
                rangeClose >
                    premarketRangeHigh;

            bool premarketLowBreakout =
                premarketRangeValid &&
                rangeClose <
                    premarketRangeLow;

            bool premarketExtremeLong =
                premarketHighBreakout &&
                longScore >=
                    PremarketExtremeMinScore &&
                highBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    PremarketExtremeMinSlopeTicks &&
                (
                    m5Bullish ||
                    htfLongScore >= 1
                );

            bool premarketExtremeShort =
                premarketLowBreakout &&
                shortScore >=
                    PremarketExtremeMinScore &&
                lowBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -PremarketExtremeMinSlopeTicks &&
                (
                    m5Bearish ||
                    htfShortScore >= 1
                );

            bool premarketLongBias =
                premarketHighBreakout &&
                (
                    (
                        m5Bullish &&
                        longScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeLong
                );

            bool premarketShortBias =
                premarketLowBreakout &&
                (
                    (
                        m5Bearish &&
                        shortScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeShort
                );

            // =====================================================
            // V1.6.9 - FRESH AGGRESSIVE EXPANSION DETECTION
            // =====================================================
            int aggressiveLongScore;
            int aggressiveShortScore;
            int aggressiveLongDirectionalBars;
            int aggressiveShortDirectionalBars;
            double aggressiveLongDisplacementTicks;
            double aggressiveShortDisplacementTicks;

            CalculateAggressionState(
                bars,
                closedBarIndex,
                momentumTickSize,
                rangeRatio,
                volumeRatio,
                bodyRatio,
                slopeTicks,
                highBreakout,
                lowBreakout,
                out aggressiveLongScore,
                out aggressiveShortScore,
                out aggressiveLongDirectionalBars,
                out aggressiveShortDirectionalBars,
                out aggressiveLongDisplacementTicks,
                out aggressiveShortDisplacementTicks
            );

            bool aggressiveLongExpansion =
                aggressiveLongScore >= AggressionMinScore &&
                highBreakout &&
                aggressiveLongDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveLongDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketHighBreakout &&
                            (
                                m5Bullish ||
                                htfLongScore >= 1
                            )
                          )
                        : m5AboveVwap
                );

            bool aggressiveShortExpansion =
                aggressiveShortScore >= AggressionMinScore &&
                lowBreakout &&
                aggressiveShortDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveShortDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketLowBreakout &&
                            (
                                m5Bearish ||
                                htfShortScore >= 1
                            )
                          )
                        : m5BelowVwap
                );

            // V1.6.20: Aggressive expansion may resolve AUTO early only
            // when aligned with pressure or while pressure is neutral.
            // An opposite impulse is interpreted as a pullback.
            if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                aggressiveLongExpansion !=
                    aggressiveShortExpansion
            )
            {
                bool aggressiveResolveLong =
                    aggressiveLongExpansion;

                int pressureLongScore;
                int pressureShortScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out pressureLongScore,
                        out pressureShortScore
                    );

                bool counterPressure =
                    (
                        aggressiveResolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !aggressiveResolveLong &&
                        pressure == "LONG"
                    );

                if (!counterPressure)
                {
                    autoResolvedDirection =
                        aggressiveResolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoDirectionReason =
                        (
                            aggressiveResolveLong
                                ? "FRESH AGGRESSIVE EXPANSION LONG"
                                : "FRESH AGGRESSIVE EXPANSION SHORT"
                        )
                        + (
                            pressure == "NEUTRAL"
                                ? " | NEUTRAL DISCOVERY"
                                : " | ALIGNED PRESSURE"
                          );
                }
            }

            // Do not let an already over-extended Opening candidate suppress
            // a fresh Range momentum signal.
            if (openingLongCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingLongCandidate =
                        false;
                }
            }

            if (openingShortCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingShortCandidate =
                        false;
                }
            }

            bool openingCandidatePresent =
                openingLongCandidate ||
                openingShortCandidate;

            bool extremeOpeningOverride =
                openingBuildLock &&
                (
                    extremeLongMomentum ||
                    extremeShortMomentum ||
                    aggressiveLongExpansion ||
                    aggressiveShortExpansion ||
                    strongOpeningPressureLong ||
                    strongOpeningPressureShort
                );

            if (
                !nySessionActive ||
                !allowMomentumMode ||
                (
                    openingBuildLock &&
                    !extremeOpeningOverride
                ) ||
                (
                    openingCandidatePresent &&
                    !strongOpeningPressureLong &&
                    !strongOpeningPressureShort
                )
            )
            {
                return;
            }

            string effectiveRangeDirection;

            // Premarket AUTO is resolved from the premarket frontier because
            // the regular-session VWAP intentionally does not exist yet.
            if (
                premarketSession &&
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                bool premarketAutoLong =
                    premarketLongBias ||
                    aggressiveLongExpansion;

                bool premarketAutoShort =
                    premarketShortBias ||
                    aggressiveShortExpansion;

                if (
                    premarketAutoLong !=
                        premarketAutoShort
                )
                {
                    effectiveRangeDirection =
                        premarketAutoLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        aggressiveLongExpansion ||
                        aggressiveShortExpansion
                            ? (
                                premarketAutoLong
                                    ? "PREMARKET FRESH AGGRESSIVE EXPANSION LONG"
                                    : "PREMARKET FRESH AGGRESSIVE EXPANSION SHORT"
                              )
                            : (
                                premarketAutoLong
                                    ? "PREMARKET HIGH BREAKOUT + MOMENTUM"
                                    : "PREMARKET LOW BREAKOUT + MOMENTUM"
                              );
                }
                else
                {
                    effectiveRangeDirection =
                        "NONE";

                    autoResolvedDirection =
                        "NONE";

                    autoDirectionReason =
                        "PREMARKET WAITING FOR RANGE BREAKOUT";
                }
            }
            // V1.6.31 OPENING AUTO:
            // During 09:30-10:00, fresh completed Range bars own direction.
            // M5/HTF remain context, but they do not replace a strong live
            // pressure read. The 60-second execution stability guard remains.
            else if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                freshOpeningPressure &&
                (
                    strongOpeningPressureLong !=
                    strongOpeningPressureShort
                )
            )
            {
                bool resolveOpeningLong =
                    strongOpeningPressureLong;

                effectiveRangeDirection =
                    resolveOpeningLong
                        ? "LONG ONLY"
                        : "SHORT ONLY";

                autoResolvedDirection =
                    effectiveRangeDirection;

                autoDirectionReason =
                    "NY OPEN RANGE PRESSURE "
                    + (resolveOpeningLong ? "LONG" : "SHORT")
                    + " "
                    + latestOpeningPressureConfidence
                    + "%"
                    + " | "
                    + latestOpeningPressureReason;
            }
            // V1.6.20 RTH AUTO:
            // ALIGNED pressure -> preserve direct scalp entry.
            // NEUTRAL pressure -> fast impulse may discover direction.
            // COUNTER pressure -> classify as pullback; do not flip AUTO.
            else if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                (
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion ||
                    extremeLongMomentum !=
                        extremeShortMomentum
                )
            )
            {
                bool resolveLong =
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion
                        ? aggressiveLongExpansion
                        : extremeLongMomentum;

                int longPressureScore;
                int shortPressureScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out longPressureScore,
                        out shortPressureScore
                    );

                bool counterPressure =
                    (
                        resolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !resolveLong &&
                        pressure == "LONG"
                    );

                if (counterPressure)
                {
                    effectiveRangeDirection =
                        pressure == "LONG"
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        "COUNTER-PRESSURE FAST IMPULSE BLOCKED"
                        + " | Pressure: " + pressure
                        + " " + longPressureScore + "/" + shortPressureScore
                        + " | FastSide: " + (resolveLong ? "LONG" : "SHORT")
                        + " | WAIT RESUMPTION";

                    string pressureLogKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|" + pressure
                        + "|" + (resolveLong ? "LONG" : "SHORT")
                        + "|" + longPressureScore
                        + "/" + shortPressureScore;

                    if (
                        pressureLogKey !=
                            lastDirectionalPressureLogKey
                    )
                    {
                        lastDirectionalPressureLogKey =
                            pressureLogKey;

                        PrintBotMessage(
                            "COUNTER-PRESSURE MOMENTUM"
                            + " | FastSide: "
                            + (resolveLong ? "LONG" : "SHORT")
                            + " | GeneralPressure: " + pressure
                            + " | Score L/S: "
                            + longPressureScore + "/" + shortPressureScore
                            + " | Action: PULLBACK - NO COUNTER ENTRY"
                        );
                    }
                }
                else
                {
                    effectiveRangeDirection =
                        resolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    string pressureTag =
                        pressure == "NEUTRAL"
                            ? "NEUTRAL DISCOVERY"
                            : "ALIGNED PRESSURE";

                    autoDirectionReason =
                        (
                            aggressiveLongExpansion ||
                            aggressiveShortExpansion
                                ? (
                                    resolveLong
                                        ? "FRESH AGGRESSIVE EXPANSION LONG"
                                        : "FRESH AGGRESSIVE EXPANSION SHORT"
                                  )
                                : (
                                    resolveLong
                                        ? "EXTREME R20 LONG + BREAKOUT + VWAP"
                                        : "EXTREME R20 SHORT + BREAKOUT + VWAP"
                                  )
                        )
                        + " | " + pressureTag
                        + " " + longPressureScore + "/" + shortPressureScore;
                }
            }
            else
            {
                effectiveRangeDirection =
                    ResolveEffectiveDirection(
                        rangeNyTime,
                        rangeClose,
                        m5Bullish,
                        m5Bearish,
                        m5AboveVwap,
                        m5BelowVwap
                    );
            }

            bool allowLong =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "LONG ONLY";

            bool allowShort =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "SHORT ONLY";

            string momentumSession =
                GetBotSessionWindow(
                    rangeNyTime
                );

            bool strictMiddayMomentum =
                string.Equals(
                    momentumSession,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            // =====================================================
            // V1.6.28 - EARLY TREND CAPTURE V1
            // =====================================================
            // 3/5 may enter early only when M5 + VWAP + breakout are aligned.
            // A plain 3/5 against confirmed M5 is not allowed.
            bool earlyAlignedLong =
                !premarketSession &&
                allowLong &&
                m5Bullish &&
                m5AboveVwap &&
                longScore >= 3 &&
                shortScore <= 1 &&
                highBreakout;

            bool earlyAlignedShort =
                !premarketSession &&
                allowShort &&
                m5Bearish &&
                m5BelowVwap &&
                shortScore >= 3 &&
                longScore <= 1 &&
                lowBreakout;

            if (earlyAlignedLong)
            {
                persistentDirectionBias = "LONG ONLY";
                persistentDirectionBiasLastConfirmedNy = rangeNyTime;
                persistentDirectionBiasUntilNy =
                    rangeNyTime.AddSeconds(
                        PersistentDirectionBiasSeconds
                    );
            }
            else if (earlyAlignedShort)
            {
                persistentDirectionBias = "SHORT ONLY";
                persistentDirectionBiasLastConfirmedNy = rangeNyTime;
                persistentDirectionBiasUntilNy =
                    rangeNyTime.AddSeconds(
                        PersistentDirectionBiasSeconds
                    );
            }
            else if (
                persistentDirectionBiasUntilNy != DateTime.MinValue &&
                rangeNyTime > persistentDirectionBiasUntilNy
            )
            {
                persistentDirectionBias = "NONE";
                persistentDirectionBiasUntilNy = DateTime.MinValue;
                persistentDirectionBiasLastConfirmedNy = DateTime.MinValue;
            }

            bool persistentLongBias =
                string.Equals(
                    persistentDirectionBias,
                    "LONG ONLY",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                rangeNyTime <= persistentDirectionBiasUntilNy &&
                m5Bullish &&
                m5AboveVwap;

            bool persistentShortBias =
                string.Equals(
                    persistentDirectionBias,
                    "SHORT ONLY",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                rangeNyTime <= persistentDirectionBiasUntilNy &&
                m5Bearish &&
                m5BelowVwap;

            // =====================================================
            // V1.6.29 - PERSISTENT MOMENTUM CONFIRMATION
            // =====================================================
            // A valid aligned 3/5 impulse can decay to 2/5 on the next
            // Range callback simply because volume/breakout is no longer
            // counted. Keep that impulse alive for 30 seconds ONLY while:
            // - M5 and VWAP remain aligned,
            // - opposite momentum stays <= 1,
            // - EMA9 slope still points in the trade direction.
            bool persistentLongContinuation =
                persistentLongBias &&
                persistentDirectionBiasLastConfirmedNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    persistentDirectionBiasLastConfirmedNy
                ).TotalSeconds <=
                    PersistentMomentumContinuationSeconds &&
                longScore >= 2 &&
                shortScore <= 1 &&
                emaSlope > 0;

            bool persistentShortContinuation =
                persistentShortBias &&
                persistentDirectionBiasLastConfirmedNy != DateTime.MinValue &&
                (
                    rangeNyTime -
                    persistentDirectionBiasLastConfirmedNy
                ).TotalSeconds <=
                    PersistentMomentumContinuationSeconds &&
                shortScore >= 2 &&
                longScore <= 1 &&
                emaSlope < 0;

            bool rawLongReady =
                premarketSession
                    ? (
                        allowLong &&
                        (
                            premarketLongBias ||
                            aggressiveLongExpansion
                        )
                      )
                    : (
                        allowLong &&
                        (
                            strongOpeningPressureLong ||
                            (
                                m5AboveVwap &&
                                (
                                    (
                                        m5Bullish &&
                                        bullishMomentum
                                    ) ||
                                    earlyAlignedLong ||
                                    (
                                        persistentLongBias &&
                                        longScore >= 3 &&
                                        shortScore <= 1 &&
                                        highBreakout
                                    ) ||
                                    persistentLongContinuation ||
                                    extremeLongMomentum ||
                                    aggressiveLongExpansion
                                )
                            )
                        )
                      );

            bool rawShortReady =
                premarketSession
                    ? (
                        allowShort &&
                        (
                            premarketShortBias ||
                            aggressiveShortExpansion
                        )
                      )
                    : (
                        allowShort &&
                        (
                            strongOpeningPressureShort ||
                            (
                                m5BelowVwap &&
                                (
                                    (
                                        m5Bearish &&
                                        bearishMomentum
                                    ) ||
                                    earlyAlignedShort ||
                                    (
                                        persistentShortBias &&
                                        shortScore >= 3 &&
                                        longScore <= 1 &&
                                        lowBreakout
                                    ) ||
                                    persistentShortContinuation ||
                                    extremeShortMomentum ||
                                    aggressiveShortExpansion
                                )
                            )
                        )
                      );

            // Never let an ordinary 3/5 trade directly against confirmed M5.
            // Extreme/Aggressive paths keep their existing special handling.
            if (
                rawLongReady &&
                longScore == 3 &&
                m5Bearish &&
                !extremeLongMomentum &&
                !aggressiveLongExpansion
            )
            {
                rawLongReady = false;
            }

            if (
                rawShortReady &&
                shortScore == 3 &&
                m5Bullish &&
                !extremeShortMomentum &&
                !aggressiveShortExpansion
            )
            {
                rawShortReady = false;
            }

            if (strictMiddayMomentum)
            {
                // V1.6.29:
                // Keep the original strict midday path for ordinary signals,
                // but do NOT kill a clean V1 aligned early impulse or its
                // 30-second continuation memory. This fixes the case where
                // MIDDAY demanded 5/5 + HTF and discarded a valid 3/5 trend
                // even while M5 + VWAP + breakout were aligned.
                rawLongReady =
                    rawLongReady &&
                    (
                        earlyAlignedLong ||
                        persistentLongContinuation ||
                        (
                            longScore >=
                                MiddayMomentumMinScore &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveLongExpansion &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );

                rawShortReady =
                    rawShortReady &&
                    (
                        earlyAlignedShort ||
                        persistentShortContinuation ||
                        (
                            shortScore >=
                                MiddayMomentumMinScore &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveShortExpansion &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );
            }

            if (premarketSession)
            {
                if (!premarketRangeValid)
                {
                    return;
                }

                if (rawLongReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            true,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawLongReady =
                            false;
                    }
                }

                if (rawShortReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            false,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawShortReady =
                            false;
                    }
                }
            }

            // =====================================================
            // OPENING SAFETY PATCH - UNIVERSAL CONTEXT / ANTI-CHASE
            // =====================================================
            // During the Opening fallback window, fast-path Momentum cannot
            // enter directly against M5 or beyond the Opening anti-chase limit.
            // Instead, the candidate is converted into a pending Smart Retest.
            if (openingPriority && !premarketSession)
            {
                if (
                    rawLongReady &&
                    m5Bearish &&
                    !(
                        strongOpeningPressureLong &&
                        latestOpeningPressureConfidence >=
                            OpeningPressureStrongConfidence
                    )
                )
                {
                    double breakoutLevel =
                        openingRangeReady
                            ? openingRangeHigh
                            : GetHighestHigh(
                                bars,
                                Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                closedBarIndex - 1
                              );

                    ArmSmartRetest(
                        true,
                        rangeNyTime,
                        breakoutLevel,
                        m5BullishBreakLevel,
                        rangeClose,
                        longScore,
                        "OPENING COUNTERTREND LONG"
                    );

                    string blockKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|LONG|M5_BEARISH";

                    if (blockKey != lastOpeningContextBlockLogKey)
                    {
                        lastOpeningContextBlockLogKey = blockKey;
                        PrintBotMessage(
                            "OPENING FAST PATH BLOCKED - COUNTERTREND"
                            + " | Side: LONG"
                            + " | M5: BEARISH"
                            + " | Action: WAIT SMART RETEST"
                        );
                    }

                    rawLongReady = false;
                }

                if (
                    rawShortReady &&
                    m5Bullish &&
                    !(
                        strongOpeningPressureShort &&
                        latestOpeningPressureConfidence >=
                            OpeningPressureStrongConfidence
                    )
                )
                {
                    double breakoutLevel =
                        openingRangeReady
                            ? openingRangeLow
                            : GetLowestLow(
                                bars,
                                Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                closedBarIndex - 1
                              );

                    ArmSmartRetest(
                        false,
                        rangeNyTime,
                        breakoutLevel,
                        m5BearishBreakLevel,
                        rangeClose,
                        shortScore,
                        "OPENING COUNTERTREND SHORT"
                    );

                    string blockKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|SHORT|M5_BULLISH";

                    if (blockKey != lastOpeningContextBlockLogKey)
                    {
                        lastOpeningContextBlockLogKey = blockKey;
                        PrintBotMessage(
                            "OPENING FAST PATH BLOCKED - COUNTERTREND"
                            + " | Side: SHORT"
                            + " | M5: BULLISH"
                            + " | Action: WAIT SMART RETEST"
                        );
                    }

                    rawShortReady = false;
                }

                if (rawLongReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        LogOpeningPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            true,
                            rangeNyTime,
                            openingRangeReady ? openingRangeHigh : rangeClose,
                            m5BullishBreakLevel,
                            rangeClose,
                            longScore,
                            "OPENING PRICE EXTENDED LONG"
                        );

                        string antiChaseOverrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|LONG|"
                            + extensionPoints.ToString("0.00", CultureInfo.InvariantCulture)
                            + "|"
                            + maxExtensionPoints.ToString("0.00", CultureInfo.InvariantCulture);

                        if (
                            antiChaseOverrideKey !=
                                lastOpeningAntiChaseOverrideLogKey
                        )
                        {
                            lastOpeningAntiChaseOverrideLogKey =
                                antiChaseOverrideKey;

                            PrintBotMessage(
                                "OPENING ANTI-CHASE OVERRIDE"
                                + " | Side: LONG"
                                + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                                + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                                + " | Aggressive: " + aggressiveLongExpansion
                                + " | Extreme: " + extremeLongMomentum
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawLongReady = false;
                    }
                }

                if (rawShortReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        LogOpeningPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            false,
                            rangeNyTime,
                            openingRangeReady ? openingRangeLow : rangeClose,
                            m5BearishBreakLevel,
                            rangeClose,
                            shortScore,
                            "OPENING PRICE EXTENDED SHORT"
                        );

                        string antiChaseOverrideKey =
                            rangeNyTime.ToString("yyyyMMddHHmmss")
                            + "|SHORT|"
                            + extensionPoints.ToString("0.00", CultureInfo.InvariantCulture)
                            + "|"
                            + maxExtensionPoints.ToString("0.00", CultureInfo.InvariantCulture);

                        if (
                            antiChaseOverrideKey !=
                                lastOpeningAntiChaseOverrideLogKey
                        )
                        {
                            lastOpeningAntiChaseOverrideLogKey =
                                antiChaseOverrideKey;

                            PrintBotMessage(
                                "OPENING ANTI-CHASE OVERRIDE"
                                + " | Side: SHORT"
                                + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                                + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                                + " | Aggressive: " + aggressiveShortExpansion
                                + " | Extreme: " + extremeShortMomentum
                                + " | Action: WAIT SMART RETEST"
                            );
                        }

                        rawShortReady = false;
                    }
                }
            }

            // =====================================================
            // V1.6.9 - POST-MOVE EXHAUSTION GUARD
            // =====================================================
            // A mature directional move may keep producing ordinary Momentum
            // scores even after the best expansion is gone. If price is already
            // far from the session opposite extreme and current flow is weak,
            // do not keep chasing that same direction. A genuinely NEW
            // aggressive expansion is allowed through.
            double sessionUpMoveTicks;
            double sessionDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                out sessionUpMoveTicks,
                out sessionDownMoveTicks
            );

            bool weakCurrentExpansion =
                volumeRatio <=
                    ExhaustionMaxWeakVolumeRatio ||
                bodyRatio <=
                    ExhaustionMaxWeakBodyRatio;

            if (
                rawLongReady &&
                !aggressiveLongExpansion &&
                sessionUpMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    true,
                    rangeNyTime,
                    sessionUpMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    longScore
                );

                rawLongReady =
                    false;
            }

            if (
                rawShortReady &&
                !aggressiveShortExpansion &&
                sessionDownMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    false,
                    rangeNyTime,
                    sessionDownMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    shortScore
                );

                rawShortReady =
                    false;
            }

            // =====================================================
            // V1.6.11 - SMART RETEST / NO-CHASE ENTRY ENGINE
            // =====================================================
            // Extended ordinary signals arm a short-lived pending setup instead
            // of being forgotten. Aggressive Expansion may enter immediately only
            // when the higher-priority Opening safety guards above allow it.
            if (rawLongReady && !aggressiveLongExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = longScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "EXTENDED LONG SIGNAL"
                    );
                    LogPullbackWait(true, rangeNyTime, extensionTicks, maxExtensionTicks, longScore);
                    rawLongReady = false;
                }
            }

            if (rawShortReady && !aggressiveShortExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = shortScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "EXTENDED SHORT SIGNAL"
                    );
                    LogPullbackWait(false, rangeNyTime, extensionTicks, maxExtensionTicks, shortScore);
                    rawShortReady = false;
                }
            }

            // V1.6.23 Phase 3 - AGGRESSIVE MATURE-MOVE HARD CAP.
            // Aggressive Expansion keeps its fast-entry privilege while fresh.
            // But if price is already extremely stretched from EMA9 AND the
            // directional session leg is mature, do not buy/sell the tail.
            // Convert it into the existing Smart Retest workflow instead.
            if (rawLongReady && aggressiveLongExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize);

                if (
                    sessionUpMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks
                )
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "MATURE AGGRESSIVE LONG"
                    );

                    LogPullbackWait(
                        true, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, longScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: LONG"
                        + " | SessionMove: " + sessionUpMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawLongReady = false;
                }
            }

            if (rawShortReady && aggressiveShortExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize);

                if (
                    sessionDownMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks
                )
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "MATURE AGGRESSIVE SHORT"
                    );

                    LogPullbackWait(
                        false, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, shortScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: SHORT"
                        + " | SessionMove: " + sessionDownMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawShortReady = false;
                }
            }

            // A pending setup may now be confirmed even though the original
            // breakout bar is gone. This is the actual pullback-entry layer.
            bool smartRetestLong = false;
            bool smartRetestShort = false;
            string smartRetestPattern = string.Empty;
            string smartRetestStructureSetupKey = string.Empty;

            TryConfirmSmartRetest(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                rangeClose,
                longScore,
                shortScore,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                out smartRetestLong,
                out smartRetestShort,
                out smartRetestPattern,
                out smartRetestStructureSetupKey
            );

            if (smartRetestLong)
            {
                rawLongReady = true;
                rawShortReady = false;
                PrintSmartRetestConfirmed(true, rangeNyTime, smartRetestPattern, rangeClose, longScore);
            }
            else if (smartRetestShort)
            {
                rawShortReady = true;
                rawLongReady = false;
                PrintSmartRetestConfirmed(false, rangeNyTime, smartRetestPattern, rangeClose, shortScore);
            }

            // =====================================================
            // V1.6.18 - SHADOW SIGNAL DATASET
            // =====================================================
            // Capture meaningful candidates even when a later guard rejects
            // the trade. This is intentionally observational only.
            bool shadowLongCandidate =
                longScore >= MomentumMinScore ||
                extremeLongMomentum ||
                aggressiveLongExpansion ||
                highBreakout ||
                smartRetestLong;

            bool shadowShortCandidate =
                shortScore >= MomentumMinScore ||
                extremeShortMomentum ||
                aggressiveShortExpansion ||
                lowBreakout ||
                smartRetestShort;

            string shadowLongId = string.Empty;
            string shadowShortId = string.Empty;

            if (shadowLongCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    true,
                    longScore,
                    aggressiveLongExpansion,
                    extremeLongMomentum,
                    smartRetestLong,
                    highBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfLongScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        true,
                        rawLongReady,
                        allowLong,
                        premarketSession,
                        m5AboveVwap,
                        m5Bullish,
                        strictMiddayMomentum,
                        longScore,
                        htfLongScore,
                        aggressiveLongExpansion,
                        sessionUpMoveTicks,
                        weakCurrentExpansion
                    );

                shadowLongId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        true,
                        momentumSession,
                        rawLongReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        longScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        highBreakout,
                        aggressiveLongScore,
                        aggressiveLongExpansion,
                        extremeLongMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfLongScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            if (shadowShortCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    false,
                    shortScore,
                    aggressiveShortExpansion,
                    extremeShortMomentum,
                    smartRetestShort,
                    lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfShortScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        false,
                        rawShortReady,
                        allowShort,
                        premarketSession,
                        m5BelowVwap,
                        m5Bearish,
                        strictMiddayMomentum,
                        shortScore,
                        htfShortScore,
                        aggressiveShortExpansion,
                        sessionDownMoveTicks,
                        weakCurrentExpansion
                    );

                shadowShortId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        false,
                        momentumSession,
                        rawShortReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        shortScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        lowBreakout,
                        aggressiveShortScore,
                        aggressiveShortExpansion,
                        extremeShortMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfShortScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            // =====================================================
            // V1.6.15A - LIVE ANALYSIS CONFIDENCE
            // =====================================================
            // Keep an advisory percentage alive while the bot is still
            // analyzing. This does NOT authorize or block entries.
            if (
                !rawLongReady &&
                !rawShortReady
            )
            {
                bool analysisIsLong;

                if (
                    string.Equals(
                        autoResolvedDirection,
                        "LONG ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = true;
                }
                else if (
                    string.Equals(
                        autoResolvedDirection,
                        "SHORT ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = false;
                }
                else
                {
                    analysisIsLong =
                        longScore >= shortScore;
                }

                int analysisConfidence;
                string analysisQuality;
                string analysisTiming;
                string analysisManipulation;
                string analysisReason;

                EvaluateNasdaqSetupQuality(
                    analysisIsLong,
                    analysisIsLong
                        ? longScore
                        : shortScore,
                    analysisIsLong
                        ? aggressiveLongExpansion
                        : aggressiveShortExpansion,
                    analysisIsLong
                        ? extremeLongMomentum
                        : extremeShortMomentum,
                    false,
                    analysisIsLong
                        ? highBreakout
                        : lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    analysisIsLong
                        ? htfLongScore
                        : htfShortScore,
                    out analysisConfidence,
                    out analysisQuality,
                    out analysisTiming,
                    out analysisManipulation,
                    out analysisReason
                );

                latestSetupConfidence =
                    analysisConfidence;

                latestSetupQuality =
                    analysisConfidence >= 70
                        ? analysisQuality
                        : "ANALYZING";

                latestSetupTiming =
                    "ANALYZING";

                latestManipulationState =
                    analysisManipulation;

                return;
            }

            bool selectedAggressiveExpansion =
                rawLongReady
                    ? aggressiveLongExpansion
                    : aggressiveShortExpansion;

            if (selectedAggressiveExpansion)
            {
                string aggressionLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT");

                if (
                    aggressionLogKey !=
                        lastAggressionSignalLogKey
                )
                {
                    lastAggressionSignalLogKey =
                        aggressionLogKey;

                    PrintBotMessage(
                        "AGGRESSIVE EXPANSION DETECTED"
                        + " | Side: "
                        + (rawLongReady ? "LONG" : "SHORT")
                        + " | Aggression: "
                        + (
                            rawLongReady
                                ? aggressiveLongScore
                                : aggressiveShortScore
                          )
                        + "/5"
                        + " | R20: "
                        + (
                            rawLongReady
                                ? longScore
                                : shortScore
                          )
                        + "/5"
                        + " | Displacement: "
                        + (
                            rawLongReady
                                ? aggressiveLongDisplacementTicks
                                : aggressiveShortDisplacementTicks
                          ).ToString("0")
                        + "t"
                        + " | Range x"
                        + rangeRatio.ToString("0.00")
                        + " | Volume x"
                        + volumeRatio.ToString("0.00")
                        + " | Body "
                        + (bodyRatio * 100.0).ToString("0")
                        + "%"
                        + " | EMA Slope "
                        + slopeTicks.ToString("0.0")
                        + "t"
                    );
                }
            }

            bool highConvictionMomentum =
                selectedAggressiveExpansion ||
                (
                rawLongReady
                    ? (
                        (
                            premarketSession &&
                            premarketExtremeLong
                        ) ||
                        extremeLongMomentum ||
                        (
                            longScore >= 4 &&
                            highBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                    : (
                        (
                            premarketSession &&
                            premarketExtremeShort
                        ) ||
                        extremeShortMomentum ||
                        (
                            shortScore >= 4 &&
                            lowBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                );

            bool effectiveExtremeMomentum =
                premarketSession
                    ? (
                        rawLongReady
                            ? premarketExtremeLong
                            : premarketExtremeShort
                      )
                    : (
                        rawLongReady
                            ? extremeLongMomentum
                            : extremeShortMomentum
                      );

            // =====================================================
            // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE
            // =====================================================
            int setupConfidence;
            string setupQuality;
            string setupTiming;
            string manipulationState;
            string setupQualityReason;

            EvaluateNasdaqSetupQuality(
                rawLongReady,
                rawLongReady ? longScore : shortScore,
                selectedAggressiveExpansion,
                effectiveExtremeMomentum,
                !string.IsNullOrWhiteSpace(smartRetestPattern),
                rawLongReady ? highBreakout : lowBreakout,
                bodyRatio,
                volumeRatio,
                slopeTicks,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                m5Structure,
                m5Liquidity,
                rawLongReady ? htfLongScore : htfShortScore,
                out setupConfidence,
                out setupQuality,
                out setupTiming,
                out manipulationState,
                out setupQualityReason
            );

            latestSetupConfidence =
                setupConfidence;
            latestSetupQuality =
                setupQuality;
            latestSetupTiming =
                setupTiming;
            latestManipulationState =
                manipulationState;

            string setupQualityLogKey =
                closedRangeTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + setupConfidence
                + "|"
                + setupQuality
                + "|"
                + setupTiming
                + "|"
                + manipulationState;

            if (
                setupQualityLogKey !=
                    lastSetupQualityLogKey
            )
            {
                lastSetupQualityLogKey =
                    setupQualityLogKey;

                PrintBotMessage(
                    "SETUP QUALITY"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | "
                    + setupQuality
                    + " | Confidence: "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                    + " | "
                    + setupQualityReason
                );
            }

            currentSetupState =
                setupQuality
                + " "
                + setupConfidence
                + "% | "
                + setupTiming;

            string learningContext =
                (
                    !string.IsNullOrWhiteSpace(smartRetestPattern)
                        ? "SMART RETEST " + smartRetestPattern + " "
                        : selectedAggressiveExpansion
                        ? (
                            premarketSession
                                ? "PREMARKET AGGRESSIVE EXPANSION "
                                : "R20 AGGRESSIVE EXPANSION "
                          )
                        : (
                            premarketSession
                                ? (
                                    effectiveExtremeMomentum
                                        ? "PREMARKET R20 EXTREME MOMENTUM "
                                        : "PREMARKET R20 MOMENTUM "
                                  )
                                : (
                                    effectiveExtremeMomentum
                                        ? "R20 EXTREME MOMENTUM "
                                        : "R20 MOMENTUM "
                                  )
                          )
                )
                + (
                    rawLongReady
                        ? longScore
                        : shortScore
                )
                + "/5";

            string learningReason;

            bool learningAllowed =
                IsLearningTradeAllowed(
                    rawLongReady
                        ? "LONG"
                        : "SHORT",
                    rangeNyTime,
                    learningContext,
                    out learningReason
                );

            DateTime closedRangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            string rangeSignalLogKey =
                closedRangeTime.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + (rawLongReady ? longScore : shortScore);

            if (rangeSignalLogKey != lastRangeSignalLogKey)
            {
                lastRangeSignalLogKey = rangeSignalLogKey;

                PrintBotMessage(
                    "RANGE MOMENTUM SIGNAL"
                    + (
                        premarketSession
                            ? " | PREMARKET"
                            : (
                                openingPriority
                                    ? " | OPENING FALLBACK"
                                    : string.Empty
                              )
                      )
                    + " | Bar: "
                    + closedRangeNyTime.ToString("HH:mm:ss")
                    + " ET"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20 Score: "
                    + (rawLongReady ? longScore : shortScore)
                    + "/5"
                    + " | M5 Trend: "
                    + (
                        m5Bullish
                            ? "BULLISH"
                            : m5Bearish
                                ? "BEARISH"
                                : "NEUTRAL"
                    )
                    + " | M5 VWAP: "
                    + (
                        m5AboveVwap
                            ? "ABOVE"
                            : m5BelowVwap
                                ? "BELOW"
                                : "AT"
                    )
                    + " | M5 Structure: "
                    + m5Structure
                    + " | Quality: "
                    + setupQuality
                    + " "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                );
            }

            if (!learningAllowed)
            {
                UpdateShadowSignalDecision(
                    rawLongReady
                        ? shadowLongId
                        : shadowShortId,
                    "LEARNING_BLOCKED",
                    learningReason
                );

                string learningBlockedLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT")
                    + "|"
                    + learningContext
                    + "|"
                    + learningReason;

                if (
                    learningBlockedLogKey !=
                        lastLearningBlockedLogKey
                )
                {
                    lastLearningBlockedLogKey =
                        learningBlockedLogKey;

                    PrintBotMessage(
                        "LEARNING BLOCK RANGE"
                        + " | Bar: "
                        + closedRangeNyTime.ToString(
                            "HH:mm:ss"
                        )
                        + " ET"
                        + " | "
                        + learningReason
                    );
                }

                return;
            }

            lastLearningBlockedLogKey =
                string.Empty;

            CaptureLearningSignalContext(
                rawLongReady
                    ? "LONG"
                    : "SHORT",
                rangeNyTime,
                learningContext
            );

            pendingShadowSignalId =
                rawLongReady
                    ? shadowLongId
                    : shadowShortId;

            UpdateShadowSignalDecision(
                pendingShadowSignalId,
                "ENTRY_ATTEMPT",
                "PASSED SIGNAL + LEARNING GATES"
            );

            TrySubmitEntry(
                rawLongReady,
                closedRangeTime,
                false,
                string.IsNullOrWhiteSpace(smartRetestStructureSetupKey)
                    ? null
                    : smartRetestStructureSetupKey,
                false,
                highConvictionMomentum
            );
        }
        private void CalculateMomentumScores(
            Bars bars,
            int closedBarIndex,
            double emaFastCurrent,
            out int longScore,
            out int shortScore,
            out double rangeRatio,
            out double volumeRatio,
            out double bodyRatio,
            out double emaFastSlope,
            out bool highBreakout,
            out bool lowBreakout)
        {
            longScore = 0;
            shortScore = 0;
            rangeRatio = 0;
            volumeRatio = 0;
            bodyRatio = 0;
            emaFastSlope = 0;
            highBreakout = false;
            lowBreakout = false;

            if (
                bars == null ||
                closedBarIndex <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 2
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            double high =
                bars.GetHigh(
                    closedBarIndex
                );

            double low =
                bars.GetLow(
                    closedBarIndex
                );

            double currentRange =
                Math.Max(
                    0,
                    high - low
                );

            double currentBody =
                Math.Abs(
                    close - open
                );

            bodyRatio =
                currentRange > 0
                    ? currentBody /
                        currentRange
                    : 0;

            double averageRange = 0;
            double averageVolume = 0;

            for (
                int i = closedBarIndex -
                    MomentumAverageLookback;
                i < closedBarIndex;
                i++
            )
            {
                averageRange +=
                    Math.Max(
                        0,
                        bars.GetHigh(i) -
                        bars.GetLow(i)
                    );

                averageVolume +=
                    bars.GetVolume(i);
            }

            averageRange /=
                MomentumAverageLookback;

            averageVolume /=
                MomentumAverageLookback;

            rangeRatio =
                averageRange > 0
                    ? currentRange /
                        averageRange
                    : 0;

            double currentVolume =
                bars.GetVolume(
                    closedBarIndex
                );

            volumeRatio =
                averageVolume > 0
                    ? currentVolume /
                        averageVolume
                    : 0;

            double emaFastPrevious =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex - 1
                );

            emaFastSlope =
                emaFastCurrent -
                emaFastPrevious;

            double previousHighest =
                double.MinValue;

            double previousLowest =
                double.MaxValue;

            for (
                int i = closedBarIndex -
                    MomentumBreakoutLookback;
                i < closedBarIndex;
                i++
            )
            {
                previousHighest =
                    Math.Max(
                        previousHighest,
                        bars.GetHigh(i)
                    );

                previousLowest =
                    Math.Min(
                        previousLowest,
                        bars.GetLow(i)
                    );
            }

            highBreakout =
                close > previousHighest;

            lowBreakout =
                close < previousLowest;

            bool bullishCandle =
                close > open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool bearishCandle =
                close < open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    MomentumRangeExpansion;

            bool volumeExpanded =
                volumeRatio >=
                    MomentumVolumeExpansion;

            bool emaRising =
                emaFastSlope > 0;

            bool emaFalling =
                emaFastSlope < 0;

            // V1.6.31 - Direction and movement quality must not inflate
            // both sides at the same time. Range/volume expansion only earns
            // credit for the side the completed Range bar actually closed on.
            bool barClosedBullish =
                close > open;

            bool barClosedBearish =
                close < open;

            // Five components:
            // 1) strong directional body
            // 2) EMA9 slope
            // 3) range expansion in the bar direction
            // 4) relative volume expansion in the bar direction
            // 5) close breakout of recent Range bars
            if (bullishCandle)
                longScore++;

            if (emaRising)
                longScore++;

            if (rangeExpanded && barClosedBullish)
                longScore++;

            if (volumeExpanded && barClosedBullish)
                longScore++;

            if (highBreakout)
                longScore++;

            if (bearishCandle)
                shortScore++;

            if (emaFalling)
                shortScore++;

            if (rangeExpanded && barClosedBearish)
                shortScore++;

            if (volumeExpanded && barClosedBearish)
                shortScore++;

            if (lowBreakout)
                shortScore++;
        }

    }
}

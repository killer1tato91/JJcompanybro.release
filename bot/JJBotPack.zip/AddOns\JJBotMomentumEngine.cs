﻿#region Using declarations
using System;
using System.Globalization;
using System.Windows.Media;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private void UpdateMomentumFromRangeBars(
            Bars bars,
            bool evaluateClosedRangeBar)
        {
            if (
                bars == null ||
                bars.Count <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 3
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            int longScore;
            int shortScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaSlope;
            bool highBreakout;
            bool lowBreakout;

            CalculateMomentumScores(
                bars,
                closedBarIndex,
                emaFastCurrent,
                out longScore,
                out shortScore,
                out rangeRatio,
                out volumeRatio,
                out bodyRatio,
                out emaSlope,
                out highBreakout,
                out lowBreakout
            );

            bool bullishMomentum =
                longScore >= MomentumMinScore;

            bool bearishMomentum =
                shortScore >= MomentumMinScore;

            string momentumState =
                bullishMomentum &&
                !bearishMomentum
                    ? "BULLISH "
                        + longScore
                        + "/5"
                    : bearishMomentum &&
                        !bullishMomentum
                        ? "BEARISH "
                            + shortScore
                            + "/5"
                        : "L "
                            + longScore
                            + "/5 | S "
                            + shortScore
                            + "/5";

            lock (marketContextLock)
            {
                latestRangeLongScore =
                    longScore;
                latestRangeShortScore =
                    shortScore;
                latestRangeRatio =
                    rangeRatio;
                latestRangeVolumeRatio =
                    volumeRatio;
                latestRangeBodyRatio =
                    bodyRatio;
                latestRangeEmaSlope =
                    emaSlope;
                latestRangeHighBreakout =
                    highBreakout;
                latestRangeLowBreakout =
                    lowBreakout;
                latestRangeMomentumState =
                    momentumState;
            }

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (
                        !botRunning ||
                        momentumText == null
                    )
                    {
                        return;
                    }

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        bullishMomentum
                            ? Brushes.LimeGreen
                            : bearishMomentum
                                ? Brushes.OrangeRed
                                : Brushes.Goldenrod;
                })
            );

            if (!evaluateClosedRangeBar)
                return;

            DateTime closedRangeTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime rangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            EnsureTradingDay(
                rangeNyTime
            );

            bool m5Ready;
            bool m5Bullish;
            bool m5Bearish;
            bool m5AboveVwap;
            bool m5BelowVwap;
            string m5Structure;
            string m5Liquidity;
            int htfLongScore;
            int htfShortScore;
            double m5BullishBreakLevel;
            double m5BearishBreakLevel;

            lock (marketContextLock)
            {
                m5Ready =
                    latestM5ContextReady;
                m5Bullish =
                    latestM5BullishTrend;
                m5Bearish =
                    latestM5BearishTrend;
                m5AboveVwap =
                    latestM5AboveVwap;
                m5BelowVwap =
                    latestM5BelowVwap;
                m5Structure =
                    latestM5StructureState;

                m5Liquidity =
                    latestM5LiquidityState;

                htfLongScore =
                    latestHtfLongScore;

                htfShortScore =
                    latestHtfShortScore;
                m5BullishBreakLevel =
                    latestM5BullishStructureBreakLevel;
                m5BearishBreakLevel =
                    latestM5BearishStructureBreakLevel;
            }

            if (!m5Ready)
                return;

            bool nySessionActive =
                IsBotNySessionActive(
                    rangeNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    rangeNyTime
                );

            bool allowMomentumMode =
                activeStrategyMode == "MOMENTUM SCALP" ||
                activeStrategyMode == "HYBRID";

            bool openingPriority =
                IsOpeningPriorityActive(
                    rangeNyTime
                );

            bool openingBuildLock =
                IsOpeningBuildWindow(
                    rangeNyTime
                );

            // V1.6.2:
            // 09:30-09:35: Momentum is blocked while the opening range forms.
            // 09:35-10:00: Momentum is fallback only. If price is currently
            // presenting a valid Opening breakout, Opening gets first priority.
            double rangeClose =
                bars.GetClose(
                    closedBarIndex
                );

            double openingBuffer =
                selectedInstrument != null
                    ? selectedInstrument
                        .MasterInstrument
                        .TickSize
                        * OpeningBreakoutBufferTicks
                    : 0;

            bool openingLongCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bullish &&
                m5AboveVwap &&
                rangeClose >=
                    openingRangeHigh +
                    openingBuffer;

            bool openingShortCandidate =
                openingPriority &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                m5Bearish &&
                m5BelowVwap &&
                rangeClose <=
                    openingRangeLow -
                    openingBuffer;

            // =====================================================
            // V1.6.5 - EARLY EXTREME MOMENTUM DETECTION
            // =====================================================
            double momentumTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double slopeTicks =
                momentumTickSize > 0
                    ? emaSlope /
                        momentumTickSize
                    : 0;

            // V1.6.18 - advance previously-recorded shadow candidates using
            // only completed Range bars. This has no execution side effects.
            double completedRangeHigh = bars.GetHigh(closedBarIndex);
            double completedRangeLow = bars.GetLow(closedBarIndex);

            UpdateShadowSignalOutcomes(
                rangeNyTime,
                rangeClose,
                completedRangeHigh,
                completedRangeLow,
                momentumTickSize
            );

            // V1.6.23 Phase 7 - continue adjudicating the ORIGINAL signal
            // after a forced financial/session exit. This never submits orders.
            UpdateDeferredLearningSignalOutcomes(
                rangeNyTime,
                completedRangeHigh,
                completedRangeLow
            );

            bool extremeLongMomentum =
                longScore >=
                    ExtremeMomentumMinScore &&
                highBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    ExtremeMomentumMinSlopeTicks &&
                m5AboveVwap;

            bool extremeShortMomentum =
                shortScore >=
                    ExtremeMomentumMinScore &&
                lowBreakout &&
                bodyRatio >=
                    ExtremeMomentumMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -ExtremeMomentumMinSlopeTicks &&
                m5BelowVwap;

            // Premarket has no RTH VWAP yet, so its fast path uses the
            // completed premarket frontier + M5 direction instead.
            bool premarketRangeValid =
                premarketSession &&
                premarketRangeReady &&
                premarketRangeDateNy ==
                    rangeNyTime.Date;

            bool premarketHighBreakout =
                premarketRangeValid &&
                rangeClose >
                    premarketRangeHigh;

            bool premarketLowBreakout =
                premarketRangeValid &&
                rangeClose <
                    premarketRangeLow;

            bool premarketExtremeLong =
                premarketHighBreakout &&
                longScore >=
                    PremarketExtremeMinScore &&
                highBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks >=
                    PremarketExtremeMinSlopeTicks &&
                (
                    m5Bullish ||
                    htfLongScore >= 1
                );

            bool premarketExtremeShort =
                premarketLowBreakout &&
                shortScore >=
                    PremarketExtremeMinScore &&
                lowBreakout &&
                bodyRatio >=
                    PremarketExtremeMinBodyRatio &&
                volumeRatio >=
                    ExtremeMomentumMinVolumeRatio &&
                slopeTicks <=
                    -PremarketExtremeMinSlopeTicks &&
                (
                    m5Bearish ||
                    htfShortScore >= 1
                );

            bool premarketLongBias =
                premarketHighBreakout &&
                (
                    (
                        m5Bullish &&
                        longScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeLong
                );

            bool premarketShortBias =
                premarketLowBreakout &&
                (
                    (
                        m5Bearish &&
                        shortScore >=
                            PremarketMomentumMinScore
                    ) ||
                    premarketExtremeShort
                );

            // =====================================================
            // V1.6.9 - FRESH AGGRESSIVE EXPANSION DETECTION
            // =====================================================
            int aggressiveLongScore;
            int aggressiveShortScore;
            int aggressiveLongDirectionalBars;
            int aggressiveShortDirectionalBars;
            double aggressiveLongDisplacementTicks;
            double aggressiveShortDisplacementTicks;

            CalculateAggressionState(
                bars,
                closedBarIndex,
                momentumTickSize,
                rangeRatio,
                volumeRatio,
                bodyRatio,
                slopeTicks,
                highBreakout,
                lowBreakout,
                out aggressiveLongScore,
                out aggressiveShortScore,
                out aggressiveLongDirectionalBars,
                out aggressiveShortDirectionalBars,
                out aggressiveLongDisplacementTicks,
                out aggressiveShortDisplacementTicks
            );

            bool aggressiveLongExpansion =
                aggressiveLongScore >= AggressionMinScore &&
                highBreakout &&
                aggressiveLongDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveLongDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketHighBreakout &&
                            (
                                m5Bullish ||
                                htfLongScore >= 1
                            )
                          )
                        : m5AboveVwap
                );

            bool aggressiveShortExpansion =
                aggressiveShortScore >= AggressionMinScore &&
                lowBreakout &&
                aggressiveShortDirectionalBars >=
                    AggressionMinDirectionalBars &&
                aggressiveShortDisplacementTicks >=
                    AggressionMinDisplacementTicks &&
                (
                    premarketSession
                        ? (
                            premarketLowBreakout &&
                            (
                                m5Bearish ||
                                htfShortScore >= 1
                            )
                          )
                        : m5BelowVwap
                );

            // V1.6.20: Aggressive expansion may resolve AUTO early only
            // when aligned with pressure or while pressure is neutral.
            // An opposite impulse is interpreted as a pullback.
            if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                aggressiveLongExpansion !=
                    aggressiveShortExpansion
            )
            {
                bool aggressiveResolveLong =
                    aggressiveLongExpansion;

                int pressureLongScore;
                int pressureShortScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out pressureLongScore,
                        out pressureShortScore
                    );

                bool counterPressure =
                    (
                        aggressiveResolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !aggressiveResolveLong &&
                        pressure == "LONG"
                    );

                if (!counterPressure)
                {
                    autoResolvedDirection =
                        aggressiveResolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoDirectionReason =
                        (
                            aggressiveResolveLong
                                ? "FRESH AGGRESSIVE EXPANSION LONG"
                                : "FRESH AGGRESSIVE EXPANSION SHORT"
                        )
                        + (
                            pressure == "NEUTRAL"
                                ? " | NEUTRAL DISCOVERY"
                                : " | ALIGNED PRESSURE"
                          );
                }
            }

            // Do not let an already over-extended Opening candidate suppress
            // a fresh Range momentum signal.
            if (openingLongCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingLongCandidate =
                        false;
                }
            }

            if (openingShortCandidate)
            {
                double extensionPoints;
                double maxExtensionPoints;

                if (
                    IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints
                    )
                )
                {
                    openingShortCandidate =
                        false;
                }
            }

            bool openingCandidatePresent =
                openingLongCandidate ||
                openingShortCandidate;

            bool extremeOpeningOverride =
                openingBuildLock &&
                (
                    extremeLongMomentum ||
                    extremeShortMomentum ||
                    aggressiveLongExpansion ||
                    aggressiveShortExpansion
                );

            if (
                !nySessionActive ||
                !allowMomentumMode ||
                (
                    openingBuildLock &&
                    !extremeOpeningOverride
                ) ||
                openingCandidatePresent
            )
            {
                return;
            }

            string effectiveRangeDirection;

            // Premarket AUTO is resolved from the premarket frontier because
            // the regular-session VWAP intentionally does not exist yet.
            if (
                premarketSession &&
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                bool premarketAutoLong =
                    premarketLongBias ||
                    aggressiveLongExpansion;

                bool premarketAutoShort =
                    premarketShortBias ||
                    aggressiveShortExpansion;

                if (
                    premarketAutoLong !=
                        premarketAutoShort
                )
                {
                    effectiveRangeDirection =
                        premarketAutoLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        aggressiveLongExpansion ||
                        aggressiveShortExpansion
                            ? (
                                premarketAutoLong
                                    ? "PREMARKET FRESH AGGRESSIVE EXPANSION LONG"
                                    : "PREMARKET FRESH AGGRESSIVE EXPANSION SHORT"
                              )
                            : (
                                premarketAutoLong
                                    ? "PREMARKET HIGH BREAKOUT + MOMENTUM"
                                    : "PREMARKET LOW BREAKOUT + MOMENTUM"
                              );
                }
                else
                {
                    effectiveRangeDirection =
                        "NONE";

                    autoResolvedDirection =
                        "NONE";

                    autoDirectionReason =
                        "PREMARKET WAITING FOR RANGE BREAKOUT";
                }
            }
            // V1.6.20 RTH AUTO:
            // ALIGNED pressure -> preserve direct scalp entry.
            // NEUTRAL pressure -> fast impulse may discover direction.
            // COUNTER pressure -> classify as pullback; do not flip AUTO.
            else if (
                string.Equals(
                    activeDirection,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                (
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion ||
                    extremeLongMomentum !=
                        extremeShortMomentum
                )
            )
            {
                bool resolveLong =
                    aggressiveLongExpansion !=
                        aggressiveShortExpansion
                        ? aggressiveLongExpansion
                        : extremeLongMomentum;

                int longPressureScore;
                int shortPressureScore;

                string pressure =
                    EvaluateDirectionalPressure(
                        out longPressureScore,
                        out shortPressureScore
                    );

                bool counterPressure =
                    (
                        resolveLong &&
                        pressure == "SHORT"
                    ) ||
                    (
                        !resolveLong &&
                        pressure == "LONG"
                    );

                if (counterPressure)
                {
                    effectiveRangeDirection =
                        pressure == "LONG"
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    autoDirectionReason =
                        "COUNTER-PRESSURE FAST IMPULSE BLOCKED"
                        + " | Pressure: " + pressure
                        + " " + longPressureScore + "/" + shortPressureScore
                        + " | FastSide: " + (resolveLong ? "LONG" : "SHORT")
                        + " | WAIT RESUMPTION";

                    string pressureLogKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|" + pressure
                        + "|" + (resolveLong ? "LONG" : "SHORT")
                        + "|" + longPressureScore
                        + "/" + shortPressureScore;

                    if (
                        pressureLogKey !=
                            lastDirectionalPressureLogKey
                    )
                    {
                        lastDirectionalPressureLogKey =
                            pressureLogKey;

                        PrintBotMessage(
                            "COUNTER-PRESSURE MOMENTUM"
                            + " | FastSide: "
                            + (resolveLong ? "LONG" : "SHORT")
                            + " | GeneralPressure: " + pressure
                            + " | Score L/S: "
                            + longPressureScore + "/" + shortPressureScore
                            + " | Action: PULLBACK - NO COUNTER ENTRY"
                        );
                    }
                }
                else
                {
                    effectiveRangeDirection =
                        resolveLong
                            ? "LONG ONLY"
                            : "SHORT ONLY";

                    autoResolvedDirection =
                        effectiveRangeDirection;

                    string pressureTag =
                        pressure == "NEUTRAL"
                            ? "NEUTRAL DISCOVERY"
                            : "ALIGNED PRESSURE";

                    autoDirectionReason =
                        (
                            aggressiveLongExpansion ||
                            aggressiveShortExpansion
                                ? (
                                    resolveLong
                                        ? "FRESH AGGRESSIVE EXPANSION LONG"
                                        : "FRESH AGGRESSIVE EXPANSION SHORT"
                                  )
                                : (
                                    resolveLong
                                        ? "EXTREME R20 LONG + BREAKOUT + VWAP"
                                        : "EXTREME R20 SHORT + BREAKOUT + VWAP"
                                  )
                        )
                        + " | " + pressureTag
                        + " " + longPressureScore + "/" + shortPressureScore;
                }
            }
            else
            {
                effectiveRangeDirection =
                    ResolveEffectiveDirection(
                        rangeNyTime,
                        rangeClose,
                        m5Bullish,
                        m5Bearish,
                        m5AboveVwap,
                        m5BelowVwap
                    );
            }

            bool allowLong =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "LONG ONLY";

            bool allowShort =
                effectiveRangeDirection == "BOTH" ||
                effectiveRangeDirection == "SHORT ONLY";

            string momentumSession =
                GetBotSessionWindow(
                    rangeNyTime
                );

            bool strictMiddayMomentum =
                string.Equals(
                    momentumSession,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            bool rawLongReady =
                premarketSession
                    ? (
                        allowLong &&
                        (
                            premarketLongBias ||
                            aggressiveLongExpansion
                        )
                      )
                    : (
                        allowLong &&
                        m5AboveVwap &&
                        (
                            (
                                m5Bullish &&
                                bullishMomentum
                            ) ||
                            extremeLongMomentum ||
                            aggressiveLongExpansion
                        )
                      );

            bool rawShortReady =
                premarketSession
                    ? (
                        allowShort &&
                        (
                            premarketShortBias ||
                            aggressiveShortExpansion
                        )
                      )
                    : (
                        allowShort &&
                        m5BelowVwap &&
                        (
                            (
                                m5Bearish &&
                                bearishMomentum
                            ) ||
                            extremeShortMomentum ||
                            aggressiveShortExpansion
                        )
                      );

            if (strictMiddayMomentum)
            {
                rawLongReady =
                    rawLongReady &&
                    (
                        (
                            longScore >=
                                MiddayMomentumMinScore &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveLongExpansion &&
                            htfLongScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );

                rawShortReady =
                    rawShortReady &&
                    (
                        (
                            shortScore >=
                                MiddayMomentumMinScore &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        ) ||
                        (
                            aggressiveShortExpansion &&
                            htfShortScore >=
                                MiddayMinHtfAlignmentScore
                        )
                    );
            }

            if (premarketSession)
            {
                if (!premarketRangeValid)
                {
                    return;
                }

                if (rawLongReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            true,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawLongReady =
                            false;
                    }
                }

                if (rawShortReady)
                {
                    double extensionTicks;

                    if (
                        IsPremarketPriceChaseBlocked(
                            false,
                            rangeClose,
                            out extensionTicks
                        )
                    )
                    {
                        LogPremarketPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionTicks
                        );

                        rawShortReady =
                            false;
                    }
                }
            }

            // =====================================================
            // OPENING SAFETY PATCH - UNIVERSAL CONTEXT / ANTI-CHASE
            // =====================================================
            // During the Opening fallback window, fast-path Momentum cannot
            // enter directly against M5 or beyond the Opening anti-chase limit.
            // Instead, the candidate is converted into a pending Smart Retest.
            if (openingPriority && !premarketSession)
            {
                if (rawLongReady && m5Bearish)
                {
                    double breakoutLevel =
                        openingRangeReady
                            ? openingRangeHigh
                            : GetHighestHigh(
                                bars,
                                Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                closedBarIndex - 1
                              );

                    ArmSmartRetest(
                        true,
                        rangeNyTime,
                        breakoutLevel,
                        m5BullishBreakLevel,
                        rangeClose,
                        longScore,
                        "OPENING COUNTERTREND LONG"
                    );

                    string blockKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|LONG|M5_BEARISH";

                    if (blockKey != lastOpeningContextBlockLogKey)
                    {
                        lastOpeningContextBlockLogKey = blockKey;
                        PrintBotMessage(
                            "OPENING FAST PATH BLOCKED - COUNTERTREND"
                            + " | Side: LONG"
                            + " | M5: BEARISH"
                            + " | Action: WAIT SMART RETEST"
                        );
                    }

                    rawLongReady = false;
                }

                if (rawShortReady && m5Bullish)
                {
                    double breakoutLevel =
                        openingRangeReady
                            ? openingRangeLow
                            : GetLowestLow(
                                bars,
                                Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                                closedBarIndex - 1
                              );

                    ArmSmartRetest(
                        false,
                        rangeNyTime,
                        breakoutLevel,
                        m5BearishBreakLevel,
                        rangeClose,
                        shortScore,
                        "OPENING COUNTERTREND SHORT"
                    );

                    string blockKey =
                        rangeNyTime.ToString("yyyyMMddHHmmss")
                        + "|SHORT|M5_BULLISH";

                    if (blockKey != lastOpeningContextBlockLogKey)
                    {
                        lastOpeningContextBlockLogKey = blockKey;
                        PrintBotMessage(
                            "OPENING FAST PATH BLOCKED - COUNTERTREND"
                            + " | Side: SHORT"
                            + " | M5: BULLISH"
                            + " | Action: WAIT SMART RETEST"
                        );
                    }

                    rawShortReady = false;
                }

                if (rawLongReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        true,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        LogOpeningPriceChaseBlock(
                            true,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            true,
                            rangeNyTime,
                            openingRangeReady ? openingRangeHigh : rangeClose,
                            m5BullishBreakLevel,
                            rangeClose,
                            longScore,
                            "OPENING PRICE EXTENDED LONG"
                        );

                        PrintBotMessage(
                            "OPENING ANTI-CHASE OVERRIDE"
                            + " | Side: LONG"
                            + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                            + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                            + " | Aggressive: " + aggressiveLongExpansion
                            + " | Extreme: " + extremeLongMomentum
                            + " | Action: WAIT SMART RETEST"
                        );

                        rawLongReady = false;
                    }
                }

                if (rawShortReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (IsOpeningPriceChaseBlocked(
                        false,
                        rangeClose,
                        out extensionPoints,
                        out maxExtensionPoints))
                    {
                        LogOpeningPriceChaseBlock(
                            false,
                            rangeNyTime,
                            rangeClose,
                            extensionPoints,
                            maxExtensionPoints
                        );

                        ArmSmartRetest(
                            false,
                            rangeNyTime,
                            openingRangeReady ? openingRangeLow : rangeClose,
                            m5BearishBreakLevel,
                            rangeClose,
                            shortScore,
                            "OPENING PRICE EXTENDED SHORT"
                        );

                        PrintBotMessage(
                            "OPENING ANTI-CHASE OVERRIDE"
                            + " | Side: SHORT"
                            + " | Extension: " + extensionPoints.ToString("0.00") + " pts"
                            + " | Max: " + maxExtensionPoints.ToString("0.00") + " pts"
                            + " | Aggressive: " + aggressiveShortExpansion
                            + " | Extreme: " + extremeShortMomentum
                            + " | Action: WAIT SMART RETEST"
                        );

                        rawShortReady = false;
                    }
                }
            }

            // =====================================================
            // V1.6.9 - POST-MOVE EXHAUSTION GUARD
            // =====================================================
            // A mature directional move may keep producing ordinary Momentum
            // scores even after the best expansion is gone. If price is already
            // far from the session opposite extreme and current flow is weak,
            // do not keep chasing that same direction. A genuinely NEW
            // aggressive expansion is allowed through.
            double sessionUpMoveTicks;
            double sessionDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                out sessionUpMoveTicks,
                out sessionDownMoveTicks
            );

            bool weakCurrentExpansion =
                volumeRatio <=
                    ExhaustionMaxWeakVolumeRatio ||
                bodyRatio <=
                    ExhaustionMaxWeakBodyRatio;

            if (
                rawLongReady &&
                !aggressiveLongExpansion &&
                sessionUpMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    true,
                    rangeNyTime,
                    sessionUpMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    longScore
                );

                rawLongReady =
                    false;
            }

            if (
                rawShortReady &&
                !aggressiveShortExpansion &&
                sessionDownMoveTicks >=
                    ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                LogPostMoveExhaustionBlock(
                    false,
                    rangeNyTime,
                    sessionDownMoveTicks,
                    volumeRatio,
                    bodyRatio,
                    shortScore
                );

                rawShortReady =
                    false;
            }

            // =====================================================
            // V1.6.11 - SMART RETEST / NO-CHASE ENTRY ENGINE
            // =====================================================
            // Extended ordinary signals arm a short-lived pending setup instead
            // of being forgotten. Aggressive Expansion may enter immediately only
            // when the higher-priority Opening safety guards above allow it.
            if (rawLongReady && !aggressiveLongExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = longScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "EXTENDED LONG SIGNAL"
                    );
                    LogPullbackWait(true, rangeNyTime, extensionTicks, maxExtensionTicks, longScore);
                    rawLongReady = false;
                }
            }

            if (rawShortReady && !aggressiveShortExpansion)
            {
                double extensionTicks = momentumTickSize > 0
                    ? Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize)
                    : 0;
                double maxExtensionTicks = shortScore <= 3
                    ? PullbackMaxExtensionTicks3of5
                    : PullbackMaxExtensionTicks4Plus;

                if (extensionTicks > maxExtensionTicks)
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );
                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "EXTENDED SHORT SIGNAL"
                    );
                    LogPullbackWait(false, rangeNyTime, extensionTicks, maxExtensionTicks, shortScore);
                    rawShortReady = false;
                }
            }

            // V1.6.23 Phase 3 - AGGRESSIVE MATURE-MOVE HARD CAP.
            // Aggressive Expansion keeps its fast-entry privilege while fresh.
            // But if price is already extremely stretched from EMA9 AND the
            // directional session leg is mature, do not buy/sell the tail.
            // Convert it into the existing Smart Retest workflow instead.
            if (rawLongReady && aggressiveLongExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (rangeClose - emaFastCurrent) / momentumTickSize);

                if (
                    sessionUpMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks
                )
                {
                    double breakoutLevel = GetHighestHigh(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        true, rangeNyTime, breakoutLevel, m5BullishBreakLevel,
                        rangeClose, longScore, "MATURE AGGRESSIVE LONG"
                    );

                    LogPullbackWait(
                        true, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, longScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: LONG"
                        + " | SessionMove: " + sessionUpMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawLongReady = false;
                }
            }

            if (rawShortReady && aggressiveShortExpansion && momentumTickSize > 0)
            {
                double aggressiveExtensionTicks =
                    Math.Max(0, (emaFastCurrent - rangeClose) / momentumTickSize);

                if (
                    sessionDownMoveTicks >= AggressiveMatureMoveMinTicks &&
                    aggressiveExtensionTicks > AggressiveMaxEmaExtensionTicks
                )
                {
                    double breakoutLevel = GetLowestLow(
                        bars,
                        Math.Max(0, closedBarIndex - MomentumBreakoutLookback),
                        closedBarIndex - 1
                    );

                    ArmSmartRetest(
                        false, rangeNyTime, breakoutLevel, m5BearishBreakLevel,
                        rangeClose, shortScore, "MATURE AGGRESSIVE SHORT"
                    );

                    LogPullbackWait(
                        false, rangeNyTime, aggressiveExtensionTicks,
                        AggressiveMaxEmaExtensionTicks, shortScore
                    );

                    PrintBotMessage(
                        "SKIP AGGRESSIVE CHASE - MATURE MOVE"
                        + " | Side: SHORT"
                        + " | SessionMove: " + sessionDownMoveTicks.ToString("0") + "t"
                        + " | EMA9 Extension: " + aggressiveExtensionTicks.ToString("0") + "t"
                        + " | Action: SMART RETEST"
                    );

                    rawShortReady = false;
                }
            }

            // A pending setup may now be confirmed even though the original
            // breakout bar is gone. This is the actual pullback-entry layer.
            bool smartRetestLong = false;
            bool smartRetestShort = false;
            string smartRetestPattern = string.Empty;
            string smartRetestStructureSetupKey = string.Empty;

            TryConfirmSmartRetest(
                bars,
                closedBarIndex,
                rangeNyTime,
                momentumTickSize,
                rangeClose,
                longScore,
                shortScore,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                out smartRetestLong,
                out smartRetestShort,
                out smartRetestPattern,
                out smartRetestStructureSetupKey
            );

            if (smartRetestLong)
            {
                rawLongReady = true;
                rawShortReady = false;
                PrintSmartRetestConfirmed(true, rangeNyTime, smartRetestPattern, rangeClose, longScore);
            }
            else if (smartRetestShort)
            {
                rawShortReady = true;
                rawLongReady = false;
                PrintSmartRetestConfirmed(false, rangeNyTime, smartRetestPattern, rangeClose, shortScore);
            }

            // =====================================================
            // V1.6.18 - SHADOW SIGNAL DATASET
            // =====================================================
            // Capture meaningful candidates even when a later guard rejects
            // the trade. This is intentionally observational only.
            bool shadowLongCandidate =
                longScore >= MomentumMinScore ||
                extremeLongMomentum ||
                aggressiveLongExpansion ||
                highBreakout ||
                smartRetestLong;

            bool shadowShortCandidate =
                shortScore >= MomentumMinScore ||
                extremeShortMomentum ||
                aggressiveShortExpansion ||
                lowBreakout ||
                smartRetestShort;

            string shadowLongId = string.Empty;
            string shadowShortId = string.Empty;

            if (shadowLongCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    true,
                    longScore,
                    aggressiveLongExpansion,
                    extremeLongMomentum,
                    smartRetestLong,
                    highBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfLongScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        true,
                        rawLongReady,
                        allowLong,
                        premarketSession,
                        m5AboveVwap,
                        m5Bullish,
                        strictMiddayMomentum,
                        longScore,
                        htfLongScore,
                        aggressiveLongExpansion,
                        sessionUpMoveTicks,
                        weakCurrentExpansion
                    );

                shadowLongId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        true,
                        momentumSession,
                        rawLongReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        longScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        highBreakout,
                        aggressiveLongScore,
                        aggressiveLongExpansion,
                        extremeLongMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfLongScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            if (shadowShortCandidate)
            {
                int shadowConfidence;
                string shadowQuality;
                string shadowTiming;
                string shadowManipulation;
                string shadowQualityReason;

                EvaluateNasdaqSetupQuality(
                    false,
                    shortScore,
                    aggressiveShortExpansion,
                    extremeShortMomentum,
                    smartRetestShort,
                    lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    htfShortScore,
                    out shadowConfidence,
                    out shadowQuality,
                    out shadowTiming,
                    out shadowManipulation,
                    out shadowQualityReason
                );

                string shadowDecisionReason =
                    BuildShadowDecisionReason(
                        false,
                        rawShortReady,
                        allowShort,
                        premarketSession,
                        m5BelowVwap,
                        m5Bearish,
                        strictMiddayMomentum,
                        shortScore,
                        htfShortScore,
                        aggressiveShortExpansion,
                        sessionDownMoveTicks,
                        weakCurrentExpansion
                    );

                shadowShortId =
                    RegisterShadowSignalCandidate(
                        closedRangeTime,
                        rangeNyTime,
                        false,
                        momentumSession,
                        rawShortReady ? "ELIGIBLE" : "REJECTED",
                        shadowDecisionReason,
                        rangeClose,
                        shortScore,
                        rangeRatio,
                        volumeRatio,
                        bodyRatio,
                        slopeTicks,
                        lowBreakout,
                        aggressiveShortScore,
                        aggressiveShortExpansion,
                        extremeShortMomentum,
                        m5Bullish ? "BULLISH" : (m5Bearish ? "BEARISH" : "NEUTRAL"),
                        m5AboveVwap ? "ABOVE" : (m5BelowVwap ? "BELOW" : "AT"),
                        m5Structure,
                        m5Liquidity,
                        htfShortScore,
                        shadowConfidence,
                        shadowQuality,
                        shadowTiming,
                        shadowManipulation
                    );
            }

            // =====================================================
            // V1.6.15A - LIVE ANALYSIS CONFIDENCE
            // =====================================================
            // Keep an advisory percentage alive while the bot is still
            // analyzing. This does NOT authorize or block entries.
            if (
                !rawLongReady &&
                !rawShortReady
            )
            {
                bool analysisIsLong;

                if (
                    string.Equals(
                        autoResolvedDirection,
                        "LONG ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = true;
                }
                else if (
                    string.Equals(
                        autoResolvedDirection,
                        "SHORT ONLY",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    analysisIsLong = false;
                }
                else
                {
                    analysisIsLong =
                        longScore >= shortScore;
                }

                int analysisConfidence;
                string analysisQuality;
                string analysisTiming;
                string analysisManipulation;
                string analysisReason;

                EvaluateNasdaqSetupQuality(
                    analysisIsLong,
                    analysisIsLong
                        ? longScore
                        : shortScore,
                    analysisIsLong
                        ? aggressiveLongExpansion
                        : aggressiveShortExpansion,
                    analysisIsLong
                        ? extremeLongMomentum
                        : extremeShortMomentum,
                    false,
                    analysisIsLong
                        ? highBreakout
                        : lowBreakout,
                    bodyRatio,
                    volumeRatio,
                    slopeTicks,
                    m5Bullish,
                    m5Bearish,
                    m5AboveVwap,
                    m5BelowVwap,
                    m5Structure,
                    m5Liquidity,
                    analysisIsLong
                        ? htfLongScore
                        : htfShortScore,
                    out analysisConfidence,
                    out analysisQuality,
                    out analysisTiming,
                    out analysisManipulation,
                    out analysisReason
                );

                latestSetupConfidence =
                    analysisConfidence;

                latestSetupQuality =
                    analysisConfidence >= 70
                        ? analysisQuality
                        : "ANALYZING";

                latestSetupTiming =
                    "ANALYZING";

                latestManipulationState =
                    analysisManipulation;

                return;
            }

            bool selectedAggressiveExpansion =
                rawLongReady
                    ? aggressiveLongExpansion
                    : aggressiveShortExpansion;

            if (selectedAggressiveExpansion)
            {
                string aggressionLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT");

                if (
                    aggressionLogKey !=
                        lastAggressionSignalLogKey
                )
                {
                    lastAggressionSignalLogKey =
                        aggressionLogKey;

                    PrintBotMessage(
                        "AGGRESSIVE EXPANSION DETECTED"
                        + " | Side: "
                        + (rawLongReady ? "LONG" : "SHORT")
                        + " | Aggression: "
                        + (
                            rawLongReady
                                ? aggressiveLongScore
                                : aggressiveShortScore
                          )
                        + "/5"
                        + " | R20: "
                        + (
                            rawLongReady
                                ? longScore
                                : shortScore
                          )
                        + "/5"
                        + " | Displacement: "
                        + (
                            rawLongReady
                                ? aggressiveLongDisplacementTicks
                                : aggressiveShortDisplacementTicks
                          ).ToString("0")
                        + "t"
                        + " | Range x"
                        + rangeRatio.ToString("0.00")
                        + " | Volume x"
                        + volumeRatio.ToString("0.00")
                        + " | Body "
                        + (bodyRatio * 100.0).ToString("0")
                        + "%"
                        + " | EMA Slope "
                        + slopeTicks.ToString("0.0")
                        + "t"
                    );
                }
            }

            bool highConvictionMomentum =
                selectedAggressiveExpansion ||
                (
                rawLongReady
                    ? (
                        (
                            premarketSession &&
                            premarketExtremeLong
                        ) ||
                        extremeLongMomentum ||
                        (
                            longScore >= 4 &&
                            highBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                    : (
                        (
                            premarketSession &&
                            premarketExtremeShort
                        ) ||
                        extremeShortMomentum ||
                        (
                            shortScore >= 4 &&
                            lowBreakout &&
                            volumeRatio >=
                                MomentumVolumeExpansion
                        )
                      )
                );

            bool effectiveExtremeMomentum =
                premarketSession
                    ? (
                        rawLongReady
                            ? premarketExtremeLong
                            : premarketExtremeShort
                      )
                    : (
                        rawLongReady
                            ? extremeLongMomentum
                            : extremeShortMomentum
                      );

            // =====================================================
            // V1.6.15 - NASDAQ SETUP QUALITY / CONFIDENCE
            // =====================================================
            int setupConfidence;
            string setupQuality;
            string setupTiming;
            string manipulationState;
            string setupQualityReason;

            EvaluateNasdaqSetupQuality(
                rawLongReady,
                rawLongReady ? longScore : shortScore,
                selectedAggressiveExpansion,
                effectiveExtremeMomentum,
                !string.IsNullOrWhiteSpace(smartRetestPattern),
                rawLongReady ? highBreakout : lowBreakout,
                bodyRatio,
                volumeRatio,
                slopeTicks,
                m5Bullish,
                m5Bearish,
                m5AboveVwap,
                m5BelowVwap,
                m5Structure,
                m5Liquidity,
                rawLongReady ? htfLongScore : htfShortScore,
                out setupConfidence,
                out setupQuality,
                out setupTiming,
                out manipulationState,
                out setupQualityReason
            );

            latestSetupConfidence =
                setupConfidence;
            latestSetupQuality =
                setupQuality;
            latestSetupTiming =
                setupTiming;
            latestManipulationState =
                manipulationState;

            string setupQualityLogKey =
                closedRangeTime.ToString("yyyyMMddHHmmss")
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + setupConfidence
                + "|"
                + setupQuality
                + "|"
                + setupTiming
                + "|"
                + manipulationState;

            if (
                setupQualityLogKey !=
                    lastSetupQualityLogKey
            )
            {
                lastSetupQualityLogKey =
                    setupQualityLogKey;

                PrintBotMessage(
                    "SETUP QUALITY"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | "
                    + setupQuality
                    + " | Confidence: "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                    + " | "
                    + setupQualityReason
                );
            }

            currentSetupState =
                setupQuality
                + " "
                + setupConfidence
                + "% | "
                + setupTiming;

            string learningContext =
                (
                    !string.IsNullOrWhiteSpace(smartRetestPattern)
                        ? "SMART RETEST " + smartRetestPattern + " "
                        : selectedAggressiveExpansion
                        ? (
                            premarketSession
                                ? "PREMARKET AGGRESSIVE EXPANSION "
                                : "R20 AGGRESSIVE EXPANSION "
                          )
                        : (
                            premarketSession
                                ? (
                                    effectiveExtremeMomentum
                                        ? "PREMARKET R20 EXTREME MOMENTUM "
                                        : "PREMARKET R20 MOMENTUM "
                                  )
                                : (
                                    effectiveExtremeMomentum
                                        ? "R20 EXTREME MOMENTUM "
                                        : "R20 MOMENTUM "
                                  )
                          )
                )
                + (
                    rawLongReady
                        ? longScore
                        : shortScore
                )
                + "/5";

            string learningReason;

            bool learningAllowed =
                IsLearningTradeAllowed(
                    rawLongReady
                        ? "LONG"
                        : "SHORT",
                    rangeNyTime,
                    learningContext,
                    out learningReason
                );

            DateTime closedRangeNyTime =
                ConvertToNewYorkTime(
                    closedRangeTime
                );

            string rangeSignalLogKey =
                closedRangeTime.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (rawLongReady ? "LONG" : "SHORT")
                + "|"
                + (rawLongReady ? longScore : shortScore);

            if (rangeSignalLogKey != lastRangeSignalLogKey)
            {
                lastRangeSignalLogKey = rangeSignalLogKey;

                PrintBotMessage(
                    "RANGE MOMENTUM SIGNAL"
                    + (
                        premarketSession
                            ? " | PREMARKET"
                            : (
                                openingPriority
                                    ? " | OPENING FALLBACK"
                                    : string.Empty
                              )
                      )
                    + " | Bar: "
                    + closedRangeNyTime.ToString("HH:mm:ss")
                    + " ET"
                    + " | Side: "
                    + (rawLongReady ? "LONG" : "SHORT")
                    + " | R20 Score: "
                    + (rawLongReady ? longScore : shortScore)
                    + "/5"
                    + " | M5 Trend: "
                    + (
                        m5Bullish
                            ? "BULLISH"
                            : m5Bearish
                                ? "BEARISH"
                                : "NEUTRAL"
                    )
                    + " | M5 VWAP: "
                    + (
                        m5AboveVwap
                            ? "ABOVE"
                            : m5BelowVwap
                                ? "BELOW"
                                : "AT"
                    )
                    + " | M5 Structure: "
                    + m5Structure
                    + " | Quality: "
                    + setupQuality
                    + " "
                    + setupConfidence
                    + "%"
                    + " | Timing: "
                    + setupTiming
                    + " | Manipulation: "
                    + manipulationState
                );
            }

            if (!learningAllowed)
            {
                UpdateShadowSignalDecision(
                    rawLongReady
                        ? shadowLongId
                        : shadowShortId,
                    "LEARNING_BLOCKED",
                    learningReason
                );

                string learningBlockedLogKey =
                    closedRangeTime.ToString(
                        "yyyyMMddHHmmss"
                    )
                    + "|"
                    + (rawLongReady ? "LONG" : "SHORT")
                    + "|"
                    + learningContext
                    + "|"
                    + learningReason;

                if (
                    learningBlockedLogKey !=
                        lastLearningBlockedLogKey
                )
                {
                    lastLearningBlockedLogKey =
                        learningBlockedLogKey;

                    PrintBotMessage(
                        "LEARNING BLOCK RANGE"
                        + " | Bar: "
                        + closedRangeNyTime.ToString(
                            "HH:mm:ss"
                        )
                        + " ET"
                        + " | "
                        + learningReason
                    );
                }

                return;
            }

            lastLearningBlockedLogKey =
                string.Empty;

            CaptureLearningSignalContext(
                rawLongReady
                    ? "LONG"
                    : "SHORT",
                rangeNyTime,
                learningContext
            );

            pendingShadowSignalId =
                rawLongReady
                    ? shadowLongId
                    : shadowShortId;

            UpdateShadowSignalDecision(
                pendingShadowSignalId,
                "ENTRY_ATTEMPT",
                "PASSED SIGNAL + LEARNING GATES"
            );

            TrySubmitEntry(
                rawLongReady,
                closedRangeTime,
                false,
                string.IsNullOrWhiteSpace(smartRetestStructureSetupKey)
                    ? null
                    : smartRetestStructureSetupKey,
                false,
                highConvictionMomentum
            );
        }
        private void CalculateMomentumScores(
            Bars bars,
            int closedBarIndex,
            double emaFastCurrent,
            out int longScore,
            out int shortScore,
            out double rangeRatio,
            out double volumeRatio,
            out double bodyRatio,
            out double emaFastSlope,
            out bool highBreakout,
            out bool lowBreakout)
        {
            longScore = 0;
            shortScore = 0;
            rangeRatio = 0;
            volumeRatio = 0;
            bodyRatio = 0;
            emaFastSlope = 0;
            highBreakout = false;
            lowBreakout = false;

            if (
                bars == null ||
                closedBarIndex <
                    MomentumAverageLookback +
                    MomentumBreakoutLookback + 2
            )
            {
                return;
            }

            double open =
                bars.GetOpen(
                    closedBarIndex
                );

            double close =
                bars.GetClose(
                    closedBarIndex
                );

            double high =
                bars.GetHigh(
                    closedBarIndex
                );

            double low =
                bars.GetLow(
                    closedBarIndex
                );

            double currentRange =
                Math.Max(
                    0,
                    high - low
                );

            double currentBody =
                Math.Abs(
                    close - open
                );

            bodyRatio =
                currentRange > 0
                    ? currentBody /
                        currentRange
                    : 0;

            double averageRange = 0;
            double averageVolume = 0;

            for (
                int i = closedBarIndex -
                    MomentumAverageLookback;
                i < closedBarIndex;
                i++
            )
            {
                averageRange +=
                    Math.Max(
                        0,
                        bars.GetHigh(i) -
                        bars.GetLow(i)
                    );

                averageVolume +=
                    bars.GetVolume(i);
            }

            averageRange /=
                MomentumAverageLookback;

            averageVolume /=
                MomentumAverageLookback;

            rangeRatio =
                averageRange > 0
                    ? currentRange /
                        averageRange
                    : 0;

            double currentVolume =
                bars.GetVolume(
                    closedBarIndex
                );

            volumeRatio =
                averageVolume > 0
                    ? currentVolume /
                        averageVolume
                    : 0;

            double emaFastPrevious =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex - 1
                );

            emaFastSlope =
                emaFastCurrent -
                emaFastPrevious;

            double previousHighest =
                double.MinValue;

            double previousLowest =
                double.MaxValue;

            for (
                int i = closedBarIndex -
                    MomentumBreakoutLookback;
                i < closedBarIndex;
                i++
            )
            {
                previousHighest =
                    Math.Max(
                        previousHighest,
                        bars.GetHigh(i)
                    );

                previousLowest =
                    Math.Min(
                        previousLowest,
                        bars.GetLow(i)
                    );
            }

            highBreakout =
                close > previousHighest;

            lowBreakout =
                close < previousLowest;

            bool bullishCandle =
                close > open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool bearishCandle =
                close < open &&
                bodyRatio >=
                    MomentumMinBodyRatio;

            bool rangeExpanded =
                rangeRatio >=
                    MomentumRangeExpansion;

            bool volumeExpanded =
                volumeRatio >=
                    MomentumVolumeExpansion;

            bool emaRising =
                emaFastSlope > 0;

            bool emaFalling =
                emaFastSlope < 0;

            // Five independent components:
            // 1) strong directional body
            // 2) EMA9 slope
            // 3) range expansion
            // 4) relative volume expansion
            // 5) close breakout of recent bars
            if (bullishCandle)
                longScore++;

            if (emaRising)
                longScore++;

            if (rangeExpanded)
                longScore++;

            if (volumeExpanded)
                longScore++;

            if (highBreakout)
                longScore++;

            if (bearishCandle)
                shortScore++;

            if (emaFalling)
                shortScore++;

            if (rangeExpanded)
                shortScore++;

            if (volumeExpanded)
                shortScore++;

            if (lowBreakout)
                shortScore++;
        }

    }
}

﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Media;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT PROP NEWS COMPLIANCE GUARD - V1.6.46
    // =========================================================
    // Purpose:
    // - Protect mixed prop-firm portfolios/copy groups from news-rule breaches.
    // - Use the strictest mandatory timing currently present in the user's
    //   active prop-firm set: MFFU = flat/no orders from T-2m through T+2m.
    // - Apply that same 2-minute window to timed USD data releases so a master
    //   account cannot copy a trade into a more restrictive follower account.
    //
    // IMPORTANT:
    // This is NOT another strategy-quality filter. Outside the 4-minute
    // compliance window it has zero influence on R20, Opening, Structure,
    // Learning, L2, Smart Retest, Quality Score, or execution timing.
    // =========================================================
    public partial class JJBotWindow
    {
        private sealed class JJNewsEvent
        {
            public string Title;
            public string Country;
            public string Impact;
            public DateTime TimeNy;
        }

        private const string NewsCalendarUrl =
            "https://nfs.faireconomy.media/ff_calendar_thisweek.json";

        private const int PropNewsMinutesBefore = 2;
        private const int PropNewsMinutesAfter = 2;
        private const int NewsCalendarRefreshMinutes = 15;
        private const int NewsCalendarMaxCacheHours = 30;

        private readonly object newsGuardLock = new object();
        private readonly List<JJNewsEvent> propNewsEvents = new List<JJNewsEvent>();

        private DateTime newsCalendarLastFetchUtc = DateTime.MinValue;
        private DateTime newsCalendarLastSuccessUtc = DateTime.MinValue;
        private DateTime newsCalendarLastLogUtc = DateTime.MinValue;
        private bool newsCalendarFetchInProgress;
        private bool newsCalendarLoaded;
        private string newsCalendarLastError = string.Empty;
        private string newsLastFlattenKey = string.Empty;
        private string newsLastBlockLogKey = string.Empty;
        private string newsLastNextEventLogKey = string.Empty;

        private string GetNewsCalendarCachePath()
        {
            string documents =
                Environment.GetFolderPath(
                    Environment.SpecialFolder.MyDocuments
                );

            string folder =
                Path.Combine(
                    documents,
                    "JJ Trading Tools",
                    "News"
                );

            Directory.CreateDirectory(folder);

            return Path.Combine(
                folder,
                "ff_calendar_thisweek.json"
            );
        }

        private string JsonUnescape(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            return value
                .Replace("\\/", "/")
                .Replace("\\\"", "\"")
                .Replace("\\\\", "\\");
        }

        private List<JJNewsEvent> ParseNewsCalendar(string json)
        {
            List<JJNewsEvent> parsed =
                new List<JJNewsEvent>();

            if (string.IsNullOrWhiteSpace(json))
                return parsed;

            Regex eventRegex =
                new Regex(
                    "\\{\\\"title\\\":\\\"(?<title>(?:\\\\.|[^\\\"])*)\\\","
                    + "\\\"country\\\":\\\"(?<country>(?:\\\\.|[^\\\"])*)\\\","
                    + "\\\"date\\\":\\\"(?<date>(?:\\\\.|[^\\\"])*)\\\","
                    + "\\\"impact\\\":\\\"(?<impact>(?:\\\\.|[^\\\"])*)\\\"",
                    RegexOptions.Compiled |
                    RegexOptions.CultureInvariant
                );

            MatchCollection matches =
                eventRegex.Matches(json);

            foreach (Match match in matches)
            {
                string country =
                    JsonUnescape(
                        match.Groups["country"].Value
                    );

                // The current bot trades U.S. equity-index futures. For prop
                // compliance, only timed USD releases are relevant here.
                if (
                    !string.Equals(
                        country,
                        "USD",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    continue;
                }

                string rawDate =
                    JsonUnescape(
                        match.Groups["date"].Value
                    );

                DateTimeOffset parsedOffset;

                if (
                    !DateTimeOffset.TryParse(
                        rawDate,
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind,
                        out parsedOffset
                    )
                )
                {
                    continue;
                }

                // FairEconomy/ForexFactory's JSON export supplies an explicit
                // Eastern offset (-04:00/-05:00). DateTime retains that New York
                // wall-clock value for direct comparison with nowNy.
                DateTime eventNy =
                    DateTime.SpecifyKind(
                        parsedOffset.DateTime,
                        DateTimeKind.Unspecified
                    );

                parsed.Add(
                    new JJNewsEvent
                    {
                        Title = JsonUnescape(match.Groups["title"].Value),
                        Country = country,
                        Impact = JsonUnescape(match.Groups["impact"].Value),
                        TimeNy = eventNy
                    }
                );
            }

            parsed.Sort(
                delegate(JJNewsEvent a, JJNewsEvent b)
                {
                    return a.TimeNy.CompareTo(b.TimeNy);
                }
            );

            return parsed;
        }

        private void ReplaceNewsEvents(
            List<JJNewsEvent> events,
            DateTime successUtc)
        {
            lock (newsGuardLock)
            {
                propNewsEvents.Clear();
                propNewsEvents.AddRange(events);
                newsCalendarLoaded = events.Count > 0;
                newsCalendarLastSuccessUtc = successUtc;
                newsCalendarLastError = string.Empty;
            }
        }

        private bool TryLoadNewsCalendarCache()
        {
            try
            {
                string path =
                    GetNewsCalendarCachePath();

                if (!File.Exists(path))
                    return false;

                DateTime writeUtc =
                    File.GetLastWriteTimeUtc(path);

                if (
                    (DateTime.UtcNow - writeUtc).TotalHours >
                    NewsCalendarMaxCacheHours
                )
                {
                    return false;
                }

                string json =
                    File.ReadAllText(path);

                List<JJNewsEvent> events =
                    ParseNewsCalendar(json);

                if (events.Count == 0)
                    return false;

                ReplaceNewsEvents(
                    events,
                    writeUtc
                );

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void EnsureNewsCalendarRefresh()
        {
            DateTime nowUtc = DateTime.UtcNow;

            lock (newsGuardLock)
            {
                if (
                    newsCalendarFetchInProgress ||
                    (
                        newsCalendarLastFetchUtc != DateTime.MinValue &&
                        (nowUtc - newsCalendarLastFetchUtc).TotalMinutes <
                            NewsCalendarRefreshMinutes
                    )
                )
                {
                    return;
                }

                newsCalendarFetchInProgress = true;
                newsCalendarLastFetchUtc = nowUtc;
            }

            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    try
                    {
                        string json;

                        using (WebClient client = new WebClient())
                        {
                            client.Headers[HttpRequestHeader.UserAgent] =
                                "JJTradingTools-NewsGuard/1.0";

                            json =
                                client.DownloadString(
                                    NewsCalendarUrl
                                );
                        }

                        List<JJNewsEvent> events =
                            ParseNewsCalendar(json);

                        if (events.Count == 0)
                        {
                            throw new Exception(
                                "calendar returned no timed USD events"
                            );
                        }

                        try
                        {
                            File.WriteAllText(
                                GetNewsCalendarCachePath(),
                                json
                            );
                        }
                        catch
                        {
                            // Cache persistence is best-effort only.
                        }

                        ReplaceNewsEvents(
                            events,
                            DateTime.UtcNow
                        );
                    }
                    catch (Exception ex)
                    {
                        bool loadedCache = false;

                        lock (newsGuardLock)
                        {
                            if (!newsCalendarLoaded)
                            {
                                // Load outside the lock below.
                                loadedCache = true;
                            }
                        }

                        if (loadedCache)
                            TryLoadNewsCalendarCache();

                        lock (newsGuardLock)
                        {
                            newsCalendarLastError =
                                ex.Message;
                        }
                    }
                    finally
                    {
                        lock (newsGuardLock)
                        {
                            newsCalendarFetchInProgress = false;
                        }
                    }
                }
            );
        }

        private bool TryGetActivePropNewsWindow(
            DateTime nowNy,
            out JJNewsEvent activeEvent,
            out DateTime windowStart,
            out DateTime windowEnd)
        {
            activeEvent = null;
            windowStart = DateTime.MinValue;
            windowEnd = DateTime.MinValue;

            EnsureNewsCalendarRefresh();

            List<JJNewsEvent> snapshot =
                new List<JJNewsEvent>();

            bool loaded;
            DateTime lastSuccessUtc;

            lock (newsGuardLock)
            {
                loaded = newsCalendarLoaded;
                lastSuccessUtc = newsCalendarLastSuccessUtc;

                if (loaded)
                    snapshot.AddRange(propNewsEvents);
            }

            if (!loaded)
                return false;

            // Never trust a stale calendar indefinitely. A weekly file can be
            // cached overnight/weekend, but not beyond the safety horizon.
            if (
                lastSuccessUtc != DateTime.MinValue &&
                (DateTime.UtcNow - lastSuccessUtc).TotalHours >
                    NewsCalendarMaxCacheHours
            )
            {
                return false;
            }

            foreach (JJNewsEvent newsEvent in snapshot)
            {
                DateTime start =
                    newsEvent.TimeNy.AddMinutes(
                        -PropNewsMinutesBefore
                    );

                DateTime end =
                    newsEvent.TimeNy.AddMinutes(
                        PropNewsMinutesAfter
                    );

                if (
                    nowNy >= start &&
                    nowNy <= end
                )
                {
                    activeEvent = newsEvent;
                    windowStart = start;
                    windowEnd = end;
                    return true;
                }
            }

            return false;
        }

        private bool IsPropNewsComplianceBlocked(
            DateTime nowNy,
            out string reason)
        {
            reason = string.Empty;

            // Fail closed for NEW ENTRIES when the calendar is unavailable or
            // stale. This prevents the bot from opening a prop trade while it
            // cannot prove that the current minute is news-safe. Existing
            // positions are not blindly flattened merely because the feed is
            // temporarily unavailable.
            EnsureNewsCalendarRefresh();

            bool calendarUsable;
            string calendarError;
            DateTime lastSuccessUtc;

            lock (newsGuardLock)
            {
                lastSuccessUtc = newsCalendarLastSuccessUtc;
                calendarError = newsCalendarLastError;

                calendarUsable =
                    newsCalendarLoaded &&
                    lastSuccessUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - lastSuccessUtc).TotalHours <=
                        NewsCalendarMaxCacheHours;
            }

            if (!calendarUsable)
            {
                reason =
                    "NEWS CALENDAR NOT READY"
                    + (
                        string.IsNullOrWhiteSpace(calendarError)
                            ? string.Empty
                            : " | " + calendarError
                      );

                return true;
            }

            JJNewsEvent activeEvent;
            DateTime start;
            DateTime end;

            if (
                TryGetActivePropNewsWindow(
                    nowNy,
                    out activeEvent,
                    out start,
                    out end
                )
            )
            {
                reason =
                    "USD "
                    + (activeEvent.Impact ?? "")
                    + " | "
                    + (activeEvent.Title ?? "NEWS")
                    + " | Event "
                    + activeEvent.TimeNy.ToString("HH:mm:ss")
                    + " ET"
                    + " | Flat/No Entry "
                    + start.ToString("HH:mm:ss")
                    + "-"
                    + end.ToString("HH:mm:ss")
                    + " ET";

                return true;
            }

            return false;
        }


        // =====================================================
        // V1.6.46 - NEXT NEWS VISIBILITY / TELEMETRY
        // Observational only. It does not add an entry filter and it does
        // not change the existing +/-2 minute compliance behavior.
        // =====================================================
        private bool TryGetNextPropNewsEvent(
            DateTime nowNy,
            out JJNewsEvent nextEvent,
            out DateTime guardStart,
            out DateTime guardEnd,
            out bool activeNow)
        {
            nextEvent = null;
            guardStart = DateTime.MinValue;
            guardEnd = DateTime.MinValue;
            activeNow = false;

            EnsureNewsCalendarRefresh();

            List<JJNewsEvent> snapshot =
                new List<JJNewsEvent>();

            bool usable;
            DateTime lastSuccessUtc;

            lock (newsGuardLock)
            {
                lastSuccessUtc = newsCalendarLastSuccessUtc;

                usable =
                    newsCalendarLoaded &&
                    lastSuccessUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - lastSuccessUtc).TotalHours <=
                        NewsCalendarMaxCacheHours;

                if (usable)
                    snapshot.AddRange(propNewsEvents);
            }

            if (!usable)
                return false;

            foreach (JJNewsEvent newsEvent in snapshot)
            {
                DateTime start =
                    newsEvent.TimeNy.AddMinutes(
                        -PropNewsMinutesBefore
                    );

                DateTime end =
                    newsEvent.TimeNy.AddMinutes(
                        PropNewsMinutesAfter
                    );

                // Keep the currently-active event visible through the end of
                // its compliance window. Otherwise show the next future one.
                if (nowNy <= end)
                {
                    nextEvent = newsEvent;
                    guardStart = start;
                    guardEnd = end;
                    activeNow =
                        nowNy >= start &&
                        nowNy <= end;

                    return true;
                }
            }

            return false;
        }

        private void GetNewsGuardDisplaySnapshot(
            DateTime nowNy,
            out string title,
            out string impact,
            out string eventTime,
            out string guardWindow,
            out string status)
        {
            title = "--";
            impact = "--";
            eventTime = "--";
            guardWindow = "--";
            status = "CALENDAR NOT READY";

            string lastError;
            bool calendarUsable;
            DateTime lastSuccessUtc;

            lock (newsGuardLock)
            {
                lastError = newsCalendarLastError;
                lastSuccessUtc = newsCalendarLastSuccessUtc;

                calendarUsable =
                    newsCalendarLoaded &&
                    lastSuccessUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - lastSuccessUtc).TotalHours <=
                        NewsCalendarMaxCacheHours;
            }

            if (!calendarUsable)
            {
                status =
                    string.IsNullOrWhiteSpace(lastError)
                        ? "CALENDAR NOT READY"
                        : "CALENDAR ERROR";

                return;
            }

            JJNewsEvent nextEvent;
            DateTime start;
            DateTime end;
            bool activeNow;

            if (
                !TryGetNextPropNewsEvent(
                    nowNy,
                    out nextEvent,
                    out start,
                    out end,
                    out activeNow
                ) ||
                nextEvent == null
            )
            {
                title = "NO MORE USD NEWS";
                impact = "--";
                eventTime = "--";
                guardWindow = "--";
                status = "CLEAR";
                return;
            }

            title =
                string.IsNullOrWhiteSpace(nextEvent.Title)
                    ? "USD NEWS"
                    : nextEvent.Title;

            impact =
                string.IsNullOrWhiteSpace(nextEvent.Impact)
                    ? "UNKNOWN"
                    : nextEvent.Impact.ToUpperInvariant();

            eventTime =
                nextEvent.TimeNy.ToString(
                    "ddd MM/dd HH:mm:ss"
                ) + " ET";

            guardWindow =
                start.ToString("HH:mm:ss")
                + " - "
                + end.ToString("HH:mm:ss")
                + " ET";

            if (activeNow)
            {
                status = "BLOCKED / FLAT REQUIRED";
            }
            else
            {
                TimeSpan untilGuard =
                    start - nowNy;

                if (untilGuard.TotalSeconds > 0)
                {
                    if (untilGuard.TotalHours >= 1)
                    {
                        status =
                            "READY | Guard in "
                            + ((int)untilGuard.TotalHours).ToString()
                            + "h "
                            + untilGuard.Minutes.ToString()
                            + "m";
                    }
                    else
                    {
                        status =
                            "READY | Guard in "
                            + Math.Max(0, (int)Math.Ceiling(untilGuard.TotalMinutes)).ToString()
                            + "m";
                    }
                }
                else
                {
                    status = "READY";
                }
            }
        }

        private void UpdateNewsGuardDisplay()
        {
            DateTime nowNy;

            try
            {
                nowNy = GetCurrentNewYorkTime();
            }
            catch
            {
                nowNy = DateTime.Now;
            }

            string title;
            string impact;
            string eventTime;
            string guardWindow;
            string status;

            GetNewsGuardDisplaySnapshot(
                nowNy,
                out title,
                out impact,
                out eventTime,
                out guardWindow,
                out status
            );

            Action updateUi =
                new Action(() =>
                {
                    if (newsNextText != null)
                        newsNextText.Text = title;

                    if (newsImpactText != null)
                    {
                        newsImpactText.Text = impact;

                        if (
                            impact.IndexOf(
                                "HIGH",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0
                        )
                        {
                            newsImpactText.Foreground = Brushes.OrangeRed;
                        }
                        else
                        {
                            newsImpactText.Foreground = Brushes.Goldenrod;
                        }
                    }

                    if (newsEventTimeText != null)
                        newsEventTimeText.Text = eventTime;

                    if (newsGuardWindowText != null)
                        newsGuardWindowText.Text = guardWindow;

                    if (newsGuardStatusText != null)
                    {
                        newsGuardStatusText.Text = status;

                        if (
                            status.IndexOf(
                                "BLOCKED",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0 ||
                            status.IndexOf(
                                "NOT READY",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0 ||
                            status.IndexOf(
                                "ERROR",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0
                        )
                        {
                            newsGuardStatusText.Foreground = Brushes.OrangeRed;
                        }
                        else
                        {
                            newsGuardStatusText.Foreground = Brushes.LimeGreen;
                        }
                    }
                });

            if (Dispatcher.CheckAccess())
                updateUi();
            else
                Dispatcher.BeginInvoke(updateUi);

            // Log only when the displayed event changes. No 3-second spam.
            if (title != "--" && title != "NO MORE USD NEWS")
            {
                string eventKey =
                    title
                    + "|"
                    + eventTime;

                if (
                    !string.Equals(
                        newsLastNextEventLogKey,
                        eventKey,
                        StringComparison.Ordinal
                    )
                )
                {
                    newsLastNextEventLogKey = eventKey;

                    PrintBotMessage(
                        "NEWS CALENDAR READY"
                        + " | Next: USD "
                        + impact
                        + " | "
                        + title
                        + " | Event "
                        + eventTime
                        + " | Guard "
                        + guardWindow
                    );
                }
            }
        }

        private void GetNewsGuardTelemetry(
            out string nextTitle,
            out string nextImpact,
            out string nextEventTimeEt,
            out string guardWindowEt,
            out string guardStatus)
        {
            DateTime nowNy;

            try
            {
                nowNy = GetCurrentNewYorkTime();
            }
            catch
            {
                nowNy = DateTime.Now;
            }

            GetNewsGuardDisplaySnapshot(
                nowNy,
                out nextTitle,
                out nextImpact,
                out nextEventTimeEt,
                out guardWindowEt,
                out guardStatus
            );
        }

        private void ApplyPropNewsComplianceGuard(
            DateTime nowNy)
        {
            string reason;

            bool blocked =
                IsPropNewsComplianceBlocked(
                    nowNy,
                    out reason
                );

            if (!blocked)
                return;

            JJNewsEvent activeEvent;
            DateTime start;
            DateTime end;

            if (
                !TryGetActivePropNewsWindow(
                    nowNy,
                    out activeEvent,
                    out start,
                    out end
                ) ||
                activeEvent == null
            )
            {
                return;
            }

            string eventKey =
                activeEvent.TimeNy.ToString("yyyyMMdd-HHmmss")
                + "|"
                + (activeEvent.Title ?? "NEWS");

            if (
                !string.Equals(
                    newsLastBlockLogKey,
                    eventKey,
                    StringComparison.Ordinal
                )
            )
            {
                newsLastBlockLogKey = eventKey;

                PrintBotMessage(
                    "NEWS COMPLIANCE ACTIVE"
                    + " | "
                    + reason
                    + " | Policy: UNIVERSAL PROP SAFE +/-2M"
                );
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (isFlat)
                return;

            if (
                string.Equals(
                    newsLastFlattenKey,
                    eventKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            newsLastFlattenKey = eventKey;

            try
            {
                activeForcedExitReason =
                    "NEWS_COMPLIANCE";

                executionStatus =
                    "NEWS COMPLIANCE FLAT";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "NEWS COMPLIANCE FORCE FLAT"
                    + " | "
                    + reason
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                );

                selectedAccount.Flatten(
                    new[]
                    {
                        selectedInstrument
                    }
                );
            }
            catch (Exception ex)
            {
                // Permit a retry on the next market-data cycle if the flatten
                // call itself fails.
                newsLastFlattenKey = string.Empty;

                PrintBotMessage(
                    "NEWS COMPLIANCE FLATTEN ERROR: "
                    + ex.Message
                );
            }
        }
    }
}

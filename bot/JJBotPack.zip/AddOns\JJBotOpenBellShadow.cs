#region Using declarations
using System;
using System.Globalization;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.67 - OPEN BELL SHADOW (LOG ONLY)
    // Never sends, changes or cancels orders. It simulates two virtual trades per day
    // from the same 09:29:58 decision point of the Open Bell and writes lines "OB SHADOW |"
    // to the bot log, so the idea can be validated with real ticks before using it:
    //   Leg1   : range < 61 -> virtual LONG, range >= 61 -> virtual SHORT (SL 33.5 / TP 30.5 pts)
    //   Reverse: if Leg1 hits its stop, a virtual trade in the opposite direction starts at
    //            the stop price with the same SL / TP. Everything is closed at 10:00 NY.
    // Slippage / stop slippage match the 277-day study (0.25 pts entry, 0.25 pts on stops).
    // =========================================================
    internal sealed class JJOpenBellShadowSim
    {
        private const double SlPts = 33.5;
        private const double TpPts = 30.5;
        private const double Slip = 0.25;
        private static readonly TimeSpan EndTod = new TimeSpan(10, 0, 0);

        private readonly object sync = new object();

        private DateTime day = DateTime.MinValue;
        private int state;          // 0 idle, 1 leg1 open, 2 reverse open, 3 finished
        private int side;           // +1 long, -1 short (current leg)
        private int leg1Side;
        private double entry;
        private double leg1Entry;
        private DateTime entryTime = DateTime.MinValue;
        private double mfe;
        private double mae;
        private double rangePts;
        private double leg1Pts;
        private double revPts;
        private bool reversed;

        public Action<string> Log;

        private static string F(double v)
        {
            return v.ToString("0.00", CultureInfo.InvariantCulture);
        }

        private static string SideName(int s)
        {
            return s > 0 ? "LONG" : "SHORT";
        }

        private void Write(string message)
        {
            Action<string> log = Log;
            if (log != null)
                log("OB SHADOW | " + message);
        }

        public void Start(DateTime ny, double range, double price, double threshold)
        {
            lock (sync)
            {
                if (day == ny.Date && state != 0)
                    return;

                day = ny.Date;
                rangePts = range;
                leg1Side = range < threshold ? 1 : -1;
                side = leg1Side;
                entry = price + side * Slip;
                leg1Entry = entry;
                entryTime = ny;
                mfe = 0.0;
                mae = 0.0;
                leg1Pts = 0.0;
                revPts = 0.0;
                reversed = false;
                state = 1;

                Write("START | Range " + F(range) + " | Leg1 " + SideName(side)
                    + " | Entry " + F(entry) + " | SL " + F(SlPts) + " pts | TP " + F(TpPts) + " pts | End 10:00 NY");
            }
        }

        public void OnTick(DateTime ny, double price)
        {
            lock (sync)
            {
                if (state != 1 && state != 2)
                    return;

                if (ny.Date != day)
                {
                    state = 0;
                    return;
                }

                double fav = side * (price - entry);
                if (fav > mfe) mfe = fav;
                if (fav < mae) mae = fav;

                if (ny.TimeOfDay >= EndTod)
                {
                    CloseLeg(ny, "TIME", fav, price);
                    return;
                }

                if (fav <= -SlPts)
                {
                    CloseLeg(ny, "SL", -SlPts - Slip, price);
                    return;
                }

                if (fav >= TpPts)
                {
                    CloseLeg(ny, "TP", TpPts, price);
                    return;
                }
            }
        }

        private void CloseLeg(DateTime ny, string how, double pts, double price)
        {
            double seconds = (ny - entryTime).TotalSeconds;
            string legName = state == 1 ? "LEG1" : "REVERSE";

            Write(legName + " END | " + SideName(side) + " | " + how
                + " | Pts " + F(pts) + " | USD per MNQ " + F(pts * 2.0)
                + " | MFE " + F(mfe) + " | MAE " + F(mae)
                + " | Seconds " + F(seconds));

            if (state == 1)
            {
                leg1Pts = pts;

                if (how == "SL")
                {
                    // Reverse trade starts at the stop price of Leg1 (opposite direction).
                    double stopPrice = leg1Entry - leg1Side * SlPts;
                    side = -leg1Side;
                    entry = stopPrice + side * Slip;
                    entryTime = ny;
                    mfe = 0.0;
                    mae = 0.0;
                    reversed = true;
                    state = 2;

                    Write("REVERSE START | " + SideName(side) + " | Entry " + F(entry)
                        + " | SL " + F(SlPts) + " pts | TP " + F(TpPts) + " pts | End 10:00 NY");

                    // Price may already be beyond the reverse stop/target (gap); the next tick decides it.
                    return;
                }
            }
            else
            {
                revPts = pts;
            }

            state = 3;
            double total = leg1Pts + revPts;
            Write("DAY | Range " + F(rangePts) + " | Leg1 " + SideName(leg1Side) + " " + F(leg1Pts) + " pts"
                + " | Reverse " + (reversed ? F(revPts) + " pts" : "none")
                + " | Total " + F(total) + " pts | USD per MNQ " + F(total * 2.0));
        }
    }

    public partial class JJBotWindow
    {
        // V1.7.67 - log-only shadow simulation of the Open Bell (see JJOpenBellShadowSim).
        private readonly JJOpenBellShadowSim openBellShadowSim = new JJOpenBellShadowSim();

        private void OpenBellShadowStart(DateTime ny, double rangePts, double price)
        {
            try
            {
                if (openBellShadowSim.Log == null)
                    openBellShadowSim.Log = delegate (string m) { PrintBotMessage(m); };

                openBellShadowSim.Start(ny, rangePts, price, Core20OpenBellRangeThresholdPts);
            }
            catch
            {
            }
        }

        private void OpenBellShadowTick(DateTime ny, double price)
        {
            try
            {
                openBellShadowSim.OnTick(ny, price);
            }
            catch
            {
            }
        }
    }
}

#region Using declarations
using System;
using System.Globalization;
using System.IO;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.67 - OPEN BELL SHADOW (LOG ONLY)
    // Never sends, changes or cancels orders. It simulates two virtual trades per day
    // from the same 09:29:58 decision point of the Open Bell and writes lines "OB SHADOW |"
    // to the bot log, so the idea can be validated with real ticks before using it:
    //   Leg1   : range < 61 -> virtual LONG, range >= 61 -> virtual SHORT (SL 33.5 / TP 30.5 pts)
    //   Reverse: if Leg1 hits its stop, a virtual trade in the opposite direction starts at
    //            the stop price with the same SL / TP. Everything is closed at 10:00 NY.
    // Slippage / stop slippage match the 277-day study (0.25 pts entry, 0.25 pts on stops).
    // =========================================================
    internal sealed class JJOpenBellShadowSim
    {
        private const double SlPts = 33.5;
        private const double TpPts = 30.5;
        private const double Slip = 0.25;
        private static readonly TimeSpan EndTod = new TimeSpan(10, 0, 0);

        private readonly object sync = new object();

        private DateTime day = DateTime.MinValue;
        private int state;          // 0 idle, 1 leg1 open, 2 reverse open, 3 finished
        private int side;           // +1 long, -1 short (current leg)
        private int leg1Side;
        private double entry;
        private double leg1Entry;
        private DateTime entryTime = DateTime.MinValue;
        private double mfe;
        private double mae;
        private double rangePts;
        private double leg1Pts;
        private double revPts;
        private bool reversed;

        public Action<string> Log;

        private static string F(double v)
        {
            return v.ToString("0.00", CultureInfo.InvariantCulture);
        }

        private static string SideName(int s)
        {
            return s > 0 ? "LONG" : "SHORT";
        }

        private void Write(string message)
        {
            Action<string> log = Log;
            if (log != null)
                log("OB SHADOW | " + message);
        }

        public void Start(DateTime ny, double range, double price, double threshold)
        {
            lock (sync)
            {
                if (day == ny.Date && state != 0)
                    return;

                day = ny.Date;
                rangePts = range;
                leg1Side = range < threshold ? 1 : -1;
                side = leg1Side;
                entry = price + side * Slip;
                leg1Entry = entry;
                entryTime = ny;
                mfe = 0.0;
                mae = 0.0;
                leg1Pts = 0.0;
                revPts = 0.0;
                reversed = false;
                state = 1;

                Write("START | Range " + F(range) + " | Leg1 " + SideName(side)
                    + " | Entry " + F(entry) + " | SL " + F(SlPts) + " pts | TP " + F(TpPts) + " pts | End 10:00 NY");
            }
        }

        public void OnTick(DateTime ny, double price)
        {
            lock (sync)
            {
                if (state != 1 && state != 2)
                    return;

                if (ny.Date != day)
                {
                    state = 0;
                    return;
                }

                double fav = side * (price - entry);
                if (fav > mfe) mfe = fav;
                if (fav < mae) mae = fav;

                if (ny.TimeOfDay >= EndTod)
                {
                    CloseLeg(ny, "TIME", fav, price);
                    return;
                }

                if (fav <= -SlPts)
                {
                    CloseLeg(ny, "SL", -SlPts - Slip, price);
                    return;
                }

                if (fav >= TpPts)
                {
                    CloseLeg(ny, "TP", TpPts, price);
                    return;
                }
            }
        }

        private void CloseLeg(DateTime ny, string how, double pts, double price)
        {
            double seconds = (ny - entryTime).TotalSeconds;
            string legName = state == 1 ? "LEG1" : "REVERSE";

            Write(legName + " END | " + SideName(side) + " | " + how
                + " | Pts " + F(pts) + " | USD per MNQ " + F(pts * 2.0)
                + " | MFE " + F(mfe) + " | MAE " + F(mae)
                + " | Seconds " + F(seconds));

            if (state == 1)
            {
                leg1Pts = pts;

                if (how == "SL")
                {
                    // Reverse trade starts at the stop price of Leg1 (opposite direction).
                    double stopPrice = leg1Entry - leg1Side * SlPts;
                    side = -leg1Side;
                    entry = stopPrice + side * Slip;
                    entryTime = ny;
                    mfe = 0.0;
                    mae = 0.0;
                    reversed = true;
                    state = 2;

                    Write("REVERSE START | " + SideName(side) + " | Entry " + F(entry)
                        + " | SL " + F(SlPts) + " pts | TP " + F(TpPts) + " pts | End 10:00 NY");

                    // Price may already be beyond the reverse stop/target (gap); the next tick decides it.
                    return;
                }
            }
            else
            {
                revPts = pts;
            }

            state = 3;
            double total = leg1Pts + revPts;
            Write("DAY | Range " + F(rangePts) + " | Leg1 " + SideName(leg1Side) + " " + F(leg1Pts) + " pts"
                + " | Reverse " + (reversed ? F(revPts) + " pts" : "none")
                + " | Total " + F(total) + " pts | USD per MNQ " + F(total * 2.0));
        }
    }

    // =========================================================
    // V1.7.95 - OPEN BELL "LONG DAY" SHADOW (LOG ONLY)
    // Every day the range says LONG (< 61 pts) it simulates, from the SAME 09:29:58 price,
    // a virtual LONG and a virtual SHORT (SL 33.5 / TP 30.5 pts, flat 10:00) and records
    // the tape delta 09:25-09:29:58 and whether the LONG TAPE VETO fired.
    // Question it answers: on days of LONG + tape against (veto), does an immediate SHORT
    // reach TP? (19-oct and 20-oct: LONG vetoed, a SHORT at 09:29:58 would have hit TP.)
    // One row per day in JJBotData\Learning\openbell_long_days_shadow.csv. Never sends orders.
    // =========================================================
    internal sealed class JJOpenBellLongDayShadow
    {
        private const double SlPts = 33.5;
        private const double TpPts = 30.5;
        private const double Slip = 0.25;
        private static readonly TimeSpan EndTod = new TimeSpan(10, 0, 0);

        private sealed class Leg
        {
            public int Side;
            public double Entry;
            public double Mfe;
            public double Mae;
            public bool Done;
            public string How = string.Empty;
            public double Pts;
            public double Seconds;
        }

        private readonly object sync = new object();
        private DateTime day = DateTime.MinValue;
        private bool active;
        private bool written;
        private DateTime startNy;
        private double rangePts;
        private double tapeDelta;
        private int tapeSnaps;
        private bool vetoed;
        private double price0;
        private Leg longLeg;
        private Leg shortLeg;

        public Action<string> Log;
        public Func<string> RootFolder;

        private static string F(double v)
        {
            return v.ToString("0.00", CultureInfo.InvariantCulture);
        }

        public void Start(DateTime ny, double range, double price, double tape, int snaps, bool longVetoed)
        {
            lock (sync)
            {
                if (day == ny.Date)
                    return;

                day = ny.Date;
                active = true;
                written = false;
                startNy = ny;
                rangePts = range;
                tapeDelta = tape;
                tapeSnaps = snaps;
                vetoed = longVetoed;
                price0 = price;
                longLeg = new Leg { Side = 1, Entry = price + Slip };
                shortLeg = new Leg { Side = -1, Entry = price - Slip };

                Write("START | Range " + F(range) + " | Tape " + tape.ToString("0", CultureInfo.InvariantCulture)
                    + " (" + snaps + " snaps) | LongVeto " + (longVetoed ? "YES" : "NO")
                    + " | Price " + F(price) + " | Virtual LONG + SHORT | SL " + F(SlPts) + " / TP " + F(TpPts) + " pts");
            }
        }

        public void OnTick(DateTime ny, double price)
        {
            lock (sync)
            {
                if (!active)
                    return;

                if (ny.Date != day)
                {
                    active = false;
                    return;
                }

                bool timeUp = ny.TimeOfDay >= EndTod;
                Step(longLeg, ny, price, timeUp);
                Step(shortLeg, ny, price, timeUp);

                if (longLeg.Done && shortLeg.Done)
                    Finish();
            }
        }

        private void Step(Leg leg, DateTime ny, double price, bool timeUp)
        {
            if (leg.Done)
                return;

            double fav = leg.Side * (price - leg.Entry);
            if (fav > leg.Mfe) leg.Mfe = fav;
            if (fav < leg.Mae) leg.Mae = fav;

            string how = null;
            double pts = 0.0;

            if (fav <= -SlPts) { how = "SL"; pts = -SlPts - Slip; }
            else if (fav >= TpPts) { how = "TP"; pts = TpPts; }
            else if (timeUp) { how = "TIME"; pts = fav; }

            if (how == null)
                return;

            leg.Done = true;
            leg.How = how;
            leg.Pts = pts;
            leg.Seconds = (ny - startNy).TotalSeconds;
        }

        private void Finish()
        {
            if (written)
                return;

            written = true;
            active = false;

            Write("DAY | Range " + F(rangePts) + " | Tape " + tapeDelta.ToString("0", CultureInfo.InvariantCulture)
                + " | LongVeto " + (vetoed ? "YES" : "NO")
                + " | LONG " + longLeg.How + " " + F(longLeg.Pts) + " pts (" + F(longLeg.Seconds) + "s)"
                + " | SHORT " + shortLeg.How + " " + F(shortLeg.Pts) + " pts (" + F(shortLeg.Seconds) + "s)");

            try
            {
                Func<string> rootFn = RootFolder;
                string root = rootFn != null ? rootFn() : null;

                if (string.IsNullOrWhiteSpace(root))
                    root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData");

                string folder = Path.Combine(root, "Learning");
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, "openbell_long_days_shadow.csv");
                bool exists = File.Exists(path);

                string dateKey = day.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                if (exists && File.ReadAllText(path).Contains(dateKey + ","))
                    return;

                using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
                {
                    if (!exists)
                        sw.WriteLine("Date,RangePts,TapeDelta,TapeSnaps,LongVeto,Price,"
                            + "LongResult,LongPts,LongSec,LongMfe,LongMae,ShortResult,ShortPts,ShortSec,ShortMfe,ShortMae");

                    sw.WriteLine(string.Join(",", new[]
                    {
                        dateKey, F(rangePts), tapeDelta.ToString("0", CultureInfo.InvariantCulture),
                        tapeSnaps.ToString(CultureInfo.InvariantCulture), vetoed ? "YES" : "NO", F(price0),
                        longLeg.How, F(longLeg.Pts), F(longLeg.Seconds), F(longLeg.Mfe), F(longLeg.Mae),
                        shortLeg.How, F(shortLeg.Pts), F(shortLeg.Seconds), F(shortLeg.Mfe), F(shortLeg.Mae)
                    }));
                }
            }
            catch (Exception ex)
            {
                Write("CSV ERROR | " + ex.Message);
            }
        }

        private void Write(string message)
        {
            Action<string> log = Log;
            if (log != null)
                log("OB LONG-DAY SHADOW | " + message);
        }
    }

    public partial class JJBotWindow
    {
        // V1.7.95 - LONG-day shadow (LONG vs SHORT from 09:29:58, log + CSV only).
        private readonly JJOpenBellLongDayShadow openBellLongDayShadow = new JJOpenBellLongDayShadow();

        private void OpenBellLongDayShadowStart(DateTime ny, double rangePts, double price, double tape, int snaps, bool longVetoed)
        {
            try
            {
                if (openBellLongDayShadow.Log == null)
                    openBellLongDayShadow.Log = delegate (string m) { PrintBotMessage(m); };

                if (openBellLongDayShadow.RootFolder == null)
                    openBellLongDayShadow.RootFolder = delegate { return stateFolderPath; };

                openBellLongDayShadow.Start(ny, rangePts, price, tape, snaps, longVetoed);
            }
            catch
            {
            }
        }

        // V1.7.67 - log-only shadow simulation of the Open Bell (see JJOpenBellShadowSim).
        private readonly JJOpenBellShadowSim openBellShadowSim = new JJOpenBellShadowSim();

        private void OpenBellShadowStart(DateTime ny, double rangePts, double price)
        {
            try
            {
                if (openBellShadowSim.Log == null)
                    openBellShadowSim.Log = delegate (string m) { PrintBotMessage(m); };

                openBellShadowSim.Start(ny, rangePts, price, Core20OpenBellRangeThresholdPts);
            }
            catch
            {
            }
        }

        private void OpenBellShadowTick(DateTime ny, double price)
        {
            try
            {
                openBellShadowSim.OnTick(ny, price);
            }
            catch
            {
            }

            try
            {
                openBellLongDayShadow.OnTick(ny, price);
            }
            catch
            {
            }
        }
    }
}

﻿#region Using declarations
using System;
using System.Globalization;
using System.IO;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private readonly object openingDecisionRecorderLock = new object();
        private string lastOpeningDecisionRecorderKey = string.Empty;

        private bool IsOpeningDecisionRecorderWindow(DateTime nyTime)
        {
            int t = ToTimeInt(nyTime);
            return t >= 92930 && t <= 94500;
        }

        private string GetOpeningDecisionRecorderPath(DateTime nyTime)
        {
            if (selectedInstrument == null)
                return string.Empty;

            Directory.CreateDirectory(GetLearningFolderPath());

            string safeInstrument =
                MakeSafeFileName(selectedInstrument.FullName);

            return Path.Combine(
                GetLearningFolderPath(),
                "opening_r20_"
                    + nyTime.ToString("yyyy-MM-dd")
                    + "_"
                    + safeInstrument
                    + ".csv"
            );
        }

        private string GetOpeningTracePath(DateTime nyTime)
        {
            if (selectedInstrument == null)
                return string.Empty;

            Directory.CreateDirectory(GetLearningFolderPath());

            string safeInstrument =
                MakeSafeFileName(selectedInstrument.FullName);

            return Path.Combine(
                GetLearningFolderPath(),
                "opening_trace_"
                    + nyTime.ToString("yyyy-MM-dd")
                    + "_"
                    + safeInstrument
                    + ".txt"
            );
        }

        private void AppendOpeningDiagnosticMessage(string message)
        {
            try
            {
                if (!botRunning || selectedInstrument == null)
                    return;

                DateTime nyTime =
                    ConvertToNewYorkTime(DateTime.Now);

                if (!IsOpeningDecisionRecorderWindow(nyTime))
                    return;

                string path = GetOpeningTracePath(nyTime);
                if (string.IsNullOrWhiteSpace(path))
                    return;

                lock (openingDecisionRecorderLock)
                {
                    File.AppendAllText(
                        path,
                        nyTime.ToString("yyyy-MM-dd HH:mm:ss.fff")
                            + " | "
                            + message
                            + Environment.NewLine
                    );
                }
            }
            catch
            {
                // Diagnostics must never interfere with trading.
            }
        }

        private void RecordOpeningR20Decision(
            DateTime nyTime,
            double price,
            int longScore,
            int shortScore,
            bool highBreakout,
            bool lowBreakout,
            double rangeRatio,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            bool aggressiveLong,
            bool aggressiveShort,
            bool extremeLong,
            bool extremeShort,
            string longMovePhase,
            string shortMovePhase,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            string m5Structure,
            string m5Liquidity,
            bool rawLongReady,
            bool rawShortReady,
            int confidence,
            string quality,
            string timing,
            string manipulation,
            string finalDecision,
            string reason)
        {
            try
            {
                if (
                    !botRunning ||
                    selectedInstrument == null ||
                    !IsOpeningDecisionRecorderWindow(nyTime)
                )
                {
                    return;
                }

                bool l2Active;
                bool l2Ready;
                double l2Bid;
                double l2Ask;
                double l2Spread;
                string l2Tape;
                string l2ConfluenceSnapshot;
                string l2AbsorptionSnapshot;
                int l2LongPersistenceSnapshot;
                int l2ShortPersistenceSnapshot;
                double l2AgeMs;

                lock (level2Sync)
                {
                    l2Active = level2ObserveActive;
                    l2Ready = level2BookReady;
                    l2Bid = level2BidPct;
                    l2Ask = level2AskPct;
                    l2Spread = level2SpreadTicks;
                    l2Tape = level2TapeBias;
                    l2ConfluenceSnapshot = level2Confluence;
                    l2AbsorptionSnapshot = level2Absorption;
                    l2LongPersistenceSnapshot = level2LongPersistence;
                    l2ShortPersistenceSnapshot = level2ShortPersistence;
                    l2AgeMs =
                        level2LastCalcUtc == DateTime.MinValue
                            ? -1
                            : Math.Max(
                                0,
                                (DateTime.UtcNow - level2LastCalcUtc)
                                    .TotalMilliseconds
                              );
                }

                string m5Trend =
                    m5Bullish
                        ? "BULLISH"
                        : m5Bearish
                            ? "BEARISH"
                            : "NEUTRAL";

                string m5Vwap =
                    m5AboveVwap
                        ? "ABOVE"
                        : m5BelowVwap
                            ? "BELOW"
                            : "AT";

                string recorderRoute =
                    (reason ?? string.Empty).IndexOf("FAST_OPEN", StringComparison.OrdinalIgnoreCase) >= 0
                        ? "FAST_OPEN"
                        : (reason ?? string.Empty).IndexOf("BREAKOUT_CONTINUATION", StringComparison.OrdinalIgnoreCase) >= 0
                            ? "BREAKOUT_CONTINUATION"
                            : (reason ?? string.Empty).IndexOf("SMART RETEST", StringComparison.OrdinalIgnoreCase) >= 0
                                ? "SMART_RETEST"
                                : "DIRECT";

                string key =
                    nyTime.ToString("yyyyMMddHHmmss")
                    + "|" + longScore
                    + "|" + shortScore
                    + "|" + highBreakout
                    + "|" + lowBreakout
                    + "|" + aggressiveLong
                    + "|" + aggressiveShort
                    + "|" + rawLongReady
                    + "|" + rawShortReady
                    + "|" + finalDecision
                    + "|" + reason;

                lock (openingDecisionRecorderLock)
                {
                    if (key == lastOpeningDecisionRecorderKey)
                        return;

                    lastOpeningDecisionRecorderKey = key;

                    string path = GetOpeningDecisionRecorderPath(nyTime);
                    if (string.IsNullOrWhiteSpace(path))
                        return;

                    bool writeHeader = !File.Exists(path);

                    using (StreamWriter writer = new StreamWriter(path, true))
                    {
                        if (writeHeader)
                        {
                            writer.WriteLine(
                                "TimeNY,Price,R20Long,R20Short,HighBreakout,LowBreakout,RangeRatio,VolumeRatio,BodyPct,SlopeTicks,AggressiveLong,AggressiveShort,ExtremeLong,ExtremeShort,LongMovePhase,ShortMovePhase,M5Trend,M5VWAP,M5Structure,M5Liquidity,RawLongReady,RawShortReady,Confidence,Quality,Timing,Manipulation,L2Active,L2Ready,L2BidPct,L2AskPct,L2SpreadTicks,L2Tape,L2Confluence,L2Absorption,L2LongPersistence,L2ShortPersistence,L2AgeMs,Strategy,Route,OpeningBias,PreOpenHigh,PreOpenLow,FinalDecision,Reason"
                            );
                        }

                        writer.WriteLine(
                            nyTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + ","
                            + price.ToString("0.00", CultureInfo.InvariantCulture) + ","
                            + longScore + ","
                            + shortScore + ","
                            + (highBreakout ? "YES" : "NO") + ","
                            + (lowBreakout ? "YES" : "NO") + ","
                            + rangeRatio.ToString("0.00", CultureInfo.InvariantCulture) + ","
                            + volumeRatio.ToString("0.00", CultureInfo.InvariantCulture) + ","
                            + (bodyRatio * 100.0).ToString("0", CultureInfo.InvariantCulture) + ","
                            + slopeTicks.ToString("0.0", CultureInfo.InvariantCulture) + ","
                            + (aggressiveLong ? "YES" : "NO") + ","
                            + (aggressiveShort ? "YES" : "NO") + ","
                            + (extremeLong ? "YES" : "NO") + ","
                            + (extremeShort ? "YES" : "NO") + ","
                            + EscapeCsv(longMovePhase) + ","
                            + EscapeCsv(shortMovePhase) + ","
                            + m5Trend + ","
                            + m5Vwap + ","
                            + EscapeCsv(m5Structure) + ","
                            + EscapeCsv(m5Liquidity) + ","
                            + (rawLongReady ? "YES" : "NO") + ","
                            + (rawShortReady ? "YES" : "NO") + ","
                            + confidence + ","
                            + EscapeCsv(quality) + ","
                            + EscapeCsv(timing) + ","
                            + EscapeCsv(manipulation) + ","
                            + (l2Active ? "YES" : "NO") + ","
                            + (l2Ready ? "YES" : "NO") + ","
                            + l2Bid.ToString("0.0", CultureInfo.InvariantCulture) + ","
                            + l2Ask.ToString("0.0", CultureInfo.InvariantCulture) + ","
                            + l2Spread.ToString("0.0", CultureInfo.InvariantCulture) + ","
                            + EscapeCsv(l2Tape) + ","
                            + EscapeCsv(l2ConfluenceSnapshot) + ","
                            + EscapeCsv(l2AbsorptionSnapshot) + ","
                            + l2LongPersistenceSnapshot + ","
                            + l2ShortPersistenceSnapshot + ","
                            + l2AgeMs.ToString("0", CultureInfo.InvariantCulture) + ","
                            + "OPENING" + ","
                            + EscapeCsv(recorderRoute) + ","
                            + EscapeCsv(openingMap.Ready ? openingMap.OpeningBias : "NEUTRAL") + ","
                            + (openingMap.Ready ? openingMap.PreOpenHigh : 0).ToString("0.00", CultureInfo.InvariantCulture) + ","
                            + (openingMap.Ready ? openingMap.PreOpenLow : 0).ToString("0.00", CultureInfo.InvariantCulture) + ","
                            + EscapeCsv(finalDecision) + ","
                            + EscapeCsv(reason)
                        );
                    }
                }
            }
            catch
            {
                // Recorder is observational only. Never affect execution.
            }
        }
    }
}

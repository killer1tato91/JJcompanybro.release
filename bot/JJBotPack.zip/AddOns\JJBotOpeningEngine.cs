﻿#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // =====================================================
        // V1.6.80 - NY OPENING MAP + FAST OPEN IGNITION
        // =====================================================
        // This model is built from data JJ already calculates. It prepares
        // context before 09:30; it never submits an order by itself.
        private sealed class OpeningMap
        {
            public bool Ready;
            public DateTime TradingDateNy;
            public double PreOpenHigh;
            public double PreOpenLow;
            public double PreOpenMid;
            public double PreOpenRangeTicks;
            public double Vwap;
            public string VwapLocation;
            public double VolumeRatio;
            public string OpeningBias;
        }

        private readonly OpeningMap openingMap = new OpeningMap();
        private string lastOpeningMapLogKey = string.Empty;
        private string lastOpeningIgnitionLogKey = string.Empty;

        private void UpdateOpeningMap(DateTime nyTradingDate)
        {
            if (!premarketContextReady || premarketContextDateNy != nyTradingDate)
                return;

            double high = premarketRangeReady ? premarketRangeHigh : 0;
            double low = premarketRangeReady ? premarketRangeLow : 0;
            if (high <= low)
                return;

            double vwap;
            double volumeRatio;
            bool aboveVwap;
            bool belowVwap;
            lock (marketContextLock)
            {
                vwap = latestM5Vwap;
                volumeRatio = latestRangeVolumeRatio;
                aboveVwap = latestM5AboveVwap;
                belowVwap = latestM5BelowVwap;
            }

            openingMap.Ready = true;
            openingMap.TradingDateNy = nyTradingDate.Date;
            openingMap.PreOpenHigh = high;
            openingMap.PreOpenLow = low;
            openingMap.PreOpenMid = (high + low) / 2.0;
            openingMap.PreOpenRangeTicks = premarketContextRangeTicks;
            openingMap.Vwap = vwap;
            openingMap.VwapLocation = aboveVwap ? "ABOVE" : belowVwap ? "BELOW" : "AT";
            openingMap.VolumeRatio = volumeRatio;
            openingMap.OpeningBias =
                premarketContextBiasScore >= 2 ? "LONG" :
                premarketContextBiasScore <= -2 ? "SHORT" : "NEUTRAL";

            string key = nyTradingDate.ToString("yyyyMMdd")
                + "|" + openingMap.OpeningBias
                + "|" + high.ToString("0.00", CultureInfo.InvariantCulture)
                + "|" + low.ToString("0.00", CultureInfo.InvariantCulture);

            if (!string.Equals(key, lastOpeningMapLogKey, StringComparison.Ordinal))
            {
                lastOpeningMapLogKey = key;
                PrintBotMessage(
                    "OPENING MAP"
                    + " | Bias: " + openingMap.OpeningBias
                    + " | PreH: " + openingMap.PreOpenHigh.ToString("0.00")
                    + " | PreL: " + openingMap.PreOpenLow.ToString("0.00")
                    + " | Mid: " + openingMap.PreOpenMid.ToString("0.00")
                    + " | VWAPLoc: " + openingMap.VwapLocation
                    + " | VolContext x" + openingMap.VolumeRatio.ToString("0.00")
                );
            }
        }

        private bool TryEvaluateFastOpenIgnition(
            bool isLong,
            DateTime signalNyTime,
            double executablePrice,
            out string reason)
        {
            reason = "NO OPENING MAP";

            int timeValue = ToTimeInt(signalNyTime);
            if (timeValue < 93000 || timeValue >= 93130)
            {
                reason = "OUTSIDE FAST OPEN IGNITION WINDOW";
                return false;
            }

            if (!openingMap.Ready || openingMap.TradingDateNy != signalNyTime.Date)
            {
                UpdateOpeningMap(signalNyTime.Date);
                if (!openingMap.Ready || openingMap.TradingDateNy != signalNyTime.Date)
                    return false;
            }

            int longScore;
            int shortScore;
            bool highBreakout;
            bool lowBreakout;
            double bodyRatio;
            double volumeRatio;
            double emaSlope;
            lock (marketContextLock)
            {
                longScore = latestRangeLongScore;
                shortScore = latestRangeShortScore;
                highBreakout = latestRangeHighBreakout;
                lowBreakout = latestRangeLowBreakout;
                bodyRatio = latestRangeBodyRatio;
                volumeRatio = latestRangeVolumeRatio;
                emaSlope = latestRangeEmaSlope;
            }

            double tickSize = selectedInstrument != null && selectedInstrument.MasterInstrument != null
                ? selectedInstrument.MasterInstrument.TickSize
                : 0;
            if (tickSize <= 0)
            {
                reason = "INVALID TICK SIZE";
                return false;
            }

            int score = isLong ? longScore : shortScore;
            int oppositeScore = isLong ? shortScore : longScore;
            double slopeTicks = emaSlope / tickSize;
            double acceptanceBuffer = tickSize * 2.0;
            bool preOpenBreak = isLong
                ? executablePrice >= openingMap.PreOpenHigh + acceptanceBuffer
                : executablePrice <= openingMap.PreOpenLow - acceptanceBuffer;
            bool rangeBreak = isLong ? highBreakout : lowBreakout;
            bool force = score >= 4 && oppositeScore <= 2 && bodyRatio >= 0.68
                && (isLong ? slopeTicks >= 3.0 : slopeTicks <= -3.0);
            // Volume is weighted evidence, not an all-or-nothing >=2x gate.
            bool participation = volumeRatio >= 1.15 || bodyRatio >= 0.80;
            bool acceptance = preOpenBreak && rangeBreak;

            if (!force)
            {
                reason = "IGNITION FORCE NOT PROVEN";
                return false;
            }
            if (!participation)
            {
                reason = "OPENING PARTICIPATION TOO WEAK";
                return false;
            }
            if (!acceptance)
            {
                reason = preOpenBreak
                    ? "BREAK NOT ACCEPTED BY RANGE"
                    : "PREOPEN LEVEL NOT ACCEPTED";
                return false;
            }

            reason = "ACCEPTED PREOPEN BREAK"
                + " | Bias " + openingMap.OpeningBias
                + " | R20 " + score + "/5"
                + " | Vol x" + volumeRatio.ToString("0.00")
                + " | Body " + (bodyRatio * 100.0).ToString("0") + "%"
                + " | Slope " + slopeTicks.ToString("0.0") + "t";

            string key = signalNyTime.ToString("yyyyMMddHHmmss")
                + "|" + (isLong ? "LONG" : "SHORT");
            if (!string.Equals(key, lastOpeningIgnitionLogKey, StringComparison.Ordinal))
            {
                lastOpeningIgnitionLogKey = key;
                PrintBotMessage(
                    "OPENING IGNITION"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | Route: FAST_OPEN"
                    + " | " + reason
                );
            }

            return true;
        }
        private bool IsOpeningBuildWindow(
            DateTime nyTime)
        {
            if (
                activeStrategyMode != "HYBRID" &&
                activeStrategyMode != "OPENING"
            )
            {
                return false;
            }

            int timeValue =
                nyTime.Hour * 10000
                + nyTime.Minute * 100
                + nyTime.Second;

            return
                timeValue >= OpeningRangeStart &&
                timeValue < OpeningEntryStart;
        }
        private bool IsOpeningEntryWindow(
            DateTime nyTime)
        {
            int timeValue =
                nyTime.Hour * 10000
                + nyTime.Minute * 100
                + nyTime.Second;

            return
                timeValue >= OpeningEntryStart &&
                timeValue < OpeningEntryEnd;
        }
        private bool IsOpeningPriorityActive(
            DateTime nyTime)
        {
            if (
                activeStrategyMode != "HYBRID" &&
                activeStrategyMode != "OPENING"
            )
            {
                return false;
            }

            if (openingTradeTakenToday)
            {
                return false;
            }

            return IsOpeningEntryWindow(
                nyTime
            );
        }
        private bool TryBuildPremarketRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex <= 0
            )
            {
                return false;
            }

            // Exclude the newest closed M5 bar. The fast Range engine can
            // then detect a true breakout beyond the latest completed
            // premarket frontier instead of comparing price to itself.
            int endIndex =
                Math.Max(
                    0,
                    closedBarIndex - 1
                );

            double high =
                double.MinValue;

            double low =
                double.MaxValue;

            int matchedBars = 0;
            DateTime lastMatchedNy =
                DateTime.MinValue;

            for (
                int i = 0;
                i <= endIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date !=
                        nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeValue <
                        PremarketSessionStart ||
                    timeValue >
                        PremarketSessionEnd
                )
                {
                    continue;
                }

                high =
                    Math.Max(
                        high,
                        bars.GetHigh(i)
                    );

                low =
                    Math.Min(
                        low,
                        bars.GetLow(i)
                    );

                matchedBars++;
                lastMatchedNy =
                    barNy;
            }

            // V1.6.50 - 03:00 LAUNCH FRONTIER FALLBACK
            // At the exact 03:00 ET session open there are no completed bars
            // inside the 03:00-09:25 premarket window yet.  The previous logic
            // therefore returned false and the Momentum engine could not trade
            // the first expansion of the session.  Build a temporary frontier
            // from the final 60 minutes before 03:00 so a genuine 03:00 break
            // can be detected immediately.  As soon as completed premarket bars
            // exist, the normal 03:00+ frontier above automatically takes over.
            bool launchFrontierFallback = false;

            if (
                matchedBars <= 0 ||
                high == double.MinValue ||
                low == double.MaxValue ||
                high <= low
            )
            {
                DateTime launchStartNy =
                    nyTradingDate.Date.AddHours(2);

                DateTime launchEndNy =
                    nyTradingDate.Date.AddHours(3);

                high = double.MinValue;
                low = double.MaxValue;
                matchedBars = 0;
                lastMatchedNy = DateTime.MinValue;

                for (
                    int i = 0;
                    i <= endIndex;
                    i++
                )
                {
                    DateTime barNy =
                        ConvertToNewYorkTime(
                            bars.GetTime(i)
                        );

                    if (
                        barNy < launchStartNy ||
                        barNy >= launchEndNy
                    )
                    {
                        continue;
                    }

                    high =
                        Math.Max(
                            high,
                            bars.GetHigh(i)
                        );

                    low =
                        Math.Min(
                            low,
                            bars.GetLow(i)
                        );

                    matchedBars++;
                    lastMatchedNy = barNy;
                }

                if (
                    matchedBars <= 0 ||
                    high == double.MinValue ||
                    low == double.MaxValue ||
                    high <= low
                )
                {
                    return false;
                }

                launchFrontierFallback = true;
            }

            premarketRangeReady =
                true;

            premarketRangeHigh =
                high;

            premarketRangeLow =
                low;

            premarketRangeDateNy =
                nyTradingDate;

            premarketRangeLastM5TimeNy =
                lastMatchedNy;

            if (launchFrontierFallback)
            {
                // V1.6.74 - diagnostic debounce only.  The launch frontier
                // itself is still recalculated exactly as before; we simply
                // avoid printing the identical READY line every engine loop.
                string launchLogKey =
                    nyTradingDate.ToString("yyyyMMdd")
                    + "|"
                    + premarketRangeHigh.ToString(
                        "0.00",
                        System.Globalization.CultureInfo.InvariantCulture
                    )
                    + "|"
                    + premarketRangeLow.ToString(
                        "0.00",
                        System.Globalization.CultureInfo.InvariantCulture
                    );

                if (!string.Equals(
                    lastPremarketLaunchFrontierLogKey,
                    launchLogKey,
                    StringComparison.Ordinal))
                {
                    lastPremarketLaunchFrontierLogKey =
                        launchLogKey;

                    PrintBotMessage(
                        "PREMARKET 03:00 LAUNCH FRONTIER READY"
                        + " | Prior60m H/L "
                        + premarketRangeHigh.ToString("0.00")
                        + "/"
                        + premarketRangeLow.ToString("0.00")
                        + " | Analysis: READY"
                        + " | Execution: LOCKED UNTIL 03:15 ET"
                    );
                }
            }

            return true;
        }
        private bool UpdatePremarketContextFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0 ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return false;
            }

            double high = double.MinValue;
            double low = double.MaxValue;
            double firstOpen = 0;
            double lastClose = 0;
            int barsCount = 0;
            int bullBars = 0;
            int bearBars = 0;
            List<double> closes = new List<double>();

            for (int i = 0; i <= closedBarIndex; i++)
            {
                DateTime barNy = ConvertToNewYorkTime(bars.GetTime(i));
                if (barNy.Date != nyTradingDate)
                    continue;

                int tv = ToTimeInt(barNy);
                if (tv < PremarketSessionStart || tv > PremarketSessionEnd)
                    continue;

                double o = bars.GetOpen(i);
                double h = bars.GetHigh(i);
                double l = bars.GetLow(i);
                double c = bars.GetClose(i);

                if (barsCount == 0)
                    firstOpen = o;

                high = Math.Max(high, h);
                low = Math.Min(low, l);
                lastClose = c;
                closes.Add(c);
                barsCount++;

                if (c > o) bullBars++;
                else if (c < o) bearBars++;
            }

            if (barsCount <= 0 || high <= low)
                return false;

            double mid = (high + low) / 2.0;
            int upper = 0;
            int lower = 0;
            foreach (double c in closes)
            {
                if (c > mid) upper++;
                else if (c < mid) lower++;
            }

            double tickSize = selectedInstrument.MasterInstrument.TickSize;
            double position = (lastClose - low) / (high - low);
            position = Math.Max(0, Math.Min(1, position));

            int biasScore = 0;
            if (lastClose > firstOpen) biasScore++;
            else if (lastClose < firstOpen) biasScore--;
            if (bullBars > bearBars) biasScore++;
            else if (bearBars > bullBars) biasScore--;
            if (upper > lower) biasScore++;
            else if (lower > upper) biasScore--;
            if (position >= PremarketStrongBiasPosition) biasScore++;
            else if (position <= 1.0 - PremarketStrongBiasPosition) biasScore--;

            string bias =
                biasScore >= 3 ? "BULLISH" :
                biasScore <= -3 ? "BEARISH" :
                biasScore > 0 ? "BULLISH-LEAN" :
                biasScore < 0 ? "BEARISH-LEAN" : "NEUTRAL";

            premarketContextReady = barsCount >= PremarketContextMinBars;
            premarketContextDateNy = nyTradingDate;
            premarketContextOpen = firstOpen;
            premarketContextLastClose = lastClose;
            premarketContextMid = mid;
            premarketContextRangeTicks = tickSize > 0 ? (high - low) / tickSize : 0;
            premarketContextBars = barsCount;
            premarketBullBars = bullBars;
            premarketBearBars = bearBars;
            premarketUpperHalfCloses = upper;
            premarketLowerHalfCloses = lower;
            premarketContextPosition = position;
            premarketContextBias = bias;
            premarketContextBiasScore = biasScore;

            UpdateOpeningMap(nyTradingDate);

            DateTime nowNy = GetCurrentNewYorkTime();
            bool openingSnapshot = ToTimeInt(nowNy) >= 92500;
            bool finalNotLogged = lastPremarketContextFinalLogDateNy.Date != nyTradingDate.Date;
            bool periodic = lastPremarketContextLogNy == DateTime.MinValue ||
                (nowNy - lastPremarketContextLogNy).TotalMinutes >= 30;

            if (premarketContextReady && (periodic || (openingSnapshot && finalNotLogged)))
            {
                bool finalSnapshot = openingSnapshot && finalNotLogged;
                lastPremarketContextLogNy = nowNy;
                if (finalSnapshot)
                    lastPremarketContextFinalLogDateNy = nyTradingDate.Date;

                PrintBotMessage(
                    (finalSnapshot ? "PREMARKET CONTEXT READY FOR OPEN" : "PREMARKET CONTEXT UPDATE")
                    + " | High: " + high.ToString("0.00")
                    + " | Low: " + low.ToString("0.00")
                    + " | Mid: " + mid.ToString("0.00")
                    + " | Range: " + premarketContextRangeTicks.ToString("0") + "t"
                    + " | LastPos: " + (position * 100.0).ToString("0") + "%"
                    + " | Bull/Bear M5: " + bullBars + "/" + bearBars
                    + " | Upper/Lower closes: " + upper + "/" + lower
                    + " | Bias: " + bias + " (" + biasScore + ")"
                );
            }

            return true;
        }
        private bool IsPremarketPriceChaseBlocked(
            bool isLong,
            double price,
            out double extensionTicks)
        {
            extensionTicks = 0;

            if (
                !premarketRangeReady ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null
            )
            {
                return false;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
            {
                return false;
            }

            double extensionPoints =
                isLong
                    ? price -
                        premarketRangeHigh
                    : premarketRangeLow -
                        price;

            extensionTicks =
                Math.Max(
                    0,
                    extensionPoints /
                        tickSize
                );

            return
                extensionTicks >
                    PremarketMaxChaseTicks;
        }
        private void LogPremarketPriceChaseBlock(
            bool isLong,
            DateTime signalNy,
            double price,
            double extensionTicks)
        {
            string key =
                signalNy.ToString(
                    "yyyyMMddHHmmss"
                )
                + "|"
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                  )
                + "|"
                + Math.Round(
                    extensionTicks
                ).ToString(
                    CultureInfo.InvariantCulture
                );

            if (
                key ==
                    lastPremarketChaseBlockLogKey
            )
            {
                return;
            }

            lastPremarketChaseBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - PREMARKET PRICE EXTENDED"
                + " | Side: "
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                  )
                + " | Price: "
                + price.ToString(
                    "0.00",
                    CultureInfo.InvariantCulture
                )
                + " | Extension: "
                + extensionTicks.ToString(
                    "0",
                    CultureInfo.InvariantCulture
                )
                + "t"
                + " | Max: "
                + PremarketMaxChaseTicks
                + "t"
            );
        }
        private bool TryBuildPreEntryRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0
            )
            {
                return false;
            }

            double high = double.MinValue;
            double low = double.MaxValue;
            int matchedBars = 0;

            for (
                int i = 0;
                i <= closedBarIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date != nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    ToTimeInt(
                        barNy
                    );

                if (
                    timeValue < PreEntryRangeStart ||
                    timeValue > PreEntryRangeEnd
                )
                {
                    continue;
                }

                high =
                    Math.Max(
                        high,
                        bars.GetHigh(i)
                    );

                low =
                    Math.Min(
                        low,
                        bars.GetLow(i)
                    );

                matchedBars++;
            }

            if (
                matchedBars <= 0 ||
                high <= low
            )
            {
                return false;
            }

            bool shouldLog =
                !preEntryRangeReady ||
                preEntryRangeDateNy !=
                    nyTradingDate;

            preEntryRangeReady = true;
            preEntryRangeHigh = high;
            preEntryRangeLow = low;
            preEntryRangeDateNy =
                nyTradingDate;

            if (shouldLog)
            {
                PrintBotMessage(
                    "PRE-ENTRY RANGE READY"
                    + " | 09:00-09:29 ET"
                    + " | High: "
                    + preEntryRangeHigh.ToString("0.00")
                    + " | Low: "
                    + preEntryRangeLow.ToString("0.00")
                    + " | Width: "
                    + (
                        preEntryRangeHigh -
                        preEntryRangeLow
                      ).ToString("0.00")
                );
            }

            return true;
        }
        private void EvaluateOpeningRangeGuard(
            DateTime nyTradingDate)
        {
            if (
                !openingRangeReady ||
                !preEntryRangeReady ||
                preEntryRangeDateNy !=
                    nyTradingDate
            )
            {
                openingRangeGuardBlocked = false;
                openingRangeGuardReason =
                    string.Empty;
                openingRangeGuardDateNy =
                    nyTradingDate;

                return;
            }

            double preEntryWidth =
                preEntryRangeHigh -
                preEntryRangeLow;

            double openingWidth =
                openingRangeHigh -
                openingRangeLow;

            if (
                preEntryWidth <= 0 ||
                openingWidth <= 0
            )
            {
                openingRangeGuardBlocked = false;
                openingRangeGuardReason =
                    string.Empty;
                openingRangeGuardDateNy =
                    nyTradingDate;

                return;
            }

            double expansionRatio =
                openingWidth /
                preEntryWidth;

            bool blocked =
                expansionRatio >
                    OpeningMaxPreEntryExpansionRatio;

            bool changed =
                openingRangeGuardDateNy !=
                    nyTradingDate ||
                openingRangeGuardBlocked !=
                    blocked;

            openingRangeGuardBlocked =
                blocked;

            openingRangeGuardReason =
                blocked
                    ? "OPENING OVEREXTENDED "
                        + expansionRatio.ToString("0.00")
                        + "x PRE-ENTRY"
                    : string.Empty;

            openingRangeGuardDateNy =
                nyTradingDate;

            if (changed)
            {
                PrintBotMessage(
                    blocked
                        ? "OPENING RANGE GUARD BLOCKED"
                            + " | Opening: "
                            + openingWidth.ToString("0.00")
                            + " | PreEntry: "
                            + preEntryWidth.ToString("0.00")
                            + " | Ratio: "
                            + expansionRatio.ToString("0.00")
                            + "x"
                            + " | HYBRID FALLBACK ALLOWED"
                        : "OPENING RANGE GUARD READY"
                            + " | Opening/PreEntry Ratio: "
                            + expansionRatio.ToString("0.00")
                            + "x"
                );
            }
        }
        private bool TryBuildOpeningRangeFromBars(
            Bars bars,
            int closedBarIndex,
            DateTime nyTradingDate)
        {
            if (
                bars == null ||
                closedBarIndex < 0
            )
            {
                return false;
            }

            int bestIndex = -1;
            DateTime bestNyTime =
                DateTime.MaxValue;

            for (
                int i = 0;
                i <= closedBarIndex;
                i++
            )
            {
                DateTime barNy =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (
                    barNy.Date != nyTradingDate
                )
                {
                    continue;
                }

                int timeValue =
                    barNy.Hour * 10000
                    + barNy.Minute * 100
                    + barNy.Second;

                if (
                    timeValue < OpeningRangeStart ||
                    timeValue >= 94000
                )
                {
                    continue;
                }

                if (barNy < bestNyTime)
                {
                    bestNyTime = barNy;
                    bestIndex = i;
                }
            }

            if (bestIndex < 0)
            {
                return false;
            }

            double candidateHigh =
                bars.GetHigh(
                    bestIndex
                );

            double candidateLow =
                bars.GetLow(
                    bestIndex
                );

            if (
                candidateHigh <= candidateLow
            )
            {
                return false;
            }

            openingRangeHigh =
                candidateHigh;

            openingRangeLow =
                candidateLow;

            openingRangeBarTimeNy =
                bestNyTime;

            openingRangeReady =
                true;

            EvaluateOpeningRangeGuard(
                nyTradingDate
            );

            if (
                openingRangeLoggedDate !=
                    nyTradingDate
            )
            {
                openingRangeLoggedDate =
                    nyTradingDate;

                PrintBotMessage(
                    "OPENING RANGE READY"
                    + " | "
                    + bestNyTime.ToString("HH:mm")
                    + " ET"
                    + " | High: "
                    + openingRangeHigh.ToString("0.00")
                    + " | Low: "
                    + openingRangeLow.ToString("0.00")
                );
            }

            return true;
        }
        private bool IsOpeningPriceChaseBlocked(
            bool isLong,
            double currentPrice,
            out double extensionPoints,
            out double maxExtensionPoints)
        {
            extensionPoints = 0;
            maxExtensionPoints = 0;

            if (
                !openingRangeReady ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                openingRangeHigh <= openingRangeLow
            )
            {
                return false;
            }

            double tickSize =
                selectedInstrument.MasterInstrument.TickSize;

            if (tickSize <= 0)
                return false;

            double openingWidth =
                openingRangeHigh -
                openingRangeLow;

            maxExtensionPoints =
                Math.Max(
                    openingWidth *
                        OpeningMaxChaseRangeFraction,
                    tickSize *
                        OpeningMinChaseTicks
                );

            extensionPoints =
                isLong
                    ? Math.Max(
                        0,
                        currentPrice -
                            openingRangeHigh
                      )
                    : Math.Max(
                        0,
                        openingRangeLow -
                            currentPrice
                      );

            return
                extensionPoints >
                    maxExtensionPoints;
        }
        private void LogOpeningPriceChaseBlock(
            bool isLong,
            DateTime nyTime,
            double currentPrice,
            double extensionPoints,
            double maxExtensionPoints)
        {
            // V1.6.37 - throttle repeated anti-chase telemetry. The state is
            // unchanged; only duplicate log noise is reduced to once per
            // minute and side.
            // V1.6.52 - use wall-clock time for telemetry throttling.
            // On startup NinjaTrader can replay several completed signal bars
            // in one real second; using each bar's NY time made the same guard
            // flood the log with different historical prices. The trading
            // decision is unchanged; only duplicate telemetry is suppressed.
            string key =
                DateTime.UtcNow.ToString(
                    "yyyyMMddHHmm"
                )
                + "|"
                + (isLong ? "LONG" : "SHORT");

            if (key == lastPriceChaseBlockLogKey)
                return;

            lastPriceChaseBlockLogKey =
                key;

            PrintBotMessage(
                "SKIP TRADE - OPENING PRICE EXTENDED"
                + " | Side: "
                + (isLong ? "LONG" : "SHORT")
                + " | Price: "
                + currentPrice.ToString("0.00")
                + " | OR High: "
                + openingRangeHigh.ToString("0.00")
                + " | OR Low: "
                + openingRangeLow.ToString("0.00")
                + " | Extension: "
                + extensionPoints.ToString("0.00")
                + " pts"
                + " | Max: "
                + maxExtensionPoints.ToString("0.00")
                + " pts"
            );
        }

    }
}

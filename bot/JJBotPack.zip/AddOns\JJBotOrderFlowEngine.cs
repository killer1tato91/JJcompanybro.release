﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // =====================================================
        // V10.1 - LEVEL 2 OBSERVE BOOK FIX
        // =====================================================
        // OBSERVE ONLY.
        // No cambia entradas, dirección, Move Phase, TP/SL,
        // trailing, Scale-In ni Learning.
        // =====================================================

        private sealed class JJLevel2Row
        {
            public double Price;
            public long Volume;
            public string MarketMaker;
        }

        private readonly object level2Sync =
            new object();

        private readonly List<JJLevel2Row> level2BidRows =
            new List<JJLevel2Row>();

        private readonly List<JJLevel2Row> level2AskRows =
            new List<JJLevel2Row>();

        private Instrument level2ObservedInstrument;
        private bool level2ObserveActive;

        private long level2DepthEvents;
        private long level2BidAdd;
        private long level2BidRemove;
        private long level2AskAdd;
        private long level2AskRemove;

        private double level2AggBuy;
        private double level2AggSell;

        private double level2LastTradePrice;
        private double level2LastBidPrice;
        private double level2LastAskPrice;
        private long level2TapeTrades;
        private long level2UnknownTrades;

        private DateTime level2LastCalcUtc =
            DateTime.MinValue;

        private DateTime level2LastLogUtc =
            DateTime.MinValue;

        private const int Level2BookMaxRows = 50;
        private const int Level2TopRows = 10;
        private const int Level2CalcMs = 250;
        private const int Level2LogSeconds = 5;

        // V10.5 - Do not trust the first partial depth snapshot.
        // A valid L2 context requires both sides of the book populated
        // and a minimum number of depth events received.
        private const int Level2WarmupMinRowsPerSide = 10;
        private const long Level2WarmupMinDepthEvents = 500;
        private bool level2BookReady;

        private void StartLevel2Observe()
        {
            StopLevel2Observe();

            if (selectedInstrument == null)
            {
                PrintBotMessage(
                    "LEVEL2 OBSERVE WAIT | Instrument not ready"
                );
                return;
            }

            level2ObservedInstrument =
                selectedInstrument;

            level2ObserveActive = true;

            lock (level2Sync)
            {
                level2BidRows.Clear();
                level2AskRows.Clear();

                level2DepthEvents = 0;
                level2BookReady = false;

                level2BidAdd = 0;
                level2BidRemove = 0;
                level2AskAdd = 0;
                level2AskRemove = 0;

                level2AggBuy = 0;
                level2AggSell = 0;

                level2FlowAggBuyTotal = 0;
                level2FlowAggSellTotal = 0;
                level2FlowSamples.Clear();
                level2BuyProgressTicks = 0;
                level2SellProgressTicks = 0;
                level2BuyEfficiency = 0;
                level2SellEfficiency = 0;
                level2AbsorptionEfficiency = "NEUTRAL";
                level2TrappedTraders = "NONE";
                level2FlowInterpretation = "NEUTRAL";

                level2LastTradePrice = 0;
                level2LastBidPrice = 0;
                level2LastAskPrice = 0;
                level2TapeTrades = 0;
                level2UnknownTrades = 0;
            }

            level2ObservedInstrument.Dispatcher.BeginInvoke(
                new Action(
                    () =>
                    {
                        if (
                            level2ObserveActive &&
                            level2ObservedInstrument != null
                        )
                        {
                            level2ObservedInstrument
                                .MarketDepth
                                .Update +=
                                OnLevel2DepthUpdate;

                            level2ObservedInstrument
                                .MarketData
                                .Update +=
                                OnLevel2MarketDataUpdate;
                        }
                    }
                )
            );

            PrintBotMessage(
                "LEVEL2 OBSERVE ACTIVE | "
                + selectedInstrument.FullName
                + " | BOOK FIX V10.7 + FAST OPEN + RETEST TIMING | CONFIRMATION ACTIVE"
            );
        }

        private void StopLevel2Observe()
        {
            Instrument oldInstrument =
                level2ObservedInstrument;

            level2ObserveActive = false;
            level2ObservedInstrument = null;

            if (oldInstrument != null)
            {
                oldInstrument.Dispatcher.BeginInvoke(
                    new Action(
                        () =>
                        {
                            try
                            {
                                oldInstrument
                                    .MarketDepth
                                    .Update -=
                                    OnLevel2DepthUpdate;

                                oldInstrument
                                    .MarketData
                                    .Update -=
                                    OnLevel2MarketDataUpdate;
                            }
                            catch
                            {
                            }
                        }
                    )
                );
            }

            lock (level2Sync)
            {
                level2BidRows.Clear();
                level2AskRows.Clear();
            }
        }

        private void OnLevel2DepthUpdate(
            object sender,
            MarketDepthEventArgs e)
        {
            if (
                !level2ObserveActive ||
                e == null
            )
            {
                return;
            }

            lock (level2Sync)
            {
                level2DepthEvents++;

                if (
                    e.MarketDataType ==
                    MarketDataType.Bid
                )
                {
                    ApplyDepthEvent(
                        level2BidRows,
                        e,
                        true
                    );
                }
                else if (
                    e.MarketDataType ==
                    MarketDataType.Ask
                )
                {
                    ApplyDepthEvent(
                        level2AskRows,
                        e,
                        false
                    );
                }
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            if (
                (
                    nowUtc -
                    level2LastCalcUtc
                ).TotalMilliseconds >=
                Level2CalcMs
            )
            {
                level2LastCalcUtc =
                    nowUtc;

                CalculateLevel2Context();
            }

            if (
                (
                    nowUtc -
                    level2LastLogUtc
                ).TotalSeconds >=
                Level2LogSeconds
            )
            {
                level2LastLogUtc =
                    nowUtc;

                LogLevel2Context();
            }
        }

        private void OnLevel2MarketDataUpdate(
            object sender,
            MarketDataEventArgs e)
        {
            if (
                !level2ObserveActive ||
                e == null
            )
            {
                return;
            }

            lock (level2Sync)
            {
                if (
                    e.MarketDataType ==
                    MarketDataType.Bid
                )
                {
                    level2LastBidPrice =
                        e.Price;

                    return;
                }

                if (
                    e.MarketDataType ==
                    MarketDataType.Ask
                )
                {
                    level2LastAskPrice =
                        e.Price;

                    return;
                }

                if (
                    e.MarketDataType !=
                    MarketDataType.Last
                )
                {
                    return;
                }

                level2LastTradePrice =
                    e.Price;

                level2TapeTrades++;

                double tradeVolume =
                    Math.Max(
                        0,
                        e.Volume
                    );

                double tickSize =
                    0.0;

                if (
                    selectedInstrument != null &&
                    selectedInstrument
                        .MasterInstrument != null
                )
                {
                    tickSize =
                        selectedInstrument
                            .MasterInstrument
                            .TickSize;
                }

                double epsilon =
                    tickSize > 0
                        ? tickSize * 0.25
                        : 0.0000001;

                bool classifiedBuy = false;
                bool classifiedSell = false;

                // Aggressive buy:
                // Last trade executes at/through current ask.
                if (
                    level2LastAskPrice > 0 &&
                    e.Price >=
                    level2LastAskPrice -
                    epsilon
                )
                {
                    classifiedBuy = true;
                }
                // Aggressive sell:
                // Last trade executes at/through current bid.
                else if (
                    level2LastBidPrice > 0 &&
                    e.Price <=
                    level2LastBidPrice +
                    epsilon
                )
                {
                    classifiedSell = true;
                }
                // If trade occurs between bid/ask, classify by
                // proximity to the nearest side when possible.
                else if (
                    level2LastBidPrice > 0 &&
                    level2LastAskPrice > 0
                )
                {
                    double bidDistance =
                        Math.Abs(
                            e.Price -
                            level2LastBidPrice
                        );

                    double askDistance =
                        Math.Abs(
                            level2LastAskPrice -
                            e.Price
                        );

                    if (
                        askDistance <
                        bidDistance
                    )
                    {
                        classifiedBuy = true;
                    }
                    else if (
                        bidDistance <
                        askDistance
                    )
                    {
                        classifiedSell = true;
                    }
                }

                if (classifiedBuy)
                {
                    level2AggBuy += tradeVolume;
                    level2FlowAggBuyTotal += tradeVolume;
                }
                else if (classifiedSell)
                {
                    level2AggSell += tradeVolume;
                    level2FlowAggSellTotal += tradeVolume;
                }
                else
                {
                    level2UnknownTrades++;
                }

                RecordLevel2FlowSample(
                    DateTime.UtcNow,
                    e.Price
                );
            }
        }

        private void RecordLevel2FlowSample(
            DateTime nowUtc,
            double price)
        {
            if (price <= 0)
                return;

            level2FlowSamples.Enqueue(
                new JJLevel2FlowSample
                {
                    Utc = nowUtc,
                    Price = price,
                    AggBuyTotal = level2FlowAggBuyTotal,
                    AggSellTotal = level2FlowAggSellTotal
                }
            );

            DateTime cutoff =
                nowUtc.AddSeconds(
                    -Level2EfficiencyWindowSeconds
                );

            while (
                level2FlowSamples.Count > 1 &&
                level2FlowSamples.Peek().Utc < cutoff
            )
            {
                level2FlowSamples.Dequeue();
            }
        }

        private void CalculateLevel2AbsorptionEfficiency()
        {
            level2BuyProgressTicks = 0.0;
            level2SellProgressTicks = 0.0;
            level2BuyEfficiency = 0.0;
            level2SellEfficiency = 0.0;
            level2AbsorptionEfficiency = "NEUTRAL";
            level2TrappedTraders = "NONE";
            level2FlowInterpretation = "NEUTRAL";

            if (
                !level2BookReady ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                selectedInstrument.MasterInstrument.TickSize <= 0 ||
                level2FlowSamples.Count < 2
            )
            {
                return;
            }

            JJLevel2FlowSample first =
                level2FlowSamples.Peek();

            JJLevel2FlowSample last = null;
            double minPrice = double.MaxValue;
            double maxPrice = double.MinValue;

            foreach (
                JJLevel2FlowSample sample
                in level2FlowSamples
            )
            {
                last = sample;
                minPrice = Math.Min(minPrice, sample.Price);
                maxPrice = Math.Max(maxPrice, sample.Price);
            }

            if (last == null || first.Price <= 0 || last.Price <= 0)
                return;

            if (
                (DateTime.UtcNow - last.Utc).TotalSeconds >
                    Level2EfficiencyWindowSeconds
            )
            {
                return;
            }

            double tickSize =
                selectedInstrument.MasterInstrument.TickSize;

            double buyAgg =
                Math.Max(
                    0.0,
                    last.AggBuyTotal - first.AggBuyTotal
                );

            double sellAgg =
                Math.Max(
                    0.0,
                    last.AggSellTotal - first.AggSellTotal
                );

            level2BuyProgressTicks =
                Math.Max(
                    0.0,
                    (maxPrice - first.Price) / tickSize
                );

            level2SellProgressTicks =
                Math.Max(
                    0.0,
                    (first.Price - minPrice) / tickSize
                );

            level2BuyEfficiency =
                buyAgg > 0
                    ? level2BuyProgressTicks /
                        Math.Max(1.0, buyAgg / 100.0)
                    : 0.0;

            level2SellEfficiency =
                sellAgg > 0
                    ? level2SellProgressTicks /
                        Math.Max(1.0, sellAgg / 100.0)
                    : 0.0;

            bool sellDominant =
                sellAgg >= Level2EfficiencyMinDominantAgg &&
                sellAgg >= Math.Max(1.0, buyAgg) *
                    Level2EfficiencyDominanceRatio;

            bool buyDominant =
                buyAgg >= Level2EfficiencyMinDominantAgg &&
                buyAgg >= Math.Max(1.0, sellAgg) *
                    Level2EfficiencyDominanceRatio;

            bool buyAbsorptionConfirmed =
                sellDominant &&
                level2SellProgressTicks <=
                    Level2AbsorptionMaxProgressTicks &&
                level2SellEfficiency <=
                    Level2AbsorptionMaxTicksPer100Agg &&
                level2BidPct >= 52.0;

            bool sellAbsorptionConfirmed =
                buyDominant &&
                level2BuyProgressTicks <=
                    Level2AbsorptionMaxProgressTicks &&
                level2BuyEfficiency <=
                    Level2AbsorptionMaxTicksPer100Agg &&
                level2AskPct >= 52.0;

            double reclaimFromLowTicks =
                Math.Max(
                    0.0,
                    (last.Price - minPrice) / tickSize
                );

            double rejectFromHighTicks =
                Math.Max(
                    0.0,
                    (maxPrice - last.Price) / tickSize
                );

            bool sellersTrapped =
                buyAbsorptionConfirmed &&
                reclaimFromLowTicks >=
                    Level2TrappedReclaimTicks;

            bool buyersTrapped =
                sellAbsorptionConfirmed &&
                rejectFromHighTicks >=
                    Level2TrappedReclaimTicks;

            if (buyAbsorptionConfirmed)
            {
                level2AbsorptionEfficiency =
                    "BUY ABSORPTION CONFIRMED";
                level2FlowInterpretation =
                    sellersTrapped
                        ? "LONG REVERSAL SUPPORT"
                        : "SELL AGGRESSION ABSORBED";
            }
            else if (sellAbsorptionConfirmed)
            {
                level2AbsorptionEfficiency =
                    "SELL ABSORPTION CONFIRMED";
                level2FlowInterpretation =
                    buyersTrapped
                        ? "SHORT REVERSAL SUPPORT"
                        : "BUY AGGRESSION ABSORBED";
            }
            else if (buyDominant)
            {
                level2AbsorptionEfficiency =
                    "BUY AGGRESSION EFFICIENT";
                level2FlowInterpretation =
                    "LONG CONTINUATION FLOW";
            }
            else if (sellDominant)
            {
                level2AbsorptionEfficiency =
                    "SELL AGGRESSION EFFICIENT";
                level2FlowInterpretation =
                    "SHORT CONTINUATION FLOW";
            }

            if (sellersTrapped)
            {
                level2TrappedTraders =
                    "SELLERS TRAPPED";
            }
            else if (buyersTrapped)
            {
                level2TrappedTraders =
                    "BUYERS TRAPPED";
            }
        }

        private bool IsLevel2BuyAbsorptionConfirmed()
        {
            return string.Equals(
                level2AbsorptionEfficiency,
                "BUY ABSORPTION CONFIRMED",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private bool IsLevel2SellAbsorptionConfirmed()
        {
            return string.Equals(
                level2AbsorptionEfficiency,
                "SELL ABSORPTION CONFIRMED",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private bool AreLevel2SellersTrapped()
        {
            return string.Equals(
                level2TrappedTraders,
                "SELLERS TRAPPED",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private bool AreLevel2BuyersTrapped()
        {
            return string.Equals(
                level2TrappedTraders,
                "BUYERS TRAPPED",
                StringComparison.OrdinalIgnoreCase
            );
        }

        private void ApplyDepthEvent(
            List<JJLevel2Row> book,
            MarketDepthEventArgs e,
            bool isBid)
        {
            int position =
                e.Position;

            switch (e.Operation)
            {
                case Operation.Add:
                {
                    JJLevel2Row row =
                        CreateDepthRow(e);

                    if (position < 0)
                        position = 0;

                    if (position > book.Count)
                        position = book.Count;

                    book.Insert(
                        position,
                        row
                    );

                    if (isBid)
                        level2BidAdd++;
                    else
                        level2AskAdd++;

                    break;
                }

                case Operation.Update:
                {
                    JJLevel2Row row =
                        CreateDepthRow(e);

                    // V10.6:
                    // MarketDepth position indexes are provider snapshots and
                    // can become stale while events are arriving quickly.
                    // Price is the stable identity for our normalized local book.
                    // Update by price first; only use the position as fallback.
                    int priceIndex =
                        FindDepthIndexByPrice(
                            book,
                            row.Price
                        );

                    if (priceIndex >= 0)
                    {
                        book[priceIndex] =
                            row;
                    }
                    else if (
                        position >= 0 &&
                        position < book.Count
                    )
                    {
                        book[position] =
                            row;
                    }
                    else
                    {
                        book.Add(
                            row
                        );
                    }

                    break;
                }

                case Operation.Remove:
                {
                    // V10.6:
                    // Remove by price first. Removing an old positional index
                    // was the main way a valid best bid/ask could survive while
                    // a different row was deleted, producing impossible
                    // negative spreads.
                    int priceIndex =
                        FindDepthIndexByPrice(
                            book,
                            e.Price
                        );

                    if (priceIndex >= 0)
                    {
                        book.RemoveAt(
                            priceIndex
                        );
                    }
                    else if (
                        position >= 0 &&
                        position < book.Count
                    )
                    {
                        book.RemoveAt(
                            position
                        );
                    }

                    if (isBid)
                        level2BidRemove++;
                    else
                        level2AskRemove++;

                    break;
                }
            }

            NormalizeDepthBook(
                book,
                isBid
            );

            SanitizeCrossedLevel2Book(
                isBid
            );
        }

        private void SanitizeCrossedLevel2Book(
            bool updatedBidSide)
        {
            if (
                level2BidRows.Count == 0 ||
                level2AskRows.Count == 0
            )
            {
                return;
            }

            double bestBid =
                level2BidRows[0].Price;

            double bestAsk =
                level2AskRows[0].Price;

            if (
                bestBid <= 0 ||
                bestAsk <= 0 ||
                bestAsk > bestBid
            )
            {
                return;
            }

            // A real limit book must have Ask > Bid. A crossed local book here
            // means one stale row survived an asynchronous depth update.
            // Remove only the stale/opposite rows made impossible by the fresh
            // side, then re-normalize that side.
            if (updatedBidSide)
            {
                level2AskRows.RemoveAll(
                    row =>
                        row != null &&
                        row.Price <= bestBid
                );

                NormalizeDepthBook(
                    level2AskRows,
                    false
                );
            }
            else
            {
                level2BidRows.RemoveAll(
                    row =>
                        row != null &&
                        row.Price >= bestAsk
                );

                NormalizeDepthBook(
                    level2BidRows,
                    true
                );
            }
        }

        private JJLevel2Row CreateDepthRow(
            MarketDepthEventArgs e)
        {
            return new JJLevel2Row
            {
                Price = e.Price,
                Volume = Math.Max(
                    0,
                    Convert.ToInt64(
                        e.Volume
                    )
                ),
                MarketMaker =
                    e.MarketMaker ??
                    string.Empty
            };
        }

        private int FindDepthIndexByPrice(
            List<JJLevel2Row> book,
            double price)
        {
            if (book == null)
                return -1;

            return book.FindIndex(
                x =>
                    x != null &&
                    Math.Abs(
                        x.Price -
                        price
                    ) <
                    0.0000001
            );
        }

        private void UpsertDepthByPrice(
            List<JJLevel2Row> book,
            JJLevel2Row row)
        {
            int index =
                FindDepthIndexByPrice(
                    book,
                    row.Price
                );

            if (index >= 0)
            {
                book[index] =
                    row;
            }
            else
            {
                book.Add(
                    row
                );
            }
        }

        private void RemoveDepthByPrice(
            List<JJLevel2Row> book,
            double price)
        {
            int index =
                FindDepthIndexByPrice(
                    book,
                    price
                );

            if (index >= 0)
            {
                book.RemoveAt(
                    index
                );
            }
        }

        private void NormalizeDepthBook(
            List<JJLevel2Row> book,
            bool isBid)
        {
            if (isBid)
            {
                book.Sort(
                    (a, b) =>
                        b.Price.CompareTo(
                            a.Price
                        )
                );
            }
            else
            {
                book.Sort(
                    (a, b) =>
                        a.Price.CompareTo(
                            b.Price
                        )
                );
            }

            for (
                int i =
                    book.Count - 1;
                i > 0;
                i--
            )
            {
                if (
                    Math.Abs(
                        book[i].Price -
                        book[i - 1].Price
                    ) <
                    0.0000001
                )
                {
                    book[i - 1].Volume =
                        Math.Max(
                            book[i - 1]
                                .Volume,
                            book[i]
                                .Volume
                        );

                    book.RemoveAt(
                        i
                    );
                }
            }

            if (
                book.Count >
                Level2BookMaxRows
            )
            {
                book.RemoveRange(
                    Level2BookMaxRows,
                    book.Count -
                    Level2BookMaxRows
                );
            }
        }

        private double level2BidPct = 50.0;
        private double level2AskPct = 50.0;

        private long level2TopBidVolume;
        private long level2TopAskVolume;

        private string level2Bias =
            "NEUTRAL";

        private string level2StackPull =
            "BALANCED";

        private string level2Absorption =
            "NONE";

        private double level2SpreadTicks;

        // =====================================================
        // V10.4 - LEVEL2 FLOW SUMMARY / OBSERVE ONLY
        // =====================================================
        private double level2TapeDelta;
        private string level2TapeBias =
            "NEUTRAL";

        private string level2Confluence =
            "NEUTRAL";

        private int level2LongPersistence;
        private int level2ShortPersistence;
        private int level2NeutralPersistence;

        private const int Level2PersistenceCap = 6;

        // =====================================================
        // V1.6.44 - LEVEL2 ABSORPTION EFFICIENCY / TRAPPED FLOW
        // =====================================================
        // This layer does NOT create entries and does NOT add a new hard
        // filter. It interprets whether aggressive tape is actually producing
        // proportional price progress. Existing price/setup engines remain
        // the authority; this state is used only to improve L2 confirmation
        // and to avoid treating absorbed aggression as genuine continuation.
        private sealed class JJLevel2FlowSample
        {
            public DateTime Utc;
            public double Price;
            public double AggBuyTotal;
            public double AggSellTotal;
        }

        private readonly Queue<JJLevel2FlowSample> level2FlowSamples =
            new Queue<JJLevel2FlowSample>();

        private double level2FlowAggBuyTotal;
        private double level2FlowAggSellTotal;

        private double level2BuyProgressTicks;
        private double level2SellProgressTicks;
        private double level2BuyEfficiency;
        private double level2SellEfficiency;

        private string level2AbsorptionEfficiency = "NEUTRAL";
        private string level2TrappedTraders = "NONE";
        private string level2FlowInterpretation = "NEUTRAL";

        private const double Level2EfficiencyWindowSeconds = 3.0;
        private const double Level2EfficiencyMinDominantAgg = 80.0;
        private const double Level2EfficiencyDominanceRatio = 1.50;
        private const double Level2AbsorptionMaxProgressTicks = 4.0;
        private const double Level2AbsorptionMaxTicksPer100Agg = 4.0;
        private const double Level2TrappedReclaimTicks = 3.0;

        private void CalculateLevel2Context()
        {
            lock (level2Sync)
            {
                level2TopBidVolume =
                    level2BidRows
                        .Take(
                            Level2TopRows
                        )
                        .Sum(
                            x => x.Volume
                        );

                level2TopAskVolume =
                    level2AskRows
                        .Take(
                            Level2TopRows
                        )
                        .Sum(
                            x => x.Volume
                        );

                long total =
                    level2TopBidVolume +
                    level2TopAskVolume;

                level2BookReady =
                    level2BidRows.Count >=
                        Level2WarmupMinRowsPerSide &&
                    level2AskRows.Count >=
                        Level2WarmupMinRowsPerSide &&
                    level2DepthEvents >=
                        Level2WarmupMinDepthEvents;

                if (!level2BookReady)
                {
                    level2BidPct = 50.0;
                    level2AskPct = 50.0;
                    level2Bias = "WARMUP";
                    level2TapeBias = "WARMUP";
                    level2Confluence = "WARMUP";
                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                    level2Absorption = "NONE";
                }

                if (total > 0)
                {
                    level2BidPct =
                        100.0 *
                        level2TopBidVolume /
                        total;

                    level2AskPct =
                        100.0 -
                        level2BidPct;
                }
                else
                {
                    level2BidPct =
                        50.0;

                    level2AskPct =
                        50.0;
                }

                if (
                    level2BookReady &&
                    level2BidPct >=
                    58.0
                )
                {
                    level2Bias =
                        "LONG";
                }
                else if (
                    level2BookReady &&
                    level2AskPct >=
                    58.0
                )
                {
                    level2Bias =
                        "SHORT";
                }
                else
                {
                    level2Bias =
                        level2BookReady
                            ? "NEUTRAL"
                            : "WARMUP";
                }

                long bidFlow =
                    level2BidAdd -
                    level2BidRemove;

                long askFlow =
                    level2AskAdd -
                    level2AskRemove;

                if (
                    bidFlow >= 8 &&
                    askFlow <= -4
                )
                {
                    level2StackPull =
                        "LONG STRONG";
                }
                else if (
                    askFlow >= 8 &&
                    bidFlow <= -4
                )
                {
                    level2StackPull =
                        "SHORT STRONG";
                }
                else if (
                    bidFlow >= 6
                )
                {
                    level2StackPull =
                        "BID STACK";
                }
                else if (
                    askFlow >= 6
                )
                {
                    level2StackPull =
                        "ASK STACK";
                }
                else if (
                    bidFlow <= -6
                )
                {
                    level2StackPull =
                        "BID PULL";
                }
                else if (
                    askFlow <= -6
                )
                {
                    level2StackPull =
                        "ASK PULL";
                }
                else
                {
                    level2StackPull =
                        "BALANCED";
                }

                if (
                    level2BidRows.Count > 0 &&
                    level2AskRows.Count > 0 &&
                    selectedInstrument != null &&
                    selectedInstrument
                        .MasterInstrument !=
                        null &&
                    selectedInstrument
                        .MasterInstrument
                        .TickSize >
                        0
                )
                {
                    double rawSpreadTicks =
                        (
                            level2AskRows[0]
                                .Price -
                            level2BidRows[0]
                                .Price
                        )
                        /
                        selectedInstrument
                            .MasterInstrument
                            .TickSize;

                    // Never publish a negative/crossed spread as valid context.
                    level2SpreadTicks =
                        rawSpreadTicks > 0
                            ? rawSpreadTicks
                            : 0.0;
                }
                else
                {
                    level2SpreadTicks =
                        0.0;
                }

                level2Absorption =
                    "NONE";

                // OBSERVE-ONLY absorption candidates:
                // heavy aggressive selling + relatively resilient bid book
                // can suggest buyers absorbing sells.
                if (
                    level2AggSell >= 40 &&
                    level2AggSell >=
                        level2AggBuy * 1.5 &&
                    level2BidPct >=
                    52.0
                )
                {
                    level2Absorption =
                        "BUY ABSORB CANDIDATE";
                }
                // heavy aggressive buying + relatively resilient ask book
                // can suggest sellers absorbing buys.
                else if (
                    level2AggBuy >= 40 &&
                    level2AggBuy >=
                        level2AggSell * 1.5 &&
                    level2AskPct >=
                    52.0
                )
                {
                    level2Absorption =
                        "SELL ABSORB CANDIDATE";
                }

                // V1.6.44 - Convert raw aggression into contextual flow quality.
                // This does not create a trade or a new hard gate.
                CalculateLevel2AbsorptionEfficiency();

                // Promote the existing candidate label only when price progress
                // confirms that the dominant aggression is being absorbed.
                if (IsLevel2BuyAbsorptionConfirmed())
                {
                    level2Absorption =
                        "BUY ABSORPTION CONFIRMED";
                }
                else if (IsLevel2SellAbsorptionConfirmed())
                {
                    level2Absorption =
                        "SELL ABSORPTION CONFIRMED";
                }

                // -------------------------------------------------
                // TAPE DELTA / TAPE BIAS
                // -------------------------------------------------
                level2TapeDelta =
                    level2AggBuy -
                    level2AggSell;

                double totalAgg =
                    level2AggBuy +
                    level2AggSell;

                if (!level2BookReady)
                {
                    level2TapeBias =
                        "WARMUP";
                }
                else if (totalAgg <= 0)
                {
                    level2TapeBias =
                        "NEUTRAL";
                }
                else
                {
                    double buyPct =
                        100.0 *
                        level2AggBuy /
                        totalAgg;

                    double sellPct =
                        100.0 -
                        buyPct;

                    if (
                        buyPct >= 60.0 &&
                        level2TapeDelta >= 10
                    )
                    {
                        level2TapeBias =
                            "LONG";
                    }
                    else if (
                        sellPct >= 60.0 &&
                        level2TapeDelta <= -10
                    )
                    {
                        level2TapeBias =
                            "SHORT";
                    }
                    else
                    {
                        level2TapeBias =
                            "NEUTRAL";
                    }
                }

                // -------------------------------------------------
                // BOOK + TAPE CONFLUENCE
                // -------------------------------------------------
                if (!level2BookReady)
                {
                    level2Confluence =
                        "WARMUP";
                }
                else if (
                    level2Bias == "LONG" &&
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "STRONG LONG";
                }
                else if (
                    level2Bias == "SHORT" &&
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "STRONG SHORT";
                }
                else if (
                    level2Bias == "LONG" &&
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "CONFLICT BOOK LONG / TAPE SHORT";
                }
                else if (
                    level2Bias == "SHORT" &&
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "CONFLICT BOOK SHORT / TAPE LONG";
                }
                else if (
                    level2Bias == "LONG" ||
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "LEAN LONG";
                }
                else if (
                    level2Bias == "SHORT" ||
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "LEAN SHORT";
                }
                else
                {
                    level2Confluence =
                        "NEUTRAL";
                }

                // -------------------------------------------------
                // PERSISTENCE
                // Consecutive snapshots that keep same directional
                // confluence. Still OBSERVE ONLY.
                // -------------------------------------------------
                if (
                    level2Confluence ==
                        "STRONG LONG" ||
                    level2Confluence ==
                        "LEAN LONG"
                )
                {
                    level2LongPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2LongPersistence + 1
                        );

                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                }
                else if (
                    level2Confluence ==
                        "STRONG SHORT" ||
                    level2Confluence ==
                        "LEAN SHORT"
                )
                {
                    level2ShortPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2ShortPersistence + 1
                        );

                    level2LongPersistence = 0;
                    level2NeutralPersistence = 0;
                }
                else if (level2BookReady)
                {
                    level2NeutralPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2NeutralPersistence + 1
                        );

                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                }
                else
                {
                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                }
            }
        }

        // =====================================================
        // V10.6 - FAST OPEN LEVEL II CONFIRMATION SNAPSHOT
        // =====================================================
        // This is the first controlled use of Level II outside OBSERVE-only
        // logging. It is intentionally NOT an entry trigger by itself.
        // Execution may use it only as confirmation of an already-qualified
        // extreme opening expansion.
        private bool TryGetFastOpenLevel2Support(
            bool isLong,
            out string summary)
        {
            summary =
                "L2 NOT READY";

            lock (level2Sync)
            {
                if (
                    !level2ObserveActive ||
                    !level2BookReady
                )
                {
                    return false;
                }

                // Require a fresh calculation. Stale order-flow must never
                // authorize an opening override.
                if (
                    level2LastCalcUtc ==
                        DateTime.MinValue ||
                    (
                        DateTime.UtcNow -
                        level2LastCalcUtc
                    ).TotalSeconds > 2.0
                )
                {
                    summary =
                        "L2 STALE";

                    return false;
                }

                // Normal MNQ spread is tight. A zero, crossed, or abnormally
                // wide local book is treated as invalid confirmation.
                if (
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary =
                        "L2 INVALID SPREAD "
                        + level2SpreadTicks
                            .ToString("0.0")
                        + "t";

                    return false;
                }

                string desired =
                    isLong
                        ? "LONG"
                        : "SHORT";

                string opposite =
                    isLong
                        ? "SHORT"
                        : "LONG";

                int persistence =
                    isLong
                        ? level2LongPersistence
                        : level2ShortPersistence;

                bool bookAligned =
                    isLong
                        ? level2BidPct >= 58.0
                        : level2AskPct >= 58.0;

                bool tapeOpposes =
                    string.Equals(
                        level2TapeBias,
                        opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool confluenceAligned =
                    string.Equals(
                        level2Confluence,
                        "STRONG " + desired,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    string.Equals(
                        level2Confluence,
                        "LEAN " + desired,
                        StringComparison.OrdinalIgnoreCase
                    );

                // V1.6.44 - Fast Open now reacts only to confirmed
                // price-progress absorption, not a raw candidate. This makes
                // L2 less rigid while keeping protection against real traps.
                bool opposingAbsorption =
                    isLong
                        ? IsLevel2SellAbsorptionConfirmed()
                        : IsLevel2BuyAbsorptionConfirmed();

                bool supported =
                    bookAligned &&
                    persistence >= 5 &&
                    confluenceAligned &&
                    !tapeOpposes &&
                    !opposingAbsorption;

                summary =
                    "Book "
                    + level2Bias
                    + " "
                    + level2BidPct.ToString("0")
                    + "/"
                    + level2AskPct.ToString("0")
                    + " | Tape "
                    + level2TapeBias
                    + " "
                    + level2TapeDelta.ToString("0")
                    + " | Conf "
                    + level2Confluence
                    + " | Persist "
                    + persistence
                    + "/"
                    + Level2PersistenceCap
                    + " | Abs "
                    + level2Absorption
                    + " | Eff "
                    + level2AbsorptionEfficiency
                    + " | Trap "
                    + level2TrappedTraders
                    + " | Spread "
                    + level2SpreadTicks.ToString("0.0")
                    + "t";

                return supported;
            }
        }

        // =====================================================
        // V1.6.42 - OPENING COUNTER-M5 REVERSAL CONFIRMATION
        // =====================================================
        // Level II never creates the setup. This helper only confirms an
        // already-qualified Opening Momentum candidate that is temporarily
        // counter to the lagging M5 trend. Anti-chase, risk, location and
        // universal execution guards still run after this override.
        private bool TryGetOpeningCounterM5ReversalSupport(
            bool isLong,
            int sameSideScore,
            out string summary)
        {
            summary = "REVERSAL SUPPORT NOT CONFIRMED";

            if (sameSideScore < 4)
            {
                summary = "R20 " + sameSideScore + "/5 < 4/5";
                return false;
            }

            int samePressure =
                isLong
                    ? latestDirectionalLongPressureScore
                    : latestDirectionalShortPressureScore;

            int oppositePressure =
                isLong
                    ? latestDirectionalShortPressureScore
                    : latestDirectionalLongPressureScore;

            if (samePressure < 3 || oppositePressure > 1)
            {
                summary =
                    "Pressure "
                    + samePressure
                    + "/"
                    + oppositePressure
                    + " not >=3/1";
                return false;
            }

            string flowSummary;
            bool flowConfirmed =
                TryGetLiquidityBreakFlowSupport(
                    isLong,
                    out flowSummary
                );

            summary =
                "Pressure "
                + samePressure
                + "/"
                + oppositePressure
                + " | "
                + flowSummary;

            return flowConfirmed;
        }

        // =====================================================
        // V1.6.37 - LIQUIDITY BREAK AGGRESSIVE FLOW CONFIRMATION
        // =====================================================
        // Symmetric LONG/SHORT confirmation. Level II still cannot create a
        // setup by itself; it may only confirm a price break already detected
        // by the existing Momentum/Opening engines.
        private bool TryGetLiquidityBreakFlowSupport(
            bool isLong,
            out string summary)
        {
            summary = "L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0
                )
                {
                    summary = "L2 STALE";
                    return false;
                }

                if (level2SpreadTicks <= 0 || level2SpreadTicks > 8.0)
                {
                    summary = "L2 INVALID SPREAD " + level2SpreadTicks.ToString("0.0") + "t";
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                int persistence = isLong ? level2LongPersistence : level2ShortPersistence;

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool tapeOpposes =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool deltaAligned =
                    isLong
                        ? level2TapeDelta >= LiquidityBreakMinTapeDelta
                        : level2TapeDelta <= -LiquidityBreakMinTapeDelta;

                bool opposingAbsorption =
                    isLong
                        ? IsLevel2SellAbsorptionConfirmed()
                        : IsLevel2BuyAbsorptionConfirmed();

                bool trappedReversalSupport =
                    isLong
                        ? AreLevel2SellersTrapped()
                        : AreLevel2BuyersTrapped();

                double desiredAggression =
                    isLong ? level2AggBuy : level2AggSell;

                double oppositeAggression =
                    isLong ? level2AggSell : level2AggBuy;

                bool aggressionAligned =
                    desiredAggression >=
                        Math.Max(1.0, oppositeAggression) * 1.10;

                bool continuationSupported =
                    persistence >= 5 &&
                    confluenceAligned &&
                    deltaAligned &&
                    aggressionAligned &&
                    !tapeOpposes &&
                    !opposingAbsorption;

                // V1.6.44 - Soft reversal intelligence. Trapped traders may
                // confirm an existing price break/reversal setup even while
                // raw tape delta is still lagging. It never creates the setup.
                bool trappedSupported =
                    trappedReversalSupport &&
                    !opposingAbsorption;

                bool supported =
                    continuationSupported ||
                    trappedSupported;

                summary =
                    "Book " + level2Bias + " " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0") +
                    " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist " + persistence + "/" + Level2PersistenceCap +
                    " | Abs " + level2Absorption +
                    " | Eff " + level2AbsorptionEfficiency +
                    " | Trap " + level2TrappedTraders +
                    " | PxProg B/S " + level2BuyProgressTicks.ToString("0.0") + "/" + level2SellProgressTicks.ToString("0.0") + "t" +
                    " | Spread " + level2SpreadTicks.ToString("0.0") + "t";

                return supported;
            }
        }

        // =====================================================
        // V1.6.37 - INITIAL ENTRY LEVEL II STRONG-CONTRARY VETO
        // =====================================================
        // Initial entries are still price/setup driven. This veto only delays
        // execution when very fresh order flow is exceptionally contrary.
        private bool IsInitialEntryLevel2StronglyOpposed(
            bool isLong,
            out string summary)
        {
            summary = "L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    return false;
                }

                string opposite = isLong ? "SHORT" : "LONG";
                int oppositePersistence = isLong ? level2ShortPersistence : level2LongPersistence;
                bool oppositeTape = string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);
                bool oppositeConfluence =
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                double signedOppositeDelta = isLong ? -level2TapeDelta : level2TapeDelta;

                bool oppositeAggressionAbsorbed =
                    isLong
                        ? (IsLevel2BuyAbsorptionConfirmed() || AreLevel2SellersTrapped())
                        : (IsLevel2SellAbsorptionConfirmed() || AreLevel2BuyersTrapped());

                bool rawAggressionStronglyOpposed =
                    signedOppositeDelta >= InitialEntryL2VetoMinDelta &&
                    oppositeAgg >= Math.Max(1.0, desiredAgg) * InitialEntryL2VetoAggressionRatio &&
                    !oppositeAggressionAbsorbed;

                bool persistentOpposition =
                    oppositePersistence >= 5 &&
                    (oppositeTape || oppositeConfluence) &&
                    !oppositeAggressionAbsorbed;

                bool opposed = persistentOpposition || rawAggressionStronglyOpposed;

                summary =
                    "Book " + level2Bias + " " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0") +
                    " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | OppPersist " + oppositePersistence + "/" + Level2PersistenceCap +
                    " | Abs " + level2Absorption +
                    " | Eff " + level2AbsorptionEfficiency +
                    " | Trap " + level2TrappedTraders;

                return opposed;
            }
        }

        // =====================================================
        // V10.7 - SMART RETEST LEVEL II TIMING GUARD
        // =====================================================
        // Smart Retest already has confirmed price/structure context.
        // Level II is therefore NOT used as a new trigger here; it is used
        // only to avoid submitting the retest while the immediate order flow
        // is clearly pushing the opposite way.
        private bool IsSmartRetestLevel2Opposed(
            bool isLong,
            out string summary)
        {
            summary =
                "L2 NOT READY";

            lock (level2Sync)
            {
                if (
                    !level2ObserveActive ||
                    !level2BookReady
                )
                {
                    return false;
                }

                if (
                    level2LastCalcUtc ==
                        DateTime.MinValue ||
                    (
                        DateTime.UtcNow -
                        level2LastCalcUtc
                    ).TotalSeconds > 2.0
                )
                {
                    summary =
                        "L2 STALE";

                    return false;
                }

                if (
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary =
                        "L2 INVALID SPREAD "
                        + level2SpreadTicks.ToString("0.0")
                        + "t";

                    return false;
                }

                string desired =
                    isLong
                        ? "LONG"
                        : "SHORT";

                string opposite =
                    isLong
                        ? "SHORT"
                        : "LONG";

                int oppositePersistence =
                    isLong
                        ? level2ShortPersistence
                        : level2LongPersistence;

                bool oppositeBook =
                    isLong
                        ? level2AskPct >= 58.0
                        : level2BidPct >= 58.0;

                bool oppositeConfluence =
                    string.Equals(
                        level2Confluence,
                        "STRONG " + opposite,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    string.Equals(
                        level2Confluence,
                        "LEAN " + opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool oppositeTape =
                    string.Equals(
                        level2TapeBias,
                        opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                // V1.6.44 - A raw absorption candidate is no longer enough
                // to delay a retest. Require price-progress confirmation.
                bool oppositeAbsorption =
                    isLong
                        ? IsLevel2SellAbsorptionConfirmed()
                        : IsLevel2BuyAbsorptionConfirmed();

                // A 2/6 persistent opposite book+confluence is already enough
                // to delay a Smart Retest. It does not cancel the setup; the
                // pending retest remains armed and can fire on a later Range bar
                // when L2 neutralizes or aligns.
                bool opposed =
                    (
                        oppositeBook &&
                        oppositeConfluence &&
                        oppositePersistence >= 2
                    ) ||
                    (
                        oppositeTape &&
                        oppositePersistence >= 2
                    ) ||
                    oppositeAbsorption;

                summary =
                    "Desired "
                    + desired
                    + " | Book "
                    + level2Bias
                    + " "
                    + level2BidPct.ToString("0")
                    + "/"
                    + level2AskPct.ToString("0")
                    + " | Tape "
                    + level2TapeBias
                    + " "
                    + level2TapeDelta.ToString("0")
                    + " | Conf "
                    + level2Confluence
                    + " | OppPersist "
                    + oppositePersistence
                    + "/"
                    + Level2PersistenceCap
                    + " | Abs "
                    + level2Absorption
                    + " | Spread "
                    + level2SpreadTicks.ToString("0.0")
                    + "t";

                return opposed;
            }
        }

        private void LogLevel2Context()
        {
            long events;
            int bidRows;
            int askRows;

            lock (level2Sync)
            {
                events =
                    level2DepthEvents;

                bidRows =
                    level2BidRows.Count;

                askRows =
                    level2AskRows.Count;
            }

            PrintBotMessage(
                "LEVEL2 CONTEXT"
                + " | Ready: "
                + (
                    level2BookReady
                        ? "YES"
                        : "WARMUP"
                )
                + " | Bias: "
                + level2Bias
                + " | Bid/Ask: "
                + level2BidPct.ToString("0")
                + "%/"
                + level2AskPct.ToString("0")
                + "%"
                + " | Top10 Vol: "
                + level2TopBidVolume
                + "/"
                + level2TopAskVolume
                + " | Rows: "
                + bidRows
                + "/"
                + askRows
                + " | StackPull: "
                + level2StackPull
                + " | AggBuy/Sell: "
                + level2AggBuy.ToString("0")
                + "/"
                + level2AggSell.ToString("0")
                + " | TapeTrades: "
                + level2TapeTrades
                + " | Unknown: "
                + level2UnknownTrades
                + " | TapeDelta: "
                + level2TapeDelta.ToString("0")
                + " | TapeBias: "
                + level2TapeBias
                + " | Confluence: "
                + level2Confluence
                + " | Persistence: "
                + (
                    level2LongPersistence > 0
                        ? "LONG "
                            + level2LongPersistence
                            + "/"
                            + Level2PersistenceCap
                        : level2ShortPersistence > 0
                            ? "SHORT "
                                + level2ShortPersistence
                                + "/"
                                + Level2PersistenceCap
                            : "NEUTRAL "
                                + level2NeutralPersistence
                                + "/"
                                + Level2PersistenceCap
                )
                + " | Absorption: "
                + level2Absorption
                + " | AbsEff: "
                + level2AbsorptionEfficiency
                + " | PxProgress B/S: "
                + level2BuyProgressTicks.ToString("0.0")
                + "/"
                + level2SellProgressTicks.ToString("0.0")
                + "t"
                + " | Eff B/S: "
                + level2BuyEfficiency.ToString("0.0")
                + "/"
                + level2SellEfficiency.ToString("0.0")
                + "t/100"
                + " | Trapped: "
                + level2TrappedTraders
                + " | FlowRead: "
                + level2FlowInterpretation
                + " | Spread: "
                + level2SpreadTicks
                    .ToString("0.0")
                + "t"
                + " | DepthEvents: "
                + events
                + " | OBSERVE ONLY"
            );

            lock (level2Sync)
            {
                level2BidAdd = 0;
                level2BidRemove = 0;
                level2AskAdd = 0;
                level2AskRemove = 0;

                level2AggBuy = 0;
                level2AggSell = 0;
                level2TapeTrades = 0;
                level2UnknownTrades = 0;
            }
        }
    }
}

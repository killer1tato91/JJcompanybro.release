﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // =====================================================
        // V10.1 - LEVEL 2 OBSERVE BOOK FIX
        // =====================================================
        // OBSERVE ONLY.
        // No cambia entradas, dirección, Move Phase, TP/SL,
        // trailing, Scale-In ni Learning.
        // =====================================================

        private sealed class JJLevel2Row
        {
            public double Price;
            public long Volume;
            public string MarketMaker;
        }

        private readonly object level2Sync =
            new object();

        private readonly List<JJLevel2Row> level2BidRows =
            new List<JJLevel2Row>();

        private readonly List<JJLevel2Row> level2AskRows =
            new List<JJLevel2Row>();

        private Instrument level2ObservedInstrument;
        private bool level2ObserveActive;

        private long level2DepthEvents;
        private long level2BidAdd;
        private long level2BidRemove;
        private long level2AskAdd;
        private long level2AskRemove;

        private double level2AggBuy;
        private double level2AggSell;

        private double level2LastTradePrice;
        private double level2LastBidPrice;
        private double level2LastAskPrice;
        private long level2TapeTrades;
        private long level2UnknownTrades;

        private DateTime level2LastCalcUtc =
            DateTime.MinValue;

        private DateTime level2LastLogUtc =
            DateTime.MinValue;

        private const int Level2BookMaxRows = 50;
        private const int Level2TopRows = 10;
        private const int Level2CalcMs = 250;
        private const int Level2LogSeconds = 5;

        // V10.5 - Do not trust the first partial depth snapshot.
        // A valid L2 context requires both sides of the book populated
        // and a minimum number of depth events received.
        private const int Level2WarmupMinRowsPerSide = 10;
        private const long Level2WarmupMinDepthEvents = 500;
        private bool level2BookReady;

        private void StartLevel2Observe()
        {
            StopLevel2Observe();

            if (selectedInstrument == null)
            {
                PrintBotMessage(
                    "LEVEL2 OBSERVE WAIT | Instrument not ready"
                );
                return;
            }

            level2ObservedInstrument =
                selectedInstrument;

            level2ObserveActive = true;

            lock (level2Sync)
            {
                level2BidRows.Clear();
                level2AskRows.Clear();

                level2DepthEvents = 0;
                level2BookReady = false;

                level2BidAdd = 0;
                level2BidRemove = 0;
                level2AskAdd = 0;
                level2AskRemove = 0;

                level2AggBuy = 0;
                level2AggSell = 0;

                level2AbsorptionCandidateSide = "NONE";
                level2AbsorptionCandidateUtc = DateTime.MinValue;
                level2AbsorptionCandidateStartPrice = 0;
                level2AbsorptionCandidateExtremePrice = 0;
                level2AbsorptionCandidateHits = 0;
                level2ConfirmedAbsorptionSide = "NONE";
                level2ConfirmedAbsorptionUtc = DateTime.MinValue;
                level2ConfirmedAbsorptionExtremePrice = 0;
                level2LastConfirmedAbsorptionMemorySide = "NONE";
                level2LastConfirmedAbsorptionMemoryUtc = DateTime.MinValue;
                level2LastConfirmedAbsorptionMemoryExtremePrice = 0;
                level2LastConfirmedAbsorptionMemorySize = 0;
                level2AbsorptionEventHistory.Clear();
                level2LastConfirmedAbsorptionMemoryFailedTicks = 0;
                level2LastBuyConfirmedAbsorptionUtc = DateTime.MinValue;
                level2LastSellConfirmedAbsorptionUtc = DateTime.MinValue;

                level2LastTradePrice = 0;
                level2LastBidPrice = 0;
                level2LastAskPrice = 0;
                level2TapeTrades = 0;
                level2UnknownTrades = 0;
            }

            // V1.7.85 - MARKET BRAIN: only the L2 brain profile subscribes to MarketDepth.
            // Every profile still subscribes to MarketData (price, bid/ask, clock, protection).
            bool v185SubscribeDepth = V185RegisterL2(level2ObservedInstrument);

            level2ObservedInstrument.Dispatcher.BeginInvoke(
                new Action(
                    () =>
                    {
                        if (
                            level2ObserveActive &&
                            level2ObservedInstrument != null
                        )
                        {
                            if (v185SubscribeDepth && !v185DepthSubscribed)
                            {
                                level2ObservedInstrument
                                    .MarketDepth
                                    .Update +=
                                    OnLevel2DepthUpdate;

                                v185DepthSubscribed = true;
                            }

                            level2ObservedInstrument
                                .MarketData
                                .Update +=
                                OnLevel2MarketDataUpdate;
                        }
                    }
                )
            );

            PrintBotMessage(
                "LEVEL2 OBSERVE ACTIVE | "
                + selectedInstrument.FullName
                + " | BOOK FIX V10.7 + UNIFIED EDGE AUTHORITY V1.6.63 + DAILY LOG | CONFIRMATION ACTIVE"
            );
        }

        private void StopLevel2Observe()
        {
            // V1.7.85 - leave the market brain (hands Level 2 to the next profile if this was the brain)
            V185UnregisterL2();

            Instrument oldInstrument =
                level2ObservedInstrument;

            level2ObserveActive = false;
            level2ObservedInstrument = null;

            if (oldInstrument != null)
            {
                oldInstrument.Dispatcher.BeginInvoke(
                    new Action(
                        () =>
                        {
                            try
                            {
                                oldInstrument
                                    .MarketDepth
                                    .Update -=
                                    OnLevel2DepthUpdate;

                                v185DepthSubscribed = false;

                                oldInstrument
                                    .MarketData
                                    .Update -=
                                    OnLevel2MarketDataUpdate;
                            }
                            catch
                            {
                            }
                        }
                    )
                );
            }

            lock (level2Sync)
            {
                level2BidRows.Clear();
                level2AskRows.Clear();
            }
        }

        // V1.7.101 - body of the old handler; called by the event pump (JJBotV1101EventPump.cs)
        private void V1101CoreLevel2Depth(
            object sender,
            MarketDepthEventArgs e)
        {
            if (
                !level2ObserveActive ||
                e == null
            )
            {
                return;
            }

            // V1.7.85 - a follower never builds its own book (late event after a hand-over)
            if (V185IsL2Follower())
                return;

            lock (level2Sync)
            {
                level2DepthEvents++;

                if (
                    e.MarketDataType ==
                    MarketDataType.Bid
                )
                {
                    ApplyDepthEvent(
                        level2BidRows,
                        e,
                        true
                    );
                }
                else if (
                    e.MarketDataType ==
                    MarketDataType.Ask
                )
                {
                    ApplyDepthEvent(
                        level2AskRows,
                        e,
                        false
                    );
                }
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            if (
                (
                    nowUtc -
                    level2LastCalcUtc
                ).TotalMilliseconds >=
                Level2CalcMs
            )
            {
                level2LastCalcUtc =
                    nowUtc;

                CalculateLevel2Context();

                // V1.7.85 - share the new L2 state with the other profiles
                V185PublishL2();
            }

            if (
                (
                    nowUtc -
                    level2LastLogUtc
                ).TotalSeconds >=
                Level2LogSeconds
            )
            {
                level2LastLogUtc =
                    nowUtc;

                LogLevel2Context();

                // V1.7.85 - publish again: carries the context line and the zeroed counters
                V185PublishL2();
            }
        }

        // V1.7.35 - last traded tick time (NY).  Authority for the central
        // signal window and decision age, live and Playback.
        private DateTime centralTickClockNy = DateTime.MinValue;

        private DateTime GetCentralClockNy()
        {
            DateTime strategyClock = GetCurrentNewYorkTime();
            DateTime tickClock = centralTickClockNy;

            if (tickClock == DateTime.MinValue)
                return strategyClock;

            // A stale tick clock (feed paused / window just opened) must
            // never be older than the coarse strategy clock by > 5 min.
            if ((strategyClock - tickClock).TotalMinutes > 5.0)
                return strategyClock;

            return tickClock;
        }

        // V1.7.101 - body of the old handler; called by the event pump (JJBotV1101EventPump.cs)
        private void V1101CoreLevel2MarketData(
            object sender,
            MarketDataEventArgs e)
        {
            if (
                !level2ObserveActive ||
                e == null
            )
            {
                return;
            }

            // V1.7.84 - drop stale / out-of-order trades in LIVE (see JJBotV184Fixes.cs).
            if (e.MarketDataType == MarketDataType.Last)
            {
                string v184Log;
                bool v184Ok = V184AcceptTick(v184Level2Clock, e.Time, IsPlaybackStrategyClockActive(), out v184Log);

                if (v184Log != null)
                    PrintBotMessage("LEVEL2 FEED | " + v184Log);

                if (!v184Ok)
                {
                    // V1.7.100 - a late trade is still real volume: count it in the tape
                    // (never its price or its time). JJBotV1100LowLatency.cs
                    V1100CountLateTradeInTape(e);
                    return;
                }

                // V1.7.84 - protection keeps running from live ticks even if the bars lag.
                V184TickDrivenProtection(e.Price);
            }

            // V1.7.86 - the market brain proves it is alive with every market event
            V186BrainAliveFromData();

            // V1.7.85 - followers copy the L2 brain's newest snapshot
            V185ApplyL2IfFollower();

            // V1.7.93 - the L2 brain keeps publishing its tape even when depth events stop
            V193PublishFromTapeIfLeader();

            // V1.7.97 - remember when the tape was LONG / SHORT (HYBRID tape gate, JJBotV195Fixes.cs)
            V197TrackTape();

            lock (level2Sync)
            {
                if (
                    e.MarketDataType ==
                    MarketDataType.Bid
                )
                {
                    level2LastBidPrice =
                        e.Price;

                    return;
                }

                if (
                    e.MarketDataType ==
                    MarketDataType.Ask
                )
                {
                    level2LastAskPrice =
                        e.Price;

                    return;
                }

                if (
                    e.MarketDataType !=
                    MarketDataType.Last
                )
                {
                    return;
                }

                // V1.7.31 - drive the central signal arbiter from the
                // strategy/Playback market clock.  This closes the tiny
                // arbitration window without DateTime.UtcNow and keeps live
                // and Replay in the same timing domain.
                // V1.7.35 - TICK-PRECISE central clock.  The Playback strategy
                // clock only advances per M5 bar, which kept the 125 ms window
                // open for up to 5 minutes.  The tick's own market time is
                // exact in both live and Playback.
                if (selectedInstrument != null)
                {
                    DateTime tickClockNy =
                        ConvertToNewYorkTime(
                            e.Time
                        );

                    if (tickClockNy > centralTickClockNy)
                        centralTickClockNy = tickClockNy;

                    JJBotCentralBrain.ObserveMarketTime(
                        selectedInstrument.FullName,
                        GetCentralClockNy()
                    );
                }

                level2LastTradePrice =
                    e.Price;

                // V1.7.97 - HYBRID limit-on-retrace shadow (log only, JJBotV197LimitShadow.cs)
                V197LimitShadowOnTick(e.Time, e.Price);

                v184LastTradeUtc = DateTime.UtcNow;

                // V1.7.85 - followers do not count the tape themselves: the counts come from
                // the L2 brain (otherwise every profile reads a different tape).
                if (V185IsL2Follower())
                    return;

                level2TapeTrades++;

                double tradeVolume =
                    Math.Max(
                        0,
                        e.Volume
                    );

                double tickSize =
                    0.0;

                if (
                    selectedInstrument != null &&
                    selectedInstrument
                        .MasterInstrument != null
                )
                {
                    tickSize =
                        selectedInstrument
                            .MasterInstrument
                            .TickSize;
                }

                double epsilon =
                    tickSize > 0
                        ? tickSize * 0.25
                        : 0.0000001;

                // V1.7.98 - HVN absorption shadow: LOG + CSV only (JJBotV198AbsorptionShadow.cs)
                V198AbsorptionOnTrade(e.Time, e.Price, tradeVolume, level2LastBidPrice, level2LastAskPrice, tickSize);

                // Aggressive buy:
                // Last trade executes at/through current ask.
                if (
                    level2LastAskPrice > 0 &&
                    e.Price >=
                    level2LastAskPrice -
                    epsilon
                )
                {
                    level2AggBuy +=
                        tradeVolume;

                    return;
                }

                // Aggressive sell:
                // Last trade executes at/through current bid.
                if (
                    level2LastBidPrice > 0 &&
                    e.Price <=
                    level2LastBidPrice +
                    epsilon
                )
                {
                    level2AggSell +=
                        tradeVolume;

                    return;
                }

                // If trade occurs between bid/ask, classify by
                // proximity to the nearest side when possible.
                if (
                    level2LastBidPrice > 0 &&
                    level2LastAskPrice > 0
                )
                {
                    double bidDistance =
                        Math.Abs(
                            e.Price -
                            level2LastBidPrice
                        );

                    double askDistance =
                        Math.Abs(
                            level2LastAskPrice -
                            e.Price
                        );

                    if (
                        askDistance <
                        bidDistance
                    )
                    {
                        level2AggBuy +=
                            tradeVolume;
                    }
                    else if (
                        bidDistance <
                        askDistance
                    )
                    {
                        level2AggSell +=
                            tradeVolume;
                    }
                    else
                    {
                        level2UnknownTrades++;
                    }
                }
                else
                {
                    level2UnknownTrades++;
                }
            }
        }

        private void ApplyDepthEvent(
            List<JJLevel2Row> book,
            MarketDepthEventArgs e,
            bool isBid)
        {
            int position =
                e.Position;

            switch (e.Operation)
            {
                case Operation.Add:
                {
                    JJLevel2Row row =
                        CreateDepthRow(e);

                    if (position < 0)
                        position = 0;

                    if (position > book.Count)
                        position = book.Count;

                    book.Insert(
                        position,
                        row
                    );

                    if (isBid)
                        level2BidAdd++;
                    else
                        level2AskAdd++;

                    break;
                }

                case Operation.Update:
                {
                    JJLevel2Row row =
                        CreateDepthRow(e);

                    // V10.6:
                    // MarketDepth position indexes are provider snapshots and
                    // can become stale while events are arriving quickly.
                    // Price is the stable identity for our normalized local book.
                    // Update by price first; only use the position as fallback.
                    int priceIndex =
                        FindDepthIndexByPrice(
                            book,
                            row.Price
                        );

                    if (priceIndex >= 0)
                    {
                        book[priceIndex] =
                            row;
                    }
                    else if (
                        position >= 0 &&
                        position < book.Count
                    )
                    {
                        book[position] =
                            row;
                    }
                    else
                    {
                        book.Add(
                            row
                        );
                    }

                    break;
                }

                case Operation.Remove:
                {
                    // V10.6:
                    // Remove by price first. Removing an old positional index
                    // was the main way a valid best bid/ask could survive while
                    // a different row was deleted, producing impossible
                    // negative spreads.
                    int priceIndex =
                        FindDepthIndexByPrice(
                            book,
                            e.Price
                        );

                    if (priceIndex >= 0)
                    {
                        book.RemoveAt(
                            priceIndex
                        );
                    }
                    else if (
                        position >= 0 &&
                        position < book.Count
                    )
                    {
                        book.RemoveAt(
                            position
                        );
                    }

                    if (isBid)
                        level2BidRemove++;
                    else
                        level2AskRemove++;

                    break;
                }
            }

            NormalizeDepthBook(
                book,
                isBid
            );

            SanitizeCrossedLevel2Book(
                isBid
            );
        }

        private void SanitizeCrossedLevel2Book(
            bool updatedBidSide)
        {
            if (
                level2BidRows.Count == 0 ||
                level2AskRows.Count == 0
            )
            {
                return;
            }

            double bestBid =
                level2BidRows[0].Price;

            double bestAsk =
                level2AskRows[0].Price;

            if (
                bestBid <= 0 ||
                bestAsk <= 0 ||
                bestAsk > bestBid
            )
            {
                return;
            }

            // A real limit book must have Ask > Bid. A crossed local book here
            // means one stale row survived an asynchronous depth update.
            // Remove only the stale/opposite rows made impossible by the fresh
            // side, then re-normalize that side.
            if (updatedBidSide)
            {
                level2AskRows.RemoveAll(
                    row =>
                        row != null &&
                        row.Price <= bestBid
                );

                NormalizeDepthBook(
                    level2AskRows,
                    false
                );
            }
            else
            {
                level2BidRows.RemoveAll(
                    row =>
                        row != null &&
                        row.Price >= bestAsk
                );

                NormalizeDepthBook(
                    level2BidRows,
                    true
                );
            }
        }

        private JJLevel2Row CreateDepthRow(
            MarketDepthEventArgs e)
        {
            return new JJLevel2Row
            {
                Price = e.Price,
                Volume = Math.Max(
                    0,
                    Convert.ToInt64(
                        e.Volume
                    )
                ),
                MarketMaker =
                    e.MarketMaker ??
                    string.Empty
            };
        }

        private int FindDepthIndexByPrice(
            List<JJLevel2Row> book,
            double price)
        {
            if (book == null)
                return -1;

            return book.FindIndex(
                x =>
                    x != null &&
                    Math.Abs(
                        x.Price -
                        price
                    ) <
                    0.0000001
            );
        }

        private void UpsertDepthByPrice(
            List<JJLevel2Row> book,
            JJLevel2Row row)
        {
            int index =
                FindDepthIndexByPrice(
                    book,
                    row.Price
                );

            if (index >= 0)
            {
                book[index] =
                    row;
            }
            else
            {
                book.Add(
                    row
                );
            }
        }

        private void RemoveDepthByPrice(
            List<JJLevel2Row> book,
            double price)
        {
            int index =
                FindDepthIndexByPrice(
                    book,
                    price
                );

            if (index >= 0)
            {
                book.RemoveAt(
                    index
                );
            }
        }

        private void NormalizeDepthBook(
            List<JJLevel2Row> book,
            bool isBid)
        {
            if (isBid)
            {
                book.Sort(
                    (a, b) =>
                        b.Price.CompareTo(
                            a.Price
                        )
                );
            }
            else
            {
                book.Sort(
                    (a, b) =>
                        a.Price.CompareTo(
                            b.Price
                        )
                );
            }

            for (
                int i =
                    book.Count - 1;
                i > 0;
                i--
            )
            {
                if (
                    Math.Abs(
                        book[i].Price -
                        book[i - 1].Price
                    ) <
                    0.0000001
                )
                {
                    book[i - 1].Volume =
                        Math.Max(
                            book[i - 1]
                                .Volume,
                            book[i]
                                .Volume
                        );

                    book.RemoveAt(
                        i
                    );
                }
            }

            if (
                book.Count >
                Level2BookMaxRows
            )
            {
                book.RemoveRange(
                    Level2BookMaxRows,
                    book.Count -
                    Level2BookMaxRows
                );
            }
        }

        private double level2BidPct = 50.0;
        private double level2AskPct = 50.0;

        private long level2TopBidVolume;
        private long level2TopAskVolume;

        private string level2Bias =
            "NEUTRAL";

        private string level2StackPull =
            "BALANCED";

        private string level2Absorption =
            "NONE";

        // =====================================================
        // V1.6.55 - CONFIRMED ABSORPTION / TRAPPED TRADER STATE
        // =====================================================
        private string level2AbsorptionCandidateSide = "NONE";
        private DateTime level2AbsorptionCandidateUtc = DateTime.MinValue;
        private double level2AbsorptionCandidateStartPrice;
        private double level2AbsorptionCandidateExtremePrice;
        private int level2AbsorptionCandidateHits;

        private string level2ConfirmedAbsorptionSide = "NONE";
        private DateTime level2ConfirmedAbsorptionUtc = DateTime.MinValue;
        private double level2ConfirmedAbsorptionExtremePrice;

        // V1.6.72 - preserve the last confirmed absorption event beyond the
        // short visible CONFIRMED TTL. Explosion execution uses this as a
        // brief reversal-window memory so a 4s display expiry cannot erase
        // a still-relevant microstructure event just before entry.
        private string level2LastConfirmedAbsorptionMemorySide = "NONE";
        private DateTime level2LastConfirmedAbsorptionMemoryUtc = DateTime.MinValue;
        private double level2LastConfirmedAbsorptionMemoryExtremePrice;
        private double level2LastConfirmedAbsorptionMemorySize;
        // V1.7.78 - rolling history of confirmed absorptions + price (persistence / zone).
        private readonly List<AbsorptionEventRecord> level2AbsorptionEventHistory = new List<AbsorptionEventRecord>();
        private readonly List<KeyValuePair<DateTime, double>> level2PriceHistory = new List<KeyValuePair<DateTime, double>>();
        private DateTime level2PriceHistoryLastSampleUtc = DateTime.MinValue;

        private struct AbsorptionEventRecord
        {
            public DateTime Utc;
            public string Side;
            public double Size;
            public double Extreme;
        }
        private double level2LastConfirmedAbsorptionMemoryFailedTicks;

        // V1.6.75 - two-sided confirmation memory. Used only to recognize
        // rotational/contested absorption zones; it does not replace the
        // existing current/last-confirmed absorption authority.
        private DateTime level2LastBuyConfirmedAbsorptionUtc = DateTime.MinValue;
        private DateTime level2LastSellConfirmedAbsorptionUtc = DateTime.MinValue;

        // V1.6.70 - require more persistence before declaring a trapped-side
        // reversal. This reduces rapid BUY/SELL confirmation ping-pong while
        // keeping genuine heavy absorption available to entry/management.
        private const double AbsorptionAggressionRatio = 1.60;
        private const double AbsorptionMinAggression = 60.0;
        private const int AbsorptionMinCandidateHits = 3;
        private const double AbsorptionMinReclaimTicks = 5.0;
        private const double AbsorptionMaxAdverseProgressTicks = 16.0;
        private const double AbsorptionCandidateMaxSeconds = 6.0;
        private const double AbsorptionConfirmedTtlSeconds = 4.0;

        private double level2SpreadTicks;

        // =====================================================
        // V10.4 - LEVEL2 FLOW SUMMARY / OBSERVE ONLY
        // =====================================================
        private double level2TapeDelta;
        private string level2TapeBias =
            "NEUTRAL";

        private string level2Confluence =
            "NEUTRAL";

        private int level2LongPersistence;
        private int level2ShortPersistence;
        private int level2NeutralPersistence;

        private const int Level2PersistenceCap = 6;

        private void CalculateLevel2Context()
        {
            lock (level2Sync)
            {
                level2TopBidVolume =
                    level2BidRows
                        .Take(
                            Level2TopRows
                        )
                        .Sum(
                            x => x.Volume
                        );

                level2TopAskVolume =
                    level2AskRows
                        .Take(
                            Level2TopRows
                        )
                        .Sum(
                            x => x.Volume
                        );

                long total =
                    level2TopBidVolume +
                    level2TopAskVolume;

                level2BookReady =
                    level2BidRows.Count >=
                        Level2WarmupMinRowsPerSide &&
                    level2AskRows.Count >=
                        Level2WarmupMinRowsPerSide &&
                    level2DepthEvents >=
                        Level2WarmupMinDepthEvents;

                if (!level2BookReady)
                {
                    level2BidPct = 50.0;
                    level2AskPct = 50.0;
                    level2Bias = "WARMUP";
                    level2TapeBias = "WARMUP";
                    level2Confluence = "WARMUP";
                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                    level2Absorption = "NONE";
                }

                if (total > 0)
                {
                    level2BidPct =
                        100.0 *
                        level2TopBidVolume /
                        total;

                    level2AskPct =
                        100.0 -
                        level2BidPct;
                }
                else
                {
                    level2BidPct =
                        50.0;

                    level2AskPct =
                        50.0;
                }

                if (
                    level2BookReady &&
                    level2BidPct >=
                    58.0
                )
                {
                    level2Bias =
                        "LONG";
                }
                else if (
                    level2BookReady &&
                    level2AskPct >=
                    58.0
                )
                {
                    level2Bias =
                        "SHORT";
                }
                else
                {
                    level2Bias =
                        level2BookReady
                            ? "NEUTRAL"
                            : "WARMUP";
                }

                long bidFlow =
                    level2BidAdd -
                    level2BidRemove;

                long askFlow =
                    level2AskAdd -
                    level2AskRemove;

                if (
                    bidFlow >= 8 &&
                    askFlow <= -4
                )
                {
                    level2StackPull =
                        "LONG STRONG";
                }
                else if (
                    askFlow >= 8 &&
                    bidFlow <= -4
                )
                {
                    level2StackPull =
                        "SHORT STRONG";
                }
                else if (
                    bidFlow >= 6
                )
                {
                    level2StackPull =
                        "BID STACK";
                }
                else if (
                    askFlow >= 6
                )
                {
                    level2StackPull =
                        "ASK STACK";
                }
                else if (
                    bidFlow <= -6
                )
                {
                    level2StackPull =
                        "BID PULL";
                }
                else if (
                    askFlow <= -6
                )
                {
                    level2StackPull =
                        "ASK PULL";
                }
                else
                {
                    level2StackPull =
                        "BALANCED";
                }

                if (
                    level2BidRows.Count > 0 &&
                    level2AskRows.Count > 0 &&
                    selectedInstrument != null &&
                    selectedInstrument
                        .MasterInstrument !=
                        null &&
                    selectedInstrument
                        .MasterInstrument
                        .TickSize >
                        0
                )
                {
                    double rawSpreadTicks =
                        (
                            level2AskRows[0]
                                .Price -
                            level2BidRows[0]
                                .Price
                        )
                        /
                        selectedInstrument
                            .MasterInstrument
                            .TickSize;

                    // Never publish a negative/crossed spread as valid context.
                    level2SpreadTicks =
                        rawSpreadTicks > 0
                            ? rawSpreadTicks
                            : 0.0;
                }
                else
                {
                    level2SpreadTicks =
                        0.0;
                }

                UpdateAbsorptionState();

                // -------------------------------------------------
                // TAPE DELTA / TAPE BIAS
                // -------------------------------------------------
                level2TapeDelta =
                    level2AggBuy -
                    level2AggSell;

                double totalAgg =
                    level2AggBuy +
                    level2AggSell;

                if (!level2BookReady)
                {
                    level2TapeBias =
                        "WARMUP";
                }
                else if (totalAgg <= 0)
                {
                    level2TapeBias =
                        "NEUTRAL";
                }
                else
                {
                    double buyPct =
                        100.0 *
                        level2AggBuy /
                        totalAgg;

                    double sellPct =
                        100.0 -
                        buyPct;

                    if (
                        buyPct >= 60.0 &&
                        level2TapeDelta >= 10
                    )
                    {
                        level2TapeBias =
                            "LONG";
                    }
                    else if (
                        sellPct >= 60.0 &&
                        level2TapeDelta <= -10
                    )
                    {
                        level2TapeBias =
                            "SHORT";
                    }
                    else
                    {
                        level2TapeBias =
                            "NEUTRAL";
                    }
                }

                // -------------------------------------------------
                // BOOK + TAPE CONFLUENCE
                // -------------------------------------------------
                if (!level2BookReady)
                {
                    level2Confluence =
                        "WARMUP";
                }
                else if (
                    level2Bias == "LONG" &&
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "STRONG LONG";
                }
                else if (
                    level2Bias == "SHORT" &&
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "STRONG SHORT";
                }
                else if (
                    level2Bias == "LONG" &&
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "CONFLICT BOOK LONG / TAPE SHORT";
                }
                else if (
                    level2Bias == "SHORT" &&
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "CONFLICT BOOK SHORT / TAPE LONG";
                }
                else if (
                    level2Bias == "LONG" ||
                    level2TapeBias == "LONG"
                )
                {
                    level2Confluence =
                        "LEAN LONG";
                }
                else if (
                    level2Bias == "SHORT" ||
                    level2TapeBias == "SHORT"
                )
                {
                    level2Confluence =
                        "LEAN SHORT";
                }
                else
                {
                    level2Confluence =
                        "NEUTRAL";
                }

                // -------------------------------------------------
                // PERSISTENCE
                // Consecutive snapshots that keep same directional
                // confluence. Still OBSERVE ONLY.
                // -------------------------------------------------
                if (
                    level2Confluence ==
                        "STRONG LONG" ||
                    level2Confluence ==
                        "LEAN LONG"
                )
                {
                    level2LongPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2LongPersistence + 1
                        );

                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                }
                else if (
                    level2Confluence ==
                        "STRONG SHORT" ||
                    level2Confluence ==
                        "LEAN SHORT"
                )
                {
                    level2ShortPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2ShortPersistence + 1
                        );

                    level2LongPersistence = 0;
                    level2NeutralPersistence = 0;
                }
                else if (level2BookReady)
                {
                    level2NeutralPersistence =
                        Math.Min(
                            Level2PersistenceCap,
                            level2NeutralPersistence + 1
                        );

                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                }
                else
                {
                    level2LongPersistence = 0;
                    level2ShortPersistence = 0;
                    level2NeutralPersistence = 0;
                }
            }
        }

        // =====================================================
        // V1.6.80 - LEVEL II AUTHORITY CONTEXT ADAPTER
        // =====================================================
        // Converts the existing Level II calculation into context labels.
        // It does not alter book/tape/absorption calculations and is never
        // an entry trigger by itself.
        private string GetLevel2AuthorityContext(bool isLong)
        {
            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return "NEUTRAL";

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                int samePersistence = isLong ? level2LongPersistence : level2ShortPersistence;
                int oppositePersistence = isLong ? level2ShortPersistence : level2LongPersistence;

                bool supportive =
                    (string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(level2Bias, desired, StringComparison.OrdinalIgnoreCase)) &&
                    samePersistence >= 3;

                // V1.7.63 - fixed label: absorption strings are BUY/SELL (not LONG/SHORT), so the old
                // IndexOf(opposite) never matched. Opposing absorption = SELL for a LONG, BUY for a SHORT.
                bool opposingAbsorption =
                    !string.IsNullOrWhiteSpace(level2Absorption) &&
                    level2Absorption.StartsWith(isLong ? "SELL" : "BUY", StringComparison.OrdinalIgnoreCase);

                bool conflict =
                    opposingAbsorption ||
                    oppositePersistence >= 5 ||
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                if (conflict)
                    return "CONFLICT";
                if (supportive)
                    return "SUPPORTIVE";
                return "NEUTRAL";
            }
        }

        // =====================================================
        // V1.7.63 - SHARED LEVEL II CONTRARY-FLOW VETO (CORE20 + HYBRID)
        // =====================================================
        // Veto-only: it NEVER creates an entry. It uses the SAME definitions as the
        // HYBRID impulse qualifier (TryGetHybridImpulseLiveFlow): confirmed opposing
        // absorption, or contrary flow dominating (tape opposed + opposing delta,
        // 5/6 contrary persistence, or contrary aggression >= 1.65x ours).
        // Unlike that qualifier it does NOT require positive evidence, so a book that
        // is not ready / a thin tape window never blocks a trade (fail-open).
        // NOTE: GetLevel2AuthorityContext() "CONFLICT" is much looser (the tape bias
        // flips every few seconds): it was CONFLICT on 3 of 3 Open Bell days with a
        // ready book, so it must not be used as a veto.
        private bool IsLevel2ContraryFlowVeto(bool isLong, out string summary)
        {
            summary = "L2 N/A";
            lock (level2Sync)
            {
                double age = level2LastCalcUtc == DateTime.MinValue
                    ? 999.0
                    : (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds;

                if (!level2ObserveActive || !level2BookReady ||
                    age < 0.0 || age > 2.0 ||
                    level2SpreadTicks <= 0.0 || level2SpreadTicks > 4.0)
                {
                    summary = "L2 NOT READY | Age " + age.ToString("0.0")
                        + "s | Spread " + level2SpreadTicks.ToString("0.0") + "t";
                    return false;
                }

                string opposite = isLong ? "SHORT" : "LONG";
                double alignedDelta = isLong ? level2TapeDelta : -level2TapeDelta;
                double alignedAgg = isLong ? level2AggBuy : level2AggSell;
                double contraryAgg = isLong ? level2AggSell : level2AggBuy;
                int contraryPersistence = isLong ? level2ShortPersistence : level2LongPersistence;

                bool tapeOpposed = string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);
                bool opposingAbsorptionConfirmed = isLong
                    ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                    : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                // The tape counters are zeroed after every context print, so a window with
                // fewer than 12 trades is too thin to judge flow (absorption can still veto).
                bool sampleOk = level2TapeTrades >= 12;
                bool contraryDominates = sampleOk && (
                    (tapeOpposed && alignedDelta <= -12.0) ||
                    (contraryPersistence >= 5 && alignedDelta < 0.0) ||
                    (contraryAgg >= Math.Max(1.0, alignedAgg) * 1.65 && alignedDelta < 0.0));

                bool veto = opposingAbsorptionConfirmed || contraryDominates;

                summary = (veto ? "CONTRARY " : "NO CONTRARY ")
                    + (isLong ? "LONG" : "SHORT")
                    + " | Delta " + level2TapeDelta.ToString("0")
                    + " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0")
                    + " | Tape " + level2TapeBias + " (" + level2TapeTrades + " trades)"
                    + " | Persist contra " + contraryPersistence
                    + " | Abs " + level2Absorption
                    + (opposingAbsorptionConfirmed ? " [OPPOSING ABSORPTION]" : string.Empty)
                    + (contraryDominates ? " [CONTRARY DOMINATES]" : string.Empty);

                return veto;
            }
        }

        // =====================================================
        // V10.6 - FAST OPEN LEVEL II CONFIRMATION SNAPSHOT
        // =====================================================
        // This is the first controlled use of Level II outside OBSERVE-only
        // logging. It is intentionally NOT an entry trigger by itself.
        // Execution may use it only as confirmation of an already-qualified
        // extreme opening expansion.
        private bool TryGetFastOpenLevel2Support(
            bool isLong,
            out string summary)
        {
            summary =
                "L2 NOT READY";

            lock (level2Sync)
            {
                if (
                    !level2ObserveActive ||
                    !level2BookReady
                )
                {
                    return false;
                }

                // Require a fresh calculation. Stale order-flow must never
                // authorize an opening override.
                if (
                    level2LastCalcUtc ==
                        DateTime.MinValue ||
                    (
                        DateTime.UtcNow -
                        level2LastCalcUtc
                    ).TotalSeconds > 2.0
                )
                {
                    summary =
                        "L2 STALE";

                    return false;
                }

                // Normal MNQ spread is tight. A zero, crossed, or abnormally
                // wide local book is treated as invalid confirmation.
                if (
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary =
                        "L2 INVALID SPREAD "
                        + level2SpreadTicks
                            .ToString("0.0")
                        + "t";

                    return false;
                }

                string desired =
                    isLong
                        ? "LONG"
                        : "SHORT";

                string opposite =
                    isLong
                        ? "SHORT"
                        : "LONG";

                int persistence =
                    isLong
                        ? level2LongPersistence
                        : level2ShortPersistence;

                bool bookAligned =
                    isLong
                        ? level2BidPct >= 58.0
                        : level2AskPct >= 58.0;

                bool tapeOpposes =
                    string.Equals(
                        level2TapeBias,
                        opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool confluenceAligned =
                    string.Equals(
                        level2Confluence,
                        "STRONG " + desired,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    string.Equals(
                        level2Confluence,
                        "LEAN " + desired,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool opposingAbsorption =
                    isLong
                        ? string.Equals(
                            level2Absorption,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            level2Absorption,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool supported =
                    bookAligned &&
                    persistence >= 5 &&
                    confluenceAligned &&
                    !tapeOpposes &&
                    !opposingAbsorption;

                summary =
                    "Book "
                    + level2Bias
                    + " "
                    + level2BidPct.ToString("0")
                    + "/"
                    + level2AskPct.ToString("0")
                    + " | Tape "
                    + level2TapeBias
                    + " "
                    + level2TapeDelta.ToString("0")
                    + " | Conf "
                    + level2Confluence
                    + " | Persist "
                    + persistence
                    + "/"
                    + Level2PersistenceCap
                    + " | Abs "
                    + level2Absorption
                    + " | Spread "
                    + level2SpreadTicks.ToString("0.0")
                    + "t";

                return supported;
            }
        }

        // =====================================================
        // V1.6.51 - OPENING REVERSAL AUTHORITY FIX
        // =====================================================
        // M5 / Opening Pressure are context, not an absolute veto, when the
        // CURRENT opening reversal already has price/structure/location plus
        // fresh aligned order-flow.  This fixes the 09:35-09:41 case where a
        // SHORT had BELOW VWAP + HIGH SWEPT + BEARISH CHOCH + 3/4 SellScore
        // but the lagging bullish M5 / neutral opening pressure kept forcing
        // WAIT SMART RETEST while price continued lower.
        //
        // Level II still cannot create a setup by itself.  A 3/5 counter-M5
        // candidate is eligible only when structure + VWAP + liquidity are
        // already aligned.  Ordinary counter-M5 candidates keep the stricter
        // 4/5 + 3/1 pressure path.
        private bool TryGetOpeningCounterM5ReversalSupport(
            bool isLong,
            int sameSideScore,
            out string summary)
        {
            summary = "REVERSAL SUPPORT NOT CONFIRMED";

            bool vwapAligned =
                isLong
                    ? latestM5AboveVwap
                    : latestM5BelowVwap;

            string structure =
                (latestM5StructureState ?? string.Empty)
                    .Trim()
                    .ToUpperInvariant();

            bool structureAligned =
                isLong
                    ? (
                        structure.Contains("BULLISH CHOCH") ||
                        structure.Contains("BULLISH BOS")
                      )
                    : (
                        structure.Contains("BEARISH CHOCH") ||
                        structure.Contains("BEARISH BOS")
                      );

            string liquidity =
                (latestM5LiquidityState ?? string.Empty)
                    .Trim()
                    .ToUpperInvariant();

            bool sweepAligned =
                isLong
                    ? liquidity.Contains("LOW SWEPT")
                    : liquidity.Contains("HIGH SWEPT");

            bool openingReversalContext =
                sameSideScore >= 3 &&
                vwapAligned &&
                structureAligned &&
                sweepAligned;

            string earlyFlowSummary;
            bool earlyFlowConfirmed =
                TryGetEarlyAggressionFlowSupport(
                    isLong,
                    out earlyFlowSummary
                );

            bool authorityFlowAligned;
            bool authorityFlowOpposed;
            string authorityFlowSummary;
            GetFreshDirectionalFlowAuthority(
                isLong,
                out authorityFlowAligned,
                out authorityFlowOpposed,
                out authorityFlowSummary
            );

            if (
                openingReversalContext &&
                !authorityFlowOpposed &&
                (earlyFlowConfirmed || authorityFlowAligned)
            )
            {
                summary =
                    "REVERSAL CONTEXT"
                    + " | R20 " + sameSideScore + "/5"
                    + " | VWAP ALIGNED"
                    + " | " + structure
                    + " | " + liquidity
                    + " | "
                    + (earlyFlowConfirmed ? earlyFlowSummary : authorityFlowSummary);

                return true;
            }

            if (sameSideScore < 4)
            {
                summary =
                    "R20 " + sameSideScore + "/5 < 4/5"
                    + " | ReversalContext="
                    + (openingReversalContext ? "YES" : "NO")
                    + " | " + earlyFlowSummary;
                return false;
            }

            int samePressure =
                isLong
                    ? latestDirectionalLongPressureScore
                    : latestDirectionalShortPressureScore;

            int oppositePressure =
                isLong
                    ? latestDirectionalShortPressureScore
                    : latestDirectionalLongPressureScore;

            string flowSummary;
            bool flowConfirmed =
                TryGetLiquidityBreakFlowSupport(
                    isLong,
                    out flowSummary
                );

            if (!flowConfirmed && authorityFlowAligned && !authorityFlowOpposed)
            {
                flowConfirmed = true;
                flowSummary = authorityFlowSummary;
            }

            // V1.6.52: a clean 4/5 reversal with aligned structure/location
            // and strong live flow does not need stale 3/1 Opening Pressure.
            if (
                vwapAligned &&
                structureAligned &&
                flowConfirmed
            )
            {
                summary =
                    "4/5 STRUCTURE/FLOW OVERRIDE"
                    + " | Pressure "
                    + samePressure + "/" + oppositePressure
                    + " | " + flowSummary;
                return true;
            }

            if (samePressure < 3 || oppositePressure > 1)
            {
                summary =
                    "Pressure "
                    + samePressure
                    + "/"
                    + oppositePressure
                    + " not >=3/1"
                    + " | " + flowSummary;
                return false;
            }

            summary =
                "Pressure "
                + samePressure
                + "/"
                + oppositePressure
                + " | "
                + flowSummary;

            return flowConfirmed;
        }


        // =====================================================
        // V1.6.55 - HEAVY ABSORPTION CONFIRMATION ENGINE
        // =====================================================
        // Candidate = aggressive traders hit one side heavily while the
        // opposite book remains resilient. Confirmation requires FAILURE TO
        // PROGRESS plus a real reclaim away from the absorbed extreme. This
        // prevents a simple aggression imbalance from being treated as a
        // reversal by itself.
        private void UpdateAbsorptionState()
        {
            level2Absorption = "NONE";

            if (!level2BookReady || selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null)
                return;

            double tickSize = selectedInstrument.MasterInstrument.TickSize;
            double price = level2LastTradePrice;

            if (tickSize <= 0 || price <= 0)
                return;

            DateTime now = DateTime.UtcNow;

            // V1.7.78 - 1 sample/second of price, 35 min, for high/low zone detection.
            if ((now - level2PriceHistoryLastSampleUtc).TotalSeconds >= 1.0)
            {
                level2PriceHistoryLastSampleUtc = now;
                level2PriceHistory.Add(new KeyValuePair<DateTime, double>(now, price));
                level2PriceHistory.RemoveAll(x => (now - x.Key).TotalMinutes > 35.0);
            }

            // Keep a confirmed state alive only for a very short execution
            // window. It is a trigger, not a persistent directional bias.
            if (level2ConfirmedAbsorptionUtc != DateTime.MinValue)
            {
                double confirmedAge =
                    (now - level2ConfirmedAbsorptionUtc).TotalSeconds;

                if (confirmedAge <= AbsorptionConfirmedTtlSeconds)
                {
                    level2Absorption =
                        level2ConfirmedAbsorptionSide + " ABSORPTION CONFIRMED";
                }
                else
                {
                    level2ConfirmedAbsorptionSide = "NONE";
                    level2ConfirmedAbsorptionUtc = DateTime.MinValue;
                    level2ConfirmedAbsorptionExtremePrice = 0;
                }
            }

            string rawCandidate = "NONE";

            if (
                level2AggSell >= AbsorptionMinAggression &&
                level2AggSell >= Math.Max(1.0, level2AggBuy) * AbsorptionAggressionRatio &&
                level2BidPct >= 50.0
            )
            {
                rawCandidate = "BUY";
            }
            else if (
                level2AggBuy >= AbsorptionMinAggression &&
                level2AggBuy >= Math.Max(1.0, level2AggSell) * AbsorptionAggressionRatio &&
                level2AskPct >= 50.0
            )
            {
                rawCandidate = "SELL";
            }

            if (!string.Equals(rawCandidate, "NONE", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.Equals(level2AbsorptionCandidateSide, rawCandidate, StringComparison.OrdinalIgnoreCase) ||
                    level2AbsorptionCandidateUtc == DateTime.MinValue ||
                    (now - level2AbsorptionCandidateUtc).TotalSeconds > AbsorptionCandidateMaxSeconds)
                {
                    level2AbsorptionCandidateSide = rawCandidate;
                    level2AbsorptionCandidateUtc = now;
                    level2AbsorptionCandidateStartPrice = price;
                    level2AbsorptionCandidateExtremePrice = price;
                    level2AbsorptionCandidateHits = 1;
                }
                else
                {
                    level2AbsorptionCandidateHits++;

                    if (rawCandidate == "BUY")
                        level2AbsorptionCandidateExtremePrice =
                            Math.Min(level2AbsorptionCandidateExtremePrice, price);
                    else
                        level2AbsorptionCandidateExtremePrice =
                            Math.Max(level2AbsorptionCandidateExtremePrice, price);
                }
            }

            if (level2AbsorptionCandidateUtc == DateTime.MinValue)
            {
                if (level2Absorption == "NONE" && rawCandidate == "BUY")
                    level2Absorption = "BUY ABSORB CANDIDATE";
                else if (level2Absorption == "NONE" && rawCandidate == "SELL")
                    level2Absorption = "SELL ABSORB CANDIDATE";
                return;
            }

            double candidateAge =
                (now - level2AbsorptionCandidateUtc).TotalSeconds;

            if (candidateAge > AbsorptionCandidateMaxSeconds)
            {
                level2AbsorptionCandidateSide = "NONE";
                level2AbsorptionCandidateUtc = DateTime.MinValue;
                level2AbsorptionCandidateStartPrice = 0;
                level2AbsorptionCandidateExtremePrice = 0;
                level2AbsorptionCandidateHits = 0;
                return;
            }

            bool buyCandidate =
                string.Equals(level2AbsorptionCandidateSide, "BUY", StringComparison.OrdinalIgnoreCase);

            double adverseTicks = buyCandidate
                ? Math.Max(0.0, (level2AbsorptionCandidateStartPrice - level2AbsorptionCandidateExtremePrice) / tickSize)
                : Math.Max(0.0, (level2AbsorptionCandidateExtremePrice - level2AbsorptionCandidateStartPrice) / tickSize);

            double reclaimTicks = buyCandidate
                ? (price - level2AbsorptionCandidateExtremePrice) / tickSize
                : (level2AbsorptionCandidateExtremePrice - price) / tickSize;

            bool resilientBook = buyCandidate
                ? level2BidPct >= 48.0
                : level2AskPct >= 48.0;

            bool confirmed =
                candidateAge >= 0.75 &&
                level2AbsorptionCandidateHits >= AbsorptionMinCandidateHits &&
                adverseTicks <= AbsorptionMaxAdverseProgressTicks &&
                reclaimTicks >= AbsorptionMinReclaimTicks &&
                resilientBook &&
                level2SpreadTicks > 0 &&
                level2SpreadTicks <= 2.0;

            if (confirmed)
            {
                level2ConfirmedAbsorptionSide = buyCandidate ? "BUY" : "SELL";
                level2ConfirmedAbsorptionUtc = now;
                level2ConfirmedAbsorptionExtremePrice =
                    level2AbsorptionCandidateExtremePrice;

                // V1.6.72 - durable event memory for the short execution
                // reversal window. This survives the 4s visible-state TTL.
                level2LastConfirmedAbsorptionMemorySide = level2ConfirmedAbsorptionSide;
                level2LastConfirmedAbsorptionMemoryUtc = now;
                level2LastConfirmedAbsorptionMemoryExtremePrice =
                    level2ConfirmedAbsorptionExtremePrice;
                // V1.7.78 - size of the aggression that was absorbed (SELL control =
                // buyers absorbed -> AggBuy; BUY control -> AggSell) and how little
                // price progressed. Used to hold Momentum only for LARGE absorption.
                level2LastConfirmedAbsorptionMemorySize =
                    buyCandidate ? level2AggSell : level2AggBuy;
                level2LastConfirmedAbsorptionMemoryFailedTicks = adverseTicks;

                level2AbsorptionEventHistory.Add(new AbsorptionEventRecord
                {
                    Utc = now,
                    Side = level2ConfirmedAbsorptionSide,
                    Size = level2LastConfirmedAbsorptionMemorySize,
                    Extreme = level2ConfirmedAbsorptionExtremePrice
                });
                level2AbsorptionEventHistory.RemoveAll(
                    x => (now - x.Utc).TotalSeconds > 130.0);

                if (string.Equals(level2ConfirmedAbsorptionSide, "BUY", StringComparison.OrdinalIgnoreCase))
                    level2LastBuyConfirmedAbsorptionUtc = now;
                else if (string.Equals(level2ConfirmedAbsorptionSide, "SELL", StringComparison.OrdinalIgnoreCase))
                    level2LastSellConfirmedAbsorptionUtc = now;

                level2Absorption =
                    level2ConfirmedAbsorptionSide + " ABSORPTION CONFIRMED";

                PrintBotMessage(
                    "HEAVY ABSORPTION CONFIRMED"
                    + " | Control: " + level2ConfirmedAbsorptionSide
                    + " | AggBuy/Sell: " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0")
                    + " | Reclaim: " + reclaimTicks.ToString("0.0") + "t"
                    + " | FailedProgress: " + adverseTicks.ToString("0.0") + "t"
                    + " | Bid/Ask: " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0")
                    + " | Spread: " + level2SpreadTicks.ToString("0.0") + "t"
                    + " | Action: TRAPPED SIDE CONFIRMED / REVERSAL WINDOW ARMED"
                );

                level2AbsorptionCandidateSide = "NONE";
                level2AbsorptionCandidateUtc = DateTime.MinValue;
                level2AbsorptionCandidateStartPrice = 0;
                level2AbsorptionCandidateExtremePrice = 0;
                level2AbsorptionCandidateHits = 0;
            }
            else if (level2Absorption == "NONE")
            {
                level2Absorption = buyCandidate
                    ? "BUY ABSORB CANDIDATE"
                    : "SELL ABSORB CANDIDATE";
            }
        }

        // A confirmed absorption reversal is allowed to challenge stale M5/VWAP
        // context, but it still needs the Range engine to confirm price turning.
        private bool TryGetConfirmedAbsorptionReversalSupport(
            bool isLong,
            out string summary)
        {
            summary = "NO CONFIRMED ABSORPTION";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady ||
                    level2ConfirmedAbsorptionUtc == DateTime.MinValue)
                    return false;

                string desired = isLong ? "BUY" : "SELL";
                if (!string.Equals(level2ConfirmedAbsorptionSide, desired, StringComparison.OrdinalIgnoreCase))
                    return false;

                double age =
                    (DateTime.UtcNow - level2ConfirmedAbsorptionUtc).TotalSeconds;

                if (age < 0 || age > AbsorptionConfirmedTtlSeconds ||
                    level2SpreadTicks <= 0 || level2SpreadTicks > 2.0)
                    return false;

                double tickSize = selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0.0;

                if (tickSize <= 0 || level2LastTradePrice <= 0 ||
                    level2ConfirmedAbsorptionExtremePrice <= 0)
                    return false;

                double reclaimTicks = isLong
                    ? (level2LastTradePrice - level2ConfirmedAbsorptionExtremePrice) / tickSize
                    : (level2ConfirmedAbsorptionExtremePrice - level2LastTradePrice) / tickSize;

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                string oppositeTape = isLong ? "SHORT" : "LONG";

                bool aggressionStillOverwhelmsAgainstReversal =
                    string.Equals(level2TapeBias, oppositeTape, StringComparison.OrdinalIgnoreCase) &&
                    oppositeAgg >= Math.Max(1.0, desiredAgg) * 2.0 &&
                    reclaimTicks < AbsorptionMinReclaimTicks + 2.0;

                bool supported =
                    reclaimTicks >= AbsorptionMinReclaimTicks &&
                    !aggressionStillOverwhelmsAgainstReversal;

                summary =
                    "Abs " + level2Absorption
                    + " | Age " + age.ToString("0.0") + "s"
                    + " | Reclaim " + reclaimTicks.ToString("0.0") + "t"
                    + " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0")
                    + " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0")
                    + " | Spread " + level2SpreadTicks.ToString("0.0") + "t";

                return supported;
            }
        }

        // =====================================================
        // V1.6.49 - EARLY AGGRESSION FLOW SUPPORT
        // =====================================================
        // Fast confirmation for a price-driven high-conviction setup when
        // M5 still points the other way.  Unlike the older liquidity-break
        // confirmation, this does not wait for 5/6 persistence and a 100
        // delta.  It requires a real imbalance in executed aggression, tape
        // agreement, fresh L2 and no confirmed/candidate absorption against
        // the intended side.  Level II still cannot create a trade by itself.
        private bool TryGetEarlyAggressionFlowSupport(
            bool isLong,
            out string summary)
        {
            summary = "EARLY L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary = "EARLY L2 STALE/INVALID";
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                int persistence = isLong ? level2LongPersistence : level2ShortPersistence;

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                double signedDelta = isLong ? level2TapeDelta : -level2TapeDelta;

                bool tapeAligned =
                    string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);

                bool tapeOpposes =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool opposingAbsorption =
                    isLong
                        ? (
                            string.Equals(level2Absorption, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                          )
                        : (
                            string.Equals(level2Absorption, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                          );

                bool confirmedOpposingAbsorption =
                    isLong
                        ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                        : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                bool supported =
                    desiredAgg >= 40.0 &&
                    desiredAgg >= Math.Max(1.0, oppositeAgg) * 1.35 &&
                    signedDelta >= 40.0 &&
                    persistence >= 2 &&
                    tapeAligned &&
                    !tapeOpposes &&
                    !opposingAbsorption &&
                    (confluenceAligned || persistence >= 4);

                summary =
                    "EarlyAgg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist " + persistence + "/" + Level2PersistenceCap +
                    " | Abs " + level2Absorption +
                    " | Spread " + level2SpreadTicks.ToString("0.0") + "t";

                return supported;
            }
        }



        // =====================================================
        // V1.6.62 - LIVE FLOW CONTEXT (WEIGHT INPUT, NOT INDEPENDENT VETO)
        // =====================================================
        // Historical edge remains the main execution authority, but a weaker
        // 3/5 live setup needs at least ONE fast microstructure confirmation.
        // A stronger 4/5+ price impulse may proceed through neutral flow, but
        // not through clearly opposite tape+persistence. This prevents the
        // old "wait for everything" paralysis without allowing history to
        // force entries directly into fresh opposing order flow.
        private bool TryGetMinimumExecutionFlowCoherence(
            bool isLong,
            out bool clearlyOpposed,
            out string summary)
        {
            clearlyOpposed = false;
            summary = "L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                {
                    summary = "L2 WARMUP/UNAVAILABLE";
                    return false;
                }

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary = "L2 STALE/INVALID";
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";

                int desiredPersistence =
                    isLong ? level2LongPersistence : level2ShortPersistence;
                int oppositePersistence =
                    isLong ? level2ShortPersistence : level2LongPersistence;

                double desiredAgg =
                    isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg =
                    isLong ? level2AggSell : level2AggBuy;
                double signedDelta =
                    isLong ? level2TapeDelta : -level2TapeDelta;

                bool tapeAligned =
                    string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);
                bool tapeOpposed =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool confluenceOpposed =
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                bool bookAligned =
                    string.Equals(level2Bias, desired, StringComparison.OrdinalIgnoreCase);

                bool aggressionAligned =
                    desiredAgg >= 24.0 &&
                    desiredAgg >= Math.Max(1.0, oppositeAgg) * 1.15 &&
                    signedDelta >= 12.0;

                bool persistenceAligned =
                    desiredPersistence >= 2;

                bool minimumAligned =
                    tapeAligned ||
                    confluenceAligned ||
                    persistenceAligned ||
                    aggressionAligned ||
                    bookAligned;

                // "Clearly opposed" deliberately needs more than one noisy
                // field. One contrary snapshot is context; tape + persistence
                // (or confluence + persistence) is a real short-lived veto.
                clearlyOpposed =
                    oppositePersistence >= 2 &&
                    (
                        tapeOpposed ||
                        confluenceOpposed
                    );

                summary =
                    "Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist L/S " + level2LongPersistence + "/" + level2ShortPersistence +
                    " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Book " + level2Bias +
                    " | MinConfirm " + (minimumAligned ? "YES" : "NO") +
                    " | Opposed " + (clearlyOpposed ? "YES" : "NO");

                return minimumAligned;
            }
        }

        // =====================================================
        // V1.6.37 - LIQUIDITY BREAK AGGRESSIVE FLOW CONFIRMATION
        // =====================================================
        // Symmetric LONG/SHORT confirmation. Level II still cannot create a
        // setup by itself; it may only confirm a price break already detected
        // by the existing Momentum/Opening engines.
        private bool TryGetLiquidityBreakFlowSupport(
            bool isLong,
            out string summary)
        {
            summary = "L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0
                )
                {
                    summary = "L2 STALE";
                    return false;
                }

                if (level2SpreadTicks <= 0 || level2SpreadTicks > 8.0)
                {
                    summary = "L2 INVALID SPREAD " + level2SpreadTicks.ToString("0.0") + "t";
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";
                int persistence = isLong ? level2LongPersistence : level2ShortPersistence;

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool tapeOpposes =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool deltaAligned =
                    isLong
                        ? level2TapeDelta >= LiquidityBreakMinTapeDelta
                        : level2TapeDelta <= -LiquidityBreakMinTapeDelta;

                bool opposingAbsorption =
                    isLong
                        ? string.Equals(level2Absorption, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase)
                        : string.Equals(level2Absorption, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase);

                double desiredAggression =
                    isLong ? level2AggBuy : level2AggSell;

                double oppositeAggression =
                    isLong ? level2AggSell : level2AggBuy;

                bool aggressionAligned =
                    desiredAggression >=
                        Math.Max(1.0, oppositeAggression) * 1.10;

                bool supported =
                    persistence >= 5 &&
                    confluenceAligned &&
                    deltaAligned &&
                    aggressionAligned &&
                    !tapeOpposes &&
                    !opposingAbsorption;

                summary =
                    "Book " + level2Bias + " " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0") +
                    " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist " + persistence + "/" + Level2PersistenceCap +
                    " | Abs " + level2Absorption +
                    " | Spread " + level2SpreadTicks.ToString("0.0") + "t";

                return supported;
            }
        }

        // =====================================================
        // V1.6.52 - FRESH FLOW AUTHORITY SNAPSHOT
        // =====================================================
        // Price/R20 remains the trigger. This helper only tells the direction
        // engines whether very fresh executed order-flow confirms that trigger
        // or is strongly fighting it. It deliberately ignores a book-only
        // imbalance so spoofing/pulling cannot create or veto a trade by itself.
        // =====================================================
        // V1.7.77 - MOMENTUM ABSORPTION MEMORY HOLD
        // =====================================================
        // The Momentum route treats absorption as context only (V1.6.63) and the hard
        // flow veto needs a filled tape window, but the tape counters are zeroed after
        // every Level II print and the visible "CONFIRMED" label expires in ~4 s.
        // 2026-10-08 10:28: SELL ABSORPTION CONFIRMED 5 s before a LONG entry -> -$94.50.
        // This hold uses the SAME durable event memory as the Explosion route
        // (level2LastConfirmedAbsorptionMemory*). It is a delay, not a permanent block:
        // fresh same-side live flow re-authorizes the entry. Fail-open if Level II is off.
        private const bool MomentumAbsorptionHoldEnabled = true;
        private const double MomentumAbsorptionHoldSeconds = 10.0;
        private const int MomentumAbsorptionReclaimPersistence = 3;
        private const double MomentumAbsorptionReclaimDelta = 35.0;
        // V1.7.78 - anti over-filter: hold ONLY for a large absorption (today only
        // ~0.8% of events: absorbed aggression >= 1500 with FailedProgress <= 3t)
        // and release as soon as price walks through the absorbed extreme.
        private const double MomentumAbsorptionMinSize = 1500.0;
        private const double MomentumAbsorptionMaxFailedTicks = 3.0;
        private const double MomentumAbsorptionWalkReleaseTicks = 2.0;

        private bool IsMomentumEntryHeldByOpposingAbsorption(bool isLong, out string summary)
        {
            summary = string.Empty;

            if (!MomentumAbsorptionHoldEnabled)
                return false;

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                string opposingSide = isLong ? "SELL" : "BUY";
                string desired = isLong ? "LONG" : "SHORT";

                double ageSeconds = double.MaxValue;
                bool recentOpposing = false;

                if (level2LastConfirmedAbsorptionMemoryUtc != DateTime.MinValue)
                {
                    ageSeconds = (DateTime.UtcNow - level2LastConfirmedAbsorptionMemoryUtc).TotalSeconds;

                    recentOpposing =
                        ageSeconds >= 0.0 &&
                        ageSeconds <= MomentumAbsorptionHoldSeconds &&
                        string.Equals(
                            level2LastConfirmedAbsorptionMemorySide,
                            opposingSide,
                            StringComparison.OrdinalIgnoreCase);
                }

                bool visibleOpposing =
                    string.Equals(
                        level2Absorption,
                        opposingSide + " ABSORPTION CONFIRMED",
                        StringComparison.OrdinalIgnoreCase);

                if (!recentOpposing && !visibleOpposing)
                    return false;

                // Only a LARGE absorption with almost no price progress counts.
                if (level2LastConfirmedAbsorptionMemorySize < MomentumAbsorptionMinSize ||
                    level2LastConfirmedAbsorptionMemoryFailedTicks > MomentumAbsorptionMaxFailedTicks)
                    return false;

                // Price walked through the absorbed extreme in the trade direction:
                // the absorption failed, so do not hold (avoids losing the entry).
                double walkTick =
                    selectedInstrument != null && selectedInstrument.MasterInstrument != null
                        ? selectedInstrument.MasterInstrument.TickSize
                        : 0.0;
                double extreme = level2LastConfirmedAbsorptionMemoryExtremePrice;
                if (walkTick > 0 && extreme > 0 && level2LastTradePrice > 0)
                {
                    double walked = isLong
                        ? (level2LastTradePrice - extreme) / walkTick
                        : (extreme - level2LastTradePrice) / walkTick;
                    if (walked >= MomentumAbsorptionWalkReleaseTicks)
                        return false;
                }

                int desiredPersistence = isLong ? level2LongPersistence : level2ShortPersistence;
                int oppositePersistence = isLong ? level2ShortPersistence : level2LongPersistence;
                double signedDelta = isLong ? level2TapeDelta : -level2TapeDelta;

                bool tapeAligned =
                    string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool revalidated =
                    desiredPersistence >= MomentumAbsorptionReclaimPersistence &&
                    signedDelta >= MomentumAbsorptionReclaimDelta &&
                    (tapeAligned || confluenceAligned);

                if (revalidated)
                    return false;

                summary =
                    "RECENT OPPOSING ABSORPTION"
                    + " | " + opposingSide + " CONFIRMED "
                    + (ageSeconds == double.MaxValue ? "NOW" : ageSeconds.ToString("0.0") + "s ago")
                    + " | Size " + level2LastConfirmedAbsorptionMemorySize.ToString("0")
                    + " | Persist " + desiredPersistence + "/" + oppositePersistence
                    + " | Delta " + signedDelta.ToString("0")
                    + " | Need: Persist>=" + MomentumAbsorptionReclaimPersistence
                    + "/6 + Delta>=" + MomentumAbsorptionReclaimDelta.ToString("0")
                    + " + Tape/Conf aligned"
                    + " | Hold " + MomentumAbsorptionHoldSeconds.ToString("0") + "s";

                return true;
            }
        }

        // =====================================================
        // V1.7.78 - PERSISTENT OPPOSING ABSORPTION AT A HIGH/LOW (reversal trigger)
        // =====================================================
        // Used while a trade is open and already in profit. Requires ALL of:
        //  1) >= AbsReversalMinEvents SELL (for a LONG) / BUY (for a SHORT) confirmed
        //     absorptions of >= AbsReversalMinEventSize inside AbsReversalWindowSeconds,
        //     total absorbed aggression >= AbsReversalMinTotalSize;
        //  2) the latest one is still LIVE (<= AbsReversalLiveSeconds) and no newer
        //     same-side-as-position absorption exists (it did not disappear / flip);
        //  3) the absorbed extreme sits at the 30-min high (LONG) / low (SHORT);
        //  4) live flow confluence against the position (persistence + delta + tape/conf).
        private const double AbsReversalWindowSeconds = 45.0;
        private const int AbsReversalMinEvents = 3;
        private const double AbsReversalMinEventSize = 400.0;
        private const double AbsReversalMinTotalSize = 3000.0;
        private const double AbsReversalLiveSeconds = 12.0;
        private const double AbsReversalZoneMinutes = 30.0;
        private const double AbsReversalZoneTicks = 20.0;
        private const int AbsReversalFlowPersistence = 3;
        private const double AbsReversalFlowDelta = 35.0;

        private bool IsPersistentAbsorptionAgainstPosition(bool positionIsLong, out string summary)
        {
            summary = string.Empty;

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady || selectedInstrument == null ||
                    selectedInstrument.MasterInstrument == null)
                    return false;

                double tickSize = selectedInstrument.MasterInstrument.TickSize;
                if (tickSize <= 0 || level2LastTradePrice <= 0)
                    return false;

                string against = positionIsLong ? "SELL" : "BUY";
                string withPos = positionIsLong ? "BUY" : "SELL";
                DateTime now = DateTime.UtcNow;

                int count = 0;
                double total = 0;
                DateTime latestAgainst = DateTime.MinValue;
                DateTime latestWith = DateTime.MinValue;
                double latestExtreme = 0;

                foreach (AbsorptionEventRecord e in level2AbsorptionEventHistory)
                {
                    double age = (now - e.Utc).TotalSeconds;
                    if (age < 0.0 || age > AbsReversalWindowSeconds)
                        continue;

                    if (string.Equals(e.Side, against, StringComparison.OrdinalIgnoreCase))
                    {
                        if (e.Size >= AbsReversalMinEventSize)
                        {
                            count++;
                            total += e.Size;
                            if (e.Utc > latestAgainst)
                            {
                                latestAgainst = e.Utc;
                                latestExtreme = e.Extreme;
                            }
                        }
                    }
                    else if (string.Equals(e.Side, withPos, StringComparison.OrdinalIgnoreCase))
                    {
                        if (e.Utc > latestWith)
                            latestWith = e.Utc;
                    }
                }

                if (count < AbsReversalMinEvents || total < AbsReversalMinTotalSize)
                    return false;

                if ((now - latestAgainst).TotalSeconds > AbsReversalLiveSeconds)
                    return false;

                if (latestWith > latestAgainst)
                    return false;

                // Zone: absorbed extreme at the 30-min high (LONG) / low (SHORT).
                double zoneExtreme = 0;
                foreach (KeyValuePair<DateTime, double> kv in level2PriceHistory)
                {
                    if ((now - kv.Key).TotalMinutes > AbsReversalZoneMinutes)
                        continue;

                    if (zoneExtreme == 0 ||
                        (positionIsLong && kv.Value > zoneExtreme) ||
                        (!positionIsLong && kv.Value < zoneExtreme))
                        zoneExtreme = kv.Value;
                }

                if (zoneExtreme <= 0 || latestExtreme <= 0)
                    return false;

                double zoneDistTicks = Math.Abs(zoneExtreme - latestExtreme) / tickSize;
                if (zoneDistTicks > AbsReversalZoneTicks)
                    return false;

                // Flow confluence AGAINST the position.
                string opposite = positionIsLong ? "SHORT" : "LONG";
                int oppPersistence = positionIsLong ? level2ShortPersistence : level2LongPersistence;
                double oppDelta = positionIsLong ? -level2TapeDelta : level2TapeDelta;

                bool tapeOpp = string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);
                bool confOpp =
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                if (!(oppPersistence >= AbsReversalFlowPersistence &&
                      oppDelta >= AbsReversalFlowDelta &&
                      (tapeOpp || confOpp)))
                    return false;

                summary =
                    "PERSISTENT " + against + " ABSORPTION"
                    + " | Events " + count + " in " + AbsReversalWindowSeconds.ToString("0") + "s"
                    + " | Total " + total.ToString("0")
                    + " | Last " + (now - latestAgainst).TotalSeconds.ToString("0.0") + "s ago"
                    + " | Zone " + zoneDistTicks.ToString("0") + "t from 30m extreme"
                    + " | Flow " + opposite + " Persist " + oppPersistence + "/6 Delta " + oppDelta.ToString("0");

                return true;
            }
        }

        private void GetFreshDirectionalFlowAuthority(
            bool isLong,
            out bool aligned,
            out bool stronglyOpposed,
            out string summary)
        {
            aligned = false;
            stronglyOpposed = false;
            summary = "FLOW NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return;

                double ageSeconds =
                    level2LastCalcUtc == DateTime.MinValue
                        ? 999.0
                        : (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds;

                if (
                    ageSeconds > 5.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 4.0
                )
                {
                    summary =
                        "FLOW STALE/INVALID | Age "
                        + ageSeconds.ToString("0.0")
                        + "s | Spread "
                        + level2SpreadTicks.ToString("0.0")
                        + "t";
                    return;
                }

                string desired = isLong ? "LONG" : "SHORT";
                string opposite = isLong ? "SHORT" : "LONG";

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                double signedDelta = isLong ? level2TapeDelta : -level2TapeDelta;
                double signedOppositeDelta = -signedDelta;

                int desiredPersistence =
                    isLong ? level2LongPersistence : level2ShortPersistence;
                int oppositePersistence =
                    isLong ? level2ShortPersistence : level2LongPersistence;

                bool tapeAligned =
                    string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);
                bool tapeOpposed =
                    string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);

                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool confluenceOpposed =
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                bool confirmedOpposingAbsorption =
                    isLong
                        ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                        : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                bool opposingAbsorption =
                    isLong
                        ? (
                            string.Equals(level2Absorption, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                          )
                        : (
                            string.Equals(level2Absorption, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                          );

                bool desiredAggressionEdge =
                    desiredAgg >= 80.0 &&
                    desiredAgg >= Math.Max(1.0, oppositeAgg) * 1.18;

                bool oppositeAggressionEdge =
                    oppositeAgg >= 120.0 &&
                    oppositeAgg >= Math.Max(1.0, desiredAgg) * 1.25;

                aligned =
                    !opposingAbsorption &&
                    signedDelta >= 100.0 &&
                    desiredAggressionEdge &&
                    (
                        tapeAligned ||
                        confluenceAligned ||
                        desiredPersistence >= 4
                    );

                // V1.6.63 - absorption is context, not a standalone veto.
                // Reserve a hard contradiction for genuinely aligned opposite
                // executed flow. Confirmed absorption can strengthen that veto,
                // but cannot create it by itself. This prevents a single noisy
                // absorption flip from overruling a Unified Edge candidate.
                bool broadOppositeFlow =
                    signedOppositeDelta >= 250.0 &&
                    oppositeAggressionEdge &&
                    (
                        tapeOpposed ||
                        confluenceOpposed
                    ) &&
                    oppositePersistence >= 4;

                bool confirmedAbsorptionWithOppositeFlow =
                    confirmedOpposingAbsorption &&
                    signedOppositeDelta >= 100.0 &&
                    oppositeAggressionEdge &&
                    (
                        tapeOpposed ||
                        confluenceOpposed
                    ) &&
                    oppositePersistence >= 4;

                stronglyOpposed =
                    broadOppositeFlow ||
                    confirmedAbsorptionWithOppositeFlow;

                summary =
                    "Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist L/S " + level2LongPersistence + "/" + level2ShortPersistence +
                    " | Abs " + level2Absorption +
                    " | Spread " + level2SpreadTicks.ToString("0.0") + "t" +
                    " | Age " + ageSeconds.ToString("0.0") + "s";
            }
        }

        // =====================================================
        // V1.6.53 - FRESH MOMENTUM CONTINUATION FLOW SUPPORT
        // =====================================================
        // Used only by the tiny post-trigger extension grace window.
        // Confirmed opposite absorption is always a hard veto. A mere
        // absorption CANDIDATE can be overruled only by exceptional aligned
        // executed flow, which prevents one noisy flag from killing a live
        // impulse while still protecting against real absorption.
        private bool TryGetFreshMomentumContinuationFlowSupport(
            bool isLong,
            out string summary)
        {
            summary = "FLOW NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                double ageSeconds =
                    level2LastCalcUtc == DateTime.MinValue
                        ? 999.0
                        : (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds;

                if (
                    ageSeconds > 3.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 2.0
                )
                {
                    summary =
                        "FLOW STALE/INVALID | Age "
                        + ageSeconds.ToString("0.0")
                        + "s | Spread "
                        + level2SpreadTicks.ToString("0.0")
                        + "t";
                    return false;
                }

                string desired = isLong ? "LONG" : "SHORT";
                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                double signedDelta = isLong ? level2TapeDelta : -level2TapeDelta;
                int persistence = isLong ? level2LongPersistence : level2ShortPersistence;

                bool tapeAligned =
                    string.Equals(level2TapeBias, desired, StringComparison.OrdinalIgnoreCase);
                bool confluenceAligned =
                    string.Equals(level2Confluence, "STRONG " + desired, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + desired, StringComparison.OrdinalIgnoreCase);

                bool confirmedOpposingAbsorption =
                    isLong
                        ? string.Equals(level2Absorption, "SELL ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase)
                        : string.Equals(level2Absorption, "BUY ABSORPTION CONFIRMED", StringComparison.OrdinalIgnoreCase);

                bool candidateOpposingAbsorption =
                    isLong
                        ? string.Equals(level2Absorption, "SELL ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase)
                        : string.Equals(level2Absorption, "BUY ABSORB CANDIDATE", StringComparison.OrdinalIgnoreCase);

                bool strongAlignedFlow =
                    desiredAgg >= 120.0 &&
                    desiredAgg >= Math.Max(1.0, oppositeAgg) * 1.30 &&
                    signedDelta >= 120.0 &&
                    (tapeAligned || confluenceAligned || persistence >= 4);

                bool exceptionalAlignedFlow =
                    desiredAgg >= 250.0 &&
                    desiredAgg >= Math.Max(1.0, oppositeAgg) * 1.75 &&
                    signedDelta >= 500.0 &&
                    persistence >= 5;

                bool supported =
                    !confirmedOpposingAbsorption &&
                    strongAlignedFlow &&
                    (!candidateOpposingAbsorption || exceptionalAlignedFlow);

                summary =
                    "Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | Persist L/S " + level2LongPersistence + "/" + level2ShortPersistence +
                    " | Abs " + level2Absorption +
                    " | Spread " + level2SpreadTicks.ToString("0.0") + "t" +
                    " | Age " + ageSeconds.ToString("0.0") + "s";

                return supported;
            }
        }

        // =====================================================
        // V1.6.37 - INITIAL ENTRY LEVEL II STRONG-CONTRARY VETO
        // =====================================================
        // Initial entries are still price/setup driven. This veto only delays
        // execution when very fresh order flow is exceptionally contrary.
        private bool IsInitialEntryLevel2StronglyOpposed(
            bool isLong,
            out string summary)
        {
            summary = "L2 NOT READY";

            lock (level2Sync)
            {
                if (!level2ObserveActive || !level2BookReady)
                    return false;

                if (
                    level2LastCalcUtc == DateTime.MinValue ||
                    (DateTime.UtcNow - level2LastCalcUtc).TotalSeconds > 2.0 ||
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    return false;
                }

                string opposite = isLong ? "SHORT" : "LONG";
                int oppositePersistence = isLong ? level2ShortPersistence : level2LongPersistence;
                bool oppositeTape = string.Equals(level2TapeBias, opposite, StringComparison.OrdinalIgnoreCase);
                bool oppositeConfluence =
                    string.Equals(level2Confluence, "STRONG " + opposite, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(level2Confluence, "LEAN " + opposite, StringComparison.OrdinalIgnoreCase);

                double desiredAgg = isLong ? level2AggBuy : level2AggSell;
                double oppositeAgg = isLong ? level2AggSell : level2AggBuy;
                double signedOppositeDelta = isLong ? -level2TapeDelta : level2TapeDelta;

                bool rawAggressionStronglyOpposed =
                    signedOppositeDelta >= InitialEntryL2VetoMinDelta &&
                    oppositeAgg >= Math.Max(1.0, desiredAgg) * InitialEntryL2VetoAggressionRatio;

                bool persistentOpposition =
                    oppositePersistence >= 5 &&
                    (oppositeTape || oppositeConfluence);

                // V1.6.63 - absorption alone is not "strongly opposed".
                // It is already represented as a score penalty by Unified Edge.
                // A hard Level II contradiction requires executed-flow evidence.
                bool opposed =
                    persistentOpposition ||
                    rawAggressionStronglyOpposed;

                summary =
                    "Book " + level2Bias + " " + level2BidPct.ToString("0") + "/" + level2AskPct.ToString("0") +
                    " | Agg " + level2AggBuy.ToString("0") + "/" + level2AggSell.ToString("0") +
                    " | Tape " + level2TapeBias + " " + level2TapeDelta.ToString("0") +
                    " | Conf " + level2Confluence +
                    " | OppPersist " + oppositePersistence + "/" + Level2PersistenceCap +
                    " | Abs " + level2Absorption;

                return opposed;
            }
        }

        // =====================================================
        // V10.7 - SMART RETEST LEVEL II TIMING GUARD
        // =====================================================
        // Smart Retest already has confirmed price/structure context.
        // Level II is therefore NOT used as a new trigger here; it is used
        // only to avoid submitting the retest while the immediate order flow
        // is clearly pushing the opposite way.
        private bool IsSmartRetestLevel2Opposed(
            bool isLong,
            out string summary)
        {
            summary =
                "L2 NOT READY";

            lock (level2Sync)
            {
                if (
                    !level2ObserveActive ||
                    !level2BookReady
                )
                {
                    return false;
                }

                if (
                    level2LastCalcUtc ==
                        DateTime.MinValue ||
                    (
                        DateTime.UtcNow -
                        level2LastCalcUtc
                    ).TotalSeconds > 2.0
                )
                {
                    summary =
                        "L2 STALE";

                    return false;
                }

                if (
                    level2SpreadTicks <= 0 ||
                    level2SpreadTicks > 8.0
                )
                {
                    summary =
                        "L2 INVALID SPREAD "
                        + level2SpreadTicks.ToString("0.0")
                        + "t";

                    return false;
                }

                string desired =
                    isLong
                        ? "LONG"
                        : "SHORT";

                string opposite =
                    isLong
                        ? "SHORT"
                        : "LONG";

                int oppositePersistence =
                    isLong
                        ? level2ShortPersistence
                        : level2LongPersistence;

                bool oppositeBook =
                    isLong
                        ? level2AskPct >= 58.0
                        : level2BidPct >= 58.0;

                bool oppositeConfluence =
                    string.Equals(
                        level2Confluence,
                        "STRONG " + opposite,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    string.Equals(
                        level2Confluence,
                        "LEAN " + opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool oppositeTape =
                    string.Equals(
                        level2TapeBias,
                        opposite,
                        StringComparison.OrdinalIgnoreCase
                    );

                bool oppositeAbsorption =
                    isLong
                        ? string.Equals(
                            level2Absorption,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            level2Absorption,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                // A 2/6 persistent opposite book+confluence is already enough
                // to delay a Smart Retest. It does not cancel the setup; the
                // pending retest remains armed and can fire on a later Range bar
                // when L2 neutralizes or aligns.
                bool opposed =
                    (
                        oppositeBook &&
                        oppositeConfluence &&
                        oppositePersistence >= 2
                    ) ||
                    (
                        oppositeTape &&
                        oppositePersistence >= 2
                    ) ||
                    oppositeAbsorption;

                summary =
                    "Desired "
                    + desired
                    + " | Book "
                    + level2Bias
                    + " "
                    + level2BidPct.ToString("0")
                    + "/"
                    + level2AskPct.ToString("0")
                    + " | Tape "
                    + level2TapeBias
                    + " "
                    + level2TapeDelta.ToString("0")
                    + " | Conf "
                    + level2Confluence
                    + " | OppPersist "
                    + oppositePersistence
                    + "/"
                    + Level2PersistenceCap
                    + " | Abs "
                    + level2Absorption
                    + " | Spread "
                    + level2SpreadTicks.ToString("0.0")
                    + "t";

                return opposed;
            }
        }

        // V1.7.83 - Open Bell LONG tape window: sum of the tape delta (aggressive buys - sells) of every
        // LEVEL2 CONTEXT snapshot between 09:25:00 and 09:29:58 NY. Reset before 09:25 (new day / replay).
        private double obTape5mDelta;
        private int obTape5mSnaps;
        private double obTape30mDelta; // V1.7.117 - Open Bell 30-minute tape (09:00:00-09:29:58)
        private int obTape30mSnaps;
        private double obTape5mVol; // V1.7.118 - aggressive volume 09:25:00-09:29:58 (selector log)

        private void LogLevel2Context()
        {
            long events;
            int bidRows;
            int askRows;

            lock (level2Sync)
            {
                events =
                    level2DepthEvents;

                bidRows =
                    level2BidRows.Count;

                askRows =
                    level2AskRows.Count;
            }

            PrintBotMessage(
                "LEVEL2 CONTEXT"
                + " | Ready: "
                + (
                    level2BookReady
                        ? "YES"
                        : "WARMUP"
                )
                + " | Bias: "
                + level2Bias
                + " | Bid/Ask: "
                + level2BidPct.ToString("0")
                + "%/"
                + level2AskPct.ToString("0")
                + "%"
                + " | Top10 Vol: "
                + level2TopBidVolume
                + "/"
                + level2TopAskVolume
                + " | Rows: "
                + bidRows
                + "/"
                + askRows
                + " | StackPull: "
                + level2StackPull
                + " | AggBuy/Sell: "
                + level2AggBuy.ToString("0")
                + "/"
                + level2AggSell.ToString("0")
                + " | TapeTrades: "
                + level2TapeTrades
                + " | Unknown: "
                + level2UnknownTrades
                + " | TapeDelta: "
                + level2TapeDelta.ToString("0")
                + " | TapeBias: "
                + level2TapeBias
                + " | Confluence: "
                + level2Confluence
                + " | Persistence: "
                + (
                    level2LongPersistence > 0
                        ? "LONG "
                            + level2LongPersistence
                            + "/"
                            + Level2PersistenceCap
                        : level2ShortPersistence > 0
                            ? "SHORT "
                                + level2ShortPersistence
                                + "/"
                                + Level2PersistenceCap
                            : "NEUTRAL "
                                + level2NeutralPersistence
                                + "/"
                                + Level2PersistenceCap
                )
                + " | Absorption: "
                + level2Absorption
                + " | Spread: "
                + level2SpreadTicks
                    .ToString("0.0")
                + "t"
                + " | DepthEvents: "
                + events
                + " | ABSORPTION CONFIRMATION ACTIVE"
            );

            lock (level2Sync)
            {
                // V1.7.83 - accumulate this snapshot into the Open Bell 5-minute tape window
                // (before the counters are zeroed). Fail-safe: any clock error just skips it.
                try
                {
                    TimeSpan obTod = GetCurrentNewYorkTime().TimeOfDay;

                    // V1.7.117 - 30-minute window 09:00:00-09:29:58 for the dirty-open filter
                    if (obTod < new TimeSpan(9, 0, 0))
                    {
                        obTape30mDelta = 0;
                        obTape30mSnaps = 0;
                    }
                    else if (level2BookReady && obTod < new TimeSpan(9, 29, 58))
                    {
                        obTape30mDelta += level2AggBuy - level2AggSell;
                        obTape30mSnaps++;
                    }

                    if (obTod < new TimeSpan(9, 25, 0))
                    {
                        obTape5mDelta = 0;
                        obTape5mSnaps = 0;
                        obTape5mVol = 0;
                    }
                    else if (level2BookReady && obTod < new TimeSpan(9, 29, 58))
                    {
                        obTape5mDelta += level2AggBuy - level2AggSell;
                        obTape5mSnaps++;
                        obTape5mVol += level2AggBuy + level2AggSell;
                    }
                }
                catch { }

                level2BidAdd = 0;
                level2BidRemove = 0;
                level2AskAdd = 0;
                level2AskRemove = 0;

                level2AggBuy = 0;
                level2AggSell = 0;
                level2TapeTrades = 0;
                level2UnknownTrades = 0;
            }
        }
    }
}

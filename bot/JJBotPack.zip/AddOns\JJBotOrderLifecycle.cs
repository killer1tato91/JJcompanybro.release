#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT ORDER LIFECYCLE
    // Stage 15 structural extraction only.
    //
    // Existing Account.OrderUpdate / ExecutionUpdate handling,
    // fill processing and order-reference lifecycle are moved
    // exactly as-is.
    //
    // No fill accounting, OCO behavior, order state handling,
    // learning updates, trailing, recovery, or execution logic
    // was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =========================================================
        // V1.6.97 - PROTECTION INVARIANT WATCHDOG
        // =========================================================
        // A filled position is never allowed to remain indefinitely
        // without BOTH live JJ_STOP and JJ_TARGET protection.
        //
        // The watchdog is deliberately post-fill only. It does NOT
        // change entry eligibility, target logic, stop calculations,
        // Mission Mode, Learning, or signal thresholds.
        private int protectionInvariantWatchdogGeneration = 0;

        // =========================================================
        // V1.6.98 - PROTECTIVE EXIT SETTLEMENT FENCE
        // =========================================================
        // OrderUpdate(Filled) can arrive BEFORE ExecutionUpdate has
        // completed the internal FLAT transition. During that tiny
        // window, the old V1.6.97 resync path could mistake a filled
        // protective order for "missing protection" and rebuild an
        // OCO after the position was already closing/flat.
        //
        // A FILLED JJ_STOP/JJ_TARGET now:
        //   1) invalidates every pending protection watchdog,
        //   2) blocks ALL bracket reconstruction during settlement,
        //   3) lets ExecutionUpdate decide whether the exit was
        //      partial or complete.
        //
        // Partial exit -> release fence and resize remaining OCO.
        // Complete exit -> keep a short dead-zone so late sibling
        // OCO Cancelled/CancelPending callbacks can never reopen.
        private DateTime protectiveExitSettlementFenceUntilUtc =
            DateTime.MinValue;

        private bool protectiveExitSettlementInProgress =
            false;

        private const int ProtectiveExitSettlementFenceMilliseconds =
            2500;

        private bool IsProtectiveExitSettlementFenceActive()
        {
            lock (executionStateLock)
            {
                return
                    protectiveExitSettlementInProgress ||
                    (
                        protectiveExitSettlementFenceUntilUtc !=
                            DateTime.MinValue &&
                        DateTime.UtcNow <
                            protectiveExitSettlementFenceUntilUtc
                    );
            }
        }

        private void ArmProtectiveExitSettlementFence(
            string orderName)
        {
            lock (executionStateLock)
            {
                protectiveExitSettlementInProgress =
                    true;

                protectiveExitSettlementFenceUntilUtc =
                    DateTime.UtcNow.AddMilliseconds(
                        ProtectiveExitSettlementFenceMilliseconds
                    );

                // Kill every watchdog created by the just-finished
                // entry lifecycle before it can rebuild an OCO.
                protectionInvariantWatchdogGeneration++;
            }

            PrintBotMessage(
                "PROTECTIVE EXIT SETTLEMENT FENCE ARMED"
                + " | Order: "
                + orderName
                + " | Hold: "
                + ProtectiveExitSettlementFenceMilliseconds
                + "ms"
                + " | Action: BLOCK OCO REBUILD UNTIL EXIT SETTLES"
            );
        }

        private void ReleaseProtectiveExitSettlementFenceForPartialExit()
        {
            lock (executionStateLock)
            {
                protectiveExitSettlementInProgress =
                    false;

                protectiveExitSettlementFenceUntilUtc =
                    DateTime.MinValue;
            }
        }

        private bool IsProtectionOrderLive(
            Order order)
        {
            if (order == null)
                return false;

            return
                order.OrderState == OrderState.Accepted ||
                order.OrderState == OrderState.Working ||
                order.OrderState == OrderState.ChangePending ||
                order.OrderState == OrderState.ChangeSubmitted;
        }

        private void QueueProtectionInvariantWatchdog()
        {
            int generation;

            lock (executionStateLock)
            {
                protectionInvariantWatchdogGeneration++;
                generation =
                    protectionInvariantWatchdogGeneration;
            }

            Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    System.Windows.Threading.DispatcherTimer timer =
                        new System.Windows.Threading.DispatcherTimer();

                    timer.Interval =
                        TimeSpan.FromMilliseconds(350);

                    int attempts = 0;

                    EventHandler handler = null;

                    handler =
                        new EventHandler(
                            delegate(
                                object sender,
                                EventArgs args)
                            {
                                Account account;
                                Instrument instrument;
                                Order localStop;
                                Order localTarget;
                                double localEntry;
                                int localQty;
                                MarketPosition localSide;
                                bool stillCurrent;
                                bool exitSettlementActive;

                                lock (executionStateLock)
                                {
                                    stillCurrent =
                                        generation ==
                                            protectionInvariantWatchdogGeneration;

                                    account =
                                        selectedAccount;

                                    instrument =
                                        selectedInstrument;

                                    localStop =
                                        stopOrder;

                                    localTarget =
                                        targetOrder;

                                    localEntry =
                                        entryFillPrice;

                                    localQty =
                                        Math.Max(
                                            0,
                                            entryQuantity -
                                                activeExitQuantity
                                        );

                                    localSide =
                                        entryMarketPosition;

                                    exitSettlementActive =
                                        protectiveExitSettlementInProgress ||
                                        (
                                            protectiveExitSettlementFenceUntilUtc !=
                                                DateTime.MinValue &&
                                            DateTime.UtcNow <
                                                protectiveExitSettlementFenceUntilUtc
                                        );
                                }

                                if (
                                    !stillCurrent ||
                                    exitSettlementActive ||
                                    account == null ||
                                    instrument == null ||
                                    localSide ==
                                        MarketPosition.Flat ||
                                    localEntry <= 0 ||
                                    localQty <= 0
                                )
                                {
                                    timer.Stop();
                                    timer.Tick -= handler;
                                    return;
                                }

                                bool stopLive =
                                    IsProtectionOrderLive(
                                        localStop
                                    );

                                bool targetLive =
                                    IsProtectionOrderLive(
                                        localTarget
                                    );

                                if (
                                    stopLive &&
                                    targetLive
                                )
                                {
                                    timer.Stop();
                                    timer.Tick -= handler;

                                    if (attempts > 0)
                                    {
                                        PrintBotMessage(
                                            "PROTECTION INVARIANT RESTORED"
                                            + " | Attempts: "
                                            + attempts
                                            + " | Qty: "
                                            + localQty
                                        );
                                    }

                                    return;
                                }

                                attempts++;

                                PrintBotMessage(
                                    "PROTECTION INVARIANT RETRY"
                                    + " | Attempt: "
                                    + attempts
                                    + "/5"
                                    + " | StopLive: "
                                    + stopLive
                                    + " | TargetLive: "
                                    + targetLive
                                    + " | Qty: "
                                    + localQty
                                );

                                SyncProtectiveBracketToEntry(
                                    localEntry,
                                    localQty,
                                    localSide
                                );

                                if (attempts < 5)
                                    return;

                                lock (executionStateLock)
                                {
                                    localStop =
                                        stopOrder;

                                    localTarget =
                                        targetOrder;
                                }

                                stopLive =
                                    IsProtectionOrderLive(
                                        localStop
                                    );

                                targetLive =
                                    IsProtectionOrderLive(
                                        localTarget
                                    );

                                if (
                                    stopLive &&
                                    targetLive
                                )
                                {
                                    timer.Stop();
                                    timer.Tick -= handler;
                                    return;
                                }

                                timer.Stop();
                                timer.Tick -= handler;

                                PrintBotMessage(
                                    "PROTECTION INVARIANT BROKEN"
                                    + " | StopLive: "
                                    + stopLive
                                    + " | TargetLive: "
                                    + targetLive
                                    + " | Action: FAILSAFE FLATTEN"
                                );

                                lock (executionStateLock)
                                {
                                    executionStatus =
                                        "PROTECTION FAILSAFE FLATTEN";

                                    activeForcedExitReason =
                                        "PROTECTION_INVARIANT";
                                }

                                UpdateExecutionMonitor();

                                try
                                {
                                    account.Flatten(
                                        new[]
                                        {
                                            instrument
                                        }
                                    );
                                }
                                catch (Exception ex)
                                {
                                    PrintBotMessage(
                                        "PROTECTION FAILSAFE FLATTEN ERROR: "
                                        + ex.Message
                                    );
                                }
                            });

                    timer.Tick += handler;
                    timer.Start();
                })
            );
        }

        private void OnAccountOrderUpdate(
            object sender,
            OrderEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Order == null ||
                e.Order.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Order.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Order.Name;

            if (
                IsAnyProfileBotOrder(orderName) &&
                !IsOwnProfileBotOrder(orderName)
            )
            {
                return;
            }

            if (
                orderName == GetProfileOrderName("JJ_SCALE_IN_LONG") ||
                orderName == GetProfileOrderName("JJ_SCALE_IN_SHORT")
            )
            {
                bool failed =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Order.OrderState ==
                        OrderState.Cancelled ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool filled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (
                    failed ||
                    filled
                )
                {
                    lock (executionStateLock)
                    {
                        smartScaleInPending = false;
                        smartScaleInOrder = e.Order;

                        if (failed)
                        {
                            smartScaleInUsed = false;
                        }
                    }
                }

                if (failed)
                {
                    PrintBotMessage(
                        "SMART SCALE-IN ORDER FAILED"
                        + " | State: "
                        + e.Order.OrderState
                        + " | Error: "
                        + e.Error
                    );
                }

                return;
            }

            if (
                orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                orderName == GetProfileOrderName("JJ_ENTRY_SHORT")
            )
            {
                bool entryRejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool entryCancelled =
                    e.Order.OrderState ==
                        OrderState.Cancelled;

                bool entryFilled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (
                    entryRejected ||
                    entryCancelled ||
                    entryFilled
                )
                {
                    lock (executionStateLock)
                    {
                        entryPending =
                            false;

                        entryOrder =
                            e.Order;

                        if (
                            entryRejected &&
                            entryQuantity <= 0
                        )
                        {
                            executionStatus =
                                "ENTRY ERROR";

                            // No real fill occurred, so the pending
                            // structure remains unconsumed.
                            pendingStructureSetupKey =
                                string.Empty;

                            pendingStructureConfirmTime =
                                DateTime.MinValue;
                        }
                        else if (
                            entryCancelled &&
                            entryQuantity > 0
                        )
                        {
                            executionStatus =
                                "ENTRY PARTIAL";
                        }
                        else if (entryFilled)
                        {
                            executionStatus =
                                stopOrder != null &&
                                targetOrder != null
                                    ? "PROTECTED"
                                    : "ENTRY FILLED";
                        }
                    }

                    UpdateExecutionMonitor();
                }

                return;
            }

            if (
                orderName != GetProfileOrderName("JJ_STOP") &&
                orderName != GetProfileOrderName("JJ_TARGET")
            )
            {
                return;
            }

            try
            {
                bool protectiveOrderFilled =
                    e.Order.OrderState ==
                        OrderState.Filled;

                if (protectiveOrderFilled)
                {
                    ArmProtectiveExitSettlementFence(
                        orderName
                    );
                }

                bool recoverableProtectiveChangeError =
                    e.Error == ErrorCode.UnableToChangeOrder;

                bool rejected =
                    e.Order.OrderState ==
                        OrderState.Rejected ||
                    e.Error ==
                        ErrorCode.OrderRejected ||
                    e.Error ==
                        ErrorCode.OrderRejectedByRisk ||
                    recoverableProtectiveChangeError ||
                    e.Error ==
                        ErrorCode.UnableToSubmitOrder;

                bool shouldFlatten =
                    false;

                double stopForLog;
                double targetForLog;

                lock (executionStateLock)
                {
                    if (
                        orderName == GetProfileOrderName("JJ_STOP")
                    )
                    {
                        stopOrder =
                            e.Order;

                        if (
                            e.Order.StopPrice > 0
                        )
                        {
                            activeStopPrice =
                                e.Order.StopPrice;

                            if (activeTradeOriginalStopPrice <= 0)
                            {
                                activeTradeOriginalStopPrice =
                                    e.Order.StopPrice;
                            }
                        }
                    }
                    else if (
                        orderName == GetProfileOrderName("JJ_TARGET")
                    )
                    {
                        targetOrder =
                            e.Order;

                        if (
                            e.Order.LimitPrice > 0
                        )
                        {
                            activeTargetPrice =
                                e.Order.LimitPrice;

                            if (activeTradeOriginalTargetPrice <= 0)
                            {
                                activeTradeOriginalTargetPrice =
                                    e.Order.LimitPrice;
                            }
                        }
                    }

                    // Track only exchange-accepted protective prices.
                    // These remain the fallback if a later Change() is rejected
                    // because its stop price became invalid during a fast move.
                    if (!rejected)
                    {
                        bool confirmedState =
                            e.Order.OrderState == OrderState.Accepted ||
                            e.Order.OrderState == OrderState.Working;

                        if (confirmedState)
                        {
                            if (orderName == GetProfileOrderName("JJ_STOP") && e.Order.StopPrice > 0)
                                lastConfirmedStopPrice = e.Order.StopPrice;
                            else if (orderName == GetProfileOrderName("JJ_TARGET") && e.Order.LimitPrice > 0)
                                lastConfirmedTargetPrice = e.Order.LimitPrice;
                        }
                    }

                    if (rejected)
                    {
                        executionStatus =
                            recoverableProtectiveChangeError
                                ? "PROTECTION CHANGE RETRY"
                                : "PROTECTION ERROR";

                        if (recoverableProtectiveChangeError)
                        {
                            if (lastConfirmedStopPrice > 0)
                                activeStopPrice = lastConfirmedStopPrice;
                            if (lastConfirmedTargetPrice > 0)
                                activeTargetPrice = lastConfirmedTargetPrice;
                        }

                        shouldFlatten =
                            !recoverableProtectiveChangeError &&
                            entryMarketPosition !=
                                MarketPosition.Flat;
                    }
                    else
                    {
                        bool stopWorking =
                            stopOrder != null &&
                            (
                                stopOrder.OrderState ==
                                    OrderState.Working ||
                                stopOrder.OrderState ==
                                    OrderState.Accepted ||
                                stopOrder.OrderState ==
                                    OrderState.ChangePending ||
                                stopOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        bool targetWorking =
                            targetOrder != null &&
                            (
                                targetOrder.OrderState ==
                                    OrderState.Working ||
                                targetOrder.OrderState ==
                                    OrderState.Accepted ||
                                targetOrder.OrderState ==
                                    OrderState.ChangePending ||
                                targetOrder.OrderState ==
                                    OrderState.ChangeSubmitted
                            );

                        if (
                            stopWorking &&
                            targetWorking &&
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "PROTECTED";
                        }
                        else if (
                            entryMarketPosition !=
                                MarketPosition.Flat
                        )
                        {
                            executionStatus =
                                "UPDATING OCO";
                        }
                    }

                    stopForLog =
                        activeStopPrice;

                    targetForLog =
                        activeTargetPrice;
                }

                UpdateExecutionMonitor();

                bool bracketBuildInProgress;
                bool exitSettlementFenceActive;

                lock (executionStateLock)
                {
                    bracketBuildInProgress =
                        protectiveBracketBuildInProgress;

                    exitSettlementFenceActive =
                        protectiveExitSettlementInProgress ||
                        (
                            protectiveExitSettlementFenceUntilUtc !=
                                DateTime.MinValue &&
                            DateTime.UtcNow <
                                protectiveExitSettlementFenceUntilUtc
                        );
                }

                if (
                    !rejected &&
                    !bracketBuildInProgress &&
                    !exitSettlementFenceActive
                )
                {
                    double localEntryAverage;
                    int localEntryQty;
                    MarketPosition localEntrySide;

                    lock (executionStateLock)
                    {
                        localEntryAverage =
                            entryFillPrice;

                        localEntryQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                activeExitQuantity
                            );

                        localEntrySide =
                            entryMarketPosition;
                    }

                    if (
                        localEntryQty > 0 &&
                        localEntryAverage > 0 &&
                        localEntrySide !=
                            MarketPosition.Flat
                    )
                    {
                        SyncProtectiveBracketToEntry(
                            localEntryAverage,
                            localEntryQty,
                            localEntrySide
                        );
                    }
                }

                if (rejected)
                {
                    PrintBotMessage(
                        "ORDER ERROR"
                        + " | "
                        + orderName
                        + " | State: "
                        + e.Order.OrderState
                        + " | Error: "
                        + e.Error
                        + " | Comment: "
                        + e.Comment
                    );

                    Account account =
                        selectedAccount;

                    Instrument instrument =
                        selectedInstrument;

                    if (recoverableProtectiveChangeError)
                    {
                        PrintBotMessage(
                            "PROTECTIVE CHANGE REJECTED - KEEP EXISTING BRACKET"
                            + " | Reason: INVALID/STALE CHANGE PRICE"
                            + " | Action: RESTORE LAST CONFIRMED PROTECTION / NO FLATTEN"
                        );

                        // A failed order modification normally leaves the last
                        // accepted OCO working. Re-sync from that accepted state
                        // rather than converting a management error into a loss.
                        double retryEntry;
                        int retryQty;
                        MarketPosition retrySide;
                        lock (executionStateLock)
                        {
                            retryEntry = entryFillPrice;
                            retryQty = Math.Max(0, entryQuantity - activeExitQuantity);
                            retrySide = entryMarketPosition;
                        }

                        if (
                            retryEntry > 0 &&
                            retryQty > 0 &&
                            retrySide != MarketPosition.Flat &&
                            !IsProtectiveExitSettlementFenceActive()
                        )
                        {
                            SyncProtectiveBracketToEntry(
                                retryEntry,
                                retryQty,
                                retrySide
                            );
                        }

                        return;
                    }

                    if (
                        shouldFlatten &&
                        account != null &&
                        instrument != null &&
                        IsSimulationAccount(
                            account
                        )
                    )
                    {
                        try
                        {
                            // Never call Flatten while holding executionStateLock.
                            account.Flatten(
                                new[]
                                {
                                    instrument
                                }
                            );

                            lock (executionStateLock)
                            {
                                executionStatus =
                                    "FLATTENING";
                            }

                            UpdateExecutionMonitor();
                        }
                        catch (
                            Exception flattenEx
                        )
                        {
                            PrintBotMessage(
                                "ORDER ERROR FLATTEN FAILED: "
                                + flattenEx.Message
                            );
                        }
                    }

                    return;
                }

                PrintBotMessage(
                    "ORDER UPDATE"
                    + " | "
                    + orderName
                    + " | State: "
                    + e.Order.OrderState
                    + " | Stop: "
                    + stopForLog.ToString("0.00")
                    + " | Target: "
                    + targetForLog.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "ORDER UPDATE ERROR: "
                    + ex.Message
                );
            }
        }
        private void OnAccountExecutionUpdate(
            object sender,
            ExecutionEventArgs e)
        {
            Account eventAccount =
                sender as Account;

            if (
                subscribedAccount == null ||
                (
                    eventAccount != null &&
                    !object.ReferenceEquals(
                        eventAccount,
                        subscribedAccount
                    )
                )
            )
            {
                return;
            }

            if (
                e == null ||
                e.Execution == null ||
                e.Execution.Instrument == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            if (
                e.Execution.Instrument.FullName !=
                    selectedInstrument.FullName
            )
            {
                return;
            }

            string orderName =
                e.Execution.Order != null
                    ? e.Execution.Order.Name
                    : e.Execution.Name;

            if (
                IsAnyProfileBotOrder(orderName) &&
                !IsOwnProfileBotOrder(orderName)
            )
            {
                return;
            }

            Account executionAccount =
                sender as Account;

            if (executionAccount == null)
            {
                executionAccount =
                    selectedAccount;
            }

            Instrument executionInstrument =
                e.Execution.Instrument;

            // ---------------------------------------------
            // ENTRY FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            bool isPrimaryEntryFill =
                orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                orderName == GetProfileOrderName("JJ_ENTRY_SHORT");

            bool isScaleInFill =
                orderName == GetProfileOrderName("JJ_SCALE_IN_LONG") ||
                orderName == GetProfileOrderName("JJ_SCALE_IN_SHORT");

            if (
                isPrimaryEntryFill ||
                isScaleInFill
            )
            {
                MarketPosition filledSide =
                    (
                        orderName == GetProfileOrderName("JJ_ENTRY_LONG") ||
                        orderName == GetProfileOrderName("JJ_SCALE_IN_LONG")
                    )
                        ? MarketPosition.Long
                        : MarketPosition.Short;

                bool firstFill;
                int cumulativeEntryQty;
                double averageEntryPrice;
                int localTradesToday;
                int localPremarketTrades;
                int localAmTrades;
                int localPmTrades;
                int localMiddayTrades;
                bool localManualTest;
                bool localOpeningEntry;
                bool localPremarketEntry;
                string localEntryRoute;

                lock (executionStateLock)
                {
                    firstFill =
                        !isScaleInFill &&
                        (
                            entryQuantity <= 0 ||
                            entryMarketPosition ==
                                MarketPosition.Flat
                        );

                    localManualTest =
                        firstFill
                            ? pendingEntryIsManualTest
                            : activeTradeIsManualTest;

                    localOpeningEntry =
                        firstFill
                            ? pendingEntryIsOpening
                            : activeTradeIsOpening;

                    localPremarketEntry =
                        firstFill
                            ? pendingEntryIsPremarket
                            : activeTradeIsPremarket;

                    localEntryRoute =
                        firstFill
                            ? pendingEntryRoute
                            : activeTradeEntryRoute;

                    if (firstFill)
                    {
                        // A genuine new entry owns a new lifecycle.
                        // Any old settlement dead-zone is no longer relevant.
                        protectiveExitSettlementInProgress =
                            false;

                        protectiveExitSettlementFenceUntilUtc =
                            DateTime.MinValue;

                        smartScaleInUsed = false;
                        smartScaleInPending = false;
                        smartScaleInOrder = null;
                        initialTradeQuantity = 0;
                        initialTradeRiskDollars = 0;
                        lastSmartScaleInAttemptUtc =
                            DateTime.MinValue;

                        activeTradeIsManualTest =
                            localManualTest;

                        activeTradeIsOpening =
                            localOpeningEntry;

                        activeTradeEntryRoute =
                            localEntryRoute ?? string.Empty;

                        activeTradeSession =
                            pendingEntrySession ?? "OUTSIDE";

                        activeTradeEffectiveStopTicks =
                            pendingEntryEffectiveStopTicks > 0
                                ? pendingEntryEffectiveStopTicks
                                : activeStopTicks;

                        activeTradeIsPremarket =
                            localPremarketEntry;

                        activeTradeSetupConfidence =
                            pendingTradeSetupConfidence;

                        activeTradeSetupQuality =
                            string.IsNullOrWhiteSpace(
                                pendingTradeSetupQuality
                            )
                                ? "ANALYZING"
                                : pendingTradeSetupQuality;

                        activeTradeSetupTiming =
                            string.IsNullOrWhiteSpace(
                                pendingTradeSetupTiming
                            )
                                ? "ANALYZING"
                                : pendingTradeSetupTiming;

                        activeTradeManipulationState =
                            string.IsNullOrWhiteSpace(
                                pendingTradeManipulationState
                            )
                                ? "NONE"
                                : pendingTradeManipulationState;

                        if (
                            localOpeningEntry &&
                            !localManualTest
                        )
                        {
                            openingTradeTakenToday =
                                true;
                        }
                    }

                    if (
                        isScaleInFill &&
                        (
                            entryMarketPosition ==
                                MarketPosition.Flat ||
                            entryMarketPosition !=
                                filledSide
                        )
                    )
                    {
                        return;
                    }

                    int previousQty =
                        Math.Max(
                            0,
                            entryQuantity
                        );

                    double previousAverage =
                        entryFillPrice;

                    cumulativeEntryQty =
                        previousQty +
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (cumulativeEntryQty <= 0)
                    {
                        return;
                    }

                    averageEntryPrice =
                        previousQty > 0 &&
                        previousAverage > 0
                            ? (
                                (
                                    previousAverage
                                    * previousQty
                                )
                                +
                                (
                                    e.Price
                                    * e.Quantity
                                )
                            )
                            / cumulativeEntryQty
                            : e.Price;

                    entryFillPrice =
                        averageEntryPrice;

                    entryQuantity =
                        cumulativeEntryQty;

                    // V1.6.83 - use Ninja-reported commission when available;
                    // otherwise fall back to JJ's firm/instrument fee table.
                    // This keeps Gross / Fees / Net and Learning accurate on
                    // prop connections where Execution.Commission is reported as 0.
                    double entryExecutionFee =
                        ResolveExecutionCommission(
                            e.Execution.Commission,
                            Math.Max(0, e.Quantity)
                        );

                    activeEntryCommission +=
                        entryExecutionFee;

                    if (!localManualTest)
                    {
                        botDailyFees +=
                            entryExecutionFee;

                        botDailyPnL -=
                            entryExecutionFee;
                    }

                    botUnrealizedPnL =
                        0;

                    if (previousQty == 0)
                    {
                        activeTradeEntryUtc = DateTime.UtcNow;
                        lastConfirmedStopPrice = 0;
                        lastConfirmedTargetPrice = 0;
                        activeTradeMfeDollars = 0;
                        activeTradeMaeDollars = 0;
                        activeTradePeakPnlDollars = 0;
                        activeTradeCurrentPrice = averageEntryPrice;
                        activeTradeUnrealizedPnl = 0;
                        activeTradeOriginalStopPrice = 0;
                        activeTradeOriginalTargetPrice = 0;
                        activeProfitRetentionStage = 0;
                        activeGivebackGuardArmed = false;
                        lastGivebackGuardLogKey = string.Empty;
                        activeProfitRetentionFactor = 0;
                        activeReversalGuardArmed = false;
                        lastReversalGuardLogKey = string.Empty;
                        activeTradeExitReason = string.Empty;
                        activeForcedExitReason = string.Empty;
                    }

                    entryMarketPosition =
                        filledSide;

                    if (
                        e.Execution.Order != null
                    )
                    {
                        if (isScaleInFill)
                        {
                            smartScaleInOrder =
                                e.Execution.Order;

                            smartScaleInPending =
                                e.Execution.Order.OrderState ==
                                    OrderState.PartFilled;
                        }
                        else
                        {
                            entryOrder =
                                e.Execution.Order;

                            entryPending =
                                e.Execution.Order.OrderState ==
                                    OrderState.PartFilled;

                            if (!entryPending)
                            {
                                pendingEntryRequestedQuantity =
                                    0;

                                pendingEntryEffectiveStopTicks =
                                    0;
                            }
                        }
                    }
                    else if (!isScaleInFill)
                    {
                        int requestedQty =
                            pendingEntryRequestedQuantity > 0
                                ? pendingEntryRequestedQuantity
                                : activeContracts;

                        entryPending =
                            cumulativeEntryQty <
                                requestedQty;
                    }

                    if (!isScaleInFill)
                    {
                        initialTradeQuantity =
                            cumulativeEntryQty;

                        initialTradeRiskDollars =
                            GetActiveTradeStopTicks()
                            * executionInstrument
                                .MasterInstrument
                                .TickSize
                            * executionInstrument
                                .MasterInstrument
                                .PointValue
                            * initialTradeQuantity;
                    }
                    else
                    {
                        smartScaleInUsed = true;
                        smartScaleInPending = false;
                    }

                    if (firstFill)
                    {
                        // Consume the structure only once: on the first
                        // real execution of this entry lifecycle.
                        if (
                            !string.IsNullOrWhiteSpace(
                                pendingStructureSetupKey
                            )
                        )
                        {
                            if (
                                filledSide ==
                                    MarketPosition.Long
                            )
                            {
                                consumedBullishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBullishStructureConfirmTime
                                )
                                {
                                    consumedBullishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                            else
                            {
                                consumedBearishStructureSetupKey =
                                    pendingStructureSetupKey;

                                if (
                                    pendingStructureConfirmTime >
                                        consumedBearishStructureConfirmTime
                                )
                                {
                                    consumedBearishStructureConfirmTime =
                                        pendingStructureConfirmTime;
                                }
                            }
                        }

                        if (!localManualTest)
                        {
                        string learningSide =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSide
                            )
                                ? pendingLearningSide
                                : (
                                    filledSide ==
                                        MarketPosition.Long
                                        ? "LONG"
                                        : "SHORT"
                                );

                        string learningSession =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningSession
                            )
                                ? pendingLearningSession
                                : "UNKNOWN";

                        string learningStructure =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningStructure
                            )
                                ? pendingLearningStructure
                                : "UNKNOWN";

                        JJBotLearningTrade newLearningTrade =
                            new JJBotLearningTrade();

                        newLearningTrade.Side =
                            learningSide;

                        newLearningTrade.SessionWindow =
                            learningSession;

                        newLearningTrade.Structure =
                            learningStructure;

                        newLearningTrade.SignalTimeNy =
                            pendingLearningSignalTimeNy;

                        newLearningTrade.EntryPrice =
                            averageEntryPrice;

                        newLearningTrade.Mfe =
                            0;

                        newLearningTrade.Mae =
                            0;

                        newLearningTrade.TechnicalConfidence =
                            activeTradeSetupConfidence;

                        newLearningTrade.SetupQuality =
                            activeTradeSetupQuality ?? string.Empty;

                        newLearningTrade.SetupTiming =
                            activeTradeSetupTiming ?? string.Empty;

                        newLearningTrade.ManipulationState =
                            activeTradeManipulationState ?? string.Empty;

                        newLearningTrade.VwapLocation =
                            pendingLearningVwapLocation ?? "WAITING";
                        newLearningTrade.VwapBandState =
                            pendingLearningVwapBandState ?? "WAITING";
                        newLearningTrade.VwapSlope =
                            pendingLearningVwapSlope ?? "FLAT";
                        newLearningTrade.VwapEntryContext =
                            pendingLearningVwapEntryContext ?? "NEUTRAL";
                        newLearningTrade.VwapZScore =
                            pendingLearningVwapZScore;
                        newLearningTrade.VwapBandWidthRatio =
                            pendingLearningVwapBandWidthRatio;

                        activeLearningTrade =
                            newLearningTrade;

                        activeLearningEventKey =
                            BuildSharedLearningEventKey(
                                newLearningTrade.Side,
                                newLearningTrade.SignalTimeNy,
                                newLearningTrade.Structure
                            );

                        lock (SharedLearningSyncRoot)
                        {
                            ClaimSharedLearningEvent(
                                activeLearningEventKey
                            );
                        }
                        }
                        else
                        {
                            activeLearningTrade =
                                null;

                            activeLearningEventKey =
                                string.Empty;
                        }

                        pendingStructureSetupKey =
                            string.Empty;

                        pendingStructureConfirmTime =
                            DateTime.MinValue;

                        riskFlattenSent =
                            false;

                        riskFlattenStage =
                            0;

                        riskFlattenLastActionUtc =
                            DateTime.MinValue;

                        riskFlattenOrder =
                            null;

                        activeEntryUsesMomentumTrailing =
                            true;

                        // Snapshot the entry-quality context once.
                        // A strong Momentum trade gets more room before BE,
                        // based on the exact signal-side score/breakout/volume.
                        int entryMomentumScore =
                            filledSide ==
                                MarketPosition.Long
                                ? latestRangeLongScore
                                : latestRangeShortScore;

                        bool entryBreakoutAligned =
                            filledSide ==
                                MarketPosition.Long
                                ? latestRangeHighBreakout
                                : latestRangeLowBreakout;

                        bool entryContextIsMomentum =
                            !string.IsNullOrWhiteSpace(
                                pendingLearningStructure
                            ) &&
                            pendingLearningStructure.IndexOf(
                                "MOMENTUM",
                                StringComparison.OrdinalIgnoreCase
                            ) >= 0;

                        activeStrongMomentumProtection =
                            !localManualTest &&
                            entryContextIsMomentum &&
                            entryMomentumScore >=
                                StrongMomentumMinScore &&
                            entryBreakoutAligned &&
                            latestRangeVolumeRatio >=
                                StrongMomentumMinVolumeRatio;

                        activeBreakEvenTriggerTicks =
                            activeStrongMomentumProtection
                                ? StrongMomentumBreakEvenTriggerTicks
                                : MomentumBreakEvenTriggerTicks;

                        momentumTrailingStage =
                            0;

                        lastMomentumTrailingStopPrice =
                            0;

                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        dailyTargetProtectionArmed =
                            false;

                        lastDailyTargetProtectionStopPrice =
                            0;

                        lastDailyTargetProtectionChangeUtc =
                            DateTime.MinValue;

                        activeExitQuantity =
                            0;

                        activeExitGrossPnL =
                            0;

                        activeExitCommission =
                            0;

                        executionStatus =
                            e.Execution.Order != null &&
                            e.Execution.Order.OrderState ==
                                OrderState.PartFilled
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";

                        // Exactly one official trade count per lifecycle.
                        // Manual TEST_LONG / TEST_SHORT are diagnostic only.
                        if (!localManualTest)
                        {
                            tradesToday++;

                            if (
                                string.Equals(
                                    pendingEntrySession,
                                    "ASIA",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                asiaTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "PREMARKET",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                premarketTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "AM",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                amTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "MIDDAY",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                middayTradesToday++;
                            }
                            else if (
                                string.Equals(
                                    pendingEntrySession,
                                    "PM",
                                    StringComparison.OrdinalIgnoreCase
                                )
                            )
                            {
                                pmTradesToday++;
                            }
                        }
                    }
                    else
                    {
                        // Keep one learning trade and update only its
                        // weighted average entry.
                        if (
                            activeLearningTrade != null
                        )
                        {
                            activeLearningTrade.EntryPrice =
                                averageEntryPrice;
                        }

                        executionStatus =
                            entryPending
                                ? "ENTRY PARTIAL"
                                : "ENTRY FILLED";
                    }

                    localTradesToday =
                        tradesToday;

                    localPremarketTrades =
                        premarketTradesToday;

                    localAmTrades =
                        amTradesToday;

                    localPmTrades =
                        pmTradesToday;

                    localMiddayTrades =
                        middayTradesToday;
                }

                if (isScaleInFill)
                {
                    PrintBotMessage(
                        "SMART SCALE-IN FILLED"
                        + " | Fill: "
                        + e.Quantity
                        + " @ "
                        + e.Price.ToString("0.00")
                        + " | Total Qty: "
                        + cumulativeEntryQty
                        + " | New Avg: "
                        + averageEntryPrice.ToString("0.00")
                    );
                }

                if (
                    firstFill &&
                    localOpeningEntry &&
                    !localManualTest
                )
                {
                    PrintBotMessage(
                        "OPENING TRADE FILLED"
                        + " | Side: "
                        + (
                            filledSide ==
                                MarketPosition.Long
                                ? "LONG"
                                : "SHORT"
                        )
                        + " | Avg: "
                        + averageEntryPrice.ToString("0.00")
                        + " | Opening trade consumed for today."
                    );
                }

                if (firstFill)
                {
                    PrintBotMessage(
                        "TRADE PROTECTION ARMED"
                        + " | PROTECT +"
                        + MomentumFirstProtectionProfitTicks
                        + "t @ +"
                        + MomentumBreakEvenTriggerTicks
                        + "t"
                        + (
                            activeStrongMomentumProtection
                                ? " (STRONG SETUP)"
                                : " (STANDARD)"
                          )
                        + " | LOCK +"
                        + MomentumLockProfitTicks
                        + "t @ +"
                        + MomentumLockTriggerTicks
                        + "t"
                        + " | LOCK2 +"
                        + MomentumLock2ProfitTicks
                        + "t @ +"
                        + MomentumLock2TriggerTicks
                        + "t"
                        + " | TRAIL "
                        + MomentumTrailDistanceTicks
                        + "t @ +"
                        + MomentumTrailTriggerTicks
                        + "t"
                        + " | SCALE +1 @ +"
                        + SmartScaleInTriggerTicks
                        + "t if confirmed & risk <= initial"
                    );

                    JJBotSharedState.PublishExecution(
                        executionAccount != null
                            ? executionAccount.Name
                            : string.Empty,
                        executionInstrument != null
                            ? executionInstrument.FullName
                            : string.Empty,
                        filledSide ==
                            MarketPosition.Long
                            ? "BUY"
                            : "SELL",
                        e.Price
                    );
                }

                UpdateExecutionMonitor();
                SavePersistentDailyState();

                PrintBotMessage(
                    (
                        isScaleInFill
                            ? "SCALE-IN ENTRY FILL"
                            : (
                                entryPending
                                    ? "ENTRY PARTIAL FILL"
                                    : "ENTRY FILL COMPLETE"
                              )
                    )
                    + " | Fill Qty: "
                    + e.Quantity
                    + " | Total Qty: "
                    + cumulativeEntryQty
                    + (
                        isScaleInFill
                            ? string.Empty
                            : "/"
                                + (
                                    pendingEntryRequestedQuantity > 0
                                        ? pendingEntryRequestedQuantity
                                        : activeContracts
                                  )
                    )
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                );

                if (firstFill && !localManualTest)
                {
                    PrintBotMessage(
                        "SESSION TRADE COUNT"
                        + " | PRE: "
                        + localPremarketTrades
                        + "/"
                        + PremarketMaxTrades
                        + " | AM: "
                        + localAmTrades
                        + "/"
                        + activeMaxTrades
                        + " | MIDDAY: "
                        + localMiddayTrades
                        + "/"
                        + MiddayMaxTrades
                        + " | PM: "
                        + localPmTrades
                        + "/"
                        + activeMaxTrades
                        + " | Day: "
                        + localTradesToday
                    );
                }

                SyncProtectiveBracketToEntry(
                    averageEntryPrice,
                    cumulativeEntryQty,
                    filledSide
                );

                // V1.6.97 - verify the actual OCO after EVERY primary/scale fill.
                // This catches a transient bracket-build race as well as an
                // incomplete OCO resize after Smart Scale-In.
                QueueProtectionInvariantWatchdog();

                if (isScaleInFill)
                {
                    EnforceSmartScaleInRiskCap();
                }

                UpdateExecutionUi();

                return;
            }

            MarketPosition currentSide;
            double currentEntryPrice;
            int currentEntryQty;
            double currentEntryCommission;
            bool currentTradeIsManualTest;

            lock (executionStateLock)
            {
                currentSide =
                    entryMarketPosition;

                currentEntryPrice =
                    entryFillPrice;

                currentEntryQty =
                    entryQuantity;

                currentEntryCommission =
                    activeEntryCommission;

                currentTradeIsManualTest =
                    activeTradeIsManualTest;
            }

            // ---------------------------------------------
            // EXIT FILL - PARTIAL FILL SAFE
            // ---------------------------------------------
            if (
                currentSide !=
                    MarketPosition.Flat &&
                currentEntryPrice > 0 &&
                currentEntryQty > 0
            )
            {
                Order executionOrder =
                    e.Execution.Order;

                OrderAction executionAction =
                    executionOrder != null
                        ? executionOrder.OrderAction
                        : OrderAction.Buy;

                bool protectiveExit =
                    orderName == GetProfileOrderName("JJ_STOP") ||
                    orderName == GetProfileOrderName("JJ_TARGET");

                bool riskExit =
                    orderName == GetProfileOrderName("JJ_RISK_FLATTEN");

                bool externalClosingAction =
                    (
                        currentSide ==
                            MarketPosition.Long &&
                        executionAction ==
                            OrderAction.Sell
                    ) ||
                    (
                        currentSide ==
                            MarketPosition.Short &&
                        executionAction ==
                            OrderAction.BuyToCover
                    );

                bool recognizedExit =
                    protectiveExit ||
                    riskExit ||
                    (
                        !IsAnyProfileBotOrder(orderName) &&
                        orderName != GetProfileOrderName("JJ_ENTRY_LONG") &&
                        orderName != GetProfileOrderName("JJ_ENTRY_SHORT") &&
                        orderName != GetProfileOrderName("JJ_SCALE_IN_LONG") &&
                        orderName != GetProfileOrderName("JJ_SCALE_IN_SHORT") &&
                        externalClosingAction
                    );

                if (recognizedExit)
                {
                    double pointValue =
                        executionInstrument
                            .MasterInstrument
                            .PointValue;

                    int exitQty =
                        Math.Max(
                            0,
                            e.Quantity
                        );

                    if (exitQty <= 0)
                    {
                        return;
                    }

                    double grossPnL =
                        currentSide ==
                            MarketPosition.Long
                            ? (
                                e.Price -
                                currentEntryPrice
                            )
                            * pointValue
                            * exitQty
                            : (
                                currentEntryPrice -
                                e.Price
                            )
                            * pointValue
                            * exitQty;

                    double exitCommission =
                        ResolveExecutionCommission(
                            e.Execution.Commission,
                            exitQty
                        );

                    bool accountFlatAfterExecution =
                        e.Execution.Position == 0 ||
                        IsSelectedInstrumentFlat();

                    bool lifecycleComplete;
                    int localExitQty;
                    int localRemainingQty;
                    double localBotPnL;
                    bool localDailyLocked;
                    double finalLearningNet;
                    string finalExitReason = string.Empty;
                    double finalTradeMfe = 0;
                    double finalTradeMae = 0;
                    double finalTradePeak = 0;

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition !=
                                currentSide ||
                            entryFillPrice <= 0
                        )
                        {
                            return;
                        }

                        if (!currentTradeIsManualTest)
                        {
                            botDailyGrossPnL +=
                                grossPnL;

                            botDailyFees +=
                                exitCommission;

                            botDailyPnL +=
                                grossPnL;

                            botDailyPnL -=
                                exitCommission;
                        }

                        activeExitQuantity +=
                            exitQty;

                        activeExitGrossPnL +=
                            grossPnL;

                        activeExitCommission +=
                            exitCommission;

                        localExitQty =
                            Math.Min(
                                activeExitQuantity,
                                entryQuantity
                            );

                        localRemainingQty =
                            Math.Max(
                                0,
                                entryQuantity -
                                localExitQty
                            );

                        lifecycleComplete =
                            accountFlatAfterExecution ||
                            localRemainingQty <= 0;

                        botUnrealizedPnL =
                            lifecycleComplete
                                ? 0
                                : botUnrealizedPnL;

                        if (lifecycleComplete)
                        {
                            // V1.6.82 - give NinjaTrader position state and any
                            // in-flight market-data callbacks a brief window to
                            // settle after a complete exit. CheckDailyLossEmergency
                            // will use realized PnL only during this window.
                            dailyLossExitSettlementUntilUtc =
                                DateTime.UtcNow.AddMilliseconds(1500);

                            if (!currentTradeIsManualTest)
                            {
                                if (
                                    botDailyPnL >=
                                        activeDailyTarget
                                )
                                {
                                    SetPersistentDailyLock(
                                        "DAILY TARGET"
                                    );
                                }
                                else if (
                                    botDailyPnL <=
                                        -activeDailyLoss
                                )
                                {
                                    SetPersistentDailyLock(
                                        "DAILY LOSS"
                                    );
                                }
                            }

                            if (
                                !string.IsNullOrWhiteSpace(activeForcedExitReason)
                            )
                            {
                                finalExitReason = activeForcedExitReason;
                            }
                            else if (
                                orderName == GetProfileOrderName("JJ_TARGET")
                            )
                            {
                                finalExitReason = "TP";
                            }
                            else if (
                                orderName == GetProfileOrderName("JJ_STOP")
                            )
                            {
                                // V1.6.94 - classify the FINAL stop exit by the
                                // actual trade result before falling back to the
                                // management-stage label.
                                //
                                // A JJ_STOP fill is not automatically a losing SL:
                                // the stop may already be at entry or in profit.
                                // Use gross trade PnL here because commissions can
                                // make a true price-BE exit slightly negative net.
                                const double ProtectedStopGrossEpsilon = 0.01;

                                bool stopExitedAtOrBetterThanEntry =
                                    currentSide == MarketPosition.Long
                                        ? e.Price >= currentEntryPrice
                                        : e.Price <= currentEntryPrice;

                                bool protectedStopByGrossPnl =
                                    activeExitGrossPnL >= -ProtectedStopGrossEpsilon;

                                if (
                                    stopExitedAtOrBetterThanEntry ||
                                    protectedStopByGrossPnl
                                )
                                {
                                    finalExitReason =
                                        Math.Abs(activeExitGrossPnL) <=
                                            ProtectedStopGrossEpsilon
                                            ? "BREAKEVEN"
                                            : "PROTECTED_STOP";
                                }
                                else
                                {
                                    finalExitReason =
                                        activeReversalGuardArmed
                                            ? "REVERSAL_GUARD"
                                            : activeGivebackGuardArmed
                                                ? "PROFIT_GIVEBACK"
                                                : activeProfitRetentionStage > 0
                                                    ? "PROFIT_RETENTION"
                                                    : momentumTrailingStage >= 4
                                                        ? "TRAILING"
                                                        : momentumTrailingStage >= 2
                                                            ? "PROFIT_LOCK"
                                                            : momentumTrailingStage >= 1
                                                                ? "BREAKEVEN"
                                                                : "SL";
                                }
                            }
                            else if (riskExit)
                            {
                                finalExitReason = "RISK_FLATTEN";
                            }
                            else
                            {
                                finalExitReason = "MANUAL_OR_EXTERNAL";
                            }

                            activeTradeExitReason = finalExitReason;
                            finalTradeMfe = activeTradeMfeDollars;
                            finalTradeMae = activeTradeMaeDollars;
                            finalTradePeak = activeTradePeakPnlDollars;

                            executionStatus =
                                persistentDailyLocked
                                    ? "DAILY RISK LOCK"
                                    : (
                                        protectiveExit
                                            ? (
                                                orderName ==
                                                    GetProfileOrderName("JJ_TARGET")
                                                    ? "TARGET FILLED"
                                                    : "STOP FILLED"
                                            )
                                            : "FLAT CONFIRMED"
                                    );

                            finalLearningNet =
                                activeExitGrossPnL
                                - activeEntryCommission
                                - activeExitCommission;
                        }
                        else
                        {
                            executionStatus =
                                protectiveExit
                                    ? "EXIT PARTIAL"
                                    : "FLATTEN PARTIAL";

                            finalLearningNet =
                                0;
                        }

                        localBotPnL =
                            botDailyPnL;

                        localDailyLocked =
                            persistentDailyLocked;
                    }

                    // V1.7.02 - ASIA loss transfers the unused PRE trade to NY AM.
                    if (
                        lifecycleComplete &&
                        !currentTradeIsManualTest &&
                        string.Equals(activeTradeSession, "ASIA", StringComparison.OrdinalIgnoreCase)
                    )
                    {
                        bool armNyBonus = finalLearningNet < -0.01;

                        lock (executionStateLock)
                        {
                            asiaLossNyAmBonusArmed = armNyBonus;
                        }

                        PrintBotMessage(
                            armNyBonus
                                ? "SESSION CAPITAL TRANSFER ARMED | Asia NET "
                                    + finalLearningNet.ToString("$0.00")
                                    + " | PREMARKET OBSERVE ONLY | NY AM +1 TRADE | AM LIMIT "
                                    + GetSessionTradeLimit("AM")
                                : "SESSION CAPITAL TRANSFER NOT NEEDED | Asia NET "
                                    + finalLearningNet.ToString("$0.00")
                                    + " | PREMARKET remains eligible"
                        );
                    }

                    SavePersistentDailyState();
                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        (
                            lifecycleComplete
                                ? "EXIT COMPLETE"
                                : "EXIT PARTIAL FILL"
                        )
                        + " | Order: "
                        + orderName
                        + " | Fill Qty: "
                        + exitQty
                        + " | Closed: "
                        + localExitQty
                        + "/"
                        + currentEntryQty
                        + " | Remaining: "
                        + localRemainingQty
                        + " | Exit: "
                        + e.Price.ToString("0.00")
                        + " | Daily Net PnL: "
                        + localBotPnL.ToString("$0.00")
                        + (
                            lifecycleComplete
                                ? " | ExitReason: " + finalExitReason
                                    + " | MFE: " + finalTradeMfe.ToString("$0.00")
                                    + " | MAE: " + finalTradeMae.ToString("$0.00")
                                    + " | Peak: " + finalTradePeak.ToString("$0.00")
                                : string.Empty
                          )
                        + (
                            currentTradeIsManualTest
                                ? string.Empty
                                : " | Day Gross: "
                                    + botDailyGrossPnL.ToString("$0.00")
                                    + " | Day Fees: "
                                    + botDailyFees.ToString("$0.00")
                        )
                    );

                    if (!lifecycleComplete)
                    {
                        // ExecutionUpdate is now authoritative: this was a
                        // REAL PARTIAL exit, not a completed lifecycle.
                        // Release the temporary fence and resize protection
                        // only for the confirmed remaining quantity.
                        ReleaseProtectiveExitSettlementFenceForPartialExit();

                        ResizeProtectiveOrdersAfterPartialExit(
                            orderName,
                            localRemainingQty
                        );

                        QueueProtectionInvariantWatchdog();

                        UpdateExecutionUi();
                        return;
                    }

                    if (!currentTradeIsManualTest)
                    {
                        lastAutomaticTradeExitWasBreakeven =
                            Math.Abs(
                                activeExitGrossPnL
                            ) <= 0.01;

                        lastAutomaticTradeExitWasLoss =
                            activeExitGrossPnL < -0.01;

                        lastAutomaticTradeExitSide =
                            currentSide == MarketPosition.Long
                                ? "LONG"
                                : currentSide == MarketPosition.Short
                                    ? "SHORT"
                                    : string.Empty;

                        lastAutomaticTradeExitNy =
                            GetCurrentNewYorkTime();

                        lastAutomaticTradeExitRangeBarTime =
                            lastRangeBarTime;

                        lastReentryBlockLogKey =
                            string.Empty;

                        lastRangeSignalLogKey =
                            string.Empty;

                        lastRangeBlockedLogKey =
                            string.Empty;

                        lastLearningBlockedLogKey =
                            string.Empty;

                        PrintBotMessage(
                            "REENTRY REARM ARMED"
                            + " | Cooldown: "
                            + AutomaticReentryCooldownSeconds
                            + "s"
                            + " | Range frontier: "
                            + (
                                lastAutomaticTradeExitRangeBarTime ==
                                    DateTime.MinValue
                                    ? "N/A"
                                    : ConvertToNewYorkTime(
                                        lastAutomaticTradeExitRangeBarTime
                                      ).ToString(
                                        "HH:mm:ss"
                                      )
                              )
                            + " ET"
                        );

                        RecordLearningTradeResult(
                            finalLearningNet,
                            finalExitReason,
                            finalTradePeak
                        );
                    }
                    else
                    {
                        PrintBotMessage(
                            "MANUAL TEST RESULT"
                            + " | Gross: "
                            + activeExitGrossPnL.ToString("$0.00")
                            + " | EntryFees: "
                            + activeEntryCommission.ToString("$0.00")
                            + " | ExitFees: "
                            + activeExitCommission.ToString("$0.00")
                            + " | Net: "
                            + finalLearningNet.ToString("$0.00")
                            + " | Official Daily PnL unchanged: "
                            + localBotPnL.ToString("$0.00")
                        );
                    }

                    lock (executionStateLock)
                    {
                        if (
                            entryMarketPosition ==
                                currentSide
                        )
                        {
                            // V1.6.98 - final exit is authoritative.
                            // Invalidate any watchdog that may have been queued
                            // before the fill callback and keep the timed fence
                            // active for late OCO sibling cancellation events.
                            protectionInvariantWatchdogGeneration++;

                            protectiveExitSettlementInProgress =
                                false;

                            if (
                                protectiveExitSettlementFenceUntilUtc ==
                                    DateTime.MinValue ||
                                protectiveExitSettlementFenceUntilUtc <
                                    DateTime.UtcNow
                            )
                            {
                                protectiveExitSettlementFenceUntilUtc =
                                    DateTime.UtcNow.AddMilliseconds(
                                        ProtectiveExitSettlementFenceMilliseconds
                                    );
                            }

                            entryFillPrice = 0;
                            activeStopPrice = 0;
                            activeTargetPrice = 0;
                            activeTradeMfeDollars = 0;
                            activeTradeMaeDollars = 0;
                            activeTradePeakPnlDollars = 0;
                            activeTradeCurrentPrice = 0;
                            activeTradeEntryUtc = DateTime.MinValue;
                            lastConfirmedStopPrice = 0;
                            lastConfirmedTargetPrice = 0;
                            activeTradeUnrealizedPnl = 0;
                            activeTradeOriginalStopPrice = 0;
                            activeTradeOriginalTargetPrice = 0;
                            activeProfitRetentionStage = 0;
                            activeGivebackGuardArmed = false;
                            lastGivebackGuardLogKey = string.Empty;
                            activeProfitRetentionFactor = 0;
                            activeReversalGuardArmed = false;
                            lastReversalGuardLogKey = string.Empty;
                            activeTradeExitReason = string.Empty;
                            activeForcedExitReason = string.Empty;
                            entryQuantity = 0;
                            botUnrealizedPnL = 0;
                            activeEntryCommission = 0;
                            activeEffectiveTargetTicks = 0;
                            activeExitQuantity = 0;
                            activeExitGrossPnL = 0;
                            activeExitCommission = 0;

                            protectiveChangeInFlight =
                                false;

                            activeProtectiveChangeToken =
                                0;

                            protectiveChangeOwner =
                                string.Empty;

                            protectiveChangeStartedUtc =
                                DateTime.MinValue;

                            entryMarketPosition =
                                MarketPosition.Flat;

                            entryPending =
                                false;

                            pendingEntryIsManualTest =
                                false;

                            activeTradeIsManualTest =
                                false;

                            pendingEntryIsOpening =
                                false;

                            pendingEntryRoute =
                                string.Empty;

                            pendingEntryEffectiveStopTicks =
                                0;

                            activeTradeEffectiveStopTicks =
                                0;

                            activeTradeIsOpening =
                                false;

                            activeTradeEntryRoute =
                                string.Empty;

                            activeTradeSession = "OUTSIDE";

                            pendingEntryIsPremarket =
                                false;

                            activeTradeIsPremarket =
                                false;

                            activeEntryUsesMomentumTrailing =
                                false;

                            momentumTrailingStage =
                                0;

                            lastMomentumTrailingStopPrice =
                                0;

                            activeStrongMomentumProtection =
                                false;

                            activeBreakEvenTriggerTicks =
                                MomentumBreakEvenTriggerTicks;

                            lastMomentumTrailingChangeUtc =
                                DateTime.MinValue;

                            dailyTargetProtectionArmed =
                                false;

                            smartScaleInUsed = false;
                            smartScaleInPending = false;
                            smartScaleInOrder = null;
                            initialTradeQuantity = 0;
                            initialTradeRiskDollars = 0;
                            lastSmartScaleInAttemptUtc =
                                DateTime.MinValue;

                            lastDailyTargetProtectionStopPrice =
                                0;

                            lastDailyTargetProtectionChangeUtc =
                                DateTime.MinValue;

                            entryOrder = null;
                            stopOrder = null;
                            targetOrder = null;
                            riskFlattenOrder = null;
                            riskFlattenSent = false;
                            riskFlattenStage = 0;
                            riskFlattenLastActionUtc =
                                DateTime.MinValue;
                        }
                    }

                    UpdateExecutionMonitor();
                    UpdateExecutionUi();
                    return;
                }
            }
        }

    }
}

#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT PERSISTENCE / SESSION STATE
    // Stage 12 structural extraction only.
    //
    // Existing persistence locking, selection restore,
    // daily-state load/reset/save, safe state-file replacement,
    // persistent file-path resolution and trading-session-date
    // logic are moved exactly as-is.
    //
    // No reset semantics, paths, values, trading-session logic,
    // or runtime behavior was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void TryRestorePersistentStateForSelection()
        {
            if (
                botRunning ||
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            LoadOrResetPersistentDailyState();
        }
        private void LoadOrResetPersistentDailyState()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            // =====================================================
            // WEEKEND CLOSED-MARKET RUNTIME RESET
            // =====================================================
            // Saturday and Sunday before the 18:00 ET futures reopen are
            // outside any active CME-style trading session.
            //
            // IMPORTANT:
            // - Do NOT restore Friday's DAILY LOSS / PROFIT FLOOR lock as
            //   an active weekend lock.
            // - Do NOT overwrite Friday's persisted XML while the market
            //   is closed.
            // - Sunday at/after 18:00 ET is NOT considered weekend-closed;
            //   GetTradingSessionDate() will then start the Monday session.
            if (IsWeekendMarketClosed(nowNy))
            {
                activeTradingDate = DateTime.MinValue;

                tradesToday = 0;
                asiaTradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                asiaLossNyAmBonusArmed = false;
                activeTradeSession = "OUTSIDE";

                pendingEntrySession = "OUTSIDE";

                botDailyGrossPnL = 0;
                botDailyFees = 0;
                botDailyPnL = 0;
                botUnrealizedPnL = 0;

                dailyPeakTotalPnL = 0;
                dailyProtectedProfitFloor = 0;
                dailyProfitFloorArmed = false;
                lastLoggedProtectedProfitFloor = 0;

                persistentDailyLocked = false;
                persistentDailyLockReason = string.Empty;

                lastExecutedSignalBar = DateTime.MinValue;

                consumedBullishStructureSetupKey = string.Empty;
                consumedBearishStructureSetupKey = string.Empty;
                consumedBullishStructureConfirmTime = DateTime.MinValue;
                consumedBearishStructureConfirmTime = DateTime.MinValue;

                pendingStructureSetupKey = string.Empty;
                pendingStructureConfirmTime = DateTime.MinValue;

                pendingEntryIsOpening = false;
                activeTradeIsOpening = false;
                pendingEntryRoute = string.Empty;
                activeTradeEntryRoute = string.Empty;
                pendingEntryIsPremarket = false;
                activeTradeIsPremarket = false;

                openingTradeTakenToday = false;
                openingRangeReady = false;
                openingRangeHigh = 0;
                openingRangeLow = 0;
                openingRangeBarTimeNy = DateTime.MinValue;
                openingRangeLoggedDate = DateTime.MinValue;

                premarketRangeReady = false;
                premarketRangeHigh = 0;
                premarketRangeLow = 0;
                premarketRangeDateNy = DateTime.MinValue;
                premarketRangeLastM5TimeNy = DateTime.MinValue;
                lastPremarketChaseBlockLogKey = string.Empty;
                premarketContextReady = false;
                premarketContextDateNy = DateTime.MinValue;
                premarketContextBias = "NEUTRAL";
                premarketContextBiasScore = 0;
                lastPremarketContextLogNy = DateTime.MinValue;
                lastPremarketContextFinalLogDateNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;

                riskFlattenSent = false;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                forceFlatSentToday = false;
                forceFlatDateNy = DateTime.MinValue;

                currentSignalState = "WAITING";
                currentSetupState = "MARKET CLOSED";

                PrintBotMessage(
                    "WEEKEND SESSION RESET"
                    + " | Strategy Clock: "
                    + nowNy.ToString("yyyy-MM-dd HH:mm:ss")
                    + " ET"
                    + " | Friday daily risk state kept on disk but NOT active."
                    + " | Next futures reset: Sunday 18:00 ET."
                );

                UpdatePnlDisplay();

                Action updateWeekendUi =
                    new Action(() =>
                    {
                        if (tradesText != null)
                        {
                            tradesText.Text =
                                "AM 0/"
                                + activeMaxTrades
                                + " | PM 0/"
                                + activeMaxTrades;
                        }

                        if (signalText != null)
                        {
                            signalText.Text = "MARKET CLOSED";
                            signalText.Foreground = Brushes.Goldenrod;
                        }
                    });

                if (Dispatcher.CheckAccess())
                {
                    updateWeekendUi();
                }
                else
                {
                    Dispatcher.InvokeAsync(updateWeekendUi);
                }

                return;
            }

            DateTime tradingSessionDate =
                GetTradingSessionDate(
                    nowNy
                );

            activeTradingDate =
                tradingSessionDate;

            JJBotDailyStateData state =
                LoadPersistentDailyState();

            bool stateMatchesToday =
                state != null &&
                state.NewYorkDate ==
                    tradingSessionDate.ToString(
                        "yyyy-MM-dd"
                    ) &&
                string.Equals(
                    state.AccountName,
                    selectedAccount.Name,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                string.Equals(
                    state.InstrumentName,
                    selectedInstrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                );

            if (stateMatchesToday)
            {
                tradesToday =
                    Math.Max(
                        0,
                        state.TradesToday
                    );

                amTradesToday =
                    Math.Max(
                        0,
                        state.AmTrades
                    );

                pmTradesToday =
                    Math.Max(
                        0,
                        state.PmTrades
                    );

                premarketTradesToday =
                    Math.Max(
                        0,
                        state.PremarketTrades
                    );

                asiaTradesToday =
                    Math.Max(
                        0,
                        state.AsiaTrades
                    );

                middayTradesToday =
                    Math.Max(
                        0,
                        state.MiddayTrades
                    );

                asiaLossNyAmBonusArmed =
                    state.AsiaLossNyAmBonusArmed ||
                    (
                        state.SchemaVersion < 5 &&
                        state.AsiaTrades > 0 &&
                        state.PremarketTrades == 0 &&
                        state.AmTrades == 0 &&
                        state.RealizedPnL < -0.01
                    );

                activeTradeSession = "OUTSIDE";

                botDailyPnL =
                    state.RealizedPnL;

                // Backward compatibility:
                // Old XML files only contain RealizedPnL (which was NET).
                // If V11 fields are absent/default zero, preserve the
                // historical net as gross with zero known fees.
                if (
                    state.SchemaVersion <
                        CurrentDailyStateSchemaVersion &&
                    Math.Abs(state.GrossPnL) < 0.0000001 &&
                    Math.Abs(state.Fees) < 0.0000001 &&
                    Math.Abs(state.RealizedPnL) > 0.0000001
                )
                {
                    botDailyGrossPnL =
                        state.RealizedPnL;

                    botDailyFees =
                        0;
                }
                else
                {
                    botDailyGrossPnL =
                        state.GrossPnL;

                    botDailyFees =
                        Math.Max(
                            0,
                            state.Fees
                        );
                }

                botUnrealizedPnL =
                    0;

                dailyPeakTotalPnL =
                    Math.Max(
                        state.PeakTotalPnL,
                        botDailyPnL
                    );

                dailyProtectedProfitFloor =
                    Math.Max(
                        0,
                        state.ProtectedProfitFloor
                    );

                dailyProfitFloorArmed =
                    state.ProfitFloorArmed &&
                    dailyProtectedProfitFloor > 0;

                lastLoggedProtectedProfitFloor =
                    dailyProtectedProfitFloor;

                persistentDailyLocked =
                    state.DailyLocked;

                persistentDailyLockReason =
                    state.DailyLockReason
                    ?? string.Empty;

                // V1.6.2 GHOST LOCK RECOVERY:
                // Before 16:25 ET, a lock with zero trades, zero PnL and no
                // recorded reason is invalid and is safe to clear.
                bool zeroActivityState =
                    tradesToday == 0 &&
                    Math.Abs(botDailyGrossPnL) < 0.0000001 &&
                    Math.Abs(botDailyFees) < 0.0000001 &&
                    Math.Abs(botDailyPnL) < 0.0000001;

                DateTime restoreNowNy =
                    GetCurrentNewYorkTime();

                bool beforeForceFlat =
                    ToTimeInt(restoreNowNy) <
                        ForceFlatTimeNy;

                // V1.6.14.1 - FORCE FLAT is a SESSION-CLOSE lock only.
                // It is valid exclusively from 16:25 ET until the 18:00 ET
                // futures-session reset. If NinjaTrader/app was not running
                // at 18:00, the persisted FORCE FLAT lock can otherwise be
                // restored the next morning and immediately block START.
                // Clear ONLY this stale reason; real risk locks (daily loss,
                // profit-floor, etc.) remain untouched.
                int restoreTimeValue =
                    ToTimeInt(restoreNowNy);

                bool forceFlatLockWindowActive =
                    restoreNowNy.DayOfWeek != DayOfWeek.Saturday &&
                    restoreNowNy.DayOfWeek != DayOfWeek.Sunday &&
                    restoreTimeValue >= ForceFlatTimeNy &&
                    restoreTimeValue < TradingSessionResetTimeNy;

                bool restoredForceFlatLock =
                    persistentDailyLocked &&
                    string.Equals(
                        persistentDailyLockReason,
                        "FORCE FLAT 16:25 ET",
                        StringComparison.OrdinalIgnoreCase
                    );

                if (
                    restoredForceFlatLock &&
                    !forceFlatLockWindowActive
                )
                {
                    persistentDailyLocked = false;
                    persistentDailyLockReason = string.Empty;
                    forceFlatSentToday = false;
                    forceFlatDateNy = DateTime.MinValue;
                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;

                    PrintBotMessage(
                        "STALE FORCE FLAT LOCK CLEARED"
                        + " | Strategy Clock: "
                        + restoreNowNy.ToString("yyyy-MM-dd HH:mm:ss")
                        + " ET"
                        + " | New session is available."
                    );

                    SavePersistentDailyState();
                }

                if (
                    persistentDailyLocked &&
                    zeroActivityState &&
                    beforeForceFlat &&
                    string.IsNullOrWhiteSpace(
                        persistentDailyLockReason
                    )
                )
                {
                    persistentDailyLocked =
                        false;

                    persistentDailyLockReason =
                        string.Empty;

                    PrintBotMessage(
                        "GHOST DAILY LOCK CLEARED"
                        + " | Date: "
                        + state.NewYorkDate
                        + " | Trades: 0"
                        + " | Gross: $0.00"
                        + " | Fees: $0.00"
                        + " | Net: $0.00"
                    );

                    SavePersistentDailyState();
                }

                lastExecutedSignalBar =
                    state.LastExecutedSignalBar;

                consumedBullishStructureSetupKey =
                    state.ConsumedBullishStructureKey
                    ?? string.Empty;

                consumedBearishStructureSetupKey =
                    state.ConsumedBearishStructureKey
                    ?? string.Empty;

                consumedBullishStructureConfirmTime =
                    state.ConsumedBullishStructureConfirmTime;

                consumedBearishStructureConfirmTime =
                    state.ConsumedBearishStructureConfirmTime;

                openingTradeTakenToday =
                    state.OpeningTradeTaken;

                openingRangeReady = false;
                openingRangeHigh = 0;
                openingRangeLow = 0;
                openingRangeBarTimeNy = DateTime.MinValue;
                openingRangeLoggedDate = DateTime.MinValue;

                premarketRangeReady = false;
                premarketRangeHigh = 0;
                premarketRangeLow = 0;
                premarketRangeDateNy = DateTime.MinValue;
                premarketRangeLastM5TimeNy = DateTime.MinValue;
                lastPremarketChaseBlockLogKey = string.Empty;
                premarketContextReady = false;
                premarketContextDateNy = DateTime.MinValue;
                premarketContextBias = "NEUTRAL";
                premarketContextBiasScore = 0;
                lastPremarketContextLogNy = DateTime.MinValue;
                lastPremarketContextFinalLogDateNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;

                // Backward-compatible recovery if an older state file
                // contains a consumed key but not the explicit timestamp.
                if (
                    consumedBullishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBullishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBullishStructureSetupKey
                        );
                }

                if (
                    consumedBearishStructureConfirmTime ==
                        DateTime.MinValue
                )
                {
                    consumedBearishStructureConfirmTime =
                        GetStructureConfirmTimeFromKey(
                            consumedBearishStructureSetupKey
                        );
                }

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "TRADING SESSION STATE RESTORED"
                    + " | Date: "
                    + state.NewYorkDate
                    + " | Trades: "
                    + tradesToday
                    + " | ASIA: "
                    + asiaTradesToday
                    + "/"
                    + AsiaMaxTrades
                    + " | PRE: "
                    + premarketTradesToday
                    + "/"
                    + PremarketMaxTrades
                    + " | AM: "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | MIDDAY: "
                    + middayTradesToday
                    + "/"
                    + MiddayMaxTrades
                    + " | PM: "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Gross: "
                    + botDailyGrossPnL.ToString("$0.00")
                    + " | Fees: "
                    + botDailyFees.ToString("$0.00")
                    + " | Net: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Peak: "
                    + dailyPeakTotalPnL.ToString("$0.00")
                    + " | ProfitFloor: "
                    + (
                        dailyProfitFloorArmed
                            ? dailyProtectedProfitFloor.ToString("$0.00")
                            : "OFF"
                      )
                    + " | Locked: "
                    + persistentDailyLocked
                    + " | LockReason: "
                    + (
                        string.IsNullOrWhiteSpace(
                            persistentDailyLockReason
                        )
                            ? "NONE"
                            : persistentDailyLockReason
                      )
                    + " | OpeningTaken: "
                    + openingTradeTakenToday
                );
            }
            else
            {
                tradesToday = 0;
                asiaTradesToday = 0;
                premarketTradesToday = 0;
                amTradesToday = 0;
                pmTradesToday = 0;
                middayTradesToday = 0;
                asiaLossNyAmBonusArmed = false;
                activeTradeSession = "OUTSIDE";
                pendingEntrySession = "OUTSIDE";
                botDailyGrossPnL = 0;
                botDailyFees = 0;
                botDailyPnL = 0;
                botUnrealizedPnL = 0;
                dailyPeakTotalPnL = 0;
                dailyProtectedProfitFloor = 0;
                dailyProfitFloorArmed = false;
                lastLoggedProtectedProfitFloor = 0;

                persistentDailyLocked =
                    false;

                persistentDailyLockReason =
                    string.Empty;

                lastExecutedSignalBar =
                    DateTime.MinValue;

                consumedBullishStructureSetupKey =
                    string.Empty;

                consumedBearishStructureSetupKey =
                    string.Empty;

                consumedBullishStructureConfirmTime =
                    DateTime.MinValue;

                consumedBearishStructureConfirmTime =
                    DateTime.MinValue;

                pendingStructureSetupKey =
                    string.Empty;

                pendingStructureConfirmTime =
                    DateTime.MinValue;

                pendingEntryIsOpening = false;
                activeTradeIsOpening = false;
                pendingEntryRoute = string.Empty;
                activeTradeEntryRoute = string.Empty;
                pendingEntryIsPremarket = false;
                activeTradeIsPremarket = false;
                openingTradeTakenToday = false;
                openingRangeReady = false;
                openingRangeHigh = 0;
                openingRangeLow = 0;
                openingRangeBarTimeNy = DateTime.MinValue;
                openingRangeLoggedDate = DateTime.MinValue;

                premarketRangeReady = false;
                premarketRangeHigh = 0;
                premarketRangeLow = 0;
                premarketRangeDateNy = DateTime.MinValue;
                premarketRangeLastM5TimeNy = DateTime.MinValue;
                lastPremarketChaseBlockLogKey = string.Empty;
                premarketContextReady = false;
                premarketContextDateNy = DateTime.MinValue;
                premarketContextBias = "NEUTRAL";
                premarketContextBiasScore = 0;
                lastPremarketContextLogNy = DateTime.MinValue;
                lastPremarketContextFinalLogDateNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;

                SavePersistentDailyState();

                PrintBotMessage(
                    "STATE FILE: "
                    + GetPersistentStateFilePath()
                );

                PrintBotMessage(
                    "NEW TRADING SESSION STATE CREATED"
                    + " | Date: "
                    + tradingSessionDate.ToString(
                        "yyyy-MM-dd"
                    )
                );
            }

            UpdatePnlDisplay();

            Action updateStateUi =
                new Action(() =>
                {
                    if (tradesText != null)
                    {
                        tradesText.Text =
                            "AM "
                            + amTradesToday
                            + "/"
                            + activeMaxTrades
                            + " | PM "
                            + pmTradesToday
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        persistentDailyLocked &&
                        signalText != null
                    )
                    {
                        signalText.Text =
                            "DAILY RISK LOCK";

                        signalText.Foreground =
                            Brushes.OrangeRed;
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                updateStateUi();
            }
            else
            {
                Dispatcher.InvokeAsync(
                    updateStateUi
                );
            }
        }
        private void SavePersistentDailyState()
        {
            string tempPath =
                string.Empty;

            try
            {
                if (
                    selectedAccount == null ||
                    selectedInstrument == null
                )
                {
                    return;
                }

                DateTime saveNowNy =
                    GetCurrentNewYorkTime();

                // Never overwrite the last completed session state while
                // Saturday / pre-open Sunday is only being used for testing.
                if (IsWeekendMarketClosed(saveNowNy))
                {
                    return;
                }

                string accountName =
                    selectedAccount.Name;

                string instrumentName =
                    selectedInstrument.FullName;

                DateTime stateDate;
                int localTradesToday;
                int localAsiaTradesToday;
                int localPremarketTradesToday;
                int localAmTradesToday;
                int localPmTradesToday;
                int localMiddayTradesToday;
                bool localAsiaLossNyAmBonusArmed;
double localBotDailyGrossPnL;
                double localBotDailyFees;
                double localBotDailyPnL;
                double localDailyPeakTotalPnL;
                double localDailyProtectedProfitFloor;
                bool localDailyProfitFloorArmed;
                bool localDailyLocked;
                string localDailyLockReason;
                DateTime localLastExecutedSignalBar;
                string localConsumedBullishStructureKey;
                string localConsumedBearishStructureKey;
                DateTime localConsumedBullishStructureConfirmTime;
                DateTime localConsumedBearishStructureConfirmTime;
                bool localOpeningTradeTaken;

                // Capture one internally consistent state snapshot.
                lock (executionStateLock)
                {
                    stateDate =
                        activeTradingDate !=
                            DateTime.MinValue
                            ? activeTradingDate
                            : GetTradingSessionDate(
                                GetCurrentNewYorkTime()
                              );

                    localTradesToday =
                        tradesToday;

                    localAsiaTradesToday =
                        asiaTradesToday;

                    localPremarketTradesToday =
                        premarketTradesToday;

                    localAmTradesToday =
                        amTradesToday;

                    localPmTradesToday =
                        pmTradesToday;

                    localMiddayTradesToday =
                        middayTradesToday;

                    localAsiaLossNyAmBonusArmed = asiaLossNyAmBonusArmed;

                    localBotDailyGrossPnL =
                        botDailyGrossPnL;

                    localBotDailyFees =
                        botDailyFees;

                    localBotDailyPnL =
                        botDailyPnL;

                    localDailyPeakTotalPnL =
                        dailyPeakTotalPnL;

                    localDailyProtectedProfitFloor =
                        dailyProtectedProfitFloor;

                    localDailyProfitFloorArmed =
                        dailyProfitFloorArmed;

                    localDailyLocked =
                        persistentDailyLocked;

                    localDailyLockReason =
                        persistentDailyLockReason
                        ?? string.Empty;

                    localLastExecutedSignalBar =
                        lastExecutedSignalBar;

                    localConsumedBullishStructureKey =
                        consumedBullishStructureSetupKey;

                    localConsumedBearishStructureKey =
                        consumedBearishStructureSetupKey;

                    localConsumedBullishStructureConfirmTime =
                        consumedBullishStructureConfirmTime;

                    localConsumedBearishStructureConfirmTime =
                        consumedBearishStructureConfirmTime;

                    localOpeningTradeTaken =
                        openingTradeTakenToday;
                }

                JJBotDailyStateData state =
                    new JJBotDailyStateData();

                state.SchemaVersion =
                    CurrentDailyStateSchemaVersion;

                state.NewYorkDate =
                    stateDate.ToString(
                        "yyyy-MM-dd"
                    );

                state.AccountName =
                    accountName;

                state.InstrumentName =
                    instrumentName;

                state.TradesToday =
                    localTradesToday;

                state.PremarketTrades =
                    localPremarketTradesToday;

                state.AsiaTrades =
                    localAsiaTradesToday;

                state.AmTrades =
                    localAmTradesToday;

                state.PmTrades =
                    localPmTradesToday;

                state.MiddayTrades =
                    localMiddayTradesToday;

                state.AsiaLossNyAmBonusArmed = localAsiaLossNyAmBonusArmed;

                state.GrossPnL =
                    localBotDailyGrossPnL;

                state.Fees =
                    localBotDailyFees;

                state.RealizedPnL =
                    localBotDailyPnL;

                state.PeakTotalPnL =
                    localDailyPeakTotalPnL;

                state.ProtectedProfitFloor =
                    localDailyProtectedProfitFloor;

                state.ProfitFloorArmed =
                    localDailyProfitFloorArmed;

                state.DailyLocked =
                    localDailyLocked;

                state.DailyLockReason =
                    localDailyLockReason;

                state.LastExecutedSignalBar =
                    localLastExecutedSignalBar;

                state.ConsumedBullishStructureKey =
                    localConsumedBullishStructureKey
                    ?? string.Empty;

                state.ConsumedBearishStructureKey =
                    localConsumedBearishStructureKey
                    ?? string.Empty;

                state.ConsumedBullishStructureConfirmTime =
                    localConsumedBullishStructureConfirmTime;

                state.ConsumedBearishStructureConfirmTime =
                    localConsumedBearishStructureConfirmTime;

                state.OpeningTradeTaken =
                    localOpeningTradeTaken;

                Directory.CreateDirectory(
                    stateFolderPath
                );

                string filePath =
                    GetPersistentStateFilePath(
                        accountName,
                        instrumentName
                    );

                string backupPath =
                    filePath + ".bak";

                tempPath =
                    filePath
                    + ".tmp."
                    + Guid.NewGuid()
                        .ToString("N");

                object persistenceLock =
                    JJBotRuntimeCoordinator.GetPersistenceLock(
                        accountName,
                        instrumentName
                    );

                lock (persistenceLock)
                {
                    XmlSerializer serializer =
                        new XmlSerializer(
                            typeof(
                                JJBotDailyStateData
                            )
                        );

                    // Never serialize directly into the live XML.
                    using (
                        FileStream stream =
                            new FileStream(
                                tempPath,
                                FileMode.CreateNew,
                                FileAccess.Write,
                                FileShare.None
                            )
                    )
                    {
                        serializer.Serialize(
                            stream,
                            state
                        );

                        stream.Flush(
                            true
                        );
                    }

                    if (File.Exists(filePath))
                    {
                        try
                        {
                            // Atomic replacement on NTFS.
                            // The previous good state becomes .bak.
                            File.Replace(
                                tempPath,
                                filePath,
                                backupPath,
                                true
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (
                            PlatformNotSupportedException
                        )
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                        catch (IOException)
                        {
                            ReplaceStateFileFallback(
                                tempPath,
                                filePath,
                                backupPath
                            );

                            tempPath =
                                string.Empty;
                        }
                    }
                    else
                    {
                        File.Move(
                            tempPath,
                            filePath
                        );

                        tempPath =
                            string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "STATE SAVE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                if (
                    !string.IsNullOrWhiteSpace(
                        tempPath
                    ) &&
                    File.Exists(
                        tempPath
                    )
                )
                {
                    try
                    {
                        File.Delete(
                            tempPath
                        );
                    }
                    catch
                    {
                    }
                }
            }
        }
        private void ReplaceStateFileFallback(
            string tempPath,
            string filePath,
            string backupPath)
        {
            // The per-key persistence lock is already held here.
            // This fallback is used only if File.Replace is unavailable.
            if (File.Exists(filePath))
            {
                File.Copy(
                    filePath,
                    backupPath,
                    true
                );
            }

            File.Copy(
                tempPath,
                filePath,
                true
            );

            File.Delete(
                tempPath
            );
        }
        private string GetPersistentStateFilePath()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return string.Empty;
            }

            return GetPersistentStateFilePath(
                selectedAccount.Name,
                selectedInstrument.FullName
            );
        }
        private string GetPersistentStateFilePath(
            string accountName,
            string instrumentName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                return string.Empty;
            }

            string safeAccount =
                MakeSafeFileName(
                    accountName
                );

            string safeInstrument =
                MakeSafeFileName(
                    instrumentName
                );

            return Path.Combine(
                stateFolderPath,
                "daily_"
                + safeAccount
                + "_"
                + safeInstrument
                + ".xml"
            );
        }
        private bool IsWeekendMarketClosed(
            DateTime nyTime)
        {
            if (nyTime.DayOfWeek == DayOfWeek.Saturday)
            {
                return true;
            }

            if (nyTime.DayOfWeek == DayOfWeek.Sunday)
            {
                return ToTimeInt(nyTime) < TradingSessionResetTimeNy;
            }

            return false;
        }

        private DateTime GetTradingSessionDate(
            DateTime nyTime)
        {
            DateTime calendarDate =
                nyTime.Date;

            int timeValue =
                ToTimeInt(
                    nyTime
                );

            if (nyTime.DayOfWeek == DayOfWeek.Saturday)
            {
                return calendarDate.AddDays(-1);
            }

            if (nyTime.DayOfWeek == DayOfWeek.Sunday)
            {
                return timeValue >= TradingSessionResetTimeNy
                    ? calendarDate.AddDays(1)
                    : calendarDate.AddDays(-2);
            }

            if (nyTime.DayOfWeek == DayOfWeek.Friday)
            {
                // There is no Friday 18:00 ET futures reopen.
                return calendarDate;
            }

            if (timeValue >= TradingSessionResetTimeNy)
            {
                return calendarDate.AddDays(1);
            }

            return calendarDate;
        }

    }
}

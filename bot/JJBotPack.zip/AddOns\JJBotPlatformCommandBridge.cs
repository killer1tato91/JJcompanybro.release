﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT PLATFORM COMMAND BRIDGE
    // Stage 19 structural extraction only.
    //
    // Existing polling, command retrieval and command execution
    // logic are moved exactly as-is.
    //
    // No polling interval, HTTP behavior, command routing,
    // start/stop behavior, trading rules or safety rules changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void StartPlatformCommandPolling()
        {
            if (
                platformCommandTimer != null
            )
            {
                return;
            }

            platformCommandTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformCommandTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformCommandIntervalSeconds
                );

            platformCommandTimer.Tick +=
                PlatformCommandTimerTick;

            platformCommandTimer.Start();
        }
        private void StopPlatformCommandPolling()
        {
            DispatcherTimer timer =
                platformCommandTimer;

            platformCommandTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformCommandTimerTick;
            }
            catch
            {
            }
        }
        // JJ_COMMAND_DUAL_ROUTE_V3
        // Alternate command polling between local Desktop backend
        // and cloud Mobile backend. Trading execution remains local.
        private bool platformPollLocalNext =
            false;

        private void PlatformCommandTimerTick(
            object sender,
            EventArgs e)
        {
            PollPlatformCommand();
        }
        private void PollPlatformCommand()
        {
            if (
                platformCommandRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                // JJ_COMMAND_DUAL_ROUTE_V3
                bool useLocalCommandServer =
                    platformPollLocalNext;

                platformPollLocalNext =
                    !platformPollLocalNext;

                string commandServerUrl =
                    useLocalCommandServer
                        ? platformServerUrl
                        : "https://jjtradingtools.ddns.net";

                string endpoint =
                    commandServerUrl
                        .TrimEnd('/')
                    + "/api/bot/commands?apiKey="
                    + Uri.EscapeDataString(
                        platformApiKey
                    )
                    + "&profileId="
                    + Uri.EscapeDataString(
                        platformProfileId
                    );

                platformCommandRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        ReadPlatformCommandRequest(
                            endpoint,
                            useLocalCommandServer
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformCommandRequestInFlight =
                    false;

                AppendVisualLog(
                    "BOT COMMAND POLL ERROR: "
                    + ex.Message
                );
            }
        }
        private void ExecutePlatformCommand(
            string commandId,
            string commandType,
            string commandAccount,
            string commandInstrument,
            string commandQuery,
            string commandStrategy,
            string commandDirection,
            int commandContracts,
            int commandMaxContracts,
            int commandStopTicks,
            int commandTargetTicks,
            int commandMaxTrades,
            double commandDailyTarget,
            double commandDailyLoss,
            double commandDollarRiskCap,
            string commandDrawdownMode,
            bool commandUsesLocalResultRoute)
        {
            if (
                string.IsNullOrWhiteSpace(
                    commandId
                ) ||
                string.Equals(
                    commandId,
                    lastProcessedPlatformCommandId,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return;
            }

            lastProcessedPlatformCommandId =
                commandId;

            if (
                string.Equals(
                    commandType,
                    "SEARCH_INSTRUMENTS",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                string[] searchResults =
                    SearchNinjaInstruments(
                        commandQuery
                    );

                PostPlatformInstrumentSearchResult(
                    commandId,
                    commandQuery,
                    searchResults,
                    commandUsesLocalResultRoute
                );

                return;
            }

            bool commandNeedsPlatformContext =
                string.Equals(
                    commandType,
                    "START_BOT",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_LONG",
                    StringComparison.OrdinalIgnoreCase
                ) ||
                string.Equals(
                    commandType,
                    "TEST_SHORT",
                    StringComparison.OrdinalIgnoreCase
                );

            if (commandNeedsPlatformContext)
            {
                if (
                    !ApplyPlatformStartConfiguration(
                        commandAccount,
                        commandInstrument,
                        commandStrategy,
                        commandDirection,
                        commandContracts,
                        commandMaxContracts,
                        commandStopTicks,
                        commandTargetTicks,
                        commandMaxTrades,
                        commandDailyTarget,
                        commandDailyLoss,
                        commandDollarRiskCap,
                        commandDrawdownMode
                    )
                )
                {
                    return;
                }
            }

            string selectedAccountName =
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty;

            string selectedInstrumentName =
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty;

            // STOP_BOT and CLOSE_ALL must not depend on what the
            // visible NinjaTrader selectors currently show.
            // CLOSE_ALL resolves the exact Account + Instrument sent
            // by the platform immediately before execution.
            if (
                !string.Equals(
                    commandType,
                    "STOP_BOT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                !string.Equals(
                    commandType,
                    "CLOSE_ALL",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                if (
                    string.IsNullOrWhiteSpace(
                        selectedAccountName
                    ) ||
                    string.IsNullOrWhiteSpace(
                        selectedInstrumentName
                    ) ||
                    !string.Equals(
                        selectedAccountName,
                        commandAccount,
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    !string.Equals(
                        selectedInstrumentName,
                        commandInstrument,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    AppendVisualLog(
                        "REMOTE COMMAND REJECTED | "
                        + commandType
                        + " | Target "
                        + commandAccount
                        + " / "
                        + commandInstrument
                        + " does not match selected "
                        + selectedAccountName
                        + " / "
                        + selectedInstrumentName
                    );

                    return;
                }
            }

            AppendVisualLog(
                "REMOTE COMMAND RECEIVED | "
                + platformProfileId
                + " | "
                + commandType
            );

            try
            {
                switch (commandType)
                {
                    case "START_BOT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            StartBotClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "STOP_BOT":
                        StopBotClicked(
                            null,
                            null
                        );
                        break;

                    case "CLOSE_ALL":
                    {
                        Account closeAccount =
                            ResolveAccountByName(
                                commandAccount
                            );

                        Instrument closeInstrument =
                            ResolveInstrumentByName(
                                commandInstrument
                            );

                        if (
                            closeAccount == null ||
                            closeInstrument == null
                        )
                        {
                            AppendVisualLog(
                                "REMOTE CLOSE ALL REJECTED"
                                + " | Target "
                                + commandAccount
                                + " / "
                                + commandInstrument
                                + " could not be resolved."
                            );

                            break;
                        }

                        AppendVisualLog(
                            "REMOTE CLOSE ALL TARGET RESOLVED"
                            + " | "
                            + closeAccount.Name
                            + " / "
                            + closeInstrument.FullName
                        );

                        CloseAllForContext(
                            closeAccount,
                            closeInstrument,
                            "PLATFORM"
                        );

                        break;
                    }

                    case "TEST_LONG":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestLongClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    case "TEST_SHORT":
                        platformRemoteStartContext =
                            true;

                        try
                        {
                            TestShortClicked(
                                null,
                                null
                            );
                        }
                        finally
                        {
                            platformRemoteStartContext =
                                false;
                        }
                        break;

                    default:
                        AppendVisualLog(
                            "REMOTE COMMAND IGNORED | "
                            + commandType
                        );
                        return;
                }

                PublishSharedState();
                PublishPlatformTelemetry();
            }
            catch (Exception ex)
            {
                AppendVisualLog(
                    "REMOTE COMMAND FAILED | "
                    + commandType
                    + " | "
                    + ex.Message
                );
            }
        }

    }
}

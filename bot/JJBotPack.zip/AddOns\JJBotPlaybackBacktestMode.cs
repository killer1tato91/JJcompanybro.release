#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // =====================================================
        // V1.7.25 - PLAYBACK-ONLY BACKTEST MODE
        // =====================================================
        // This mode is automatic and can NEVER activate on SIM/live/funded
        // accounts.  Only NinjaTrader Playback* accounts qualify.
        private bool IsPlaybackBacktestMode()
        {
            return IsPlaybackStrategyClockActive();
        }

        private bool ShouldEnforceOperationalTradeLimits()
        {
            // DEFINITIVE: Playback must mirror production risk/session behavior.
            return true;
        }

        // Called only after an authoritative Playback market event moves
        // materially backwards in time.  This makes rewinding the Playback
        // clock a clean A/B retest instead of inheriting future-state locks.
        private void ResetPlaybackBacktestTransientState(DateTime rewindNy)
        {
            if (!IsPlaybackBacktestMode())
                return;

            // Never fake/clear a real open position.  Playback must be flat
            // before a rewind becomes a clean repeated test.
            if (!IsSelectedInstrumentFlat())
            {
                PrintBotMessage(
                    "PLAYBACK REWIND DETECTED - RESET DEFERRED"
                    + " | NewTime: " + rewindNy.ToString("yyyy-MM-dd HH:mm:ss")
                    + " ET | Reason: POSITION NOT FLAT"
                );
                return;
            }

            lock (executionStateLock)
            {
                // Backtest accounting/administrative state.
                tradesToday = 0;
                asiaTradesToday = 0;
                premarketTradesToday = 0;
                asiaLossPremarketBlockedToday = false;
                amTradesToday = 0;
                middayTradesToday = 0;
                pmTradesToday = 0;

                botDailyGrossPnL = 0;
                botDailyFees = 0;
                botDailyPnL = 0;
                botUnrealizedPnL = 0;
                dailyPeakTotalPnL = 0;
                dailyProtectedProfitFloor = 0;
                dailyProfitFloorArmed = false;
                lastLoggedProtectedProfitFloor = 0;
                persistentDailyLocked = false;
                persistentDailyLockReason = string.Empty;
                dailyTargetProtectionArmed = false;
                lastDailyTargetProtectionStopPrice = 0;
                lastDailyTargetProtectionChangeUtc = DateTime.MinValue;
                riskFlattenSent = false;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                // Signal consumption / re-entry state.
                lastExecutedSignalBar = DateTime.MinValue;
                consumedBullishStructureSetupKey = string.Empty;
                consumedBearishStructureSetupKey = string.Empty;
                consumedBullishStructureConfirmTime = DateTime.MinValue;
                consumedBearishStructureConfirmTime = DateTime.MinValue;
                lastAutomaticTradeExitNy = DateTime.MinValue;
                lastAutomaticTradeExitRangeBarTime = DateTime.MinValue;
                lastAutomaticTradeExitWasBreakeven = false;
                lastAutomaticTradeExitWasLoss = false;
                lastAutomaticTradeExitSide = string.Empty;
                lastReentryBlockLogKey = string.Empty;

                // Fresh momentum / retest state.
                freshMomentumLongTriggerNy = DateTime.MinValue;
                freshMomentumShortTriggerNy = DateTime.MinValue;
                pendingSmartRetestActive = false;
                pendingSmartRetestCreatedNy = DateTime.MinValue;
                pendingSmartRetestExpiresNy = DateTime.MinValue;
                pendingSmartRetestReason = string.Empty;
                pendingSmartRetestStructureSetupKey = string.Empty;
                lastSmartRetestLogKey = string.Empty;
                lastSmartRetestConfirmedLogKey = string.Empty;

                lastRangeSignalLogKey = string.Empty;
                lastRangeBlockedLogKey = string.Empty;
                lastLearningBlockedLogKey = string.Empty;
                lastStartupWarmupBlockLogKey = string.Empty;

                // Opening route may be tested again after rewind.
                openingTradeTakenToday = false;
                lastOpeningContextBlockLogKey = string.Empty;
                lastOpeningAntiChaseOverrideLogKey = string.Empty;
                lastOpeningStabilityBlockLogKey = string.Empty;
                lastOpeningCounterTrendBlockLogKey = string.Empty;
                lastOpeningSameSetupBlockLogKey = string.Empty;

                // Commitment/TTL state must not carry future timestamps back.
                fastOpenCommitmentUntilUtc = DateTime.MinValue;
                exceptionalCommitmentUntilUtc = DateTime.MinValue;
                explosionCommitmentUntilUtc = DateTime.MinValue;
                explosionFlipCooldownUntilUtc = DateTime.MinValue;

                // A very short replay-time warmup prevents an order on the
                // exact rewind callback while still allowing repeated testing.
                automaticEntryWarmupUntilNy = rewindNy.AddSeconds(2);
            }

            // Level 2 state contains future order-book/tape history after a
            // rewind. Clear it and let Playback rebuild from the new point.
            lock (level2Sync)
            {
                level2BidRows.Clear();
                level2AskRows.Clear();
                level2DepthEvents = 0;
                level2BidAdd = 0;
                level2BidRemove = 0;
                level2AskAdd = 0;
                level2AskRemove = 0;
                level2AggBuy = 0;
                level2AggSell = 0;
                level2TapeTrades = 0;
                level2UnknownTrades = 0;
                level2LastTradePrice = 0;
                level2LastBidPrice = 0;
                level2LastAskPrice = 0;
                level2LastCalcUtc = DateTime.MinValue;
                level2LastLogUtc = DateTime.MinValue;
                level2LastStrictReadyUtc = DateTime.MinValue;
                level2LastOpeningContinuityLogUtc = DateTime.MinValue;
                level2BookReady = false;
                level2WarmupCompleted = false;
                level2BidPct = 50.0;
                level2AskPct = 50.0;
                level2TopBidVolume = 0;
                level2TopAskVolume = 0;
                level2Bias = "NEUTRAL";
                level2StackPull = "BALANCED";
                level2Absorption = "NONE";
                level2AbsorptionCandidateSide = "NONE";
                level2AbsorptionCandidateUtc = DateTime.MinValue;
                level2AbsorptionCandidateStartPrice = 0;
                level2AbsorptionCandidateExtremePrice = 0;
                level2AbsorptionCandidateHits = 0;
                level2ConfirmedAbsorptionSide = "NONE";
                level2ConfirmedAbsorptionUtc = DateTime.MinValue;
                level2ConfirmedAbsorptionExtremePrice = 0;
                level2LastConfirmedAbsorptionMemorySide = "NONE";
                level2LastConfirmedAbsorptionMemoryUtc = DateTime.MinValue;
                level2LastConfirmedAbsorptionMemoryExtremePrice = 0;
                level2LastBuyConfirmedAbsorptionUtc = DateTime.MinValue;
                level2LastSellConfirmedAbsorptionUtc = DateTime.MinValue;
                level2TapeDelta = 0;
                level2TapeBias = "NEUTRAL";
                level2Confluence = "NEUTRAL";
                level2LongPersistence = 0;
                level2ShortPersistence = 0;
                level2NeutralPersistence = 0;
            }

            lastReplayLevel2CaptureNy = DateTime.MinValue;
            lastReplayCapturedEventKey = string.Empty;

            PrintBotMessage(
                "PLAYBACK BACKTEST REWIND RESET"
                + " | NewTime: " + rewindNy.ToString("yyyy-MM-dd HH:mm:ss")
                + " ET | Trades/DailyLocks/Reentry/ConsumedSignals/L2 cleared"
                + " | Signal logic unchanged"
            );
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT POSITION RECOVERY
    // Stage 11 structural extraction only.
    //
    // Existing delayed recovery retry, live-position adoption,
    // SL/TP recovery, trailing-stage reconstruction and
    // post-restart synchronization behavior are unchanged.
    //
    // No retry timing, max attempts, prices, quantities,
    // order scanning, or protection logic was modified.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.14R2 - delayed Position Recovery.
        // NinjaTrader can expose Account.Positions a short time after START,
        // especially after an app/PC restart. During this short recovery
        // window automatic entries are blocked until the position state has
        // had time to synchronize.
        private DispatcherTimer positionRecoveryTimer;
        private int positionRecoveryAttempts;
        private bool positionRecoveryPending;
        private const int PositionRecoveryMaxAttempts = 8;
        private const int PositionRecoveryRetryMilliseconds = 1000;


        private void StartPositionRecoveryRetry()
        {
            StopPositionRecoveryRetry();

            positionRecoveryAttempts = 0;
            positionRecoveryPending = true;

            positionRecoveryTimer =
                new DispatcherTimer(
                    DispatcherPriority.Normal,
                    Dispatcher
                );

            positionRecoveryTimer.Interval =
                TimeSpan.FromMilliseconds(
                    PositionRecoveryRetryMilliseconds
                );

            positionRecoveryTimer.Tick +=
                PositionRecoveryTimerTick;

            positionRecoveryTimer.Start();

            PrintBotMessage(
                "POSITION RECOVERY WAIT"
                + " | NinjaTrader position sync retry armed"
                + " | MaxAttempts: "
                + PositionRecoveryMaxAttempts
                + " | Every: "
                + PositionRecoveryRetryMilliseconds
                + "ms"
            );
        }
        private void StopPositionRecoveryRetry()
        {
            DispatcherTimer timer =
                positionRecoveryTimer;

            positionRecoveryTimer = null;
            positionRecoveryPending = false;
            positionRecoveryAttempts = 0;

            if (timer == null)
                return;

            try
            {
                timer.Stop();
                timer.Tick -=
                    PositionRecoveryTimerTick;
            }
            catch
            {
            }
        }
        private void PositionRecoveryTimerTick(
            object sender,
            EventArgs e)
        {
            if (!botRunning)
            {
                StopPositionRecoveryRetry();
                return;
            }

            positionRecoveryAttempts++;

            MarketPosition scanSide =
                MarketPosition.Flat;

            int scanQty = 0;
            double scanAverage = 0;

            bool scanFlat = true;

            try
            {
                scanFlat =
                    TryGetSelectedInstrumentPosition(
                        out scanSide,
                        out scanQty,
                        out scanAverage
                    );
            }
            catch
            {
                scanFlat = true;
            }

            PrintBotMessage(
                "POSITION RECOVERY SCAN"
                + " | Attempt: "
                + positionRecoveryAttempts
                + "/"
                + PositionRecoveryMaxAttempts
                + " | Flat: "
                + scanFlat
                + " | Side: "
                + scanSide
                + " | Qty: "
                + scanQty
                + " | Avg: "
                + (
                    scanAverage > 0
                        ? FormatPrice(scanAverage)
                        : "0"
                  )
            );

            if (!scanFlat)
            {
                bool recovered =
                    TryRecoverExistingPosition();

                if (recovered)
                {
                    positionRecoveryPending = false;

                    PrintBotMessage(
                        "POSITION RECOVERY COMPLETE"
                        + " | Delayed account sync adopted successfully"
                        + " | Attempt: "
                        + positionRecoveryAttempts
                    );

                    StopPositionRecoveryRetry();
                    PublishSharedState();
                    return;
                }
            }

            if (
                positionRecoveryAttempts >=
                    PositionRecoveryMaxAttempts
            )
            {
                PrintBotMessage(
                    "POSITION RECOVERY WINDOW COMPLETE"
                    + " | No adoptable position found after "
                    + PositionRecoveryMaxAttempts
                    + " attempts."
                );

                StopPositionRecoveryRetry();
            }
        }
        private bool TryRecoverExistingPosition()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(account)
            )
            {
                return false;
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (
                isFlat ||
                actualSide == MarketPosition.Flat ||
                actualQty <= 0 ||
                actualAverage <= 0
            )
            {
                return false;
            }

            PrintBotMessage(
                "EXISTING POSITION DETECTED"
                + " | Account: " + account.Name
                + " | Instrument: " + instrument.FullName
                + " | Side: " + actualSide
                + " | Qty: " + actualQty
                + " | Avg: " + FormatPrice(actualAverage)
            );

            Order recoveredStop = null;
            Order recoveredTarget = null;

            string expectedStopName =
                GetProfileOrderName("JJ_STOP");

            string expectedTargetName =
                GetProfileOrderName("JJ_TARGET");

            try
            {
                lock (account.Orders)
                {
                    foreach (Order order in account.Orders)
                    {
                        if (
                            order == null ||
                            order.Instrument == null ||
                            order.Instrument.FullName != instrument.FullName
                        )
                        {
                            continue;
                        }

                        bool activeOrder =
                            order.OrderState == OrderState.Working ||
                            order.OrderState == OrderState.Accepted ||
                            order.OrderState == OrderState.Submitted ||
                            order.OrderState == OrderState.ChangePending ||
                            order.OrderState == OrderState.ChangeSubmitted;

                        if (!activeOrder)
                            continue;

                        string orderName =
                            order.Name ?? string.Empty;

                        if (
                            recoveredStop == null &&
                            string.Equals(
                                orderName,
                                expectedStopName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.StopPrice > 0
                        )
                        {
                            recoveredStop = order;
                            continue;
                        }

                        if (
                            recoveredTarget == null &&
                            string.Equals(
                                orderName,
                                expectedTargetName,
                                StringComparison.OrdinalIgnoreCase
                            ) &&
                            order.LimitPrice > 0
                        )
                        {
                            recoveredTarget = order;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "POSITION RECOVERY ORDER SCAN ERROR: "
                    + ex.Message
                );
            }

            double tickSize =
                instrument.MasterInstrument != null
                    ? instrument.MasterInstrument.TickSize
                    : 0;

            int recoveredStage = 0;
            double recoveredStopPrice =
                recoveredStop != null
                    ? recoveredStop.StopPrice
                    : 0;

            double recoveredTargetPrice =
                recoveredTarget != null
                    ? recoveredTarget.LimitPrice
                    : 0;

            if (
                tickSize > 0 &&
                recoveredStopPrice > 0
            )
            {
                double protectedTicks =
                    actualSide == MarketPosition.Long
                        ? (
                            recoveredStopPrice -
                            actualAverage
                          ) / tickSize
                        : (
                            actualAverage -
                            recoveredStopPrice
                          ) / tickSize;

                // Derive the minimum already-achieved protection stage
                // from the live stop. This is intentionally conservative:
                // a restart may resume at the same/better stop, never worse.
                if (protectedTicks >= MomentumLock2ProfitTicks)
                    recoveredStage = 3;
                else if (protectedTicks >= MomentumLockProfitTicks)
                    recoveredStage = 2;
                else if (protectedTicks >= 0)
                    recoveredStage = 1;
            }

            lock (executionStateLock)
            {
                entryPending = false;
                pendingEntryRequestedQuantity = 0;
                entryOrder = null;

                entryFillPrice = actualAverage;
                entryQuantity = actualQty;
                entryMarketPosition = actualSide;

                stopOrder = recoveredStop;
                targetOrder = recoveredTarget;

                activeStopPrice = recoveredStopPrice;
                activeTargetPrice = recoveredTargetPrice;

                if (
                    tickSize > 0 &&
                    recoveredTargetPrice > 0
                )
                {
                    double targetTicks =
                        actualSide == MarketPosition.Long
                            ? (
                                recoveredTargetPrice -
                                actualAverage
                              ) / tickSize
                            : (
                                actualAverage -
                                recoveredTargetPrice
                              ) / tickSize;

                    activeEffectiveTargetTicks =
                        Math.Max(
                            1,
                            (int)Math.Round(targetTicks)
                        );
                }
                else
                {
                    activeEffectiveTargetTicks =
                        activeTargetTicks;
                }

                activeExitQuantity = 0;
                activeExitGrossPnL = 0;
                activeExitCommission = 0;

                // Every current bot entry is protected by the momentum
                // capital-protection engine. Recovery resumes that engine.
                activeEntryUsesMomentumTrailing = true;
                activeStrongMomentumProtection = false;
                activeBreakEvenTriggerTicks =
                    MomentumBreakEvenTriggerTicks;

                momentumTrailingStage =
                    recoveredStage;

                lastMomentumTrailingStopPrice =
                    recoveredStopPrice;

                lastMomentumTrailingChangeUtc =
                    DateTime.MinValue;

                dailyTargetProtectionArmed = false;
                lastDailyTargetProtectionStopPrice = 0;
                lastDailyTargetProtectionChangeUtc =
                    DateTime.MinValue;

                executionStatus =
                    recoveredStop != null &&
                    recoveredTarget != null
                        ? "RECOVERED - PROTECTED"
                        : "RECOVERING PROTECTION";
            }

            UpdateExecutionMonitor();

            PrintBotMessage(
                "POSITION ADOPTED"
                + " | Side: " + actualSide
                + " | Qty: " + actualQty
                + " | Entry: " + FormatPrice(actualAverage)
                + " | Existing SL: "
                + (
                    recoveredStopPrice > 0
                        ? FormatPrice(recoveredStopPrice)
                        : "NONE"
                  )
                + " | Existing TP: "
                + (
                    recoveredTargetPrice > 0
                        ? FormatPrice(recoveredTargetPrice)
                        : "NONE"
                  )
                + " | TrailingStage: "
                + recoveredStage
            );

            if (
                recoveredStop == null &&
                recoveredTarget == null
            )
            {
                PrintBotMessage(
                    "POSITION RECOVERY - NO OCO FOUND"
                    + " | Building a fresh protective bracket"
                    + " for the recovered position."
                );

                SubmitProtectiveBracket(
                    actualAverage,
                    actualQty,
                    actualSide
                );
            }
            else if (
                recoveredStop == null ||
                recoveredTarget == null
            )
            {
                // Never create a second bracket on top of one surviving
                // protective order. That could duplicate exposure or
                // accidentally replace a better live stop.
                PrintBotMessage(
                    "POSITION RECOVERY WARNING - PARTIAL OCO FOUND"
                    + " | Existing SL: "
                    + (
                        recoveredStopPrice > 0
                            ? FormatPrice(recoveredStopPrice)
                            : "NONE"
                      )
                    + " | Existing TP: "
                    + (
                        recoveredTargetPrice > 0
                            ? FormatPrice(recoveredTargetPrice)
                            : "NONE"
                      )
                    + " | No duplicate bracket submitted."
                );
            }

            PrintBotMessage(
                "TRADE PROTECTION RESUMED"
                + " | BE +" + MomentumBreakEvenTriggerTicks + "t"
                + " | LOCK +" + MomentumLockProfitTicks
                + "t @ +" + MomentumLockTriggerTicks + "t"
                + " | LOCK2 +" + MomentumLock2ProfitTicks
                + "t @ +" + MomentumLock2TriggerTicks + "t"
                + " | TRAIL " + MomentumTrailDistanceTicks
                + "t @ +" + MomentumTrailTriggerTicks + "t"
                + " | NEVER-WORSEN ACTIVE"
            );

            return true;
        }

    }
}

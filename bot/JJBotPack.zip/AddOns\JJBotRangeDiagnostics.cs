﻿using System;
using System.Globalization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // DIAGNOSTIC ONLY. No entry, risk, recovery or subscription decisions.
    public sealed class JJRangeFeedDiagnostics
    {
        private readonly object sync = new object();
        private DateTime callbackUtc, calculationUtc, callbackBarTime, calculationBarTime;
        private DateTime closedBarTime, lastAdvanceUtc;
        private long callbacks, calculations;
        private long scoreComputed, scoreReused;
        private double scoreTotalMs, scoreMaxMs;
        private long rangeCompleted;
        private double rangeTotalMs, rangeMaxMs;
        private int callbackBars, calculationBars, longScore, shortScore;
        private const double StaleSeconds = 30.0;

        public void Reset()
        {
            lock (sync)
            {
                callbackUtc = calculationUtc = callbackBarTime = calculationBarTime = DateTime.MinValue;
                closedBarTime = lastAdvanceUtc = DateTime.MinValue;
                callbacks = calculations = 0;
                scoreComputed = scoreReused = 0;
                scoreTotalMs = scoreMaxMs = 0;
                rangeCompleted = 0;
                rangeTotalMs = rangeMaxMs = 0;
                callbackBars = calculationBars = longScore = shortScore = 0;
            }
        }

        public void RecordCallback(DateTime nowUtc, int count, DateTime barTime)
        {
            lock (sync)
            {
                if (callbacks == 0 || callbackBars != count || callbackBarTime != barTime)
                    lastAdvanceUtc = nowUtc;
                callbackUtc = nowUtc;
                callbackBars = count;
                callbackBarTime = barTime;
                callbacks++;
            }
        }

        public void RecordCalculation(DateTime nowUtc, int count, DateTime currentBarTime,
            DateTime closedTime, int buyScore, int sellScore)
        {
            lock (sync)
            {
                calculationUtc = nowUtc;
                calculationBars = count;
                calculationBarTime = currentBarTime;
                closedBarTime = closedTime;
                longScore = buyScore;
                shortScore = sellScore;
                calculations++;
            }
        }

        public void RecordRangeWork(double elapsedMs)
        {
            lock (sync)
            {
                rangeCompleted++;
                rangeTotalMs += elapsedMs;
                rangeMaxMs = Math.Max(rangeMaxMs, elapsedMs);
            }
        }

        public void RecordScoreWork(bool reused, double elapsedMs)
        {
            lock (sync)
            {
                if (reused) scoreReused++; else scoreComputed++;
                scoreTotalMs += elapsedMs;
                scoreMaxMs = Math.Max(scoreMaxMs, elapsedMs);
            }
        }

        public string State(DateTime nowUtc, bool loaded)
        {
            lock (sync) { return StateLocked(nowUtc, loaded); }
        }

        private string StateLocked(DateTime nowUtc, bool loaded)
        {
            if (!loaded) return "LOADING";
            if (callbacks == 0) return "NO_LIVE_CALLBACK_YET";
            if ((nowUtc - callbackUtc).TotalSeconds > StaleSeconds) return "CALLBACKS_STALE";
            if (calculations == 0 || (nowUtc - calculationUtc).TotalSeconds > StaleSeconds)
                return "CALCULATION_STALE";
            // A quiet market can leave a Range bar's timestamp unchanged.
            // Report the observation without declaring the subscription broken.
            if ((nowUtc - lastAdvanceUtc).TotalSeconds > StaleSeconds)
                return "UPDATING_TIME_UNCHANGED";
            return "UPDATING";
        }

        private static string Age(DateTime nowUtc, DateTime value)
        {
            return value == DateTime.MinValue ? "NEVER"
                : (nowUtc - value).TotalSeconds.ToString("0.0", CultureInfo.InvariantCulture) + "s";
        }

        private static string Stamp(DateTime value)
        {
            return value == DateTime.MinValue ? "NONE"
                : value.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        }

        public string Describe(DateTime nowUtc, bool loaded)
        {
            lock (sync)
            {
                return "RANGE DIAGNOSTIC | Loaded: " + (loaded ? "YES" : "NO")
                    + " | Feed: " + StateLocked(nowUtc, loaded)
                    + " | Callbacks: " + callbacks + " | CallbackAge: " + Age(nowUtc, callbackUtc)
                    + " | CallbackBars: " + callbackBars + " | CallbackBar: " + Stamp(callbackBarTime)
                    + " | Calculations: " + calculations + " | CalcAge: " + Age(nowUtc, calculationUtc)
                    + " | CalcBars: " + calculationBars + " | CalcBar: " + Stamp(calculationBarTime)
                    + " | ClosedBar: " + Stamp(closedBarTime)
                    + " | BarAdvanceAge: " + Age(nowUtc, lastAdvanceUtc)
                    + " | Scores L/S: " + longScore + "/" + shortScore
                    + " | CallbackAvgMs: " + (rangeTotalMs / Math.Max(1, rangeCompleted)).ToString("0.000", CultureInfo.InvariantCulture)
                    + " | CallbackMaxMs: " + rangeMaxMs.ToString("0.000", CultureInfo.InvariantCulture)
                    + " | ScoreComputed: " + scoreComputed + " | ScoreReused: " + scoreReused
                    + " | ScoreAvgMs: " + (scoreTotalMs / Math.Max(1, scoreComputed + scoreReused)).ToString("0.000", CultureInfo.InvariantCulture)
                    + " | ScoreMaxMs: " + scoreMaxMs.ToString("0.000", CultureInfo.InvariantCulture)
                    + " | BarTimes: NinjaTrader raw | Ages: UTC clock | Observe only";
            }
        }

        public static string RoleStatus(bool warm, bool canReclaim, int remainingSeconds, string l2Leader)
        {
            string status = !warm ? "WARMING UP | Warmup: " + Math.Max(0, remainingSeconds) + "s remaining"
                : "ROLES SHARED | Warmup: COMPLETE";
            string reclaim = !warm ? "WAIT_WARMUP" : canReclaim ? "ALLOWED" : "OPEN_WINDOW_HOLD";
            return "MARKET BRAIN SERVICE | " + status + " | Reclaim: " + reclaim
                + " | L2 leader: " + l2Leader
                + " | Another member holds one or more roles; not an entry decision";
        }
    }

    public partial class JJBotWindow
    {
        private readonly JJRangeFeedDiagnostics rangeFeedDiagnostic = new JJRangeFeedDiagnostics();
        private DateTime lastRangeDiagnosticReportUtc = DateTime.MinValue;

        private void ReportRangeFeedDiagnostic(DateTime nowUtc)
        {
            if (lastRangeDiagnosticReportUtc != DateTime.MinValue
                && (nowUtc - lastRangeDiagnosticReportUtc).TotalSeconds < 30) return;
            lastRangeDiagnosticReportUtc = nowUtc;
            PrintBotMessage(rangeFeedDiagnostic.Describe(nowUtc, rangeBarsReady));
        }
    }
}

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    // The existing EMA cache also assumes older closed history is immutable.
    // Signal evaluations always bypass reuse, even when the key is unchanged.
    internal struct JJRangeMomentumKey
    {
        private readonly object series;
        private readonly int count, index;
        private readonly DateTime first, stamp;
        private readonly double open, high, low, close, volume;

        public JJRangeMomentumKey(object series, int count, int index, DateTime first,
            DateTime stamp, double open, double high, double low, double close, double volume)
        {
            this.series = series; this.count = count; this.index = index;
            this.first = first; this.stamp = stamp; this.open = open;
            this.high = high; this.low = low; this.close = close; this.volume = volume;
        }

        public bool SameAs(JJRangeMomentumKey other)
        {
            return object.ReferenceEquals(series, other.series) && count == other.count
                && index == other.index && first == other.first && stamp == other.stamp
                && open == other.open && high == other.high && low == other.low
                && close == other.close && volume == other.volume;
        }
    }

    internal struct JJRangeMomentumValues
    {
        public double Ema, RangeRatio, VolumeRatio, BodyRatio, EmaSlope;
        public int LongScore, ShortScore;
        public bool HighBreakout, LowBreakout;
    }

    internal sealed class JJRangeMomentumCache
    {
        private readonly object sync = new object();
        private bool valid;
        private JJRangeMomentumKey key;
        private JJRangeMomentumValues values;

        public bool TryGet(JJRangeMomentumKey current, bool signalEvaluation,
            out JJRangeMomentumValues result)
        {
            lock (sync)
            {
                result = values;
                return valid && !signalEvaluation && key.SameAs(current);
            }
        }

        public void Store(JJRangeMomentumKey current, JJRangeMomentumValues result)
        {
            lock (sync) { key = current; values = result; valid = true; }
        }

        public void Reset()
        {
            lock (sync) { valid = false; key = default(JJRangeMomentumKey); }
        }
    }

    public partial class JJBotWindow
    {
        private readonly JJRangeMomentumCache rangeMomentumCache = new JJRangeMomentumCache();
    }
}

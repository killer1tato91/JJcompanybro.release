using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class JJBotRunIdentity
    {
        public const string Build = "V1.7.88-20261017";
        public static string EnvironmentTag(string account)
        {
            string name = account ?? string.Empty;
            if (name.StartsWith("Playback", StringComparison.OrdinalIgnoreCase)) return "PLAYBACK";
            if (name.StartsWith("Sim", StringComparison.OrdinalIgnoreCase)) return "SIM";
            return "ACCOUNT"; // A name is not proof of the broker's live/demo status.
        }
    }

    // Reliability patch 2026-10-12. These helpers have no account/order access.
    internal sealed class JJBotRollingTape
    {
        private struct Sample { public DateTime Time; public double Buy, Sell; }
        private readonly Queue<Sample> samples = new Queue<Sample>();
        private DateTime last = DateTime.MinValue;
        public double Buy, Sell;
        public long Trades, Unknown;
        public void Reset()
        {
            samples.Clear(); Buy = Sell = 0; Trades = Unknown = 0; last = DateTime.MinValue;
        }
        public void Add(DateTime now, double buy, double sell)
        {
            if (last != DateTime.MinValue && now < last)
            {
                // Ignore small out-of-order ticks; reset for a replay/session rewind.
                if ((last - now).TotalSeconds <= 2) return;
                Reset();
            }
            last = now;
            buy = Math.Max(0, buy); sell = Math.Max(0, sell);
            samples.Enqueue(new Sample { Time = now, Buy = buy, Sell = sell });
            Buy += buy; Sell += sell; Trades++;
            if (buy == 0 && sell == 0) Unknown++;
            while (samples.Count > 0 && (now - samples.Peek().Time).TotalSeconds >= 5)
            {
                Sample old = samples.Dequeue(); Buy -= old.Buy; Sell -= old.Sell; Trades--;
                if (old.Buy == 0 && old.Sell == 0) Unknown--;
            }
            Buy = Math.Max(0, Buy); Sell = Math.Max(0, Sell);
        }
        public void Advance(DateTime now)
        {
            if (last == DateTime.MinValue || now < last) return;
            while (samples.Count > 0 && (now - samples.Peek().Time).TotalSeconds >= 5)
            {
                Sample old = samples.Dequeue(); Buy -= old.Buy; Sell -= old.Sell; Trades--;
                if (old.Buy == 0 && old.Sell == 0) Unknown--;
            }
            Buy = Math.Max(0, Buy); Sell = Math.Max(0, Sell);
        }
    }

    internal sealed class JJBotAbsorptionEvidence
    {
        private bool buyControl;
        private double lastCumulative;
        public bool Active;
        public double Size, Extreme;
        public void Begin(bool isBuyControl, double price, double seedSize, double cumulative)
        {
            Active = true; buyControl = isBuyControl; Extreme = price;
            Size = Math.Max(0, seedSize); lastCumulative = cumulative;
        }
        public void Observe(double price, double cumulative)
        {
            if (!Active) return;
            if (price > 0) Extreme = buyControl ? Math.Min(Extreme, price) : Math.Max(Extreme, price);
            Size += Math.Max(0, cumulative - lastCumulative);
            lastCumulative = cumulative;
        }
        public void Reset() { Active = false; Size = Extreme = lastCumulative = 0; }
    }

    internal sealed class JJBotOpenBellTape
    {
        public DateTime SessionDate = DateTime.MinValue;
        private DateTime last = DateTime.MinValue;
        private int lastBucket = -1;
        public double Delta;
        public int Snapshots;
        public void Reset() { SessionDate = last = DateTime.MinValue; Delta = 0; Snapshots = 0; lastBucket = -1; }
        public void Add(DateTime now, double delta, bool ready)
        {
            if (now.Date != SessionDate || (last != DateTime.MinValue && (last - now).TotalSeconds > 2))
            {
                Reset(); SessionDate = now.Date;
            }
            if (last != DateTime.MinValue && now < last) return;
            last = now;
            TimeSpan tod = now.TimeOfDay;
            if (!ready || tod < new TimeSpan(9,25,0) || tod >= new TimeSpan(9,29,58)) return;
            Delta += delta;
            int bucket = (int)(tod - new TimeSpan(9,25,0)).TotalSeconds / 5;
            if (bucket != lastBucket) { Snapshots++; lastBucket = bucket; }
        }
    }

    internal static class JJBotProtectionMath
    {
        public static double NearTargetLockTicks(double peakTicks, double targetTicks, double gapFraction)
        {
            if (double.IsNaN(peakTicks) || double.IsNaN(targetTicks) || double.IsInfinity(targetTicks)
                || targetTicks <= 0 || peakTicks < 0.90 * targetTicks) return 0;
            return Math.Max(0, peakTicks - Math.Max(1, targetTicks * gapFraction));
        }
    }
}

// JJBotRemoteMessages.cs (2026-10-31): renamed from JJRemoteMessages.cs so the bot update ships it to every user
// (the app updater only accepts JJBot*/JJCompanyBro*/JJTrade* file names). Code unchanged.
// JJRemoteMessages - V2 (2026-10-31)
// Sends NinjaTrader pop-up messages (NTMessageBox) to the JJ app / APK and lets the user
// answer them remotely. V2: NinjaTrader shows each message box on its OWN UI thread, so every
// read/press now runs on that window's Dispatcher (V1 read them from the main thread, which
// threw and nothing was sent). Errors are written to JJBotData\nt_remote_errors.log.
//   NinjaTrader 8\JJBotData\nt_messages.json  <- written here (read by the JJ desktop bridge)
//   NinjaTrader 8\JJBotData\nt_replies.txt    -> "id|button" lines written by the desktop bridge
// It never places, changes or cancels orders.
#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJRemoteMessages : AddOnBase
    {
        private class Item
        {
            public string Id;
            public DateTime TimeUtc;
            public string Title = "";
            public string Text = "";
            public List<string> Buttons = new List<string>();
            public Window Window;
            public bool Open = true;
            public string Result = "";
        }

        private static readonly object sync = new object();
        private static readonly List<Item> items = new List<Item>();
        private static readonly HashSet<string> loggedTypes = new HashSet<string>();
        private static System.Threading.Timer pollTimer;
        private static long replyOffset = -1;
        private static bool dirty = true;

        private static string Dir { get { return Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "JJBotData"); } }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJRemoteMessages";
                Description = "Envia los mensajes de NinjaTrader a la app JJ y permite responderlos desde la APK.";
            }
            else if (State == State.Configure)
            {
                lock (sync)
                {
                    if (pollTimer == null)
                        pollTimer = new System.Threading.Timer(Poll, null, 2000, 2000);
                }
            }
            else if (State == State.Terminated)
            {
                lock (sync)
                {
                    if (pollTimer != null) { pollTimer.Dispose(); pollTimer = null; }
                }
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            if (window == null) return;
            lock (sync)
            {
                if (pollTimer == null)
                    pollTimer = new System.Threading.Timer(Poll, null, 2000, 2000);
            }
            try
            {
                Dispatcher dispatcher = window.Dispatcher;
                if (dispatcher == null || dispatcher.CheckAccess()) Capture(window, 0);
                else dispatcher.InvokeAsync(() => Capture(window, 0));
            }
            catch (Exception ex) { Err("OnWindowCreated", ex); }
        }

        private static void Err(string where, Exception ex)
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.AppendAllText(Path.Combine(Dir, "nt_remote_errors.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + " | " + where + " | " + ex.GetType().Name + ": " + ex.Message + Environment.NewLine);
            }
            catch { }
        }

        // Runs on the window's own UI thread.
        private static void Capture(Window window, int attempt)
        {
            try
            {
                string type = window.GetType().FullName ?? "?";
                bool newType;
                lock (sync) newType = loggedTypes.Add(type);
                if (newType)
                {
                    Directory.CreateDirectory(Dir);
                    File.AppendAllText(Path.Combine(Dir, "nt_window_types.log"),
                        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + " | " + type + " | " + (window.Title ?? "") + Environment.NewLine);
                }
                if (type.IndexOf("MessageBox", StringComparison.OrdinalIgnoreCase) < 0 &&
                    type.IndexOf("NTMessage", StringComparison.OrdinalIgnoreCase) < 0)
                    return;

                // JJ_NT_MESSAGES_SKIP_SHUTDOWN_V1 (2026-10-31): the "Save Workspace?" box appears when the
                // user closes NinjaTrader at the PC; forwarding it made a push/bell entry every close.
                string jjTitle = window.Title ?? "";
                if (jjTitle.IndexOf("Save Workspace", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    jjTitle.IndexOf("Guardar espacio", StringComparison.OrdinalIgnoreCase) >= 0)
                    return;

                Item item;
                lock (sync)
                {
                    item = items.FirstOrDefault(i => object.ReferenceEquals(i.Window, window));
                    if (item == null)
                    {
                        item = new Item { Id = DateTime.UtcNow.Ticks.ToString(CultureInfo.InvariantCulture), TimeUtc = DateTime.UtcNow, Window = window };
                        items.Add(item);
                        if (items.Count > 40) items.RemoveRange(0, items.Count - 40);
                        Item captured = item;
                        window.Closed += delegate
                        {
                            lock (sync)
                            {
                                captured.Open = false;
                                if (string.IsNullOrEmpty(captured.Result)) captured.Result = "Cerrado en la PC";
                                captured.Window = null;
                                dirty = true;
                            }
                        };
                    }
                }

                var texts = new List<string>();
                var buttons = new List<string>();
                Walk(window, texts, buttons, 0);
                string text = string.Join("\n", texts.Where(t => !string.IsNullOrWhiteSpace(t)).Distinct().ToArray());
                if (text.Length > 1500) text = text.Substring(0, 1500);
                lock (sync)
                {
                    item.Title = window.Title ?? "";
                    item.Text = text;
                    item.Buttons = buttons.Distinct().ToList();
                    dirty = true;
                }

                // The visual tree may not be built yet when the window is created: read again shortly.
                if ((text.Length == 0 || buttons.Count == 0) && attempt < 5)
                {
                    var retry = new DispatcherTimer(DispatcherPriority.Background, window.Dispatcher) { Interval = TimeSpan.FromMilliseconds(400) };
                    retry.Tick += delegate { retry.Stop(); Capture(window, attempt + 1); };
                    retry.Start();
                }
                WriteMessagesIfDirty();
            }
            catch (Exception ex) { Err("Capture", ex); }
        }

        private static void Walk(DependencyObject node, List<string> texts, List<string> buttons, int depth)
        {
            if (node == null || depth > 40) return;
            var button = node as ButtonBase;
            if (button != null)
            {
                string label = Label(button.Content);
                if (!string.IsNullOrEmpty(label)) buttons.Add(label);
                return;
            }
            var block = node as TextBlock;
            if (block != null && !string.IsNullOrWhiteSpace(block.Text)) texts.Add(block.Text.Trim());
            var box = node as TextBox;
            if (box != null && !string.IsNullOrWhiteSpace(box.Text)) texts.Add(box.Text.Trim());
            int count = VisualTreeHelper.GetChildrenCount(node);
            for (int i = 0; i < count; i++) Walk(VisualTreeHelper.GetChild(node, i), texts, buttons, depth + 1);
        }

        private static string Label(object content)
        {
            if (content == null) return "";
            var block = content as TextBlock;
            string text = block != null ? block.Text : content as string;
            return (text ?? "").Replace("_", "").Trim();
        }

        private static ButtonBase FindButton(DependencyObject node, string label, int depth)
        {
            if (node == null || depth > 40) return null;
            var button = node as ButtonBase;
            if (button != null && string.Equals(Label(button.Content), label, StringComparison.OrdinalIgnoreCase)) return button;
            int count = VisualTreeHelper.GetChildrenCount(node);
            for (int i = 0; i < count; i++)
            {
                var found = FindButton(VisualTreeHelper.GetChild(node, i), label, depth + 1);
                if (found != null) return found;
            }
            return null;
        }

        // Background thread: replies + file output. Never touches windows directly.
        private static void Poll(object state)
        {
            try { ReadReplies(); } catch (Exception ex) { Err("ReadReplies", ex); }
            try { WriteMessagesIfDirty(); } catch (Exception ex) { Err("WriteMessages", ex); }
        }

        private static void ReadReplies()
        {
            string file = Path.Combine(Dir, "nt_replies.txt");
            if (!File.Exists(file)) return;
            string all = File.ReadAllText(file);
            if (replyOffset < 0 || replyOffset > all.Length) replyOffset = all.Length; // ignore answers older than this session
            if (replyOffset >= all.Length) return;
            string fresh = all.Substring((int)replyOffset);
            int lastNewLine = fresh.LastIndexOf('\n');
            if (lastNewLine < 0) return;
            replyOffset += lastNewLine + 1;
            foreach (string line in fresh.Substring(0, lastNewLine).Split('\n'))
            {
                string[] parts = line.Trim().Split('|');
                if (parts.Length < 2) continue;
                Item item;
                lock (sync) item = items.FirstOrDefault(i => i.Id == parts[0] && i.Open && i.Window != null);
                if (item == null) continue;
                Window window = item.Window;
                string label = parts[1];
                window.Dispatcher.InvokeAsync(() =>
                {
                    try
                    {
                        ButtonBase button = FindButton(window, label, 0);
                        if (button != null)
                        {
                            lock (sync) { item.Result = "Respondido desde la app: " + label; dirty = true; }
                            button.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                        }
                        if (button == null || window.IsVisible)
                        {
                            // Message boxes close with DialogResult; fall back to closing the window.
                            lock (sync) { if (string.IsNullOrEmpty(item.Result)) item.Result = "Cerrado desde la app"; dirty = true; }
                            window.Close();
                        }
                    }
                    catch (Exception ex) { Err("PressButton", ex); }
                });
            }
        }

        private static string J(string value)
        {
            var sb = new StringBuilder();
            foreach (char c in value ?? "")
            {
                if (c == '"' || c == '\\') { sb.Append('\\'); sb.Append(c); }
                else if (c == '\n') sb.Append("\\n");
                else if (c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static void WriteMessagesIfDirty()
        {
            string json;
            lock (sync)
            {
                if (!dirty) return;
                dirty = false;
                var sb = new StringBuilder("[");
                bool first = true;
                foreach (Item item in items.OrderByDescending(i => i.Open).ThenByDescending(i => i.TimeUtc).Take(20))
                {
                    if (!first) sb.Append(',');
                    first = false;
                    sb.Append("{\"id\":\"").Append(J(item.Id)).Append("\",\"time\":\"").Append(item.TimeUtc.ToString("o", CultureInfo.InvariantCulture))
                      .Append("\",\"title\":\"").Append(J(item.Title)).Append("\",\"text\":\"").Append(J(item.Text))
                      .Append("\",\"open\":").Append(item.Open ? "true" : "false")
                      .Append(",\"result\":\"").Append(J(item.Result)).Append("\",\"buttons\":[");
                    for (int b = 0; b < item.Buttons.Count; b++) { if (b > 0) sb.Append(','); sb.Append('"').Append(J(item.Buttons[b])).Append('"'); }
                    sb.Append("]}");
                }
                sb.Append(']');
                json = sb.ToString();
            }
            Directory.CreateDirectory(Dir);
            string target = Path.Combine(Dir, "nt_messages.json");
            string temp = target + ".tmp";
            File.WriteAllText(temp, json);
            if (File.Exists(target)) File.Replace(temp, target, null); else File.Move(temp, target);
        }
    }
}

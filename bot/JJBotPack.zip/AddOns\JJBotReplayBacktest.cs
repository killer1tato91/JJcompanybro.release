﻿#region Using declarations
using System;
using System.Globalization;
using System.IO;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // =====================================================
        // V1.7.13 - FULL REPLAY EVENT RECORDER
        // =====================================================
        // Central capture now happens at AppendVisualLog, not only
        // PrintBotMessage. This allows accelerated Playback to preserve the
        // complete decision trail needed to explain both entries and no-trades.
        private readonly object replayBacktestSync = new object();
        private string replayBacktestFilePath = string.Empty;
        private bool replayBacktestHeaderWritten = false;
        private DateTime lastReplayLevel2CaptureNy = DateTime.MinValue;
        private string lastReplayCapturedEventKey = string.Empty;

        private bool IsReplayBacktestEvent(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return false;

            string[] prefixes = new string[]
            {
                // Replay/session clock.
                "PLAYBACK CLOCK WAITING",
                "PLAYBACK CLOCK SYNCED",
                "NEW NY TRADING SESSION",
                "TRADING SESSION STATE RESTORED",
                "NEW TRADING SESSION STATE CREATED",

                // Context / candidate formation.
                "PREMARKET CONTEXT",
                "OPENING MAP",
                "OPENING ",
                "FAST OPEN",
                "OPENING FAST PATH",
                "MARKET REGIME",
                "AUTO DIRECTION",
                "RANGE MOMENTUM 20T",
                "DECISION |",
                "SETUP QUALITY",
                "MOVE PHASE",
                "EXPLOSION EDGE",
                "SMART RETEST",
                "WAIT PULLBACK",
                "ENTRY LOCATION",

                // 20PT / final authority.
                "20PT OPPORTUNITY",
                "20PT QUALITY",
                "FINAL ENTRY AUTHORITY",
                "ENTRY BLOCKED -",
                "OPENING FAST PATH BLOCKED -",
                "LEARNING BLOCK",
                "FINAL LEARNING",

                // Execution / protection / exit.
                "SIM ENTRY SUBMITTED",
                "LIVE ENTRY SUBMITTED",
                "ENTRY SUBMITTED",
                "ENTRY FILL COMPLETE",
                "OCO BRACKET SUBMITTED",
                "TRADE PROTECTION ARMED",
                "PROTECTION INVARIANT",
                "HARD PROTECTION",
                "DYNAMIC TARGET",
                "STRUCTURE-AWARE TARGET",
                "SESSION TRADE COUNT",
                "EXIT PARTIAL FILL",
                "EXIT COMPLETE",
                "REENTRY REARM",
                "SMART SCALE-IN",
                "PROFIT RETENTION",
                "DAILY LOSS",
                "DAILY TARGET",
                "PROFIT FLOOR",
                "FORCE FLAT",
                "EMERGENCY FLATTEN",

                // V1.7.35 - CORE20 + central signal + safety trail.
                "CORE20",
                "JJ AI CORE",
                "DUPLICATE SIGNAL",
                "CRITICAL",
                "PROTECTIVE",
                "UNEXPECTED",
                "SIM ENTRY",
                "ENTRY FILL",
                "EXIT",
                "STOP ",
                "TARGET "
            };

            foreach (string prefix in prefixes)
            {
                if (message.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            // Keep usable Level 2 snapshots, but sample them so a multi-month
            // accelerated replay does not create millions of redundant rows.
            if (
                message.StartsWith("LEVEL2 CONTEXT", StringComparison.OrdinalIgnoreCase) &&
                message.IndexOf("Ready: YES", StringComparison.OrdinalIgnoreCase) >= 0
            )
            {
                DateTime nowNy = GetCurrentNewYorkTime();

                if (
                    lastReplayLevel2CaptureNy == DateTime.MinValue ||
                    (nowNy - lastReplayLevel2CaptureNy).TotalSeconds >= 5.0 ||
                    (nowNy - lastReplayLevel2CaptureNy).TotalSeconds < 0.0
                )
                {
                    lastReplayLevel2CaptureNy = nowNy;
                    return true;
                }
            }

            return false;
        }

        private string ClassifyReplayBacktestEvent(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return "UNKNOWN";

            if (message.StartsWith("CORE20 ZONE MAP", StringComparison.OrdinalIgnoreCase)) return "CORE20_ZONES";
            if (message.StartsWith("CORE20 OBSERVE", StringComparison.OrdinalIgnoreCase)) return "CORE20_OBSERVE";
            if (message.StartsWith("CORE20 PROFIT RETENTION", StringComparison.OrdinalIgnoreCase)) return "CORE20_RETENTION";
            if (message.StartsWith("CORE20 TRADE CLOSED", StringComparison.OrdinalIgnoreCase)) return "CORE20_CLOSED";
            if (message.StartsWith("CORE20 TIME EXIT", StringComparison.OrdinalIgnoreCase)) return "CORE20_TIME_EXIT";
            if (message.StartsWith("CORE20 ", StringComparison.OrdinalIgnoreCase)) return "CORE20_SIGNAL";
            if (message.StartsWith("JJ AI CORE", StringComparison.OrdinalIgnoreCase)) return "CENTRAL";
            if (message.StartsWith("CRITICAL", StringComparison.OrdinalIgnoreCase)) return "CRITICAL";
            if (message.StartsWith("LEVEL2 CONTEXT", StringComparison.OrdinalIgnoreCase)) return "LEVEL2";
            if (message.StartsWith("MARKET REGIME", StringComparison.OrdinalIgnoreCase)) return "REGIME";
            if (message.StartsWith("AUTO DIRECTION", StringComparison.OrdinalIgnoreCase)) return "DIRECTION";
            if (message.StartsWith("RANGE MOMENTUM 20T", StringComparison.OrdinalIgnoreCase)) return "R20";
            if (message.StartsWith("DECISION |", StringComparison.OrdinalIgnoreCase)) return "DECISION";
            if (message.StartsWith("SETUP QUALITY", StringComparison.OrdinalIgnoreCase)) return "SETUP_QUALITY";
            if (message.StartsWith("20PT OPPORTUNITY", StringComparison.OrdinalIgnoreCase)) return "20PT_OPPORTUNITY";
            if (message.StartsWith("20PT QUALITY", StringComparison.OrdinalIgnoreCase)) return "20PT_QUALITY";
            if (message.StartsWith("FINAL ENTRY AUTHORITY", StringComparison.OrdinalIgnoreCase)) return "FINAL_AUTHORITY";
            if (message.StartsWith("ENTRY BLOCKED -", StringComparison.OrdinalIgnoreCase)) return "ENTRY_BLOCKED";
            if (message.StartsWith("OPENING FAST PATH BLOCKED -", StringComparison.OrdinalIgnoreCase)) return "FAST_OPEN_BLOCKED";
            if (message.StartsWith("FAST OPEN", StringComparison.OrdinalIgnoreCase)) return "FAST_OPEN";
            if (message.StartsWith("OPENING ", StringComparison.OrdinalIgnoreCase)) return "OPENING";
            if (message.StartsWith("PREMARKET CONTEXT", StringComparison.OrdinalIgnoreCase)) return "PREMARKET";
            if (message.StartsWith("SIM ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase) ||
                message.StartsWith("LIVE ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase) ||
                message.StartsWith("ENTRY SUBMITTED", StringComparison.OrdinalIgnoreCase)) return "ENTRY_SUBMITTED";
            if (message.StartsWith("ENTRY FILL COMPLETE", StringComparison.OrdinalIgnoreCase)) return "ENTRY_FILL";
            if (message.StartsWith("OCO BRACKET SUBMITTED", StringComparison.OrdinalIgnoreCase)) return "OCO";
            if (message.StartsWith("EXIT COMPLETE", StringComparison.OrdinalIgnoreCase)) return "EXIT_COMPLETE";
            if (message.StartsWith("EXIT PARTIAL FILL", StringComparison.OrdinalIgnoreCase)) return "EXIT_PARTIAL";
            if (message.StartsWith("PLAYBACK CLOCK", StringComparison.OrdinalIgnoreCase)) return "PLAYBACK_CLOCK";
            return "CONTEXT";
        }

        private string CsvEscapeReplay(string value)
        {
            string v = value ?? string.Empty;
            if (v.IndexOfAny(new char[] { ',', '"', '\r', '\n' }) >= 0)
                return "\"" + v.Replace("\"", "\"\"") + "\"";
            return v;
        }

        private string GetReplayBacktestFilePath()
        {
            if (!string.IsNullOrWhiteSpace(replayBacktestFilePath))
                return replayBacktestFilePath;

            string baseFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "NinjaTrader 8",
                "JJBotData",
                "Backtests"
            );

            Directory.CreateDirectory(baseFolder);

            string instrumentName =
                selectedInstrument == null
                    ? "UNKNOWN"
                    : (selectedInstrument.FullName ?? "UNKNOWN");

            foreach (char invalid in Path.GetInvalidFileNameChars())
                instrumentName = instrumentName.Replace(invalid, '_');

            instrumentName = instrumentName.Replace(' ', '_');

            replayBacktestFilePath = Path.Combine(
                baseFolder,
                "JJReplay_" + instrumentName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
            );

            return replayBacktestFilePath;
        }

        private void CaptureReplayBacktestEvent(string message)
        {
            if (!IsAcceleratedReplayBacktestMode() || !IsReplayBacktestEvent(message))
                return;

            try
            {
                lock (replayBacktestSync)
                {
                    DateTime replayNy = GetCurrentNewYorkTime();

                    // Prevent exact duplicate rows caused by repeated UI refreshes
                    // at the same replay timestamp while preserving distinct events.
                    string eventKey =
                        replayNy.ToString("yyyyMMddHHmmssfff", CultureInfo.InvariantCulture)
                        + "|" + message;

                    if (string.Equals(eventKey, lastReplayCapturedEventKey, StringComparison.Ordinal))
                        return;

                    lastReplayCapturedEventKey = eventKey;

                    string path = GetReplayBacktestFilePath();

                    if (!replayBacktestHeaderWritten && !File.Exists(path))
                    {
                        File.AppendAllText(
                            path,
                            "ReplayTimeNY,Account,Instrument,Profile,EventType,Event\r\n",
                            Encoding.UTF8
                        );
                    }

                    replayBacktestHeaderWritten = true;

                    string account = selectedAccount == null ? string.Empty : (selectedAccount.Name ?? string.Empty);
                    string instrument = selectedInstrument == null ? string.Empty : (selectedInstrument.FullName ?? string.Empty);
                    string eventType = ClassifyReplayBacktestEvent(message);

                    string line =
                        CsvEscapeReplay(replayNy.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture)) + "," +
                        CsvEscapeReplay(account) + "," +
                        CsvEscapeReplay(instrument) + "," +
                        CsvEscapeReplay(platformProfileId ?? string.Empty) + "," +
                        CsvEscapeReplay(eventType) + "," +
                        CsvEscapeReplay(message) + "\r\n";

                    File.AppendAllText(path, line, Encoding.UTF8);
                }
            }
            catch
            {
                // Recorder must never interfere with trading/replay execution.
            }
        }
    }
}

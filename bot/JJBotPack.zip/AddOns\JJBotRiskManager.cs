﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT RISK MANAGER
    //
    // Stage 8 structural extraction only.
    // Existing dollar-risk sizing, daily target protection,
    // persistent daily lock, force-flat, unrealized PnL,
    // profit-floor and daily-loss emergency behavior is unchanged.
    //
    // No thresholds, calculations, order rules, or timing changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private int GetAutoRiskSizedContracts(
            Instrument instrument,
            int configuredContracts,
            int stopTicks,
            double dollarRiskCap,
            out double riskPerContract,
            out double totalConfiguredRisk)
        {
            riskPerContract = 0;
            totalConfiguredRisk = 0;

            if (
                instrument == null ||
                configuredContracts <= 0 ||
                stopTicks <= 0 ||
                dollarRiskCap <= 0
            )
            {
                return 0;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return 0;
            }

            double tickValue =
                tickSize *
                pointValue;

            riskPerContract =
                stopTicks *
                tickValue;

            if (riskPerContract <= 0)
            {
                return 0;
            }

            totalConfiguredRisk =
                configuredContracts *
                riskPerContract;

            int maxContractsByRisk =
                (int)Math.Floor(
                    dollarRiskCap /
                    riskPerContract
                );

            if (maxContractsByRisk <= 0)
            {
                return 0;
            }

            return Math.Min(
                configuredContracts,
                maxContractsByRisk
            );
        }
        private void UpdateDailyTargetProtection(
            double currentPrice)
        {
            // V1.6.26 - DAILY TARGET HARD CLOSE
            //
            // Daily Target now means END OF DAY for this profile:
            // 1) as soon as Realized + Unrealized reaches the configured target,
            // 2) arm the persistent DAILY TARGET lock immediately,
            // 3) disable all trailing ownership through dailyTargetProtectionArmed,
            // 4) use Account.Flatten for the selected instrument,
            // 5) retry at a controlled cadence until the REAL position is flat.
            //
            // Account.Flatten is the same emergency/force-flat primitive already
            // used elsewhere in JJ Bot and handles working orders for the instrument.
            _ = currentPrice;

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                activeDailyTarget <= 0
            )
            {
                return;
            }

            double totalPnL;
            bool alreadyArmed;

            lock (executionStateLock)
            {
                totalPnL =
                    botDailyPnL +
                    botUnrealizedPnL;

                alreadyArmed =
                    dailyTargetProtectionArmed;
            }

            if (
                !alreadyArmed &&
                totalPnL < activeDailyTarget
            )
            {
                return;
            }

            MarketPosition actualSide;
            int actualQty;
            double actualAveragePrice;

            bool actualFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAveragePrice
                );

            bool newlyArmed = false;

            lock (executionStateLock)
            {
                if (!dailyTargetProtectionArmed)
                {
                    double latestTotal =
                        botDailyPnL +
                        botUnrealizedPnL;

                    if (
                        latestTotal <
                            activeDailyTarget
                    )
                    {
                        return;
                    }

                    dailyTargetProtectionArmed =
                        true;

                    SetPersistentDailyLock(
                        "DAILY TARGET"
                    );

                    activeForcedExitReason =
                        "DAILY_TARGET";

                    executionStatus =
                        actualFlat
                            ? "DAILY TARGET"
                            : "DAILY TARGET CLOSING";

                    lastDailyTargetProtectionChangeUtc =
                        DateTime.MinValue;

                    lastDailyTargetProtectionStopPrice =
                        0;

                    newlyArmed = true;

                    totalPnL =
                        latestTotal;
                }
            }

            if (newlyArmed)
            {
                SavePersistentDailyState();
                UpdateExecutionMonitor();

                PrintBotMessage(
                    "DAILY TARGET HIT - CLOSE IMMEDIATE"
                    + " | Total: "
                    + totalPnL.ToString("$0.00")
                    + " | Target: "
                    + activeDailyTarget.ToString("$0.00")
                    + " | Action: FLATTEN + DAILY LOCK"
                );
            }

            if (actualFlat)
            {
                lock (executionStateLock)
                {
                    executionStatus =
                        "DAILY TARGET";
                }

                UpdateExecutionMonitor();
                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (executionStateLock)
            {
                // Re-use the former Daily Target change timestamp as a
                // controlled flatten retry clock. This prevents duplicate
                // Account.Flatten calls on every market-data update.
                if (
                    lastDailyTargetProtectionChangeUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastDailyTargetProtectionChangeUtc
                    ).TotalMilliseconds <
                        1000
                )
                {
                    return;
                }

                lastDailyTargetProtectionChangeUtc =
                    nowUtc;

                executionStatus =
                    "DAILY TARGET CLOSING";
            }

            UpdateExecutionMonitor();

            try
            {
                account.Flatten(
                    new[]
                    {
                        instrument
                    }
                );

                PrintBotMessage(
                    "DAILY TARGET CLOSE SENT"
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                    + " | Instrument: "
                    + instrument.FullName
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    // Allow the next market update to retry immediately.
                    lastDailyTargetProtectionChangeUtc =
                        DateTime.MinValue;
                }

                PrintBotMessage(
                    "DAILY TARGET CLOSE ERROR: "
                    + ex.Message
                );
            }
        }
        private void SetPersistentDailyLock(
            string reason)
        {
            string normalizedReason =
                string.IsNullOrWhiteSpace(reason)
                    ? "UNKNOWN"
                    : reason.Trim().ToUpperInvariant();

            bool changed =
                !persistentDailyLocked ||
                !string.Equals(
                    persistentDailyLockReason,
                    normalizedReason,
                    StringComparison.OrdinalIgnoreCase
                );

            persistentDailyLocked =
                true;

            persistentDailyLockReason =
                normalizedReason;

            SavePersistentDailyState();

            if (changed)
            {
                PrintBotMessage(
                    "DAILY LOCK SET"
                    + " | Reason: "
                    + persistentDailyLockReason
                    + " | Trades: "
                    + tradesToday
                    + " | Gross: "
                    + botDailyGrossPnL.ToString("$0.00")
                    + " | Fees: "
                    + botDailyFees.ToString("$0.00")
                    + " | Net: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Unrealized: "
                    + botUnrealizedPnL.ToString("$0.00")
                    + " | Total: "
                    + (botDailyPnL + botUnrealizedPnL).ToString("$0.00")
                    + " | ProfitFloor: "
                    + (
                        dailyProfitFloorArmed
                            ? dailyProtectedProfitFloor.ToString("$0.00")
                            : "OFF"
                      )
                );
            }
        }
        private void CheckForceFlatTime()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                return;
            }

            DateTime nowNy =
                GetCurrentNewYorkTime();

            // V1.6.14: release prior-session locks/counters exactly when the
            // next CME-style session begins. This runs even though automated
            // entries are still restricted to their configured windows.
            EnsureTradingDay(
                nowNy
            );

            if (
                forceFlatDateNy !=
                    nowNy.Date
            )
            {
                forceFlatDateNy =
                    nowNy.Date;

                forceFlatSentToday =
                    false;
            }

            if (
                premarketForceFlatDateNy !=
                    nowNy.Date
            )
            {
                premarketForceFlatDateNy =
                    nowNy.Date;

                premarketForceFlatSentToday =
                    false;
            }

            // V1.6.8 - close only a position that originated from the
            // premarket engine before the 09:30 cash open. This does NOT
            // create a daily lock and does not affect later AM entries.
            int nowTimeValue =
                ToTimeInt(
                    nowNy
                );

            bool localActivePremarketTrade;

            lock (executionStateLock)
            {
                localActivePremarketTrade =
                    activeTradeIsPremarket &&
                    entryQuantity > 0;
            }

            if (
                localActivePremarketTrade &&
                nowTimeValue >=
                    PremarketForceFlatTime &&
                nowTimeValue <
                    OpeningRangeStart &&
                !premarketForceFlatSentToday
            )
            {
                premarketForceFlatSentToday =
                    true;

                try
                {
                    activeForcedExitReason =
                        "SESSION_FORCE_FLAT";

                    executionStatus =
                        "PREMARKET FORCE FLAT";

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "PREMARKET FORCE FLAT START"
                        + " | "
                        + nowNy.ToString(
                            "HH:mm:ss"
                        )
                        + " ET"
                        + " | Before 09:30 cash open"
                    );

                    selectedAccount.Flatten(
                        new[]
                        {
                            selectedInstrument
                        }
                    );
                }
                catch (Exception ex)
                {
                    premarketForceFlatSentToday =
                        false;

                    PrintBotMessage(
                        "PREMARKET FORCE FLAT ERROR: "
                        + ex.Message
                    );
                }
            }

            // Weekend safety:
            // The 16:25 ET prop-firm force-flat rule must never create
            // a Daily Lock on Saturday or Sunday. Without this guard,
            // simply opening NinjaTrader on a weekend after 16:25 ET
            // creates a brand-new daily state with DailyLocked=true.
            if (
                nowNy.DayOfWeek ==
                    DayOfWeek.Saturday ||
                nowNy.DayOfWeek ==
                    DayOfWeek.Sunday
            )
            {
                return;
            }

            // The FORCE FLAT lock belongs only to the closing portion of
            // the current session. At 18:00 ET a new session has started, so
            // never recreate the old 16:25 lock after the session reset.
            if (
                nowTimeValue < ForceFlatTimeNy ||
                nowTimeValue >= TradingSessionResetTimeNy
            )
            {
                return;
            }

            // No new entries after the force-flat time on trading weekdays.
            SetPersistentDailyLock(
                "FORCE FLAT 16:25 ET"
            );

            MarketPosition actualSide;
            int actualQty;
            double actualAverage;

            bool isFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAverage
                );

            if (isFlat)
            {
                if (!forceFlatSentToday)
                {
                    forceFlatSentToday =
                        true;

                    executionStatus =
                        "FORCE FLAT - FLAT";

                    UpdateExecutionMonitor();

                    PrintBotMessage(
                        "FORCE FLAT CHECK"
                        + " | "
                        + nowNy.ToString("HH:mm:ss")
                        + " ET"
                        + " | Position already FLAT."
                    );
                }

                return;
            }

            if (forceFlatSentToday)
                return;

            forceFlatSentToday =
                true;

            try
            {
                activeForcedExitReason =
                    "SESSION_FORCE_FLAT";

                executionStatus =
                    "FORCE FLAT";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "FORCE FLAT START"
                    + " | "
                    + nowNy.ToString("HH:mm:ss")
                    + " ET"
                    + " | Position: "
                    + actualSide
                    + " "
                    + actualQty
                );

                selectedAccount.Flatten(
                    new[]
                    {
                        selectedInstrument
                    }
                );

                PrintBotMessage(
                    "FORCE FLAT SENT"
                    + " | Account.Flatten"
                    + " | "
                    + selectedInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                forceFlatSentToday =
                    false;

                PrintBotMessage(
                    "FORCE FLAT ERROR: "
                    + ex.Message
                );
            }
        }
        private void UpdateUnrealizedPnL(
            double currentPrice)
        {
            Instrument instrument =
                selectedInstrument;

            double localEntryPrice;
            int localQuantity;
            MarketPosition localPosition;
            bool localManualTest;

            lock (executionStateLock)
            {
                localEntryPrice =
                    entryFillPrice;

                localQuantity =
                    entryQuantity;

                localPosition =
                    entryMarketPosition;

                localManualTest =
                    activeTradeIsManualTest;
            }

            if (
                instrument == null ||
                instrument.MasterInstrument == null ||
                localEntryPrice <= 0 ||
                localQuantity <= 0 ||
                localPosition ==
                    MarketPosition.Flat
            )
            {
                lock (executionStateLock)
                {
                    botUnrealizedPnL =
                        0;
                }

                UpdatePnlDisplay();
                return;
            }

            double pointValue =
                instrument
                    .MasterInstrument
                    .PointValue;

            double newUnrealizedPnL =
                0;

            if (
                localPosition ==
                    MarketPosition.Long
            )
            {
                newUnrealizedPnL =
                    (
                        currentPrice -
                        localEntryPrice
                    )
                    * pointValue
                    * localQuantity;
            }
            else if (
                localPosition ==
                    MarketPosition.Short
            )
            {
                newUnrealizedPnL =
                    (
                        localEntryPrice -
                        currentPrice
                    )
                    * pointValue
                    * localQuantity;
            }

            lock (executionStateLock)
            {
                // Do not apply a PnL calculation to a trade that
                // changed while this method was calculating it.
                if (
                    entryFillPrice !=
                        localEntryPrice ||
                    entryQuantity !=
                        localQuantity ||
                    entryMarketPosition !=
                        localPosition
                )
                {
                    return;
                }

                botUnrealizedPnL =
                    localManualTest
                        ? 0
                        : newUnrealizedPnL;

                // V1.6.23 Phase 12 - keep real active-trade PnL separate
                // from official Daily PnL so Manual TEST telemetry remains
                // truthful while official PnL stays isolated.
                activeTradeUnrealizedPnl =
                    newUnrealizedPnL;

                // V1.6.23 - execution-wide excursion tracking.
                activeTradeCurrentPrice = currentPrice;

                // Unlike Learning MFE/MAE, this also tracks manual SIM tests
                // so trade management can be validated without polluting Learning.
                if (newUnrealizedPnL > activeTradeMfeDollars)
                    activeTradeMfeDollars = newUnrealizedPnL;

                if (newUnrealizedPnL < activeTradeMaeDollars)
                    activeTradeMaeDollars = newUnrealizedPnL;

                if (newUnrealizedPnL > activeTradePeakPnlDollars)
                    activeTradePeakPnlDollars = newUnrealizedPnL;

                if (
                    !localManualTest &&
                    activeLearningTrade != null
                )
                {
                    if (
                        botUnrealizedPnL >
                        activeLearningTrade.Mfe
                    )
                    {
                        activeLearningTrade.Mfe =
                            botUnrealizedPnL;
                    }

                    if (
                        botUnrealizedPnL <
                        activeLearningTrade.Mae
                    )
                    {
                        activeLearningTrade.Mae =
                            botUnrealizedPnL;
                    }
                }
            }

            UpdatePnlDisplay();
        }
        private void UpdatePnlDisplay()
        {
            double localGrossPnL;
            double localFees;
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;

            lock (executionStateLock)
            {
                localGrossPnL =
                    botDailyGrossPnL;

                localFees =
                    botDailyFees;

                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;
            }

            UpdateDailyProfitFloorState(
                totalPnL
            );

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (grossPnlText != null)
                    {
                        grossPnlText.Text =
                            localGrossPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (feesPnlText != null)
                    {
                        feesPnlText.Text =
                            localFees.ToString(
                                "$0.00"
                            );
                    }

                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (unrealizedPnlText != null)
                    {
                        unrealizedPnlText.Text =
                            localUnrealizedPnL.ToString(
                                "$0.00"
                            );

                        unrealizedPnlText.Foreground =
                            localUnrealizedPnL > 0
                                ? Brushes.LimeGreen
                                : localUnrealizedPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }

                    if (totalPnlText != null)
                    {
                        totalPnlText.Text =
                            totalPnL.ToString(
                                "$0.00"
                            );

                        totalPnlText.Foreground =
                            totalPnL > 0
                                ? Brushes.LimeGreen
                                : totalPnL < 0
                                    ? Brushes.OrangeRed
                                    : Brushes.White;
                    }
                })
            );
        }
        private void UpdateDailyProfitFloorState(
            double totalPnL)
        {
            bool newlyArmed = false;
            bool floorRaised = false;
            double localPeak;
            double localRealized;
            double localFloor;

            lock (executionStateLock)
            {
                // Keep Daily Peak as TOTAL PnL for telemetry/diagnostics.
                // IMPORTANT V1.6.14 PROFIT-FLOOR FIX:
                // Unrealized MFE may raise the displayed session peak, but it
                // must NOT create or raise a hard session floor by itself.
                // The protected floor is based only on BANKED/REALIZED profit.
                // This prevents a first trade that briefly goes +$75 floating
                // from arming a $37.50 floor and then flattening on normal noise.
                if (totalPnL > dailyPeakTotalPnL)
                {
                    dailyPeakTotalPnL =
                        totalPnL;
                }

                localRealized =
                    botDailyPnL;

                double activationThreshold =
                    Math.Max(
                        DailyProfitFloorActivationMinDollars,
                        activeDailyTarget *
                            DailyProfitFloorTargetActivationFactor
                    );

                // Arm/raise protection only from REALIZED session profits.
                // Once armed, the floor remains monotonic and can never loosen.
                if (localRealized >= activationThreshold)
                {
                    double candidateFloor =
                        localRealized *
                        DailyProfitFloorRetentionFactor;

                    if (!dailyProfitFloorArmed)
                    {
                        dailyProfitFloorArmed = true;
                        newlyArmed = true;
                    }

                    if (candidateFloor > dailyProtectedProfitFloor)
                    {
                        dailyProtectedProfitFloor =
                            candidateFloor;

                        if (
                            newlyArmed ||
                            dailyProtectedProfitFloor -
                                lastLoggedProtectedProfitFloor >=
                                    DailyProfitFloorLogStepDollars
                        )
                        {
                            floorRaised = true;
                            lastLoggedProtectedProfitFloor =
                                dailyProtectedProfitFloor;
                        }
                    }
                }

                localPeak = dailyPeakTotalPnL;
                localFloor = dailyProtectedProfitFloor;
            }

            if (newlyArmed || floorRaised)
            {
                SavePersistentDailyState();

                PrintBotMessage(
                    "DAILY PROFIT FLOOR "
                    + (newlyArmed ? "ARMED" : "RAISED")
                    + " | TotalPeak: "
                    + localPeak.ToString("$0.00")
                    + " | RealizedBasis: "
                    + localRealized.ToString("$0.00")
                    + " | Protected: "
                    + localFloor.ToString("$0.00")
                    + " | Retention: 50%"
                );
            }
        }
        private void CheckDailyLossEmergency()
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null ||
                !IsSimulationAccount(selectedAccount)
            )
            {
                return;
            }

            double totalPnL =
                botDailyPnL +
                botUnrealizedPnL;

            UpdateDailyProfitFloorState(
                totalPnL
            );

            bool localProfitFloorArmed;
            double localProtectedProfitFloor;

            lock (executionStateLock)
            {
                localProfitFloorArmed =
                    dailyProfitFloorArmed;

                localProtectedProfitFloor =
                    dailyProtectedProfitFloor;
            }

            bool profitFloorActuallyHit =
                localProfitFloorArmed &&
                localProtectedProfitFloor > 0 &&
                totalPnL <=
                    localProtectedProfitFloor;

            MarketPosition actualSide;
            int actualQty;
            double actualAvgPrice;

            bool actualFlat =
                TryGetSelectedInstrumentPosition(
                    out actualSide,
                    out actualQty,
                    out actualAvgPrice
                );

            if (actualFlat)
            {
                if (
                    profitFloorActuallyHit &&
                    !persistentDailyLocked
                )
                {
                    SetPersistentDailyLock(
                        "DAILY PROFIT FLOOR"
                    );

                    PrintBotMessage(
                        "DAILY PROFIT FLOOR HIT"
                        + " | Realized: "
                        + botDailyPnL.ToString("$0.00")
                        + " | Unrealized: "
                        + botUnrealizedPnL.ToString("$0.00")
                        + " | Total: "
                        + totalPnL.ToString("$0.00")
                        + " | Protected Floor: "
                        + localProtectedProfitFloor.ToString("$0.00")
                        + " | FLAT - TRADING LOCKED."
                    );
                }
                if (riskFlattenSent)
                {
                    executionStatus =
                        persistentDailyLocked
                            ? "DAILY RISK LOCK"
                            : "FLAT CONFIRMED";

                    PrintBotMessage(
                        "FLATTEN CONFIRMED | Position: FLAT"
                    );

                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;
                    UpdateExecutionMonitor();
                }

                return;
            }

            // Hard flatten remains mandatory for configured DAILY LOSS.
            // V1.6.4 also flattens when the protected daily/session profit
            // floor is touched after being armed.
            // A DailyLocked state caused by profit target or force-flat time
            // must never be mistaken for a loss emergency.
            bool dailyLossActuallyHit =
                totalPnL <=
                    -activeDailyLoss;

            if (
                !dailyLossActuallyHit &&
                !profitFloorActuallyHit
            )
            {
                return;
            }

            string riskLockReason =
                dailyLossActuallyHit
                    ? "DAILY LOSS"
                    : "DAILY PROFIT FLOOR";

            if (!riskFlattenSent)
            {
                SetPersistentDailyLock(
                    riskLockReason
                );

                activeForcedExitReason =
                    dailyLossActuallyHit
                        ? "DAILY_LOSS"
                        : "PROFIT_FLOOR";

                riskFlattenSent = true;
                riskFlattenStage = 0;
                riskFlattenLastActionUtc = DateTime.MinValue;
                riskFlattenOrder = null;

                SavePersistentDailyState();

                executionStatus =
                    dailyLossActuallyHit
                        ? "DAILY LOSS FLATTEN"
                        : "PROFIT FLOOR FLATTEN";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    (
                        dailyLossActuallyHit
                            ? "DAILY LOSS LIMIT HIT"
                            : "DAILY PROFIT FLOOR HIT"
                    )
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                    + " | Unrealized: "
                    + botUnrealizedPnL.ToString("$0.00")
                    + " | Total: "
                    + totalPnL.ToString("$0.00")
                    + (
                        profitFloorActuallyHit
                            ? " | Protected Floor: "
                                + localProtectedProfitFloor.ToString("$0.00")
                            : " | Daily Loss Limit: -"
                                + activeDailyLoss.ToString("$0.00")
                      )
                    + " | HARD FLATTEN STARTED."
                );
            }

            // Throttle emergency actions. Range updates can arrive many times
            // per second; a flatten attempt is allowed at most once per second.
            DateTime nowUtc = DateTime.UtcNow;

            if (
                riskFlattenLastActionUtc != DateTime.MinValue &&
                (nowUtc - riskFlattenLastActionUtc).TotalMilliseconds < 1000
            )
            {
                return;
            }

            try
            {
                if (riskFlattenStage == 0)
                {
                    selectedAccount.Flatten(
                        new[] { selectedInstrument }
                    );

                    riskFlattenStage = 1;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 1"
                        + " | Account.Flatten sent"
                        + " | Position: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                if (riskFlattenStage == 1)
                {
                    selectedAccount.CancelAllOrders(
                        selectedInstrument
                    );

                    riskFlattenStage = 2;
                    riskFlattenLastActionUtc = nowUtc;

                    PrintBotMessage(
                        "DAILY LOSS FLATTEN ATTEMPT 2"
                        + " | CancelAllOrders sent"
                        + " | Position still: " + actualSide
                        + " " + actualQty
                    );

                    return;
                }

                bool canSubmitFallback =
                    riskFlattenOrder == null ||
                    riskFlattenOrder.OrderState == OrderState.Filled ||
                    riskFlattenOrder.OrderState == OrderState.Cancelled ||
                    riskFlattenOrder.OrderState == OrderState.Rejected;

                if (!canSubmitFallback)
                {
                    riskFlattenLastActionUtc = nowUtc;
                    return;
                }

                // V1.6.12 - refresh the REAL position immediately before
                // the market fallback. Partial fills may have changed the
                // quantity since the first snapshot at the top of this method.
                MarketPosition fallbackSide;
                int fallbackQty;
                double fallbackAvgPrice;

                bool fallbackFlat =
                    TryGetSelectedInstrumentPosition(
                        out fallbackSide,
                        out fallbackQty,
                        out fallbackAvgPrice
                    );

                if (
                    fallbackFlat ||
                    fallbackQty <= 0 ||
                    fallbackSide == MarketPosition.Flat
                )
                {
                    riskFlattenSent = false;
                    riskFlattenStage = 0;
                    riskFlattenLastActionUtc = DateTime.MinValue;
                    riskFlattenOrder = null;
                    executionStatus =
                        persistentDailyLocked
                            ? "DAILY RISK LOCK"
                            : "FLAT CONFIRMED";
                    UpdateExecutionMonitor();
                    return;
                }

                OrderAction closeAction =
                    fallbackSide == MarketPosition.Long
                        ? OrderAction.Sell
                        : OrderAction.BuyToCover;

                riskFlattenOrder =
                    selectedAccount.CreateOrder(
                        selectedInstrument,
                        closeAction,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        fallbackQty,
                        0,
                        0,
                        string.Empty,
                        GetProfileOrderName("JJ_RISK_FLATTEN"),
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                selectedAccount.Submit(
                    new[] { riskFlattenOrder }
                );

                riskFlattenStage = 3;
                riskFlattenLastActionUtc = nowUtc;

                executionStatus =
                    "HARD FLATTEN MARKET";

                UpdateExecutionMonitor();

                PrintBotMessage(
                    "DAILY LOSS FLATTEN FALLBACK"
                    + " | MARKET " + closeAction
                    + " " + fallbackQty
                    + " | Position was: " + fallbackSide
                );
            }
            catch (Exception ex)
            {
                riskFlattenLastActionUtc = nowUtc;

                PrintBotMessage(
                    "DAILY LOSS FLATTEN ERROR: "
                    + ex.Message
                );
            }
        }

    }
}

﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT RUNTIME CONTROL
    // Stage 18 structural extraction only.
    //
    // Existing account/instrument selection, SIM manual test,
    // Start/Stop, account event subscription, runtime lease
    // release, Close All and runtime error coordination are
    // moved exactly as-is.
    //
    // No trading rules, risk rules, entry logic, order logic,
    // session logic or execution behavior was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void AccountSelectorChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (accountSelector == null)
                return;

            Account previousAccount =
                selectedAccount;

            Account newAccount =
                accountSelector.SelectedAccount;

            bool accountChanged =
                previousAccount != null
                ? (
                    newAccount == null ||
                    !string.Equals(
                        previousAccount.Name,
                        newAccount.Name,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                : newAccount != null;

            // =====================================================
            // SAFETY: ACCOUNT CHANGES MUST STOP THE ACTIVE ENGINE
            // =====================================================
            // Bars callbacks and Account.ExecutionUpdate / OrderUpdate
            // must never point at different accounts.
            if (
                accountChanged &&
                botRunning
            )
            {
                botRunning =
                    false;

                StopBarsEngine();

                ReleaseRuntimeLease();

                // Immediately detach callbacks from the OLD account.
                UnsubscribeExecutionAccount();

                currentSignalState =
                    "ACCOUNT CHANGED";

                currentSetupState =
                    "STOPPED";

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "ACCOUNT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;

                if (accountSelector != null)
                    accountSelector.IsEnabled = true;

                if (instrumentSelector != null)
                    instrumentSelector.IsEnabled = true;

                PrintBotMessage(
                    "BOT STOPPED - ACCOUNT CHANGED."
                );
            }

            // Even if the main signal engine was already stopped (for
            // example after a manual SIM test), never keep callbacks
            // subscribed to an account that is no longer selected.
            if (
                accountChanged &&
                !botRunning
            )
            {
                UnsubscribeExecutionAccount();
            }

            // Remove the OLD bridge state before the selection is replaced.
            if (
                accountChanged &&
                previousAccount != null &&
                selectedInstrument != null
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    previousAccount.Name,
                    selectedInstrument.FullName
                );
            }

            selectedAccount =
                newAccount;

            if (selectedAccount != null)
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "Account: "
                        + selectedAccount.Name;

                    accountStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "ACCOUNT SELECTED: "
                    + selectedAccount.Name
                );

                PublishSharedState();
            }
            else
            {
                if (accountStatusText != null)
                {
                    accountStatusText.Text =
                        "No account selected";

                    accountStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            // Restore only AFTER the engine has been stopped and the
            // new Account + Instrument selection is stable.
            TryRestorePersistentStateForSelection();
        }
        private void InstrumentSelectorChanged(
            object sender,
            EventArgs e)
        {
            if (instrumentSelector == null)
                return;

            Instrument previousInstrument =
                selectedInstrument;

            Instrument newInstrument =
                instrumentSelector.Instrument;

            // Remove the OLD bridge entry before publishing the newly
            // selected instrument. Otherwise the old chart can keep a
            // stale snapshot forever.
            if (
                selectedAccount != null &&
                previousInstrument != null &&
                (
                    newInstrument == null ||
                    !string.Equals(
                        previousInstrument.FullName,
                        newInstrument.FullName,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
            )
            {
                JJBotSharedState.RemoveSnapshot(
                    selectedAccount.Name,
                    previousInstrument.FullName
                );
            }

            // If the bot is running, stop the old data subscription first.
            if (botRunning)
            {
                StopBarsEngine();

                botRunning = false;

                ReleaseRuntimeLease();

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "INSTRUMENT CHANGED";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                    startButton.IsEnabled = true;

                if (stopButton != null)
                    stopButton.IsEnabled = false;

                if (directionCombo != null)
                    directionCombo.IsEnabled = true;
            }

            selectedInstrument =
                newInstrument;

            if (selectedInstrument != null)
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "Instrument: "
                        + selectedInstrument.FullName;

                    instrumentStatusText.Foreground =
                        Brushes.LightGreen;
                }

                PrintBotMessage(
                    "INSTRUMENT SELECTED: "
                    + selectedInstrument.FullName
                );

                PublishSharedState();
            }
            else
            {
                if (instrumentStatusText != null)
                {
                    instrumentStatusText.Text =
                        "No instrument selected";

                    instrumentStatusText.Foreground =
                        Brushes.Gray;
                }
            }

            ResetSignalDisplay();
            ResetExecutionMonitor();

            TryRestorePersistentStateForSelection();
        }
        private void TestLongClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                true
            );
        }
        private void TestShortClicked(
            object sender,
            RoutedEventArgs e)
        {
            RunManualSimTest(
                false
            );
        }
        private void RunManualSimTest(
            bool isLong)
        {
            // Manual test still uses the licensed JJ Bot execution engine.
            if (
                !RefreshBotCloudLicense(
                    true
                )
            )
            {
                PrintBotMessage(
                    "MANUAL TEST BLOCKED - CLOUD LICENSE REQUIRED"
                );

                return;
            }

            EnsureBotLicenseTimer();

            // When TEST LONG / TEST SHORT comes from J&J Company Bro,
            // ApplyPlatformStartConfiguration() has already resolved the
            // exact Account + Instrument selected in the platform.
            //
            // Do NOT overwrite them with the hidden NinjaTrader selectors
            // (which may still display Sim101).
            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;

                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select an account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;
            double dollarRiskCap;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                ) ||
                contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                ) ||
                stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                ) ||
                targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                ) ||
                maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                ) ||
                dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                ) ||
                dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                dollarRiskCapBox == null ||
                !double.TryParse(
                    dollarRiskCapBox.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out dollarRiskCap
                ) ||
                dollarRiskCap <= 0 ||
                dollarRiskCap > MaxDollarRiskCapAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Dollar Risk Cap. Maximum: "
                    + MaxDollarRiskCapAllowed.ToString("$0.00")
                    + "."
                );

                return;
            }

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            activeDollarRiskCap =
                dollarRiskCap;

            // Subscribe even when the main signal engine is STOPPED.
            SubscribeExecutionAccount(
                selectedAccount
            );

            // IMPORTANT:
            // TEST LONG / TEST SHORT must use the same persistent
            // counters as automatic trading. Otherwise reopening the
            // window could incorrectly start manual tests from 0 / 2.
            LoadOrResetPersistentDailyState();

            if (persistentDailyLocked)
            {
                // Manual TEST LONG / TEST SHORT are SIM-only diagnostics.
                // They are intentionally allowed even when the normal
                // automatic engine is DailyLocked (for example after 16:25 ET),
                // so configurations can be tested at night.
                PrintBotMessage(
                    "MANUAL TEST - DAILY LOCK BYPASSED"
                    + " | Trades: "
                    + tradesToday
                    + "/"
                    + activeMaxTrades
                    + " | Realized: "
                    + botDailyPnL.ToString("$0.00")
                );
            }

            // Give the manual test its own temporary execution permission.
            bool wasRunning =
                botRunning;

            botRunning =
                true;

            executionStatus =
                isLong
                    ? "TEST LONG"
                    : "TEST SHORT";

            UpdateExecutionMonitor();

            DateTime uniqueTestSignal =
                DateTime.UtcNow;

         TrySubmitEntry(
    isLong,
    uniqueTestSignal,
    true
);

            // Keep the signal engine's previous RUNNING/STOPPED state.
            // The submitted order and its OCO bracket continue to be
            // managed by Account.ExecutionUpdate independently.
            botRunning =
                wasRunning;

            PrintBotMessage(
                "MANUAL TEST REQUESTED | "
                + (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
            );
        }
        private void StartBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            // LICENSE GATE: no bot start without cloud authorization.
            if (
                !RefreshBotCloudLicense(
                    true
                )
            )
            {
                PrintBotMessage(
                    "START BLOCKED - CLOUD LICENSE REQUIRED"
                );

                return;
            }

            EnsureBotLicenseTimer();

            if (!platformRemoteStartContext)
            {
                selectedAccount =
                    accountSelector != null
                        ? accountSelector.SelectedAccount
                        : null;
            }

            if (selectedAccount == null)
            {
                MessageBox.Show(
                    "Select an account before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            if (!platformRemoteStartContext)
            {
                selectedInstrument =
                    instrumentSelector != null
                        ? instrumentSelector.Instrument
                        : null;
            }

            if (selectedInstrument == null)
            {
                MessageBox.Show(
                    "Select an instrument before starting the bot.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            int contracts;
            int stopTicks;
            int targetTicks;
            int maxTrades;

            double dailyTarget;
            double dailyLoss;
            double dollarRiskCap;

            if (
                !int.TryParse(
                    contractsBox.Text,
                    out contracts
                )
                || contracts <= 0 ||
                contracts > MaxContractsAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid contract quantity. Allowed range: 1-" + MaxContractsAllowed + "."
                );

                return;
            }

            if (
                !int.TryParse(
                    stopBox.Text,
                    out stopTicks
                )
                || stopTicks <= 0 ||
                stopTicks > MaxStopTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Stop Loss. Allowed range: 1-" + MaxStopTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    targetBox.Text,
                    out targetTicks
                )
                || targetTicks <= 0 ||
                targetTicks > MaxTargetTicksAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Profit Target. Allowed range: 1-" + MaxTargetTicksAllowed + " ticks."
                );

                return;
            }

            if (
                !int.TryParse(
                    maxTradesBox.Text,
                    out maxTrades
                )
                || maxTrades <= 0 ||
                maxTrades > MaxTradesPerSessionAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Max Trades value. Allowed range: 1-" + MaxTradesPerSessionAllowed + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyTargetBox.Text,
                    out dailyTarget
                )
                || dailyTarget <= 0 ||
                dailyTarget > MaxDailyTargetAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Target. Maximum: " + MaxDailyTargetAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                !double.TryParse(
                    dailyLossBox.Text,
                    out dailyLoss
                )
                || dailyLoss <= 0 ||
                dailyLoss > MaxDailyLossAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Daily Loss. Maximum: " + MaxDailyLossAllowed.ToString("$0.00") + "."
                );

                return;
            }

            if (
                dollarRiskCapBox == null ||
                !double.TryParse(
                    dollarRiskCapBox.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out dollarRiskCap
                ) ||
                dollarRiskCap <= 0 ||
                dollarRiskCap > MaxDollarRiskCapAllowed
            )
            {
                ShowInvalidValue(
                    "Invalid Dollar Risk Cap. Maximum: "
                    + MaxDollarRiskCapAllowed.ToString("$0.00")
                    + "."
                );

                return;
            }

            string requestedLeaseKey;

            if (
                !JJBotRuntimeCoordinator.TryAcquireBotLease(
                    selectedAccount.Name,
                    selectedInstrument.FullName,
                    out requestedLeaseKey
                )
            )
            {
                MessageBox.Show(
                    "Another J&J Bot window is already running this same "
                    + "Account + Instrument.\n\n"
                    + "Account: "
                    + selectedAccount.Name
                    + "\nInstrument: "
                    + selectedInstrument.FullName
                    + "\n\nStop or close the other bot window before starting this one.",
                    "J&J Trading Bot - DUPLICATE BLOCKED",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                PrintBotMessage(
                    "START BLOCKED - DUPLICATE ACCOUNT + INSTRUMENT"
                    + " | Account: "
                    + selectedAccount.Name
                    + " | Instrument: "
                    + selectedInstrument.FullName
                );

                return;
            }

            activeRuntimeLeaseKey =
                requestedLeaseKey;

            activeDirection =
                directionCombo != null &&
                directionCombo.SelectedItem != null
                    ? directionCombo.SelectedItem.ToString()
                    : "BOTH";

            activeStrategyMode =
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
                    ? strategyCombo.SelectedItem.ToString()
                    : "HYBRID";

            string direction =
                activeDirection;

            activeContracts =
                contracts;

            activeStopTicks =
                stopTicks;

            activeTargetTicks =
                targetTicks;

            activeMaxTrades =
                maxTrades;

            activeDailyTarget =
                dailyTarget;

            activeDailyLoss =
                dailyLoss;

            activeDollarRiskCap =
                dollarRiskCap;

            // Do NOT reset tradesToday / botDailyPnL here.
            // They belong to the persistent daily state and are
            // restored below by LoadOrResetPersistentDailyState().
            botUnrealizedPnL = 0;
            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;
            activeEntryCommission = 0;
            activeEffectiveTargetTicks = 0;
            activeExitQuantity = 0;
            activeExitGrossPnL = 0;
            activeExitCommission = 0;
            lastRangeSignalLogKey = string.Empty;
            lastRangeBlockedLogKey = string.Empty;
            lastLearningBlockedLogKey = string.Empty;

            entryPending = false;
            pendingEntryRequestedQuantity = 0;
            entryOrder = null;
            stopOrder = null;
            targetOrder = null;
            entryFillPrice = 0;
            activeStopPrice = 0;
            activeTargetPrice = 0;
            entryQuantity = 0;

            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "WAITING";

            SubscribeExecutionAccount(
                selectedAccount
            );

            LoadOrResetPersistentDailyState();

            tradesText.Text =
                tradesToday
                + " / "
                + activeMaxTrades;

            UpdatePnlDisplay();

            ResetExecutionMonitor();

            // V1.6.14R - POSITION RECOVERY / TRAILING RESUME
            // If NinjaTrader/account still has an open position after the
            // desktop app or bot was stopped/restarted, adopt that real
            // position BEFORE the signal engine begins looking for entries.
            // Existing protective orders are reused and the stop is never
            // moved backwards.
            bool recoveredExistingPosition =
                TryRecoverExistingPosition();

            signalText.Text =
                recoveredExistingPosition
                    ? "RECOVERED POSITION - LOADING MARKET DATA..."
                    : "LOADING 5M DATA...";

            signalText.Foreground =
                Brushes.Goldenrod;

            statusText.Text =
                "● STARTING";

            statusText.Foreground =
                Brushes.Goldenrod;

            startButton.IsEnabled =
                false;

            stopButton.IsEnabled =
                true;

            botRunning = true;

            if (!recoveredExistingPosition)
            {
                StartPositionRecoveryRetry();

                // V1.6.36 - do not inherit an in-progress momentum burst the
                // instant the bot is started. Let M5/HTF/Level2/R20 settle first.
                automaticEntryWarmupUntilNy =
                    GetCurrentNewYorkTime().AddSeconds(StartupEntryWarmupSeconds);
                lastStartupWarmupBlockLogKey = string.Empty;
            }
            else
            {
                StopPositionRecoveryRetry();
                automaticEntryWarmupUntilNy = DateTime.MinValue;
                lastStartupWarmupBlockLogKey = string.Empty;
            }

            currentSignalState =
                recoveredExistingPosition
                    ? "POSITION RECOVERED"
                    : "LOADING 5M DATA...";

            currentSetupState =
                "STARTING";

            PublishSharedState();

            if (directionCombo != null)
                directionCombo.IsEnabled = false;

            if (accountSelector != null)
                accountSelector.IsEnabled = false;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = false;

            LoadLearningMemory();

            PrintBotMessage(
                "LEARNING DECISION ENGINE V1.6.13 ACTIVE"
                + " | SHARED ACROSS PROFILES BY INSTRUMENT"
                + " | Hierarchy: SPECIFIC(SIDE+STRUCTURE) > SIDE > GLOBAL"
                + " | Observe: "
                + LearningObserveTrades
                + " | Caution: "
                + LearningCautionTrades
                + " | Strong: "
                + LearningStrongTrades
                + " | Block A: Exp < "
                + LearningMinExpectancy.ToString("$0.00")
                + " & Net < "
                + LearningMinNetPnL.ToString("$0.00")
                + " | Block B: WinRate < "
                + LearningMinWinRate.ToString("0")
                + "% & Exp < $0"
            );

            PrintBotMessage(
                "STARTING"
                + " | Account: "
                + selectedAccount.Name
                + " | Instrument: "
                + selectedInstrument.FullName
                + " | Direction: "
                + direction
                + " | Strategy: "
                + activeStrategyMode
                + " | Contracts: "
                + contracts
                + " | SL: "
                + stopTicks
                + " ticks"
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxTrades: "
                + maxTrades
                + " | DailyTarget: $"
                + dailyTarget
                + " | DailyLoss: $"
                + dailyLoss
                + " | DollarRiskCap: "
                + activeDollarRiskCap.ToString("$0.00")
                + " | StrategyClockNY: "
                + GetCurrentNewYorkTime()
                    .ToString("HH:mm:ss")
                + " ET"
            );

            StartBarsEngine();
        }
        // =====================================================
        // ACCOUNT PERMISSION COMPATIBILITY
        // =====================================================
        // Keep the historical method name because several mature modules
        // still call IsSimulationAccount(). The policy has changed:
        // any valid NinjaTrader Account is now allowed (SIM / Evaluation /
        // Funded / Live). No trading, signal, risk or management logic is
        // changed by this helper.
        private bool IsSimulationAccount(
            Account account)
        {
            return
                account != null &&
                !string.IsNullOrWhiteSpace(
                    account.Name
                );
        }

        private void SubscribeExecutionAccount(
            Account account)
        {
            UnsubscribeExecutionAccount();

            if (account == null)
            {
                return;
            }

            subscribedAccount =
                account;

            subscribedAccount.ExecutionUpdate +=
                OnAccountExecutionUpdate;

            subscribedAccount.OrderUpdate +=
                OnAccountOrderUpdate;
        }
        private void UnsubscribeExecutionAccount()
        {
            if (
                subscribedAccount != null
            )
            {
                subscribedAccount.ExecutionUpdate -=
                    OnAccountExecutionUpdate;

                subscribedAccount.OrderUpdate -=
                    OnAccountOrderUpdate;

                subscribedAccount =
                    null;
            }
        }
        private void ReleaseRuntimeLease()
        {
            string leaseKey =
                activeRuntimeLeaseKey;

            activeRuntimeLeaseKey =
                string.Empty;

            JJBotRuntimeCoordinator.ReleaseBotLease(
                leaseKey
            );
        }
        private void StopBotClicked(
            object sender,
            RoutedEventArgs e)
        {
            botRunning = false;

            StopPositionRecoveryRetry();

            ReleaseRuntimeLease();

            currentSignalState =
                "STOPPED";

            currentSetupState =
                "STOPPED";

            PublishSharedState();

            StopBarsEngine();

            statusText.Text =
                "● STOPPED";

            statusText.Foreground =
                Brushes.OrangeRed;

            signalText.Text =
                "STOPPED";

            signalText.Foreground =
                Brushes.White;

            startButton.IsEnabled =
                true;

            stopButton.IsEnabled =
                false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;

            PrintBotMessage(
                "BOT STOPPED - EXISTING OCO ORDERS/POSITION ARE NOT FLATTENED."
            );
        }
        private string NormalizeAccountIdentity(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            StringBuilder builder =
                new StringBuilder();

            foreach (char c in value.Trim().ToUpperInvariant())
            {
                if (char.IsLetterOrDigit(c))
                    builder.Append(c);
            }

            return builder.ToString();
        }

        private int CountAccountDigits(
            string value)
        {
            int count = 0;

            if (string.IsNullOrEmpty(value))
                return count;

            foreach (char c in value)
            {
                if (char.IsDigit(c))
                    count++;
            }

            return count;
        }

        private Account ResolveAccountByName(
            string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
                return null;

            string requested =
                accountName.Trim();

            List<Account> available =
                new List<Account>();

            try
            {
                foreach (Account account in Account.All)
                {
                    if (
                        account != null &&
                        !string.IsNullOrWhiteSpace(account.Name)
                    )
                    {
                        available.Add(account);
                    }
                }
            }
            catch
            {
                return null;
            }

            // Stage 1: exact NinjaTrader account name.
            Account exact =
                available.FirstOrDefault(
                    account =>
                        string.Equals(
                            account.Name.Trim(),
                            requested,
                            StringComparison.OrdinalIgnoreCase
                        )
                );

            if (exact != null)
                return exact;

            string requestedKey =
                NormalizeAccountIdentity(requested);

            if (string.IsNullOrWhiteSpace(requestedKey))
                return null;

            // Stage 2: canonical exact match. This safely handles
            // visual separators such as APEX-530762 vs APEX530762.
            List<Account> canonicalMatches =
                available
                    .Where(
                        account =>
                            string.Equals(
                                NormalizeAccountIdentity(account.Name),
                                requestedKey,
                                StringComparison.OrdinalIgnoreCase
                            )
                    )
                    .ToList();

            if (canonicalMatches.Count == 1)
            {
                AppendVisualLog(
                    "ACCOUNT RESOLUTION | Requested: "
                    + requested
                    + " | NinjaMatch: "
                    + canonicalMatches[0].Name
                    + " | Method: NORMALIZED_EXACT"
                );

                return canonicalMatches[0];
            }

            if (canonicalMatches.Count > 1)
            {
                AppendVisualLog(
                    "ACCOUNT RESOLUTION BLOCKED | Requested: "
                    + requested
                    + " | Reason: AMBIGUOUS NORMALIZED MATCH"
                );

                return null;
            }

            // Stage 3: safe unique prefix match for provider aliases that
            // omit an internal suffix/padding in the Desktop display name.
            // Require a substantial identity and >= 6 digits so generic
            // names such as APEX cannot select an arbitrary account.
            if (
                requestedKey.Length >= 8 &&
                CountAccountDigits(requestedKey) >= 6
            )
            {
                List<Account> prefixMatches =
                    available
                        .Where(
                            account =>
                            {
                                string candidateKey =
                                    NormalizeAccountIdentity(account.Name);

                                if (
                                    candidateKey.Length < 8 ||
                                    CountAccountDigits(candidateKey) < 6
                                )
                                {
                                    return false;
                                }

                                return
                                    candidateKey.StartsWith(
                                        requestedKey,
                                        StringComparison.OrdinalIgnoreCase
                                    ) ||
                                    requestedKey.StartsWith(
                                        candidateKey,
                                        StringComparison.OrdinalIgnoreCase
                                    );
                            }
                        )
                        .ToList();

                if (prefixMatches.Count == 1)
                {
                    AppendVisualLog(
                        "ACCOUNT RESOLUTION | Requested: "
                        + requested
                        + " | NinjaMatch: "
                        + prefixMatches[0].Name
                        + " | Method: UNIQUE_PREFIX"
                    );

                    return prefixMatches[0];
                }

                if (prefixMatches.Count > 1)
                {
                    AppendVisualLog(
                        "ACCOUNT RESOLUTION BLOCKED | Requested: "
                        + requested
                        + " | Reason: AMBIGUOUS PREFIX MATCH | Candidates: "
                        + string.Join(
                            ", ",
                            prefixMatches.Select(account => account.Name)
                        )
                    );

                    return null;
                }
            }

            return null;
        }
        private Instrument ResolveInstrumentByName(
            string instrumentName)
        {
            if (
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                return null;
            }

            try
            {
                return Instrument.GetInstrument(
                    instrumentName
                );
            }
            catch
            {
                return null;
            }
        }
        private void CloseAllForContext(
            Account targetAccount,
            Instrument targetInstrument,
            string origin)
        {
            if (
                targetAccount == null ||
                targetInstrument == null
            )
            {
                PrintBotMessage(
                    "CLOSE ALL CONTEXT ERROR"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | Account/Instrument not resolved."
                );

                return;
            }

            try
            {
                targetAccount.Flatten(
                    new[]
                    {
                        targetInstrument
                    }
                );

                botRunning = false;

                ReleaseRuntimeLease();

                entryPending = false;

                currentSignalState =
                    "SIM FLATTEN SENT";

                currentSetupState =
                    "STOPPED";

                executionStatus =
                    "FLATTENING";

                PublishSharedState();

                riskFlattenSent =
                    true;

                UpdateExecutionMonitor();
                StopBarsEngine();

                if (statusText != null)
                {
                    statusText.Text =
                        "● STOPPED";

                    statusText.Foreground =
                        Brushes.OrangeRed;
                }

                if (signalText != null)
                {
                    signalText.Text =
                        "SIM FLATTEN SENT";

                    signalText.Foreground =
                        Brushes.Goldenrod;
                }

                if (startButton != null)
                {
                    startButton.IsEnabled =
                        true;
                }

                if (stopButton != null)
                {
                    stopButton.IsEnabled =
                        false;
                }

                if (directionCombo != null)
                {
                    directionCombo.IsEnabled =
                        true;
                }

                if (accountSelector != null)
                {
                    accountSelector.IsEnabled =
                        true;
                }

                if (instrumentSelector != null)
                {
                    instrumentSelector.IsEnabled =
                        true;
                }

                PrintBotMessage(
                    "SIM CLOSE ALL / FLATTEN SENT"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | "
                    + targetAccount.Name
                    + " / "
                    + targetInstrument.FullName
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "CLOSE ALL ERROR"
                    + " | Origin: "
                    + (origin ?? "UNKNOWN")
                    + " | "
                    + ex.Message
                );
            }
        }
        private void CloseAllClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                selectedAccount == null ||
                selectedInstrument == null
            )
            {
                MessageBox.Show(
                    "Select an account and instrument first.",
                    "J&J Trading Bot",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                return;
            }

            CloseAllForContext(
                selectedAccount,
                selectedInstrument,
                "NINJA UI"
            );
        }
        private void SetEngineError(
            string text)
        {
            botRunning = false;

            StopBarsEngine();

            if (statusText != null)
            {
                statusText.Text =
                    "● STOPPED";

                statusText.Foreground =
                    Brushes.OrangeRed;
            }

            if (signalText != null)
            {
                signalText.Text =
                    text;

                signalText.Foreground =
                    Brushes.OrangeRed;
            }

            if (startButton != null)
                startButton.IsEnabled = true;

            if (stopButton != null)
                stopButton.IsEnabled = false;

            if (directionCombo != null)
                directionCombo.IsEnabled = true;

            if (accountSelector != null)
                accountSelector.IsEnabled = true;

            if (instrumentSelector != null)
                instrumentSelector.IsEnabled = true;
        }

    }
}

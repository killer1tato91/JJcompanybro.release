#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT RUNTIME COORDINATOR / SHARED STATE
    // Stage 16 structural extraction only.
    //
    // Existing Account+Instrument lease coordination,
    // runtime snapshots/shared-state registration and persistence
    // lock coordination are moved exactly as-is.
    //
    // No lease rules, keys, synchronization, persistence lock,
    // account/instrument scoping, or runtime behavior was changed.
    // =========================================================
    public class JJBotSharedSnapshot
    {
        public bool IsRunning;
        public string AccountName;
        public string InstrumentName;

        public int TradesToday;
        public int MaxTrades;
        public int AmTrades;
        public int PmTrades;

        public double RealizedPnL;
        public double UnrealizedPnL;
        public double TotalPnL;

        public bool DailyLocked;

        public string Position;
        public int PositionQty;

        public double EntryPrice;
        public double StopPrice;
        public double TargetPrice;

        public string OrderStatus;
        public string Signal;
        public string Setup;

        // Advanced visual state for JJBotChart
        public string StrategyMode;
        public string SessionWindow;
        public string H4Trend;
        public string H1Trend;
        public string HtfContextBias;

        public string M5Trend;
        public string M5VwapSide;

        // DISPLAY-ONLY COMPATIBILITY FOR JJBotChart.
        // These fields are intentionally NOT used by Recovery trading logic.
        // They exist so the newer chart panel can compile against the
        // stable JJBotSharedSnapshot contract.
        public string M5VwapLocation;
        public double M5VwapZScore;
        public double M5VwapStdDev;
        public string M5VwapBandState;
        public string M5VwapSlope;
        public string M5VwapEntryContext;

        public string M5Liquidity;
        public string M5Structure;

        public string RangeMomentum;
        public int RangeLongScore;
        public int RangeShortScore;

        public bool LearningActive;
        public int LearningPatterns;
        public int LearningTrades;

        public string TrailingState;

        public long ExecutionSequence;
        public string LastExecutionSide;
        public double LastExecutionPrice;

        public DateTime LastUpdateUtc;

        public JJBotSharedSnapshot()
        {
            AccountName = string.Empty;
            InstrumentName = string.Empty;
            Position = "FLAT";
            OrderStatus = "WAITING";
            Signal = "WAITING";
            Setup = "WAITING";

            StrategyMode = "HYBRID";
            SessionWindow = "OUTSIDE";
            H4Trend = "WAITING";
            H1Trend = "WAITING";
            HtfContextBias = "NEUTRAL 0/2";
            M5Trend = "WAITING";
            M5VwapSide = "WAITING";

            // Chart compatibility defaults only.
            M5VwapLocation = "WAITING";
            M5VwapZScore = 0;
            M5VwapStdDev = 0;
            M5VwapBandState = "WAITING";
            M5VwapSlope = "FLAT";
            M5VwapEntryContext = "NEUTRAL";

            M5Liquidity = "NONE";
            M5Structure = "WAITING";
            RangeMomentum = "WAITING RANGE";
            TrailingState = "OFF";

            LastExecutionSide = string.Empty;
            LastUpdateUtc = DateTime.MinValue;
        }

        public JJBotSharedSnapshot Clone()
        {
            return new JJBotSharedSnapshot
            {
                IsRunning = IsRunning,
                AccountName = AccountName,
                InstrumentName = InstrumentName,

                TradesToday = TradesToday,
                MaxTrades = MaxTrades,
                AmTrades = AmTrades,
                PmTrades = PmTrades,

                RealizedPnL = RealizedPnL,
                UnrealizedPnL = UnrealizedPnL,
                TotalPnL = TotalPnL,

                DailyLocked = DailyLocked,

                Position = Position,
                PositionQty = PositionQty,

                EntryPrice = EntryPrice,
                StopPrice = StopPrice,
                TargetPrice = TargetPrice,

                OrderStatus = OrderStatus,
                Signal = Signal,
                Setup = Setup,

                StrategyMode = StrategyMode,
                SessionWindow = SessionWindow,
                H4Trend = H4Trend,
                H1Trend = H1Trend,
                HtfContextBias = HtfContextBias,
                M5Trend = M5Trend,
                M5VwapSide = M5VwapSide,

                M5VwapLocation = M5VwapLocation,
                M5VwapZScore = M5VwapZScore,
                M5VwapStdDev = M5VwapStdDev,
                M5VwapBandState = M5VwapBandState,
                M5VwapSlope = M5VwapSlope,
                M5VwapEntryContext = M5VwapEntryContext,

                M5Liquidity = M5Liquidity,
                M5Structure = M5Structure,

                RangeMomentum = RangeMomentum,
                RangeLongScore = RangeLongScore,
                RangeShortScore = RangeShortScore,

                LearningActive = LearningActive,
                LearningPatterns = LearningPatterns,
                LearningTrades = LearningTrades,

                TrailingState = TrailingState,

                ExecutionSequence = ExecutionSequence,
                LastExecutionSide = LastExecutionSide,
                LastExecutionPrice = LastExecutionPrice,

                LastUpdateUtc = LastUpdateUtc
            };
        }
    }
    public static class JJBotSharedState
    {
        private static readonly object SyncRoot =
            new object();

        // V7 MULTI-INSTRUMENT:
        // One independent snapshot per Account + Instrument.
        // This prevents MES and MNQ windows from overwriting each
        // other's chart state when both bots are running together.
        private static readonly Dictionary<string, JJBotSharedSnapshot> snapshots =
            new Dictionary<string, JJBotSharedSnapshot>(
                StringComparer.OrdinalIgnoreCase
            );

        public static event Action StateChanged;

        // V7.1:
        // Removes a stale Account + Instrument state when a bot window
        // changes account/instrument. This prevents an old bot state from
        // remaining visible on a chart after the selector changes.
        public static void RemoveSnapshot(
            string accountName,
            string instrumentName)
        {
            Action handler = null;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                if (snapshots.Remove(key))
                {
                    handler =
                        StateChanged;
                }
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

       // =========================================================
// ACCOUNT + INSTRUMENT SNAPSHOT
// =========================================================
// This is the SAFE lookup used when the caller knows both
// the account and the instrument.
public static JJBotSharedSnapshot GetSnapshot(
    string accountName,
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(accountName) ||
        string.IsNullOrWhiteSpace(instrumentName)
    )
    {
        return null;
    }

    string key =
        BuildKey(
            accountName,
            instrumentName
        );

    lock (SyncRoot)
    {
        JJBotSharedSnapshot snapshot;

        if (
            !snapshots.TryGetValue(
                key,
                out snapshot
            ) ||
            snapshot == null
        )
        {
            return null;
        }

        return snapshot.Clone();
    }
}


// =========================================================
// INSTRUMENT-ONLY COMPATIBILITY LOOKUP
// =========================================================
// IMPORTANT:
// If MORE THAN ONE account has a bot running on the same
// instrument, this method intentionally returns null.
//
// It is safer to show NO LINK than randomly display the
// state of another account.
public static JJBotSharedSnapshot GetSnapshot(
    string instrumentName)
{
    if (
        string.IsNullOrWhiteSpace(
            instrumentName
        )
    )
    {
        return null;
    }

    lock (SyncRoot)
    {
        JJBotSharedSnapshot found = null;

        foreach (
            KeyValuePair<string, JJBotSharedSnapshot> pair
            in snapshots
        )
        {
            JJBotSharedSnapshot candidate =
                pair.Value;

            if (
                candidate == null ||
                string.IsNullOrWhiteSpace(
                    candidate.InstrumentName
                ) ||
                !string.Equals(
                    candidate.InstrumentName,
                    instrumentName,
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                continue;
            }

            // More than one bot is publishing the same instrument.
            // Never guess which account the chart wants.
            if (found != null)
            {
                return null;
            }

            found =
                candidate;
        }

        return found != null
            ? found.Clone()
            : null;
    }
}

        // Kept for compatibility with any older visual code.
        // Returns the most recently updated bot of any instrument.
        public static JJBotSharedSnapshot GetSnapshot()
        {
            lock (SyncRoot)
            {
                JJBotSharedSnapshot newest = null;

                foreach (
                    KeyValuePair<string, JJBotSharedSnapshot> pair
                    in snapshots
                )
                {
                    JJBotSharedSnapshot candidate =
                        pair.Value;

                    if (
                        candidate != null &&
                        (
                            newest == null ||
                            candidate.LastUpdateUtc >
                                newest.LastUpdateUtc
                        )
                    )
                    {
                        newest = candidate;
                    }
                }

                return newest != null
                    ? newest.Clone()
                    : null;
            }
        }

        public static void Update(
            bool isRunning,
            string accountName,
            string instrumentName,
            int tradesToday,
            int maxTrades,
            int amTrades,
            int pmTrades,
            double realizedPnL,
            double unrealizedPnL,
            double totalPnL,
            bool dailyLocked,
            string position,
            int positionQty,
            double entryPrice,
            double stopPrice,
            double targetPrice,
            string orderStatus,
            string signal,
            string setup,
            string strategyMode,
            string sessionWindow,
            string h4Trend,
            string h1Trend,
            string htfContextBias,
            string m5Trend,
            string m5VwapSide,
            string m5Liquidity,
            string m5Structure,
            string rangeMomentum,
            int rangeLongScore,
            int rangeShortScore,
            bool learningActive,
            int learningPatterns,
            int learningTrades,
            string trailingState)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    snapshots[key] =
                        current;
                }

                current.IsRunning =
                    isRunning;

                current.AccountName =
                    accountName ?? string.Empty;

                current.InstrumentName =
                    instrumentName ?? string.Empty;

                current.TradesToday =
                    tradesToday;

                current.MaxTrades =
                    maxTrades;

                current.AmTrades =
                    amTrades;

                current.PmTrades =
                    pmTrades;

                current.RealizedPnL =
                    realizedPnL;

                current.UnrealizedPnL =
                    unrealizedPnL;

                current.TotalPnL =
                    totalPnL;

                current.DailyLocked =
                    dailyLocked;

                current.Position =
                    string.IsNullOrWhiteSpace(
                        position
                    )
                        ? "FLAT"
                        : position;

                current.PositionQty =
                    positionQty;

                current.EntryPrice =
                    entryPrice;

                current.StopPrice =
                    stopPrice;

                current.TargetPrice =
                    targetPrice;

                current.OrderStatus =
                    orderStatus ?? "WAITING";

                current.Signal =
                    signal ?? "WAITING";

                current.Setup =
                    setup ?? "WAITING";

                current.StrategyMode =
                    strategyMode ?? "HYBRID";

                current.SessionWindow =
                    sessionWindow ?? "OUTSIDE";

                current.H4Trend =
                    h4Trend ?? "WAITING";

                current.H1Trend =
                    h1Trend ?? "WAITING";

                current.HtfContextBias =
                    htfContextBias ?? "NEUTRAL 0/2";

                current.M5Trend =
                    m5Trend ?? "WAITING";

                current.M5VwapSide =
                    m5VwapSide ?? "WAITING";

                current.M5Liquidity =
                    m5Liquidity ?? "NONE";

                current.M5Structure =
                    m5Structure ?? "WAITING";

                current.RangeMomentum =
                    rangeMomentum ?? "WAITING RANGE";

                current.RangeLongScore =
                    rangeLongScore;

                current.RangeShortScore =
                    rangeShortScore;

                current.LearningActive =
                    learningActive;

                current.LearningPatterns =
                    learningPatterns;

                current.LearningTrades =
                    learningTrades;

                current.TrailingState =
                    trailingState ?? "OFF";

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }

        public static void PublishExecution(
            string accountName,
            string instrumentName,
            string side,
            double price)
        {
            Action handler;

            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                JJBotSharedSnapshot current;

                if (
                    !snapshots.TryGetValue(
                        key,
                        out current
                    ) ||
                    current == null
                )
                {
                    current =
                        new JJBotSharedSnapshot();

                    current.AccountName =
                        accountName ?? string.Empty;

                    current.InstrumentName =
                        instrumentName ?? string.Empty;

                    snapshots[key] =
                        current;
                }

                current.ExecutionSequence++;

                current.LastExecutionSide =
                    side ?? string.Empty;

                current.LastExecutionPrice =
                    price;

                current.LastUpdateUtc =
                    DateTime.UtcNow;

                handler =
                    StateChanged;
            }

            if (handler != null)
            {
                try
                {
                    handler();
                }
                catch
                {
                }
            }
        }
    }
    public static class JJBotRuntimeCoordinator
    {
        private static readonly object SyncRoot =
            new object();

        private static readonly Dictionary<string, object>
            persistenceLocks =
                new Dictionary<string, object>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static readonly HashSet<string>
            activeBotKeys =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

        private static string BuildKey(
            string accountName,
            string instrumentName)
        {
            return
                (accountName ?? string.Empty).Trim()
                + "|"
                + (instrumentName ?? string.Empty).Trim();
        }

        public static object GetPersistenceLock(
            string accountName,
            string instrumentName)
        {
            string key =
                BuildKey(
                    accountName,
                    instrumentName
                );

            lock (SyncRoot)
            {
                object gate;

                if (
                    !persistenceLocks.TryGetValue(
                        key,
                        out gate
                    ) ||
                    gate == null
                )
                {
                    gate =
                        new object();

                    persistenceLocks[key] =
                        gate;
                }

                return gate;
            }
        }

        public static bool TryAcquireBotLease(
            string accountName,
            string instrumentName,
            out string leaseKey)
        {
            leaseKey =
                BuildKey(
                    accountName,
                    instrumentName
                );

            if (
                string.IsNullOrWhiteSpace(
                    accountName
                ) ||
                string.IsNullOrWhiteSpace(
                    instrumentName
                )
            )
            {
                leaseKey =
                    string.Empty;

                return false;
            }

            lock (SyncRoot)
            {
                if (
                    activeBotKeys.Contains(
                        leaseKey
                    )
                )
                {
                    return false;
                }

                activeBotKeys.Add(
                    leaseKey
                );

                return true;
            }
        }

        public static void ReleaseBotLease(
            string leaseKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    leaseKey
                )
            )
            {
                return;
            }

            lock (SyncRoot)
            {
                activeBotKeys.Remove(
                    leaseKey
                );
            }
        }
    }

}

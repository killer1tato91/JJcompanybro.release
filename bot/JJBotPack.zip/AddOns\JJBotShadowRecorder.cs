#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT SHADOW RECORDER
    // Extracted from JJBotControl v1.6.20 during segmentation.
    //
    // IMPORTANT:
    // Structural refactor only. No signal, execution, learning,
    // risk, timing, or Shadow Recorder behavior was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =====================================================
        // V1.6.18 - SHADOW SIGNAL RECORDER
        // Records signal candidates and forward outcomes WITHOUT submitting,
        // changing or cancelling orders. This dataset is intended for
        // walk-forward parameter validation and threshold audits.
        private sealed class JJBotShadowSignal
        {
            public string Id;
            public DateTime SignalTimeNy;
            public string Side;
            public string SessionWindow;
            public string Decision;
            public string DecisionReason;
            public double SignalPrice;
            public int MomentumScore;
            public double RangeRatio;
            public double VolumeRatio;
            public double BodyRatio;
            public double SlopeTicks;
            public bool DirectionalBreakout;
            public int AggressionScore;
            public bool AggressiveExpansion;
            public bool ExtremeMomentum;
            public string M5Trend;
            public string M5Vwap;
            public string M5Structure;
            public string M5Liquidity;
            public int HtfAlignmentScore;
            public int TechnicalQuality;
            public string SetupQuality;
            public string SetupTiming;
            public string ManipulationState;
            public double MfeTicks;
            public double MaeTicks;
            public readonly HashSet<int> WrittenHorizons =
                new HashSet<int>();
        }

        private readonly object shadowSignalLock =
            new object();

        private readonly List<JJBotShadowSignal> activeShadowSignals =
            new List<JJBotShadowSignal>();

        private readonly HashSet<string> shadowSignalIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private const bool ShadowSignalRecorderEnabled = true;
        private static readonly int[] ShadowSignalHorizonsSeconds =
            new int[] { 30, 60, 180, 300 };

        private string pendingShadowSignalId = string.Empty;


        // =====================================================
        // V1.6.18 - SHADOW SIGNAL RECORDER HELPERS
        // =====================================================
        private string BuildShadowDecisionReason(
            bool isLong,
            bool ready,
            bool directionAllowed,
            bool premarketSession,
            bool vwapAligned,
            bool m5TrendAligned,
            bool strictMiddayMomentum,
            int momentumScore,
            int htfAlignmentScore,
            bool aggressiveExpansion,
            double sessionExtensionTicks,
            bool weakCurrentExpansion)
        {
            if (ready)
                return "PASSED CURRENT SIGNAL GATES";

            if (!directionAllowed)
                return "DIRECTION FILTER";

            if (!premarketSession && !vwapAligned)
                return "VWAP FILTER";

            if (
                strictMiddayMomentum &&
                !(
                    (
                        momentumScore >= MiddayMomentumMinScore &&
                        htfAlignmentScore >= MiddayMinHtfAlignmentScore
                    ) ||
                    (
                        aggressiveExpansion &&
                        htfAlignmentScore >= MiddayMinHtfAlignmentScore
                    )
                )
            )
            {
                return "MIDDAY FILTER";
            }

            if (
                !aggressiveExpansion &&
                sessionExtensionTicks >= ExhaustionMinMoveTicks &&
                weakCurrentExpansion
            )
            {
                return "POST-MOVE EXHAUSTION";
            }

            if (!premarketSession && !m5TrendAligned)
                return "M5 TREND / MOMENTUM FILTER";

            return "SIGNAL FILTER";
        }

        private string RegisterShadowSignalCandidate(
            DateTime signalBarTime,
            DateTime signalTimeNy,
            bool isLong,
            string sessionWindow,
            string decision,
            string decisionReason,
            double signalPrice,
            int momentumScore,
            double rangeRatio,
            double volumeRatio,
            double bodyRatio,
            double slopeTicks,
            bool directionalBreakout,
            int aggressionScore,
            bool aggressiveExpansion,
            bool extremeMomentum,
            string m5Trend,
            string m5Vwap,
            string m5Structure,
            string m5Liquidity,
            int htfAlignmentScore,
            int technicalQuality,
            string setupQuality,
            string setupTiming,
            string manipulationState)
        {
            if (!ShadowSignalRecorderEnabled)
                return string.Empty;

            string side = isLong ? "LONG" : "SHORT";
            string id =
                signalBarTime.ToString("yyyyMMddHHmmss")
                + "|"
                + side;

            JJBotShadowSignal item = null;

            lock (shadowSignalLock)
            {
                if (shadowSignalIds.Contains(id))
                    return id;

                shadowSignalIds.Add(id);

                item = new JJBotShadowSignal
                {
                    Id = id,
                    SignalTimeNy = signalTimeNy,
                    Side = side,
                    SessionWindow = sessionWindow ?? string.Empty,
                    Decision = decision ?? string.Empty,
                    DecisionReason = decisionReason ?? string.Empty,
                    SignalPrice = signalPrice,
                    MomentumScore = momentumScore,
                    RangeRatio = rangeRatio,
                    VolumeRatio = volumeRatio,
                    BodyRatio = bodyRatio,
                    SlopeTicks = slopeTicks,
                    DirectionalBreakout = directionalBreakout,
                    AggressionScore = aggressionScore,
                    AggressiveExpansion = aggressiveExpansion,
                    ExtremeMomentum = extremeMomentum,
                    M5Trend = m5Trend ?? string.Empty,
                    M5Vwap = m5Vwap ?? string.Empty,
                    M5Structure = m5Structure ?? string.Empty,
                    M5Liquidity = m5Liquidity ?? string.Empty,
                    HtfAlignmentScore = htfAlignmentScore,
                    TechnicalQuality = technicalQuality,
                    SetupQuality = setupQuality ?? string.Empty,
                    SetupTiming = setupTiming ?? string.Empty,
                    ManipulationState = manipulationState ?? string.Empty,
                    MfeTicks = 0,
                    MaeTicks = 0
                };

                activeShadowSignals.Add(item);
            }

            AppendShadowSignalCsv(item, "CANDIDATE", 0, signalPrice, 0);
            return id;
        }

        private void UpdateShadowSignalDecision(
            string id,
            string decision,
            string reason)
        {
            if (
                !ShadowSignalRecorderEnabled ||
                string.IsNullOrWhiteSpace(id)
            )
            {
                return;
            }

            JJBotShadowSignal found = null;

            lock (shadowSignalLock)
            {
                for (int i = 0; i < activeShadowSignals.Count; i++)
                {
                    if (
                        string.Equals(
                            activeShadowSignals[i].Id,
                            id,
                            StringComparison.OrdinalIgnoreCase
                        )
                    )
                    {
                        found = activeShadowSignals[i];
                        found.Decision = decision ?? found.Decision;
                        found.DecisionReason = reason ?? found.DecisionReason;
                        break;
                    }
                }
            }

            if (found != null)
                AppendShadowSignalCsv(found, "DECISION", 0, found.SignalPrice, 0);
        }

        private void UpdateShadowSignalOutcomes(
            DateTime currentTimeNy,
            double currentClose,
            double currentHigh,
            double currentLow,
            double tickSize)
        {
            if (
                !ShadowSignalRecorderEnabled ||
                tickSize <= 0
            )
            {
                return;
            }

            List<Tuple<JJBotShadowSignal, int, double>> writes =
                new List<Tuple<JJBotShadowSignal, int, double>>();

            lock (shadowSignalLock)
            {
                for (int i = activeShadowSignals.Count - 1; i >= 0; i--)
                {
                    JJBotShadowSignal item = activeShadowSignals[i];
                    if (item == null)
                    {
                        activeShadowSignals.RemoveAt(i);
                        continue;
                    }

                    double favorableTicks;
                    double adverseTicks;

                    if (item.Side == "LONG")
                    {
                        favorableTicks =
                            (currentHigh - item.SignalPrice) / tickSize;
                        adverseTicks =
                            (currentLow - item.SignalPrice) / tickSize;
                    }
                    else
                    {
                        favorableTicks =
                            (item.SignalPrice - currentLow) / tickSize;
                        adverseTicks =
                            (item.SignalPrice - currentHigh) / tickSize;
                    }

                    item.MfeTicks =
                        Math.Max(item.MfeTicks, favorableTicks);
                    item.MaeTicks =
                        Math.Min(item.MaeTicks, adverseTicks);

                    int elapsedSeconds =
                        Math.Max(
                            0,
                            (int)Math.Floor(
                                (currentTimeNy - item.SignalTimeNy).TotalSeconds
                            )
                        );

                    for (int h = 0; h < ShadowSignalHorizonsSeconds.Length; h++)
                    {
                        int horizon = ShadowSignalHorizonsSeconds[h];
                        if (
                            elapsedSeconds >= horizon &&
                            !item.WrittenHorizons.Contains(horizon)
                        )
                        {
                            item.WrittenHorizons.Add(horizon);

                            double moveTicks =
                                item.Side == "LONG"
                                    ? (currentClose - item.SignalPrice) / tickSize
                                    : (item.SignalPrice - currentClose) / tickSize;

                            writes.Add(
                                Tuple.Create(item, horizon, moveTicks)
                            );
                        }
                    }

                    if (
                        item.WrittenHorizons.Contains(300) ||
                        elapsedSeconds > 900
                    )
                    {
                        activeShadowSignals.RemoveAt(i);
                    }
                }
            }

            for (int i = 0; i < writes.Count; i++)
            {
                AppendShadowSignalCsv(
                    writes[i].Item1,
                    "OUTCOME",
                    writes[i].Item2,
                    currentClose,
                    writes[i].Item3
                );
            }
        }

        private string GetShadowSignalFolderPath()
        {
            string root = stateFolderPath;

            if (string.IsNullOrWhiteSpace(root))
            {
                root = Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments
                    ),
                    "NinjaTrader 8",
                    "JJBotData"
                );
            }

            return Path.Combine(root, "ShadowSignals");
        }

        private void AppendShadowSignalCsv(
            JJBotShadowSignal item,
            string eventType,
            int horizonSeconds,
            double observedPrice,
            double moveTicks)
        {
            if (item == null)
                return;

            try
            {
                string folder = GetShadowSignalFolderPath();
                Directory.CreateDirectory(folder);

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : "UNKNOWN";

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : "UNKNOWN";

                string safeAccount =
                    Regex.Replace(accountName, "[^A-Za-z0-9_.-]", "_");
                string safeInstrument =
                    Regex.Replace(instrumentName, "[^A-Za-z0-9_.-]", "_");

                string filePath =
                    Path.Combine(
                        folder,
                        "shadow_"
                        + safeAccount
                        + "_"
                        + safeInstrument
                        + "_"
                        + item.SignalTimeNy.ToString("yyyyMMdd")
                        + ".csv"
                    );

                bool writeHeader = !File.Exists(filePath);

                StringBuilder line = new StringBuilder();
                line.Append(CsvShadow(item.Id)).Append(',');
                line.Append(CsvShadow(eventType)).Append(',');
                line.Append(CsvShadow(item.SignalTimeNy.ToString("o"))).Append(',');
                line.Append(CsvShadow(accountName)).Append(',');
                line.Append(CsvShadow(instrumentName)).Append(',');
                line.Append(CsvShadow(item.Side)).Append(',');
                line.Append(CsvShadow(item.SessionWindow)).Append(',');
                line.Append(CsvShadow(item.Decision)).Append(',');
                line.Append(CsvShadow(item.DecisionReason)).Append(',');
                line.Append(item.SignalPrice.ToString("0.########", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MomentumScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.RangeRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.VolumeRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.BodyRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.SlopeTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.DirectionalBreakout ? "1" : "0").Append(',');
                line.Append(item.AggressionScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.AggressiveExpansion ? "1" : "0").Append(',');
                line.Append(item.ExtremeMomentum ? "1" : "0").Append(',');
                line.Append(CsvShadow(item.M5Trend)).Append(',');
                line.Append(CsvShadow(item.M5Vwap)).Append(',');
                line.Append(CsvShadow(item.M5Structure)).Append(',');
                line.Append(CsvShadow(item.M5Liquidity)).Append(',');
                line.Append(item.HtfAlignmentScore.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.TechnicalQuality.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(CsvShadow(item.SetupQuality)).Append(',');
                line.Append(CsvShadow(item.SetupTiming)).Append(',');
                line.Append(CsvShadow(item.ManipulationState)).Append(',');
                line.Append(horizonSeconds.ToString(CultureInfo.InvariantCulture)).Append(',');
                line.Append(observedPrice.ToString("0.########", CultureInfo.InvariantCulture)).Append(',');
                line.Append(moveTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MfeTicks.ToString("0.####", CultureInfo.InvariantCulture)).Append(',');
                line.Append(item.MaeTicks.ToString("0.####", CultureInfo.InvariantCulture));

                string header =
                    "CandidateId,EventType,SignalTimeNY,Account,Instrument,Side,Session,Decision,DecisionReason,SignalPrice,R20,RangeRatio,VolumeRatio,BodyRatio,EmaSlopeTicks,Breakout,AggressionScore,AggressiveExpansion,ExtremeMomentum,M5Trend,M5VWAP,M5Structure,M5Liquidity,HTFAlignment,TechnicalQuality,SetupQuality,SetupTiming,Manipulation,HorizonSeconds,ObservedPrice,MoveTicks,MfeTicks,MaeTicks";

                lock (shadowSignalLock)
                {
                    if (writeHeader)
                        File.AppendAllText(filePath, header + Environment.NewLine, Encoding.UTF8);

                    File.AppendAllText(
                        filePath,
                        line.ToString() + Environment.NewLine,
                        Encoding.UTF8
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SHADOW RECORDER ERROR | " + ex.Message
                );
            }
        }

        private string CsvShadow(string value)
        {
            string text = value ?? string.Empty;
            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }


    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT M5 SIGNAL / STRUCTURE ENGINE
    // Stage 13 structural extraction only.
    //
    // Existing M5 signal evaluation, VWAP, liquidity sweep,
    // BOS/CHOCH, structure setup keys, quality scoring and
    // mature-move protection are moved exactly as-is.
    //
    // No thresholds, scoring, timing, entry conditions,
    // execution behavior or learning behavior was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private bool TryGetLatestM5StructureBreakLevel(
            Bars bars,
            int closedBarIndex,
            bool isLong,
            out double level)
        {
            level = 0;
            if (bars == null || closedBarIndex < SweepLookback + StructureLookback)
                return false;

            int firstSweepIndex = Math.Max(SweepLookback, closedBarIndex - SweepMaxAgeBars);
            int bestConfirm = -1;
            double bestLevel = 0;

            for (int sweepIndex = firstSweepIndex; sweepIndex <= closedBarIndex; sweepIndex++)
            {
                int priorStart = Math.Max(0, sweepIndex - SweepLookback);
                int priorEnd = sweepIndex - 1;
                if (priorEnd <= priorStart) continue;

                double priorLow = GetLowestLow(bars, priorStart, priorEnd);
                double priorHigh = GetHighestHigh(bars, priorStart, priorEnd);
                double sweepLow = bars.GetLow(sweepIndex);
                double sweepHigh = bars.GetHigh(sweepIndex);
                double sweepClose = bars.GetClose(sweepIndex);
                double tickSize = selectedInstrument != null && selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize : 0;
                if (tickSize <= 0) return false;

                bool sweep = isLong
                    ? (priorLow - sweepLow >= MinimumSweepTicks * tickSize && sweepClose > priorLow)
                    : (sweepHigh - priorHigh >= MinimumSweepTicks * tickSize && sweepClose < priorHigh);
                if (!sweep) continue;

                int structureStart = Math.Max(0, sweepIndex - StructureLookback);
                double structureLevel = isLong
                    ? GetHighestHigh(bars, structureStart, sweepIndex - 1)
                    : GetLowestLow(bars, structureStart, sweepIndex - 1);

                for (int confirmIndex = sweepIndex + 1; confirmIndex <= closedBarIndex; confirmIndex++)
                {
                    double c = bars.GetClose(confirmIndex);
                    bool confirmed = isLong ? c > structureLevel : c < structureLevel;
                    if (confirmed)
                    {
                        if (confirmIndex >= bestConfirm)
                        {
                            bestConfirm = confirmIndex;
                            bestLevel = structureLevel;
                        }
                        break;
                    }
                }
            }

            if (bestConfirm < 0 || bestLevel <= 0)
                return false;

            level = bestLevel;
            return true;
        }
        private void UpdateSignalFromBars(
            Bars bars,
            bool checkClosedBarCross)
        {
            if (
                bars == null ||
                bars.Count < SlowEmaPeriod + 10
            )
            {
                return;
            }

            int lastIndex =
                bars.Count - 1;

            // lastIndex is the currently forming 5-minute bar.
            // The previous bar is the last fully confirmed/closed bar.
            int closedBarIndex =
                Math.Max(
                    0,
                    lastIndex - 1
                );

            // =================================================
            // CLOSED BAR VALUES FOR SIGNAL DECISIONS
            //
            // IMPORTANT:
            // EMA, price, VWAP, trend, liquidity and structure
            // are all evaluated from the SAME confirmed 5m bar.
            // =================================================
            double emaFastCurrent =
                CalculateEma(
                    bars,
                    FastEmaPeriod,
                    closedBarIndex
                );

            double emaSlowCurrent =
                CalculateEma(
                    bars,
                    SlowEmaPeriod,
                    closedBarIndex
                );

            double lastPrice =
                bars.GetClose(
                    closedBarIndex
                );

            DateTime closedBarTime =
                bars.GetTime(
                    closedBarIndex
                );

            DateTime decisionNyTime =
                ConvertToNewYorkTime(
                    closedBarTime
                );

            EnsureTradingDay(
                decisionNyTime
            );

            double currentVwap;
            double currentVwapStdDev;
            double currentVwapUpper1;
            double currentVwapUpper2;
            double currentVwapLower1;
            double currentVwapLower2;

            CalculateSessionVwapContext(
                bars,
                closedBarIndex,
                out currentVwap,
                out currentVwapStdDev,
                out currentVwapUpper1,
                out currentVwapUpper2,
                out currentVwapLower1,
                out currentVwapLower2
            );

            double currentVwapZScore =
                currentVwapStdDev > 0
                    ? (lastPrice - currentVwap) / currentVwapStdDev
                    : 0;

            double currentVwapBandWidth =
                currentVwapUpper2 > 0 &&
                currentVwapLower2 > 0
                    ? currentVwapUpper2 - currentVwapLower2
                    : 0;

            string currentVwapLocation =
                ClassifyVwapLocation(
                    currentVwapZScore
                );

            string currentVwapSlope;
            string currentVwapBandState;
            string currentVwapEntryContext;
            double currentVwapBandWidthRatio;

            lock (marketContextLock)
            {
                currentVwapSlope =
                    ClassifyVwapSlope(
                        currentVwap,
                        latestM5Vwap,
                        selectedInstrument != null &&
                        selectedInstrument.MasterInstrument != null
                            ? selectedInstrument.MasterInstrument.TickSize
                            : 0.25
                    );

                currentVwapBandState =
                    UpdateVwapBandStateLocked(
                        decisionNyTime.Date,
                        currentVwapBandWidth,
                        out currentVwapBandWidthRatio
                    );

                currentVwapEntryContext =
                    ResolveVwapEntryContext(
                        currentVwapLocation,
                        currentVwapBandState,
                        currentVwapSlope
                    );
            }

            bool bullishTrend =
                emaFastCurrent >
                emaSlowCurrent;

            bool bearishTrend =
                emaFastCurrent <
                emaSlowCurrent;

            bool aboveVwap =
                currentVwap > 0 &&
                lastPrice > currentVwap;

            bool belowVwap =
                currentVwap > 0 &&
                lastPrice < currentVwap;

            bool nySessionActive =
                IsBotNySessionActive(
                    decisionNyTime
                );

            bool premarketSession =
                IsPremarketSession(
                    decisionNyTime
                );

            if (premarketSession)
            {
                TryBuildPremarketRangeFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );

                UpdatePremarketContextFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );
            }
            else if (
                ToTimeInt(decisionNyTime) >= 92500 &&
                ToTimeInt(decisionNyTime) <= 100000 &&
                premarketContextDateNy != decisionNyTime.Date
            )
            {
                // A bot started shortly before/at the open still reconstructs
                // the completed premarket map from historical M5 bars.
                UpdatePremarketContextFromBars(
                    bars,
                    closedBarIndex,
                    decisionNyTime.Date
                );
            }

            // Unrealized PnL must continue using the live/forming bar.
            double livePrice =
                bars.GetClose(
                    lastIndex
                );

            UpdateBreakevenFollowThrough(
                bars.GetHigh(
                    lastIndex
                ),
                bars.GetLow(
                    lastIndex
                ),
                ConvertToNewYorkTime(
                    bars.GetTime(
                        lastIndex
                    )
                )
            );

            UpdateUnrealizedPnL(
                livePrice
            );

            CheckForceFlatTime();
            CheckDailyLossEmergency();

            string trend =
                bullishTrend
                    ? "BULLISH"
                    : bearishTrend
                        ? "BEARISH"
                        : "NEUTRAL";

            Brush trendBrush =
                bullishTrend
                    ? Brushes.LimeGreen
                    : bearishTrend
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // CLOSED-BAR STRUCTURE ANALYSIS
            // =================================================
            string liquidityState;
            string structureState;

            bool bullishStructureConfirmed;
            bool bearishStructureConfirmed;

            string bullishStructureSetupKey;
            string bearishStructureSetupKey;

            DetectLiquidityAndStructure(
                bars,
                closedBarIndex,
                out liquidityState,
                out structureState,
                out bullishStructureConfirmed,
                out bearishStructureConfirmed,
                out bullishStructureSetupKey,
                out bearishStructureSetupKey
            );

            Brush liquidityBrush =
                liquidityState == "LOW SWEPT"
                    ? Brushes.LimeGreen
                    : liquidityState == "HIGH SWEPT"
                        ? Brushes.OrangeRed
                        : liquidityState == "BOTH SWEPT"
                            ? Brushes.MediumPurple
                            : Brushes.Gray;

            Brush structureBrush =
                bullishStructureConfirmed
                    ? Brushes.LimeGreen
                    : bearishStructureConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            // =================================================
            // MOMENTUM ENGINE V2
            // Momentum is calculated by the INTERNAL Range-20
            // series. M5 supplies context only.
            // =================================================
            int longMomentumScore;
            int shortMomentumScore;
            double rangeRatio;
            double volumeRatio;
            double bodyRatio;
            double emaFastSlope;
            bool highBreakout;
            bool lowBreakout;
            string momentumState;

            lock (marketContextLock)
            {
                longMomentumScore =
                    latestRangeLongScore;

                shortMomentumScore =
                    latestRangeShortScore;

                rangeRatio =
                    latestRangeRatio;

                volumeRatio =
                    latestRangeVolumeRatio;

                bodyRatio =
                    latestRangeBodyRatio;

                emaFastSlope =
                    latestRangeEmaSlope;

                highBreakout =
                    latestRangeHighBreakout;

                lowBreakout =
                    latestRangeLowBreakout;

                momentumState =
                    latestRangeMomentumState;
            }

            bool bullishMomentumConfirmed =
                longMomentumScore >= MomentumMinScore;

            bool bearishMomentumConfirmed =
                shortMomentumScore >= MomentumMinScore;

            Brush momentumBrush =
                bullishMomentumConfirmed
                    ? Brushes.LimeGreen
                    : bearishMomentumConfirmed
                        ? Brushes.OrangeRed
                        : Brushes.Goldenrod;

            double bullishStructureBreakLevel = 0;
            double bearishStructureBreakLevel = 0;
            TryGetLatestM5StructureBreakLevel(
                bars, closedBarIndex, true, out bullishStructureBreakLevel
            );
            TryGetLatestM5StructureBreakLevel(
                bars, closedBarIndex, false, out bearishStructureBreakLevel
            );

            // V1.6.30 - nearby structural map for entry-location quality.
            // Exclude the current closed bar so its own breakout wick does not
            // become the resistance/support we are trying to measure.
            double recentStructureHigh = 0;
            double recentStructureLow = 0;
            int locationEndIndex = closedBarIndex - 1;
            if (locationEndIndex >= 0)
            {
                int locationStartIndex = Math.Max(
                    0,
                    locationEndIndex - EntryLocationLookbackM5Bars + 1
                );

                if (locationEndIndex >= locationStartIndex)
                {
                    recentStructureHigh = GetHighestHigh(
                        bars,
                        locationStartIndex,
                        locationEndIndex
                    );

                    recentStructureLow = GetLowestLow(
                        bars,
                        locationStartIndex,
                        locationEndIndex
                    );
                }
            }

            // Publish the latest confirmed M5 context so Range
            // momentum can use it as its directional filter.
            lock (marketContextLock)
            {
                latestM5ContextReady = true;
                latestM5BullishTrend = bullishTrend;
                latestM5BearishTrend = bearishTrend;
                latestM5AboveVwap = aboveVwap;
                latestM5BelowVwap = belowVwap;
                latestM5BullishStructure =
                    bullishStructureConfirmed;
                latestM5BearishStructure =
                    bearishStructureConfirmed;
                latestM5LiquidityState =
                    liquidityState;
                latestM5StructureState =
                    structureState;
                latestM5DecisionNyTime =
                    decisionNyTime;
                latestM5Vwap =
                    currentVwap;

                latestM5VwapStdDev =
                    currentVwapStdDev;
                latestM5VwapUpper1 =
                    currentVwapUpper1;
                latestM5VwapUpper2 =
                    currentVwapUpper2;
                latestM5VwapLower1 =
                    currentVwapLower1;
                latestM5VwapLower2 =
                    currentVwapLower2;
                latestM5VwapZScore =
                    currentVwapZScore;
                latestM5VwapBandWidth =
                    currentVwapBandWidth;
                latestM5VwapBandWidthRatio =
                    currentVwapBandWidthRatio;
                latestM5VwapLocation =
                    currentVwapLocation;
                latestM5VwapBandState =
                    currentVwapBandState;
                latestM5VwapSlope =
                    currentVwapSlope;
                latestM5VwapEntryContext =
                    currentVwapEntryContext;

                latestM5BullishStructureBreakLevel =
                    bullishStructureBreakLevel;
                latestM5BearishStructureBreakLevel =
                    bearishStructureBreakLevel;
                latestM5DecisionPrice =
                    lastPrice;
                latestM5RecentStructureHigh =
                    recentStructureHigh;
                latestM5RecentStructureLow =
                    recentStructureLow;
            }

            // =================================================
            // DIRECTION FILTER
            // =================================================
            string direction =
                ResolveEffectiveDirection(
                    decisionNyTime,
                    lastPrice,
                    bullishTrend,
                    bearishTrend,
                    aboveVwap,
                    belowVwap
                );

            bool allowLong =
                direction == "BOTH" ||
                direction == "LONG ONLY";

            bool allowShort =
                direction == "BOTH" ||
                direction == "SHORT ONLY";

            // =================================================
            // V12 OPENING MODE
            // =================================================
            bool openingModeEnabled =
                activeStrategyMode == "OPENING" ||
                activeStrategyMode == "HYBRID";

            bool openingWindow =
                IsOpeningEntryWindow(
                    decisionNyTime
                );

            bool openingPriority =
                IsOpeningPriorityActive(
                    decisionNyTime
                );

            // V1.6.2:
            // 09:30-09:35 is reserved ONLY to build the opening range.
            // No Structure/Momentum entry can consume an AM slot there.
            bool openingBuildLock =
                IsOpeningBuildWindow(
                    decisionNyTime
                );

            if (
                openingModeEnabled &&
                openingWindow
            )
            {
                if (
                    !preEntryRangeReady ||
                    preEntryRangeDateNy !=
                        decisionNyTime.Date
                )
                {
                    TryBuildPreEntryRangeFromBars(
                        bars,
                        closedBarIndex,
                        decisionNyTime.Date
                    );
                }

                if (!openingRangeReady)
                {
                    TryBuildOpeningRangeFromBars(
                        bars,
                        closedBarIndex,
                        decisionNyTime.Date
                    );
                }
            }

            if (
                openingModeEnabled &&
                openingWindow &&
                premarketContextReady &&
                premarketContextDateNy == decisionNyTime.Date
            )
            {
                // The opening engine now consumes the premarket map as context.
                // It remains confirmation/statistics rather than a standalone trigger.
                currentSetupState =
                    "OPENING | PM " + premarketContextBias
                    + " | PM H/L " + premarketRangeHigh.ToString("0.00")
                    + "/" + premarketRangeLow.ToString("0.00");
            }

            bool openingLongReady =
                false;

            bool openingShortReady =
                false;

            // V1.6.31R4 - OPENING PRESSURE COMPATIBILITY
            // The old latestOpeningPressure* snapshot fields were removed
            // from the modular bot. Use the current Directional Pressure
            // engine directly so SignalEngine, DirectionalPressure and
            // ExecutionEngine all consume the same live context.
            int openingLongPressureScore;
            int openingShortPressureScore;

            string currentOpeningPressure =
                EvaluateDirectionalPressure(
                    out openingLongPressureScore,
                    out openingShortPressureScore
                );

            bool openingPressureLongAligned =
                string.Equals(
                    currentOpeningPressure,
                    "LONG",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                openingLongPressureScore >= 3 &&
                openingShortPressureScore <= 1;

            bool openingPressureShortAligned =
                string.Equals(
                    currentOpeningPressure,
                    "SHORT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                openingShortPressureScore >= 3 &&
                openingLongPressureScore <= 1;

            if (
                openingModeEnabled &&
                openingWindow &&
                openingRangeReady &&
                !openingRangeGuardBlocked &&
                !openingTradeTakenToday &&
                decisionNyTime >
                    openingRangeBarTimeNy
            )
            {
                double openingBuffer =
                    selectedInstrument != null
                        ? selectedInstrument
                            .MasterInstrument
                            .TickSize
                            * OpeningBreakoutBufferTicks
                        : 0;

                // V1.6.31: M5 Opening is now a confirmation/fallback path.
                // The live Range pressure engine must agree with the side.
                openingLongReady =
                    allowLong &&
                    openingPressureLongAligned &&
                    bullishTrend &&
                    aboveVwap &&
                    lastPrice >=
                        openingRangeHigh +
                        openingBuffer;

                openingShortReady =
                    allowShort &&
                    openingPressureShortAligned &&
                    bearishTrend &&
                    belowVwap &&
                    lastPrice <=
                        openingRangeLow -
                        openingBuffer;

                if (openingLongReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (
                        IsOpeningPriceChaseBlocked(
                            true,
                            lastPrice,
                            out extensionPoints,
                            out maxExtensionPoints
                        )
                    )
                    {
                        openingLongReady =
                            false;

                        LogOpeningPriceChaseBlock(
                            true,
                            decisionNyTime,
                            lastPrice,
                            extensionPoints,
                            maxExtensionPoints
                        );
                    }
                }

                if (openingShortReady)
                {
                    double extensionPoints;
                    double maxExtensionPoints;

                    if (
                        IsOpeningPriceChaseBlocked(
                            false,
                            lastPrice,
                            out extensionPoints,
                            out maxExtensionPoints
                        )
                    )
                    {
                        openingShortReady =
                            false;

                        LogOpeningPriceChaseBlock(
                            false,
                            decisionNyTime,
                            lastPrice,
                            extensionPoints,
                            maxExtensionPoints
                        );
                    }
                }
            }

            // =================================================
            // FINAL CONDITIONS
            // =================================================
            // Premarket V1 is momentum-only. Structure remains RTH/Midday/PM
            // so the new early window cannot silently change the proven M5 path.
            bool structureLongReady =
                nySessionActive &&
                !premarketSession &&
                allowLong &&
                bullishTrend &&
                aboveVwap &&
                bullishStructureConfirmed;

            bool structureShortReady =
                nySessionActive &&
                !premarketSession &&
                allowShort &&
                bearishTrend &&
                belowVwap &&
                bearishStructureConfirmed;

            string decisionSessionWindow =
                GetBotSessionWindow(
                    decisionNyTime
                );

            bool strictMidday =
                string.Equals(
                    decisionSessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                );

            if (strictMidday)
            {
                structureLongReady =
                    structureLongReady &&
                    latestHtfLongScore >=
                        MiddayMinHtfAlignmentScore;

                structureShortReady =
                    structureShortReady &&
                    latestHtfShortScore >=
                        MiddayMinHtfAlignmentScore;
            }

            // Structure entries are evaluated on confirmed M5 bars.
            // Momentum entries are evaluated separately by Range-20.
            // Do not duplicate Range momentum state inside the M5 engine.

            bool structureModeEnabled =
                activeStrategyMode == "STRUCTURE" ||
                activeStrategyMode == "HYBRID";

            bool openingSignalPresent =
                openingLongReady ||
                openingShortReady;

            bool rawLongReady =
                structureModeEnabled &&
                !openingBuildLock &&
                !openingSignalPresent &&
                structureLongReady;

            bool rawShortReady =
                structureModeEnabled &&
                !openingBuildLock &&
                !openingSignalPresent &&
                structureShortReady;

            // =====================================================
            // V1.6.10 - GLOBAL STRUCTURE MATURE-MOVE GUARD
            // =====================================================
            // A 4/4 BOS/CHOCH can remain valid after the directional leg is
            // already mature. When Range continuation is weak (<=2/5, <=1.0x
            // volume and no fresh breakout), wait instead of entering the tail.
            double structureTickSize =
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
                    ? selectedInstrument.MasterInstrument.TickSize
                    : 0;

            double structureUpMoveTicks;
            double structureDownMoveTicks;

            CalculateSessionMoveExtensionTicks(
                bars,
                closedBarIndex,
                decisionNyTime,
                structureTickSize,
                out structureUpMoveTicks,
                out structureDownMoveTicks
            );

            bool weakLongContinuation =
                longMomentumScore <= StructureExhaustionMaxMomentumScore &&
                volumeRatio <= StructureExhaustionMaxVolumeRatio &&
                !highBreakout;

            bool weakShortContinuation =
                shortMomentumScore <= StructureExhaustionMaxMomentumScore &&
                volumeRatio <= StructureExhaustionMaxVolumeRatio &&
                !lowBreakout;

            if (
                rawLongReady &&
                structureUpMoveTicks >= StructureExhaustionMinMoveTicks &&
                weakLongContinuation
            )
            {
                LogStructureMatureMoveBlock(
                    true, decisionNyTime, structureUpMoveTicks,
                    longMomentumScore, volumeRatio, highBreakout
                );
                rawLongReady = false;
            }

            if (
                rawShortReady &&
                structureDownMoveTicks >= StructureExhaustionMinMoveTicks &&
                weakShortContinuation
            )
            {
                LogStructureMatureMoveBlock(
                    false, decisionNyTime, structureDownMoveTicks,
                    shortMomentumScore, volumeRatio, lowBreakout
                );
                rawShortReady = false;
            }

            string longLearningLookupContext =
                structureState;

            string shortLearningLookupContext =
                structureState;

            string learningLongReason;
            string learningShortReason;

            bool learningLongAllowed =
                IsLearningTradeAllowed(
                    "LONG",
                    decisionNyTime,
                    longLearningLookupContext,
                    out learningLongReason
                );

            bool learningShortAllowed =
                IsLearningTradeAllowed(
                    "SHORT",
                    decisionNyTime,
                    shortLearningLookupContext,
                    out learningShortReason
                );

            bool openingLearningAllowed =
                true;

            string openingLearningReason =
                string.Empty;

            if (
                openingLongReady ||
                openingShortReady
            )
            {
                openingLearningAllowed =
                    IsLearningTradeAllowed(
                        openingLongReady
                            ? "LONG"
                            : "SHORT",
                        decisionNyTime,
                        "OPENING BREAKOUT",
                        out openingLearningReason
                    );
            }

            bool openingReady =
                (openingLongReady || openingShortReady) &&
                openingLearningAllowed;

            bool longReady =
                rawLongReady &&
                learningLongAllowed;

            bool shortReady =
                rawShortReady &&
                learningShortAllowed;

            double totalBotPnL =
                botDailyPnL +
                botUnrealizedPnL;

            string currentSessionWindow =
                decisionSessionWindow;

            bool sessionTradeLocked =
                IsSessionTradeLimitReached(
                    currentSessionWindow
                );

            bool dailyRiskLocked =
                persistentDailyLocked ||
                totalBotPnL >= activeDailyTarget ||
                totalBotPnL <= -activeDailyLoss;

            if (
                !persistentDailyLocked &&
                (
                    totalBotPnL >= activeDailyTarget ||
                    totalBotPnL <= -activeDailyLoss
                )
            )
            {
                SetPersistentDailyLock(
                    totalBotPnL >= activeDailyTarget
                        ? "DAILY TARGET"
                        : "DAILY LOSS"
                );
            }

            if (
                dailyRiskLocked ||
                sessionTradeLocked
            )
            {
                longReady = false;
                shortReady = false;
                openingReady = false;
            }

            string confirmation =
                longReady || shortReady
                    ? "READY"
                    : "WAITING";

            Brush confirmationBrush =
                longReady
                    ? Brushes.LimeGreen
                    : shortReady
                        ? Brushes.OrangeRed
                        : Brushes.Gray;

            string setup;
            Brush setupBrush;

            string signal;
            Brush signalBrush;

            if (dailyRiskLocked)
            {
                setup =
                    "DAILY RISK LOCK";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "DAILY RISK LOCK";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (sessionTradeLocked)
            {
                setup =
                    currentSessionWindow
                    + " TRADE LIMIT";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    currentSessionWindow
                    + " LOCKED "
                    + GetSessionTradeCount(
                        currentSessionWindow
                    )
                    + "/"
                    + GetSessionTradeLimit(
                        currentSessionWindow
                    );

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (!nySessionActive)
            {
                setup =
                    "OUTSIDE NY SESSION";

                setupBrush =
                    Brushes.Gray;

                signal =
                    "OUTSIDE NY SESSION";

                signalBrush =
                    Brushes.Gray;
            }
            else if (
                (openingLongReady || openingShortReady) &&
                !openingLearningAllowed
            )
            {
                setup =
                    "OPENING LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "OPENING EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (openingReady)
            {
                setup =
                    openingLongReady
                        ? "OPENING LONG READY"
                        : "OPENING SHORT READY";

                setupBrush =
                    openingLongReady
                        ? Brushes.LimeGreen
                        : Brushes.OrangeRed;

                signal =
                    openingLongReady
                        ? "OPENING LONG SIGNAL"
                        : "OPENING SHORT SIGNAL";

                signalBrush =
                    openingLongReady
                        ? Brushes.LimeGreen
                        : Brushes.OrangeRed;
            }
            else if (openingBuildLock)
            {
                setup =
                    "OPENING BUILD";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "BUILDING OPENING RANGE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                openingPriority &&
                !openingSignalPresent &&
                !longReady &&
                !shortReady
            )
            {
                // Opening gets the first look. If there is no Opening
                // breakout, valid Structure/Momentum setups may fall through.
                setup =
                    "OPENING WATCH";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    openingRangeReady
                        ? "WAIT OPENING / FALLBACK READY"
                        : "WAIT OPENING RANGE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                rawLongReady &&
                !learningLongAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "LONG EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                rawShortReady &&
                !learningShortAllowed
            )
            {
                setup =
                    "LEARNING BLOCK";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "SHORT EDGE TOO LOW";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (longReady)
            {
                setup =
                    "LONG READY";

                setupBrush =
                    Brushes.LimeGreen;

                signal =
                    "LONG SIGNAL";

                signalBrush =
                    Brushes.LimeGreen;
            }
            else if (shortReady)
            {
                setup =
                    "SHORT READY";

                setupBrush =
                    Brushes.OrangeRed;

                signal =
                    "SHORT SIGNAL";

                signalBrush =
                    Brushes.OrangeRed;
            }
            else if (
                liquidityState != "NONE" &&
                !bullishStructureConfirmed &&
                !bearishStructureConfirmed
            )
            {
                // V1.6.50: PREMARKET is momentum-only.  BOS/CHOCH is not an
                // entry requirement in this window, so do not report a false
                // structure veto.  The Momentum engine is waiting for a fresh
                // R20/price break with Level II aggression confirmation.
                setup =
                    premarketSession
                        ? "PREMARKET MOMENTUM WATCH"
                        : "WAIT BOS/CHOCH";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    premarketSession
                        ? "WAIT R20 / AGGRESSION"
                        : "WAITING STRUCTURE";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else if (
                bullishStructureConfirmed ||
                bearishStructureConfirmed
            )
            {
                setup =
                    "FILTERED";

                setupBrush =
                    Brushes.Goldenrod;

                signal =
                    "FILTERS NOT ALIGNED";

                signalBrush =
                    Brushes.Goldenrod;
            }
            else
            {
                setup =
                    "WAIT LIQUIDITY";

                setupBrush =
                    Brushes.Gray;

                signal =
                    bullishTrend
                        ? "BULLISH"
                        : bearishTrend
                            ? "BEARISH"
                            : "WAITING";

                signalBrush =
                    bullishTrend
                        ? Brushes.LimeGreen
                        : bearishTrend
                            ? Brushes.OrangeRed
                            : Brushes.Gray;
            }

            // =================================================
            // OUTPUT ONLY WHEN A NEW 5M BAR IS CONFIRMED
            // =================================================
            if (checkClosedBarCross)
            {
                string vwapSide =
                    currentVwap <= 0
                        ? "VWAP N/A"
                        : aboveVwap
                            ? "ABOVE VWAP"
                            : belowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                // Diagnostic score.
                // The score is informational only and does NOT change
                // the actual entry conditions above.
                int buyScore = 0;
                int sellScore = 0;

                List<string> buyMissing =
                    new List<string>();

                List<string> sellMissing =
                    new List<string>();

                if (bullishTrend)
                    buyScore++;
                else
                    buyMissing.Add("Trend");

                if (aboveVwap)
                    buyScore++;
                else
                    buyMissing.Add("VWAP");

                if (
                    liquidityState == "LOW SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    buyScore++;
                else
                    buyMissing.Add("Low Sweep");

                if (bullishStructureConfirmed)
                    buyScore++;
                else
                    buyMissing.Add("Bullish Structure");

                if (bearishTrend)
                    sellScore++;
                else
                    sellMissing.Add("Trend");

                if (belowVwap)
                    sellScore++;
                else
                    sellMissing.Add("VWAP");

                if (
                    liquidityState == "HIGH SWEPT" ||
                    liquidityState == "BOTH SWEPT"
                )
                    sellScore++;
                else
                    sellMissing.Add("High Sweep");

                if (bearishStructureConfirmed)
                    sellScore++;
                else
                    sellMissing.Add("Bearish Structure");

                PrintBotMessage(
                    "DECISION"
                    + " | "
                    + decisionNyTime.ToString("HH:mm")
                    + " ET"
                    + " | Trend: "
                    + trend
                    + " | "
                    + vwapSide
                    + " | Sweep: "
                    + liquidityState
                    + " | Structure: "
                    + structureState
                    + " | Session: "
                    + (
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED"
                    )
                    + " | Strategy: "
                    + activeStrategyMode
                    + " | Momentum: "
                    + momentumState
                    + " | Setup: "
                    + setup
                );

                PrintBotMessage(
                    "RANGE MOMENTUM "
                    + MomentumRangeTicks
                    + "T"
                    + " | LONG: "
                    + longMomentumScore
                    + "/5"
                    + " | SHORT: "
                    + shortMomentumScore
                    + "/5"
                    + " | Range x"
                    + rangeRatio.ToString("0.00")
                    + " | Volume x"
                    + volumeRatio.ToString("0.00")
                    + " | Body "
                    + (bodyRatio * 100.0).ToString("0")
                    + "%"
                    + " | EMA9 Slope: "
                    + emaFastSlope.ToString("0.00")
                    + " | Breakout: "
                    + (
                        highBreakout
                            ? "HIGH"
                            : lowBreakout
                                ? "LOW"
                                : "NONE"
                    )
                );

                LogLearningDecision(
                    decisionNyTime,
                    trend,
                    vwapSide,
                    liquidityState,
                    structureState,
                    setup,
                    buyScore,
                    sellScore
                );

                if (
                    rawLongReady &&
                    !learningLongAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK LONG | "
                        + learningLongReason
                    );
                }

                if (
                    rawShortReady &&
                    !learningShortAllowed
                )
                {
                    PrintBotMessage(
                        "LEARNING BLOCK SHORT | "
                        + learningShortReason
                    );
                }

                PrintBotMessage(
                    "BUY SCORE: "
                    + buyScore
                    + "/4"
                    + (
                        buyMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    buyMissing
                                )
                            : " | READY"
                    )
                );

                PrintBotMessage(
                    "SELL SCORE: "
                    + sellScore
                    + "/4"
                    + (
                        sellMissing.Count > 0
                            ? " | Missing: "
                                + string.Join(
                                    ", ",
                                    sellMissing
                                )
                            : " | READY"
                    )
                );

                if (openingReady)
                {
                    bool openingIsLong =
                        openingLongReady;

                    PrintBotMessage(
                        "OPENING SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Side: "
                        + (openingIsLong ? "LONG" : "SHORT")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | OR High: "
                        + openingRangeHigh.ToString("0.00")
                        + " | OR Low: "
                        + openingRangeLow.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Trend: "
                        + trend
                    );

                    CaptureLearningSignalContext(
                        openingIsLong
                            ? "LONG"
                            : "SHORT",
                        decisionNyTime,
                        "OPENING BREAKOUT"
                    );

                    TrySubmitEntry(
                        openingIsLong,
                        closedBarTime,
                        false,
                        null,
                        true,
                        false,
                        "OPENING",
                        "DIRECT",
                        "M5 OPENING BREAKOUT FALLBACK"
                    );
                }
                else if (longReady)
                {
                    PrintBotMessage(
                        "LONG SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string longLearningContext =
                        structureState;

                    if (bullishStructureBreakLevel > 0)
                    {
                        ArmSmartRetest(
                            true,
                            decisionNyTime,
                            bullishStructureBreakLevel,
                            bullishStructureBreakLevel,
                            lastPrice,
                            4,
                            "M5 STRUCTURE READY",
                            bullishStructureSetupKey
                        );

                        PrintBotMessage(
                            "WAIT STRUCTURE RETEST"
                            + " | Side: LONG"
                            + " | Level: " + bullishStructureBreakLevel.ToString("0.00")
                            + " | Setup: " + structureState
                        );
                    }
                    else
                    {
                        CaptureLearningSignalContext(
                            "LONG",
                            decisionNyTime,
                            longLearningContext
                        );

                        TrySubmitEntry(
                            true,
                            closedBarTime,
                            false,
                            bullishStructureSetupKey,
                            false,
                            false,
                            "STRUCTURE",
                            "DIRECT",
                            "M5 STRUCTURE CANDIDATE"
                        );
                    }
                }
                else if (shortReady)
                {
                    PrintBotMessage(
                        "SHORT SIGNAL"
                        + " | NY: "
                        + decisionNyTime.ToString("HH:mm")
                        + " | Price: "
                        + lastPrice.ToString("0.00")
                        + " | EMA9: "
                        + emaFastCurrent.ToString("0.00")
                        + " | EMA50: "
                        + emaSlowCurrent.ToString("0.00")
                        + " | VWAP: "
                        + currentVwap.ToString("0.00")
                        + " | Liquidity: "
                        + liquidityState
                        + " | Structure: "
                        + structureState
                    );

                    string shortLearningContext =
                        structureState;

                    if (bearishStructureBreakLevel > 0)
                    {
                        ArmSmartRetest(
                            false,
                            decisionNyTime,
                            bearishStructureBreakLevel,
                            bearishStructureBreakLevel,
                            lastPrice,
                            4,
                            "M5 STRUCTURE READY",
                            bearishStructureSetupKey
                        );

                        PrintBotMessage(
                            "WAIT STRUCTURE RETEST"
                            + " | Side: SHORT"
                            + " | Level: " + bearishStructureBreakLevel.ToString("0.00")
                            + " | Setup: " + structureState
                        );
                    }
                    else
                    {
                        CaptureLearningSignalContext(
                            "SHORT",
                            decisionNyTime,
                            shortLearningContext
                        );

                        TrySubmitEntry(
                            false,
                            closedBarTime,
                            false,
                            bearishStructureSetupKey,
                            false,
                            false,
                            "STRUCTURE",
                            "DIRECT",
                            "M5 STRUCTURE CANDIDATE"
                        );
                    }
                }
            }

            currentSignalState =
                signal;

            currentSetupState =
                setup;

            PublishSharedState();

            // =================================================
            // UPDATE UI
            // =================================================
            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (!botRunning)
                        return;

                    lastPriceText.Text =
                        FormatPrice(
                            lastPrice
                        );

                    emaFastText.Text =
                        FormatPrice(
                            emaFastCurrent
                        );

                    emaSlowText.Text =
                        FormatPrice(
                            emaSlowCurrent
                        );

                    vwapText.Text =
                        currentVwap > 0
                            ? FormatPrice(
                                currentVwap
                            )
                            : "--";

                    trendText.Text =
                        trend;

                    trendText.Foreground =
                        trendBrush;

                    nySessionText.Text =
                        nySessionActive
                            ? "ACTIVE"
                            : "CLOSED";

                    nySessionText.Foreground =
                        nySessionActive
                            ? Brushes.LimeGreen
                            : Brushes.Gray;

                    liquidityText.Text =
                        liquidityState;

                    liquidityText.Foreground =
                        liquidityBrush;

                    structureText.Text =
                        structureState;

                    structureText.Foreground =
                        structureBrush;

                    momentumText.Text =
                        "R20 "
                        + momentumState;

                    momentumText.Foreground =
                        momentumBrush;

                    confirmationText.Text =
                        confirmation;

                    confirmationText.Foreground =
                        confirmationBrush;

                    setupText.Text =
                        setup;

                    setupText.Foreground =
                        setupBrush;

                    barTimeText.Text =
                        decisionNyTime.ToString(
                            "MM/dd HH:mm"
                        )
                        + " ET";

                    signalText.Text =
                        signal;

                    signalText.Foreground =
                        signalBrush;

                    pnlText.Text =
                        botDailyPnL.ToString(
                            "$0.00"
                        );

                    tradesText.Text =
                        "AM "
                        + amTradesToday
                        + "/"
                        + activeMaxTrades
                        + " | PM "
                        + pmTradesToday
                        + "/"
                        + activeMaxTrades;
                })
            );
        }
        private void DetectLiquidityAndStructure(
            Bars bars,
            int closedBarIndex,
            out string liquidityState,
            out string structureState,
            out bool bullishConfirmed,
            out bool bearishConfirmed,
            out string bullishSetupKey,
            out string bearishSetupKey)
        {
            liquidityState =
                "NONE";

            structureState =
                "WAITING";

            bullishConfirmed =
                false;

            bearishConfirmed =
                false;

            bullishSetupKey =
                string.Empty;

            bearishSetupKey =
                string.Empty;

            if (
                bars == null ||
                selectedInstrument == null ||
                selectedInstrument.MasterInstrument == null ||
                closedBarIndex <
                    SweepLookback + StructureLookback
            )
            {
                return;
            }

            double tickSize =
                selectedInstrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
            {
                return;
            }

            double minimumSweepDistance =
                MinimumSweepTicks
                * tickSize;

            string consumedBullishKey;
            string consumedBearishKey;
            DateTime consumedBullishConfirmTime;
            DateTime consumedBearishConfirmTime;

            lock (executionStateLock)
            {
                consumedBullishKey =
                    consumedBullishStructureSetupKey
                    ?? string.Empty;

                consumedBearishKey =
                    consumedBearishStructureSetupKey
                    ?? string.Empty;

                consumedBullishConfirmTime =
                    consumedBullishStructureConfirmTime;

                consumedBearishConfirmTime =
                    consumedBearishStructureConfirmTime;
            }

            int firstSweepIndex =
                Math.Max(
                    SweepLookback,
                    closedBarIndex
                        - SweepMaxAgeBars
                );

            int latestLiquidityIndex =
                -1;

            int latestBullishConfirmIndex =
                -1;

            int latestBearishConfirmIndex =
                -1;

            int latestBullishSweepIndex =
                -1;

            int latestBearishSweepIndex =
                -1;

            string latestBullishSetupKey =
                string.Empty;

            string latestBearishSetupKey =
                string.Empty;

            // Scan oldest -> newest so the most recent valid,
            // UNCONSUMED structural event wins.
            for (
                int sweepIndex =
                    firstSweepIndex;
                sweepIndex <= closedBarIndex;
                sweepIndex++
            )
            {
                int priorStart =
                    Math.Max(
                        0,
                        sweepIndex
                            - SweepLookback
                    );

                int priorEnd =
                    sweepIndex - 1;

                if (
                    priorEnd <= priorStart
                )
                {
                    continue;
                }

                double priorLow =
                    GetLowestLow(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double priorHigh =
                    GetHighestHigh(
                        bars,
                        priorStart,
                        priorEnd
                    );

                double sweepLow =
                    bars.GetLow(
                        sweepIndex
                    );

                double sweepHigh =
                    bars.GetHigh(
                        sweepIndex
                    );

                double sweepClose =
                    bars.GetClose(
                        sweepIndex
                    );

                // A sweep must reclaim the prior level AND exceed it
                // by at least MinimumSweepTicks. One-tick noise is ignored.
                bool lowSweep =
                    (
                        priorLow -
                        sweepLow
                    ) >=
                        minimumSweepDistance &&
                    sweepClose >
                        priorLow;

                bool highSweep =
                    (
                        sweepHigh -
                        priorHigh
                    ) >=
                        minimumSweepDistance &&
                    sweepClose <
                        priorHigh;

                // One candle can legitimately sweep both sides.
                // Represent that explicitly instead of allowing the
                // HIGH branch to overwrite the LOW branch.
                if (
                    (lowSweep || highSweep) &&
                    sweepIndex >=
                        latestLiquidityIndex
                )
                {
                    latestLiquidityIndex =
                        sweepIndex;

                    liquidityState =
                        lowSweep && highSweep
                            ? "BOTH SWEPT"
                            : lowSweep
                                ? "LOW SWEPT"
                                : "HIGH SWEPT";
                }

                // ---------------------------------------------
                // BULLISH STRUCTURE BREAK AFTER LOW SWEEP
                // ---------------------------------------------
                if (lowSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureHigh =
                        GetHighestHigh(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            > structureHigh
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    true,
                                    sweepIndex,
                                    confirmIndex
                                );

                            // The FIRST close through the pre-sweep
                            // structure level defines this setup.
                            // If it was already filled/consumed, do not
                            // reinterpret later closes as a new setup.
                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBullishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBullishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBullishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBullishConfirmIndex
                            )
                            {
                                latestBullishConfirmIndex =
                                    confirmIndex;

                                latestBullishSweepIndex =
                                    sweepIndex;

                                latestBullishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }

                // ---------------------------------------------
                // BEARISH STRUCTURE BREAK AFTER HIGH SWEEP
                // ---------------------------------------------
                if (highSweep)
                {
                    int structureStart =
                        Math.Max(
                            0,
                            sweepIndex
                                - StructureLookback
                        );

                    double structureLow =
                        GetLowestLow(
                            bars,
                            structureStart,
                            sweepIndex - 1
                        );

                    for (
                        int confirmIndex =
                            sweepIndex + 1;
                        confirmIndex <=
                            closedBarIndex;
                        confirmIndex++
                    )
                    {
                        if (
                            bars.GetClose(
                                confirmIndex
                            )
                            < structureLow
                        )
                        {
                            string setupKey =
                                BuildStructureSetupKey(
                                    bars,
                                    false,
                                    sweepIndex,
                                    confirmIndex
                                );

                            DateTime confirmTime =
                                bars.GetTime(
                                    confirmIndex
                                );

                            if (
                                !string.Equals(
                                    setupKey,
                                    consumedBearishKey,
                                    StringComparison.Ordinal
                                ) &&
                                (
                                    consumedBearishConfirmTime ==
                                        DateTime.MinValue ||
                                    confirmTime >
                                        consumedBearishConfirmTime
                                ) &&
                                confirmIndex >=
                                    latestBearishConfirmIndex
                            )
                            {
                                latestBearishConfirmIndex =
                                    confirmIndex;

                                latestBearishSweepIndex =
                                    sweepIndex;

                                latestBearishSetupKey =
                                    setupKey;
                            }

                            break;
                        }
                    }
                }
            }

            // Pick the most recent UNCONSUMED structural break.
            if (
                latestBullishConfirmIndex >
                    latestBearishConfirmIndex
            )
            {
                bullishConfirmed =
                    true;

                bearishConfirmed =
                    false;

                bullishSetupKey =
                    latestBullishSetupKey;

                // BOS / CHOCH is classified from the EMA context that
                // existed BEFORE the sweep, not after the break.
                int contextIndex =
                    Math.Max(
                        0,
                        latestBullishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep <
                        slowBeforeSweep
                        ? "BULLISH CHOCH"
                        : "BULLISH BOS";
            }
            else if (
                latestBearishConfirmIndex >
                    latestBullishConfirmIndex
            )
            {
                bullishConfirmed =
                    false;

                bearishConfirmed =
                    true;

                bearishSetupKey =
                    latestBearishSetupKey;

                int contextIndex =
                    Math.Max(
                        0,
                        latestBearishSweepIndex - 1
                    );

                double fastBeforeSweep =
                    CalculateEma(
                        bars,
                        FastEmaPeriod,
                        contextIndex
                    );

                double slowBeforeSweep =
                    CalculateEma(
                        bars,
                        SlowEmaPeriod,
                        contextIndex
                    );

                structureState =
                    fastBeforeSweep >
                        slowBeforeSweep
                        ? "BEARISH CHOCH"
                        : "BEARISH BOS";
            }
        }
        private string BuildStructureSetupKey(
            Bars bars,
            bool isLong,
            int sweepIndex,
            int confirmIndex)
        {
            if (
                bars == null ||
                sweepIndex < 0 ||
                confirmIndex < 0 ||
                sweepIndex >= bars.Count ||
                confirmIndex >= bars.Count
            )
            {
                return string.Empty;
            }

            DateTime sweepTime =
                bars.GetTime(
                    sweepIndex
                );

            DateTime confirmTime =
                bars.GetTime(
                    confirmIndex
                );

            return
                (
                    isLong
                        ? "LONG"
                        : "SHORT"
                )
                + "|S:"
                + sweepTime.Ticks
                + "|C:"
                + confirmTime.Ticks;
        }
        private DateTime GetStructureConfirmTimeFromKey(
            string setupKey)
        {
            if (
                string.IsNullOrWhiteSpace(
                    setupKey
                )
            )
            {
                return DateTime.MinValue;
            }

            const string marker =
                "|C:";

            int markerIndex =
                setupKey.LastIndexOf(
                    marker,
                    StringComparison.Ordinal
                );

            if (
                markerIndex < 0
            )
            {
                return DateTime.MinValue;
            }

            string ticksText =
                setupKey.Substring(
                    markerIndex +
                    marker.Length
                );

            long ticks;

            if (
                !long.TryParse(
                    ticksText,
                    out ticks
                ) ||
                ticks <= 0 ||
                ticks > DateTime.MaxValue.Ticks
            )
            {
                return DateTime.MinValue;
            }

            try
            {
                return new DateTime(
                    ticks
                );
            }
            catch
            {
                return DateTime.MinValue;
            }
        }
        private void CalculateSessionVwapContext(
            Bars bars,
            int endIndex,
            out double vwap,
            out double stdDev,
            out double upper1,
            out double upper2,
            out double lower1,
            out double lower2)
        {
            vwap = 0;
            stdDev = 0;
            upper1 = 0;
            upper2 = 0;
            lower1 = 0;
            lower2 = 0;

            if (
                bars == null ||
                endIndex < 0 ||
                endIndex >= bars.Count
            )
            {
                return;
            }

            DateTime endNyTime =
                ConvertToNewYorkTime(
                    bars.GetTime(
                        endIndex
                    )
                );

            DateTime sessionDate =
                endNyTime.Date;

            double cumulativePriceVolume = 0;
            double cumulativePriceSquaredVolume = 0;
            double cumulativeVolume = 0;

            for (
                int i = endIndex;
                i >= 0;
                i--
            )
            {
                DateTime barNyTime =
                    ConvertToNewYorkTime(
                        bars.GetTime(i)
                    );

                if (barNyTime.Date < sessionDate)
                    break;

                if (barNyTime.Date != sessionDate)
                    continue;

                int nyTime =
                    ToTimeInt(
                        barNyTime
                    );

                if (nyTime < RthVwapStart)
                    break;

                long volume =
                    bars.GetVolume(i);

                if (volume <= 0)
                    continue;

                double typicalPrice =
                    (
                        bars.GetHigh(i)
                        + bars.GetLow(i)
                        + bars.GetClose(i)
                    )
                    / 3.0;

                double weightedVolume =
                    (double)volume;

                cumulativePriceVolume +=
                    typicalPrice *
                    weightedVolume;

                cumulativePriceSquaredVolume +=
                    typicalPrice *
                    typicalPrice *
                    weightedVolume;

                cumulativeVolume +=
                    weightedVolume;
            }

            if (cumulativeVolume <= 0)
                return;

            vwap =
                cumulativePriceVolume /
                cumulativeVolume;

            double variance =
                (
                    cumulativePriceSquaredVolume /
                    cumulativeVolume
                )
                -
                (
                    vwap *
                    vwap
                );

            if (variance < 0)
                variance = 0;

            stdDev =
                Math.Sqrt(
                    variance
                );

            upper1 =
                vwap +
                stdDev;

            upper2 =
                vwap +
                (2.0 * stdDev);

            lower1 =
                vwap -
                stdDev;

            lower2 =
                vwap -
                (2.0 * stdDev);
        }

        private double CalculateSessionVwap(
            Bars bars,
            int endIndex)
        {
            double vwap;
            double stdDev;
            double upper1;
            double upper2;
            double lower1;
            double lower2;

            CalculateSessionVwapContext(
                bars,
                endIndex,
                out vwap,
                out stdDev,
                out upper1,
                out upper2,
                out lower1,
                out lower2
            );

            return vwap;
        }

        private string ClassifyVwapLocation(
            double zScore)
        {
            if (zScore >= 1.50)
                return "UPPER EXTREME";

            if (zScore >= 0.50)
                return "UPPER 1";

            if (zScore <= -1.50)
                return "LOWER EXTREME";

            if (zScore <= -0.50)
                return "LOWER 1";

            return "CENTER";
        }

        private string ClassifyVwapSlope(
            double currentVwap,
            double previousVwap,
            double tickSize)
        {
            if (
                currentVwap <= 0 ||
                previousVwap <= 0
            )
            {
                return "FLAT";
            }

            double threshold =
                Math.Max(
                    tickSize,
                    0.0000001
                );

            double delta =
                currentVwap -
                previousVwap;

            if (delta >= threshold)
                return "UP";

            if (delta <= -threshold)
                return "DOWN";

            return "FLAT";
        }

        private string UpdateVwapBandStateLocked(
            DateTime sessionDate,
            double bandWidth,
            out double widthRatio)
        {
            widthRatio = 1.0;

            if (
                latestVwapWidthSessionDate !=
                    sessionDate
            )
            {
                recentVwapBandWidths.Clear();
                latestVwapWidthSessionDate =
                    sessionDate;
            }

            double averageWidth =
                recentVwapBandWidths.Count > 0
                    ? recentVwapBandWidths.Average()
                    : 0;

            if (
                averageWidth > 0 &&
                bandWidth > 0
            )
            {
                widthRatio =
                    bandWidth /
                    averageWidth;
            }

            string state =
                "NORMAL";

            if (
                recentVwapBandWidths.Count >= 4
            )
            {
                if (widthRatio <= 0.82)
                    state = "COMPRESSION";
                else if (widthRatio >= 1.18)
                    state = "EXPANSION";
            }

            if (bandWidth > 0)
            {
                recentVwapBandWidths.Enqueue(
                    bandWidth
                );

                while (
                    recentVwapBandWidths.Count >
                        12
                )
                {
                    recentVwapBandWidths.Dequeue();
                }
            }

            return state;
        }

        private string ResolveVwapEntryContext(
            string location,
            string bandState,
            string slope)
        {
            if (location == "LOWER EXTREME")
                return bandState == "COMPRESSION"
                    ? "FAVORABLE LONG / SQUEEZE"
                    : "FAVORABLE LONG";

            if (location == "LOWER 1")
                return slope == "UP"
                    ? "GOOD LONG ZONE"
                    : "LONG LOCATION";

            if (location == "UPPER EXTREME")
                return bandState == "COMPRESSION"
                    ? "FAVORABLE SHORT / SQUEEZE"
                    : "FAVORABLE SHORT";

            if (location == "UPPER 1")
                return slope == "DOWN"
                    ? "GOOD SHORT ZONE"
                    : "SHORT LOCATION";

            if (bandState == "COMPRESSION")
                return "CENTER / COMPRESSION";

            return "NEUTRAL";
        }
        private void EvaluateNasdaqSetupQuality(
            bool isLong,
            int momentumScore,
            bool aggressiveExpansion,
            bool extremeMomentum,
            bool smartRetest,
            bool directionalBreakout,
            double bodyRatio,
            double volumeRatio,
            double slopeTicks,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            string m5Structure,
            string m5Liquidity,
            int htfAlignmentScore,
            out int confidence,
            out string quality,
            out string timing,
            out string manipulation,
            out string reason)
        {
            int score = 35;

            // R20 is the primary Nasdaq trigger.
            score +=
                Math.Max(
                    0,
                    Math.Min(5, momentumScore)
                ) * 7;

            bool trendAligned =
                isLong
                    ? m5Bullish
                    : m5Bearish;

            bool vwapAligned =
                isLong
                    ? m5AboveVwap
                    : m5BelowVwap;

            bool structureAligned =
                IsStructureAlignedForSetup(
                    isLong,
                    m5Structure
                );

            bool trendOpposed =
                (
                    isLong &&
                    m5Bearish
                ) ||
                (
                    !isLong &&
                    m5Bullish
                );

            DateTime qualityNyTime =
                GetCurrentNewYorkTime();

            int qualityTimeInt =
                ToTimeInt(
                    qualityNyTime
                );

            bool openingDiscovery =
                qualityTimeInt >=
                    OpeningRangeStart &&
                qualityTimeInt <
                    OpeningEntryStart;

            if (trendAligned)
            {
                score += 8;
            }
            else if (trendOpposed)
            {
                // Opposite confirmed M5 trend is a major contextual conflict,
                // especially during the cash-open discovery phase.
                score -=
                    openingDiscovery
                        ? 25
                        : 15;
            }

            if (vwapAligned)
                score += 7;

            if (structureAligned)
            {
                score += 5;
            }
            else
            {
                // WAITING / opposite structure must reduce confidence instead
                // of silently contributing zero while R20 pushes score to 99%.
                score -=
                    openingDiscovery
                        ? 18
                        : 6;
            }

            if (openingDiscovery)
            {
                // Opening is still being discovered. This is intentionally
                // a confidence penalty only; the hard 60-second execution
                // veto lives in JJBotExecutionEngine.
                score -= 10;

                if (htfAlignmentScore < 2)
                {
                    score -= 5;
                }
            }

            score +=
                Math.Max(
                    0,
                    Math.Min(2, htfAlignmentScore)
                ) * 4;

            if (directionalBreakout)
                score += 6;

            if (aggressiveExpansion)
                score += 8;
            else if (extremeMomentum)
                score += 5;

            if (smartRetest)
                score += 5;

            if (bodyRatio >= 0.70)
                score += 4;
            else if (bodyRatio < 0.55)
                score -= 5;

            if (volumeRatio >= 1.20)
                score += 4;
            else if (volumeRatio < 0.85)
                score -= 5;

            double directionalSlope =
                isLong
                    ? slopeTicks
                    : -slopeTicks;

            if (directionalSlope >= 5.0)
                score += 4;
            else if (directionalSlope < 1.0)
                score -= 4;

            manipulation =
                GetManipulationState(
                    isLong,
                    m5Liquidity,
                    m5Structure
                );

            if (
                manipulation ==
                    "CONFIRMED WITH SETUP"
            )
            {
                score += 5;
            }
            else if (
                manipulation ==
                    "OPPOSING RISK"
            )
            {
                score -= 10;
            }

            // V1.6.25 - LEARNING QUALITY PENALTY.
            // Quality may no longer advertise OPTIMAL 99% while the exact
            // R20 setup bucket has a proven negative expectancy.
            string learningQualityContext =
                "R20 MOMENTUM "
                + momentumScore
                + "/5";

            bool learningQualityBlocked;
            string learningQualityReason;

            int learningPenalty =
                GetLearningQualityPenalty(
                    isLong ? "LONG" : "SHORT",
                    qualityNyTime,
                    learningQualityContext,
                    out learningQualityBlocked,
                    out learningQualityReason
                );

            if (learningPenalty > 0)
            {
                score -= learningPenalty;
            }

            confidence =
                Math.Max(
                    45,
                    Math.Min(99, score)
                );

            if (confidence >= 88)
                quality = "OPTIMAL";
            else if (confidence >= 80)
                quality = "HIGH";
            else if (confidence >= 70)
                quality = "CONFIRMED";
            else
                quality = "STANDARD";

            if (smartRetest)
            {
                timing = "CONFIRMED RETEST";
            }
            else if (
                aggressiveExpansion ||
                extremeMomentum
            )
            {
                timing = "EARLY";
            }
            else if (
                directionalBreakout &&
                momentumScore >= 4
            )
            {
                timing = "CONFIRMED";
            }
            else
            {
                timing = "DEVELOPING";
            }

            reason =
                "R20 "
                + momentumScore
                + "/5"
                + " | M5 "
                + (
                    trendAligned
                        ? "ALIGNED"
                        : trendOpposed
                            ? "OPPOSED"
                            : "MIXED"
                  )
                + " | Structure "
                + (
                    structureAligned
                        ? "ALIGNED"
                        : "WAITING/OPPOSED"
                  )
                + " | Opening "
                + (
                    openingDiscovery
                        ? "DISCOVERY"
                        : "STABLE"
                  )
                + " | Learning "
                + (
                    learningQualityBlocked
                        ? "BLOCK"
                        : learningPenalty > 0
                            ? "PENALTY -" + learningPenalty
                            : "OK"
                  )
                + " | VWAP "
                + (vwapAligned ? "ALIGNED" : "MIXED")
                + " | HTF "
                + Math.Max(0, Math.Min(2, htfAlignmentScore))
                + "/2"
                + " | Breakout "
                + (directionalBreakout ? "YES" : "NO")
                + " | Aggression "
                + (aggressiveExpansion ? "YES" : "NO");
        }
        private bool IsStructureAlignedForSetup(
            bool isLong,
            string structureState)
        {
            string state =
                (structureState ?? string.Empty)
                    .ToUpperInvariant();

            if (isLong)
            {
                return
                    state.Contains("BULLISH");
            }

            return
                state.Contains("BEARISH");
        }
        private void LogStructureMatureMoveBlock(
            bool isLong,
            DateTime nyTime,
            double moveTicks,
            int momentumScore,
            double volumeRatio,
            bool breakout)
        {
            string side = isLong ? "LONG" : "SHORT";
            string key =
                side + "|" + nyTime.ToString("yyyyMMddHHmm") + "|"
                + Math.Floor(moveTicks / 100.0).ToString(CultureInfo.InvariantCulture);

            if (string.Equals(key, lastStructureExhaustionLogKey, StringComparison.Ordinal))
                return;

            lastStructureExhaustionLogKey = key;

            PrintBotMessage(
                "SKIP STRUCTURE - MATURE MOVE / NO FRESH EXPANSION"
                + " | Side: " + side
                + " | Move: " + moveTicks.ToString("0") + "t"
                + " | R20: " + momentumScore + "/5"
                + " | Volume x" + volumeRatio.ToString("0.00")
                + " | Breakout: " + (breakout ? "YES" : "NO")
            );
        }

    }
}

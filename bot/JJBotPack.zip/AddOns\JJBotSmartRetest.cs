#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private void ArmSmartRetest(
            bool isLong,
            DateTime nyTime,
            double breakoutLevel,
            double structureLevel,
            double impulseExtreme,
            int score,
            string reason,
            string structureSetupKey = null)
        {
            pendingSmartRetestActive = true;
            pendingSmartRetestIsLong = isLong;
            pendingSmartRetestCreatedNy = nyTime;
            pendingSmartRetestExpiresNy = nyTime.AddSeconds(SmartRetestWindowSeconds);
            pendingSmartRetestBreakoutLevel = breakoutLevel;
            pendingSmartRetestStructureLevel = structureLevel;
            pendingSmartRetestImpulseExtreme = impulseExtreme;
            pendingSmartRetestOriginalScore = score;
            pendingSmartRetestReason = reason ?? string.Empty;
            pendingSmartRetestStructureSetupKey = structureSetupKey ?? string.Empty;

            string key = (isLong ? "LONG" : "SHORT") + "|" + nyTime.ToString("yyyyMMddHHmmss");
            if (key != lastSmartRetestLogKey)
            {
                lastSmartRetestLogKey = key;
                PrintBotMessage(
                    "SMART RETEST ARMED"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | R20: " + score + "/5"
                    + " | Breakout: " + breakoutLevel.ToString("0.00")
                    + " | M5 Structure: " + (structureLevel > 0 ? structureLevel.ToString("0.00") : "N/A")
                    + " | Window: " + SmartRetestWindowSeconds + "s"
                );
            }
        }
        private void TryConfirmSmartRetest(
            Bars bars,
            int closedBarIndex,
            DateTime nyTime,
            double tickSize,
            double close,
            int longScore,
            int shortScore,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            out bool confirmLong,
            out bool confirmShort,
            out string pattern,
            out string structureSetupKey)
        {
            confirmLong = false;
            confirmShort = false;
            pattern = string.Empty;
            structureSetupKey = string.Empty;

            if (!pendingSmartRetestActive || bars == null || tickSize <= 0)
                return;

            if (nyTime > pendingSmartRetestExpiresNy || nyTime.Date != pendingSmartRetestCreatedNy.Date)
            {
                PrintBotMessage("SMART RETEST EXPIRED | Side: "
                    + (pendingSmartRetestIsLong ? "LONG" : "SHORT")
                    + " | No valid retest confirmation.");
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;
                return;
            }

            if (closedBarIndex < 2)
                return;

            bool isLong = pendingSmartRetestIsLong;
            double high = bars.GetHigh(closedBarIndex);
            double low = bars.GetLow(closedBarIndex);
            double open = bars.GetOpen(closedBarIndex);
            double priorOpen = bars.GetOpen(closedBarIndex - 1);
            double priorClose = bars.GetClose(closedBarIndex - 1);
            double priorHigh = bars.GetHigh(closedBarIndex - 1);
            double priorLow = bars.GetLow(closedBarIndex - 1);
            double levelTol = SmartRetestLevelToleranceTicks * tickSize;
            double structureTol = SmartRetestStructureToleranceTicks * tickSize;

            bool contextOk = isLong
                ? (m5Bullish && m5AboveVwap && longScore >= SmartRetestMinResumeScore)
                : (m5Bearish && m5BelowVwap && shortScore >= SmartRetestMinResumeScore);

            if (!contextOk)
                return;

            bool breakoutRetest = false;
            if (pendingSmartRetestBreakoutLevel > 0)
            {
                breakoutRetest = isLong
                    ? (low <= pendingSmartRetestBreakoutLevel + levelTol && close > pendingSmartRetestBreakoutLevel)
                    : (high >= pendingSmartRetestBreakoutLevel - levelTol && close < pendingSmartRetestBreakoutLevel);
            }

            bool structureRetest = false;
            if (pendingSmartRetestStructureLevel > 0)
            {
                structureRetest = isLong
                    ? (low <= pendingSmartRetestStructureLevel + structureTol && close > pendingSmartRetestStructureLevel)
                    : (high >= pendingSmartRetestStructureLevel - structureTol && close < pendingSmartRetestStructureLevel);
            }

            bool priorWasPullback = isLong ? priorClose < priorOpen : priorClose > priorOpen;
            bool resumed = isLong
                ? (close > open && close > priorHigh)
                : (close < open && close < priorLow);
            bool microPullbackContinuation = priorWasPullback && resumed;

            if (structureRetest)
                pattern = "STRUCTURE RETEST";
            else if (breakoutRetest)
                pattern = "BREAKOUT RETEST";
            else if (microPullbackContinuation)
                pattern = "MICRO PULLBACK";
            else
                return;

            structureSetupKey = pendingSmartRetestStructureSetupKey;
            confirmLong = isLong;
            confirmShort = !isLong;
            pendingSmartRetestActive = false;
            pendingSmartRetestStructureSetupKey = string.Empty;
        }
        private void PrintSmartRetestConfirmed(
            bool isLong,
            DateTime nyTime,
            string pattern,
            double price,
            int score)
        {
            string normalizedPattern =
                string.IsNullOrWhiteSpace(pattern)
                    ? "RETEST"
                    : pattern.Trim().ToUpperInvariant();

            string logKey =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + normalizedPattern
                + "|"
                + nyTime.ToString("yyyyMMddHHmmss")
                + "|"
                + price.ToString("0.00");

            // The evaluator can be called multiple times while the same
            // confirmed retest is still visible. Keep the trading state
            // untouched and suppress only duplicate telemetry.
            if (
                string.Equals(
                    lastSmartRetestConfirmedLogKey,
                    logKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastSmartRetestConfirmedLogKey =
                logKey;

            PrintBotMessage(
                "SMART RETEST CONFIRMED"
                + " | " + normalizedPattern
                + " | Side: " + (isLong ? "LONG" : "SHORT")
                + " | Price: " + price.ToString("0.00")
                + " | R20: " + score + "/5"
                + " | NY: " + nyTime.ToString("HH:mm:ss")
            );
        }

    }
}

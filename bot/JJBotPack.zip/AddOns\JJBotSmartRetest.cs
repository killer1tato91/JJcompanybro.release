﻿#region Using declarations
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        // V1.6.30 - SMART RETEST CONFIRMATION V2
        // Level -> Reaction -> Confirmation -> Entry.
        private const double SmartRetestV2MinReactionBodyRatio = 0.35;
        private const int SmartRetestV2MinSameSideScore = 2;
        private const int SmartRetestV2MaxOppositeScore = 1;
        private const int SmartRetestV2MicroPullbackMinScore = 3;

        private void ArmSmartRetest(
            bool isLong,
            DateTime nyTime,
            double breakoutLevel,
            double structureLevel,
            double impulseExtreme,
            int score,
            string reason,
            string structureSetupKey = null)
        {
            string normalizedReason =
                reason ?? string.Empty;

            bool samePendingSetup =
                pendingSmartRetestActive &&
                pendingSmartRetestIsLong == isLong &&
                string.Equals(
                    pendingSmartRetestReason,
                    normalizedReason,
                    StringComparison.OrdinalIgnoreCase
                ) &&
                Math.Abs(
                    pendingSmartRetestBreakoutLevel -
                    breakoutLevel
                ) < 0.0000001 &&
                Math.Abs(
                    pendingSmartRetestStructureLevel -
                    structureLevel
                ) < 0.0000001;

            if (samePendingSetup)
            {
                // Do NOT restart Created/Expires on every Range callback.
                // Repeated anti-chase signals used to keep the retest alive
                // forever and spam the log every second.
                pendingSmartRetestOriginalScore =
                    Math.Max(
                        pendingSmartRetestOriginalScore,
                        score
                    );

                if (impulseExtreme > 0)
                {
                    if (pendingSmartRetestImpulseExtreme <= 0)
                    {
                        pendingSmartRetestImpulseExtreme =
                            impulseExtreme;
                    }
                    else
                    {
                        pendingSmartRetestImpulseExtreme =
                            isLong
                                ? Math.Max(
                                    pendingSmartRetestImpulseExtreme,
                                    impulseExtreme
                                  )
                                : Math.Min(
                                    pendingSmartRetestImpulseExtreme,
                                    impulseExtreme
                                  );
                    }
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        structureSetupKey
                    )
                )
                {
                    pendingSmartRetestStructureSetupKey =
                        structureSetupKey;
                }

                return;
            }

            pendingSmartRetestActive = true;
            pendingSmartRetestIsLong = isLong;
            pendingSmartRetestCreatedNy = nyTime;
            pendingSmartRetestExpiresNy = nyTime.AddSeconds(SmartRetestWindowSeconds);
            pendingSmartRetestBreakoutLevel = breakoutLevel;
            pendingSmartRetestStructureLevel = structureLevel;
            pendingSmartRetestImpulseExtreme = impulseExtreme;
            pendingSmartRetestOriginalScore = score;
            pendingSmartRetestReason = normalizedReason;
            pendingSmartRetestStructureSetupKey = structureSetupKey ?? string.Empty;

            string key =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + normalizedReason
                + "|"
                + breakoutLevel.ToString("0.00", CultureInfo.InvariantCulture)
                + "|"
                + structureLevel.ToString("0.00", CultureInfo.InvariantCulture);

            if (key != lastSmartRetestLogKey)
            {
                lastSmartRetestLogKey = key;
                PrintBotMessage(
                    "SMART RETEST ARMED"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | R20: " + score + "/5"
                    + " | Breakout: " + breakoutLevel.ToString("0.00")
                    + " | M5 Structure: " + (structureLevel > 0 ? structureLevel.ToString("0.00") : "N/A")
                    + " | Window: " + SmartRetestWindowSeconds + "s"
                );
            }
        }
        private void TryConfirmSmartRetest(
            Bars bars,
            int closedBarIndex,
            DateTime nyTime,
            double tickSize,
            double close,
            int longScore,
            int shortScore,
            bool m5Bullish,
            bool m5Bearish,
            bool m5AboveVwap,
            bool m5BelowVwap,
            out bool confirmLong,
            out bool confirmShort,
            out string pattern,
            out string structureSetupKey)
        {
            confirmLong = false;
            confirmShort = false;
            pattern = string.Empty;
            structureSetupKey = string.Empty;

            if (!pendingSmartRetestActive || bars == null || tickSize <= 0)
                return;

            if (nyTime > pendingSmartRetestExpiresNy || nyTime.Date != pendingSmartRetestCreatedNy.Date)
            {
                PrintBotMessage("SMART RETEST EXPIRED | Side: "
                    + (pendingSmartRetestIsLong ? "LONG" : "SHORT")
                    + " | No valid retest confirmation.");
                pendingSmartRetestActive = false;
                pendingSmartRetestStructureSetupKey = string.Empty;
                return;
            }

            if (closedBarIndex < 2)
                return;

            bool isLong = pendingSmartRetestIsLong;
            double high = bars.GetHigh(closedBarIndex);
            double low = bars.GetLow(closedBarIndex);
            double open = bars.GetOpen(closedBarIndex);
            double priorOpen = bars.GetOpen(closedBarIndex - 1);
            double priorClose = bars.GetClose(closedBarIndex - 1);
            double priorHigh = bars.GetHigh(closedBarIndex - 1);
            double priorLow = bars.GetLow(closedBarIndex - 1);
            double levelTol = SmartRetestLevelToleranceTicks * tickSize;
            double structureTol = SmartRetestStructureToleranceTicks * tickSize;

            double retestAgeSeconds =
                Math.Max(
                    0,
                    (nyTime - pendingSmartRetestCreatedNy).TotalSeconds
                );

            bool staleRetest =
                retestAgeSeconds >
                    SmartRetestFreshWindowSeconds;

            int sameSideScore =
                isLong
                    ? longScore
                    : shortScore;

            int oppositeScore =
                isLong
                    ? shortScore
                    : longScore;

            double barRange =
                Math.Max(
                    tickSize,
                    high - low
                );

            double resumeBodyRatio =
                Math.Abs(close - open) /
                    barRange;

            int requiredResumeScore =
                staleRetest
                    ? SmartRetestStaleMinResumeScore
                    : SmartRetestMinResumeScore;

            bool contextOk = isLong
                ? (
                    m5Bullish &&
                    m5AboveVwap &&
                    sameSideScore >= requiredResumeScore
                  )
                : (
                    m5Bearish &&
                    m5BelowVwap &&
                    sameSideScore >= requiredResumeScore
                  );

            if (!contextOk)
                return;

            // A late retest is allowed only if the market clearly resumed
            // in the original direction. This preserves useful pullbacks
            // while rejecting stale continuation attempts.
            if (
                staleRetest &&
                (
                    oppositeScore >
                        SmartRetestStaleMaxOppositeScore ||
                    resumeBodyRatio <
                        SmartRetestStaleMinResumeBodyRatio
                )
            )
            {
                return;
            }

            bool breakoutRetest = false;
            if (pendingSmartRetestBreakoutLevel > 0)
            {
                breakoutRetest = isLong
                    ? (low <= pendingSmartRetestBreakoutLevel + levelTol && close > pendingSmartRetestBreakoutLevel)
                    : (high >= pendingSmartRetestBreakoutLevel - levelTol && close < pendingSmartRetestBreakoutLevel);
            }

            bool structureRetest = false;
            if (pendingSmartRetestStructureLevel > 0)
            {
                structureRetest = isLong
                    ? (low <= pendingSmartRetestStructureLevel + structureTol && close > pendingSmartRetestStructureLevel)
                    : (high >= pendingSmartRetestStructureLevel - structureTol && close < pendingSmartRetestStructureLevel);
            }

            bool priorWasPullback =
                isLong
                    ? priorClose < priorOpen
                    : priorClose > priorOpen;

            bool resumed = isLong
                ? (close > open && close > priorHigh)
                : (close < open && close < priorLow);

            bool impulseSideRecovered =
                pendingSmartRetestImpulseExtreme <= 0 ||
                (
                    isLong
                        ? close >=
                            (
                                pendingSmartRetestBreakoutLevel > 0
                                    ? (
                                        pendingSmartRetestBreakoutLevel +
                                        pendingSmartRetestImpulseExtreme
                                      ) / 2.0
                                    : close
                              )
                        : close <=
                            (
                                pendingSmartRetestBreakoutLevel > 0
                                    ? (
                                        pendingSmartRetestBreakoutLevel +
                                        pendingSmartRetestImpulseExtreme
                                      ) / 2.0
                                    : close
                              )
                  );

            bool directionalReaction =
                isLong
                    ? close > open
                    : close < open;

            bool strongReaction =
                directionalReaction &&
                resumeBodyRatio >=
                    SmartRetestV2MinReactionBodyRatio &&
                sameSideScore >=
                    Math.Max(
                        requiredResumeScore,
                        SmartRetestV2MinSameSideScore
                    ) &&
                oppositeScore <=
                    SmartRetestV2MaxOppositeScore;

            // A level touch/reclaim alone is NOT an entry anymore.
            // It must show a directional rejection/reaction with usable
            // Range momentum and weak opposite pressure.
            bool confirmedStructureRetest =
                structureRetest &&
                strongReaction;

            bool confirmedBreakoutRetest =
                breakoutRetest &&
                strongReaction;

            bool microPullbackContinuation =
                priorWasPullback &&
                resumed &&
                sameSideScore >=
                    Math.Max(
                        requiredResumeScore,
                        SmartRetestV2MicroPullbackMinScore
                    ) &&
                oppositeScore <=
                    SmartRetestV2MaxOppositeScore &&
                resumeBodyRatio >=
                    SmartRetestV2MinReactionBodyRatio &&
                (
                    !staleRetest ||
                    impulseSideRecovered
                );

            if (confirmedStructureRetest)
                pattern = "STRUCTURE RETEST V2";
            else if (confirmedBreakoutRetest)
                pattern = "BREAKOUT RETEST V2";
            else if (microPullbackContinuation)
                pattern = "MICRO PULLBACK V2";
            else
                return;

            structureSetupKey = pendingSmartRetestStructureSetupKey;
            confirmLong = isLong;
            confirmShort = !isLong;
            pendingSmartRetestActive = false;
            pendingSmartRetestStructureSetupKey = string.Empty;
        }
        private void PrintSmartRetestConfirmed(
            bool isLong,
            DateTime nyTime,
            string pattern,
            double price,
            int score)
        {
            string normalizedPattern =
                string.IsNullOrWhiteSpace(pattern)
                    ? "RETEST"
                    : pattern.Trim().ToUpperInvariant();

            string logKey =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + normalizedPattern
                + "|"
                + nyTime.ToString("yyyyMMddHHmmss")
                + "|"
                + price.ToString("0.00");

            // The evaluator can be called multiple times while the same
            // confirmed retest is still visible. Keep the trading state
            // untouched and suppress only duplicate telemetry.
            if (
                string.Equals(
                    lastSmartRetestConfirmedLogKey,
                    logKey,
                    StringComparison.Ordinal
                )
            )
            {
                return;
            }

            lastSmartRetestConfirmedLogKey =
                logKey;

            PrintBotMessage(
                "SMART RETEST CONFIRMED"
                + " | " + normalizedPattern
                + " | Side: " + (isLong ? "LONG" : "SHORT")
                + " | Price: " + price.ToString("0.00")
                + " | R20: " + score + "/5"
                + " | Age: "
                + Math.Max(
                    0,
                    (int)Math.Round(
                        (nyTime - pendingSmartRetestCreatedNy).TotalSeconds
                    )
                  )
                + "s"
                + " | Timing: "
                + (
                    (nyTime - pendingSmartRetestCreatedNy).TotalSeconds
                        <= SmartRetestFreshWindowSeconds
                        ? "FRESH"
                        : "STALE-CONFIRMED"
                  )
                + " | NY: " + nyTime.ToString("HH:mm:ss")
            );
        }

    }
}

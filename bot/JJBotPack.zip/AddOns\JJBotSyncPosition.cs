// JJ_SYNC_POSITION_V1 (2026-11-17)
//
// POR QUE EXISTE
//   El 2026-11-17 la slave entro con 12 contratos en vez de 4. Causa: la
//   orden del master se lleno en TRES ejecuciones parciales (1 + 1 + 2) y
//   el copiador manda una copia POR EJECUCION con el tamano fijo completo.
//   3 x 4 = 12. Con el stop de 33.5 pts eso son ~$800 en un trade.
//
//   El servidor (server.js) ya tiene el camino correcto escrito:
//
//       if (hasMasterPosition) { ... type: 'SYNC_POSITION', targetPosition ... }
//       // Backward compatibility for an older AddOn that does
//       // not yet send the post-fill master position.
//       ... type: 'COPY_TRADE' ...
//
//   SYNC_POSITION dice "quedate en -4" en vez de "vende 4". Es idempotente:
//   tres mensajes iguales dejan la slave en -4, no en -12. Pero el AddOn
//   nunca mandaba la posicion del master, asi que el servidor caia siempre
//   al camino viejo, y ademas el AddOn no sabia ejecutar SYNC_POSITION.
//
//   Este archivo aporta la segunda mitad: ejecutar SYNC_POSITION.
//   La primera mitad es una linea en SendTrade (mandar positionQuantity).
//
// COMO FUNCIONA
//   Lee la posicion actual de la slave, le suma lo que ya mandamos y aun
//   no se refleja (pendiente), y manda SOLO la diferencia contra el
//   objetivo. Si la diferencia es cero, no manda nada. Por eso los fills
//   parciales dejan de multiplicar.
//
// LIMITES DE SEGURIDAD
//   - JJSyncMaxDelta: nunca manda mas de 20 contratos de golpe. Si el
//     calculo pide mas, no manda nada y lo registra. Un numero absurdo es
//     sintoma de un bug, no una orden a obedecer.
//   - Lo pendiente se olvida a los 5 s para no quedar trabado si una orden
//     se rechaza.
//   - Cruzar de corto a largo (o al reves) se hace en dos ordenes.
//
// APAGAR: JJSyncPositionEnabled = false (vuelve al camino COPY_TRADE).

using System;
using System.Collections.Generic;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJCompanyBroAddon
    {
        private static readonly bool JJSyncPositionEnabled = true;

        // Tope duro. Ninguna sincronizacion legitima pide mas que esto.
        private const int JJSyncMaxDelta = 20;

        // Segundos tras los cuales se descarta lo pendiente (orden rechazada,
        // desconexion, etc.) para no quedar bloqueados.
        private const double JJSyncPendingTtlSeconds = 5.0;

        private readonly object jjSyncLock = new object();
        private readonly Dictionary<string, int> jjSyncPending = new Dictionary<string, int>();
        private readonly Dictionary<string, DateTime> jjSyncPendingUtc = new Dictionary<string, DateTime>();

        // Lee un entero con signo del JSON. ExtractInt del AddOn no maneja
        // el '-', y targetPosition es negativo en los cortos.
        private static int JJSyncParseSignedInt(string json, string key, out bool found)
        {
            found = false;
            if (string.IsNullOrEmpty(json)) return 0;

            int i = json.IndexOf(key, StringComparison.Ordinal);
            if (i < 0) return 0;

            i += key.Length;
            while (i < json.Length && (json[i] == ' ' || json[i] == '\t')) i++;

            bool neg = false;
            if (i < json.Length && (json[i] == '-' || json[i] == '+'))
            {
                neg = json[i] == '-';
                i++;
            }

            int value = 0;
            int digits = 0;
            while (i < json.Length && json[i] >= '0' && json[i] <= '9')
            {
                value = value * 10 + (json[i] - '0');
                i++;
                digits++;
                if (digits > 9) return 0;   // numero absurdo
            }

            if (digits == 0) return 0;

            found = true;
            return neg ? -value : value;
        }

        // Posicion firmada de una cuenta en un instrumento. Positivo = largo.
        private static int JJSyncSignedPosition(Account account, string symbol)
        {
            foreach (Position p in account.Positions)
            {
                if (p == null || p.Instrument == null) continue;
                if (p.Instrument.FullName != symbol) continue;

                if (p.MarketPosition == MarketPosition.Long) return Math.Abs(p.Quantity);
                if (p.MarketPosition == MarketPosition.Short) return -Math.Abs(p.Quantity);
                return 0;
            }
            return 0;
        }

        private void JJSyncSubmit(Account account, Instrument instrument, OrderAction action, int qty, string etiqueta)
        {
            Order o = account.CreateOrder(
                instrument,
                action,
                OrderType.Market,
                OrderEntry.Automated,
                TimeInForce.Day,
                qty,
                0,
                0,
                "",
                "JJ_COPY_" + etiqueta + "_" + DateTime.Now.Ticks,
                DateTime.MaxValue,
                null
            );

            account.Submit(new[] { o });
        }

        // Llamado desde CheckCommands cuando llega un SYNC_POSITION.
        // masterPosition NO limita el tamano de la slave: si el usuario puso
        // fixed size mas grande, es su decision. Solo se usa para dos cosas que
        // valen en todos los modos: si el master esta flat la slave cierra, y la
        // slave nunca queda del lado contrario al master.
        private void JJSyncPositionExecute(string targetAccount, string symbol, int targetPosition, int masterPosition)
        {
            if (!JJSyncPositionEnabled)
            {
                Print("JJ SYNC: desactivado, se ignora el comando.");
                return;
            }

            try
            {
                if (string.IsNullOrWhiteSpace(targetAccount) || string.IsNullOrWhiteSpace(symbol))
                    return;

                Account account = null;
                foreach (Account a in Account.All)
                {
                    if (a != null && a.Name == targetAccount) { account = a; break; }
                }

                if (account == null)
                {
                    Print("JJ SYNC: cuenta no encontrada: " + targetAccount);
                    return;
                }

                Instrument instrument = Instrument.GetInstrument(symbol);
                if (instrument == null)
                {
                    Print("JJ SYNC: instrumento no encontrado: " + symbol);
                    return;
                }

                // NO se recorta el objetivo contra el tamano del master.
                // Si el usuario pone fixed size en 10 con el master en 4, eso es una
                // decision suya de arriesgar mas en esa cuenta y hay que respetarla.
                // Las cuentas sin fixed size ya siguen al master solas: en modo SAME
                // el servidor hace targetAbs = sourceAbs, o sea el objetivo ES la
                // posicion del master.
                //
                // Lo unico que si se fuerza es el lado y el cero, porque es cierto en
                // todos los modos: si el master esta flat, la slave va a flat.
                if (masterPosition == 0 && targetPosition != 0)
                {
                    Print("JJ SYNC: el master esta flat pero el objetivo era " +
                          targetPosition + ". Se cierra la slave | cuenta=" + targetAccount);
                    targetPosition = 0;
                }

                // El lado tampoco puede contradecir al master: si el master esta corto,
                // la slave no puede quedar larga, sea cual sea el modo.
                if (masterPosition != 0 && targetPosition != 0 &&
                    Math.Sign(targetPosition) != Math.Sign(masterPosition))
                {
                    int corregido = Math.Sign(masterPosition) * Math.Abs(targetPosition);
                    Print("JJ SYNC: el objetivo " + targetPosition +
                          " va al lado contrario del master (" + masterPosition +
                          "). Se usa " + corregido + " | cuenta=" + targetAccount);
                    targetPosition = corregido;
                }

                string key = targetAccount + "|" + symbol;

                int actual;
                int pendiente;
                int delta;

                lock (jjSyncLock)
                {
                    DateTime ultimo;
                    if (jjSyncPendingUtc.TryGetValue(key, out ultimo) &&
                        (DateTime.UtcNow - ultimo).TotalSeconds > JJSyncPendingTtlSeconds)
                    {
                        jjSyncPending[key] = 0;   // caduco: la orden no llego a reflejarse
                    }

                    if (!jjSyncPending.TryGetValue(key, out pendiente))
                        pendiente = 0;

                    actual = JJSyncSignedPosition(account, symbol);

                    // Lo que la slave va a tener cuando se reflejen las ordenes ya mandadas.
                    int efectivo = actual + pendiente;
                    delta = targetPosition - efectivo;

                    if (delta == 0)
                    {
                        Print("JJ SYNC: " + targetAccount + " " + symbol +
                              " ya esta en el objetivo " + targetPosition +
                              " (actual " + actual + ", pendiente " + pendiente + "). Sin orden.");
                        return;
                    }

                    if (Math.Abs(delta) > JJSyncMaxDelta)
                    {
                        Print("JJ SYNC BLOQUEADO: delta " + delta + " supera el tope de " +
                              JJSyncMaxDelta + " | cuenta=" + targetAccount +
                              " objetivo=" + targetPosition + " actual=" + actual +
                              " pendiente=" + pendiente + ". NO se manda nada.");
                        return;
                    }

                    jjSyncPending[key] = pendiente + delta;
                    jjSyncPendingUtc[key] = DateTime.UtcNow;
                }

                int efectivoAntes = actual + pendiente;

                Print("JJ SYNC: " + targetAccount + " " + symbol +
                      " | objetivo " + targetPosition +
                      " | actual " + actual + " | pendiente " + pendiente +
                      " | manda " + delta);

                // Cruce por cero: primero se cierra lo que hay, luego se abre al otro lado.
                // Asi ningun broker rechaza un BuyToCover mayor que el corto existente.
                if (efectivoAntes != 0 && Math.Sign(targetPosition) != 0 &&
                    Math.Sign(efectivoAntes) != Math.Sign(targetPosition))
                {
                    int cierre = Math.Abs(efectivoAntes);
                    JJSyncSubmit(account, instrument,
                        efectivoAntes > 0 ? OrderAction.Sell : OrderAction.BuyToCover,
                        cierre, "SYNCFLAT");

                    int apertura = Math.Abs(targetPosition);
                    JJSyncSubmit(account, instrument,
                        targetPosition > 0 ? OrderAction.Buy : OrderAction.SellShort,
                        apertura, "SYNCOPEN");
                    return;
                }

                int cantidad = Math.Abs(delta);
                OrderAction accion;

                if (delta > 0)
                    accion = efectivoAntes < 0 ? OrderAction.BuyToCover : OrderAction.Buy;
                else
                    accion = efectivoAntes > 0 ? OrderAction.Sell : OrderAction.SellShort;

                JJSyncSubmit(account, instrument, accion, cantidad, "SYNC");
            }
            catch (Exception ex)
            {
                Print("JJ SYNC error: " + ex.Message);
            }
        }

        // Llamado desde CheckCommands. Devuelve true si el json era un SYNC_POSITION.
        private bool JJSyncHandleCommand(string json)
        {
            if (string.IsNullOrEmpty(json)) return false;
            if (json.IndexOf("SYNC_POSITION", StringComparison.Ordinal) < 0) return false;

            string cuenta = ExtractValue(json, "\"account\":\"");
            string simbolo = ExtractValue(json, "\"symbol\":\"");

            bool hay;
            int objetivo = JJSyncParseSignedInt(json, "\"targetPosition\":", out hay);

            if (!hay)
            {
                Print("JJ SYNC: comando sin targetPosition, se ignora: " + json);
                return true;
            }

            bool hayMaster;
            int master = JJSyncParseSignedInt(json, "\"masterPosition\":", out hayMaster);

            if (!hayMaster)
            {
                // Sin la posicion del master no se puede aplicar el tope. Se pasa el
                // propio objetivo para que el recorte no haga nada, en vez de bloquear.
                master = objetivo;
            }

            JJSyncPositionExecute(cuenta, simbolo, objetivo, master);
            return true;
        }
    }
}

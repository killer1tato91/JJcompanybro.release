// JJ_SYNC_POSITION_V1 (2026-11-17)
//
// POR QUE EXISTE
//   El 2026-11-17 la slave entro con 12 contratos en vez de 4. Causa: la
//   orden del master se lleno en TRES ejecuciones parciales (1 + 1 + 2) y
//   el copiador manda una copia POR EJECUCION con el tamano fijo completo.
//   3 x 4 = 12. Con el stop de 33.5 pts eso son ~$800 en un trade.
//
//   El servidor (server.js) ya tiene el camino correcto escrito:
//
//       if (hasMasterPosition) { ... type: 'SYNC_POSITION', targetPosition ... }
//       // Backward compatibility for an older AddOn that does
//       // not yet send the post-fill master position.
//       ... type: 'COPY_TRADE' ...
//
//   SYNC_POSITION dice "quedate en -4" en vez de "vende 4". Es idempotente:
//   tres mensajes iguales dejan la slave en -4, no en -12. Pero el AddOn
//   nunca mandaba la posicion del master, asi que el servidor caia siempre
//   al camino viejo, y ademas el AddOn no sabia ejecutar SYNC_POSITION.
//
//   Este archivo aporta la segunda mitad: ejecutar SYNC_POSITION.
//   La primera mitad es una linea en SendTrade (mandar positionQuantity).
//
// COMO FUNCIONA
//   Lee la posicion actual de la slave, le suma lo que ya mandamos y aun
//   no se refleja (pendiente), y manda SOLO la diferencia contra el
//   objetivo. Si la diferencia es cero, no manda nada. Por eso los fills
//   parciales dejan de multiplicar.
//
// LIMITES DE SEGURIDAD
//   - JJSyncMaxDelta: nunca manda mas de 20 contratos de golpe. Si el
//     calculo pide mas, no manda nada y lo registra. Un numero absurdo es
//     sintoma de un bug, no una orden a obedecer.
//   - Lo pendiente se olvida a los 5 s para no quedar trabado si una orden
//     se rechaza.
//   - Cruzar de corto a largo (o al reves) se hace en dos ordenes.
//
// APAGAR: JJSyncPositionEnabled = false (vuelve al camino COPY_TRADE).

using System;
using System.Collections.Generic;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJCompanyBroAddon
    {
        private static readonly bool JJSyncPositionEnabled = true;

        // Tope duro. Ninguna sincronizacion legitima pide mas que esto.
        private const int JJSyncMaxDelta = 20;

        // Segundos tras los cuales se descarta lo pendiente (orden rechazada,
        // desconexion, etc.) para no quedar bloqueados.
        private const double JJSyncPendingTtlSeconds = 5.0;

        private readonly object jjSyncLock = new object();
        private readonly Dictionary<string, DateTime> jjSyncPendingUtc = new Dictionary<string, DateTime>();

        // V1.7.123 (18-nov-2026) - ARREGLO DEL DOBLE CONTEO.
        // Antes lo pendiente era un contador (jjSyncPending) al que se le SUMABA el delta
        // al mandar la orden, pero nunca se le restaba al llenarse: solo se borraba por el
        // TTL de 5 s. Dos SYNC seguidos dentro de esa ventana contaban la misma orden dos
        // veces. El 18-nov la esclava recibio "cubrir 3" teniendo 2 y quedo LONG 1
        // (entrada 09:40:52.6 -> salida 09:40:56.2, 3.6 s de diferencia).
        // Ahora lo pendiente se DERIVA de las ordenes vivas que mandamos: en cuanto una
        // llena o se cancela deja de contar sola, sin depender de ningun temporizador.
        private readonly Dictionary<string, List<Order>> jjSyncOrders = new Dictionary<string, List<Order>>();

        // Suma firmada de lo que falta por llenar de nuestras propias ordenes SYNC.
        // Compra = positivo, venta = negativo. Limpia de paso las ya terminadas.
        private int JJSyncPendingFromOrders(string key)
        {
            List<Order> lista;
            if (!jjSyncOrders.TryGetValue(key, out lista) || lista == null)
                return 0;

            int suma = 0;

            for (int i = lista.Count - 1; i >= 0; i--)
            {
                Order o = lista[i];

                if (o == null) { lista.RemoveAt(i); continue; }

                OrderState st = o.OrderState;

                bool terminada =
                    st == OrderState.Filled ||
                    st == OrderState.Cancelled ||
                    st == OrderState.Rejected;

                if (terminada) { lista.RemoveAt(i); continue; }

                int restante = o.Quantity - o.Filled;
                if (restante <= 0) continue;

                bool compra =
                    o.OrderAction == OrderAction.Buy ||
                    o.OrderAction == OrderAction.BuyToCover;

                suma += compra ? restante : -restante;
            }

            if (lista.Count == 0)
                jjSyncOrders.Remove(key);

            return suma;
        }

        private void JJSyncRegisterOrder(string key, Order o)
        {
            if (o == null) return;

            lock (jjSyncLock)
            {
                List<Order> lista;
                if (!jjSyncOrders.TryGetValue(key, out lista) || lista == null)
                {
                    lista = new List<Order>();
                    jjSyncOrders[key] = lista;
                }
                lista.Add(o);
            }
        }

        // Lee un entero con signo del JSON. ExtractInt del AddOn no maneja
        // el '-', y targetPosition es negativo en los cortos.
        private static int JJSyncParseSignedInt(string json, string key, out bool found)
        {
            found = false;
            if (string.IsNullOrEmpty(json)) return 0;

            int i = json.IndexOf(key, StringComparison.Ordinal);
            if (i < 0) return 0;

            i += key.Length;
            while (i < json.Length && (json[i] == ' ' || json[i] == '\t')) i++;

            bool neg = false;
            if (i < json.Length && (json[i] == '-' || json[i] == '+'))
            {
                neg = json[i] == '-';
                i++;
            }

            int value = 0;
            int digits = 0;
            while (i < json.Length && json[i] >= '0' && json[i] <= '9')
            {
                value = value * 10 + (json[i] - '0');
                i++;
                digits++;
                if (digits > 9) return 0;   // numero absurdo
            }

            if (digits == 0) return 0;

            found = true;
            return neg ? -value : value;
        }

        // Posicion firmada de una cuenta en un instrumento. Positivo = largo.
        private static int JJSyncSignedPosition(Account account, string symbol)
        {
            foreach (Position p in account.Positions)
            {
                if (p == null || p.Instrument == null) continue;
                if (p.Instrument.FullName != symbol) continue;

                if (p.MarketPosition == MarketPosition.Long) return Math.Abs(p.Quantity);
                if (p.MarketPosition == MarketPosition.Short) return -Math.Abs(p.Quantity);
                return 0;
            }
            return 0;
        }

        private void JJSyncSubmit(Account account, Instrument instrument, OrderAction action, int qty, string etiqueta, string key)
        {
            Order o = account.CreateOrder(
                instrument,
                action,
                OrderType.Market,
                OrderEntry.Automated,
                TimeInForce.Day,
                qty,
                0,
                0,
                "",
                "JJ_COPY_" + etiqueta + "_" + DateTime.Now.Ticks,
                DateTime.MaxValue,
                null
            );

            // V1.7.123: se registra ANTES de mandarla para que el siguiente SYNC la
            // vea como pendiente, y deje de contarla sola en cuanto llene o se cancele.
            JJSyncRegisterOrder(key, o);

            account.Submit(new[] { o });
        }

        // Llamado desde CheckCommands cuando llega un SYNC_POSITION.
        // masterPosition NO limita el tamano de la slave: si el usuario puso
        // fixed size mas grande, es su decision. Solo se usa para dos cosas que
        // valen en todos los modos: si el master esta flat la slave cierra, y la
        // slave nunca queda del lado contrario al master.
        private void JJSyncPositionExecute(string targetAccount, string symbol, int targetPosition, int masterPosition)
        {
            if (!JJSyncPositionEnabled)
            {
                Print("JJ SYNC: desactivado, se ignora el comando.");
                return;
            }

            try
            {
                if (string.IsNullOrWhiteSpace(targetAccount) || string.IsNullOrWhiteSpace(symbol))
                    return;

                Account account = null;
                foreach (Account a in Account.All)
                {
                    if (a != null && a.Name == targetAccount) { account = a; break; }
                }

                if (account == null)
                {
                    Print("JJ SYNC: cuenta no encontrada: " + targetAccount);
                    return;
                }

                Instrument instrument = Instrument.GetInstrument(symbol);
                if (instrument == null)
                {
                    Print("JJ SYNC: instrumento no encontrado: " + symbol);
                    return;
                }

                // NO se recorta el objetivo contra el tamano del master.
                // Si el usuario pone fixed size en 10 con el master en 4, eso es una
                // decision suya de arriesgar mas en esa cuenta y hay que respetarla.
                // Las cuentas sin fixed size ya siguen al master solas: en modo SAME
                // el servidor hace targetAbs = sourceAbs, o sea el objetivo ES la
                // posicion del master.
                //
                // Lo unico que si se fuerza es el lado y el cero, porque es cierto en
                // todos los modos: si el master esta flat, la slave va a flat.
                if (masterPosition == 0 && targetPosition != 0)
                {
                    Print("JJ SYNC: el master esta flat pero el objetivo era " +
                          targetPosition + ". Se cierra la slave | cuenta=" + targetAccount);
                    targetPosition = 0;
                }

                // El lado tampoco puede contradecir al master: si el master esta corto,
                // la slave no puede quedar larga, sea cual sea el modo.
                if (masterPosition != 0 && targetPosition != 0 &&
                    Math.Sign(targetPosition) != Math.Sign(masterPosition))
                {
                    int corregido = Math.Sign(masterPosition) * Math.Abs(targetPosition);
                    Print("JJ SYNC: el objetivo " + targetPosition +
                          " va al lado contrario del master (" + masterPosition +
                          "). Se usa " + corregido + " | cuenta=" + targetAccount);
                    targetPosition = corregido;
                }

                string key = targetAccount + "|" + symbol;

                int actual;
                int pendiente;
                int delta;

                lock (jjSyncLock)
                {
                    // V1.7.123: lo pendiente sale de las ordenes vivas, no de un contador.
                    pendiente = JJSyncPendingFromOrders(key);

                    actual = JJSyncSignedPosition(account, symbol);

                    // Lo que la slave va a tener cuando se reflejen las ordenes ya mandadas.
                    int efectivo = actual + pendiente;
                    delta = targetPosition - efectivo;

                    if (delta == 0)
                    {
                        Print("JJ SYNC: " + targetAccount + " " + symbol +
                              " ya esta en el objetivo " + targetPosition +
                              " (actual " + actual + ", pendiente " + pendiente + "). Sin orden.");
                        return;
                    }

                    if (Math.Abs(delta) > JJSyncMaxDelta)
                    {
                        Print("JJ SYNC BLOQUEADO: delta " + delta + " supera el tope de " +
                              JJSyncMaxDelta + " | cuenta=" + targetAccount +
                              " objetivo=" + targetPosition + " actual=" + actual +
                              " pendiente=" + pendiente + ". NO se manda nada.");
                        return;
                    }

                    jjSyncPendingUtc[key] = DateTime.UtcNow;
                }

                int efectivoAntes = actual + pendiente;

                Print("JJ SYNC: " + targetAccount + " " + symbol +
                      " | objetivo " + targetPosition +
                      " | actual " + actual + " | pendiente " + pendiente +
                      " | manda " + delta);

                // Cruce por cero: primero se cierra lo que hay, luego se abre al otro lado.
                // Asi ningun broker rechaza un BuyToCover mayor que el corto existente.
                if (efectivoAntes != 0 && Math.Sign(targetPosition) != 0 &&
                    Math.Sign(efectivoAntes) != Math.Sign(targetPosition))
                {
                    int cierre = Math.Abs(efectivoAntes);
                    JJSyncSubmit(account, instrument,
                        efectivoAntes > 0 ? OrderAction.Sell : OrderAction.BuyToCover,
                        cierre, "SYNCFLAT", key);

                    int apertura = Math.Abs(targetPosition);
                    JJSyncSubmit(account, instrument,
                        targetPosition > 0 ? OrderAction.Buy : OrderAction.SellShort,
                        apertura, "SYNCOPEN", key);
                    return;
                }

                int cantidad = Math.Abs(delta);
                OrderAction accion;

                if (delta > 0)
                    accion = efectivoAntes < 0 ? OrderAction.BuyToCover : OrderAction.Buy;
                else
                    accion = efectivoAntes > 0 ? OrderAction.Sell : OrderAction.SellShort;

                // V1.7.123 - RED DE SEGURIDAD: una orden que REDUCE nunca puede pasarse de
                // cero. Si por lectura atrasada del broker o por un objetivo mal calculado
                // la cantidad excede lo que creemos tener, se recorta hasta aplanar.
                // El 18-nov la esclava tenia 2 cortos y le llego "cubrir 3": quedo LONG 1.
                // Con este recorte lo peor que puede pasar es quedarse plana, nunca
                // invertida contra el master.
                bool reduce =
                    (delta > 0 && efectivoAntes < 0) ||
                    (delta < 0 && efectivoAntes > 0);

                if (reduce && cantidad > Math.Abs(efectivoAntes))
                {
                    Print("JJ SYNC RECORTE: la orden de " + cantidad +
                          " pasaria de cero teniendo " + efectivoAntes +
                          " | cuenta=" + targetAccount +
                          " objetivo=" + targetPosition +
                          ". Se recorta a " + Math.Abs(efectivoAntes) + " (aplana, no invierte).");
                    cantidad = Math.Abs(efectivoAntes);
                }

                if (cantidad <= 0)
                {
                    Print("JJ SYNC: cantidad 0 tras el recorte | cuenta=" + targetAccount + ". Sin orden.");
                    return;
                }

                JJSyncSubmit(account, instrument, accion, cantidad, "SYNC", key);
            }
            catch (Exception ex)
            {
                Print("JJ SYNC error: " + ex.Message);
            }
        }

        // Llamado desde CheckCommands. Devuelve true si el json era un SYNC_POSITION.
        private bool JJSyncHandleCommand(string json)
        {
            if (string.IsNullOrEmpty(json)) return false;
            if (json.IndexOf("SYNC_POSITION", StringComparison.Ordinal) < 0) return false;

            string cuenta = ExtractValue(json, "\"account\":\"");
            string simbolo = ExtractValue(json, "\"symbol\":\"");

            bool hay;
            int objetivo = JJSyncParseSignedInt(json, "\"targetPosition\":", out hay);

            if (!hay)
            {
                Print("JJ SYNC: comando sin targetPosition, se ignora: " + json);
                return true;
            }

            bool hayMaster;
            int master = JJSyncParseSignedInt(json, "\"masterPosition\":", out hayMaster);

            if (!hayMaster)
            {
                // Sin la posicion del master no se puede aplicar el tope. Se pasa el
                // propio objetivo para que el recorte no haga nada, en vez de bloquear.
                master = objetivo;
            }

            JJSyncPositionExecute(cuenta, simbolo, objetivo, master);
            return true;
        }
    }
}

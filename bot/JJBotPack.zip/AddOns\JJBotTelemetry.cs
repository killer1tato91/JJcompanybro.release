#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TELEMETRY / SHARED STATE
    // Stage 3 segmentation from JJBotControl v1.6.20.
    //
    // IMPORTANT:
    // Structural refactor only.
    // No signal, risk, learning, order, or trade-management logic changed.
    // Platform remote-command execution remains in JJBotControl for now.
    // =========================================================
    public partial class JJBotWindow
    {
        private void UpdateExecutionMonitor()
        {
            MarketPosition localPosition;
            int localQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            int localStopTicks;
            int localTargetTicks;

            lock (executionStateLock)
            {
                localPosition =
                    entryMarketPosition;

                localQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localStopTicks =
                    activeStopTicks;

                localTargetTicks =
                    activeTargetTicks;
            }

            PublishSharedState();

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (positionText != null)
                    {
                        if (
                            localPosition ==
                                MarketPosition.Long
                        )
                        {
                            positionText.Text =
                                "LONG";

                            positionText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localPosition ==
                                MarketPosition.Short
                        )
                        {
                            positionText.Text =
                                "SHORT";

                            positionText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else
                        {
                            positionText.Text =
                                "FLAT";

                            positionText.Foreground =
                                Brushes.White;
                        }
                    }

                    if (positionQtyText != null)
                    {
                        positionQtyText.Text =
                            localQuantity.ToString();
                    }

                    if (entryPriceText != null)
                    {
                        entryPriceText.Text =
                            localEntryPrice > 0
                                ? FormatPrice(
                                    localEntryPrice
                                )
                                : "--";
                    }

                    if (stopPriceText != null)
                    {
                        stopPriceText.Text =
                            localStopPrice > 0
                                ? FormatPrice(
                                    localStopPrice
                                )
                                : "--";
                    }

                    if (targetPriceText != null)
                    {
                        targetPriceText.Text =
                            localTargetPrice > 0
                                ? FormatPrice(
                                    localTargetPrice
                                )
                                : "--";
                    }

                    if (riskRewardText != null)
                    {
                        double riskDistance =
                            0;

                        double rewardDistance =
                            0;

                        if (
                            localEntryPrice > 0 &&
                            localStopPrice > 0 &&
                            localTargetPrice > 0
                        )
                        {
                            riskDistance =
                                Math.Abs(
                                    localEntryPrice -
                                    localStopPrice
                                );

                            rewardDistance =
                                Math.Abs(
                                    localTargetPrice -
                                    localEntryPrice
                                );
                        }

                        double rr =
                            riskDistance > 0
                                ? rewardDistance /
                                    riskDistance
                                : (
                                    localStopTicks > 0
                                        ? (
                                            double
                                            )localTargetTicks
                                            / localStopTicks
                                        : 0
                                );

                        riskRewardText.Text =
                            "1 : "
                            + rr.ToString(
                                "0.00"
                            );
                    }

                    if (orderStatusText != null)
                    {
                        orderStatusText.Text =
                            localExecutionStatus;

                        if (
                            localExecutionStatus ==
                                "PROTECTED"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.LimeGreen;
                        }
                        else if (
                            localExecutionStatus ==
                                "STOP FILLED" ||
                            localExecutionStatus ==
                                "ENTRY ERROR" ||
                            localExecutionStatus ==
                                "PROTECTION ERROR" ||
                            localExecutionStatus ==
                                "DAILY LOSS FLATTEN"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.OrangeRed;
                        }
                        else if (
                            localExecutionStatus ==
                                "ENTRY SUBMITTED" ||
                            localExecutionStatus ==
                                "ENTRY FILLED" ||
                            localExecutionStatus ==
                                "FLATTENING" ||
                            localExecutionStatus ==
                                "WAITING PROTECTION" ||
                            localExecutionStatus ==
                                "UPDATING OCO"
                        )
                        {
                            orderStatusText.Foreground =
                                Brushes.Goldenrod;
                        }
                        else
                        {
                            orderStatusText.Foreground =
                                Brushes.White;
                        }
                    }
                })
            );
        }
        private void PublishSharedState()
        {
            string position;
            int localTradesToday;
            int localAmTrades;
            int localPmTrades;
            double localRealizedPnL;
            double localUnrealizedPnL;
            double totalPnL;
            bool localDailyLocked;
            int localEntryQuantity;
            double localEntryPrice;
            double localStopPrice;
            double localTargetPrice;
            string localExecutionStatus;
            bool localDailyTargetProtectionArmed;
            bool localMomentumTrailingActive;
            int localMomentumTrailingStage;

            lock (executionStateLock)
            {
                position =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? "LONG"
                        : entryMarketPosition ==
                            MarketPosition.Short
                            ? "SHORT"
                            : "FLAT";

                localTradesToday =
                    tradesToday;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                totalPnL =
                    localRealizedPnL +
                    localUnrealizedPnL;

                localDailyLocked =
                    persistentDailyLocked;

                localEntryQuantity =
                    entryQuantity;

                localEntryPrice =
                    entryFillPrice;

                localStopPrice =
                    activeStopPrice;

                localTargetPrice =
                    activeTargetPrice;

                localExecutionStatus =
                    executionStatus;

                localDailyTargetProtectionArmed =
                    dailyTargetProtectionArmed;

                localMomentumTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localMomentumTrailingStage =
                    momentumTrailingStage;
            }

            string h4Trend =
                "WAITING";

            string h1Trend =
                "WAITING";

            string htfContextBias =
                "NEUTRAL 0/2";

            string m5Trend =
                "WAITING";

            string m5VwapSide =
                "WAITING";

            string m5Liquidity =
                "NONE";

            string m5Structure =
                "WAITING";

            string rangeMomentum =
                "WAITING RANGE";

            int rangeLongScore = 0;
            int rangeShortScore = 0;

            DateTime sessionReferenceNy =
                GetCurrentNewYorkTime();

            lock (marketContextLock)
            {
                h4Trend =
                    latestH4Trend
                    ?? "WAITING";

                h1Trend =
                    latestH1Trend
                    ?? "WAITING";

                htfContextBias =
                    latestHtfContextBias
                    ?? "NEUTRAL 0/2";

                if (latestM5ContextReady)
                {
                    m5Trend =
                        latestM5BullishTrend
                            ? "BULLISH"
                            : latestM5BearishTrend
                                ? "BEARISH"
                                : "NEUTRAL";

                    m5VwapSide =
                        latestM5AboveVwap
                            ? "ABOVE VWAP"
                            : latestM5BelowVwap
                                ? "BELOW VWAP"
                                : "AT VWAP";

                    m5Liquidity =
                        latestM5LiquidityState
                        ?? "NONE";

                    m5Structure =
                        latestM5StructureState
                        ?? "WAITING";

                    if (
                        latestM5DecisionNyTime !=
                            DateTime.MinValue
                    )
                    {
                        sessionReferenceNy =
                            latestM5DecisionNyTime;
                    }
                }

                rangeMomentum =
                    latestRangeMomentumState
                    ?? "WAITING RANGE";

                rangeLongScore =
                    latestRangeLongScore;

                rangeShortScore =
                    latestRangeShortScore;
            }

            int learningPatterns = 0;
            int learningTrades = 0;

            lock (SharedLearningSyncRoot)
            {
                if (
                    learningMemory != null &&
                    learningMemory.Patterns != null
                )
                {
                    learningPatterns =
                        learningMemory.Patterns.Count;

                    foreach (
                        JJBotLearningPattern pattern
                        in learningMemory.Patterns
                    )
                    {
                        if (pattern != null)
                        {
                            learningTrades +=
                                pattern.Trades;
                        }
                    }
                }
            }

            string trailingState =
                "OFF";

            if (localDailyTargetProtectionArmed)
            {
                trailingState =
                    "DAILY TARGET TRAIL";
            }
            else if (localMomentumTrailingActive)
            {
                trailingState =
                    localMomentumTrailingStage == 0
                        ? "ARMED"
                        : localMomentumTrailingStage == 1
                            ? "BREAK EVEN"
                            : localMomentumTrailingStage == 2
                                ? "LOCK +"
                                    + MomentumLockProfitTicks
                                    + "t"
                                : localMomentumTrailingStage == 3
                                    ? "LOCK +"
                                        + MomentumLock2ProfitTicks
                                        + "t"
                                    : "TRAIL "
                                        + MomentumTrailDistanceTicks
                                        + "t";
            }

            JJBotSharedState.Update(
                botRunning,
                selectedAccount != null
                    ? selectedAccount.Name
                    : string.Empty,
                selectedInstrument != null
                    ? selectedInstrument.FullName
                    : string.Empty,
                localTradesToday,
                activeMaxTrades,
                localAmTrades,
                localPmTrades,
                localRealizedPnL,
                localUnrealizedPnL,
                totalPnL,
                localDailyLocked,
                position,
                localEntryQuantity,
                localEntryPrice,
                localStopPrice,
                localTargetPrice,
                localExecutionStatus,
                currentSignalState,
                currentSetupState,
                activeStrategyMode,
                GetBotSessionWindow(
                    sessionReferenceNy
                ),
                h4Trend,
                h1Trend,
                htfContextBias,
                m5Trend,
                m5VwapSide,
                m5Liquidity,
                m5Structure,
                rangeMomentum,
                rangeLongScore,
                rangeShortScore,
                true,
                learningPatterns,
                learningTrades,
                trailingState
            );
        }
        private void LoadPlatformBridgeConfig()
        {
            try
            {
                platformConfigFile =
                    Path.Combine(
                        Environment.GetFolderPath(
                            Environment.SpecialFolder.MyDocuments
                        ),
                        "J&J Company Bro",
                        "config.json"
                    );

                if (
                    !File.Exists(
                        platformConfigFile
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: config.json not found at "
                        + platformConfigFile
                    );

                    return;
                }

                string json =
                    File.ReadAllText(
                        platformConfigFile
                    );

                string loadedApiKey =
                    ExtractJsonStringValue(
                        json,
                        "apiKey"
                    );

                string loadedServerUrl =
                    ExtractJsonStringValue(
                        json,
                        "serverUrl"
                    );

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedApiKey
                    )
                )
                {
                    platformApiKey =
                        loadedApiKey.Trim();
                }

                if (
                    !string.IsNullOrWhiteSpace(
                        loadedServerUrl
                    )
                )
                {
                    platformServerUrl =
                        loadedServerUrl
                            .Trim()
                            .TrimEnd('/');
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformServerUrl
                    )
                )
                {
                    platformServerUrl =
                        "http://localhost:3001";
                }

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE: apiKey missing in config.json"
                    );
                }
                else
                {
                    PrintBotMessage(
                        "PLATFORM BRIDGE READY"
                    );
                }
            }
            catch (Exception ex)
            {
                platformApiKey =
                    string.Empty;

                platformServerUrl =
                    "http://localhost:3001";

                PrintBotMessage(
                    "PLATFORM BRIDGE CONFIG ERROR: "
                    + ex.Message
                );
            }
        }
        private string ExtractJsonStringValue(
            string json,
            string propertyName)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return string.Empty;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*\\\"(?<value>(?:\\\\.|[^\\\"])*)\\\"";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                if (
                    !match.Success
                )
                {
                    return string.Empty;
                }

                string value =
                    match.Groups["value"].Value;

                return
                    value
                        .Replace("\\\\", "\\")
                        .Replace("\\\"", "\"")
                        .Replace("\\r", "\r")
                        .Replace("\\n", "\n")
                        .Replace("\\t", "\t");
            }
            catch
            {
                return string.Empty;
            }
        }
        private int ExtractJsonIntValue(
            string json,
            string propertyName,
            int fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                int value;

                if (
                    match.Success &&
                    int.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }
        private double ExtractJsonDoubleValue(
            string json,
            string propertyName,
            double fallback)
        {
            if (
                string.IsNullOrWhiteSpace(json) ||
                string.IsNullOrWhiteSpace(
                    propertyName
                )
            )
            {
                return fallback;
            }

            try
            {
                string pattern =
                    "\\\""
                    + Regex.Escape(propertyName)
                    + "\\\"\\s*:\\s*(?<value>-?[0-9]+(?:\\.[0-9]+)?)";

                Match match =
                    Regex.Match(
                        json,
                        pattern,
                        RegexOptions.IgnoreCase
                    );

                double value;

                if (
                    match.Success &&
                    double.TryParse(
                        match.Groups["value"].Value,
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out value
                    )
                )
                {
                    return value;
                }
            }
            catch
            {
            }

            return fallback;
        }
        private void StartPlatformTelemetry()
        {
            if (
                platformTelemetryTimer != null
            )
            {
                return;
            }

            platformTelemetryTimer =
                new DispatcherTimer(
                    DispatcherPriority.Background,
                    Dispatcher
                );

            platformTelemetryTimer.Interval =
                TimeSpan.FromSeconds(
                    PlatformTelemetryIntervalSeconds
                );

            platformTelemetryTimer.Tick +=
                PlatformTelemetryTimerTick;

            platformTelemetryTimer.Start();

            // Send once immediately so the platform does not
            // have to wait for the first timer interval.
            PublishPlatformTelemetry();
        }
        private void StopPlatformTelemetry()
        {
            DispatcherTimer timer =
                platformTelemetryTimer;

            platformTelemetryTimer = null;

            if (timer == null)
            {
                return;
            }

            try
            {
                timer.Stop();

                timer.Tick -=
                    PlatformTelemetryTimerTick;
            }
            catch
            {
            }
        }
        private void PlatformTelemetryTimerTick(
            object sender,
            EventArgs e)
        {
            PublishPlatformTelemetry();
        }
        private void PublishPlatformTelemetry()
        {
            if (
                platformTelemetryRequestInFlight
            )
            {
                return;
            }

            if (
                string.IsNullOrWhiteSpace(
                    platformApiKey
                )
            )
            {
                // The main J&J Company Bro AddOn may have
                // created config.json after this bot window
                // was opened. Retry loading it automatically.
                LoadPlatformBridgeConfig();

                if (
                    string.IsNullOrWhiteSpace(
                        platformApiKey
                    )
                )
                {
                    return;
                }
            }

            try
            {
                PublishSharedState();

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : string.Empty;

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : string.Empty;

                JJBotSharedSnapshot snapshot =
                    JJBotSharedState.GetSnapshot(
                        accountName,
                        instrumentName
                    );

                string direction =
                    GetTelemetryDirection();

                string strategy =
                    GetTelemetryStrategy();

                int contracts =
                    botRunning
                        ? activeContracts
                        : GetTelemetryIntFromTextBox(
                            contractsBox,
                            activeContracts
                        );

                int stopTicks =
                    botRunning
                        ? activeStopTicks
                        : GetTelemetryIntFromTextBox(
                            stopBox,
                            activeStopTicks
                        );

                int targetTicks =
                    botRunning
                        ? activeTargetTicks
                        : GetTelemetryIntFromTextBox(
                            targetBox,
                            activeTargetTicks
                        );

                int maxTrades =
                    botRunning
                        ? activeMaxTrades
                        : GetTelemetryIntFromTextBox(
                            maxTradesBox,
                            activeMaxTrades
                        );

                double dailyTarget =
                    botRunning
                        ? activeDailyTarget
                        : GetTelemetryDoubleFromTextBox(
                            dailyTargetBox,
                            activeDailyTarget
                        );

                double dailyLoss =
                    botRunning
                        ? activeDailyLoss
                        : GetTelemetryDoubleFromTextBox(
                            dailyLossBox,
                            activeDailyLoss
                        );

                double dollarRiskCap =
                    botRunning
                        ? activeDollarRiskCap
                        : GetTelemetryDoubleFromTextBox(
                            dollarRiskCapBox,
                            activeDollarRiskCap
                        );

                string json =
                    BuildPlatformTelemetryJson(
                        snapshot,
                        accountName,
                        instrumentName,
                        direction,
                        strategy,
                        contracts,
                        stopTicks,
                        targetTicks,
                        maxTrades,
                        dailyTarget,
                        dailyLoss,
                        dollarRiskCap
                    );

                string endpoint =
                    platformServerUrl
                        .TrimEnd('/')
                    + "/api/bot/state";

                platformTelemetryRequestInFlight =
                    true;

                ThreadPool.QueueUserWorkItem(
                    delegate
                    {
                        SendPlatformTelemetryRequest(
                            endpoint,
                            json
                        );
                    }
                );
            }
            catch (Exception ex)
            {
                platformTelemetryRequestInFlight =
                    false;

                PrintBotMessage(
                    "PLATFORM TELEMETRY BUILD ERROR: "
                    + ex.Message
                );
            }
        }
        private string GetTelemetryDirection()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeDirection
                )
            )
            {
                return activeDirection;
            }

            if (
                directionCombo != null &&
                directionCombo.SelectedItem != null
            )
            {
                return
                    directionCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeDirection
                )
                    ? "BOTH"
                    : activeDirection;
        }
        private string GetTelemetryStrategy()
        {
            if (
                botRunning &&
                !string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
            )
            {
                return activeStrategyMode;
            }

            if (
                strategyCombo != null &&
                strategyCombo.SelectedItem != null
            )
            {
                return
                    strategyCombo
                        .SelectedItem
                        .ToString();
            }

            return
                string.IsNullOrWhiteSpace(
                    activeStrategyMode
                )
                    ? "HYBRID"
                    : activeStrategyMode;
        }
        private int GetTelemetryIntFromTextBox(
            TextBox box,
            int fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            int value;

            if (
                int.TryParse(
                    box.Text,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }
        private double GetTelemetryDoubleFromTextBox(
            TextBox box,
            double fallback)
        {
            if (
                box == null
            )
            {
                return fallback;
            }

            double value;

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out value
                )
            )
            {
                return value;
            }

            if (
                double.TryParse(
                    box.Text,
                    NumberStyles.Float,
                    CultureInfo.CurrentCulture,
                    out value
                )
            )
            {
                return value;
            }

            return fallback;
        }
        private string[] GetPlatformAvailableInstruments()
        {
            List<string> names =
                new List<string>();

            HashSet<string> seen =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase
                );

            DateTime now =
                DateTime.Now.Date;

            DateTime minimumExpiry =
                now.AddDays(-45);

            DateTime maximumExpiry =
                now.AddMonths(18);

            try
            {
                foreach (
                    Instrument instrument
                    in Instrument.All
                )
                {
                    if (
                        instrument == null ||
                        instrument.MasterInstrument == null
                    )
                    {
                        continue;
                    }

                    if (
                        instrument
                            .MasterInstrument
                            .InstrumentType !=
                        InstrumentType.Future
                    )
                    {
                        continue;
                    }

                    string fullName =
                        instrument.FullName;

                    if (
                        string.IsNullOrWhiteSpace(
                            fullName
                        )
                    )
                    {
                        continue;
                    }

                    DateTime expiry =
                        instrument.Expiry;

                    if (
                        expiry != DateTime.MinValue &&
                        (
                            expiry.Date < minimumExpiry ||
                            expiry.Date > maximumExpiry
                        )
                    )
                    {
                        continue;
                    }

                    if (
                        seen.Add(
                            fullName
                        )
                    )
                    {
                        names.Add(
                            fullName
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "INSTRUMENT LIST ERROR: "
                    + ex.Message
                );
            }

            if (
                selectedInstrument != null &&
                !string.IsNullOrWhiteSpace(
                    selectedInstrument.FullName
                ) &&
                seen.Add(
                    selectedInstrument.FullName
                )
            )
            {
                names.Add(
                    selectedInstrument.FullName
                );
            }

            names.Sort(
                StringComparer.OrdinalIgnoreCase
            );

            if (
                names.Count > 300
            )
            {
                names =
                    names.GetRange(
                        0,
                        300
                    );
            }

            return names.ToArray();
        }
        private void AppendJsonStringArrayProperty(
            StringBuilder builder,
            string name,
            string[] values,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":[");

            bool first =
                true;

            if (values != null)
            {
                for (
                    int i = 0;
                    i < values.Length;
                    i++
                )
                {
                    string value =
                        values[i];

                    if (
                        string.IsNullOrWhiteSpace(
                            value
                        )
                    )
                    {
                        continue;
                    }

                    if (!first)
                    {
                        builder.Append(",");
                    }

                    AppendJsonString(
                        builder,
                        value
                    );

                    first =
                        false;
                }
            }

            builder.Append("]");
        }
        private string BuildPlatformTelemetryJson(
            JJBotSharedSnapshot snapshot,
            string accountName,
            string instrumentName,
            string direction,
            string strategy,
            int contracts,
            int stopTicks,
            int targetTicks,
            int maxTrades,
            double dailyTarget,
            double dailyLoss,
            double dollarRiskCap)
        {
            bool running =
                snapshot != null
                    ? snapshot.IsRunning
                    : botRunning;

            int trades =
                snapshot != null
                    ? snapshot.TradesToday
                    : tradesToday;

            // dailyPnl remains NET for backward compatibility.
            double dailyPnl =
                snapshot != null
                    ? snapshot.RealizedPnL
                    : botDailyPnL;

            double grossPnl =
                botDailyGrossPnL;

            double commissionsFees =
                botDailyFees;

            string position =
                snapshot != null
                    ? snapshot.Position
                    : "FLAT";

            int positionQty =
                snapshot != null
                    ? snapshot.PositionQty
                    : 0;

            double entryPrice =
                snapshot != null
                    ? snapshot.EntryPrice
                    : 0;

            string trend =
                snapshot != null
                    ? snapshot.M5Trend
                    : "WAITING";

            string vwap =
                snapshot != null
                    ? snapshot.M5VwapSide
                    : "WAITING";

            string liquidity =
                snapshot != null
                    ? snapshot.M5Liquidity
                    : "NONE";

            string structure =
                snapshot != null
                    ? snapshot.M5Structure
                    : "WAITING";

            int rangeLong =
                snapshot != null
                    ? snapshot.RangeLongScore
                    : latestRangeLongScore;

            int rangeShort =
                snapshot != null
                    ? snapshot.RangeShortScore
                    : latestRangeShortScore;

            string currentSignal =
                snapshot != null
                    ? snapshot.Signal
                    : currentSignalState;

            string setup =
                snapshot != null
                    ? snapshot.Setup
                    : currentSetupState;

            double unrealizedPnl =
                snapshot != null
                    ? snapshot.UnrealizedPnL
                    : botUnrealizedPnL;

            double totalPnl =
                snapshot != null
                    ? snapshot.TotalPnL
                    : botDailyPnL +
                        botUnrealizedPnL;

            int amTrades =
                snapshot != null
                    ? snapshot.AmTrades
                    : amTradesToday;

            int pmTrades =
                snapshot != null
                    ? snapshot.PmTrades
                    : pmTradesToday;

            DateTime strategyClockNy =
                GetCurrentNewYorkTime();

            DateTime marketTimeNy =
                latestM5DecisionNyTime !=
                    DateTime.MinValue
                    ? latestM5DecisionNyTime
                    : strategyClockNy;

            string lockReason =
                string.IsNullOrWhiteSpace(
                    persistentDailyLockReason
                )
                    ? "NONE"
                    : persistentDailyLockReason;

            string openingState =
                openingRangeGuardBlocked
                    ? "BLOCKED"
                    : openingRangeReady
                        ? "READY"
                        : "BUILDING";

            string preEntryState =
                preEntryRangeReady
                    ? "READY"
                    : "WAITING";

            bool activeTrade =
                !string.Equals(
                    position,
                    "FLAT",
                    StringComparison.OrdinalIgnoreCase
                ) &&
                positionQty > 0;

            double telemetryCurrentPrice;
            double telemetryActiveTradePnl;
            double telemetryMfe;
            double telemetryMae;
            double telemetryPeakTradePnl;
            double telemetryLockedPnl;
            double telemetryInitialRisk;
            double telemetryCurrentR;
            double telemetryPeakR;
            double telemetryGivebackPnl;
            double telemetryGivebackPercent;
            double telemetryDistanceToStopTicks;
            double telemetryDistanceToTargetTicks;
            bool telemetryGivebackGuardArmed;
            bool telemetryReversalGuardArmed;
            int telemetryProfitRetentionStage;
            double telemetryProfitRetentionFactor;
            string telemetryExitMode;

            lock (executionStateLock)
            {
                telemetryCurrentPrice = activeTradeCurrentPrice;
                telemetryActiveTradePnl = activeTradeUnrealizedPnl;
                telemetryMfe = activeTradeMfeDollars;
                telemetryMae = activeTradeMaeDollars;
                telemetryPeakTradePnl = activeTradePeakPnlDollars;
                telemetryProfitRetentionStage = activeProfitRetentionStage;
                telemetryProfitRetentionFactor = activeProfitRetentionFactor;
                telemetryGivebackGuardArmed = activeGivebackGuardArmed;
                telemetryReversalGuardArmed = activeReversalGuardArmed;
                telemetryInitialRisk = initialTradeRiskDollars;
                telemetryCurrentR = 0;
                telemetryPeakR = 0;
                telemetryGivebackPnl = 0;
                telemetryGivebackPercent = 0;
                telemetryDistanceToStopTicks = 0;
                telemetryDistanceToTargetTicks = 0;

                telemetryExitMode = string.IsNullOrWhiteSpace(activeTradeExitReason)
                    ? (momentumTrailingStage >= 4 ? "TRAILING"
                        : momentumTrailingStage == 3 ? "LOCK_PROFIT_2"
                        : momentumTrailingStage == 2 ? "LOCK_PROFIT"
                        : momentumTrailingStage == 1 ? "BREAKEVEN"
                        : "STANDARD")
                    : activeTradeExitReason;

                telemetryLockedPnl = 0;

                if (
                    activeTrade &&
                    selectedInstrument != null &&
                    selectedInstrument.MasterInstrument != null &&
                    entryFillPrice > 0 &&
                    activeStopPrice > 0 &&
                    entryQuantity > 0
                )
                {
                    double lockedPoints =
                        entryMarketPosition == MarketPosition.Long
                            ? activeStopPrice - entryFillPrice
                            : entryMarketPosition == MarketPosition.Short
                                ? entryFillPrice - activeStopPrice
                                : 0;

                    telemetryLockedPnl = Math.Max(
                        0,
                        lockedPoints
                            * selectedInstrument.MasterInstrument.PointValue
                            * entryQuantity
                    );

                    double telemetryTickSize =
                        selectedInstrument.MasterInstrument.TickSize;

                    if (telemetryTickSize > 0 && telemetryCurrentPrice > 0)
                    {
                        if (entryMarketPosition == MarketPosition.Long)
                        {
                            telemetryDistanceToStopTicks =
                                Math.Max(0, (telemetryCurrentPrice - activeStopPrice) / telemetryTickSize);

                            if (activeTargetPrice > 0)
                                telemetryDistanceToTargetTicks =
                                    Math.Max(0, (activeTargetPrice - telemetryCurrentPrice) / telemetryTickSize);
                        }
                        else if (entryMarketPosition == MarketPosition.Short)
                        {
                            telemetryDistanceToStopTicks =
                                Math.Max(0, (activeStopPrice - telemetryCurrentPrice) / telemetryTickSize);

                            if (activeTargetPrice > 0)
                                telemetryDistanceToTargetTicks =
                                    Math.Max(0, (telemetryCurrentPrice - activeTargetPrice) / telemetryTickSize);
                        }
                    }
                }

                if (telemetryInitialRisk > 0)
                {
                    telemetryCurrentR =
                        telemetryActiveTradePnl / telemetryInitialRisk;

                    telemetryPeakR =
                        telemetryPeakTradePnl / telemetryInitialRisk;
                }

                telemetryGivebackPnl =
                    Math.Max(
                        0,
                        telemetryPeakTradePnl -
                        Math.Max(0, telemetryActiveTradePnl)
                    );

                telemetryGivebackPercent =
                    telemetryPeakTradePnl > 0
                        ? telemetryGivebackPnl / telemetryPeakTradePnl * 100.0
                        : 0;
            }

            int telemetryTechnicalConfidence =
                activeTrade &&
                activeTradeSetupConfidence > 0
                    ? activeTradeSetupConfidence
                    : latestSetupConfidence;

            string telemetryConfidenceSide =
                activeTrade
                    ? (
                        entryMarketPosition ==
                            MarketPosition.Long
                            ? "LONG"
                            : (
                                entryMarketPosition ==
                                    MarketPosition.Short
                                    ? "SHORT"
                                    : string.Empty
                              )
                      )
                    : (
                        string.Equals(
                            autoResolvedDirection,
                            "LONG ONLY",
                            StringComparison.OrdinalIgnoreCase
                        )
                            ? "LONG"
                            : (
                                string.Equals(
                                    autoResolvedDirection,
                                    "SHORT ONLY",
                                    StringComparison.OrdinalIgnoreCase
                                )
                                    ? "SHORT"
                                    : string.Empty
                              )
                      );

            string telemetryConfidenceStructure =
                activeTrade &&
                activeLearningTrade != null
                    ? activeLearningTrade.Structure
                    : latestM5StructureState;

            int telemetryConfidenceSampleTrades;
            double telemetryObservedWinRate;
            double telemetryHistoricalWinProbability;
            string telemetryConfidenceReliability;
            int telemetryForcedSignalResolved;
            double telemetryHistoricalConfidenceWeight;

            int telemetrySetupConfidence =
                GetCalibratedSetupConfidence(
                    telemetryConfidenceSide,
                    telemetryConfidenceStructure,
                    telemetryTechnicalConfidence,
                    out telemetryConfidenceSampleTrades,
                    out telemetryObservedWinRate,
                    out telemetryHistoricalWinProbability,
                    out telemetryConfidenceReliability,
                    out telemetryForcedSignalResolved,
                    out telemetryHistoricalConfidenceWeight
                );

            string telemetrySetupQuality =
                activeTrade &&
                !string.IsNullOrWhiteSpace(
                    activeTradeSetupQuality
                )
                    ? activeTradeSetupQuality
                    : (
                        string.IsNullOrWhiteSpace(
                            latestSetupQuality
                        )
                            ? "ANALYZING"
                            : latestSetupQuality
                      );

            bool telemetryConfidenceFrozen =
                activeTrade &&
                activeTradeSetupConfidence > 0;

            bool learningActive =
                snapshot != null
                    ? snapshot.LearningActive
                    : true;

            string learningStatus =
                learningActive
                    ? "ACTIVE"
                    : "OFF";

            string[] logLines =
                visualLogLines != null
                    ? visualLogLines.ToArray()
                    : new string[0];

            // V1.6.6 - retain up to MaxVisualLogLines locally, but send
            // only the most recent telemetry tail to the platform.
            int logStart =
                Math.Max(
                    0,
                    logLines.Length -
                        PlatformTelemetryMaxLogLines
                );

            StringBuilder builder =
                new StringBuilder();

            builder.Append("{");
            builder.Append("\"apiKey\":");
            AppendJsonString(
                builder,
                platformApiKey
            );
            builder.Append(",\"profileId\":");
            AppendJsonString(
                builder,
                platformProfileId
            );
            builder.Append(",\"state\":{");

            AppendJsonStringProperty(
                builder,
                "profileId",
                platformProfileId,
                false
            );

            AppendJsonProperty(
                builder,
                "running",
                running
                    ? "true"
                    : "false",
                true
            );

            AppendJsonStringProperty(
                builder,
                "account",
                accountName,
                true
            );

            AppendJsonStringProperty(
                builder,
                "instrument",
                instrumentName,
                true
            );

            AppendJsonStringArrayProperty(
                builder,
                "availableInstruments",
                GetPlatformAvailableInstruments(),
                true
            );

            AppendJsonStringProperty(
                builder,
                "strategy",
                strategy,
                true
            );

            AppendJsonStringProperty(
                builder,
                "direction",
                direction,
                true
            );

            AppendJsonStringProperty(
                builder,
                "resolvedDirection",
                string.Equals(
                    direction,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
                    ? autoResolvedDirection
                    : direction,
                true
            );

            AppendJsonStringProperty(
                builder,
                "directionReason",
                string.Equals(
                    direction,
                    "AUTO",
                    StringComparison.OrdinalIgnoreCase
                )
                    ? autoDirectionReason
                    : "MANUAL "
                        + direction,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "contracts",
                contracts,
                true
            );

            AppendJsonStringProperty(
                builder,
                "trendM5",
                trend,
                true
            );

            AppendJsonStringProperty(
                builder,
                "vwap",
                vwap,
                true
            );

            AppendJsonStringProperty(
                builder,
                "liquidity",
                liquidity,
                true
            );

            AppendJsonStringProperty(
                builder,
                "structure",
                structure,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeLongScore",
                rangeLong,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeShortScore",
                rangeShort,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "rangeScoreMax",
                5,
                true
            );

            AppendJsonStringProperty(
                builder,
                "currentSignal",
                currentSignal,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setup",
                setup,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "setupConfidence",
                telemetrySetupConfidence,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "technicalSetupConfidence",
                telemetryTechnicalConfidence,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "confidenceSampleTrades",
                telemetryConfidenceSampleTrades,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "observedConfidenceWinRate",
                telemetryObservedWinRate,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "historicalWinProbability",
                telemetryHistoricalWinProbability,
                true
            );

            AppendJsonStringProperty(
                builder,
                "confidenceReliability",
                telemetryConfidenceReliability,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "forcedSignalResolved",
                telemetryForcedSignalResolved,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "historicalConfidenceWeight",
                telemetryHistoricalConfidenceWeight,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setupQuality",
                telemetrySetupQuality,
                true
            );

            AppendJsonStringProperty(
                builder,
                "setupTiming",
                string.IsNullOrWhiteSpace(
                    latestSetupTiming
                )
                    ? "ANALYZING"
                    : latestSetupTiming,
                true
            );

            AppendJsonStringProperty(
                builder,
                "manipulationState",
                string.IsNullOrWhiteSpace(
                    latestManipulationState
                )
                    ? "NONE"
                    : latestManipulationState,
                true
            );

            AppendJsonProperty(
                builder,
                "setupConfidenceFrozen",
                telemetryConfidenceFrozen
                    ? "true"
                    : "false",
                true
            );

            AppendJsonNumberProperty(
                builder,
                "stopTicks",
                stopTicks,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "targetTicks",
                targetTicks,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyTarget",
                dailyTarget,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyLoss",
                dailyLoss,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dollarRiskCap",
                activeDollarRiskCap,
                true
            );

            AppendJsonStringProperty(
                builder,
                "learningStatus",
                learningStatus,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "grossPnl",
                grossPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "commissionsFees",
                commissionsFees,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "netPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "realizedPnl",
                dailyPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "unrealizedPnl",
                unrealizedPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "totalPnl",
                totalPnl,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "dailyPeakPnl",
                dailyPeakTotalPnL,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "protectedProfitFloor",
                dailyProfitFloorArmed
                    ? dailyProtectedProfitFloor
                    : 0,
                true
            );

            AppendJsonProperty(
                builder,
                "profitFloorArmed",
                dailyProfitFloorArmed
                    ? "true"
                    : "false",
                true
            );

            AppendJsonStringProperty(
                builder,
                "dailyLockReason",
                lockReason,
                true
            );

            AppendJsonStringProperty(
                builder,
                "strategyClockNy",
                strategyClockNy.ToString(
                    "yyyy-MM-dd HH:mm:ss"
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "marketTimeNy",
                marketTimeNy.ToString(
                    "yyyy-MM-dd HH:mm:ss"
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "openingState",
                openingState,
                true
            );

            AppendJsonStringProperty(
                builder,
                "openingGuardReason",
                string.IsNullOrWhiteSpace(
                    openingRangeGuardReason
                )
                    ? "NONE"
                    : openingRangeGuardReason,
                true
            );

            AppendJsonStringProperty(
                builder,
                "preEntryState",
                preEntryState,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "preEntryHigh",
                preEntryRangeReady
                    ? preEntryRangeHigh
                    : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "preEntryLow",
                preEntryRangeReady
                    ? preEntryRangeLow
                    : 0,
                true
            );

            AppendJsonProperty(
                builder,
                "activeTrade",
                activeTrade
                    ? "true"
                    : "false",
                true
            );

            AppendJsonNumberProperty(
                builder,
                "tradesToday",
                trades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "premarketTrades",
                premarketTradesToday,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "amTrades",
                amTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "middayTrades",
                middayTradesToday,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "pmTrades",
                pmTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "premarketMaxTrades",
                PremarketMaxTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "middayMaxTrades",
                MiddayMaxTrades,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "tradesThisSession",
                GetSessionTradeCount(
                    GetBotSessionWindow(
                        strategyClockNy
                    )
                ),
                true
            );

            AppendJsonNumberProperty(
                builder,
                "maxTradesPerSession",
                GetSessionTradeLimit(
                    GetBotSessionWindow(
                        strategyClockNy
                    )
                ),
                true
            );

            AppendJsonStringProperty(
                builder,
                "position",
                position,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "positionQuantity",
                positionQty,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "averageEntryPrice",
                entryPrice,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "currentPrice",
                activeTrade ? telemetryCurrentPrice : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeOpenPnl",
                activeTrade ? unrealizedPnl : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeOpenPnl",
                activeTrade ? telemetryActiveTradePnl : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradePeakPnl",
                activeTrade ? telemetryPeakTradePnl : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeMfe",
                activeTrade ? telemetryMfe : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeMae",
                activeTrade ? telemetryMae : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeLockedPnl",
                activeTrade ? telemetryLockedPnl : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeInitialRisk",
                activeTrade ? telemetryInitialRisk : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeCurrentR",
                activeTrade ? telemetryCurrentR : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradePeakR",
                activeTrade ? telemetryPeakR : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeGivebackPnl",
                activeTrade ? telemetryGivebackPnl : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeGivebackPercent",
                activeTrade ? telemetryGivebackPercent : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeDistanceToStopTicks",
                activeTrade ? telemetryDistanceToStopTicks : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "activeTradeDistanceToTargetTicks",
                activeTrade ? telemetryDistanceToTargetTicks : 0,
                true
            );

            AppendJsonBoolProperty(
                builder,
                "givebackGuardArmed",
                activeTrade && telemetryGivebackGuardArmed,
                true
            );

            AppendJsonBoolProperty(
                builder,
                "reversalGuardArmed",
                activeTrade && telemetryReversalGuardArmed,
                true
            );

            AppendJsonNumberProperty(
                builder,
                "profitRetentionStage",
                activeTrade ? telemetryProfitRetentionStage : 0,
                true
            );

            AppendJsonDoubleProperty(
                builder,
                "profitRetentionPercent",
                activeTrade ? telemetryProfitRetentionFactor * 100.0 : 0,
                true
            );

            AppendJsonStringProperty(
                builder,
                "activeTradeExitMode",
                activeTrade ? telemetryExitMode : "NONE",
                true
            );

            AppendJsonStringProperty(
                builder,
                "addonVersion",
                PlatformBridgeVersion,
                true
            );

            AppendJsonStringProperty(
                builder,
                "engineVersion",
                "V1.6.18",
                true
            );

            builder.Append(",\"logs\":[");

            bool firstLog = true;

            for (
                int i = logStart;
                i < logLines.Length;
                i++
            )
            {
                if (!firstLog)
                {
                    builder.Append(",");
                }

                AppendJsonString(
                    builder,
                    logLines[i]
                );

                firstLog = false;
            }

            builder.Append("]");
            builder.Append("}}");

            return builder.ToString();
        }
        private void AppendJsonProperty(
            StringBuilder builder,
            string name,
            string rawValue,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");
            builder.Append(rawValue);
        }
        private void AppendJsonStringProperty(
            StringBuilder builder,
            string name,
            string value,
            bool prependComma)
        {
            if (prependComma)
            {
                builder.Append(",");
            }

            AppendJsonString(
                builder,
                name
            );

            builder.Append(":");

            AppendJsonString(
                builder,
                value
            );
        }
        private void AppendJsonNumberProperty(
            StringBuilder builder,
            string name,
            int value,
            bool prependComma)
        {
            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }
        private void AppendJsonDoubleProperty(
            StringBuilder builder,
            string name,
            double value,
            bool prependComma)
        {
            if (
                double.IsNaN(value) ||
                double.IsInfinity(value)
            )
            {
                value = 0;
            }

            AppendJsonProperty(
                builder,
                name,
                value.ToString(
                    "0.########",
                    CultureInfo.InvariantCulture
                ),
                prependComma
            );
        }
        private void AppendJsonBoolProperty(
            StringBuilder builder,
            string name,
            bool value,
            bool prependComma)
        {
            AppendJsonProperty(
                builder,
                name,
                value ? "true" : "false",
                prependComma
            );
        }

        private void AppendJsonString(
            StringBuilder builder,
            string value)
        {
            builder.Append("\"");

            string text =
                value ?? string.Empty;

            for (
                int i = 0;
                i < text.Length;
                i++
            )
            {
                char c =
                    text[i];

                switch (c)
                {
                    case '\\':
                        builder.Append("\\\\");
                        break;

                    case '"':
                        builder.Append("\\\"");
                        break;

                    case '\r':
                        builder.Append("\\r");
                        break;

                    case '\n':
                        builder.Append("\\n");
                        break;

                    case '\t':
                        builder.Append("\\t");
                        break;

                    default:
                        if (c < 32)
                        {
                            builder.Append(
                                "\\u"
                                + ((int)c).ToString(
                                    "x4"
                                )
                            );
                        }
                        else
                        {
                            builder.Append(c);
                        }
                        break;
                }
            }

            builder.Append("\"");
        }
        private void ApplyPlatformAuthorizationHeader(
            HttpWebRequest request)
        {
            if (
                request == null ||
                string.IsNullOrWhiteSpace(platformApiKey)
            )
            {
                return;
            }

            request.Headers[HttpRequestHeader.Authorization] =
                "Bearer " + platformApiKey;
        }
        private void SendPlatformTelemetryRequest(
            string endpoint,
            string json)
        {
            try
            {
                byte[] body =
                    Encoding.UTF8.GetBytes(
                        json
                    );

                HttpWebRequest request =
                    (HttpWebRequest)
                    WebRequest.Create(
                        endpoint
                    );

                request.Method =
                    "POST";

                ApplyPlatformAuthorizationHeader(
                    request
                );

                request.ContentType =
                    "application/json";

                request.ContentLength =
                    body.Length;

                request.Timeout =
                    2500;

                request.ReadWriteTimeout =
                    2500;

                using (
                    Stream requestStream =
                        request.GetRequestStream()
                )
                {
                    requestStream.Write(
                        body,
                        0,
                        body.Length
                    );
                }

                using (
                    HttpWebResponse response =
                        (HttpWebResponse)
                        request.GetResponse()
                )
                {
                    int statusCode =
                        (int)response.StatusCode;

                    if (
                        statusCode >= 200 &&
                        statusCode < 300
                    )
                    {
                        lastPlatformTelemetrySuccessUtc =
                            DateTime.UtcNow;
                    }
                }
            }
            catch (WebException ex)
            {
                // Do not spam the visual log every 3 seconds.
                // Only emit a message if the platform bridge had
                // previously been healthy.
                if (
                    lastPlatformTelemetrySuccessUtc !=
                        DateTime.MinValue
                )
                {
                    DateTime lastSuccess =
                        lastPlatformTelemetrySuccessUtc;

                    lastPlatformTelemetrySuccessUtc =
                        DateTime.MinValue;

                    Dispatcher.BeginInvoke(
                        new Action(
                            delegate
                            {
                                AppendVisualLog(
                                    "PLATFORM TELEMETRY OFFLINE: "
                                    + ex.Message
                                );
                            }
                        )
                    );
                }
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(
                    new Action(
                        delegate
                        {
                            AppendVisualLog(
                                "PLATFORM TELEMETRY ERROR: "
                                + ex.Message
                            );
                        }
                    )
                );
            }
            finally
            {
                platformTelemetryRequestInFlight =
                    false;
            }
        }

    }
}

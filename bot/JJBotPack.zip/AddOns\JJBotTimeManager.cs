#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TIME / SESSION MANAGER
    // Extracted from JJBotControl v1.6.20.
    //
    // IMPORTANT:
    // Structural refactor only. No trading logic was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =====================================================
        // NY SESSION FILTER
        // =====================================================
        private bool IsAsiaSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            // Cross-midnight NY window: 19:00:00 -> 02:59:59.
            return
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd;
        }

        private bool IsPremarketSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            return
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;
        }

        // V1.7.25 - PLAYBACK CLOCK RESTORE + PREMARKET OBSERVE-ONLY.
        // V1.7.20 - PREMARKET OBSERVE-ONLY.
        // Context, Level 2, learning and opening preparation stay active,
        // but automatic execution is locked for the entire premarket window.
        private bool IsPremarketExecutionGuardActive(
            DateTime nyTime)
        {
            return IsPremarketSession(nyTime);
        }

        private int GetNyAmTradeLimit()
        {
            return Math.Max(
                1,
                activeMaxTrades + NySessionAdditionalTradeAllowance
            );
        }

        private int GetNyPmTradeLimit()
        {
            return Math.Max(
                1,
                activeMaxTrades + NySessionAdditionalTradeAllowance
            );
        }

        private bool IsBotNySessionActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            bool asiaSession =
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd;

            bool premarketSession =
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;

            bool session1 =
                value >= BotSession1Start &&
                value <= BotSession1End;

            // V1.6.67 - SESSION SCOPE
            // MIDDAY remains disabled. PM automatic trading is enabled from 14:00 to 16:24:59 ET.
            // 16:25 ET is intentionally left to the existing FORCE FLAT safety rule.
            // ASIA runs 19:00-02:59:59 ET. PREMARKET/London begins at 03:00 ET; AM remains enabled.
            bool middaySession = false;
            bool session2 =
                value >= BotSession2Start &&
                value <= BotSession2End;

            // V1.7.27 - EXECUTION SCOPE.
            // Asia and Premarket remain analysis/context windows only.
            // Automatic execution is allowed only in NY AM and NY PM.
            return
                session1 ||
                middaySession ||
                session2;
        }

        private string GetBotSessionWindow(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            if (
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd
            )
            {
                return "ASIA";
            }

            if (
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd
            )
            {
                return "PREMARKET";
            }

            if (
                value >= BotSession1Start &&
                value <= BotSession1End
            )
            {
                return "AM";
            }

            // V1.6.76 - MIDDAY is intentionally not an automatic trading session.
            // Keep 12:00-13:59:59 ET as an analysis-only / no-entry gap so
            // Session Window, Session Trader and execution authority agree.
            if (
                value >= BotMiddayStart &&
                value <= BotMiddayEnd
            )
            {
                return "OUTSIDE";
            }

            if (
                value >= BotSession2Start &&
                value <= BotSession2End
            )
            {
                return "PM";
            }

            return "OUTSIDE";
        }

        private int GetSessionTradeCount(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "ASIA",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return asiaTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return premarketTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return amTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return middayTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return pmTradesToday;
            }

            return 0;
        }

        private bool IsSessionTradeLimitReached(
            string sessionWindow)
        {
            if (
                string.IsNullOrWhiteSpace(
                    sessionWindow
                ) ||
                sessionWindow == "OUTSIDE"
            )
            {
                return false;
            }

            int sessionLimit =
                GetSessionTradeLimit(
                    sessionWindow
                );

            return
                GetSessionTradeCount(
                    sessionWindow
                ) >=
                sessionLimit;
        }

        private int GetSessionTradeLimit(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "ASIA",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return AsiaMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return PremarketMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return MiddayMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return GetNyAmTradeLimit();
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return GetNyPmTradeLimit();
            }

            return 0;
        }

        private string GetSessionTradeStatus(
            DateTime nyTime)
        {
            string session =
                GetBotSessionWindow(
                    nyTime
                );

            if (session == "ASIA")
            {
                return "ASIA OBSERVE ONLY";
            }

            if (session == "PREMARKET")
            {
                if (IsPremarketExecutionGuardActive(nyTime))
                {
                    return "PREMARKET OBSERVE ONLY";
                }

                return "PREMARKET OBSERVE ONLY";
            }

            if (session == "AM")
            {
                return
                    "AM "
                    + amTradesToday
                    + "/"
                    + GetNyAmTradeLimit();
            }

            if (session == "PM")
            {
                return
                    "PM "
                    + pmTradesToday
                    + "/"
                    + GetNyPmTradeLimit();
            }

            return
                "ASIA OBSERVE | PRE OBSERVE"
                + " | AM "
                + amTradesToday
                + "/"
                + GetNyAmTradeLimit()
                + " | PM "
                + pmTradesToday
                + "/"
                + GetNyPmTradeLimit();
        }

        // =====================================================
        // CONVERT BAR TIME FROM NINJATRADER APPLICATION
        // TIME ZONE TO NEW YORK TIME.
        // =====================================================
        // =====================================================
        // V1.7.24 - PLAYBACK-AWARE MONOTONIC STRATEGY CLOCK
        // =====================================================
        // LIVE/SIM accounts use the real NY wall clock.
        // Playback accounts use the latest authoritative replay timestamp so
        // sessions, warmup, cooldowns and TTL logic follow Market Replay time.
        private DateTime playbackStrategyClockNy = DateTime.MinValue;
        private bool playbackClockSyncedLogged = false;
        private bool playbackClockWaitingLogged = false;

        private bool IsPlaybackStrategyClockActive()
        {
            try
            {
                string accountName =
                    selectedAccount == null
                        ? string.Empty
                        : selectedAccount.Name ?? string.Empty;

                return
                    accountName.StartsWith(
                        "Playback",
                        StringComparison.OrdinalIgnoreCase
                    );
            }
            catch
            {
                return false;
            }
        }

        private bool IsPlaybackStrategyClockWaiting()
        {
            return
                IsPlaybackStrategyClockActive() &&
                playbackStrategyClockNy == DateTime.MinValue;
        }

        private void UpdatePlaybackStrategyClock(
            DateTime marketTimestamp)
        {
            if (
                !IsPlaybackStrategyClockActive() ||
                marketTimestamp == DateTime.MinValue
            )
            {
                return;
            }

            DateTime marketNy =
                ConvertToNewYorkTime(
                    marketTimestamp
                );

            if (marketNy == DateTime.MinValue)
            {
                return;
            }

            bool firstSync =
                playbackStrategyClockNy == DateTime.MinValue;

            // Playback callbacks can arrive out of order.
            // Never allow the strategy clock to move backwards.
            if (
                !firstSync &&
                marketNy < playbackStrategyClockNy
            )
            {
                return;
            }

            playbackStrategyClockNy = marketNy;

            if (firstSync)
            {
                playbackClockWaitingLogged = false;

                if (!playbackClockSyncedLogged)
                {
                    playbackClockSyncedLogged = true;

                    PrintBotMessage(
                        "PLAYBACK CLOCK SYNCED"
                        + " | StrategyClockNY: "
                        + marketNy.ToString("yyyy-MM-dd HH:mm:ss")
                        + " ET"
                        + " | ClockSource: PLAYBACK MARKET"
                    );
                }

                if (
                    botRunning &&
                    IsSelectedInstrumentFlat()
                )
                {
                    automaticEntryWarmupUntilNy =
                        marketNy.AddSeconds(
                            StartupEntryWarmupSeconds
                        );

                    lastStartupWarmupBlockLogKey =
                        string.Empty;
                }

                LoadOrResetPersistentDailyState();
            }
        }

        private DateTime GetStrategyUtcNow()
        {
            if (
                IsPlaybackStrategyClockActive() &&
                playbackStrategyClockNy != DateTime.MinValue
            )
            {
                try
                {
                    TimeZoneInfo newYorkTimeZone =
                        TimeZoneInfo.FindSystemTimeZoneById(
                            "Eastern Standard Time"
                        );

                    DateTime nyUnspecified =
                        DateTime.SpecifyKind(
                            playbackStrategyClockNy,
                            DateTimeKind.Unspecified
                        );

                    return TimeZoneInfo.ConvertTimeToUtc(
                        nyUnspecified,
                        newYorkTimeZone
                    );
                }
                catch
                {
                    return playbackStrategyClockNy;
                }
            }

            return DateTime.UtcNow;
        }

        private bool IsAcceleratedReplayBacktestMode()
        {
            return IsPlaybackStrategyClockActive();
        }

        private DateTime GetCurrentNewYorkTime()
        {
            if (
                IsPlaybackStrategyClockActive() &&
                playbackStrategyClockNy != DateTime.MinValue
            )
            {
                return playbackStrategyClockNy;
            }

            try
            {
                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                return TimeZoneInfo.ConvertTimeFromUtc(
                    DateTime.UtcNow,
                    newYorkTimeZone
                );
            }
            catch
            {
                return DateTime.Now;
            }
        }

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                // If conversion ever fails, keep the original
                // timestamp instead of crashing the bot.
                return time;
            }
        }

        // =====================================================
        // DATETIME -> HHMMSS INTEGER
        // =====================================================
        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }


    }
}

#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TIME / SESSION MANAGER
    // Extracted from JJBotControl v1.6.20.
    //
    // IMPORTANT:
    // Structural refactor only. No trading logic was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =====================================================
        // NY SESSION FILTER
        // =====================================================
        private bool IsPremarketSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            return
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;
        }

        private bool IsBotNySessionActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            bool premarketSession =
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;

            bool session1 =
                value >= BotSession1Start &&
                value <= BotSession1End;

            // V1.6.64 - SESSION SCOPE
            // MIDDAY remains disabled. PM automatic trading is enabled from 14:00 to 15:30 ET.
            // PREMARKET begins at 03:00 ET (London-session coverage); AM remains enabled.
            bool middaySession = false;
            bool session2 =
                value >= BotSession2Start &&
                value <= BotSession2End;

            return
                premarketSession ||
                session1 ||
                middaySession ||
                session2;
        }

        private string GetBotSessionWindow(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            if (
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd
            )
            {
                return "PREMARKET";
            }

            if (
                value >= BotSession1Start &&
                value <= BotSession1End
            )
            {
                return "AM";
            }

            if (
                value >= BotMiddayStart &&
                value <= BotMiddayEnd
            )
            {
                return "MIDDAY";
            }

            if (
                value >= BotSession2Start &&
                value <= BotSession2End
            )
            {
                return "PM";
            }

            return "OUTSIDE";
        }

        private int GetSessionTradeCount(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return premarketTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return amTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return middayTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return pmTradesToday;
            }

            return 0;
        }

        private bool IsSessionTradeLimitReached(
            string sessionWindow)
        {
            if (
                string.IsNullOrWhiteSpace(
                    sessionWindow
                ) ||
                sessionWindow == "OUTSIDE"
            )
            {
                return false;
            }

            int sessionLimit =
                GetSessionTradeLimit(
                    sessionWindow
                );

            return
                GetSessionTradeCount(
                    sessionWindow
                ) >=
                sessionLimit;
        }

        private int GetSessionTradeLimit(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return PremarketMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return MiddayMaxTrades;
            }

            return activeMaxTrades;
        }

        private string GetSessionTradeStatus(
            DateTime nyTime)
        {
            string session =
                GetBotSessionWindow(
                    nyTime
                );

            if (session == "PREMARKET")
            {
                return
                    "PREMARKET "
                    + premarketTradesToday
                    + "/"
                    + PremarketMaxTrades;
            }

            if (session == "AM")
            {
                return
                    "AM "
                    + amTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            if (session == "MIDDAY")
            {
                return
                    "MIDDAY "
                    + middayTradesToday
                    + "/"
                    + MiddayMaxTrades;
            }

            if (session == "PM")
            {
                return
                    "PM "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            return
                "PRE "
                + premarketTradesToday
                + "/"
                + PremarketMaxTrades
                + " | AM "
                + amTradesToday
                + "/"
                + activeMaxTrades
                + " | MIDDAY "
                + middayTradesToday
                + "/"
                + MiddayMaxTrades
                + " | PM "
                + pmTradesToday
                + "/"
                + activeMaxTrades;
        }

        // =====================================================
        // CONVERT BAR TIME FROM NINJATRADER APPLICATION
        // TIME ZONE TO NEW YORK TIME.
        // =====================================================
        // =====================================================
        // V1.6.2 - RELIABLE CURRENT NEW YORK CLOCK
        // =====================================================
        // Bar timestamps may use NinjaTrader's configured display timezone.
        // The actual current clock must use UTC -> New York directly.
        private DateTime GetCurrentNewYorkTime()
        {
            try
            {
                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                return TimeZoneInfo.ConvertTimeFromUtc(
                    DateTime.UtcNow,
                    newYorkTimeZone
                );
            }
            catch
            {
                return DateTime.Now;
            }
        }

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                // If conversion ever fails, keep the original
                // timestamp instead of crashing the bot.
                return time;
            }
        }

        // =====================================================
        // DATETIME -> HHMMSS INTEGER
        // =====================================================
        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }


    }
}

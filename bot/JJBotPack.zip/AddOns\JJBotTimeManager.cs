#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TIME / SESSION MANAGER
    // Extracted from JJBotControl v1.6.20.
    //
    // IMPORTANT:
    // Structural refactor only. No trading logic was changed.
    // =========================================================
    public partial class JJBotWindow
    {
        // =====================================================
        // NY SESSION FILTER
        // =====================================================
        private bool IsAsiaSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            // Cross-midnight NY window: 19:00:00 -> 02:59:59.
            return
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd;
        }

        private bool IsPremarketSession(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            return
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;
        }

        // V1.6.74 - 03:00-03:14:59 is analysis-only.  This helper is
        // intentionally separate from IsPremarketSession so all context
        // engines can continue to run while order submission is locked.
        private bool IsPremarketExecutionGuardActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            return
                value >= PremarketSessionStart &&
                value < PremarketExecutionStart;
        }

        private bool IsBotNySessionActive(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            bool asiaSession =
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd;

            bool premarketSession =
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd;

            bool session1 =
                value >= BotSession1Start &&
                value <= BotSession1End;

            // V1.6.67 - SESSION SCOPE
            // MIDDAY remains disabled. PM automatic trading is enabled from 14:00 to 16:24:59 ET.
            // 16:25 ET is intentionally left to the existing FORCE FLAT safety rule.
            // ASIA runs 19:00-02:59:59 ET. PREMARKET/London begins at 03:00 ET; AM remains enabled.
            bool middaySession = false;
            bool session2 =
                value >= BotSession2Start &&
                value <= BotSession2End;

            return
                asiaSession ||
                premarketSession ||
                session1 ||
                middaySession ||
                session2;
        }

        private string GetBotSessionWindow(
            DateTime nyTime)
        {
            int value =
                ToTimeInt(
                    nyTime
                );

            if (
                value >= AsiaSessionStart ||
                value <= AsiaSessionEnd
            )
            {
                return "ASIA";
            }

            if (
                value >= PremarketSessionStart &&
                value <= PremarketSessionEnd
            )
            {
                return "PREMARKET";
            }

            if (
                value >= BotSession1Start &&
                value <= BotSession1End
            )
            {
                return "AM";
            }

            // V1.6.76 - MIDDAY is intentionally not an automatic trading session.
            // Keep 12:00-13:59:59 ET as an analysis-only / no-entry gap so
            // Session Window, Session Trader and execution authority agree.
            if (
                value >= BotMiddayStart &&
                value <= BotMiddayEnd
            )
            {
                return "OUTSIDE";
            }

            if (
                value >= BotSession2Start &&
                value <= BotSession2End
            )
            {
                return "PM";
            }

            return "OUTSIDE";
        }

        private int GetSessionTradeCount(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "ASIA",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return asiaTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return premarketTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return amTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "AM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return Math.Min(
                    MaxTradesPerSessionAllowed,
                    activeMaxTrades + GetNyAmTransferredTradeBonus()
                );
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return middayTradesToday;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PM",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return pmTradesToday;
            }

            return 0;
        }

        // =====================================================
        // V1.7.01 - SESSION CAPITAL PRESERVATION
        // =====================================================
        // If the official ASIA allocation has already been used and the
        // bot's NET realized PnL is negative, PREMARKET becomes observation
        // only.  This does NOT consume the PRE trade counter and persists
        // across restart because AsiaTrades + realized PnL already persist.
        //
        // The goal is allocation of daily risk, not a new signal filter:
        // preserve the next available risk bullet for NY/AM.
        private bool IsPremarketSuppressedByAsiaLoss(
            out double realizedNetSnapshot)
        {
            realizedNetSnapshot = 0;

            lock (executionStateLock)
            {
                realizedNetSnapshot = botDailyPnL;

                return
                    asiaLossNyAmBonusArmed &&
                    asiaTradesToday > 0 &&
                    premarketTradesToday == 0;
            }
        }

        // V1.7.02 - The skipped PREMARKET allocation is transferred to NY AM.
        // Example: user MaxTrades 2 -> AM limit 3 for that trading day.
        private int GetNyAmTransferredTradeBonus()
        {
            lock (executionStateLock)
            {
                return
                    asiaLossNyAmBonusArmed &&
                    asiaTradesToday > 0 &&
                    premarketTradesToday == 0
                        ? 1
                        : 0;
            }
        }

        private bool IsSessionTradeLimitReached(
            string sessionWindow)
        {
            if (
                string.IsNullOrWhiteSpace(
                    sessionWindow
                ) ||
                sessionWindow == "OUTSIDE"
            )
            {
                return false;
            }

            int sessionLimit =
                GetSessionTradeLimit(
                    sessionWindow
                );

            return
                GetSessionTradeCount(
                    sessionWindow
                ) >=
                sessionLimit;
        }

        private int GetSessionTradeLimit(
            string sessionWindow)
        {
            if (
                string.Equals(
                    sessionWindow,
                    "ASIA",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return AsiaMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "PREMARKET",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return PremarketMaxTrades;
            }

            if (
                string.Equals(
                    sessionWindow,
                    "MIDDAY",
                    StringComparison.OrdinalIgnoreCase
                )
            )
            {
                return MiddayMaxTrades;
            }

            return activeMaxTrades;
        }

        private string GetSessionTradeStatus(
            DateTime nyTime)
        {
            string session =
                GetBotSessionWindow(
                    nyTime
                );

            if (session == "ASIA")
            {
                return
                    "ASIA "
                    + asiaTradesToday
                    + "/"
                    + AsiaMaxTrades;
            }

            if (session == "PREMARKET")
            {
                double asiaLossNet;

                if (
                    IsPremarketSuppressedByAsiaLoss(
                        out asiaLossNet
                    )
                )
                {
                    return
                        "PREMARKET OBSERVE ONLY | ASIA LOSS "
                        + asiaLossNet.ToString("$0.00")
                        + " | NY BULLET RESERVED";
                }

                if (IsPremarketExecutionGuardActive(nyTime))
                {
                    return
                        "PREMARKET GUARD | "
                        + premarketTradesToday
                        + "/"
                        + PremarketMaxTrades;
                }

                return
                    "PREMARKET ACTIVE | "
                    + premarketTradesToday
                    + "/"
                    + PremarketMaxTrades;
            }

            if (session == "AM")
            {
                int amLimit = GetSessionTradeLimit("AM");

                return
                    "AM "
                    + amTradesToday
                    + "/"
                    + amLimit
                    + (amLimit > activeMaxTrades ? " | +1 PRE TRANSFER" : string.Empty);
            }

            if (session == "PM")
            {
                return
                    "PM "
                    + pmTradesToday
                    + "/"
                    + activeMaxTrades;
            }

            return
                "ASIA "
                + asiaTradesToday
                + "/"
                + AsiaMaxTrades
                + " | PRE "
                + premarketTradesToday
                + "/"
                + PremarketMaxTrades
                + " | AM "
                + amTradesToday
                + "/"
                + activeMaxTrades
                + " | PM "
                + pmTradesToday
                + "/"
                + activeMaxTrades;
        }

        // =====================================================
        // CONVERT BAR TIME FROM NINJATRADER APPLICATION
        // TIME ZONE TO NEW YORK TIME.
        // =====================================================
        // =====================================================
        // V1.6.2 - RELIABLE CURRENT NEW YORK CLOCK
        // =====================================================
        // Bar timestamps may use NinjaTrader's configured display timezone.
        // The actual current clock must use UTC -> New York directly.
        private DateTime GetCurrentNewYorkTime()
        {
            try
            {
                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                return TimeZoneInfo.ConvertTimeFromUtc(
                    DateTime.UtcNow,
                    newYorkTimeZone
                );
            }
            catch
            {
                return DateTime.Now;
            }
        }

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                // If conversion ever fails, keep the original
                // timestamp instead of crashing the bot.
                return time;
            }
        }

        // =====================================================
        // DATETIME -> HHMMSS INTEGER
        // =====================================================
        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }


    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.81 - TRADE JOURNAL (PASIVO, SOLO REGISTRA)
    // No cambia entradas, TP, SL, tamano, filtros ni ninguna decision.
    // Lee los mensajes que el bot ya imprime (PrintBotMessage) y arma:
    //
    //   JJBotData\Journal\journal_trades_<cuenta>.csv
    //     una fila por trade: estrategia, ruta, lado, tamano, SL/TP, resultado,
    //     MFE/MAE, segundos, y la FOTO del contexto al entrar (puntaje de
    //     explosion, eficiencia, R20, fase del movimiento, setup, ubicacion,
    //     Level 2, HTF, decision, tamano dinamico, rango/contexto/L2 del Open Bell,
    //     setup de Gerard).
    //
    //   JJBotData\Journal\journal_sessions_<cuenta>.csv
    //     resumen del dia (trades, ganados, perdidos, neto, pico, minimo,
    //     motivo del lock, conteo de bloqueos por motivo). Se agrega una fila en
    //     cada DAILY LOCK / BOT STOPPED / cambio de dia: para analizar usar la
    //     ULTIMA fila de cada SessionDate. Los bloqueos cuentan MENSAJES (un mismo
    //     bloqueo repetido varias veces por segundo suma varias veces).
    //
    // HYBRID EFFICIENCY WOULD BLOCK (solo log): si HYBRID (MOMENTUM) entra y la
    // ultima lectura de explosion del mismo lado (<= 10 s) dice Efficiency POOR,
    // imprime "HYBRID EFFICIENCY WOULD BLOCK (LOG ONLY)" y marca el trade en el
    // journal (HybridWouldBlock = 1). La entrada NO se bloquea.
    //
    // Todo va dentro de try/catch: si algo falla, el bot sigue igual.
    // =========================================================
    public partial class JJBotWindow
    {
        private sealed class JrnSnap
        {
            public string Line;
            public DateTime Utc;
        }

        private sealed class JrnTrade
        {
            public string TradeId;
            public string Strategy;
            public string Route;
            public string Side;
            public DateTime EntryNy;
            public string Qty;
            public string SlTicks;
            public string RiskUsd;
            public string AvgEntry = "";
            public string SlPrice = "";
            public string TpPrice = "";
            public double DayNetBefore;
            public int Partials;
            public int LadderMoves;
            public bool WouldBlock;
            public string Expl = "";
            public double ExplAgeSec = -1;
            public string Move = "";
            public string Setup = "";
            public string Location = "";
            public string L2 = "";
            public string Htf = "";
            public string Decision = "";
            public string Final = "";
            public string DynSize = "";
            public string RiskSize = "";
            public string ObRange = "";
            public string ObCtx = "";
            public string ObL2 = "";
            public string Gerard = "";
        }

        private readonly object jrnLock = new object();

        [ThreadStatic]
        private static bool jrnInHook;

        private readonly Dictionary<string, JrnSnap> jrnLast = new Dictionary<string, JrnSnap>();
        private readonly Dictionary<string, int> jrnBlocks = new Dictionary<string, int>();
        private JrnTrade jrnOpen;
        private DateTime jrnDay = DateTime.MinValue;
        private int jrnTrades;
        private int jrnWins;
        private int jrnLosses;
        private int jrnWouldBlockCount;
        private double jrnDayNet;
        private double jrnPeakNet;
        private double jrnMinNet;
        private string jrnLockReason = "";

        private const string JrnTradesHeader =
            "SessionDate,Account,Instrument,TradeId,Strategy,Route,Side,EntryNy,ExitNy,Seconds,Qty,AvgEntry,Exit," +
            "SlTicks,RiskUsd,SlPrice,TpPrice,ExitReason,TradeNetUsd,MfeUsd,MaeUsd,PeakUsd,DayNetBefore,DayNetAfter," +
            "Partials,LadderMoves,HybridWouldBlock," +
            "ExplScore,ExplR20,ExplDisp,ExplVol,ExplAggRatio,ExplDelta,ExplPersist,ExplFlow,ExplAbs,ExplProgress,ExplEfficiency,ExplAgeSec," +
            "MovePhase,MoveEmaExt,MoveSessionMove,SetupQuality,EntryLocation,Level2Context,HtfContext,Decision,FinalAuthority," +
            "DynamicSizing,RiskSizing,OpenBellRange,OpenBellContext,OpenBellL2,GerardSetup";

        private const string JrnSessionsHeader =
            "SessionDate,Account,Instrument,WrittenNy,Trigger,Trades,Wins,Losses,DayNet,PeakDayNet,MinDayNet," +
            "LockReason,HybridWouldBlock,Blocks";

        // Called from PrintBotMessage for every message.
        private void JournalOnMessage(string message)
        {
            if (jrnInHook || string.IsNullOrEmpty(message))
                return;

            string pendingPrint = null;

            try
            {
                jrnInHook = true;

                lock (jrnLock)
                {
                    pendingPrint = JournalProcess(message);
                }

                if (pendingPrint != null)
                    PrintBotMessage(pendingPrint);
            }
            catch
            {
                // passive recorder: never affects the bot
            }
            finally
            {
                jrnInHook = false;
            }
        }

        private string JournalProcess(string msg)
        {
            DateTime nyNow = JrnNyNow();
            DateTime session = nyNow.Hour >= 18 ? nyNow.Date.AddDays(1) : nyNow.Date;

            if (jrnDay != session)
            {
                if (jrnDay != DateTime.MinValue && (jrnTrades > 0 || jrnBlocks.Count > 0))
                    JrnWriteSession("DAY ROLLOVER", nyNow);

                jrnDay = session;
                jrnBlocks.Clear();
                jrnTrades = jrnWins = jrnLosses = jrnWouldBlockCount = 0;
                jrnDayNet = jrnPeakNet = jrnMinNet = 0;
                jrnLockReason = "";
            }

            // V1.7.95 - after a STOP/START the journal started the day at $0, so the next
            // trade was written with TradeNet = whole day net (22-oct: SL -$62 written as +$178)
            // and counted as a win. Seed the day from the restored session state.
            if (msg.StartsWith("TRADING SESSION STATE RESTORED", StringComparison.Ordinal) && jrnOpen == null)
            {
                double restoredNet = JrnNum(JrnField(msg, "| Net: "), double.NaN);
                if (!double.IsNaN(restoredNet))
                {
                    jrnDayNet = restoredNet;
                    jrnPeakNet = Math.Max(jrnPeakNet, Math.Max(0, JrnNum(JrnField(msg, "Peak: "), restoredNet)));
                    jrnMinNet = Math.Min(jrnMinNet, restoredNet);
                }

                int restoredTrades;
                string restoredTradesText = JrnField(msg, "Trades: ");
                if (int.TryParse(restoredTradesText, NumberStyles.Integer, CultureInfo.InvariantCulture, out restoredTrades)
                    && restoredTrades > jrnTrades)
                    jrnTrades = restoredTrades;
            }

            string side = JrnSide(msg);

            // ---------- context snapshots ----------
            if (msg.StartsWith("EXPLOSION EDGE EXECUTION", StringComparison.Ordinal) && msg.Contains("| Explosion ") && side != null)
                JrnSet("EXPL_" + side, msg);
            else if (msg.StartsWith("MOVE PHASE", StringComparison.Ordinal) && side != null)
                JrnSet("MOVE_" + side, msg);
            else if (msg.StartsWith("SETUP QUALITY", StringComparison.Ordinal) && side != null)
                JrnSet("SETUP_" + side, msg);
            else if (msg.StartsWith("ENTRY LOCATION", StringComparison.Ordinal) && side != null)
                JrnSet("LOC_" + side, msg);
            else if (msg.StartsWith("LEVEL2 CONTEXT", StringComparison.Ordinal))
                JrnSet("L2", msg);
            else if (msg.StartsWith("HTF CONTEXT", StringComparison.Ordinal))
                JrnSet("HTF", msg);
            else if (msg.StartsWith("DECISION |", StringComparison.Ordinal))
                JrnSet("DECISION", msg);
            else if (msg.StartsWith("FINAL ENTRY AUTHORITY", StringComparison.Ordinal))
                JrnSet("FINAL", msg);
            else if (msg.Contains("DYNAMIC SIZING |"))
                JrnSet("DYNSIZE", msg);
            else if (msg.StartsWith("REMAINING DAILY RISK AUTO SIZING", StringComparison.Ordinal) || msg.StartsWith("AUTO RISK SIZING", StringComparison.Ordinal))
                JrnSet("RISKSIZE", msg);
            else if (msg.StartsWith("CORE20 OPEN BELL CONTEXT", StringComparison.Ordinal))
                JrnSet("OBCTX", msg);
            else if (msg.StartsWith("CORE20 OPEN BELL L2", StringComparison.Ordinal))
                JrnSet("OBL2", msg);
            else if (msg.StartsWith("CORE20 OPEN BELL | Range", StringComparison.Ordinal))
                JrnSet("OBRANGE", msg);
            else if (msg.StartsWith("CORE20 GERARD | Range", StringComparison.Ordinal))
                JrnSet("GERARD", msg);

            // ---------- block counters ----------
            if (!msg.StartsWith("HYBRID EFFICIENCY WOULD BLOCK", StringComparison.Ordinal))
            {
                string blockKey = JrnBlockKey(msg);
                if (blockKey != null)
                {
                    int c;
                    jrnBlocks.TryGetValue(blockKey, out c);
                    jrnBlocks[blockKey] = c + 1;
                }
            }

            string toPrint = null;

            // ---------- trade lifecycle ----------
            if (msg.StartsWith("JJ AI CORE ENTRY SUBMITTED", StringComparison.Ordinal))
            {
                if (jrnOpen != null)
                    JrnWriteTrade(jrnOpen, nyNow, "", "UNCLOSED", "", "", "", "", jrnDayNet);

                toPrint = JrnOpenTrade(msg, nyNow);
            }
            else if (jrnOpen != null)
            {
                if (msg.StartsWith("ENTRY FILL COMPLETE", StringComparison.Ordinal))
                    jrnOpen.AvgEntry = JrnField(msg, "Avg: ");
                else if (msg.StartsWith("OCO BRACKET SUBMITTED", StringComparison.Ordinal))
                {
                    jrnOpen.SlPrice = JrnField(msg, "SL: ");
                    jrnOpen.TpPrice = JrnField(msg, "TP: ");
                }
                else if (msg.Contains(" LADDER |"))
                    jrnOpen.LadderMoves++;
                else if (msg.StartsWith("EXIT PARTIAL FILL", StringComparison.Ordinal))
                    jrnOpen.Partials++;
                else if (msg.StartsWith("EXIT COMPLETE", StringComparison.Ordinal))
                {
                    double dayAfter = JrnNum(JrnField(msg, "Daily Net PnL: "), jrnDayNet);

                    JrnWriteTrade(
                        jrnOpen,
                        nyNow,
                        JrnField(msg, "Exit: "),
                        JrnField(msg, "ExitReason: "),
                        JrnField(msg, "MFE: "),
                        JrnField(msg, "MAE: "),
                        JrnField(msg, "Peak: "),
                        "",
                        dayAfter);

                    double tradeNet = dayAfter - jrnOpen.DayNetBefore;
                    jrnTrades++;
                    if (tradeNet > 0) jrnWins++; else jrnLosses++;
                    jrnDayNet = dayAfter;
                    jrnPeakNet = Math.Max(jrnPeakNet, dayAfter);
                    jrnMinNet = Math.Min(jrnMinNet, dayAfter);
                    jrnOpen = null;
                }
            }

            // ---------- session summary ----------
            if (msg.StartsWith("DAILY LOCK SET", StringComparison.Ordinal))
            {
                jrnLockReason = JrnField(msg, "Reason: ");
                JrnWriteSession("DAILY LOCK", nyNow);
            }
            else if (msg.StartsWith("BOT STOPPED", StringComparison.Ordinal) && (jrnTrades > 0 || jrnBlocks.Count > 0))
            {
                JrnWriteSession("BOT STOPPED", nyNow);
            }

            return toPrint;
        }

        private string JrnOpenTrade(string msg, DateTime nyNow)
        {
            // "JJ AI CORE ENTRY SUBMITTED | Decision: MNQ 12-26|id|SIDE|STRATEGY|ROUTE | SIDE | Qty: 3 | SL: 134t | Risk: $201.00 | ..."
            string decision = JrnField(msg, "Decision: ");
            string[] parts = decision.Split('|');

            JrnTrade t = new JrnTrade();
            t.TradeId = parts.Length > 1 ? parts[1] : nyNow.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture);
            t.Side = parts.Length > 2 ? parts[2] : (JrnSide(msg) ?? "");
            t.Strategy = parts.Length > 3 ? parts[3] : "";
            t.Route = parts.Length > 4 ? parts[4] : "";
            t.EntryNy = nyNow;
            t.Qty = JrnField(msg, "Qty: ");
            t.SlTicks = JrnField(msg, "SL: ");
            t.RiskUsd = JrnField(msg, "Risk: ");
            t.DayNetBefore = jrnDayNet;

            DateTime nowUtc = DateTime.UtcNow;
            string s = t.Side;

            JrnSnap ex = JrnGet("EXPL_" + s, 120);
            if (ex != null)
            {
                t.Expl = ex.Line;
                t.ExplAgeSec = (nowUtc - ex.Utc).TotalSeconds;
            }

            t.Move = JrnLine("MOVE_" + s, 120);
            t.Setup = JrnLine("SETUP_" + s, 120);
            t.Location = JrnLine("LOC_" + s, 120);
            t.L2 = JrnLine("L2", 120);
            t.Htf = JrnLine("HTF", 3600);
            t.Decision = JrnLine("DECISION", 600);
            t.Final = JrnLine("FINAL", 30);
            t.DynSize = JrnLine("DYNSIZE", 30);
            t.RiskSize = JrnLine("RISKSIZE", 30);

            if (t.Route.IndexOf("OPENBELL", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                t.ObRange = JrnLine("OBRANGE", 120);
                t.ObCtx = JrnLine("OBCTX", 120);
                t.ObL2 = JrnLine("OBL2", 120);
            }

            if (t.Route.IndexOf("GERARD", StringComparison.OrdinalIgnoreCase) >= 0)
                t.Gerard = JrnLine("GERARD", 300);

            jrnOpen = t;

            // HYBRID efficiency check (LOG ONLY - the entry is NOT blocked).
            if (string.Equals(t.Strategy, "MOMENTUM", StringComparison.OrdinalIgnoreCase) &&
                ex != null &&
                t.ExplAgeSec <= 10.0 &&
                JrnField(ex.Line, "Efficiency ").StartsWith("POOR", StringComparison.Ordinal))
            {
                t.WouldBlock = true;
                jrnWouldBlockCount++;

                return "HYBRID EFFICIENCY WOULD BLOCK (LOG ONLY)"
                    + " | Side: " + t.Side
                    + " | Explosion " + JrnField(ex.Line, "Explosion ")
                    + " | Progress/100Agg " + JrnField(ex.Line, "Progress/100Agg ")
                    + " | Efficiency " + JrnField(ex.Line, "Efficiency ")
                    + " | Age " + t.ExplAgeSec.ToString("0.0", CultureInfo.InvariantCulture) + "s"
                    + " | Action: ENTRY KEPT (measuring for 2 weeks)";
            }

            return null;
        }

        private void JrnWriteTrade(JrnTrade t, DateTime nyNow, string exit, string exitReason,
            string mfe, string mae, string peak, string unused, double dayAfter)
        {
            string e = t.Expl ?? "";
            double seconds = (nyNow - t.EntryNy).TotalSeconds;

            string[] cols =
            {
                jrnDay.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                JrnAccount(),
                JrnInstrument(),
                t.TradeId,
                t.Strategy,
                t.Route,
                t.Side,
                t.EntryNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                nyNow.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                seconds.ToString("0", CultureInfo.InvariantCulture),
                t.Qty,
                t.AvgEntry,
                exit,
                t.SlTicks,
                t.RiskUsd,
                t.SlPrice,
                t.TpPrice,
                exitReason,
                exitReason == "UNCLOSED" ? "" : (dayAfter - t.DayNetBefore).ToString("0.00", CultureInfo.InvariantCulture),
                mfe,
                mae,
                peak,
                t.DayNetBefore.ToString("0.00", CultureInfo.InvariantCulture),
                exitReason == "UNCLOSED" ? "" : dayAfter.ToString("0.00", CultureInfo.InvariantCulture),
                t.Partials.ToString(CultureInfo.InvariantCulture),
                t.LadderMoves.ToString(CultureInfo.InvariantCulture),
                t.WouldBlock ? "1" : "0",
                JrnField(e, "Explosion "),
                JrnField(e, "R20 "),
                JrnField(e, "Disp "),
                JrnField(e, "Vol x"),
                JrnField(e, "AggRatio "),
                JrnField(e, "Delta "),
                JrnField(e, "Persist "),
                JrnField(e, "Flow "),
                JrnField(e, "Abs "),
                JrnField(e, "Progress/100Agg "),
                JrnField(e, "Efficiency "),
                t.ExplAgeSec < 0 ? "" : t.ExplAgeSec.ToString("0.0", CultureInfo.InvariantCulture),
                JrnField(t.Move, "Phase: "),
                JrnField(t.Move, "EMA9Ext: "),
                JrnField(t.Move, "SessionMove: "),
                JrnStrip(t.Setup),
                JrnStrip(t.Location),
                JrnStrip(t.L2),
                JrnStrip(t.Htf),
                JrnStrip(t.Decision),
                JrnStrip(t.Final),
                JrnStrip(t.DynSize),
                JrnStrip(t.RiskSize),
                JrnStrip(t.ObRange),
                JrnStrip(t.ObCtx),
                JrnStrip(t.ObL2),
                JrnStrip(t.Gerard)
            };

            JrnAppend("journal_trades_" + JrnFileSafe(JrnAccount()) + ".csv", JrnTradesHeader,
                string.Join(",", cols.Select(x => JrnCsv(x)).ToArray()));
        }

        private void JrnWriteSession(string trigger, DateTime nyNow)
        {
            string blocks = string.Join(";",
                jrnBlocks.OrderByDescending(kv => kv.Value).Take(15)
                    .Select(kv => kv.Key + "=" + kv.Value.ToString(CultureInfo.InvariantCulture)).ToArray());

            string[] cols =
            {
                jrnDay.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                JrnAccount(),
                JrnInstrument(),
                nyNow.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                trigger,
                jrnTrades.ToString(CultureInfo.InvariantCulture),
                jrnWins.ToString(CultureInfo.InvariantCulture),
                jrnLosses.ToString(CultureInfo.InvariantCulture),
                jrnDayNet.ToString("0.00", CultureInfo.InvariantCulture),
                jrnPeakNet.ToString("0.00", CultureInfo.InvariantCulture),
                jrnMinNet.ToString("0.00", CultureInfo.InvariantCulture),
                jrnLockReason,
                jrnWouldBlockCount.ToString(CultureInfo.InvariantCulture),
                blocks
            };

            JrnAppend("journal_sessions_" + JrnFileSafe(JrnAccount()) + ".csv", JrnSessionsHeader,
                string.Join(",", cols.Select(x => JrnCsv(x)).ToArray()));
        }

        // ---------- helpers ----------
        private static TimeZoneInfo jrnNyTz;

        // Own clock (no bot locks taken inside the journal lock).
        private static DateTime JrnNyNow()
        {
            try
            {
                if (jrnNyTz == null)
                    jrnNyTz = V185NyZone();
                return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, jrnNyTz);
            }
            catch
            {
                return DateTime.UtcNow.AddHours(-4);
            }
        }

        private void JrnSet(string key, string line)
        {
            JrnSnap s;
            if (!jrnLast.TryGetValue(key, out s))
            {
                s = new JrnSnap();
                jrnLast[key] = s;
            }
            s.Line = line;
            s.Utc = DateTime.UtcNow;
        }

        private JrnSnap JrnGet(string key, double maxAgeSec)
        {
            JrnSnap s;
            if (!jrnLast.TryGetValue(key, out s) || s == null)
                return null;
            if ((DateTime.UtcNow - s.Utc).TotalSeconds > maxAgeSec)
                return null;
            return s;
        }

        private string JrnLine(string key, double maxAgeSec)
        {
            JrnSnap s = JrnGet(key, maxAgeSec);
            return s == null ? "" : s.Line;
        }

        private static string JrnSide(string msg)
        {
            if (msg.Contains("Side: LONG")) return "LONG";
            if (msg.Contains("Side: SHORT")) return "SHORT";
            return null;
        }

        // Text after "key" up to the next " |" (or end of line).
        private static string JrnField(string line, string key)
        {
            if (string.IsNullOrEmpty(line))
                return "";
            int i = line.IndexOf(key, StringComparison.Ordinal);
            if (i < 0)
                return "";
            i += key.Length;
            int j = line.IndexOf(" |", i, StringComparison.Ordinal);
            string v = j < 0 ? line.Substring(i) : line.Substring(i, j - i);
            return v.Trim();
        }

        private static double JrnNum(string s, double fallback)
        {
            if (string.IsNullOrWhiteSpace(s))
                return fallback;
            double v;
            string clean = s.Replace("$", "").Replace(",", "").Trim();
            return double.TryParse(clean, NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? v : fallback;
        }

        // Drops the "TITLE | " prefix so the column keeps only the data.
        private static string JrnStrip(string line)
        {
            if (string.IsNullOrEmpty(line))
                return "";
            int i = line.IndexOf(" | ", StringComparison.Ordinal);
            return i < 0 ? line : line.Substring(i + 3);
        }

        private static string JrnBlockKey(string msg)
        {
            if (msg.StartsWith("ENTRY BLOCKED - ", StringComparison.Ordinal))
                return JrnNormalize("ENTRY BLOCKED " + JrnCut(msg.Substring(16)));

            if (msg.StartsWith("JJ AI CORE ACCOUNT BLOCK", StringComparison.Ordinal))
                return JrnNormalize("ACCOUNT BLOCK " + JrnField(msg, "Reason: "));

            if (msg.IndexOf("BLOCK", StringComparison.Ordinal) < 0 &&
                msg.IndexOf("SKIP", StringComparison.Ordinal) < 0 &&
                msg.IndexOf("VETO", StringComparison.Ordinal) < 0 &&
                msg.IndexOf("EXPLOSION HOLD", StringComparison.Ordinal) < 0)
                return null;

            if (msg.StartsWith("LEVEL2 CONTEXT", StringComparison.Ordinal) ||
                msg.StartsWith("BOT LICENSE", StringComparison.Ordinal))
                return null;

            string[] segs = msg.Split(new[] { " | " }, StringSplitOptions.None);
            foreach (string seg in segs)
            {
                if (seg.Contains("BLOCK") || seg.Contains("SKIP") || seg.Contains("VETO") || seg.Contains("EXPLOSION HOLD"))
                    return JrnNormalize(seg);
            }

            return null;
        }

        private static string JrnCut(string s)
        {
            int i = s.IndexOf(" |", StringComparison.Ordinal);
            return i < 0 ? s : s.Substring(0, i);
        }

        private static string JrnNormalize(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char ch in s)
            {
                if (char.IsDigit(ch)) { if (sb.Length == 0 || sb[sb.Length - 1] != '#') sb.Append('#'); }
                else if (ch == ',' || ch == ';' || ch == '=' || ch == '\r' || ch == '\n') sb.Append(' ');
                else sb.Append(ch);
            }
            string r = sb.ToString().Trim();
            return r.Length > 60 ? r.Substring(0, 60) : r;
        }

        private string JrnAccount()
        {
            try { return selectedAccount != null ? selectedAccount.Name : "NO_ACCOUNT"; }
            catch { return "NO_ACCOUNT"; }
        }

        private string JrnInstrument()
        {
            try { return selectedInstrument != null ? selectedInstrument.FullName : ""; }
            catch { return ""; }
        }

        private static string JrnFileSafe(string s)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                s = s.Replace(c, '_');
            return s.Replace(' ', '_');
        }

        private static string JrnCsv(string s)
        {
            if (string.IsNullOrEmpty(s))
                return "";
            s = s.Replace("\r", " ").Replace("\n", " ");
            if (s.IndexOf(',') >= 0 || s.IndexOf('"') >= 0)
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        private void JrnAppend(string fileName, string header, string line)
        {
            string root = stateFolderPath;

            if (string.IsNullOrWhiteSpace(root))
            {
                root = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    "NinjaTrader 8",
                    "JJBotData");
            }

            string folder = Path.Combine(root, "Journal");
            Directory.CreateDirectory(folder);

            string path = Path.Combine(folder, fileName);
            bool exists = File.Exists(path);

            using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
            {
                if (!exists)
                    sw.WriteLine(header);
                sw.WriteLine(line);
            }
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TRADE MANAGEMENT
    // V1.7.06 FLOATING CAPITAL MANAGEMENT. Post-entry management remains drawdown-aware.
    // JJ qualifies entries around an 80-tick / 20-point opportunity, but the
    // user's configured TP remains authoritative and may be shorter or longer.
    // Peak floating PnL retention / giveback is now the PRIMARY profit-protection
    // authority. Fixed tick maps no longer own normal winner management.
    // Daily Target pace still calculates ExpectedMinimumPerTrade independently.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.38 - PROFIT RETENTION V3
        // V1.6.90 - MFE-BASED PROFIT RETENTION.
        // Profit Retention and Profit Giveback no longer wait for a hard
        // 45-second + 1.25R gate. Fast winners can bank part of peak MFE
        // immediately once the minimum meaningful MFE threshold is reached.
        private const double GlobalProfitRetentionGraceSeconds = 0.0;
        private const double GlobalProfitRetentionMinPeakR = 0.20;
        private string lastGlobalRetentionDeferredLogKey = string.Empty;
        private DateTime lastGlobalRetentionDeferredLogUtc = DateTime.MinValue;

        // V1.7.09 - PARTIAL PROFIT PLAN + ADAPTIVE SCALE LADDER + FIXED ORIGINAL TP3.
        // Base position is distributed automatically: ~33% at +30t, ~17% at +50t,
        // and the remainder at the original configured TP (standard = +80t).
        // After TP1 the stop is at BE; after any scale fill the floor becomes
        // Combined BE. Scale contracts always inherit the ORIGINAL final TP price.
        // 80 ticks / 20 MNQ-NQ points remains JJ's ENTRY QUALIFICATION focus only.
        // It is NOT a cap on the user's configured TP and it no longer owns the
        // winner stop map. Profit protection is based on PEAK FLOATING PnL:
        // Retention = CurrentOpenPnL / PeakOpenPnL; Giveback = 1 - Retention.
        private const int JjPrimaryObjectiveTicks = 80;
        private const int SmartScaleInZoneStartTicks = 30;
        private const int SmartScaleInZoneEndTicks = 50;

        // V1.7.09 - ADAPTIVE PARTIALS / SCALE LADDER.
        private const int AdaptivePartialTp1Ticks = 30;
        private const int AdaptivePartialTp2Ticks = 50;
        private const int AdaptiveScaleLargeMaxIntervalTicks = 2;
        private const int AdaptiveScaleAttemptThrottleMs = 250;

        private long adaptivePartialTradeKey = 0;
        private double adaptiveOriginalEntryPrice = 0;
        private int adaptiveOriginalBaseQuantity = 0;
        private string lastPreTp1ProtectionLogKey = string.Empty;
        // V1.7.51 - HYBRID Asia scalp time exit (no progress -> flatten).
        private const int HybridScalpTimeExitSeconds = 180;
        private const int HybridScalpTimeExitMinPeakTicks = 16;
        private long hybridScalpTimeExitEntryTicks = 0;
        private int adaptiveTp1PlannedQty = 0;
        private int adaptiveTp2PlannedQty = 0;
        private int adaptiveTp1FilledQty = 0;
        private int adaptiveTp2FilledQty = 0;
        private bool adaptiveTp1Submitted = false;
        private bool adaptiveTp2Submitted = false;
        private bool adaptiveTp1Filled = false;
        private bool adaptiveTp2Filled = false;
        private Order adaptiveTp1Order = null;
        private Order adaptiveTp2Order = null;
        private const double DailyTargetProgressProtectionFactor = 0.30;

        // V1.7.06 - PRIMARY FLOATING CAPITAL RETENTION MAP.
        // These are percentages of PEAK floating PnL, not ticks.
        // Strong expansion gets more breathing room; weakening context retains more.
        private const double FloatingRetentionStrongExpansion = 0.72; // allow ~28% giveback
        private const double FloatingRetentionNormal = 0.82;          // allow ~18% giveback
        private const double FloatingRetentionWeakening = 0.90;       // allow ~10% giveback
        private const double NearTargetStrongRetention = 0.88;        // secondary floor only
        private const double NearTargetNormalRetention = 0.92;
        private const double NearTargetWeakRetention = 0.95;

        // V1.7.08 - NEAR-TARGET PRICE TRAIL.
        // Once >=90% of the configured TP has been reached, normal Floating
        // Capital retention remains as a secondary floor, but the primary
        // near-target protection follows the best favorable PRICE closely.
        // Gap is a percentage of the user's configured target distance, so it
        // scales automatically with any TP instead of relying on hard tick maps.
        private const double NearTargetTrailGapStrongPctOfTarget = 0.050; // 5.0% TP distance
        private const double NearTargetTrailGapNormalPctOfTarget = 0.030; // 3.0%
        private const double NearTargetTrailGapWeakPctOfTarget = 0.015;   // 1.5%
        private const double NearTargetTrailMinGapTicks = 1.0;            // execution granularity only
        private string lastNearTargetPriceTrailLogKey = string.Empty;
        private DateTime lastNearTargetPriceTrailLogUtc = DateTime.MinValue;
        private const double MinimumObjectiveRetentionBoost = 0.03;
        private const double DailyProgressRetentionBoost = 0.03;
        private const double MaxAdaptiveFloatingRetention = 0.97;
        private const double FloatingCapitalMinPeakDollars = 10.0;
        private string lastFloatingCapitalManagementLogKey = string.Empty;
        private DateTime lastFloatingCapitalManagementLogUtc = DateTime.MinValue;

        // V1.7.07 - SCALE-IN / FLOATING CAPITAL SYNCHRONIZATION.
        // A scale fill changes quantity and weighted average immediately. Give the
        // new combined position a brief normalization window so that the size
        // transition itself is not misread as market giveback. During this window
        // Combined-BE + NeverWorsen remain fully authoritative.
        private const double FloatingCapitalScaleNormalizeSeconds = 1.50;
        private const double SmartScaleInNearTargetBlockFactor = 0.90;
        private int floatingCapitalObservedQuantity = 0;
        private DateTime floatingCapitalScaleNormalizeUntilUtc = DateTime.MinValue;
        private double floatingCapitalPreScalePeakDollars = 0;
        private string lastFloatingCapitalScaleSyncLogKey = string.Empty;

        // EOD: give the trade more room while still preventing a +30/+40/+50t
        // winner from returning to the original stop.
        private const int EodProtect30Ticks = 12;
        private const int EodProtect40Ticks = 20;
        private const int EodProtect50Ticks = 32;
        private const int EodProtect60Ticks = 40;
        private const int EodProtect70Ticks = 56;

        // INTRADAY/TRAILING: preserve equity more aggressively.
        private const int IntradayProtect30Ticks = 18;
        private const int IntradayProtect40Ticks = 28;
        private const int IntradayProtect50Ticks = 34;
        private const int IntradayProtect60Ticks = 48;
        private const int IntradayProtect70Ticks = 62;

        // Once the trade has met its dynamically expected minimum OR the day
        // has reached 30% of Daily Target, use a tighter tick map while still
        // allowing the trade to continue toward the 80t objective.
        private const int EodTightProtect30Ticks = 18;
        private const int EodTightProtect40Ticks = 28;
        private const int EodTightProtect50Ticks = 40;
        private const int EodTightProtect60Ticks = 50;
        private const int EodTightProtect70Ticks = 62;

        private const int IntradayTightProtect30Ticks = 20;
        private const int IntradayTightProtect40Ticks = 32;
        private const int IntradayTightProtect50Ticks = 42;
        private const int IntradayTightProtect60Ticks = 52;
        private const int IntradayTightProtect70Ticks = 65;

        private const double EodPeakLockFactor = 0.65;
        private const double EodPeakLockDailyProgressFactor = 0.75;
        private const double IntradayPeakLockFactor = 0.75;
        private const double IntradayPeakLockDailyProgressFactor = 0.80;

        private string lastTradeManagementModeLogKey = string.Empty;
        private string lastExpectedMinimumTradeLogKey = string.Empty;
        private string lastTickProtectionLogKey = string.Empty;
        private string lastMinimumObjectiveLogKey = string.Empty;
        private string lastDailyThirtyProtectionLogKey = string.Empty;
        private string lastScaleZoneLogKey = string.Empty;

        // V1.6.87 - EXPANSION HOLD V2.1 / BREAKOUT + ORIGIN EXPANSION
        // Trade-management-only experiment. Entry, SL/TP, Daily Target,
        // Scale-In eligibility and risk limits remain unchanged.
        //
        // Initial qualification has TWO management-only paths:
        //   A) BREAKOUT EXPANSION
        //      - same-side R20 >= 4/5
        //      - active same-side breakout
        //      - volume >= 1.25x
        //   B) ORIGIN EXPANSION (no breakout required)
        //      - same-side R20 >= 4/5
        //      - volume >= 1.50x
        //      - supportive live L2/tape persistence
        //      - trade has already progressed >= 16 ticks in favor
        //
        // This changes ONLY management after an entry already exists. It does
        // not create entries, bypass Final Entry Authority or alter Scale-In.
        //
        // V2.1 then evaluates fresh market context continuously. The hold is
        // refreshed by a support score built from R20, breakout, volume and L2.
        // A brief pullback or one weak snapshot does NOT immediately cancel it.
        //
        // Hold releases when:
        //   - peak excursion reaches 80 ticks (20 MNQ/NQ points), OR
        //   - there is a hard momentum reversal (same <=2 AND opposite >=4), OR
        //   - confirmation has been stale >=20s, current support is weak (<=1/4)
        //     and price has given back >=28 ticks from peak.
        //
        // While Hold is active:
        //   - the first +30t protection may move to breakeven only;
        //   - Lock / Lock2 / dynamic trailing are deferred;
        //   - Profit Retention and Profit Giveback are deferred.
        //
        // Regular/non-expansion trades keep the existing management unchanged.
        private const int ExpansionHoldObjectiveTicks = 80;
        private const int ExpansionHoldMinMomentumScore = 4;
        private const double ExpansionHoldMinVolumeRatio = 1.25;
        private const double ExpansionHoldOriginMinVolumeRatio = 1.50;
        private const double ExpansionHoldOriginMinFavorableTicks = 16.0;
        private const int ExpansionHoldReleaseSameSideScore = 2;
        private const int ExpansionHoldReleaseOppositeScore = 4;
        private const int ExpansionHoldRefreshMinSupportScore = 3;
        private const int ExpansionHoldWeakSupportScore = 1;
        private const double ExpansionHoldConfirmationGraceSeconds = 20.0;
        private const double ExpansionHoldMinGivebackTicksForStaleRelease = 28.0;
        private const int ExpansionHoldL2Persistence = 4;
        private DateTime expansionHoldTradeEntryUtc = DateTime.MinValue;
        private DateTime expansionHoldLastConfirmedUtc = DateTime.MinValue;
        private bool expansionHoldQualified = false;
        private bool lastExpansionHoldActive = false;
        private int lastExpansionHoldSupportScore = 0;
        private string expansionHoldQualificationMode = "NONE";

        // V1.6.66 - Explosion Fast Retention. At the first +30t trigger,
        // protect +18t (~60% of that first impulse) so intraday-trailing
        // accounts preserve more floating capital when the explosion fades.
        private const int MomentumFirstProtectionProfitTicks = 18;

        // V1.6.89 - MANAGEMENT-ONLY NOISE TOLERANCE / INTRADAY FLOATING FLOOR / MISSION MODE.
        // No entry, signal, Final Entry Authority, regime or Scale-In eligibility logic is changed.
        private const double TradeBreathingRoomPeakTicks = 80.0;
        private const double IntradayFloorStage1PeakDollars = 120.0;
        private const double IntradayFloorStage2PeakDollars = 160.0;
        private const double IntradayFloorStage3PeakDollars = 200.0;
        private const double IntradayFloorStage4PeakDollars = 250.0;
        private const double IntradayFloorStage5PeakDollars = 300.0;
        private const double IntradayFloorStage1Factor = 0.40;
        private const double IntradayFloorStage2Factor = 0.50;
        private const double IntradayFloorStage3Factor = 0.60;
        private const double IntradayFloorStage4Factor = 0.70;
        private const double IntradayFloorStage5Factor = 0.75;
        private const double PostScaleMinimumFloorFactor = 0.65;
        private const double EodPostScaleMinimumFloorFactor = 0.60;

        // V1.6.92 - SESSION-ADAPTIVE POST-SCALE BREATHING ROOM.
        // Percent-of-peak floors remain the capital-protection layer, but after
        // Smart Scale-In they cannot place a NEW stop too close to live price
        // while continuation remains healthy. Distance is expressed in PRICE
        // POINTS (not dollars), so larger contract size does not accidentally
        // turn the floor into a 3-4 point noise stop at NY Open.
        private const double NyOpenBreathingBasePoints = 10.0;
        private const double NyOpenBreathingMinPoints = 8.0;
        private const double NyOpenBreathingMaxPoints = 14.0;
        private const double NyAmBreathingBasePoints = 8.0;
        private const double NyAmBreathingMinPoints = 6.0;
        private const double NyAmBreathingMaxPoints = 10.0;
        private const double NyPmBreathingBasePoints = 7.0;
        private const double NyPmBreathingMinPoints = 5.0;
        private const double NyPmBreathingMaxPoints = 9.0;
        private const double LondonBreathingBasePoints = 7.0;
        private const double LondonBreathingMinPoints = 5.0;
        private const double LondonBreathingMaxPoints = 9.0;
        private const double AsiaBreathingBasePoints = 5.0;
        private const double AsiaBreathingMinPoints = 3.0;
        private const double AsiaBreathingMaxPoints = 7.0;
        private const double PreOpenBreathingBasePoints = 9.0;
        private const double PreOpenBreathingMinPoints = 7.0;
        private const double PreOpenBreathingMaxPoints = 12.0;
        private const double OtherBreathingBasePoints = 6.0;
        private const double OtherBreathingMinPoints = 4.0;
        private const double OtherBreathingMaxPoints = 8.0;
        private string lastAdaptiveBreathingLogKey = string.Empty;
        private DateTime lastAdaptiveBreathingLogUtc = DateTime.MinValue;

        private const double MissionModeMinVolumeRatio = 1.25;
        private const int MissionModeMinMomentumScore = 4;
        private const int MissionModeMinHtfScore = 1;
        private const int MissionModeTargetSafetyTicks = 4;
        private const double MissionModeDollarCushion = 1.03;

        // =====================================================
        // RECOVERY V4 - NEAR-TARGET PROFIT PROTECTION ONLY
        // =====================================================
        // Management-only. Does NOT change entry, direction, target,
        // Final Entry Authority, Learning, risk sizing or central-core logic.
        //
        // Once peak MFE reaches >=90% of the currently-live TP distance,
        // arm near-target protection. The base 88% floor gives strong expansion
        // room; the V1.7.06 adaptive floating-capital block may tighten further.
        // The TP itself is NOT moved and the trade is NOT market-closed.
        private const double NearTargetActivationFactor = 0.90;
        private const double NearTargetRetentionFactor = 0.88;
        private const double NearTargetMinTargetTicks = 20.0;
        private string lastNearTargetProtectionLogKey = string.Empty;
        private DateTime lastNearTargetProtectionLogUtc = DateTime.MinValue;
        private const int NearTargetProtectionLogThrottleMs = 1000;

        private DateTime lastMissionTargetChangeUtc = DateTime.MinValue;
        private double lastMissionTargetPrice = 0;
        private string lastMissionModeLogKey = string.Empty;


        private double GetSessionAdaptivePostScaleBreathingRoomPoints(
            bool strongContinuation,
            bool exceptionalContinuation,
            bool weakContinuation,
            out string sessionName)
        {
            DateTime nyNow;

            try
            {
                TimeZoneInfo eastern =
                    TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

                nyNow =
                    TimeZoneInfo.ConvertTimeFromUtc(
                        DateTime.UtcNow,
                        eastern
                    );
            }
            catch
            {
                nyNow = DateTime.UtcNow;
            }

            TimeSpan tod = nyNow.TimeOfDay;

            double basePoints;
            double minPoints;
            double maxPoints;

            if (tod >= new TimeSpan(9, 30, 0) && tod < new TimeSpan(10, 0, 0))
            {
                sessionName = "NY_OPEN";
                basePoints = NyOpenBreathingBasePoints;
                minPoints = NyOpenBreathingMinPoints;
                maxPoints = NyOpenBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(10, 0, 0) && tod < new TimeSpan(12, 0, 0))
            {
                sessionName = "NY_AM";
                basePoints = NyAmBreathingBasePoints;
                minPoints = NyAmBreathingMinPoints;
                maxPoints = NyAmBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(13, 0, 0) && tod < new TimeSpan(16, 0, 0))
            {
                sessionName = "NY_PM";
                basePoints = NyPmBreathingBasePoints;
                minPoints = NyPmBreathingMinPoints;
                maxPoints = NyPmBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(8, 0, 0) && tod < new TimeSpan(9, 30, 0))
            {
                sessionName = "NY_PREOPEN";
                basePoints = PreOpenBreathingBasePoints;
                minPoints = PreOpenBreathingMinPoints;
                maxPoints = PreOpenBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(3, 0, 0) && tod < new TimeSpan(8, 0, 0))
            {
                sessionName = "LONDON";
                basePoints = LondonBreathingBasePoints;
                minPoints = LondonBreathingMinPoints;
                maxPoints = LondonBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(18, 0, 0) || tod < new TimeSpan(3, 0, 0))
            {
                sessionName = "ASIA_OVERNIGHT";
                basePoints = AsiaBreathingBasePoints;
                minPoints = AsiaBreathingMinPoints;
                maxPoints = AsiaBreathingMaxPoints;
            }
            else
            {
                sessionName = "OTHER";
                basePoints = OtherBreathingBasePoints;
                minPoints = OtherBreathingMinPoints;
                maxPoints = OtherBreathingMaxPoints;
            }

            double roomPoints = basePoints;

            if (exceptionalContinuation)
                roomPoints = maxPoints;
            else if (strongContinuation)
                roomPoints = Math.Min(maxPoints, basePoints + 2.0);
            else if (weakContinuation)
                roomPoints = minPoints;

            return Math.Max(minPoints, Math.Min(maxPoints, roomPoints));
        }


        private int GetDailyTradeCapacityForManagement()
        {
            // V1.7.28 - FIXED AM/PM-ONLY EXECUTION CAPACITY.
            // NY AM 3 + NY PM 3 = 6 maximum automatic entries/day.
            // Asia/Premarket are context-only and never consume capacity.
            return 6;
        }

        private int GetDailyTradesTakenForManagement()
        {
            return Math.Max(
                0,
                amTradesToday +
                pmTradesToday
            );
        }

        private double GetExpectedMinimumPerTrade(
            double realizedDayPnl,
            double dailyTarget,
            out int remainingTradesIncludingCurrent,
            out double remainingTarget)
        {
            int dailyCapacity = GetDailyTradeCapacityForManagement();
            int tradesTaken = GetDailyTradesTakenForManagement();

            // Session counters are incremented on fill, so the active trade is
            // already included in tradesTaken. Add it back to the remaining
            // opportunity count so trade #1 still sees DailyTarget / 6.
            remainingTradesIncludingCurrent =
                Math.Max(1, dailyCapacity - tradesTaken + 1);

            remainingTarget =
                Math.Max(0, dailyTarget - realizedDayPnl);

            return remainingTradesIncludingCurrent > 0
                ? remainingTarget / remainingTradesIncludingCurrent
                : remainingTarget;
        }

        private int GetTickProtectionFloorTicks(
            bool intradayDrawdownMode,
            double peakFavorableTicks,
            bool tightened)
        {
            if (peakFavorableTicks < 30.0)
                return 0;

            if (intradayDrawdownMode)
            {
                if (peakFavorableTicks >= 70.0)
                    return tightened ? IntradayTightProtect70Ticks : IntradayProtect70Ticks;
                if (peakFavorableTicks >= 60.0)
                    return tightened ? IntradayTightProtect60Ticks : IntradayProtect60Ticks;
                if (peakFavorableTicks >= 50.0)
                    return tightened ? IntradayTightProtect50Ticks : IntradayProtect50Ticks;
                if (peakFavorableTicks >= 40.0)
                    return tightened ? IntradayTightProtect40Ticks : IntradayProtect40Ticks;

                return tightened ? IntradayTightProtect30Ticks : IntradayProtect30Ticks;
            }

            if (peakFavorableTicks >= 70.0)
                return tightened ? EodTightProtect70Ticks : EodProtect70Ticks;
            if (peakFavorableTicks >= 60.0)
                return tightened ? EodTightProtect60Ticks : EodProtect60Ticks;
            if (peakFavorableTicks >= 50.0)
                return tightened ? EodTightProtect50Ticks : EodProtect50Ticks;
            if (peakFavorableTicks >= 40.0)
                return tightened ? EodTightProtect40Ticks : EodProtect40Ticks;

            return tightened ? EodTightProtect30Ticks : EodProtect30Ticks;
        }

        // =====================================================
        // V1.6.33 - STRUCTURE-AWARE TARGET V1
        // =====================================================
        // This method changes only where profit is taken. V1.6.36 adds a
        // separate pre-entry Structural RR gate in JJBotExecutionEngine;
        // this target helper itself still does not decide entry eligibility.
        //
        // V1.7.05: structure remains entry-room context. The user's configured
        // TP is preserved exactly after fill, even if it is shorter or longer
        // than the 80-tick entry qualification window.
        private const int StructureTargetMaxBufferTicks = 8;
        private string lastStructureTargetLogKey = string.Empty;

        // V1.6.75 - Protective Stop Safety telemetry debounce only.
        // Stop calculations and Account.Change() behavior are unchanged.
        private string lastProtectiveStopSafetyLogKey = string.Empty;
        private DateTime lastProtectiveStopSafetyLogUtc = DateTime.MinValue;
        private const int ProtectiveStopSafetyLogThrottleMs = 750;

        private int GetStructureAwareTargetTicks(
            MarketPosition marketPosition,
            double entryPrice,
            double tickSize,
            int dynamicTargetTicks)
        {
            // V1.7.05 - structure decides ENTRY ROOM, not the user's TP.
            // The pre-entry 20PT gate already required 80 effective ticks (or
            // open space). Once filled, preserve the exact configured target.
            if (
                dynamicTargetTicks <= 0 ||
                entryPrice <= 0 ||
                tickSize <= 0 ||
                marketPosition == MarketPosition.Flat
            )
            {
                return Math.Max(1, dynamicTargetTicks);
            }

            bool isLong = marketPosition == MarketPosition.Long;
            double roomTicks;
            string referenceName;
            double referencePrice;

            bool hasBarrier =
                TryGetEntryLocationRoom(
                    isLong,
                    entryPrice,
                    tickSize,
                    out roomTicks,
                    out referenceName,
                    out referencePrice
                );

            if (hasBarrier)
            {
                PrintBotMessage(
                    "TARGET STRUCTURE CONTEXT"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | ConfiguredTP: " + dynamicTargetTicks + "t"
                    + " | Next: " + referenceName
                    + " @ " + referencePrice.ToString("0.00")
                    + " | RawRoom: " + roomTicks.ToString("0") + "t"
                    + " | Action: USER TP PRESERVED"
                );
            }

            return dynamicTargetTicks;
        }

        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            // V1.7.05 - USER TARGET AUTHORITY.
            // The 20PT engine qualifies the ENTRY using 80 clean ticks, but once
            // inside the market JJ respects the TP configured by the user exactly.
            // No momentum/HTF/mission rule may silently shorten or extend it.
            int targetTicks = Math.Max(1, activeTargetTicks);

            PrintBotMessage(
                "USER TARGET AUTHORITY"
                + " | ConfiguredTP: " + targetTicks + "t"
                + " | EntryFocus: " + JjPrimaryObjectiveTicks + "t / 20pt"
                + " | Action: KEEP USER TP"
            );

            return targetTicks;
        }

        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            // V1.7.09 - TP3 NEVER MOVES AFTER SCALE-IN.
            // Stop calculations use the live weighted average, but the final TP
            // stays anchored to the original trade entry.
            double finalTargetAnchor =
                adaptiveOriginalEntryPrice > 0
                    ? adaptiveOriginalEntryPrice
                    : (
                        smartScaleInAnchorEntryPrice > 0
                            ? smartScaleInAnchorEntryPrice
                            : averageEntryPrice
                      );

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    finalTargetAnchor
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    finalTargetAnchor
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            // =====================================================
            // V8 - NEVER-WORSEN PROTECTIVE STOP GUARD
            // =====================================================
            // OCO Sync may resize/synchronize the bracket, but it must
            // NEVER move an already-improved stop backwards.
            //
            // LONG  -> higher stop is better.
            // SHORT -> lower stop is better.
            //
            // activeStopPrice is reserved immediately by BE / Lock /
            // Trailing / Daily Target protection before Account.Change(),
            // so synchronous OrderUpdate callbacks cannot reconstruct the
            // original SL while NinjaTrader is processing the change.
            double protectedStopPrice;

            lock (executionStateLock)
            {
                protectedStopPrice =
                    activeStopPrice;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    marketPosition,
                    protectedStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // =====================================================
            // SMART SCALE-IN COMBINED BREAK-EVEN GUARD
            // =====================================================
            // After a scale-in fill, averageEntryPrice is the NEW weighted
            // average for the entire open position. The old stop may have
            // been break-even for the pre-scale position but still be a loss
            // for the larger combined position. Never allow that condition.
            bool scaleInActive;
            double liveScaleFallbackPrice;

            lock (executionStateLock)
            {
                scaleInActive = smartScaleInUsed;
                liveScaleFallbackPrice = activeTradeCurrentPrice;
            }

            if (scaleInActive)
            {
                double combinedBreakEvenStop =
                    RoundToInstrumentTick(
                        averageEntryPrice
                    );

                desiredStop =
                    EnforceNeverWorsenStop(
                        marketPosition,
                        combinedBreakEvenStop,
                        desiredStop
                    );

                desiredStop =
                    RoundToInstrumentTick(
                        desiredStop
                    );

                bool liveAdjusted;
                bool usedLevel2;
                double liveReferencePrice;

                double liveSafeStop =
                    ClampProtectiveStopToLiveMarket(
                        marketPosition,
                        desiredStop,
                        liveScaleFallbackPrice,
                        tickSize,
                        out liveAdjusted,
                        out usedLevel2,
                        out liveReferencePrice
                    );

                bool canKeepCombinedBreakeven =
                    marketPosition == MarketPosition.Long
                        ? liveSafeStop >= combinedBreakEvenStop - tickSize * 0.5
                        : liveSafeStop <= combinedBreakEvenStop + tickSize * 0.5;

                if (!canKeepCombinedBreakeven)
                {
                    PrintBotMessage(
                        "SMART SCALE-IN PROTECTION FAILURE"
                        + " | Avg: " + averageEntryPrice.ToString("0.00")
                        + " | Required BE SL: " + combinedBreakEvenStop.ToString("0.00")
                        + " | LiveSafe SL: " + liveSafeStop.ToString("0.00")
                        + " | MarketRef: " + liveReferencePrice.ToString("0.00")
                        + " | Action: EMERGENCY FLATTEN"
                    );

                    try
                    {
                        account.Flatten(
                            new[]
                            {
                                instrument
                            }
                        );
                    }
                    catch (Exception flattenEx)
                    {
                        PrintBotMessage(
                            "SMART SCALE-IN EMERGENCY FLATTEN ERROR: "
                            + flattenEx.Message
                        );
                    }

                    return;
                }

                desiredStop = liveSafeStop;

                PrintBotMessage(
                    "SMART SCALE-IN COMBINED BE"
                    + " | Avg: " + averageEntryPrice.ToString("0.00")
                    + " | SL: " + desiredStop.ToString("0.00")
                    + " | Qty: " + openQuantity
                );
            }

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_TARGET"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_STOP"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private double EnforceNeverWorsenStop(
            MarketPosition side,
            double currentProtectedStop,
            double requestedStop)
        {
            if (requestedStop <= 0)
                return currentProtectedStop;

            if (currentProtectedStop <= 0)
                return requestedStop;

            if (side == MarketPosition.Long)
            {
                return Math.Max(
                    currentProtectedStop,
                    requestedStop
                );
            }

            if (side == MarketPosition.Short)
            {
                return Math.Min(
                    currentProtectedStop,
                    requestedStop
                );
            }

            return currentProtectedStop;
        }
        // V1.6.73 - LIVE PROTECTIVE STOP PRICE SAFETY
        // Revalidate the final stop against the freshest available L2 bid/ask
        // immediately before Account.Change(). This prevents NinjaTrader
        // UnableToChangeOrder / InvalidPrice when price crosses the requested
        // protection level between calculation and submission.
        private double ClampProtectiveStopToLiveMarket(
            MarketPosition side,
            double requestedStop,
            double fallbackPrice,
            double tickSize,
            out bool adjusted,
            out bool usedLevel2,
            out double liveReferencePrice)
        {
            adjusted = false;
            usedLevel2 = false;
            liveReferencePrice = fallbackPrice;

            if (requestedStop <= 0 || tickSize <= 0)
                return requestedStop;

            double bestBid = 0;
            double bestAsk = 0;

            lock (level2Sync)
            {
                if (
                    level2BookReady &&
                    level2BidRows.Count > 0 &&
                    level2AskRows.Count > 0
                )
                {
                    bestBid = level2BidRows[0].Price;
                    bestAsk = level2AskRows[0].Price;
                }
            }

            const int safetyTicks = 2;
            double safeStop = requestedStop;

            if (side == MarketPosition.Long)
            {
                double reference = bestBid > 0
                    ? bestBid
                    : fallbackPrice;

                if (reference <= 0)
                    return requestedStop;

                usedLevel2 = bestBid > 0;
                liveReferencePrice = reference;

                double maxValidSellStop =
                    RoundToInstrumentTick(
                        reference -
                        (safetyTicks * tickSize)
                    );

                safeStop = Math.Min(
                    requestedStop,
                    maxValidSellStop
                );
            }
            else if (side == MarketPosition.Short)
            {
                double reference = bestAsk > 0
                    ? bestAsk
                    : fallbackPrice;

                if (reference <= 0)
                    return requestedStop;

                usedLevel2 = bestAsk > 0;
                liveReferencePrice = reference;

                double minValidBuyStop =
                    RoundToInstrumentTick(
                        reference +
                        (safetyTicks * tickSize)
                    );

                safeStop = Math.Max(
                    requestedStop,
                    minValidBuyStop
                );
            }

            safeStop =
                RoundToInstrumentTick(
                    safeStop
                );

            adjusted =
                Math.Abs(
                    safeStop - requestedStop
                ) >= tickSize * 0.5;

            return safeStop;
        }

        // V1.6.93 - MISSION MODE TARGET MANAGER / LIVE OPEN-QTY FIX. Management-only.
        // Extends or contracts the working TP toward the dollars still needed
        // for the configured daily target while continuation remains aligned.
        // It never changes entry eligibility or Scale-In risk limits.
        private void TryUpdateMissionModeTarget(
            double currentPrice,
            MarketPosition side,
            double entryPrice,
            int openQuantity,
            int sideMomentumScore,
            int htfScore,
            bool m5Aligned,
            bool sideBreakout,
            double volumeRatio,
            bool l2Ready,
            int oppositePersistence,
            double signedTapeDelta)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            // V1.6.93 - MISSION LIVE OPEN-QTY AUTHORITY.
            // The caller's quantity snapshot can be stale after Smart Scale-In or
            // a partial exit. Rebuild the quantity from the execution state that
            // actually owns the live position before converting dollars to points.
            int liveOpenQuantity;

            lock (executionStateLock)
            {
                liveOpenQuantity =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );
            }

            if (account == null || instrument == null || currentPrice <= 0 ||
                entryPrice <= 0 || liveOpenQuantity <= 0 || side == MarketPosition.Flat)
                return;

            double dailyTarget = activeDailyTarget;
            double realizedDayPnl = botDailyPnL;
            if (dailyTarget <= 0 || realizedDayPnl >= dailyTarget || dailyTargetProtectionArmed)
                return;

            bool continuationAligned =
                sideMomentumScore >= MissionModeMinMomentumScore &&
                htfScore >= MissionModeMinHtfScore &&
                m5Aligned &&
                (sideBreakout || volumeRatio >= MissionModeMinVolumeRatio);

            // L2 is confirmation, not mandatory authority. If ready, clear
            // opposite persistence + negative tape can veto Mission extension.
            if (l2Ready && oppositePersistence >= ExpansionHoldL2Persistence && signedTapeDelta < 0)
                continuationAligned = false;

            if (!continuationAligned)
                return;

            Order localTarget;
            double currentTargetPrice;
            lock (executionStateLock)
            {
                localTarget = targetOrder;
                currentTargetPrice = activeTargetPrice;
            }

            if (localTarget == null ||
                (localTarget.OrderState != OrderState.Working && localTarget.OrderState != OrderState.Accepted))
                return;

            double pointValue = instrument.MasterInstrument.PointValue;
            double tickSize = instrument.MasterInstrument.TickSize;
            if (pointValue <= 0 || tickSize <= 0)
                return;

            double dollarsStillNeeded =
                Math.Max(0, (dailyTarget - realizedDayPnl) * MissionModeDollarCushion);
            if (dollarsStillNeeded <= 0)
                return;

            double missionPoints =
                dollarsStillNeeded / (pointValue * liveOpenQuantity);

            double missionTargetPrice =
                side == MarketPosition.Long
                    ? entryPrice + missionPoints
                    : entryPrice - missionPoints;

            // V1.7.05 - retained only for backward compatibility if this helper
            // is ever called again. The live management loop no longer invokes it;
            // user-configured TP is the sole target authority.
            double configuredTargetPrice =
                side == MarketPosition.Long
                    ? entryPrice + Math.Max(1, activeTargetTicks) * tickSize
                    : entryPrice - Math.Max(1, activeTargetTicks) * tickSize;

            double minimumForwardTarget =
                side == MarketPosition.Long
                    ? currentPrice + MissionModeTargetSafetyTicks * tickSize
                    : currentPrice - MissionModeTargetSafetyTicks * tickSize;

            if (side == MarketPosition.Long)
            {
                if (minimumForwardTarget >= configuredTargetPrice)
                    return;

                missionTargetPrice = Math.Max(missionTargetPrice, minimumForwardTarget);
                missionTargetPrice = Math.Min(missionTargetPrice, configuredTargetPrice);
            }
            else
            {
                if (minimumForwardTarget <= configuredTargetPrice)
                    return;

                missionTargetPrice = Math.Min(missionTargetPrice, minimumForwardTarget);
                missionTargetPrice = Math.Max(missionTargetPrice, configuredTargetPrice);
            }

            missionTargetPrice = RoundToInstrumentTick(missionTargetPrice);

            if (currentTargetPrice <= 0)
                currentTargetPrice = side == MarketPosition.Long ? double.MinValue : double.MaxValue;

            if (Math.Abs(missionTargetPrice - localTarget.LimitPrice) < tickSize * 0.5)
                return;

            DateTime nowUtc = DateTime.UtcNow;
            if (lastMissionTargetChangeUtc != DateTime.MinValue &&
                (nowUtc - lastMissionTargetChangeUtc).TotalMilliseconds < ProtectiveOrderChangeThrottleMs)
                return;

            long token;
            if (!TryBeginProtectiveChange("MISSION_TARGET", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    int refreshedOpenQuantity =
                        Math.Max(
                            0,
                            entryQuantity -
                            activeExitQuantity
                        );

                    // Quantity may change asynchronously when Smart Scale-In fills
                    // or a partial exit completes. Never submit a TP calculated
                    // with a stale quantity; the next management tick will recalc.
                    if (!ReferenceEquals(targetOrder, localTarget) ||
                        entryMarketPosition != side ||
                        dailyTargetProtectionArmed ||
                        refreshedOpenQuantity != liveOpenQuantity)
                        return;

                    activeTargetPrice = missionTargetPrice;
                    activeEffectiveTargetTicks =
                        Math.Max(
                            1,
                            (int)Math.Round(
                                Math.Abs(missionTargetPrice - entryPrice) / tickSize
                            )
                        );
                    localTarget.LimitPriceChanged = missionTargetPrice;
                    lastMissionTargetChangeUtc = nowUtc;
                    lastMissionTargetPrice = missionTargetPrice;
                }

                account.Change(new[] { localTarget });

                string missionKey =
                    side + "|" + missionTargetPrice.ToString("0.00") + "|" +
                    liveOpenQuantity + "|" + sideMomentumScore + "|" + htfScore;

                if (!string.Equals(missionKey, lastMissionModeLogKey, StringComparison.Ordinal))
                {
                    lastMissionModeLogKey = missionKey;
                    PrintBotMessage(
                        "MISSION MODE TARGET"
                        + " | Side: " + side
                        + " | RealizedDay: " + realizedDayPnl.ToString("$0.00")
                        + " | DailyTarget: " + dailyTarget.ToString("$0.00")
                        + " | Qty: " + liveOpenQuantity
                        + " | R20: " + sideMomentumScore + "/5"
                        + " | HTF: " + htfScore + "/2"
                        + " | Breakout: " + sideBreakout
                        + " | Volume x" + volumeRatio.ToString("0.00")
                        + " | New TP: " + missionTargetPrice.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("MISSION MODE TARGET ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }

        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            // V1.7.32 - CORE20 owns management in CORE20 mode:
            // partials 30/50/TP + break-even after TP1 + 60-minute time exit.
            // No floating-capital, near-target, retention or trailing layers.
            if (IsCore20Mode())
            {
                Core20ManageOpenTrade(currentPrice);
                return;
            }

            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            double localActiveTargetPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            int localBreakEvenTriggerTicks;
            bool localStrongMomentumProtection;
            bool localTrailingActive;
            bool localDailyProtectionArmed;
            double localInitialRiskDollars;
            double localPeakPnlDollars;
            int localProfitRetentionStage;
            bool localM5BullishTrend;
            bool localM5BearishTrend;
            bool localM5AboveVwap;
            bool localM5BelowVwap;
            bool localM5BullishStructure;
            bool localM5BearishStructure;
            int localRangeLongScore;
            int localRangeShortScore;
            int localHtfLongScore;
            int localHtfShortScore;
            double localBotDailyPnL;
            double localDailyTarget;
            bool localOpeningTrade;
            bool localSmartScaleInUsed;
            DateTime localTradeEntryUtc;
            double localRangeVolumeRatio;
            bool localSideBreakout;
            bool localFloatingScaleNormalizeActive = false;
            bool localFloatingScaleFillDetected = false;
            double localFloatingPreScalePeakDollars = 0;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                // RECOVERY V4.1:
                // snapshot the currently-live target so Near-Target
                // Protection evaluates the same target the order manager uses.
                localActiveTargetPrice =
                    activeTargetPrice;

                localEntryQuantity =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localBreakEvenTriggerTicks =
                    activeBreakEvenTriggerTicks > 0
                        ? activeBreakEvenTriggerTicks
                        : MomentumBreakEvenTriggerTicks;

                localStrongMomentumProtection =
                    activeStrongMomentumProtection;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;

                localInitialRiskDollars =
                    initialTradeRiskDollars;

                localPeakPnlDollars =
                    activeTradePeakPnlDollars;

                localProfitRetentionStage =
                    activeProfitRetentionStage;

                localM5BullishTrend = latestM5BullishTrend;
                localM5BearishTrend = latestM5BearishTrend;
                localM5AboveVwap = latestM5AboveVwap;
                localM5BelowVwap = latestM5BelowVwap;
                localM5BullishStructure = latestM5BullishStructure;
                localM5BearishStructure = latestM5BearishStructure;
                localRangeLongScore = latestRangeLongScore;
                localRangeShortScore = latestRangeShortScore;
                localHtfLongScore = latestHtfLongScore;
                localHtfShortScore = latestHtfShortScore;
                localBotDailyPnL = botDailyPnL;
                localDailyTarget = activeDailyTarget;
                localOpeningTrade = activeTradeIsOpening;
                localSmartScaleInUsed = smartScaleInUsed;
                localTradeEntryUtc = activeTradeEntryUtc;
            }

            lock (marketContextLock)
            {
                localRangeVolumeRatio =
                    latestRangeVolumeRatio;

                localSideBreakout =
                    localMarketPosition == MarketPosition.Long
                        ? latestRangeHighBreakout
                        : latestRangeLowBreakout;
            }

            // V1.7.07 - Detect a filled scale add from the live open quantity.
            // We do not reset the trade's true peak; we only pause NEW floating-
            // capital tightening briefly while Ninja/position accounting settles.
            DateTime floatingScaleNowUtc = DateTime.UtcNow;

            lock (executionStateLock)
            {
                if (localMarketPosition == MarketPosition.Flat || localEntryQuantity <= 0)
                {
                    floatingCapitalObservedQuantity = 0;
                    floatingCapitalScaleNormalizeUntilUtc = DateTime.MinValue;
                    floatingCapitalPreScalePeakDollars = 0;
                    lastFloatingCapitalScaleSyncLogKey = string.Empty;
                }
                else
                {
                    if (floatingCapitalObservedQuantity <= 0)
                    {
                        floatingCapitalObservedQuantity = localEntryQuantity;
                    }
                    else if (
                        localSmartScaleInUsed &&
                        localEntryQuantity > floatingCapitalObservedQuantity
                    )
                    {
                        floatingCapitalPreScalePeakDollars =
                            Math.Max(0, localPeakPnlDollars);

                        floatingCapitalObservedQuantity =
                            localEntryQuantity;

                        floatingCapitalScaleNormalizeUntilUtc =
                            floatingScaleNowUtc.AddSeconds(
                                FloatingCapitalScaleNormalizeSeconds
                            );

                        localFloatingScaleFillDetected = true;
                    }
                    else if (localEntryQuantity < floatingCapitalObservedQuantity)
                    {
                        // Partial exits are not scale adds. Track the new live qty
                        // without starting a scale normalization window.
                        floatingCapitalObservedQuantity = localEntryQuantity;
                    }

                    localFloatingScaleNormalizeActive =
                        floatingCapitalScaleNormalizeUntilUtc != DateTime.MinValue &&
                        floatingScaleNowUtc < floatingCapitalScaleNormalizeUntilUtc;

                    localFloatingPreScalePeakDollars =
                        floatingCapitalPreScalePeakDollars;
                }
            }

            if (localFloatingScaleFillDetected)
            {
                string scaleSyncKey =
                    localTradeEntryUtc.Ticks + "|" + localEntryQuantity;

                if (scaleSyncKey != lastFloatingCapitalScaleSyncLogKey)
                {
                    lastFloatingCapitalScaleSyncLogKey = scaleSyncKey;
                    PrintBotMessage(
                        "FLOATING CAPITAL SCALE SYNC"
                        + " | Qty: " + localEntryQuantity
                        + " | PreScalePeak: " + localFloatingPreScalePeakDollars.ToString("$0.00")
                        + " | Normalize: " + FloatingCapitalScaleNormalizeSeconds.ToString("0.00") + "s"
                        + " | AuthorityDuringSync: COMBINED BE + NEVER_WORSEN"
                    );
                }
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            // V1.7.09 - partial exits are evaluated from the ORIGINAL entry
            // before any combined-average trailing calculations.
            TryAdaptivePartialProfitPlan(
                currentPrice
            );

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            // Phase 3 Reversal Guard may protect a winning trade before the
            // normal BE trigger. Do not return until it also has too little
            // favorable excursion for reversal protection.
            if (
                favorableTicks < localBreakEvenTriggerTicks &&
                favorableTicks < ReversalGuardMinFavorableTicks
            )
            {
                return;
            }

            double pointValueForTradeIntelligence =
                instrument.MasterInstrument.PointValue;

            double currentTradePnlDollars = 0;

            if (
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double favorablePoints =
                    favorableTicks * tickSize;

                currentTradePnlDollars =
                    favorablePoints *
                    pointValueForTradeIntelligence *
                    localEntryQuantity;
            }

            double peakFavorableTicks;

            lock (executionStateLock)
            {
                if (
                    entryMarketPosition == localMarketPosition &&
                    entryFillPrice > 0
                )
                {
                    activeTradePeakFavorableTicks =
                        Math.Max(
                            activeTradePeakFavorableTicks,
                            Math.Max(0, favorableTicks)
                        );
                }

                peakFavorableTicks = activeTradePeakFavorableTicks;
            }

            int sideMomentumScore =
                localMarketPosition == MarketPosition.Long
                    ? localRangeLongScore
                    : localRangeShortScore;

            int oppositeMomentumScoreForHold =
                localMarketPosition == MarketPosition.Long
                    ? localRangeShortScore
                    : localRangeLongScore;

            // Reset Expansion Hold state exactly once for each new trade.
            if (localTradeEntryUtc != expansionHoldTradeEntryUtc)
            {
                expansionHoldTradeEntryUtc =
                    localTradeEntryUtc;

                expansionHoldLastConfirmedUtc =
                    DateTime.MinValue;

                expansionHoldQualified =
                    false;

                lastExpansionHoldActive =
                    false;

                lastExpansionHoldSupportScore =
                    0;

                expansionHoldQualificationMode =
                    "NONE";
            }

            // V2: snapshot L2 for CONTINUOUS confirmation only.
            // It is evidence for trade management, never entry authority.
            bool expansionL2Ready = false;
            int expansionSameSidePersistence = 0;
            int expansionOppositePersistence = 0;
            double expansionSignedTapeDelta = 0;
            string expansionAbsorption = "NONE";

            lock (level2Sync)
            {
                expansionL2Ready =
                    level2ObserveActive &&
                    level2BookReady;

                expansionAbsorption =
                    level2Absorption ?? "NONE";

                if (localMarketPosition == MarketPosition.Long)
                {
                    expansionSameSidePersistence =
                        level2LongPersistence;

                    expansionOppositePersistence =
                        level2ShortPersistence;

                    expansionSignedTapeDelta =
                        level2TapeDelta;
                }
                else
                {
                    expansionSameSidePersistence =
                        level2ShortPersistence;

                    expansionOppositePersistence =
                        level2LongPersistence;

                    expansionSignedTapeDelta =
                        -level2TapeDelta;
                }
            }

            bool expansionOppositeAbsorption =
                localMarketPosition == MarketPosition.Long
                    ? (
                        string.Equals(
                            expansionAbsorption,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            expansionAbsorption,
                            "SELL ABSORPTION CONFIRMED",
                            StringComparison.OrdinalIgnoreCase
                        )
                      )
                    : (
                        string.Equals(
                            expansionAbsorption,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            expansionAbsorption,
                            "BUY ABSORPTION CONFIRMED",
                            StringComparison.OrdinalIgnoreCase
                        )
                      );

            bool expansionL2Support =
                expansionL2Ready &&
                expansionSameSidePersistence >= ExpansionHoldL2Persistence &&
                expansionSignedTapeDelta >= 0 &&
                !expansionOppositeAbsorption;

            int expansionSupportScore = 0;

            if (sideMomentumScore >= ExpansionHoldMinMomentumScore)
                expansionSupportScore++;

            if (localSideBreakout)
                expansionSupportScore++;

            if (localRangeVolumeRatio >= ExpansionHoldMinVolumeRatio)
                expansionSupportScore++;

            if (expansionL2Support)
                expansionSupportScore++;

            bool breakoutExpansionQualification =
                sideMomentumScore >= ExpansionHoldMinMomentumScore &&
                localSideBreakout &&
                localRangeVolumeRatio >= ExpansionHoldMinVolumeRatio;

            // V2.1 ORIGIN EXPANSION: a strong move can start from a session /
            // structural low or high and travel materially BEFORE a formal
            // breakout prints. Because this method runs only after a position
            // already exists, this path affects management only.
            bool originExpansionQualification =
                sideMomentumScore >= ExpansionHoldMinMomentumScore &&
                !localSideBreakout &&
                localRangeVolumeRatio >= ExpansionHoldOriginMinVolumeRatio &&
                expansionL2Support &&
                favorableTicks >= ExpansionHoldOriginMinFavorableTicks;

            bool expansionQualificationNow =
                breakoutExpansionQualification ||
                originExpansionQualification;

            DateTime expansionNowUtc =
                DateTime.UtcNow;

            if (!expansionHoldQualified && expansionQualificationNow)
            {
                expansionHoldQualified =
                    true;

                expansionHoldQualificationMode =
                    breakoutExpansionQualification
                        ? "BREAKOUT"
                        : "ORIGIN";

                expansionHoldLastConfirmedUtc =
                    expansionNowUtc;

                PrintBotMessage(
                    "EXPANSION HOLD QUALIFIED"
                    + " | Mode: " + expansionHoldQualificationMode
                    + " | Side: " + localMarketPosition
                    + " | R20: " + sideMomentumScore + "/5"
                    + " | Breakout: " + localSideBreakout
                    + " | Volume x" + localRangeVolumeRatio.ToString("0.00")
                    + " | Progress: " + favorableTicks.ToString("0") + "t"
                    + " | L2: " + (expansionL2Support ? "SUPPORT" : "NOT REQUIRED")
                    + " | Support: " + expansionSupportScore + "/4"
                    + " | Objective: " + ExpansionHoldObjectiveTicks + "t"
                );
            }

            // Fresh confirmation extends the hold. We intentionally require
            // 3/4 evidence so one isolated L2 or R20 snapshot cannot keep a
            // weak expansion alive indefinitely.
            if (
                expansionHoldQualified &&
                expansionSupportScore >= ExpansionHoldRefreshMinSupportScore
            )
            {
                expansionHoldLastConfirmedUtc =
                    expansionNowUtc;
            }

            double expansionConfirmationAgeSeconds =
                expansionHoldLastConfirmedUtc != DateTime.MinValue
                    ? Math.Max(
                        0,
                        (expansionNowUtc - expansionHoldLastConfirmedUtc)
                            .TotalSeconds
                      )
                    : double.MaxValue;

            double expansionGivebackTicks =
                Math.Max(
                    0,
                    peakFavorableTicks - favorableTicks
                );

            bool expansionHardMomentumFailure =
                sideMomentumScore <= ExpansionHoldReleaseSameSideScore &&
                oppositeMomentumScoreForHold >= ExpansionHoldReleaseOppositeScore;

            bool expansionOppositeMicroFailure =
                expansionL2Ready &&
                expansionOppositePersistence >= ExpansionHoldL2Persistence &&
                expansionSignedTapeDelta < 0 &&
                expansionOppositeAbsorption;

            bool expansionStaleFailure =
                expansionConfirmationAgeSeconds >= ExpansionHoldConfirmationGraceSeconds &&
                expansionSupportScore <= ExpansionHoldWeakSupportScore &&
                expansionGivebackTicks >= ExpansionHoldMinGivebackTicksForStaleRelease;

            bool expansionMaterialFailure =
                expansionHardMomentumFailure ||
                expansionOppositeMicroFailure ||
                expansionStaleFailure;

            // V1.6.89 - Global breathing room applies to every managed trade,
            // not only Expansion Hold trades. It defers aggressive lock/trail
            // layers until the trade has developed ~20 points of peak MFE,
            // unless a hard opposite reversal is confirmed. Intraday floating
            // floors below can still override this and protect meaningful PnL.
            bool globalBreathingRoomActive =
                peakFavorableTicks < TradeBreathingRoomPeakTicks &&
                !expansionHardMomentumFailure &&
                !expansionOppositeMicroFailure;

            bool expansionHoldActive =
                expansionHoldQualified &&
                peakFavorableTicks < ExpansionHoldObjectiveTicks &&
                !expansionMaterialFailure;

            if (
                expansionHoldActive != lastExpansionHoldActive ||
                (
                    expansionHoldActive &&
                    expansionSupportScore != lastExpansionHoldSupportScore
                )
            )
            {
                bool activeStateChanged =
                    expansionHoldActive != lastExpansionHoldActive;

                lastExpansionHoldActive =
                    expansionHoldActive;

                lastExpansionHoldSupportScore =
                    expansionSupportScore;

                if (activeStateChanged)
                {
                    PrintBotMessage(
                        expansionHoldActive
                            ? (
                                "EXPANSION HOLD ACTIVE"
                                + " | Mode: " + expansionHoldQualificationMode
                                + " | Side: " + localMarketPosition
                                + " | R20: " + sideMomentumScore + "/5"
                                + " | Opp: " + oppositeMomentumScoreForHold + "/5"
                                + " | Support: " + expansionSupportScore + "/4"
                                + " | L2Persist Same/Opp: "
                                + expansionSameSidePersistence + "/"
                                + expansionOppositePersistence
                                + " | Tape: " + expansionSignedTapeDelta.ToString("0")
                                + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                                + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                                + " | Management: BE ONLY / RETENTION DEFERRED"
                              )
                            : (
                                "EXPANSION HOLD RELEASED"
                                + " | Mode: " + expansionHoldQualificationMode
                                + " | Side: " + localMarketPosition
                                + " | R20: " + sideMomentumScore + "/5"
                                + " | Opp: " + oppositeMomentumScoreForHold + "/5"
                                + " | Support: " + expansionSupportScore + "/4"
                                + " | ConfirmAge: "
                                + expansionConfirmationAgeSeconds.ToString("0.0") + "s"
                                + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                                + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                                + " | Reason: "
                                + (
                                    peakFavorableTicks >= ExpansionHoldObjectiveTicks
                                        ? "20PT OBJECTIVE REACHED"
                                        : expansionHardMomentumFailure
                                            ? "HARD MOMENTUM REVERSAL"
                                            : expansionOppositeMicroFailure
                                                ? "OPPOSITE MICROSTRUCTURE CONFIRMED"
                                                : expansionStaleFailure
                                                    ? "CONFIRMATION STALE + GIVEBACK"
                                                    : "NO LONGER QUALIFIED"
                                  )
                                + " | Action: NORMAL MANAGEMENT RESUMED"
                              )
                    );
                }
                else
                {
                    PrintBotMessage(
                        "EXPANSION HOLD CONFIRMATION"
                        + " | Mode: " + expansionHoldQualificationMode
                        + " | Side: " + localMarketPosition
                        + " | Support: " + expansionSupportScore + "/4"
                        + " | R20: " + sideMomentumScore + "/5"
                        + " | Breakout: " + localSideBreakout
                        + " | Volume x" + localRangeVolumeRatio.ToString("0.00")
                        + " | L2: " + (expansionL2Support ? "SUPPORT" : "MIXED")
                        + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                        + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                    );
                }
            }

            // V1.7.05 - Mission pace may tighten protection and recalculate the
            // expected minimum per trade, but it may NOT move the user's TP.
            // TryUpdateMissionModeTarget intentionally not called.

            double desiredStop =
                localActiveStopPrice;

            int desiredStage =
                localMomentumStage;

            // LEGACY STAGES 1-4 (disabled in V1.7.06).
            // Kept in source for rollback/reference only. Winner management now
            // belongs to Floating Capital % + contextual reversal protection.
            // Stage 1: legacy profit-protected break-even.
            if (
                false && // V1.7.06: legacy fixed-tick winner stage disabled
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                desiredStop =
                    (expansionHoldActive || globalBreathingRoomActive)
                        ? localEntryFillPrice
                        : (
                            localMarketPosition ==
                                MarketPosition.Long
                                ? localEntryFillPrice
                                    + MomentumFirstProtectionProfitTicks
                                    * tickSize
                                : localEntryFillPrice
                                    - MomentumFirstProtectionProfitTicks
                                    * tickSize
                          );

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                false && // V1.7.06: legacy fixed-tick winner stage disabled
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Second staged profit lock
            if (
                false && // V1.7.06: legacy fixed-tick winner stage disabled
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumLock2TriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLock2ProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLock2ProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        3
                    );
            }

            // Stage 4: Dynamic trailing
            if (
                false && // V1.7.06: legacy fixed-tick trailing disabled
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    desiredStop =
                        Math.Max(
                            desiredStop,
                            trailCandidate
                        );
                }
                else
                {
                    desiredStop =
                        Math.Min(
                            desiredStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    4;
            }

            // V1.6.23 Phase 2 - Profit Retention Manager.
            // Once a trade has produced meaningful MFE, protect a fraction
            // of the PEAK open PnL. This complements the fixed-tick stages
            // and is especially useful when a dynamic target is below the
            // +180t trailing trigger. Never-worsen below guarantees this
            // layer cannot loosen an existing stop.
            int desiredRetentionStage =
                localProfitRetentionStage;

            double desiredRetentionFactor = 0;

            // V1.6.91 - HARD PROFIT RETENTION FLOOR.
            // Once retention computes a profitable floor, live-price safety
            // is NOT allowed to silently clamp that stop back below the
            // retained-profit level. If the market has already crossed the
            // required floor before Ninja can accept the stop change, flatten
            // the position instead of converting Profit Retention into a loss.
            bool retentionHardFloorArmed = false;
            double retentionHardFloorStop = 0;
            double retentionHardFloorDollars = 0;

            bool intradayDrawdownMode =
                string.Equals(
                    activeDrawdownMode,
                    "INTRADAY",
                    StringComparison.OrdinalIgnoreCase
                );

            double tradeAgeSeconds =
                localTradeEntryUtc != DateTime.MinValue
                    ? Math.Max(0, (DateTime.UtcNow - localTradeEntryUtc).TotalSeconds)
                    : double.MaxValue;

            // V1.6.90 - MFE-BASED RETENTION AUTHORITY.
            // Do not make fast winners wait on a wall-clock timer. Stage 1/2/3
            // and Giveback may protect as soon as meaningful peak MFE exists.
            // Fixed momentum PROTECT/LOCK/LOCK2/TRAIL logic remains live and
            // Never-Worsen still guarantees the strongest stop wins.
            bool globalRetentionGraceComplete =
                false; // V1.7.06: legacy R/tick retention + giveback disabled.
                       // Floating Capital Management is the winner authority.

            double retentionStage1TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage1TriggerR
                    : ProfitRetentionStage1TriggerR;
            double retentionStage1Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage1Factor
                    : ProfitRetentionStage1Factor;
            double retentionStage2TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage2TriggerR
                    : ProfitRetentionStage2TriggerR;
            double retentionStage2Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage2Factor
                    : ProfitRetentionStage2Factor;
            double retentionStage3TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage3TriggerR
                    : ProfitRetentionStage3TriggerR;
            double retentionStage3Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage3Factor
                    : ProfitRetentionStage3Factor;

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0
            )
            {
                double peakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                bool globalRetentionEligible =
                    globalRetentionGraceComplete &&
                    peakR >= GlobalProfitRetentionMinPeakR;

                if (!globalRetentionEligible)
                {
                    string deferredKey =
                        Math.Floor(tradeAgeSeconds / 5.0).ToString("0")
                        + "|" + Math.Floor(peakR * 10.0).ToString("0");

                    if (
                        deferredKey != lastGlobalRetentionDeferredLogKey ||
                        (DateTime.UtcNow - lastGlobalRetentionDeferredLogUtc).TotalSeconds >= 5.0
                    )
                    {
                        lastGlobalRetentionDeferredLogKey = deferredKey;
                        lastGlobalRetentionDeferredLogUtc = DateTime.UtcNow;

                        PrintBotMessage(
                            "PROFIT RETENTION DEFERRED"
                            + " | Age: " + tradeAgeSeconds.ToString("0.0") + "s"
                            + " | PeakR: " + peakR.ToString("0.00")
                            + " | Need: PeakR >= "
                            + GlobalProfitRetentionMinPeakR.ToString("0.00") + "R"
                            + " | Mode: MFE-BASED"
                        );
                    }
                }

                if (globalRetentionEligible && peakR >= retentionStage3TriggerR)
                {
                    desiredRetentionStage = 3;
                    desiredRetentionFactor = retentionStage3Factor;
                }
                else if (globalRetentionEligible && peakR >= retentionStage2TriggerR)
                {
                    desiredRetentionStage = 2;
                    desiredRetentionFactor = retentionStage2Factor;
                }
                else if (globalRetentionEligible && peakR >= retentionStage1TriggerR)
                {
                    desiredRetentionStage = 1;
                    desiredRetentionFactor = retentionStage1Factor;
                }

                if (desiredRetentionFactor > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars *
                        desiredRetentionFactor;

                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double retentionStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        retentionStop =
                            RoundToInstrumentTick(retentionStop);

                        retentionHardFloorArmed = true;
                        retentionHardFloorStop = retentionStop;
                        retentionHardFloorDollars = protectedDollars;

                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, retentionStop);
                        else
                            desiredStop = Math.Min(desiredStop, retentionStop);
                    }
                }
            }

            // =====================================================
            // RECOVERY V4 - NEAR-TARGET PROFIT PROTECTION
            // =====================================================
            // Uses PEAK progress toward the live TP so protection remains
            // armed even if price begins to retrace.
            //
            // Example:
            // 100t TP -> activates from 95t peak progress.
            // At activation, protects ~90% of peak MFE with the EXISTING
            // protective stop. It does not move TP or market-close.
            //
            // Stable Never-Worsen / protective-stop handling remains authority.
            if (
                localActiveTargetPrice > 0 &&
                localPeakPnlDollars > 0 &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                tickSize > 0
            )
            {
                double liveTargetDistanceTicks =
                    Math.Abs(
                        localActiveTargetPrice -
                        localEntryFillPrice
                    ) / tickSize;

                if (
                    liveTargetDistanceTicks >=
                        NearTargetMinTargetTicks &&
                    peakFavorableTicks >=
                        liveTargetDistanceTicks *
                        NearTargetActivationFactor
                )
                {
                    double nearTargetProtectedDollars =
                        localPeakPnlDollars *
                        NearTargetRetentionFactor;

                    double nearTargetProtectedPoints =
                        nearTargetProtectedDollars /
                        (
                            pointValueForTradeIntelligence *
                            localEntryQuantity
                        );

                    double nearTargetStop =
                        localMarketPosition ==
                            MarketPosition.Long
                            ? localEntryFillPrice +
                              nearTargetProtectedPoints
                            : localEntryFillPrice -
                              nearTargetProtectedPoints;

                    nearTargetStop =
                        RoundToInstrumentTick(
                            nearTargetStop
                        );

                    if (
                        localMarketPosition ==
                            MarketPosition.Long
                    )
                    {
                        desiredStop =
                            Math.Max(
                                desiredStop,
                                nearTargetStop
                            );
                    }
                    else
                    {
                        desiredStop =
                            Math.Min(
                                desiredStop,
                                nearTargetStop
                            );
                    }

                    double targetProgress =
                        liveTargetDistanceTicks > 0
                            ? peakFavorableTicks /
                              liveTargetDistanceTicks
                            : 0;

                    string nearTargetLogKey =
                        localMarketPosition
                        + "|"
                        + localActiveTargetPrice.ToString(
                            "0.00"
                          )
                        + "|"
                        + Math.Floor(
                            targetProgress * 100.0
                          ).ToString("0")
                        + "|"
                        + nearTargetStop.ToString("0.00");

                    DateTime nearTargetNowUtc =
                        DateTime.UtcNow;

                    if (
                        !string.Equals(
                            nearTargetLogKey,
                            lastNearTargetProtectionLogKey,
                            StringComparison.Ordinal
                        ) ||
                        lastNearTargetProtectionLogUtc ==
                            DateTime.MinValue ||
                        (
                            nearTargetNowUtc -
                            lastNearTargetProtectionLogUtc
                        ).TotalMilliseconds >=
                            NearTargetProtectionLogThrottleMs
                    )
                    {
                        lastNearTargetProtectionLogKey =
                            nearTargetLogKey;

                        lastNearTargetProtectionLogUtc =
                            nearTargetNowUtc;

                        PrintBotMessage(
                            "NEAR TARGET PROTECTION"
                            + " | Progress: "
                            + (
                                targetProgress * 100.0
                              ).ToString("0.0")
                            + "%"
                            + " | Peak: "
                            + localPeakPnlDollars.ToString(
                                "$0.00"
                              )
                            + " | Retain: "
                            + (
                                NearTargetRetentionFactor *
                                100.0
                              ).ToString("0")
                            + "%"
                            + " | Target: "
                            + localActiveTargetPrice.ToString(
                                "0.00"
                              )
                            + " | StopProposal: "
                            + nearTargetStop.ToString("0.00")
                            + " | Authority: STABLE PROTECTIVE STOP"
                        );
                    }
                }
            }

            // =====================================================
            // V1.6.70 - DAILY TARGET PRE-SECURE
            // =====================================================
            // Once the current trade carries the day to >=90% of the daily
            // objective, use the existing protective stop to preserve at
            // least 80% of that objective whenever the market allows it.
            // The hard DAILY TARGET flatten remains unchanged at 100%.
            if (
                localDailyTarget > 0 &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                currentTradePnlDollars > 0
            )
            {
                double currentDayTotal =
                    localBotDailyPnL +
                    currentTradePnlDollars;

                double preSecureActivation =
                    localDailyTarget *
                    DailyTargetPreSecureActivationFactor;

                if (
                    currentDayTotal >= preSecureActivation &&
                    currentDayTotal < localDailyTarget
                )
                {
                    double desiredProtectedDay =
                        localDailyTarget *
                        DailyTargetPreSecureRetentionFactor;

                    double requiredOpenProfit =
                        Math.Max(
                            0,
                            desiredProtectedDay -
                            localBotDailyPnL
                        );

                    if (requiredOpenProfit > 0)
                    {
                        double protectedPoints =
                            requiredOpenProfit /
                            (
                                pointValueForTradeIntelligence *
                                localEntryQuantity
                            );

                        double targetSecureStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, targetSecureStop);
                        else
                            desiredStop = Math.Min(desiredStop, targetSecureStop);
                    }
                }
            }

            // =====================================================
            // V1.6.23 Phase 9 - PROFIT GIVEBACK GUARD
            // =====================================================
            // Profit Retention tiers protect progressively larger peaks.
            // This extra layer reacts to the PATH of the trade: if a trade
            // already produced useful MFE but starts returning too much of
            // that peak, protect a conservative fraction before a full
            // reversal develops. It never loosens an existing stop.
            bool givebackGuardApplied = false;
            double givebackPercent = 0;
            double givebackPeakR = 0;
            double adaptiveGivebackTrigger =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardTriggerPercent
                    : ProfitGivebackGuardTriggerPercent;
            double adaptiveGivebackRetention =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardRetentionFactor
                    : ProfitGivebackGuardRetentionFactor;
            double activeGivebackMinPeakR =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardMinPeakR
                    : ProfitGivebackGuardMinPeakR;
            string adaptiveGivebackMode = "BASE";

            // Snapshot Level 2 once for this management pass.
            // Same-side flow gets more breathing room; opposite flow tightens
            // protection sooner. L2 never loosens an already protected stop.
            bool l2ReadySnapshot = false;
            int sameSidePersistenceSnapshot = 0;
            int oppositePersistenceSnapshot = 0;
            double tapeDeltaSnapshot = 0;
            string absorptionSnapshot = "NONE";

            lock (level2Sync)
            {
                l2ReadySnapshot =
                    level2ObserveActive &&
                    level2BookReady;

                tapeDeltaSnapshot =
                    level2TapeDelta;

                absorptionSnapshot =
                    level2Absorption;

                if (localMarketPosition == MarketPosition.Long)
                {
                    sameSidePersistenceSnapshot = level2LongPersistence;
                    oppositePersistenceSnapshot = level2ShortPersistence;
                }
                else
                {
                    sameSidePersistenceSnapshot = level2ShortPersistence;
                    oppositePersistenceSnapshot = level2LongPersistence;
                }
            }

            if (l2ReadySnapshot)
            {
                double signedTapeDelta =
                    localMarketPosition == MarketPosition.Long
                        ? tapeDeltaSnapshot
                        : -tapeDeltaSnapshot;

                bool sameSideAbsorptionRisk =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool oppositeAbsorptionSignal =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool strongSameSideL2 =
                    sameSidePersistenceSnapshot >=
                        ProfitGivebackL2SupportPersistence &&
                    signedTapeDelta >=
                        ProfitGivebackL2MinDelta &&
                    !sameSideAbsorptionRisk;

                bool strongOppositeL2 =
                    oppositePersistenceSnapshot >=
                        ProfitGivebackL2OppositePersistence ||
                    signedTapeDelta <=
                        -ProfitGivebackL2MinDelta ||
                    oppositeAbsorptionSignal;

                bool counterTrendContext =
                    localMarketPosition == MarketPosition.Long
                        ? (
                            localM5BearishTrend &&
                            localHtfShortScore > localHtfLongScore
                          )
                        : (
                            localM5BullishTrend &&
                            localHtfLongScore > localHtfShortScore
                          );

                if (strongOppositeL2)
                {
                    adaptiveGivebackMode = "L2 OPPOSITE";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2OppositeTriggerPercent
                            : ProfitGivebackL2OppositeTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2OppositeRetentionFactor
                            : ProfitGivebackL2OppositeRetentionFactor;
                }
                else if (counterTrendContext)
                {
                    adaptiveGivebackMode = "COUNTERTREND DEFENSE";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayCounterTrendGivebackTriggerPercent
                            : CounterTrendGivebackTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayCounterTrendGivebackRetentionFactor
                            : CounterTrendGivebackRetentionFactor;
                }
                else if (strongSameSideL2)
                {
                    adaptiveGivebackMode = "L2 SUPPORT";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2SupportTriggerPercent
                            : ProfitGivebackL2SupportTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2SupportRetentionFactor
                            : ProfitGivebackL2SupportRetentionFactor;
                }
            }

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0 &&
                currentTradePnlDollars > 0
            )
            {
                givebackPeakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                double givebackDollars =
                    Math.Max(
                        0,
                        localPeakPnlDollars -
                        currentTradePnlDollars
                    );

                givebackPercent =
                    localPeakPnlDollars > 0
                        ? givebackDollars / localPeakPnlDollars
                        : 0;

                bool globalGivebackEligible =
                    globalRetentionGraceComplete &&
                    givebackPeakR >= GlobalProfitRetentionMinPeakR;

                if (
                    globalGivebackEligible &&
                    givebackPeakR >= activeGivebackMinPeakR &&
                    givebackPercent >= adaptiveGivebackTrigger
                )
                {
                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedDollars =
                            localPeakPnlDollars *
                            adaptiveGivebackRetention;

                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double givebackStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        // Keep StopMarket on the valid side of current market.
                        if (localMarketPosition == MarketPosition.Long)
                            givebackStop = Math.Min(givebackStop, currentPrice - tickSize);
                        else
                            givebackStop = Math.Max(givebackStop, currentPrice + tickSize);

                        givebackStop =
                            RoundToInstrumentTick(givebackStop);

                        bool improvesCurrentStop =
                            localMarketPosition == MarketPosition.Long
                                ? givebackStop > localActiveStopPrice
                                : givebackStop < localActiveStopPrice;

                        if (improvesCurrentStop)
                        {
                            if (localMarketPosition == MarketPosition.Long)
                                desiredStop = Math.Max(desiredStop, givebackStop);
                            else
                                desiredStop = Math.Min(desiredStop, givebackStop);

                            givebackGuardApplied = true;
                        }
                    }
                }
            }

            // =====================================================
            // V1.6.92 - FLOATING PROFIT FLOOR / POST-SCALE FLOOR
            // =====================================================
            // INTRADAY: preserve the staged peak-PnL floor, with at least 65%
            // retained after Smart Scale-In once peak PnL reaches $120.
            // EOD: keep normal breathing room, but after Smart Scale-In do not
            // allow the enlarged position to surrender the entire favorable
            // excursion; preserve at least 60% of peak once peak >= $120.
            if (
                false && // V1.7.06: legacy fixed-dollar staged floor disabled
                localPeakPnlDollars >= IntradayFloorStage1PeakDollars &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double activeFloatingFloorFactor = 0;

                if (intradayDrawdownMode)
                {
                    activeFloatingFloorFactor =
                        localPeakPnlDollars >= IntradayFloorStage5PeakDollars
                            ? IntradayFloorStage5Factor
                            : localPeakPnlDollars >= IntradayFloorStage4PeakDollars
                                ? IntradayFloorStage4Factor
                                : localPeakPnlDollars >= IntradayFloorStage3PeakDollars
                                    ? IntradayFloorStage3Factor
                                    : localPeakPnlDollars >= IntradayFloorStage2PeakDollars
                                        ? IntradayFloorStage2Factor
                                        : IntradayFloorStage1Factor;

                    if (localSmartScaleInUsed)
                        activeFloatingFloorFactor = Math.Max(activeFloatingFloorFactor, PostScaleMinimumFloorFactor);
                }
                // EOD does not use this legacy staged dollar floor.
                // V1.7.06 floating-capital retention below is the common EOD/INTRADAY
                // winner authority; combined-BE and NeverWorsen remain safety layers.

                if (activeFloatingFloorFactor > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars * activeFloatingFloorFactor;

                    double protectedPoints =
                        protectedDollars /
                        (pointValueForTradeIntelligence * localEntryQuantity);

                    double floatingFloorStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + protectedPoints
                            : localEntryFillPrice - protectedPoints;

                    if (localMarketPosition == MarketPosition.Long)
                        floatingFloorStop = Math.Min(floatingFloorStop, currentPrice - tickSize);
                    else
                        floatingFloorStop = Math.Max(floatingFloorStop, currentPrice + tickSize);

                    floatingFloorStop = RoundToInstrumentTick(floatingFloorStop);

                    if (localMarketPosition == MarketPosition.Long)
                        desiredStop = Math.Max(desiredStop, floatingFloorStop);
                    else
                        desiredStop = Math.Min(desiredStop, floatingFloorStop);
                }
            }

            // =====================================================
            // V1.6.92 - SESSION-ADAPTIVE POST-SCALE BREATHING ROOM
            // =====================================================
            // This is management-only. It does not grant Scale-In eligibility,
            // alter entries or increase risk. It only prevents NEW post-scale
            // stop improvements from becoming too close to live price because
            // a dollar/percentage floor compresses when quantity is large.
            //
            // Daily Target Pre-Secure and material opposite reversal retain
            // authority and may tighten more aggressively. Never-worsen below
            // guarantees this layer never moves an already-protected stop back.
            if (
                localSmartScaleInUsed &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                currentTradePnlDollars > 0
            )
            {
                bool m5ContinuationAligned =
                    localMarketPosition == MarketPosition.Long
                        ? (localM5BullishTrend && localM5AboveVwap)
                        : (localM5BearishTrend && localM5BelowVwap);

                int currentHtfScore =
                    localMarketPosition == MarketPosition.Long
                        ? localHtfLongScore
                        : localHtfShortScore;

                bool strongContinuation =
                    sideMomentumScore >= 4 &&
                    currentHtfScore >= 1 &&
                    m5ContinuationAligned &&
                    (
                        localSideBreakout ||
                        localRangeVolumeRatio >= MissionModeMinVolumeRatio
                    ) &&
                    !expansionHardMomentumFailure &&
                    !expansionOppositeMicroFailure;

                bool exceptionalContinuation =
                    strongContinuation &&
                    localSideBreakout &&
                    localRangeVolumeRatio >= 1.50 &&
                    expansionL2Support;

                bool weakContinuation =
                    sideMomentumScore <= 2 ||
                    !m5ContinuationAligned ||
                    expansionSupportScore <= 1;

                string adaptiveSessionName;
                double adaptiveRoomPoints =
                    GetSessionAdaptivePostScaleBreathingRoomPoints(
                        strongContinuation,
                        exceptionalContinuation,
                        weakContinuation,
                        out adaptiveSessionName
                    );

                double currentDayTotalForAdaptive =
                    localBotDailyPnL + currentTradePnlDollars;

                bool dailyPreSecureOwns =
                    localDailyTarget > 0 &&
                    currentDayTotalForAdaptive >=
                        localDailyTarget * DailyTargetPreSecureActivationFactor;

                bool materialReversalOwns =
                    expansionHardMomentumFailure ||
                    expansionOppositeMicroFailure;

                if (!dailyPreSecureOwns && !materialReversalOwns)
                {
                    double adaptiveBoundary =
                        localMarketPosition == MarketPosition.Long
                            ? currentPrice - adaptiveRoomPoints
                            : currentPrice + adaptiveRoomPoints;

                    adaptiveBoundary =
                        RoundToInstrumentTick(adaptiveBoundary);

                    if (localMarketPosition == MarketPosition.Long)
                        desiredStop = Math.Min(desiredStop, adaptiveBoundary);
                    else
                        desiredStop = Math.Max(desiredStop, adaptiveBoundary);

                    string adaptiveLogKey =
                        adaptiveSessionName
                        + "|" + adaptiveRoomPoints.ToString("0.0")
                        + "|" + (strongContinuation ? "STRONG" : weakContinuation ? "WEAK" : "NORMAL")
                        + "|" + localEntryQuantity
                        + "|" + Math.Floor(currentTradePnlDollars / 25.0).ToString("0");

                    DateTime adaptiveNowUtc = DateTime.UtcNow;

                    if (
                        !string.Equals(
                            adaptiveLogKey,
                            lastAdaptiveBreathingLogKey,
                            StringComparison.Ordinal
                        ) ||
                        lastAdaptiveBreathingLogUtc == DateTime.MinValue ||
                        (adaptiveNowUtc - lastAdaptiveBreathingLogUtc).TotalSeconds >= 10.0
                    )
                    {
                        lastAdaptiveBreathingLogKey = adaptiveLogKey;
                        lastAdaptiveBreathingLogUtc = adaptiveNowUtc;

                        PrintBotMessage(
                            "SESSION ADAPTIVE BREATHING"
                            + " | Session: " + adaptiveSessionName
                            + " | Room: " + adaptiveRoomPoints.ToString("0.0") + "pt"
                            + " | Continuation: "
                            + (exceptionalContinuation ? "EXCEPTIONAL"
                                : strongContinuation ? "STRONG"
                                : weakContinuation ? "WEAK"
                                : "NORMAL")
                            + " | Qty: " + localEntryQuantity
                            + " | Peak: " + localPeakPnlDollars.ToString("$0.00")
                            + " | Open: " + currentTradePnlDollars.ToString("$0.00")
                            + " | Boundary: " + adaptiveBoundary.ToString("0.00")
                        );
                    }
                }
            }

            // =====================================================
            // V1.7.06 - FLOATING CAPITAL MANAGEMENT + DAILY PACE
            // =====================================================
            // PRIMARY AUTHORITY FOR WINNER MANAGEMENT:
            //   PeakFloatingPnL -> Retention% -> Giveback% -> adaptive floor.
            //
            // Daily Target / ExpectedMinimumPerTrade remains a PACE calculation.
            // Reaching the expected minimum does NOT close the trade and does NOT
            // move the user's TP. It only adds a modest retention boost.
            int remainingTradesIncludingCurrent = 1;
            double remainingTargetDollars = 0;
            double expectedMinimumPerTrade = 0;

            if (localDailyTarget > 0)
            {
                expectedMinimumPerTrade =
                    GetExpectedMinimumPerTrade(
                        localBotDailyPnL,
                        localDailyTarget,
                        out remainingTradesIncludingCurrent,
                        out remainingTargetDollars
                    );
            }

            double currentDayTotalForProtection =
                localBotDailyPnL +
                Math.Max(0, currentTradePnlDollars);

            bool minimumTradeObjectiveReached =
                expectedMinimumPerTrade > 0 &&
                currentTradePnlDollars >= expectedMinimumPerTrade;

            bool dailyThirtyPercentProtection =
                localDailyTarget > 0 &&
                currentDayTotalForProtection >=
                    localDailyTarget * DailyTargetProgressProtectionFactor;

            if (minimumTradeObjectiveReached)
            {
                string minimumReachedKey =
                    localTradeEntryUtc.Ticks + "|" +
                    Math.Round(expectedMinimumPerTrade, 2).ToString("0.00");

                if (minimumReachedKey != lastMinimumObjectiveLogKey)
                {
                    lastMinimumObjectiveLogKey = minimumReachedKey;
                    PrintBotMessage(
                        "MINIMUM TRADE OBJECTIVE REACHED"
                        + " | OpenPnL: " + currentTradePnlDollars.ToString("$0.00")
                        + " | MinimumExpected: " + expectedMinimumPerTrade.ToString("$0.00")
                        + " | Action: RETENTION BOOST / KEEP USER TP"
                    );
                }
            }

            if (dailyThirtyPercentProtection)
            {
                string dailyThirtyKey =
                    localTradeEntryUtc.Ticks + "|" +
                    Math.Round(currentDayTotalForProtection, 2).ToString("0.00");

                if (lastDailyThirtyProtectionLogKey.Length == 0 ||
                    !lastDailyThirtyProtectionLogKey.StartsWith(localTradeEntryUtc.Ticks + "|", StringComparison.Ordinal))
                {
                    lastDailyThirtyProtectionLogKey = dailyThirtyKey;
                    PrintBotMessage(
                        "DAILY TARGET 30% PROTECTION ARMED"
                        + " | DayWithOpen: " + currentDayTotalForProtection.ToString("$0.00")
                        + " | Threshold: "
                        + (localDailyTarget * DailyTargetProgressProtectionFactor).ToString("$0.00")
                        + " | DailyTarget: " + localDailyTarget.ToString("$0.00")
                        + " | Action: RETENTION BOOST / KEEP USER TP"
                    );
                }
            }

            string managementMode =
                intradayDrawdownMode
                    ? "INTRADAY/TRAILING"
                    : "EOD";

            string managementModeKey =
                managementMode + "|" + localTradeEntryUtc.Ticks;

            if (managementModeKey != lastTradeManagementModeLogKey)
            {
                lastTradeManagementModeLogKey = managementModeKey;
                PrintBotMessage(
                    "TRADE MANAGEMENT MODE"
                    + " | " + managementMode
                    + " | EntryFocus: " + JjPrimaryObjectiveTicks + "t / 20pt"
                    + " | UserTP: " + activeTargetTicks + "t"
                    + " | StopAuthority: FLOATING CAPITAL %"
                );
            }

            if (localDailyTarget > 0 && expectedMinimumPerTrade > 0)
            {
                string expectedKey =
                    localTradeEntryUtc.Ticks + "|" +
                    remainingTradesIncludingCurrent + "|" +
                    Math.Round(expectedMinimumPerTrade, 2).ToString("0.00");

                if (expectedKey != lastExpectedMinimumTradeLogKey)
                {
                    lastExpectedMinimumTradeLogKey = expectedKey;
                    PrintBotMessage(
                        "EXPECTED MIN TRADE"
                        + " | DailyTarget: " + localDailyTarget.ToString("$0.00")
                        + " | Realized: " + localBotDailyPnL.ToString("$0.00")
                        + " | RemainingTarget: " + remainingTargetDollars.ToString("$0.00")
                        + " | RemainingTrades: " + remainingTradesIncludingCurrent
                        + " | MinimumExpected: " + expectedMinimumPerTrade.ToString("$0.00")
                    );
                }
            }

            // Context classification for floating-capital retention.
            bool floatingM5Aligned =
                localMarketPosition == MarketPosition.Long
                    ? (localM5BullishTrend && localM5AboveVwap)
                    : (localM5BearishTrend && localM5BelowVwap);

            bool floatingStrongExpansion =
                sideMomentumScore >= 4 &&
                expansionSupportScore >= 3 &&
                floatingM5Aligned &&
                !expansionHardMomentumFailure &&
                !expansionOppositeMicroFailure &&
                (
                    localSideBreakout ||
                    localRangeVolumeRatio >= MissionModeMinVolumeRatio ||
                    expansionL2Support
                );

            bool floatingWeakening =
                expansionHardMomentumFailure ||
                expansionOppositeMicroFailure ||
                sideMomentumScore <= 2 ||
                expansionSupportScore <= 1 ||
                !floatingM5Aligned;

            double targetProgressPct = 0;
            if (activeTargetTicks > 0)
            {
                if (adaptiveOriginalEntryPrice > 0 && tickSize > 0)
                {
                    double originalProgressTicks =
                        localMarketPosition == MarketPosition.Long
                            ? (currentPrice - adaptiveOriginalEntryPrice) / tickSize
                            : (adaptiveOriginalEntryPrice - currentPrice) / tickSize;

                    targetProgressPct =
                        Math.Max(0, originalProgressTicks / activeTargetTicks);
                }
                else
                {
                    targetProgressPct =
                        Math.Max(
                            0,
                            peakFavorableTicks / activeTargetTicks
                        );
                }
            }

            bool nearTargetCapitalMode =
                targetProgressPct >= NearTargetActivationFactor;

            double adaptiveRetentionFactor =
                floatingWeakening
                    ? FloatingRetentionWeakening
                    : floatingStrongExpansion
                        ? FloatingRetentionStrongExpansion
                        : FloatingRetentionNormal;

            if (nearTargetCapitalMode)
            {
                adaptiveRetentionFactor =
                    floatingWeakening
                        ? NearTargetWeakRetention
                        : floatingStrongExpansion
                            ? NearTargetStrongRetention
                            : NearTargetNormalRetention;
            }

            // Daily pace can tighten protection, but only modestly. It must not
            // erase the extra breathing room granted to a healthy NY expansion.
            if (minimumTradeObjectiveReached)
                adaptiveRetentionFactor += MinimumObjectiveRetentionBoost;

            if (dailyThirtyPercentProtection)
                adaptiveRetentionFactor += DailyProgressRetentionBoost;

            adaptiveRetentionFactor =
                Math.Min(
                    MaxAdaptiveFloatingRetention,
                    adaptiveRetentionFactor
                );

            double floatingRetentionPct =
                localPeakPnlDollars > 0
                    ? Math.Max(0, currentTradePnlDollars) / localPeakPnlDollars
                    : 0;

            double floatingGivebackPct =
                localPeakPnlDollars > 0
                    ? Math.Max(0, 1.0 - floatingRetentionPct)
                    : 0;

            double meaningfulPeakThreshold =
                expectedMinimumPerTrade > 0
                    ? Math.Max(
                        FloatingCapitalMinPeakDollars,
                        expectedMinimumPerTrade * 0.20
                      )
                    : FloatingCapitalMinPeakDollars;

            // V1.7.19 - TP1->TP2 SCALE WINDOW BREATHING.
            // Once TP1 is banked, the trade is already protected by BE.
            // While TP2 is still pending (+30t to +50t), do NOT let the normal
            // 72/82/90% Floating Capital retention map choke the position.
            // This window belongs to the adaptive Scale-In ladder. The hard floor
            // remains original BE before any add, then weighted Combined-BE after
            // a Scale-In fill. NeverWorsen and all market-side stop safety remain
            // authoritative. Normal Floating Capital resumes only after TP2 fills.
            bool adaptiveScaleBreathingWindow =
                adaptiveTp1Filled &&
                !adaptiveTp2Filled;

            bool floatingCapitalEligible =
                // Before TP1: original SL owns risk.
                // TP1->TP2: BE / Combined-BE owns protection and Scale gets room.
                // After TP2: normal Floating Capital retention may tighten again.
                adaptiveTp1Filled &&
                !adaptiveScaleBreathingWindow &&
                !localFloatingScaleNormalizeActive &&
                localPeakPnlDollars >= meaningfulPeakThreshold &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0;

            if (adaptiveScaleBreathingWindow && !localFloatingScaleNormalizeActive)
            {
                string breathingKey =
                    localTradeEntryUtc.Ticks + "|SCALE_BREATH|" + localEntryQuantity;

                DateTime breathingNowUtc = DateTime.UtcNow;

                if (
                    breathingKey != lastFloatingCapitalManagementLogKey ||
                    lastFloatingCapitalManagementLogUtc == DateTime.MinValue ||
                    (breathingNowUtc - lastFloatingCapitalManagementLogUtc).TotalSeconds >= 5.0
                )
                {
                    lastFloatingCapitalManagementLogKey = breathingKey;
                    lastFloatingCapitalManagementLogUtc = breathingNowUtc;

                    PrintBotMessage(
                        "SCALE WINDOW PROTECTION"
                        + " | TP1: BANKED"
                        + " | TP2: PENDING"
                        + " | FloatingCapital: DEFERRED"
                        + " | StopFloor: "
                        + (localSmartScaleInUsed ? "COMBINED-BE" : "BREAK-EVEN")
                        + " | ScaleWindow: 30-50t"
                        + " | MinimumTrade: " + (minimumTradeObjectiveReached ? "REACHED" : "NO")
                        + " | Action: LET TRADE BREATHE / SCALE IF CONTEXT SAFE"
                    );
                }
            }

            if (localFloatingScaleNormalizeActive)
            {
                string normalizeKey =
                    localTradeEntryUtc.Ticks + "|SYNC|" + localEntryQuantity;

                if (normalizeKey != lastFloatingCapitalManagementLogKey)
                {
                    lastFloatingCapitalManagementLogKey = normalizeKey;
                    lastFloatingCapitalManagementLogUtc = DateTime.UtcNow;

                    PrintBotMessage(
                        "FLOATING CAPITAL NORMALIZING AFTER SCALE"
                        + " | Qty: " + localEntryQuantity
                        + " | Peak: " + localPeakPnlDollars.ToString("$0.00")
                        + " | Open: " + currentTradePnlDollars.ToString("$0.00")
                        + " | NewFloatingTighten: PAUSED"
                        + " | CombinedBE: ACTIVE"
                        + " | NeverWorsen: ACTIVE"
                    );
                }
            }

            if (floatingCapitalEligible)
            {
                double protectedFloatingDollars =
                    localPeakPnlDollars * adaptiveRetentionFactor;

                double protectedFloatingPoints =
                    protectedFloatingDollars /
                    (pointValueForTradeIntelligence * localEntryQuantity);

                double floatingCapitalStop =
                    localMarketPosition == MarketPosition.Long
                        ? localEntryFillPrice + protectedFloatingPoints
                        : localEntryFillPrice - protectedFloatingPoints;

                floatingCapitalStop =
                    RoundToInstrumentTick(floatingCapitalStop);

                if (localMarketPosition == MarketPosition.Long)
                    desiredStop = Math.Max(desiredStop, floatingCapitalStop);
                else
                    desiredStop = Math.Min(desiredStop, floatingCapitalStop);

                string floatingContext =
                    floatingWeakening
                        ? "WEAKENING"
                        : floatingStrongExpansion
                            ? "STRONG_EXPANSION"
                            : "NORMAL";

                string floatingKey =
                    localTradeEntryUtc.Ticks + "|" +
                    floatingContext + "|" +
                    Math.Floor(targetProgressPct * 100.0).ToString("0") + "|" +
                    Math.Floor(adaptiveRetentionFactor * 100.0).ToString("0") + "|" +
                    Math.Floor(floatingRetentionPct * 100.0).ToString("0");

                DateTime floatingNowUtc = DateTime.UtcNow;

                if (
                    floatingKey != lastFloatingCapitalManagementLogKey ||
                    lastFloatingCapitalManagementLogUtc == DateTime.MinValue ||
                    (floatingNowUtc - lastFloatingCapitalManagementLogUtc).TotalSeconds >= 5.0
                )
                {
                    lastFloatingCapitalManagementLogKey = floatingKey;
                    lastFloatingCapitalManagementLogUtc = floatingNowUtc;

                    PrintBotMessage(
                        "FLOATING CAPITAL MANAGEMENT"
                        + " | Context: " + floatingContext
                        + " | Peak: " + localPeakPnlDollars.ToString("$0.00")
                        + " | Open: " + currentTradePnlDollars.ToString("$0.00")
                        + " | RetentionNow: " + (floatingRetentionPct * 100.0).ToString("0.0") + "%"
                        + " | Giveback: " + (floatingGivebackPct * 100.0).ToString("0.0") + "%"
                        + " | ProtectFloor: " + (adaptiveRetentionFactor * 100.0).ToString("0.0") + "%"
                        + " | TargetProgress: " + (targetProgressPct * 100.0).ToString("0.0") + "%"
                        + " | NearTarget: " + (nearTargetCapitalMode ? "YES" : "NO")
                        + " | MinimumTrade: " + (minimumTradeObjectiveReached ? "REACHED" : "NO")
                        + " | Daily30: " + (dailyThirtyPercentProtection ? "ARMED" : "NO")
                    );
                }
            }

            // =====================================================
            // V1.7.08 - NEAR-TARGET PRICE TRAIL
            // =====================================================
            // At >=90% of the currently configured TP, stop waiting passively
            // on a peak-retention floor. Follow the best favorable PRICE with a
            // small adaptive gap. This keeps the TP live while sharply reducing
            // how much of a nearly-complete winner can be returned.
            //
            // IMPORTANT:
            // - Does NOT market-close simply because 90% was reached.
            // - Does NOT move the user's TP.
            // - Gap is proportional to configured TP distance, not a hard tick map.
            // - Strong expansion gets slightly more room; weakening gets very tight.
            // - NeverWorsen and final market-side safety remain authoritative.
            if (
                nearTargetCapitalMode &&
                activeTargetTicks > 0 &&
                peakFavorableTicks > 0 &&
                tickSize > 0 &&
                localEntryFillPrice > 0
            )
            {
                double nearTargetTrailGapPct =
                    floatingWeakening
                        ? NearTargetTrailGapWeakPctOfTarget
                        : floatingStrongExpansion
                            ? NearTargetTrailGapStrongPctOfTarget
                            : NearTargetTrailGapNormalPctOfTarget;

                double nearTargetTrailGapTicks =
                    Math.Max(
                        NearTargetTrailMinGapTicks,
                        activeTargetTicks * nearTargetTrailGapPct
                    );

                double protectedPeakTicks =
                    Math.Max(
                        0,
                        peakFavorableTicks - nearTargetTrailGapTicks
                    );

                double nearTargetPriceTrailStop =
                    localMarketPosition == MarketPosition.Long
                        ? localEntryFillPrice + protectedPeakTicks * tickSize
                        : localEntryFillPrice - protectedPeakTicks * tickSize;

                nearTargetPriceTrailStop =
                    RoundToInstrumentTick(nearTargetPriceTrailStop);

                if (localMarketPosition == MarketPosition.Long)
                    desiredStop = Math.Max(desiredStop, nearTargetPriceTrailStop);
                else
                    desiredStop = Math.Min(desiredStop, nearTargetPriceTrailStop);

                string nearTargetTrailContext =
                    floatingWeakening
                        ? "WEAKENING"
                        : floatingStrongExpansion
                            ? "STRONG_EXPANSION"
                            : "NORMAL";

                string nearTargetPriceTrailKey =
                    localTradeEntryUtc.Ticks + "|" +
                    nearTargetTrailContext + "|" +
                    Math.Floor(targetProgressPct * 100.0).ToString("0") + "|" +
                    Math.Floor(peakFavorableTicks).ToString("0") + "|" +
                    nearTargetPriceTrailStop.ToString("0.00");

                DateTime nearTargetTrailNowUtc = DateTime.UtcNow;

                if (
                    nearTargetPriceTrailKey != lastNearTargetPriceTrailLogKey ||
                    lastNearTargetPriceTrailLogUtc == DateTime.MinValue ||
                    (nearTargetTrailNowUtc - lastNearTargetPriceTrailLogUtc).TotalSeconds >= 2.0
                )
                {
                    lastNearTargetPriceTrailLogKey = nearTargetPriceTrailKey;
                    lastNearTargetPriceTrailLogUtc = nearTargetTrailNowUtc;

                    PrintBotMessage(
                        "NEAR TARGET PRICE TRAIL"
                        + " | Context: " + nearTargetTrailContext
                        + " | TargetProgress: " + (targetProgressPct * 100.0).ToString("0.0") + "%"
                        + " | PeakTicks: " + peakFavorableTicks.ToString("0.0")
                        + " | TrailGap: " + nearTargetTrailGapTicks.ToString("0.0") + "t"
                        + " | GapPctTP: " + (nearTargetTrailGapPct * 100.0).ToString("0.0") + "%"
                        + " | StopProposal: " + nearTargetPriceTrailStop.ToString("0.00")
                        + " | TP: LIVE / UNCHANGED"
                        + " | NeverWorsen: ACTIVE"
                    );
                }
            }

            // =====================================================
            // V1.6.23 Phase 3 - ACTIVE TRADE REVERSAL GUARD
            // =====================================================
            // This is protection, not a reversal-entry engine. A trade must
            // first have meaningful positive MFE. Then a multi-factor opposite
            // context (structure/trend/VWAP/momentum) may tighten the stop to
            // retain part of peak open profit. NeverWorsen + market-side cap
            // ensure the stop cannot move backwards or cross the market.
            // V1.7.07 - Contextual reversal remains a safety authority. Legacy
            // R-based Profit Retention / Giveback are disabled; Floating Capital %
            // now owns normal winner protection. Legacy reversal
            // context is computed below for diagnostics only and cannot tighten
            // the stop.
            bool reversalGuardApplied = false;
            bool legacyContextReversalAuthorityEnabled = false;
            int reversalContextScore = 0;
            int oppositeMomentumScore = 0;
            int sameSideMomentumScore = 0;

            if (localMarketPosition == MarketPosition.Long)
            {
                if (localM5BearishStructure) reversalContextScore += 2;
                if (localM5BearishTrend) reversalContextScore += 1;
                if (localM5BelowVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeShortScore;
                sameSideMomentumScore = localRangeLongScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }
            else if (localMarketPosition == MarketPosition.Short)
            {
                if (localM5BullishStructure) reversalContextScore += 2;
                if (localM5BullishTrend) reversalContextScore += 1;
                if (localM5AboveVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeLongScore;
                sameSideMomentumScore = localRangeShortScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }

            double peakRForReversal =
                localInitialRiskDollars > 0
                    ? localPeakPnlDollars / localInitialRiskDollars
                    : 0;

            if (
                legacyContextReversalAuthorityEnabled &&
                favorableTicks >= ReversalGuardMinFavorableTicks &&
                peakRForReversal >= ReversalGuardMinPeakR &&
                reversalContextScore >= ReversalGuardMinContextScore &&
                localPeakPnlDollars > 0
            )
            {
                double pointValue = instrument.MasterInstrument.PointValue;

                if (pointValue > 0 && localEntryQuantity > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars * ReversalGuardPeakRetentionFactor;

                    double protectedPoints =
                        protectedDollars / (pointValue * localEntryQuantity);

                    double reversalStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + protectedPoints
                            : localEntryFillPrice - protectedPoints;

                    // A StopMarket must remain on the valid side of market.
                    if (localMarketPosition == MarketPosition.Long)
                        reversalStop = Math.Min(reversalStop, currentPrice - tickSize);
                    else
                        reversalStop = Math.Max(reversalStop, currentPrice + tickSize);

                    reversalStop = RoundToInstrumentTick(reversalStop);

                    bool improvesCurrentStop =
                        localMarketPosition == MarketPosition.Long
                            ? reversalStop > localActiveStopPrice
                            : reversalStop < localActiveStopPrice;

                    if (improvesCurrentStop)
                    {
                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, reversalStop);
                        else
                            desiredStop = Math.Min(desiredStop, reversalStop);

                        reversalGuardApplied = true;
                    }
                }
            }

            // V1.7.09 - TP1 BANKED => NO RETURN TO ORIGINAL RISK.
            // Before Scale-In, protect the original entry. After Scale-In,
            // localEntryFillPrice is the weighted combined average and becomes
            // the Combined-BE floor.
            if (adaptiveTp1Filled)
            {
                double adaptiveBeFloor =
                    localSmartScaleInUsed
                        ? localEntryFillPrice
                        : (
                            adaptiveOriginalEntryPrice > 0
                                ? adaptiveOriginalEntryPrice
                                : localEntryFillPrice
                          );

                adaptiveBeFloor =
                    RoundToInstrumentTick(
                        adaptiveBeFloor
                    );

                if (localMarketPosition == MarketPosition.Long)
                    desiredStop = Math.Max(desiredStop, adaptiveBeFloor);
                else if (localMarketPosition == MarketPosition.Short)
                    desiredStop = Math.Min(desiredStop, adaptiveBeFloor);
            }

            // V1.7.50 - PRE-TP1 MFE PROTECTION (HYBRID only).
            // GetTickProtectionFloorTicks() (EOD 12/20/32/40/56t, INTRADAY 18/28/34/48/62t at
            // MFE 30/40/50/60/70t) was defined but NEVER called, so before TP1 filled only the
            // original SL owned risk: 2026-10-01 trades that reached +52t / +84t closed at full
            // SL (-$110 / -$208). Now the stop map is applied from the first +30t of MFE.
            // After TP1 the BE floor / Floating Capital above take over. NeverWorsen and the
            // live-market clamps below stay authoritative. CORE20 is untouched.
            if (
                !adaptiveTp1Filled &&
                string.Equals(activeStrategyMode, "HYBRID", StringComparison.OrdinalIgnoreCase)
            )
            {
                int preTp1FloorTicks =
                    GetTickProtectionFloorTicks(
                        IsIntradayDrawdownProfile(),
                        peakFavorableTicks,
                        false
                    );

                if (preTp1FloorTicks > 0)
                {
                    double preTp1Entry =
                        adaptiveOriginalEntryPrice > 0
                            ? adaptiveOriginalEntryPrice
                            : localEntryFillPrice;

                    double preTp1FloorStop =
                        RoundToInstrumentTick(
                            localMarketPosition == MarketPosition.Long
                                ? preTp1Entry + preTp1FloorTicks * tickSize
                                : preTp1Entry - preTp1FloorTicks * tickSize
                        );

                    if (localMarketPosition == MarketPosition.Long)
                        desiredStop = Math.Max(desiredStop, preTp1FloorStop);
                    else if (localMarketPosition == MarketPosition.Short)
                        desiredStop = Math.Min(desiredStop, preTp1FloorStop);

                    string preTp1Key =
                        localTradeEntryUtc.Ticks + "|PRETP1|" + preTp1FloorTicks;

                    if (preTp1Key != lastPreTp1ProtectionLogKey)
                    {
                        lastPreTp1ProtectionLogKey = preTp1Key;

                        PrintBotMessage(
                            "PRE-TP1 PROTECTION"
                            + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                            + " | Floor: +" + preTp1FloorTicks + "t"
                            + " | Stop: " + preTp1FloorStop.ToString("0.00")
                            + " | Mode: " + (IsIntradayDrawdownProfile() ? "INTRADAY" : "EOD")
                        );
                    }
                }
            }

            // V1.7.51 - HYBRID ASIA SCALP TIME EXIT.
            // The scalp thesis (small 12-20 pt flow-driven move) must show progress
            // quickly. If after 180 s the trade never reached +16t (4 pts) of favorable
            // excursion and TP1 has not filled, flatten at market instead of waiting
            // for the full stop. Once per trade; Asia + HYBRID only; CORE20 untouched.
            if (
                !adaptiveTp1Filled &&
                string.Equals(activeStrategyMode, "HYBRID", StringComparison.OrdinalIgnoreCase) &&
                IsHybridAsiaExecutionEnabled() &&
                IsAsiaSession(GetCurrentNewYorkTime()) &&
                localTradeEntryUtc != DateTime.MinValue &&
                (localMarketPosition == MarketPosition.Long || localMarketPosition == MarketPosition.Short) &&
                peakFavorableTicks < HybridScalpTimeExitMinPeakTicks &&
                (DateTime.UtcNow - localTradeEntryUtc).TotalSeconds >= HybridScalpTimeExitSeconds &&
                hybridScalpTimeExitEntryTicks != localTradeEntryUtc.Ticks
            )
            {
                hybridScalpTimeExitEntryTicks = localTradeEntryUtc.Ticks;

                try
                {
                    lock (executionStateLock)
                    {
                        activeForcedExitReason = "HYBRID_SCALP_TIME_EXIT";
                    }

                    PrintBotMessage(
                        "ASIA SCALP TIME EXIT"
                        + " | Age: " + (DateTime.UtcNow - localTradeEntryUtc).TotalSeconds.ToString("0") + "s"
                        + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                        + " | Need: " + HybridScalpTimeExitMinPeakTicks + "t"
                        + " | Action: NO PROGRESS / FLATTEN"
                    );

                    account.Flatten(new[] { instrument });
                }
                catch (Exception ex)
                {
                    hybridScalpTimeExitEntryTicks = 0;
                    PrintBotMessage("ASIA SCALP TIME EXIT ERROR: " + ex.Message);
                }

                return;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // V1.6.23 Phase 12 - FINAL UNIVERSAL STOP SAFETY.
            // Every protection layer (BE, locks, trailing, Profit Retention,
            // Giveback Guard, Reversal Guard) merges into desiredStop.
            // Validate the FINAL value immediately before Account.Change().
            double safeBoundary =
                localMarketPosition == MarketPosition.Long
                    ? currentPrice - tickSize
                    : currentPrice + tickSize;

            safeBoundary =
                RoundToInstrumentTick(
                    safeBoundary
                );

            if (localMarketPosition == MarketPosition.Long)
            {
                desiredStop =
                    Math.Min(
                        desiredStop,
                        safeBoundary
                    );
            }
            else
            {
                desiredStop =
                    Math.Max(
                        desiredStop,
                        safeBoundary
                    );
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // V1.6.73 - Revalidate against the freshest live bid/ask.
            // The prior currentPrice safety clamp can become stale by the time
            // Account.Change() is submitted during a fast move.
            double stopBeforeLivePriceSafety =
                desiredStop;

            bool liveStopAdjusted;
            bool liveStopUsedLevel2;
            double liveStopReferencePrice;

            desiredStop =
                ClampProtectiveStopToLiveMarket(
                    localMarketPosition,
                    desiredStop,
                    currentPrice,
                    tickSize,
                    out liveStopAdjusted,
                    out liveStopUsedLevel2,
                    out liveStopReferencePrice
                );

            // V1.6.91 - PROFIT RETENTION MUST NEVER BECOME A LOSING STOP.
            // ClampProtectiveStopToLiveMarket() correctly keeps StopMarket
            // orders on the valid side of bid/ask, but in a fast reversal that
            // can move the requested stop through the retained-profit floor.
            // In that race, exit now; do not relabel a below-floor stop as
            // PROFIT_RETENTION.
            if (retentionHardFloorArmed)
            {
                bool retentionFloorPreserved =
                    localMarketPosition == MarketPosition.Long
                        ? desiredStop >= retentionHardFloorStop - tickSize * 0.5
                        : desiredStop <= retentionHardFloorStop + tickSize * 0.5;

                if (!retentionFloorPreserved)
                {
                    PrintBotMessage(
                        "PROFIT RETENTION FLOOR BREACHED BEFORE STOP UPDATE"
                        + " | Side: " + localMarketPosition
                        + " | Entry: " + localEntryFillPrice.ToString("0.00")
                        + " | Peak: " + localPeakPnlDollars.ToString("$0.00")
                        + " | RequiredProtect: " + retentionHardFloorDollars.ToString("$0.00")
                        + " | Required SL: " + retentionHardFloorStop.ToString("0.00")
                        + " | LiveSafe SL: " + desiredStop.ToString("0.00")
                        + " | MarketRef: " + liveStopReferencePrice.ToString("0.00")
                        + " | Action: EMERGENCY FLATTEN"
                    );

                    try
                    {
                        account.Flatten(
                            new[]
                            {
                                instrument
                            }
                        );
                    }
                    catch (Exception flattenEx)
                    {
                        PrintBotMessage(
                            "PROFIT RETENTION EMERGENCY FLATTEN ERROR: "
                            + flattenEx.Message
                        );
                    }

                    return;
                }
            }

            if (liveStopAdjusted)
            {
                string protectiveSafetyLogKey =
                    localMarketPosition
                    + "|" + stopBeforeLivePriceSafety.ToString("0.00")
                    + "|" + desiredStop.ToString("0.00")
                    + "|" + liveStopReferencePrice.ToString("0.00")
                    + "|" + (liveStopUsedLevel2 ? "L2" : "LAST");

                DateTime protectiveSafetyNowUtc = DateTime.UtcNow;

                if (
                    !string.Equals(
                        protectiveSafetyLogKey,
                        lastProtectiveStopSafetyLogKey,
                        StringComparison.Ordinal
                    ) ||
                    lastProtectiveStopSafetyLogUtc == DateTime.MinValue ||
                    (protectiveSafetyNowUtc - lastProtectiveStopSafetyLogUtc)
                        .TotalMilliseconds >= ProtectiveStopSafetyLogThrottleMs
                )
                {
                    lastProtectiveStopSafetyLogKey = protectiveSafetyLogKey;
                    lastProtectiveStopSafetyLogUtc = protectiveSafetyNowUtc;

                    PrintBotMessage(
                        "PROTECTIVE STOP PRICE SAFETY"
                        + " | Side: " + localMarketPosition
                        + " | Requested: "
                        + stopBeforeLivePriceSafety.ToString("0.00")
                        + " | Adjusted: "
                        + desiredStop.ToString("0.00")
                        + " | Ref: "
                        + liveStopReferencePrice.ToString("0.00")
                        + " | Source: "
                        + (liveStopUsedLevel2 ? "LEVEL2" : "LAST_PRICE")
                        + " | Buffer: 2t"
                    );
                }
            }

            // The safety clamp may remove the improvement if price moved
            // through the requested stop while the calculation was running.
            bool finalStopStillImproves =
                localMarketPosition == MarketPosition.Long
                    ? desiredStop > localActiveStopPrice
                    : desiredStop < localActiveStopPrice;

            if (!finalStopStillImproves)
                return;

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                // V8:
                // Reserve the improved stop immediately. This closes the
                // race where OrderUpdate/OCO Sync could still see the old
                // activeStopPrice and restore the original protective SL.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                if (givebackGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeGivebackGuardArmed;
                            activeGivebackGuardArmed = true;
                        }
                    }

                    string givebackKey =
                        localMarketPosition.ToString()
                        + "|" + Math.Round(givebackPercent * 100.0).ToString("0")
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || givebackKey != lastGivebackGuardLogKey)
                    {
                        lastGivebackGuardLogKey = givebackKey;

                        PrintBotMessage(
                            "PROFIT GIVEBACK GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | PeakR: " + givebackPeakR.ToString("0.00")
                            + " | Giveback: " + (givebackPercent * 100.0).ToString("0") + "%"
                            + " | Mode: " + adaptiveGivebackMode
                            + " | RetainPeak: "
                            + (adaptiveGivebackRetention * 100.0).ToString("0") + "%"
                            + " | Trigger: "
                            + (adaptiveGivebackTrigger * 100.0).ToString("0") + "%"
                            + " | L2 Same/Opp: "
                            + sameSidePersistenceSnapshot + "/"
                            + oppositePersistenceSnapshot
                            + " | TapeDelta: "
                            + tapeDeltaSnapshot.ToString("0")
                            + " | Abs: " + absorptionSnapshot
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                if (reversalGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeReversalGuardArmed;
                            activeReversalGuardArmed = true;
                        }
                    }

                    string reversalKey =
                        localMarketPosition.ToString()
                        + "|" + reversalContextScore
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || reversalKey != lastReversalGuardLogKey)
                    {
                        lastReversalGuardLogKey = reversalKey;

                        PrintBotMessage(
                            "REVERSAL GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | ContextScore: " + reversalContextScore
                            + " | OppMomentum: " + oppositeMomentumScore + "/5"
                            + " | PeakR: " + peakRForReversal.ToString("0.00")
                            + " | RetainPeak: "
                            + (ReversalGuardPeakRetentionFactor * 100.0).ToString("0") + "%"
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                bool retentionAdvanced = false;
                double retentionFactorApplied = 0;
                double retentionPeakPnl = 0;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(stopOrder, localStopOrder) &&
                        desiredRetentionStage > activeProfitRetentionStage
                    )
                    {
                        activeProfitRetentionStage = desiredRetentionStage;
                        activeProfitRetentionFactor = desiredRetentionFactor;
                        retentionAdvanced = true;
                        retentionFactorApplied = desiredRetentionFactor;
                        retentionPeakPnl = activeTradePeakPnlDollars;
                    }
                }

                if (retentionAdvanced)
                {
                    PrintBotMessage(
                        "PROFIT RETENTION STAGE "
                        + desiredRetentionStage
                        + " | Peak: "
                        + retentionPeakPnl.ToString("$0.00")
                        + " | Retain: "
                        + (retentionFactorApplied * 100.0).ToString("0")
                        + "%"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? (
                                (expansionHoldActive || globalBreathingRoomActive)
                                    ? "BREATHING ROOM BE"
                                    : localStrongMomentumProtection
                                        ? "ADAPTIVE BREAK EVEN"
                                        : "PROFIT PROTECT"
                              )
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : desiredStage == 3
                                    ? "LOCK PROFIT 2"
                                    : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        // =====================================================
        // V1.7.09 - ADAPTIVE PARTIAL PROFIT PLAN
        // =====================================================
        private int GetAdaptiveTp1Quantity(
            int baseQty)
        {
            if (baseQty <= 1)
                return 0;

            if (baseQty == 2)
                return 1;

            int qty =
                (int)Math.Round(
                    baseQty / 3.0,
                    MidpointRounding.AwayFromZero
                );

            return Math.Max(1, Math.Min(baseQty - 2, qty));
        }

        private int GetAdaptiveTp2Quantity(
            int baseQty,
            int tp1Qty)
        {
            int remainingAfterTp1 =
                Math.Max(0, baseQty - tp1Qty);

            if (remainingAfterTp1 <= 1)
                return 0;

            int qty =
                (int)Math.Round(
                    baseQty / 6.0,
                    MidpointRounding.AwayFromZero
                );

            return Math.Max(1, Math.Min(remainingAfterTp1 - 1, qty));
        }

        private void EnsureAdaptivePartialPlanInitialized()
        {
            long tradeKey;
            double currentEntry;
            int baseQty;

            lock (executionStateLock)
            {
                tradeKey =
                    activeTradeEntryUtc != DateTime.MinValue
                        ? activeTradeEntryUtc.Ticks
                        : 0;

                currentEntry = entryFillPrice;
                baseQty = initialTradeQuantity;
            }

            if (tradeKey <= 0 || currentEntry <= 0 || baseQty <= 0)
                return;

            lock (executionStateLock)
            {
                if (adaptivePartialTradeKey == tradeKey)
                    return;

                adaptivePartialTradeKey = tradeKey;
                adaptiveOriginalEntryPrice =
                    smartScaleInAnchorEntryPrice > 0
                        ? smartScaleInAnchorEntryPrice
                        : currentEntry;

                adaptiveOriginalBaseQuantity = baseQty;
                adaptiveTp1PlannedQty = GetAdaptiveTp1Quantity(baseQty);
                adaptiveTp2PlannedQty =
                    GetAdaptiveTp2Quantity(
                        baseQty,
                        adaptiveTp1PlannedQty
                    );

                adaptiveTp1FilledQty = 0;
                adaptiveTp2FilledQty = 0;
                adaptiveTp1Submitted = false;
                adaptiveTp2Submitted = false;
                adaptiveTp1Filled = adaptiveTp1PlannedQty <= 0;
                adaptiveTp2Filled = adaptiveTp2PlannedQty <= 0;
                adaptiveTp1Order = null;
                adaptiveTp2Order = null;
            }

            PrintBotMessage(
                "ADAPTIVE PARTIAL PLAN"
                + " | BaseQty: " + baseQty
                + " | TP1 +" + AdaptivePartialTp1Ticks + "t: " + adaptiveTp1PlannedQty
                + " | TP2 +" + AdaptivePartialTp2Ticks + "t: " + adaptiveTp2PlannedQty
                + " | TP3 Original: "
                + Math.Max(1, activeTargetTicks) + "t"
                + " | TP3 Qty: "
                + Math.Max(
                    1,
                    baseQty - adaptiveTp1PlannedQty - adaptiveTp2PlannedQty
                  )
                + " | ScaleQty: ALL -> ORIGINAL TP3"
            );
        }

        private void TryAdaptivePartialProfitPlan(
            double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            EnsureAdaptivePartialPlanInitialized();

            MarketPosition side;
            int openQty;
            double originalEntry;
            bool tp1Submitted;
            bool tp1Filled;
            bool tp2Submitted;
            int tp1Qty;
            int tp2Qty;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                openQty = Math.Max(0, entryQuantity - activeExitQuantity);
                originalEntry = adaptiveOriginalEntryPrice;
                tp1Submitted = adaptiveTp1Submitted;
                tp1Filled = adaptiveTp1Filled;
                tp2Submitted = adaptiveTp2Submitted;
                tp1Qty = adaptiveTp1PlannedQty;
                tp2Qty = adaptiveTp2PlannedQty;
            }

            if (
                side == MarketPosition.Flat ||
                openQty <= 0 ||
                originalEntry <= 0
            )
            {
                return;
            }

            double tickSize = instrument.MasterInstrument.TickSize;
            if (tickSize <= 0)
                return;

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - originalEntry) / tickSize
                    : (originalEntry - currentPrice) / tickSize;

            if (
                !tp1Submitted &&
                tp1Qty > 0 &&
                favorableTicks >= AdaptivePartialTp1Ticks &&
                openQty > 1
            )
            {
                SubmitAdaptivePartialExit(
                    1,
                    Math.Min(tp1Qty, openQty - 1),
                    side,
                    favorableTicks
                );

                return;
            }

            if (
                tp1Filled &&
                !tp2Submitted &&
                tp2Qty > 0 &&
                favorableTicks >= AdaptivePartialTp2Ticks &&
                openQty > 1
            )
            {
                SubmitAdaptivePartialExit(
                    2,
                    Math.Min(tp2Qty, openQty - 1),
                    side,
                    favorableTicks
                );
            }
        }

        private void SubmitAdaptivePartialExit(
            int stage,
            int quantity,
            MarketPosition side,
            double favorableTicks)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                quantity <= 0 ||
                side == MarketPosition.Flat
            )
            {
                return;
            }

            string orderName =
                stage == 1
                    ? GetProfileOrderName("JJ_PARTIAL_TP1")
                    : GetProfileOrderName("JJ_PARTIAL_TP2");

            lock (executionStateLock)
            {
                if (stage == 1)
                {
                    if (adaptiveTp1Submitted)
                        return;

                    adaptiveTp1Submitted = true;
                }
                else
                {
                    if (adaptiveTp2Submitted || !adaptiveTp1Filled)
                        return;

                    adaptiveTp2Submitted = true;
                }
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Sell
                        : OrderAction.BuyToCover;

                Order partialOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        quantity,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (stage == 1)
                        adaptiveTp1Order = partialOrder;
                    else
                        adaptiveTp2Order = partialOrder;
                }

                account.Submit(
                    new[] { partialOrder }
                );

                PrintBotMessage(
                    "ADAPTIVE PARTIAL SUBMITTED"
                    + " | TP" + stage
                    + " | Qty: " + quantity
                    + " | Progress: " + favorableTicks.ToString("0.0") + "t"
                    + " | TP3: ORIGINAL / UNCHANGED"
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (stage == 1)
                    {
                        adaptiveTp1Submitted = false;
                        adaptiveTp1Order = null;
                    }
                    else
                    {
                        adaptiveTp2Submitted = false;
                        adaptiveTp2Order = null;
                    }
                }

                PrintBotMessage(
                    "ADAPTIVE PARTIAL ERROR"
                    + " | TP" + stage
                    + " | " + ex.Message
                );
            }
        }

        // Called by JJBotOrderLifecycle for JJ_PARTIAL_TP1 / TP2 executions.
        private void HandleAdaptivePartialExitFill(
            string orderName,
            int fillQty)
        {
            if (fillQty <= 0)
                return;

            bool tp1CompletedNow = false;
            bool tp2CompletedNow = false;

            lock (executionStateLock)
            {
                if (
                    orderName == GetProfileOrderName("JJ_PARTIAL_TP1")
                )
                {
                    adaptiveTp1FilledQty += fillQty;
                    if (
                        !adaptiveTp1Filled &&
                        adaptiveTp1FilledQty >= adaptiveTp1PlannedQty
                    )
                    {
                        adaptiveTp1Filled = true;
                        tp1CompletedNow = true;
                    }
                }
                else if (
                    orderName == GetProfileOrderName("JJ_PARTIAL_TP2")
                )
                {
                    adaptiveTp2FilledQty += fillQty;
                    if (
                        !adaptiveTp2Filled &&
                        adaptiveTp2FilledQty >= adaptiveTp2PlannedQty
                    )
                    {
                        adaptiveTp2Filled = true;
                        tp2CompletedNow = true;
                    }
                }
            }

            if (tp1CompletedNow)
            {
                PrintBotMessage(
                    "TP1 BANKED"
                    + " | +" + AdaptivePartialTp1Ticks + "t"
                    + " | Qty: " + adaptiveTp1FilledQty
                    + " | StopFloor: BREAK-EVEN"
                    + " | ScaleWindow: 30-50t OPEN"
                );
            }

            if (tp2CompletedNow)
            {
                PrintBotMessage(
                    "TP2 BANKED"
                    + " | +" + AdaptivePartialTp2Ticks + "t"
                    + " | Qty: " + adaptiveTp2FilledQty
                    + " | ScaleRefill: TO MAX IF CONTEXT SAFE"
                    + " | FinalTarget: ORIGINAL TP3"
                );
            }
        }

        private int GetAdaptiveScaleAddQuantity(
            int configuredMaxContracts,
            int currentQty,
            int baseQty,
            double favorableTicks)
        {
            if (
                configuredMaxContracts <= currentQty ||
                baseQty <= 0 ||
                favorableTicks < SmartScaleInZoneStartTicks ||
                favorableTicks > SmartScaleInZoneEndTicks ||
                !adaptiveTp1Filled
            )
            {
                return 0;
            }

            int missing = configuredMaxContracts - currentQty;

            // TP2 has already paid: refill the just-created hole immediately,
            // subject to the normal continuation/risk checks below.
            // V1.7.32 - NO IMMEDIATE REFILL AFTER TP2.
            // Selling at TP2 and buying the same contracts back at the same
            // price only paid commission/slippage. TP2 now simply banks.
            if (
                adaptiveTp2Filled &&
                favorableTicks >= AdaptivePartialTp2Ticks
            )
            {
                return 0;
            }

            if (favorableTicks >= AdaptivePartialTp2Ticks)
                return 0;

            int tp1Qty = GetAdaptiveTp1Quantity(baseQty);
            int postTp1BaseQty = Math.Max(1, baseQty - tp1Qty);

            int intervalTicks;
            int batchQty;

            if (configuredMaxContracts <= 10)
            {
                intervalTicks =
                    Math.Max(
                        1,
                        (int)Math.Ceiling(
                            20.0 / configuredMaxContracts
                        )
                    );
                batchQty = 1;
            }
            else if (configuredMaxContracts <= 20)
            {
                intervalTicks = 1;
                batchQty = 1;
            }
            else
            {
                intervalTicks = AdaptiveScaleLargeMaxIntervalTicks;
                batchQty =
                    Math.Max(
                        2,
                        (int)Math.Ceiling(
                            configuredMaxContracts / 10.0
                        )
                    );
            }

            int completedSteps =
                (int)Math.Floor(
                    (favorableTicks - SmartScaleInZoneStartTicks) /
                    intervalTicks
                );

            if (completedSteps <= 0)
                return 0;

            int desiredQtyAtThisLevel =
                Math.Min(
                    configuredMaxContracts,
                    postTp1BaseQty + completedSteps * batchQty
                );

            int addQty =
                Math.Max(
                    0,
                    desiredQtyAtThisLevel - currentQty
                );

            return Math.Min(missing, addQty);
        }

        private bool CanOpeningScaleIn(
            double favorableTicks,
            int currentQty,
            out string reason)
        {
            reason = "NOT FAST OPEN";
            if (!activeTradeIsOpening)
                return true; // Existing non-opening Smart Scale-In behavior is preserved.

            if (!string.Equals(
                activeTradeEntryRoute,
                "FAST_OPEN",
                StringComparison.OrdinalIgnoreCase))
            {
                reason = "OPENING ROUTE IS NOT FAST_OPEN";
                return false;
            }

            if (favorableTicks <= 0)
            {
                reason = "POSITION NOT FAVORABLE";
                return false;
            }

            int maxContracts = Math.Max(1, Math.Min(MaxContractsAllowed, openingScaleInMaxContracts));
            if (currentQty >= maxContracts)
            {
                reason = "USER/RISK MAX CONTRACTS REACHED";
                return false;
            }

            if (dailyTargetProtectionArmed)
            {
                reason = "DAILY TARGET PROTECTION ACTIVE";
                return false;
            }

            reason = "FAVORABLE OPENING CONTINUATION ELIGIBLE";
            return true;
        }

        private int GetSmartScaleInRequiredTicks(
            int baseQty,
            int currentQty)
        {
            // V1.7.09 compatibility helper. Adaptive ladder owns exact levels.
            return SmartScaleInZoneStartTicks;
        }

        private void TrySmartScaleIn(
            double currentPrice)
        {
            // V1.7.32 - CORE20 never scales in (validated without scale-in).
            if (IsCore20Mode())
                return;

            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                !smartScaleInEnabled ||
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            MarketPosition side;
            double entryPrice;
            double stopPrice;
            int currentQty;
            int baseQty;
            double initialRisk;
            bool manualTrade;
            bool scalePending;
            bool targetProtection;
            bool entryIsPending;
            bool openingTrade;
            double targetPrice;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                entryPrice = entryFillPrice;
                stopPrice = activeStopPrice;

                currentQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                baseQty = initialTradeQuantity;
                initialRisk = initialTradeRiskDollars;
                manualTrade = activeTradeIsManualTest;
                scalePending = smartScaleInPending;
                targetProtection = dailyTargetProtectionArmed;
                entryIsPending = entryPending;
                openingTrade = activeTradeIsOpening;
                targetPrice = activeTargetPrice;
            }

            if (
                side == MarketPosition.Flat ||
                entryPrice <= 0 ||
                stopPrice <= 0 ||
                currentQty <= 0 ||
                baseQty <= 0 ||
                initialRisk <= 0 ||
                manualTrade ||
                scalePending ||
                targetProtection ||
                entryIsPending ||
                !adaptiveTp1Filled
            )
            {
                return;
            }

            int configuredMaxContracts =
                Math.Max(
                    baseQty,
                    Math.Min(
                        MaxContractsAllowed,
                        openingScaleInMaxContracts
                    )
                );

            if (currentQty >= configuredMaxContracts)
            {
                string maxQtyKey =
                    "MAX|" + side + "|" + entryPrice.ToString("0.00") + "|" + configuredMaxContracts;

                if (maxQtyKey != lastScaleZoneLogKey)
                {
                    lastScaleZoneLogKey = maxQtyKey;
                    PrintBotMessage(
                        "MAX QTY REACHED"
                        + " | Qty: " + currentQty
                        + "/" + configuredMaxContracts
                        + " | Scale-In: OFF"
                    );
                }
                return;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double scaleAnchorPrice =
                smartScaleInAnchorEntryPrice > 0
                    ? smartScaleInAnchorEntryPrice
                    : entryPrice;

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - scaleAnchorPrice) / tickSize
                    : (scaleAnchorPrice - currentPrice) / tickSize;

            // V1.7.07 - Do not increase exposure when the live trade has already
            // completed ~90% of the user's configured target. At that point the
            // job changes from adding size to preserving/capturing the objective.
            if (targetPrice > 0)
            {
                double targetDistance =
                    Math.Abs(targetPrice - entryPrice);

                double targetProgressAnchor =
                    adaptiveOriginalEntryPrice > 0
                        ? adaptiveOriginalEntryPrice
                        : scaleAnchorPrice;

                double targetDistanceFromOriginal =
                    Math.Abs(targetPrice - targetProgressAnchor);

                double favorableDistanceFromOriginal =
                    side == MarketPosition.Long
                        ? currentPrice - targetProgressAnchor
                        : targetProgressAnchor - currentPrice;

                double liveTargetProgress =
                    targetDistanceFromOriginal > tickSize * 0.5
                        ? Math.Max(0, favorableDistanceFromOriginal / targetDistanceFromOriginal)
                        : 0;

                if (liveTargetProgress >= SmartScaleInNearTargetBlockFactor)
                {
                    string nearTargetScaleKey =
                        "NEAR_TARGET|" + side + "|" +
                        Math.Floor(liveTargetProgress * 100.0).ToString("0") + "|" +
                        currentQty;

                    if (nearTargetScaleKey != lastScaleZoneLogKey)
                    {
                        lastScaleZoneLogKey = nearTargetScaleKey;
                        PrintBotMessage(
                            "SMART SCALE-IN BLOCKED - NEAR TARGET"
                            + " | Progress: " + (liveTargetProgress * 100.0).ToString("0.0") + "%"
                            + " | Threshold: " + (SmartScaleInNearTargetBlockFactor * 100.0).ToString("0") + "%"
                            + " | Qty: " + currentQty
                            + " | Action: MANAGE/PROTECT EXISTING POSITION"
                        );
                    }

                    return;
                }
            }

            if (favorableTicks < SmartScaleInZoneStartTicks)
            {
                return;
            }

            if (favorableTicks > SmartScaleInZoneEndTicks)
            {
                string closedKey =
                    "CLOSED|" + side + "|" + entryPrice.ToString("0.00");

                if (closedKey != lastScaleZoneLogKey)
                {
                    lastScaleZoneLogKey = closedKey;
                    PrintBotMessage(
                        "SCALE ZONE CLOSED"
                        + " | MFE: " + favorableTicks.ToString("0") + "t"
                        + " | Zone End: " + SmartScaleInZoneEndTicks + "t"
                        + " | Qty: " + currentQty + "/" + configuredMaxContracts
                        + " | Action: MANAGE POSITION ONLY"
                    );
                }
                return;
            }

            string scaleZoneKey =
                side + "|" + entryPrice.ToString("0.00") + "|" +
                currentQty + "|" + configuredMaxContracts;

            if (scaleZoneKey != lastScaleZoneLogKey)
            {
                lastScaleZoneLogKey = scaleZoneKey;
                PrintBotMessage(
                    "SCALE ZONE ACTIVE"
                    + " | MFE: " + favorableTicks.ToString("0") + "t"
                    + " | Zone: " + SmartScaleInZoneStartTicks + "-" + SmartScaleInZoneEndTicks + "t"
                    + " | Qty: " + currentQty + "/" + configuredMaxContracts
                    + " | Action: ADAPTIVE LADDER / ADD TOWARD MAX IF SAFE"
                );
            }

            string openingScaleReason;
            if (!CanOpeningScaleIn(favorableTicks, currentQty, out openingScaleReason))
                return;

            int scaleAddQty =
                GetAdaptiveScaleAddQuantity(
                    configuredMaxContracts,
                    currentQty,
                    baseQty,
                    favorableTicks
                );

            if (scaleAddQty <= 0)
                return;

            // V1.7.04 - Scale Zone safety. Every add between +30t and +50t
            // still requires BREAK-EVEN OR BETTER, then the existing atomic
            // worst-case risk calculation prove that adding size cannot exceed
            // the original trade risk / Dollar Risk Cap.
            double lockStop = entryPrice;

            bool stopProtected =
                side == MarketPosition.Long
                    ? stopPrice >=
                        lockStop - tickSize * 0.5
                    : stopPrice <=
                        lockStop + tickSize * 0.5;

            if (!stopProtected)
            {
                return;
            }

            // PRE-SUBMIT SCALE-IN SAFETY:
            // the currently working stop must already protect the projected
            // weighted-average break-even AFTER adding the next contract.
            // This prevents increasing size while the old BE would become a
            // loss on the larger combined position.
            int projectedQty =
                currentQty + scaleAddQty;

            double projectedAverageEntry =
                (
                    entryPrice * currentQty
                    + currentPrice * scaleAddQty
                ) / projectedQty;

            projectedAverageEntry =
                RoundToInstrumentTick(
                    projectedAverageEntry
                );

            // V1.7.09 - TP1 has already banked profit and current stop is at
            // BE-or-better. The stop does NOT need to protect the projected
            // combined average before the add; doing so would make scale-in
            // unreachable. Instead, verify that Combined-BE can be placed on
            // the valid side of the live market immediately after the fill.
            bool projectedCombinedBePlaceable =
                side == MarketPosition.Long
                    ? projectedAverageEntry <= currentPrice - tickSize
                    : projectedAverageEntry >= currentPrice + tickSize;

            if (!projectedCombinedBePlaceable)
            {
                PrintBotMessage(
                    "SMART SCALE-IN WAIT - COMBINED BE TOO CLOSE TO MARKET"
                    + " | Current Avg: " + entryPrice.ToString("0.00")
                    + " | Projected Avg: " + projectedAverageEntry.ToString("0.00")
                    + " | Market: " + currentPrice.ToString("0.00")
                    + " | Qty: " + currentQty + "->" + projectedQty
                );
                return;
            }

            int momentumScore;
            int oppositeMomentumScore;
            int htfScore;
            bool m5Aligned;

            lock (marketContextLock)
            {
                momentumScore =
                    side == MarketPosition.Long
                        ? latestRangeLongScore
                        : latestRangeShortScore;

                oppositeMomentumScore =
                    side == MarketPosition.Long
                        ? latestRangeShortScore
                        : latestRangeLongScore;

                htfScore =
                    side == MarketPosition.Long
                        ? latestHtfLongScore
                        : latestHtfShortScore;

                m5Aligned =
                    side == MarketPosition.Long
                        ? (latestM5BullishTrend && latestM5AboveVwap)
                        : (latestM5BearishTrend && latestM5BelowVwap);
            }

            if (
                momentumScore <
                    SmartScaleInMinMomentumScore ||
                htfScore <
                    SmartScaleInMinHtfScore
            )
            {
                return;
            }

            // V1.6.23 Phase 5 - CONTINUATION-ONLY SCALE-IN.
            // Adding size is more selective than the original entry:
            // 1) never add during RANGE,
            // 2) regime/pressure cannot point against the open trade,
            // 3) opposite R20 momentum must be quiet,
            // 4) M5 trend + VWAP must still support the trade.
            int pressureLongScore;
            int pressureShortScore;
            string pressure = EvaluateDirectionalPressure(
                out pressureLongScore,
                out pressureShortScore
            );

            string regimeDirection;
            string regimeReason;
            string regime = EvaluateMarketRegime(
                out regimeDirection,
                out regimeReason
            );

            string sideText =
                side == MarketPosition.Long ? "LONG" : "SHORT";

            bool pressureAgainst =
                (side == MarketPosition.Long && pressure == "SHORT") ||
                (side == MarketPosition.Short && pressure == "LONG");

            bool regimeAgainst =
                (side == MarketPosition.Long && regimeDirection == "SHORT") ||
                (side == MarketPosition.Short && regimeDirection == "LONG");

            bool contextBlocked =
                regime == "RANGE" ||
                pressureAgainst ||
                regimeAgainst ||
                !m5Aligned ||
                oppositeMomentumScore > SmartScaleInMaxOppMomentumScore;

            if (contextBlocked)
            {
                string blockKey =
                    sideText + "|" + regime + "|" + regimeDirection + "|" +
                    pressure + "|" + momentumScore + "|" + oppositeMomentumScore + "|" +
                    (m5Aligned ? "M5OK" : "M5NO");

                if (!string.Equals(
                    lastSmartScaleInContextBlockKey,
                    blockKey,
                    StringComparison.Ordinal))
                {
                    lastSmartScaleInContextBlockKey = blockKey;
                    PrintBotMessage(
                        "SMART SCALE-IN WAIT - CONTINUATION NOT CONFIRMED"
                        + " | Side: " + sideText
                        + " | Regime: " + regime + "/" + regimeDirection
                        + " | Pressure: " + pressure
                        + " | Momentum: " + momentumScore + "/5"
                        + " | Opp: " + oppositeMomentumScore + "/5"
                        + " | M5Aligned: " + m5Aligned
                    );
                }

                return;
            }

            lastSmartScaleInContextBlockKey = string.Empty;

            // Estimated worst-case PnL if the new contract fills
            // around currentPrice and the EXISTING stop is hit.
            double existingWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        entryPrice
                      )
                      * pointValue
                      * currentQty
                    : (
                        entryPrice -
                        stopPrice
                      )
                      * pointValue
                      * currentQty;

            double addedWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        currentPrice
                      )
                      * pointValue
                      * scaleAddQty
                    : (
                        currentPrice -
                        stopPrice
                      )
                      * pointValue
                      * scaleAddQty;

            double combinedWorstCase =
                existingWorstCase +
                addedWorstCase;

            double scaleInRiskLimit =
                Math.Min(
                    initialRisk,
                    activeDollarRiskCap > 0
                        ? activeDollarRiskCap
                        : initialRisk
                );

            if (
                combinedWorstCase <
                    -scaleInRiskLimit
            )
            {
                PrintBotMessage(
                    "SMART SCALE-IN BLOCKED - RISK CAP"
                    + " | WorstCase: "
                    + combinedWorstCase.ToString("$0.00")
                    + " | Limit: -"
                    + scaleInRiskLimit.ToString("$0.00")
                );

                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            // V1.6.12 - FINAL atomic revalidation immediately before
            // reserving the scale-in. The earlier snapshot is only a fast
            // eligibility check; fills/trailing may have changed quantity
            // or stop while momentum context was being evaluated.
            lock (executionStateLock)
            {
                if (
                    smartScaleInPending ||
                    entryPending ||
                    entryMarketPosition != side ||
                    activeTradeIsManualTest ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                int refreshedQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                double refreshedEntryPrice =
                    entryFillPrice;

                double refreshedStopPrice =
                    activeStopPrice;

                double refreshedInitialRisk =
                    initialTradeRiskDollars;

                if (
                    refreshedQty <= 0 ||
                    refreshedEntryPrice <= 0 ||
                    refreshedStopPrice <= 0 ||
                    refreshedInitialRisk <= 0
                )
                {
                    return;
                }

                // Atomic revalidation must protect the projected NEW weighted
                // average, not merely the pre-scale entry price.
                int refreshedProjectedQty =
                    refreshedQty + scaleAddQty;

                double refreshedProjectedAverage =
                    (
                        refreshedEntryPrice * refreshedQty
                        + currentPrice * scaleAddQty
                    ) / refreshedProjectedQty;

                refreshedProjectedAverage =
                    RoundToInstrumentTick(
                        refreshedProjectedAverage
                    );

                bool refreshedCombinedBePlaceable =
                    side == MarketPosition.Long
                        ? refreshedProjectedAverage <= currentPrice - tickSize
                        : refreshedProjectedAverage >= currentPrice + tickSize;

                if (!refreshedCombinedBePlaceable)
                {
                    return;
                }

                double refreshedExistingWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            refreshedEntryPrice
                          )
                          * pointValue
                          * refreshedQty
                        : (
                            refreshedEntryPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * refreshedQty;

                double refreshedAddedWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            currentPrice
                          )
                          * pointValue
                          * scaleAddQty
                        : (
                            currentPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * scaleAddQty;

                double refreshedCombinedWorstCase =
                    refreshedExistingWorstCase +
                    refreshedAddedWorstCase;

                double refreshedRiskLimit =
                    Math.Min(
                        refreshedInitialRisk,
                        activeDollarRiskCap > 0
                            ? activeDollarRiskCap
                            : refreshedInitialRisk
                    );

                if (
                    refreshedCombinedWorstCase <
                        -refreshedRiskLimit
                )
                {
                    return;
                }

                if (
                    lastSmartScaleInAttemptUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSmartScaleInAttemptUtc
                    ).TotalMilliseconds <
                        AdaptiveScaleAttemptThrottleMs
                )
                {
                    return;
                }

                if (
                    refreshedQty + scaleAddQty >
                        configuredMaxContracts
                )
                {
                    return;
                }

                // Keep the values used by the submission/log consistent
                // with the final validated execution snapshot.
                entryPrice = refreshedEntryPrice;
                stopPrice = refreshedStopPrice;
                currentQty = refreshedQty;
                initialRisk = refreshedInitialRisk;

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = nowUtc;
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        scaleAddQty,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (
                            entryMarketPosition != side
                    )
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(
                    new[]
                    {
                        scaleOrder
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN SUBMITTED"
                    + " | Side: "
                    + (
                        side == MarketPosition.Long
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Add: "
                    + scaleAddQty
                    + " | Profit: "
                    + favorableTicks.ToString("0")
                    + " ticks"
                    + " | Momentum: "
                    + momentumScore
                    + "/5"
                    + " | HTF: "
                    + htfScore
                    + "/2"
                    + " | Regime: " + regime + "/" + regimeDirection
                    + " | Pressure: " + pressure
                    + " | OppMomentum: " + oppositeMomentumScore + "/5"
                    + " | InitialRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage(
                    "SMART SCALE-IN ERROR: "
                    + ex.Message
                );
            }
        }
        private void EnforceSmartScaleInRiskCap()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            Order localStop;
            MarketPosition side;
            double averageEntry;
            double currentStop;
            double currentMarketPrice;
            int openQty;
            double initialRisk;

            lock (executionStateLock)
            {
                if (
                    !smartScaleInUsed ||
                    entryMarketPosition ==
                        MarketPosition.Flat ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    initialTradeRiskDollars <= 0
                )
                {
                    return;
                }

                localStop = stopOrder;
                side = entryMarketPosition;
                averageEntry = entryFillPrice;
                currentStop = activeStopPrice;
                currentMarketPrice = activeTradeCurrentPrice;

                openQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                initialRisk =
                    initialTradeRiskDollars;
            }

            if (
                localStop == null ||
                openQty <= 0 ||
                currentStop <= 0
            )
            {
                return;
            }

            if (
                localStop.OrderState !=
                    OrderState.Working &&
                localStop.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (pointValue <= 0)
            {
                return;
            }

            double riskCapStop =
                side == MarketPosition.Long
                    ? averageEntry
                        - initialRisk
                        / (
                            pointValue
                            * openQty
                        )
                    : averageEntry
                        + initialRisk
                        / (
                            pointValue
                            * openQty
                        );

            riskCapStop =
                RoundToInstrumentTick(
                    riskCapStop
                );

            double desiredStop =
                side == MarketPosition.Long
                    ? Math.Max(
                        currentStop,
                        riskCapStop
                      )
                    : Math.Min(
                        currentStop,
                        riskCapStop
                      );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // Phase 12 FIX: last-mile StopMarket validation for scale-in
            // risk cap using the active-trade market snapshot available in
            // this method.
            double scaleInTickSize =
                instrument.MasterInstrument.TickSize;

            if (
                currentMarketPrice > 0 &&
                scaleInTickSize > 0
            )
            {
                double scaleInSafeBoundary =
                    side == MarketPosition.Long
                        ? currentMarketPrice - scaleInTickSize
                        : currentMarketPrice + scaleInTickSize;

                scaleInSafeBoundary =
                    RoundToInstrumentTick(
                        scaleInSafeBoundary
                    );

                if (side == MarketPosition.Long)
                    desiredStop = Math.Min(desiredStop, scaleInSafeBoundary);
                else
                    desiredStop = Math.Max(desiredStop, scaleInSafeBoundary);

                desiredStop =
                    RoundToInstrumentTick(
                        desiredStop
                    );
            }

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > currentStop
                    : desiredStop < currentStop;

            if (!improves)
            {
                return;
            }

            long token;

            if (
                !TryBeginProtectiveChange(
                    "SMART_SCALE_IN_RISK",
                    out token
                )
            )
            {
                return;
            }

            try
            {
                lock (executionStateLock)
                {
                    if (
                        !ReferenceEquals(
                            stopOrder,
                            localStop
                        ) ||
                        entryMarketPosition != side
                    )
                    {
                        return;
                    }

                    activeStopPrice = desiredStop;
                    localStop.StopPriceChanged = desiredStop;
                }

                account.Change(
                    new[]
                    {
                        localStop
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP"
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                    + " | MaxRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    token
                );
            }
        }

    }
}

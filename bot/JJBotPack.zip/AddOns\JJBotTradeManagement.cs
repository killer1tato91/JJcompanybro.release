﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TRADE MANAGEMENT
    // Stage 10 structural extraction only.
    //
    // Existing target adaptation, protective bracket syncing,
    // partial-exit resize, never-worsen stop, momentum trailing,
    // Smart Scale-In and Scale-In risk-cap behavior are unchanged.
    //
    // No thresholds, prices, quantities, timing, OCO rules,
    // trailing rules, or risk calculations were modified.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.38 - PROFIT RETENTION V3
        // V1.6.66 - Explosion Fast Retention. At the first +30t trigger,
        // protect +18t (~60% of that first impulse) so intraday-trailing
        // accounts preserve more floating capital when the explosion fades.
        private const int MomentumFirstProtectionProfitTicks = 18;

        // =====================================================
        // V1.6.33 - STRUCTURE-AWARE TARGET V1
        // =====================================================
        // This method changes only where profit is taken. V1.6.36 adds a
        // separate pre-entry Structural RR gate in JJBotExecutionEngine;
        // this target helper itself still does not decide entry eligibility.
        //
        // The normal Dynamic Target remains the maximum objective.
        // If a valid M5 / Opening / Premarket structural barrier is
        // closer, take profit a small buffer BEFORE that barrier.
        private const int StructureTargetMaxBufferTicks = 8;
        private string lastStructureTargetLogKey = string.Empty;

        private int GetStructureAwareTargetTicks(
            MarketPosition marketPosition,
            double entryPrice,
            double tickSize,
            int dynamicTargetTicks)
        {
            if (
                dynamicTargetTicks <= 0 ||
                entryPrice <= 0 ||
                tickSize <= 0 ||
                marketPosition == MarketPosition.Flat
            )
            {
                return Math.Max(1, dynamicTargetTicks);
            }

            bool isLong =
                marketPosition == MarketPosition.Long;

            double roomTicks;
            string referenceName;
            double referencePrice;

            bool hasBarrier =
                TryGetEntryLocationRoom(
                    isLong,
                    entryPrice,
                    tickSize,
                    out roomTicks,
                    out referenceName,
                    out referencePrice
                );

            if (!hasBarrier || roomTicks <= 1.0)
            {
                return dynamicTargetTicks;
            }

            int availableTicks =
                Math.Max(
                    1,
                    (int)Math.Floor(roomTicks)
                );

            // Use up to 8 ticks of safety buffer, but scale it down
            // automatically when the structural barrier is very close.
            int bufferTicks =
                Math.Min(
                    StructureTargetMaxBufferTicks,
                    Math.Max(
                        1,
                        availableTicks / 5
                    )
                );

            int structuralTargetTicks =
                Math.Max(
                    1,
                    availableTicks - bufferTicks
                );

            int finalTargetTicks =
                Math.Min(
                    dynamicTargetTicks,
                    structuralTargetTicks
                );

            string logKey =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + dynamicTargetTicks
                + "|"
                + referenceName
                + "|"
                + referencePrice.ToString("0.00", CultureInfo.InvariantCulture)
                + "|"
                + finalTargetTicks;

            if (logKey != lastStructureTargetLogKey)
            {
                lastStructureTargetLogKey = logKey;

                PrintBotMessage(
                    "STRUCTURE-AWARE TARGET"
                    + " | Side: "
                    + (isLong ? "LONG" : "SHORT")
                    + " | Dynamic: "
                    + dynamicTargetTicks
                    + "t"
                    + " | Structure: "
                    + referenceName
                    + " @ "
                    + referencePrice.ToString("0.00")
                    + " | Room: "
                    + roomTicks.ToString("0")
                    + "t"
                    + " | Buffer: "
                    + bufferTicks
                    + "t"
                    + " | Final: "
                    + finalTargetTicks
                    + "t"
                );
            }

            return finalTargetTicks;
        }

        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            if (activeTargetTicks <= 0)
                return 1;

            int momentumScore = 0;
            int htfScore = 0;
            bool breakout = false;
            double volumeRatio = 0;

            lock (marketContextLock)
            {
                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    momentumScore =
                        latestRangeLongScore;

                    htfScore =
                        latestHtfLongScore;

                    breakout =
                        latestRangeHighBreakout;
                }
                else
                {
                    momentumScore =
                        latestRangeShortScore;

                    htfScore =
                        latestHtfShortScore;

                    breakout =
                        latestRangeLowBreakout;
                }

                volumeRatio =
                    latestRangeVolumeRatio;
            }

            int configuredStopTicks =
                Math.Max(1, activeStopTicks);

            int minimumRiskRewardTicks =
                (int)Math.Ceiling(
                    configuredStopTicks *
                    DynamicTargetMinimumRiskReward
                );

            int minimumTicks =
                Math.Min(
                    activeTargetTicks,
                    Math.Max(
                        DynamicTargetMinTicks,
                        minimumRiskRewardTicks
                    )
                );

            int targetTicks;

            if (
                momentumScore >= 4 &&
                breakout &&
                htfScore >= 1
            )
            {
                // Strong move: allow the full configured target.
                targetTicks =
                    activeTargetTicks;
            }
            else if (
                momentumScore >= 3 &&
                (
                    breakout ||
                    volumeRatio >=
                        MomentumVolumeExpansion
                )
            )
            {
                // Medium move: reduce target to 80%.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetMediumFactor
                    );
            }
            else
            {
                // Weak/slow move: take profit sooner.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetWeakFactor
                    );
            }

            targetTicks =
                Math.Max(
                    minimumTicks,
                    Math.Min(
                        activeTargetTicks,
                        targetTicks
                    )
                );

            PrintBotMessage(
                "DYNAMIC TARGET"
                + " | Momentum: "
                + momentumScore
                + "/5"
                + " | HTF: "
                + htfScore
                + "/2"
                + " | Breakout: "
                + breakout
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MinRR: 1:"
                + DynamicTargetMinimumRiskReward.ToString("0.00")
                + " | MinTP: "
                + minimumTicks
                + " ticks"
                + " | MaxCfg: "
                + activeTargetTicks
                + " ticks"
            );

            return targetTicks;
        }
        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            // =====================================================
            // V8 - NEVER-WORSEN PROTECTIVE STOP GUARD
            // =====================================================
            // OCO Sync may resize/synchronize the bracket, but it must
            // NEVER move an already-improved stop backwards.
            //
            // LONG  -> higher stop is better.
            // SHORT -> lower stop is better.
            //
            // activeStopPrice is reserved immediately by BE / Lock /
            // Trailing / Daily Target protection before Account.Change(),
            // so synchronous OrderUpdate callbacks cannot reconstruct the
            // original SL while NinjaTrader is processing the change.
            double protectedStopPrice;

            lock (executionStateLock)
            {
                protectedStopPrice =
                    activeStopPrice;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    marketPosition,
                    protectedStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_TARGET"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_STOP"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private double EnforceNeverWorsenStop(
            MarketPosition side,
            double currentProtectedStop,
            double requestedStop)
        {
            if (requestedStop <= 0)
                return currentProtectedStop;

            if (currentProtectedStop <= 0)
                return requestedStop;

            if (side == MarketPosition.Long)
            {
                return Math.Max(
                    currentProtectedStop,
                    requestedStop
                );
            }

            if (side == MarketPosition.Short)
            {
                return Math.Min(
                    currentProtectedStop,
                    requestedStop
                );
            }

            return currentProtectedStop;
        }
        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            int localBreakEvenTriggerTicks;
            bool localStrongMomentumProtection;
            bool localTrailingActive;
            bool localDailyProtectionArmed;
            double localInitialRiskDollars;
            double localPeakPnlDollars;
            int localProfitRetentionStage;
            bool localM5BullishTrend;
            bool localM5BearishTrend;
            bool localM5AboveVwap;
            bool localM5BelowVwap;
            bool localM5BullishStructure;
            bool localM5BearishStructure;
            int localRangeLongScore;
            int localRangeShortScore;
            int localHtfLongScore;
            int localHtfShortScore;
            double localBotDailyPnL;
            double localDailyTarget;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localBreakEvenTriggerTicks =
                    activeBreakEvenTriggerTicks > 0
                        ? activeBreakEvenTriggerTicks
                        : MomentumBreakEvenTriggerTicks;

                localStrongMomentumProtection =
                    activeStrongMomentumProtection;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;

                localInitialRiskDollars =
                    initialTradeRiskDollars;

                localPeakPnlDollars =
                    activeTradePeakPnlDollars;

                localProfitRetentionStage =
                    activeProfitRetentionStage;

                localM5BullishTrend = latestM5BullishTrend;
                localM5BearishTrend = latestM5BearishTrend;
                localM5AboveVwap = latestM5AboveVwap;
                localM5BelowVwap = latestM5BelowVwap;
                localM5BullishStructure = latestM5BullishStructure;
                localM5BearishStructure = latestM5BearishStructure;
                localRangeLongScore = latestRangeLongScore;
                localRangeShortScore = latestRangeShortScore;
                localHtfLongScore = latestHtfLongScore;
                localHtfShortScore = latestHtfShortScore;
                localBotDailyPnL = botDailyPnL;
                localDailyTarget = activeDailyTarget;
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            // Phase 3 Reversal Guard may protect a winning trade before the
            // normal BE trigger. Do not return until it also has too little
            // favorable excursion for reversal protection.
            if (
                favorableTicks < localBreakEvenTriggerTicks &&
                favorableTicks < ReversalGuardMinFavorableTicks
            )
            {
                return;
            }

            double pointValueForTradeIntelligence =
                instrument.MasterInstrument.PointValue;

            double currentTradePnlDollars = 0;

            if (
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double favorablePoints =
                    favorableTicks * tickSize;

                currentTradePnlDollars =
                    favorablePoints *
                    pointValueForTradeIntelligence *
                    localEntryQuantity;
            }

            double desiredStop =
                localActiveStopPrice;

            int desiredStage =
                localMomentumStage;

            // Stage 1: Profit-protected break-even.
            // V1.6.66: trigger is +30t and the stop protects +18t.
            if (
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumFirstProtectionProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumFirstProtectionProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Second staged profit lock
            if (
                favorableTicks >=
                    MomentumLock2TriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLock2ProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLock2ProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        3
                    );
            }

            // Stage 4: Dynamic trailing
            if (
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    desiredStop =
                        Math.Max(
                            desiredStop,
                            trailCandidate
                        );
                }
                else
                {
                    desiredStop =
                        Math.Min(
                            desiredStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    4;
            }

            // V1.6.23 Phase 2 - Profit Retention Manager.
            // Once a trade has produced meaningful MFE, protect a fraction
            // of the PEAK open PnL. This complements the fixed-tick stages
            // and is especially useful when a dynamic target is below the
            // +180t trailing trigger. Never-worsen below guarantees this
            // layer cannot loosen an existing stop.
            int desiredRetentionStage =
                localProfitRetentionStage;

            double desiredRetentionFactor = 0;

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0
            )
            {
                double peakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                if (peakR >= ProfitRetentionStage3TriggerR)
                {
                    desiredRetentionStage = 3;
                    desiredRetentionFactor = ProfitRetentionStage3Factor;
                }
                else if (peakR >= ProfitRetentionStage2TriggerR)
                {
                    desiredRetentionStage = 2;
                    desiredRetentionFactor = ProfitRetentionStage2Factor;
                }
                else if (peakR >= ProfitRetentionStage1TriggerR)
                {
                    desiredRetentionStage = 1;
                    desiredRetentionFactor = ProfitRetentionStage1Factor;
                }

                if (desiredRetentionFactor > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars *
                        desiredRetentionFactor;

                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double retentionStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, retentionStop);
                        else
                            desiredStop = Math.Min(desiredStop, retentionStop);
                    }
                }
            }

            // =====================================================
            // V1.6.70 - DAILY TARGET PRE-SECURE
            // =====================================================
            // Once the current trade carries the day to >=90% of the daily
            // objective, use the existing protective stop to preserve at
            // least 80% of that objective whenever the market allows it.
            // The hard DAILY TARGET flatten remains unchanged at 100%.
            if (
                localDailyTarget > 0 &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                currentTradePnlDollars > 0
            )
            {
                double currentDayTotal =
                    localBotDailyPnL +
                    currentTradePnlDollars;

                double preSecureActivation =
                    localDailyTarget *
                    DailyTargetPreSecureActivationFactor;

                if (
                    currentDayTotal >= preSecureActivation &&
                    currentDayTotal < localDailyTarget
                )
                {
                    double desiredProtectedDay =
                        localDailyTarget *
                        DailyTargetPreSecureRetentionFactor;

                    double requiredOpenProfit =
                        Math.Max(
                            0,
                            desiredProtectedDay -
                            localBotDailyPnL
                        );

                    if (requiredOpenProfit > 0)
                    {
                        double protectedPoints =
                            requiredOpenProfit /
                            (
                                pointValueForTradeIntelligence *
                                localEntryQuantity
                            );

                        double targetSecureStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, targetSecureStop);
                        else
                            desiredStop = Math.Min(desiredStop, targetSecureStop);
                    }
                }
            }

            // =====================================================
            // V1.6.23 Phase 9 - PROFIT GIVEBACK GUARD
            // =====================================================
            // Profit Retention tiers protect progressively larger peaks.
            // This extra layer reacts to the PATH of the trade: if a trade
            // already produced useful MFE but starts returning too much of
            // that peak, protect a conservative fraction before a full
            // reversal develops. It never loosens an existing stop.
            bool givebackGuardApplied = false;
            double givebackPercent = 0;
            double givebackPeakR = 0;
            double adaptiveGivebackTrigger =
                ProfitGivebackGuardTriggerPercent;
            double adaptiveGivebackRetention =
                ProfitGivebackGuardRetentionFactor;
            string adaptiveGivebackMode = "BASE";

            // Snapshot Level 2 once for this management pass.
            // Same-side flow gets more breathing room; opposite flow tightens
            // protection sooner. L2 never loosens an already protected stop.
            bool l2ReadySnapshot = false;
            int sameSidePersistenceSnapshot = 0;
            int oppositePersistenceSnapshot = 0;
            double tapeDeltaSnapshot = 0;
            string absorptionSnapshot = "NONE";

            lock (level2Sync)
            {
                l2ReadySnapshot =
                    level2ObserveActive &&
                    level2BookReady;

                tapeDeltaSnapshot =
                    level2TapeDelta;

                absorptionSnapshot =
                    level2Absorption;

                if (localMarketPosition == MarketPosition.Long)
                {
                    sameSidePersistenceSnapshot = level2LongPersistence;
                    oppositePersistenceSnapshot = level2ShortPersistence;
                }
                else
                {
                    sameSidePersistenceSnapshot = level2ShortPersistence;
                    oppositePersistenceSnapshot = level2LongPersistence;
                }
            }

            if (l2ReadySnapshot)
            {
                double signedTapeDelta =
                    localMarketPosition == MarketPosition.Long
                        ? tapeDeltaSnapshot
                        : -tapeDeltaSnapshot;

                bool sameSideAbsorptionRisk =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool oppositeAbsorptionSignal =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool strongSameSideL2 =
                    sameSidePersistenceSnapshot >=
                        ProfitGivebackL2SupportPersistence &&
                    signedTapeDelta >=
                        ProfitGivebackL2MinDelta &&
                    !sameSideAbsorptionRisk;

                bool strongOppositeL2 =
                    oppositePersistenceSnapshot >=
                        ProfitGivebackL2OppositePersistence ||
                    signedTapeDelta <=
                        -ProfitGivebackL2MinDelta ||
                    oppositeAbsorptionSignal;

                bool counterTrendContext =
                    localMarketPosition == MarketPosition.Long
                        ? (
                            localM5BearishTrend &&
                            localHtfShortScore > localHtfLongScore
                          )
                        : (
                            localM5BullishTrend &&
                            localHtfLongScore > localHtfShortScore
                          );

                if (strongOppositeL2)
                {
                    adaptiveGivebackMode = "L2 OPPOSITE";
                    adaptiveGivebackTrigger =
                        ProfitGivebackL2OppositeTriggerPercent;
                    adaptiveGivebackRetention =
                        ProfitGivebackL2OppositeRetentionFactor;
                }
                else if (counterTrendContext)
                {
                    adaptiveGivebackMode = "COUNTERTREND DEFENSE";
                    adaptiveGivebackTrigger =
                        CounterTrendGivebackTriggerPercent;
                    adaptiveGivebackRetention =
                        CounterTrendGivebackRetentionFactor;
                }
                else if (strongSameSideL2)
                {
                    adaptiveGivebackMode = "L2 SUPPORT";
                    adaptiveGivebackTrigger =
                        ProfitGivebackL2SupportTriggerPercent;
                    adaptiveGivebackRetention =
                        ProfitGivebackL2SupportRetentionFactor;
                }
            }

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0 &&
                currentTradePnlDollars > 0
            )
            {
                givebackPeakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                double givebackDollars =
                    Math.Max(
                        0,
                        localPeakPnlDollars -
                        currentTradePnlDollars
                    );

                givebackPercent =
                    localPeakPnlDollars > 0
                        ? givebackDollars / localPeakPnlDollars
                        : 0;

                if (
                    givebackPeakR >= ProfitGivebackGuardMinPeakR &&
                    givebackPercent >= adaptiveGivebackTrigger
                )
                {
                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedDollars =
                            localPeakPnlDollars *
                            adaptiveGivebackRetention;

                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double givebackStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        // Keep StopMarket on the valid side of current market.
                        if (localMarketPosition == MarketPosition.Long)
                            givebackStop = Math.Min(givebackStop, currentPrice - tickSize);
                        else
                            givebackStop = Math.Max(givebackStop, currentPrice + tickSize);

                        givebackStop =
                            RoundToInstrumentTick(givebackStop);

                        bool improvesCurrentStop =
                            localMarketPosition == MarketPosition.Long
                                ? givebackStop > localActiveStopPrice
                                : givebackStop < localActiveStopPrice;

                        if (improvesCurrentStop)
                        {
                            if (localMarketPosition == MarketPosition.Long)
                                desiredStop = Math.Max(desiredStop, givebackStop);
                            else
                                desiredStop = Math.Min(desiredStop, givebackStop);

                            givebackGuardApplied = true;
                        }
                    }
                }
            }

            // =====================================================
            // V1.6.23 Phase 3 - ACTIVE TRADE REVERSAL GUARD
            // =====================================================
            // This is protection, not a reversal-entry engine. A trade must
            // first have meaningful positive MFE. Then a multi-factor opposite
            // context (structure/trend/VWAP/momentum) may tighten the stop to
            // retain part of peak open profit. NeverWorsen + market-side cap
            // ensure the stop cannot move backwards or cross the market.
            // V1.6.64 - Explosion Mode: M5/VWAP/Structure are no longer
            // management authority. Profit Retention + L2 Profit Giveback remain
            // active and are the fast exit/protection layers. Legacy reversal
            // context is computed below for diagnostics only and cannot tighten
            // the stop.
            bool reversalGuardApplied = false;
            bool legacyContextReversalAuthorityEnabled = false;
            int reversalContextScore = 0;
            int oppositeMomentumScore = 0;
            int sameSideMomentumScore = 0;

            if (localMarketPosition == MarketPosition.Long)
            {
                if (localM5BearishStructure) reversalContextScore += 2;
                if (localM5BearishTrend) reversalContextScore += 1;
                if (localM5BelowVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeShortScore;
                sameSideMomentumScore = localRangeLongScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }
            else if (localMarketPosition == MarketPosition.Short)
            {
                if (localM5BullishStructure) reversalContextScore += 2;
                if (localM5BullishTrend) reversalContextScore += 1;
                if (localM5AboveVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeLongScore;
                sameSideMomentumScore = localRangeShortScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }

            double peakRForReversal =
                localInitialRiskDollars > 0
                    ? localPeakPnlDollars / localInitialRiskDollars
                    : 0;

            if (
                legacyContextReversalAuthorityEnabled &&
                favorableTicks >= ReversalGuardMinFavorableTicks &&
                peakRForReversal >= ReversalGuardMinPeakR &&
                reversalContextScore >= ReversalGuardMinContextScore &&
                localPeakPnlDollars > 0
            )
            {
                double pointValue = instrument.MasterInstrument.PointValue;

                if (pointValue > 0 && localEntryQuantity > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars * ReversalGuardPeakRetentionFactor;

                    double protectedPoints =
                        protectedDollars / (pointValue * localEntryQuantity);

                    double reversalStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + protectedPoints
                            : localEntryFillPrice - protectedPoints;

                    // A StopMarket must remain on the valid side of market.
                    if (localMarketPosition == MarketPosition.Long)
                        reversalStop = Math.Min(reversalStop, currentPrice - tickSize);
                    else
                        reversalStop = Math.Max(reversalStop, currentPrice + tickSize);

                    reversalStop = RoundToInstrumentTick(reversalStop);

                    bool improvesCurrentStop =
                        localMarketPosition == MarketPosition.Long
                            ? reversalStop > localActiveStopPrice
                            : reversalStop < localActiveStopPrice;

                    if (improvesCurrentStop)
                    {
                        if (localMarketPosition == MarketPosition.Long)
                            desiredStop = Math.Max(desiredStop, reversalStop);
                        else
                            desiredStop = Math.Min(desiredStop, reversalStop);

                        reversalGuardApplied = true;
                    }
                }
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // V1.6.23 Phase 12 - FINAL UNIVERSAL STOP SAFETY.
            // Every protection layer (BE, locks, trailing, Profit Retention,
            // Giveback Guard, Reversal Guard) merges into desiredStop.
            // Validate the FINAL value immediately before Account.Change().
            double safeBoundary =
                localMarketPosition == MarketPosition.Long
                    ? currentPrice - tickSize
                    : currentPrice + tickSize;

            safeBoundary =
                RoundToInstrumentTick(
                    safeBoundary
                );

            if (localMarketPosition == MarketPosition.Long)
            {
                desiredStop =
                    Math.Min(
                        desiredStop,
                        safeBoundary
                    );
            }
            else
            {
                desiredStop =
                    Math.Max(
                        desiredStop,
                        safeBoundary
                    );
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // The safety clamp may remove the improvement if price moved
            // through the requested stop while the calculation was running.
            bool finalStopStillImproves =
                localMarketPosition == MarketPosition.Long
                    ? desiredStop > localActiveStopPrice
                    : desiredStop < localActiveStopPrice;

            if (!finalStopStillImproves)
                return;

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                // V8:
                // Reserve the improved stop immediately. This closes the
                // race where OrderUpdate/OCO Sync could still see the old
                // activeStopPrice and restore the original protective SL.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                if (givebackGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeGivebackGuardArmed;
                            activeGivebackGuardArmed = true;
                        }
                    }

                    string givebackKey =
                        localMarketPosition.ToString()
                        + "|" + Math.Round(givebackPercent * 100.0).ToString("0")
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || givebackKey != lastGivebackGuardLogKey)
                    {
                        lastGivebackGuardLogKey = givebackKey;

                        PrintBotMessage(
                            "PROFIT GIVEBACK GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | PeakR: " + givebackPeakR.ToString("0.00")
                            + " | Giveback: " + (givebackPercent * 100.0).ToString("0") + "%"
                            + " | Mode: " + adaptiveGivebackMode
                            + " | RetainPeak: "
                            + (adaptiveGivebackRetention * 100.0).ToString("0") + "%"
                            + " | Trigger: "
                            + (adaptiveGivebackTrigger * 100.0).ToString("0") + "%"
                            + " | L2 Same/Opp: "
                            + sameSidePersistenceSnapshot + "/"
                            + oppositePersistenceSnapshot
                            + " | TapeDelta: "
                            + tapeDeltaSnapshot.ToString("0")
                            + " | Abs: " + absorptionSnapshot
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                if (reversalGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeReversalGuardArmed;
                            activeReversalGuardArmed = true;
                        }
                    }

                    string reversalKey =
                        localMarketPosition.ToString()
                        + "|" + reversalContextScore
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || reversalKey != lastReversalGuardLogKey)
                    {
                        lastReversalGuardLogKey = reversalKey;

                        PrintBotMessage(
                            "REVERSAL GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | ContextScore: " + reversalContextScore
                            + " | OppMomentum: " + oppositeMomentumScore + "/5"
                            + " | PeakR: " + peakRForReversal.ToString("0.00")
                            + " | RetainPeak: "
                            + (ReversalGuardPeakRetentionFactor * 100.0).ToString("0") + "%"
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                bool retentionAdvanced = false;
                double retentionFactorApplied = 0;
                double retentionPeakPnl = 0;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(stopOrder, localStopOrder) &&
                        desiredRetentionStage > activeProfitRetentionStage
                    )
                    {
                        activeProfitRetentionStage = desiredRetentionStage;
                        activeProfitRetentionFactor = desiredRetentionFactor;
                        retentionAdvanced = true;
                        retentionFactorApplied = desiredRetentionFactor;
                        retentionPeakPnl = activeTradePeakPnlDollars;
                    }
                }

                if (retentionAdvanced)
                {
                    PrintBotMessage(
                        "PROFIT RETENTION STAGE "
                        + desiredRetentionStage
                        + " | Peak: "
                        + retentionPeakPnl.ToString("$0.00")
                        + " | Retain: "
                        + (retentionFactorApplied * 100.0).ToString("0")
                        + "%"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? (
                                localStrongMomentumProtection
                                    ? "ADAPTIVE BREAK EVEN"
                                    : "PROTECT +10T"
                              )
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : desiredStage == 3
                                    ? "LOCK PROFIT 2"
                                    : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void TrySmartScaleIn(
            double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            MarketPosition side;
            double entryPrice;
            double stopPrice;
            int currentQty;
            int baseQty;
            double initialRisk;
            bool manualTrade;
            bool scaleUsed;
            bool scalePending;
            bool targetProtection;
            bool entryIsPending;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                entryPrice = entryFillPrice;
                stopPrice = activeStopPrice;

                currentQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                baseQty = initialTradeQuantity;
                initialRisk = initialTradeRiskDollars;
                manualTrade = activeTradeIsManualTest;
                scaleUsed = smartScaleInUsed;
                scalePending = smartScaleInPending;
                targetProtection = dailyTargetProtectionArmed;
                entryIsPending = entryPending;
            }

            if (
                side == MarketPosition.Flat ||
                entryPrice <= 0 ||
                stopPrice <= 0 ||
                currentQty <= 0 ||
                baseQty <= 0 ||
                initialRisk <= 0 ||
                manualTrade ||
                scaleUsed ||
                scalePending ||
                targetProtection ||
                entryIsPending
            )
            {
                return;
            }

            // No scale-in after a partial exit.
            if (currentQty != baseQty)
            {
                return;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - entryPrice) / tickSize
                    : (entryPrice - currentPrice) / tickSize;

            if (
                favorableTicks <
                    SmartScaleInTriggerTicks
            )
            {
                return;
            }

            // V1.6.23 Phase 6 audit fix - the +70t scale trigger must be
            // reachable before the fixed +100t / +30t profit-lock stage.
            // Require BREAK-EVEN OR BETTER here, then let the existing atomic
            // worst-case risk calculation prove that adding size cannot exceed
            // the original trade risk / Dollar Risk Cap.
            double lockStop = entryPrice;

            bool stopProtected =
                side == MarketPosition.Long
                    ? stopPrice >=
                        lockStop - tickSize * 0.5
                    : stopPrice <=
                        lockStop + tickSize * 0.5;

            if (!stopProtected)
            {
                return;
            }

            int momentumScore;
            int oppositeMomentumScore;
            int htfScore;
            bool m5Aligned;

            lock (marketContextLock)
            {
                momentumScore =
                    side == MarketPosition.Long
                        ? latestRangeLongScore
                        : latestRangeShortScore;

                oppositeMomentumScore =
                    side == MarketPosition.Long
                        ? latestRangeShortScore
                        : latestRangeLongScore;

                htfScore =
                    side == MarketPosition.Long
                        ? latestHtfLongScore
                        : latestHtfShortScore;

                m5Aligned =
                    side == MarketPosition.Long
                        ? (latestM5BullishTrend && latestM5AboveVwap)
                        : (latestM5BearishTrend && latestM5BelowVwap);
            }

            if (
                momentumScore <
                    SmartScaleInMinMomentumScore ||
                htfScore <
                    SmartScaleInMinHtfScore
            )
            {
                return;
            }

            // V1.6.23 Phase 5 - CONTINUATION-ONLY SCALE-IN.
            // Adding size is more selective than the original entry:
            // 1) never add during RANGE,
            // 2) regime/pressure cannot point against the open trade,
            // 3) opposite R20 momentum must be quiet,
            // 4) M5 trend + VWAP must still support the trade.
            int pressureLongScore;
            int pressureShortScore;
            string pressure = EvaluateDirectionalPressure(
                out pressureLongScore,
                out pressureShortScore
            );

            string regimeDirection;
            string regimeReason;
            string regime = EvaluateMarketRegime(
                out regimeDirection,
                out regimeReason
            );

            string sideText =
                side == MarketPosition.Long ? "LONG" : "SHORT";

            bool pressureAgainst =
                (side == MarketPosition.Long && pressure == "SHORT") ||
                (side == MarketPosition.Short && pressure == "LONG");

            bool regimeAgainst =
                (side == MarketPosition.Long && regimeDirection == "SHORT") ||
                (side == MarketPosition.Short && regimeDirection == "LONG");

            bool contextBlocked =
                regime == "RANGE" ||
                pressureAgainst ||
                regimeAgainst ||
                !m5Aligned ||
                oppositeMomentumScore > SmartScaleInMaxOppMomentumScore;

            if (contextBlocked)
            {
                string blockKey =
                    sideText + "|" + regime + "|" + regimeDirection + "|" +
                    pressure + "|" + momentumScore + "|" + oppositeMomentumScore + "|" +
                    (m5Aligned ? "M5OK" : "M5NO");

                if (!string.Equals(
                    lastSmartScaleInContextBlockKey,
                    blockKey,
                    StringComparison.Ordinal))
                {
                    lastSmartScaleInContextBlockKey = blockKey;
                    PrintBotMessage(
                        "SMART SCALE-IN WAIT - CONTINUATION NOT CONFIRMED"
                        + " | Side: " + sideText
                        + " | Regime: " + regime + "/" + regimeDirection
                        + " | Pressure: " + pressure
                        + " | Momentum: " + momentumScore + "/5"
                        + " | Opp: " + oppositeMomentumScore + "/5"
                        + " | M5Aligned: " + m5Aligned
                    );
                }

                return;
            }

            lastSmartScaleInContextBlockKey = string.Empty;

            // Estimated worst-case PnL if the new contract fills
            // around currentPrice and the EXISTING stop is hit.
            double existingWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        entryPrice
                      )
                      * pointValue
                      * currentQty
                    : (
                        entryPrice -
                        stopPrice
                      )
                      * pointValue
                      * currentQty;

            double addedWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        currentPrice
                      )
                      * pointValue
                      * SmartScaleInContracts
                    : (
                        currentPrice -
                        stopPrice
                      )
                      * pointValue
                      * SmartScaleInContracts;

            double combinedWorstCase =
                existingWorstCase +
                addedWorstCase;

            double scaleInRiskLimit =
                Math.Min(
                    initialRisk,
                    activeDollarRiskCap > 0
                        ? activeDollarRiskCap
                        : initialRisk
                );

            if (
                combinedWorstCase <
                    -scaleInRiskLimit
            )
            {
                PrintBotMessage(
                    "SMART SCALE-IN BLOCKED - RISK CAP"
                    + " | WorstCase: "
                    + combinedWorstCase.ToString("$0.00")
                    + " | Limit: -"
                    + scaleInRiskLimit.ToString("$0.00")
                );

                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            // V1.6.12 - FINAL atomic revalidation immediately before
            // reserving the scale-in. The earlier snapshot is only a fast
            // eligibility check; fills/trailing may have changed quantity
            // or stop while momentum context was being evaluated.
            lock (executionStateLock)
            {
                if (
                    smartScaleInUsed ||
                    smartScaleInPending ||
                    entryPending ||
                    entryMarketPosition != side ||
                    activeTradeIsManualTest ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                int refreshedQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                double refreshedEntryPrice =
                    entryFillPrice;

                double refreshedStopPrice =
                    activeStopPrice;

                double refreshedInitialRisk =
                    initialTradeRiskDollars;

                if (
                    refreshedQty <= 0 ||
                    refreshedQty != initialTradeQuantity ||
                    refreshedEntryPrice <= 0 ||
                    refreshedStopPrice <= 0 ||
                    refreshedInitialRisk <= 0
                )
                {
                    return;
                }

                // Atomic revalidation uses the same BE-or-better rule.
                // The risk-cap computation below remains the final authority.
                double refreshedLockStop = refreshedEntryPrice;

                bool refreshedStopProtected =
                    side == MarketPosition.Long
                        ? refreshedStopPrice >=
                            refreshedLockStop - tickSize * 0.5
                        : refreshedStopPrice <=
                            refreshedLockStop + tickSize * 0.5;

                if (!refreshedStopProtected)
                {
                    return;
                }

                double refreshedExistingWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            refreshedEntryPrice
                          )
                          * pointValue
                          * refreshedQty
                        : (
                            refreshedEntryPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * refreshedQty;

                double refreshedAddedWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            currentPrice
                          )
                          * pointValue
                          * SmartScaleInContracts
                        : (
                            currentPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * SmartScaleInContracts;

                double refreshedCombinedWorstCase =
                    refreshedExistingWorstCase +
                    refreshedAddedWorstCase;

                double refreshedRiskLimit =
                    Math.Min(
                        refreshedInitialRisk,
                        activeDollarRiskCap > 0
                            ? activeDollarRiskCap
                            : refreshedInitialRisk
                    );

                if (
                    refreshedCombinedWorstCase <
                        -refreshedRiskLimit
                )
                {
                    return;
                }

                if (
                    lastSmartScaleInAttemptUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSmartScaleInAttemptUtc
                    ).TotalMilliseconds <
                        SmartScaleInAttemptThrottleMs
                )
                {
                    return;
                }

                // Keep the values used by the submission/log consistent
                // with the final validated execution snapshot.
                entryPrice = refreshedEntryPrice;
                stopPrice = refreshedStopPrice;
                currentQty = refreshedQty;
                initialRisk = refreshedInitialRisk;

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = nowUtc;
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        SmartScaleInContracts,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (
                        smartScaleInUsed ||
                        entryMarketPosition != side
                    )
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(
                    new[]
                    {
                        scaleOrder
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN SUBMITTED"
                    + " | Side: "
                    + (
                        side == MarketPosition.Long
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Add: "
                    + SmartScaleInContracts
                    + " | Profit: "
                    + favorableTicks.ToString("0")
                    + " ticks"
                    + " | Momentum: "
                    + momentumScore
                    + "/5"
                    + " | HTF: "
                    + htfScore
                    + "/2"
                    + " | Regime: " + regime + "/" + regimeDirection
                    + " | Pressure: " + pressure
                    + " | OppMomentum: " + oppositeMomentumScore + "/5"
                    + " | InitialRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage(
                    "SMART SCALE-IN ERROR: "
                    + ex.Message
                );
            }
        }
        private void EnforceSmartScaleInRiskCap()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            Order localStop;
            MarketPosition side;
            double averageEntry;
            double currentStop;
            double currentMarketPrice;
            int openQty;
            double initialRisk;

            lock (executionStateLock)
            {
                if (
                    !smartScaleInUsed ||
                    entryMarketPosition ==
                        MarketPosition.Flat ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    initialTradeRiskDollars <= 0
                )
                {
                    return;
                }

                localStop = stopOrder;
                side = entryMarketPosition;
                averageEntry = entryFillPrice;
                currentStop = activeStopPrice;
                currentMarketPrice = activeTradeCurrentPrice;

                openQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                initialRisk =
                    initialTradeRiskDollars;
            }

            if (
                localStop == null ||
                openQty <= 0 ||
                currentStop <= 0
            )
            {
                return;
            }

            if (
                localStop.OrderState !=
                    OrderState.Working &&
                localStop.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (pointValue <= 0)
            {
                return;
            }

            double riskCapStop =
                side == MarketPosition.Long
                    ? averageEntry
                        - initialRisk
                        / (
                            pointValue
                            * openQty
                        )
                    : averageEntry
                        + initialRisk
                        / (
                            pointValue
                            * openQty
                        );

            riskCapStop =
                RoundToInstrumentTick(
                    riskCapStop
                );

            double desiredStop =
                side == MarketPosition.Long
                    ? Math.Max(
                        currentStop,
                        riskCapStop
                      )
                    : Math.Min(
                        currentStop,
                        riskCapStop
                      );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // Phase 12 FIX: last-mile StopMarket validation for scale-in
            // risk cap using the active-trade market snapshot available in
            // this method.
            double scaleInTickSize =
                instrument.MasterInstrument.TickSize;

            if (
                currentMarketPrice > 0 &&
                scaleInTickSize > 0
            )
            {
                double scaleInSafeBoundary =
                    side == MarketPosition.Long
                        ? currentMarketPrice - scaleInTickSize
                        : currentMarketPrice + scaleInTickSize;

                scaleInSafeBoundary =
                    RoundToInstrumentTick(
                        scaleInSafeBoundary
                    );

                if (side == MarketPosition.Long)
                    desiredStop = Math.Min(desiredStop, scaleInSafeBoundary);
                else
                    desiredStop = Math.Max(desiredStop, scaleInSafeBoundary);

                desiredStop =
                    RoundToInstrumentTick(
                        desiredStop
                    );
            }

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > currentStop
                    : desiredStop < currentStop;

            if (!improves)
            {
                return;
            }

            long token;

            if (
                !TryBeginProtectiveChange(
                    "SMART_SCALE_IN_RISK",
                    out token
                )
            )
            {
                return;
            }

            try
            {
                lock (executionStateLock)
                {
                    if (
                        !ReferenceEquals(
                            stopOrder,
                            localStop
                        ) ||
                        entryMarketPosition != side
                    )
                    {
                        return;
                    }

                    activeStopPrice = desiredStop;
                    localStop.StopPriceChanged = desiredStop;
                }

                account.Change(
                    new[]
                    {
                        localStop
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP"
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                    + " | MaxRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    token
                );
            }
        }

    }
}

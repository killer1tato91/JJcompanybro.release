#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TRADE MANAGEMENT
    // Stage 10 structural extraction only.
    //
    // Existing target adaptation, protective bracket syncing,
    // partial-exit resize, never-worsen stop, momentum trailing,
    // Smart Scale-In and Scale-In risk-cap behavior are unchanged.
    //
    // No thresholds, prices, quantities, timing, OCO rules,
    // trailing rules, or risk calculations were modified.
    // =========================================================
    public partial class JJBotWindow
    {
        // V1.6.38 - PROFIT RETENTION V3
        // V1.6.84 - Global Retention Authority Guard. Profit Retention and
        // Profit Giveback cannot take stop-management authority until every
        // trade has had at least 45 seconds to develop AND reached at least 1.25R
        // peak MFE. Fixed PROTECT/LOCK/LOCK2/TRAIL stages remain independent.
        private const double GlobalProfitRetentionGraceSeconds = 45.0;
        private const double GlobalProfitRetentionMinPeakR = 1.25;
        private string lastGlobalRetentionDeferredLogKey = string.Empty;
        private DateTime lastGlobalRetentionDeferredLogUtc = DateTime.MinValue;

        // V1.6.87 - EXPANSION HOLD V2.1 / BREAKOUT + ORIGIN EXPANSION
        // Trade-management-only experiment. Entry, SL/TP, Daily Target,
        // Scale-In eligibility and risk limits remain unchanged.
        //
        // Initial qualification has TWO management-only paths:
        //   A) BREAKOUT EXPANSION
        //      - same-side R20 >= 4/5
        //      - active same-side breakout
        //      - volume >= 1.25x
        //   B) ORIGIN EXPANSION (no breakout required)
        //      - same-side R20 >= 4/5
        //      - volume >= 1.50x
        //      - supportive live L2/tape persistence
        //      - trade has already progressed >= 16 ticks in favor
        //
        // This changes ONLY management after an entry already exists. It does
        // not create entries, bypass Final Entry Authority or alter Scale-In.
        //
        // V2.1 then evaluates fresh market context continuously. The hold is
        // refreshed by a support score built from R20, breakout, volume and L2.
        // A brief pullback or one weak snapshot does NOT immediately cancel it.
        //
        // Hold releases when:
        //   - peak excursion reaches 80 ticks (20 MNQ/NQ points), OR
        //   - there is a hard momentum reversal (same <=2 AND opposite >=4), OR
        //   - confirmation has been stale >=20s, current support is weak (<=1/4)
        //     and price has given back >=28 ticks from peak.
        //
        // While Hold is active:
        //   - the first +30t protection may move to breakeven only;
        //   - Lock / Lock2 / dynamic trailing are deferred;
        //   - Profit Retention and Profit Giveback are deferred.
        //
        // Regular/non-expansion trades keep the existing management unchanged.
        private const int ExpansionHoldObjectiveTicks = 80;
        private const int ExpansionHoldMinMomentumScore = 4;
        private const double ExpansionHoldMinVolumeRatio = 1.25;
        private const double ExpansionHoldOriginMinVolumeRatio = 1.50;
        private const double ExpansionHoldOriginMinFavorableTicks = 16.0;
        private const int ExpansionHoldReleaseSameSideScore = 2;
        private const int ExpansionHoldReleaseOppositeScore = 4;
        private const int ExpansionHoldRefreshMinSupportScore = 3;
        private const int ExpansionHoldWeakSupportScore = 1;
        private const double ExpansionHoldConfirmationGraceSeconds = 20.0;
        private const double ExpansionHoldMinGivebackTicksForStaleRelease = 28.0;
        private const int ExpansionHoldL2Persistence = 4;
        private DateTime expansionHoldTradeEntryUtc = DateTime.MinValue;
        private DateTime expansionHoldLastConfirmedUtc = DateTime.MinValue;
        private bool expansionHoldQualified = false;
        private bool lastExpansionHoldActive = false;
        private int lastExpansionHoldSupportScore = 0;
        private string expansionHoldQualificationMode = "NONE";

        // V1.6.66 - Explosion Fast Retention. At the first +30t trigger,
        // protect +18t (~60% of that first impulse) so intraday-trailing
        // accounts preserve more floating capital when the explosion fades.
        private const int MomentumFirstProtectionProfitTicks = 18;

        // V1.6.89 - MANAGEMENT-ONLY NOISE TOLERANCE / INTRADAY FLOATING FLOOR / MISSION MODE.
        // No entry, signal, Final Entry Authority, regime or Scale-In eligibility logic is changed.
        private const double TradeBreathingRoomPeakTicks = 80.0;
        private const double IntradayFloorStage1PeakDollars = 120.0;
        private const double IntradayFloorStage2PeakDollars = 160.0;
        private const double IntradayFloorStage3PeakDollars = 200.0;
        private const double IntradayFloorStage4PeakDollars = 250.0;
        private const double IntradayFloorStage5PeakDollars = 300.0;
        private const double IntradayFloorStage1Factor = 0.40;
        private const double IntradayFloorStage2Factor = 0.50;
        private const double IntradayFloorStage3Factor = 0.60;
        private const double IntradayFloorStage4Factor = 0.70;
        private const double IntradayFloorStage5Factor = 0.75;
        private const double PostScaleMinimumFloorFactor = 0.65;
        private const double EodPostScaleMinimumFloorFactor = 0.60;

        // V1.6.92 - SESSION-ADAPTIVE POST-SCALE BREATHING ROOM.
        // Percent-of-peak floors remain the capital-protection layer, but after
        // Smart Scale-In they cannot place a NEW stop too close to live price
        // while continuation remains healthy. Distance is expressed in PRICE
        // POINTS (not dollars), so larger contract size does not accidentally
        // turn the floor into a 3-4 point noise stop at NY Open.
        private const double NyOpenBreathingBasePoints = 10.0;
        private const double NyOpenBreathingMinPoints = 8.0;
        private const double NyOpenBreathingMaxPoints = 14.0;
        private const double NyAmBreathingBasePoints = 8.0;
        private const double NyAmBreathingMinPoints = 6.0;
        private const double NyAmBreathingMaxPoints = 10.0;
        private const double NyPmBreathingBasePoints = 7.0;
        private const double NyPmBreathingMinPoints = 5.0;
        private const double NyPmBreathingMaxPoints = 9.0;
        private const double LondonBreathingBasePoints = 7.0;
        private const double LondonBreathingMinPoints = 5.0;
        private const double LondonBreathingMaxPoints = 9.0;
        private const double AsiaBreathingBasePoints = 5.0;
        private const double AsiaBreathingMinPoints = 3.0;
        private const double AsiaBreathingMaxPoints = 7.0;
        private const double PreOpenBreathingBasePoints = 9.0;
        private const double PreOpenBreathingMinPoints = 7.0;
        private const double PreOpenBreathingMaxPoints = 12.0;
        private const double OtherBreathingBasePoints = 6.0;
        private const double OtherBreathingMinPoints = 4.0;
        private const double OtherBreathingMaxPoints = 8.0;
        private string lastAdaptiveBreathingLogKey = string.Empty;
        private DateTime lastAdaptiveBreathingLogUtc = DateTime.MinValue;

        private const double MissionModeMinVolumeRatio = 1.25;
        private const int MissionModeMinMomentumScore = 4;
        private const int MissionModeMinHtfScore = 1;
        private const int MissionModeTargetSafetyTicks = 4;
        private const double MissionModeDollarCushion = 1.03;

        // V1.6.94 - PROGRESSIVE DAILY CAPITAL AUTHORITY.
        // Management-only. Extends the existing Daily Target Pre-Secure idea
        // downward so meaningful daily progress cannot be returned to zero.
        // It does NOT change entries, signals, Scale-In eligibility, risk sizing,
        // OCO creation, Learning, or the hard 100% Daily Target close.
        //
        // Target progress -> minimum protected DAY PnL:
        // 50% -> 25% of target
        // 65% -> 40% of target
        // 80% -> 60% of target
        // 90% -> 80% of target (preserves existing Pre-Secure intent)
        private const double DailyCapitalStage1Progress = 0.50;
        private const double DailyCapitalStage1Floor = 0.25;
        private const double DailyCapitalStage2Progress = 0.65;
        private const double DailyCapitalStage2Floor = 0.40;
        private const double DailyCapitalStage3Progress = 0.80;
        private const double DailyCapitalStage3Floor = 0.60;
        private const double DailyCapitalStage4Progress = 0.90;
        private const double DailyCapitalStage4Floor = 0.80;

        // =====================================================
        // V1.6.96 - NEAR-TARGET PROFIT PROTECTION
        // =====================================================
        // This is NOT a new stop authority. It is part of PROFIT_PROTECTION.
        // Once the trade's PEAK excursion has completed >=95% of the live TP
        // distance, protect 90% of the peak MFE. This prevents a trade that
        // came within a few ticks of target from giving back a large portion
        // of the move. It does NOT market-close the trade and does NOT move TP.
        private const double NearTargetActivationFactor = 0.95;
        private const double NearTargetRetentionFactor = 0.90;
        private const double NearTargetMinTargetTicks = 20.0;
        private string lastNearTargetProtectionLogKey = string.Empty;
        private DateTime lastNearTargetProtectionLogUtc = DateTime.MinValue;
        private const int NearTargetProtectionLogThrottleMs = 1000;
        private DateTime lastMissionTargetChangeUtc = DateTime.MinValue;
        private double lastMissionTargetPrice = 0;
        private string lastMissionModeLogKey = string.Empty;


        private double GetSessionAdaptivePostScaleBreathingRoomPoints(
            bool strongContinuation,
            bool exceptionalContinuation,
            bool weakContinuation,
            out string sessionName)
        {
            DateTime nyNow;

            try
            {
                TimeZoneInfo eastern =
                    TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

                nyNow =
                    TimeZoneInfo.ConvertTimeFromUtc(
                        DateTime.UtcNow,
                        eastern
                    );
            }
            catch
            {
                nyNow = DateTime.UtcNow;
            }

            TimeSpan tod = nyNow.TimeOfDay;

            double basePoints;
            double minPoints;
            double maxPoints;

            if (tod >= new TimeSpan(9, 30, 0) && tod < new TimeSpan(10, 0, 0))
            {
                sessionName = "NY_OPEN";
                basePoints = NyOpenBreathingBasePoints;
                minPoints = NyOpenBreathingMinPoints;
                maxPoints = NyOpenBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(10, 0, 0) && tod < new TimeSpan(12, 0, 0))
            {
                sessionName = "NY_AM";
                basePoints = NyAmBreathingBasePoints;
                minPoints = NyAmBreathingMinPoints;
                maxPoints = NyAmBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(13, 0, 0) && tod < new TimeSpan(16, 0, 0))
            {
                sessionName = "NY_PM";
                basePoints = NyPmBreathingBasePoints;
                minPoints = NyPmBreathingMinPoints;
                maxPoints = NyPmBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(8, 0, 0) && tod < new TimeSpan(9, 30, 0))
            {
                sessionName = "NY_PREOPEN";
                basePoints = PreOpenBreathingBasePoints;
                minPoints = PreOpenBreathingMinPoints;
                maxPoints = PreOpenBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(3, 0, 0) && tod < new TimeSpan(8, 0, 0))
            {
                sessionName = "LONDON";
                basePoints = LondonBreathingBasePoints;
                minPoints = LondonBreathingMinPoints;
                maxPoints = LondonBreathingMaxPoints;
            }
            else if (tod >= new TimeSpan(18, 0, 0) || tod < new TimeSpan(3, 0, 0))
            {
                sessionName = "ASIA_OVERNIGHT";
                basePoints = AsiaBreathingBasePoints;
                minPoints = AsiaBreathingMinPoints;
                maxPoints = AsiaBreathingMaxPoints;
            }
            else
            {
                sessionName = "OTHER";
                basePoints = OtherBreathingBasePoints;
                minPoints = OtherBreathingMinPoints;
                maxPoints = OtherBreathingMaxPoints;
            }

            double roomPoints = basePoints;

            if (exceptionalContinuation)
                roomPoints = maxPoints;
            else if (strongContinuation)
                roomPoints = Math.Min(maxPoints, basePoints + 2.0);
            else if (weakContinuation)
                roomPoints = minPoints;

            return Math.Max(minPoints, Math.Min(maxPoints, roomPoints));
        }


        // =====================================================
        // V1.6.33 - STRUCTURE-AWARE TARGET V1
        // =====================================================
        // This method changes only where profit is taken. V1.6.36 adds a
        // separate pre-entry Structural RR gate in JJBotExecutionEngine;
        // this target helper itself still does not decide entry eligibility.
        //
        // The normal Dynamic Target remains the maximum objective.
        // If a valid M5 / Opening / Premarket structural barrier is
        // closer, take profit a small buffer BEFORE that barrier.
        private const int StructureTargetMaxBufferTicks = 8;
        private string lastStructureTargetLogKey = string.Empty;

        // V1.6.75 - Protective Stop Safety telemetry debounce only.
        // Stop calculations and Account.Change() behavior are unchanged.
        private string lastProtectiveStopSafetyLogKey = string.Empty;
        private DateTime lastProtectiveStopSafetyLogUtc = DateTime.MinValue;
        private const int ProtectiveStopSafetyLogThrottleMs = 750;

        private int GetStructureAwareTargetTicks(
            MarketPosition marketPosition,
            double entryPrice,
            double tickSize,
            int dynamicTargetTicks)
        {
            if (
                dynamicTargetTicks <= 0 ||
                entryPrice <= 0 ||
                tickSize <= 0 ||
                marketPosition == MarketPosition.Flat
            )
            {
                return Math.Max(1, dynamicTargetTicks);
            }

            bool isLong =
                marketPosition == MarketPosition.Long;

            double roomTicks;
            string referenceName;
            double referencePrice;

            bool hasBarrier =
                TryGetEntryLocationRoom(
                    isLong,
                    entryPrice,
                    tickSize,
                    out roomTicks,
                    out referenceName,
                    out referencePrice
                );

            if (!hasBarrier || roomTicks <= 1.0)
            {
                return dynamicTargetTicks;
            }

            int availableTicks =
                Math.Max(
                    1,
                    (int)Math.Floor(roomTicks)
                );

            // Use up to 8 ticks of safety buffer, but scale it down
            // automatically when the structural barrier is very close.
            int bufferTicks =
                Math.Min(
                    StructureTargetMaxBufferTicks,
                    Math.Max(
                        1,
                        availableTicks / 5
                    )
                );

            int structuralTargetTicks =
                Math.Max(
                    1,
                    availableTicks - bufferTicks
                );

            int finalTargetTicks =
                Math.Min(
                    dynamicTargetTicks,
                    structuralTargetTicks
                );

            string logKey =
                (isLong ? "LONG" : "SHORT")
                + "|"
                + dynamicTargetTicks
                + "|"
                + referenceName
                + "|"
                + referencePrice.ToString("0.00", CultureInfo.InvariantCulture)
                + "|"
                + finalTargetTicks;

            if (logKey != lastStructureTargetLogKey)
            {
                lastStructureTargetLogKey = logKey;

                PrintBotMessage(
                    "STRUCTURE-AWARE TARGET"
                    + " | Side: "
                    + (isLong ? "LONG" : "SHORT")
                    + " | Dynamic: "
                    + dynamicTargetTicks
                    + "t"
                    + " | Structure: "
                    + referenceName
                    + " @ "
                    + referencePrice.ToString("0.00")
                    + " | Room: "
                    + roomTicks.ToString("0")
                    + "t"
                    + " | Buffer: "
                    + bufferTicks
                    + "t"
                    + " | Final: "
                    + finalTargetTicks
                    + "t"
                );
            }

            return finalTargetTicks;
        }

        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            if (activeTargetTicks <= 0)
                return 1;

            int momentumScore = 0;
            int htfScore = 0;
            bool breakout = false;
            double volumeRatio = 0;

            lock (marketContextLock)
            {
                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    momentumScore =
                        latestRangeLongScore;

                    htfScore =
                        latestHtfLongScore;

                    breakout =
                        latestRangeHighBreakout;
                }
                else
                {
                    momentumScore =
                        latestRangeShortScore;

                    htfScore =
                        latestHtfShortScore;

                    breakout =
                        latestRangeLowBreakout;
                }

                volumeRatio =
                    latestRangeVolumeRatio;
            }

            int configuredStopTicks =
                Math.Max(1, activeStopTicks);

            int minimumRiskRewardTicks =
                (int)Math.Ceiling(
                    configuredStopTicks *
                    DynamicTargetMinimumRiskReward
                );

            int minimumTicks =
                Math.Min(
                    activeTargetTicks,
                    Math.Max(
                        DynamicTargetMinTicks,
                        minimumRiskRewardTicks
                    )
                );

            int targetTicks;

            if (
                momentumScore >= 4 &&
                breakout &&
                htfScore >= 1
            )
            {
                // Strong move: allow the full configured target.
                targetTicks =
                    activeTargetTicks;
            }
            else if (
                momentumScore >= 3 &&
                (
                    breakout ||
                    volumeRatio >=
                        MomentumVolumeExpansion
                )
            )
            {
                // Medium move: reduce target to 80%.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetMediumFactor
                    );
            }
            else
            {
                // Weak/slow move: take profit sooner.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetWeakFactor
                    );
            }

            targetTicks =
                Math.Max(
                    minimumTicks,
                    Math.Min(
                        activeTargetTicks,
                        targetTicks
                    )
                );

            PrintBotMessage(
                "DYNAMIC TARGET"
                + " | Momentum: "
                + momentumScore
                + "/5"
                + " | HTF: "
                + htfScore
                + "/2"
                + " | Breakout: "
                + breakout
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MinRR: 1:"
                + DynamicTargetMinimumRiskReward.ToString("0.00")
                + " | MinTP: "
                + minimumTicks
                + " ticks"
                + " | MaxCfg: "
                + activeTargetTicks
                + " ticks"
            );

            return targetTicks;
        }
        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            // =====================================================
            // V8 - NEVER-WORSEN PROTECTIVE STOP GUARD
            // =====================================================
            // OCO Sync may resize/synchronize the bracket, but it must
            // NEVER move an already-improved stop backwards.
            //
            // LONG  -> higher stop is better.
            // SHORT -> lower stop is better.
            //
            // activeStopPrice is reserved immediately by BE / Lock /
            // Trailing / Daily Target protection before Account.Change(),
            // so synchronous OrderUpdate callbacks cannot reconstruct the
            // original SL while NinjaTrader is processing the change.
            double protectedStopPrice;

            lock (executionStateLock)
            {
                protectedStopPrice =
                    activeStopPrice;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    marketPosition,
                    protectedStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_TARGET"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_STOP"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private double EnforceNeverWorsenStop(
            MarketPosition side,
            double currentProtectedStop,
            double requestedStop)
        {
            if (requestedStop <= 0)
                return currentProtectedStop;

            if (currentProtectedStop <= 0)
                return requestedStop;

            if (side == MarketPosition.Long)
            {
                return Math.Max(
                    currentProtectedStop,
                    requestedStop
                );
            }

            if (side == MarketPosition.Short)
            {
                return Math.Min(
                    currentProtectedStop,
                    requestedStop
                );
            }

            return currentProtectedStop;
        }
        // V1.6.73 - LIVE PROTECTIVE STOP PRICE SAFETY
        // Revalidate the final stop against the freshest available L2 bid/ask
        // immediately before Account.Change(). This prevents NinjaTrader
        // UnableToChangeOrder / InvalidPrice when price crosses the requested
        // protection level between calculation and submission.
        private double ClampProtectiveStopToLiveMarket(
            MarketPosition side,
            double requestedStop,
            double fallbackPrice,
            double tickSize,
            out bool adjusted,
            out bool usedLevel2,
            out double liveReferencePrice)
        {
            adjusted = false;
            usedLevel2 = false;
            liveReferencePrice = fallbackPrice;

            if (requestedStop <= 0 || tickSize <= 0)
                return requestedStop;

            double bestBid = 0;
            double bestAsk = 0;

            lock (level2Sync)
            {
                if (
                    level2BookReady &&
                    level2BidRows.Count > 0 &&
                    level2AskRows.Count > 0
                )
                {
                    bestBid = level2BidRows[0].Price;
                    bestAsk = level2AskRows[0].Price;
                }
            }

            const int safetyTicks = 2;
            double safeStop = requestedStop;

            if (side == MarketPosition.Long)
            {
                double reference = bestBid > 0
                    ? bestBid
                    : fallbackPrice;

                if (reference <= 0)
                    return requestedStop;

                usedLevel2 = bestBid > 0;
                liveReferencePrice = reference;

                double maxValidSellStop =
                    RoundToInstrumentTick(
                        reference -
                        (safetyTicks * tickSize)
                    );

                safeStop = Math.Min(
                    requestedStop,
                    maxValidSellStop
                );
            }
            else if (side == MarketPosition.Short)
            {
                double reference = bestAsk > 0
                    ? bestAsk
                    : fallbackPrice;

                if (reference <= 0)
                    return requestedStop;

                usedLevel2 = bestAsk > 0;
                liveReferencePrice = reference;

                double minValidBuyStop =
                    RoundToInstrumentTick(
                        reference +
                        (safetyTicks * tickSize)
                    );

                safeStop = Math.Max(
                    requestedStop,
                    minValidBuyStop
                );
            }

            safeStop =
                RoundToInstrumentTick(
                    safeStop
                );

            adjusted =
                Math.Abs(
                    safeStop - requestedStop
                ) >= tickSize * 0.5;

            return safeStop;
        }

        // V1.6.93 - MISSION MODE TARGET MANAGER / LIVE OPEN-QTY FIX. Management-only.
        // Extends or contracts the working TP toward the dollars still needed
        // for the configured daily target while continuation remains aligned.
        // It never changes entry eligibility or Scale-In risk limits.
        private void TryUpdateMissionModeTarget(
            double currentPrice,
            MarketPosition side,
            double entryPrice,
            int openQuantity,
            int sideMomentumScore,
            int htfScore,
            bool m5Aligned,
            bool sideBreakout,
            double volumeRatio,
            bool l2Ready,
            int oppositePersistence,
            double signedTapeDelta)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            // V1.6.93 - MISSION LIVE OPEN-QTY AUTHORITY.
            // The caller's quantity snapshot can be stale after Smart Scale-In or
            // a partial exit. Rebuild the quantity from the execution state that
            // actually owns the live position before converting dollars to points.
            int liveOpenQuantity;

            lock (executionStateLock)
            {
                liveOpenQuantity =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );
            }

            if (account == null || instrument == null || currentPrice <= 0 ||
                entryPrice <= 0 || liveOpenQuantity <= 0 || side == MarketPosition.Flat)
                return;

            double dailyTarget = activeDailyTarget;
            double realizedDayPnl = botDailyPnL;
            if (dailyTarget <= 0 || realizedDayPnl >= dailyTarget || dailyTargetProtectionArmed)
                return;

            bool continuationAligned =
                sideMomentumScore >= MissionModeMinMomentumScore &&
                htfScore >= MissionModeMinHtfScore &&
                m5Aligned &&
                (sideBreakout || volumeRatio >= MissionModeMinVolumeRatio);

            // L2 is confirmation, not mandatory authority. If ready, clear
            // opposite persistence + negative tape can veto Mission extension.
            if (l2Ready && oppositePersistence >= ExpansionHoldL2Persistence && signedTapeDelta < 0)
                continuationAligned = false;

            if (!continuationAligned)
                return;

            Order localTarget;
            double currentTargetPrice;
            lock (executionStateLock)
            {
                localTarget = targetOrder;
                currentTargetPrice = activeTargetPrice;
            }

            if (localTarget == null ||
                (localTarget.OrderState != OrderState.Working && localTarget.OrderState != OrderState.Accepted))
                return;

            double pointValue = instrument.MasterInstrument.PointValue;
            double tickSize = instrument.MasterInstrument.TickSize;
            if (pointValue <= 0 || tickSize <= 0)
                return;

            double dollarsStillNeeded =
                Math.Max(0, (dailyTarget - realizedDayPnl) * MissionModeDollarCushion);
            if (dollarsStillNeeded <= 0)
                return;

            double missionPoints =
                dollarsStillNeeded / (pointValue * liveOpenQuantity);

            double missionTargetPrice =
                side == MarketPosition.Long
                    ? entryPrice + missionPoints
                    : entryPrice - missionPoints;

            double minimumForwardTarget =
                side == MarketPosition.Long
                    ? currentPrice + MissionModeTargetSafetyTicks * tickSize
                    : currentPrice - MissionModeTargetSafetyTicks * tickSize;

            if (side == MarketPosition.Long)
                missionTargetPrice = Math.Max(missionTargetPrice, minimumForwardTarget);
            else
                missionTargetPrice = Math.Min(missionTargetPrice, minimumForwardTarget);

            missionTargetPrice = RoundToInstrumentTick(missionTargetPrice);

            if (currentTargetPrice <= 0)
                currentTargetPrice = side == MarketPosition.Long ? double.MinValue : double.MaxValue;

            if (Math.Abs(missionTargetPrice - localTarget.LimitPrice) < tickSize * 0.5)
                return;

            DateTime nowUtc = DateTime.UtcNow;
            if (lastMissionTargetChangeUtc != DateTime.MinValue &&
                (nowUtc - lastMissionTargetChangeUtc).TotalMilliseconds < ProtectiveOrderChangeThrottleMs)
                return;

            long token;
            if (!TryBeginProtectiveChange("MISSION_TARGET", out token))
                return;

            try
            {
                lock (executionStateLock)
                {
                    int refreshedOpenQuantity =
                        Math.Max(
                            0,
                            entryQuantity -
                            activeExitQuantity
                        );

                    // Quantity may change asynchronously when Smart Scale-In fills
                    // or a partial exit completes. Never submit a TP calculated
                    // with a stale quantity; the next management tick will recalc.
                    if (!ReferenceEquals(targetOrder, localTarget) ||
                        entryMarketPosition != side ||
                        dailyTargetProtectionArmed ||
                        refreshedOpenQuantity != liveOpenQuantity)
                        return;

                    activeTargetPrice = missionTargetPrice;
                    activeEffectiveTargetTicks =
                        Math.Max(
                            1,
                            (int)Math.Round(
                                Math.Abs(missionTargetPrice - entryPrice) / tickSize
                            )
                        );
                    localTarget.LimitPriceChanged = missionTargetPrice;
                    lastMissionTargetChangeUtc = nowUtc;
                    lastMissionTargetPrice = missionTargetPrice;
                }

                account.Change(new[] { localTarget });

                string missionKey =
                    side + "|" + missionTargetPrice.ToString("0.00") + "|" +
                    liveOpenQuantity + "|" + sideMomentumScore + "|" + htfScore;

                if (!string.Equals(missionKey, lastMissionModeLogKey, StringComparison.Ordinal))
                {
                    lastMissionModeLogKey = missionKey;
                    PrintBotMessage(
                        "MISSION MODE TARGET"
                        + " | Side: " + side
                        + " | RealizedDay: " + realizedDayPnl.ToString("$0.00")
                        + " | DailyTarget: " + dailyTarget.ToString("$0.00")
                        + " | Qty: " + liveOpenQuantity
                        + " | R20: " + sideMomentumScore + "/5"
                        + " | HTF: " + htfScore + "/2"
                        + " | Breakout: " + sideBreakout
                        + " | Volume x" + volumeRatio.ToString("0.00")
                        + " | New TP: " + missionTargetPrice.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("MISSION MODE TARGET ERROR: " + ex.Message);
            }
            finally
            {
                EndProtectiveChange(token);
            }
        }

        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            int localBreakEvenTriggerTicks;
            bool localStrongMomentumProtection;
            bool localTrailingActive;
            bool localDailyProtectionArmed;
            double localInitialRiskDollars;
            double localPeakPnlDollars;
            int localProfitRetentionStage;
            bool localM5BullishTrend;
            bool localM5BearishTrend;
            bool localM5AboveVwap;
            bool localM5BelowVwap;
            bool localM5BullishStructure;
            bool localM5BearishStructure;
            int localRangeLongScore;
            int localRangeShortScore;
            int localHtfLongScore;
            int localHtfShortScore;
            double localBotDailyPnL;
            double localDailyTarget;
            double localActiveTargetPrice;
            bool localOpeningTrade;
            bool localSmartScaleInUsed;
            DateTime localTradeEntryUtc;
            double localRangeVolumeRatio;
            bool localSideBreakout;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localBreakEvenTriggerTicks =
                    activeBreakEvenTriggerTicks > 0
                        ? activeBreakEvenTriggerTicks
                        : MomentumBreakEvenTriggerTicks;

                localStrongMomentumProtection =
                    activeStrongMomentumProtection;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;

                localInitialRiskDollars =
                    initialTradeRiskDollars;

                localPeakPnlDollars =
                    activeTradePeakPnlDollars;

                localProfitRetentionStage =
                    activeProfitRetentionStage;

                localM5BullishTrend = latestM5BullishTrend;
                localM5BearishTrend = latestM5BearishTrend;
                localM5AboveVwap = latestM5AboveVwap;
                localM5BelowVwap = latestM5BelowVwap;
                localM5BullishStructure = latestM5BullishStructure;
                localM5BearishStructure = latestM5BearishStructure;
                localRangeLongScore = latestRangeLongScore;
                localRangeShortScore = latestRangeShortScore;
                localHtfLongScore = latestHtfLongScore;
                localHtfShortScore = latestHtfShortScore;
                localBotDailyPnL = botDailyPnL;
                localDailyTarget = activeDailyTarget;
                localActiveTargetPrice = activeTargetPrice;
                localOpeningTrade = activeTradeIsOpening;
                localSmartScaleInUsed = smartScaleInUsed;
                localTradeEntryUtc = activeTradeEntryUtc;
            }

            lock (marketContextLock)
            {
                localRangeVolumeRatio =
                    latestRangeVolumeRatio;

                localSideBreakout =
                    localMarketPosition == MarketPosition.Long
                        ? latestRangeHighBreakout
                        : latestRangeLowBreakout;
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            // Phase 3 Reversal Guard may protect a winning trade before the
            // normal BE trigger. Do not return until it also has too little
            // favorable excursion for reversal protection.
            if (
                favorableTicks < localBreakEvenTriggerTicks &&
                favorableTicks < ReversalGuardMinFavorableTicks
            )
            {
                return;
            }

            double pointValueForTradeIntelligence =
                instrument.MasterInstrument.PointValue;

            double currentTradePnlDollars = 0;

            if (
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double favorablePoints =
                    favorableTicks * tickSize;

                currentTradePnlDollars =
                    favorablePoints *
                    pointValueForTradeIntelligence *
                    localEntryQuantity;
            }

            double peakFavorableTicks =
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                tickSize > 0
                    ? localPeakPnlDollars /
                      (
                          pointValueForTradeIntelligence *
                          localEntryQuantity *
                          tickSize
                      )
                    : 0;

            int sideMomentumScore =
                localMarketPosition == MarketPosition.Long
                    ? localRangeLongScore
                    : localRangeShortScore;

            int oppositeMomentumScoreForHold =
                localMarketPosition == MarketPosition.Long
                    ? localRangeShortScore
                    : localRangeLongScore;

            // Reset Expansion Hold state exactly once for each new trade.
            if (localTradeEntryUtc != expansionHoldTradeEntryUtc)
            {
                expansionHoldTradeEntryUtc =
                    localTradeEntryUtc;

                expansionHoldLastConfirmedUtc =
                    DateTime.MinValue;

                expansionHoldQualified =
                    false;

                lastExpansionHoldActive =
                    false;

                lastExpansionHoldSupportScore =
                    0;

                expansionHoldQualificationMode =
                    "NONE";
            }

            // V2: snapshot L2 for CONTINUOUS confirmation only.
            // It is evidence for trade management, never entry authority.
            bool expansionL2Ready = false;
            int expansionSameSidePersistence = 0;
            int expansionOppositePersistence = 0;
            double expansionSignedTapeDelta = 0;
            string expansionAbsorption = "NONE";

            lock (level2Sync)
            {
                expansionL2Ready =
                    level2ObserveActive &&
                    level2BookReady;

                expansionAbsorption =
                    level2Absorption ?? "NONE";

                if (localMarketPosition == MarketPosition.Long)
                {
                    expansionSameSidePersistence =
                        level2LongPersistence;

                    expansionOppositePersistence =
                        level2ShortPersistence;

                    expansionSignedTapeDelta =
                        level2TapeDelta;
                }
                else
                {
                    expansionSameSidePersistence =
                        level2ShortPersistence;

                    expansionOppositePersistence =
                        level2LongPersistence;

                    expansionSignedTapeDelta =
                        -level2TapeDelta;
                }
            }

            bool expansionOppositeAbsorption =
                localMarketPosition == MarketPosition.Long
                    ? (
                        string.Equals(
                            expansionAbsorption,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            expansionAbsorption,
                            "SELL ABSORPTION CONFIRMED",
                            StringComparison.OrdinalIgnoreCase
                        )
                      )
                    : (
                        string.Equals(
                            expansionAbsorption,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        string.Equals(
                            expansionAbsorption,
                            "BUY ABSORPTION CONFIRMED",
                            StringComparison.OrdinalIgnoreCase
                        )
                      );

            bool expansionL2Support =
                expansionL2Ready &&
                expansionSameSidePersistence >= ExpansionHoldL2Persistence &&
                expansionSignedTapeDelta >= 0 &&
                !expansionOppositeAbsorption;

            int expansionSupportScore = 0;

            if (sideMomentumScore >= ExpansionHoldMinMomentumScore)
                expansionSupportScore++;

            if (localSideBreakout)
                expansionSupportScore++;

            if (localRangeVolumeRatio >= ExpansionHoldMinVolumeRatio)
                expansionSupportScore++;

            if (expansionL2Support)
                expansionSupportScore++;

            bool breakoutExpansionQualification =
                sideMomentumScore >= ExpansionHoldMinMomentumScore &&
                localSideBreakout &&
                localRangeVolumeRatio >= ExpansionHoldMinVolumeRatio;

            // V2.1 ORIGIN EXPANSION: a strong move can start from a session /
            // structural low or high and travel materially BEFORE a formal
            // breakout prints. Because this method runs only after a position
            // already exists, this path affects management only.
            bool originExpansionQualification =
                sideMomentumScore >= ExpansionHoldMinMomentumScore &&
                !localSideBreakout &&
                localRangeVolumeRatio >= ExpansionHoldOriginMinVolumeRatio &&
                expansionL2Support &&
                favorableTicks >= ExpansionHoldOriginMinFavorableTicks;

            bool expansionQualificationNow =
                breakoutExpansionQualification ||
                originExpansionQualification;

            DateTime expansionNowUtc =
                DateTime.UtcNow;

            if (!expansionHoldQualified && expansionQualificationNow)
            {
                expansionHoldQualified =
                    true;

                expansionHoldQualificationMode =
                    breakoutExpansionQualification
                        ? "BREAKOUT"
                        : "ORIGIN";

                expansionHoldLastConfirmedUtc =
                    expansionNowUtc;

                PrintBotMessage(
                    "EXPANSION HOLD QUALIFIED"
                    + " | Mode: " + expansionHoldQualificationMode
                    + " | Side: " + localMarketPosition
                    + " | R20: " + sideMomentumScore + "/5"
                    + " | Breakout: " + localSideBreakout
                    + " | Volume x" + localRangeVolumeRatio.ToString("0.00")
                    + " | Progress: " + favorableTicks.ToString("0") + "t"
                    + " | L2: " + (expansionL2Support ? "SUPPORT" : "NOT REQUIRED")
                    + " | Support: " + expansionSupportScore + "/4"
                    + " | Objective: " + ExpansionHoldObjectiveTicks + "t"
                );
            }

            // Fresh confirmation extends the hold. We intentionally require
            // 3/4 evidence so one isolated L2 or R20 snapshot cannot keep a
            // weak expansion alive indefinitely.
            if (
                expansionHoldQualified &&
                expansionSupportScore >= ExpansionHoldRefreshMinSupportScore
            )
            {
                expansionHoldLastConfirmedUtc =
                    expansionNowUtc;
            }

            double expansionConfirmationAgeSeconds =
                expansionHoldLastConfirmedUtc != DateTime.MinValue
                    ? Math.Max(
                        0,
                        (expansionNowUtc - expansionHoldLastConfirmedUtc)
                            .TotalSeconds
                      )
                    : double.MaxValue;

            double expansionGivebackTicks =
                Math.Max(
                    0,
                    peakFavorableTicks - favorableTicks
                );

            bool expansionHardMomentumFailure =
                sideMomentumScore <= ExpansionHoldReleaseSameSideScore &&
                oppositeMomentumScoreForHold >= ExpansionHoldReleaseOppositeScore;

            bool expansionOppositeMicroFailure =
                expansionL2Ready &&
                expansionOppositePersistence >= ExpansionHoldL2Persistence &&
                expansionSignedTapeDelta < 0 &&
                expansionOppositeAbsorption;

            bool expansionStaleFailure =
                expansionConfirmationAgeSeconds >= ExpansionHoldConfirmationGraceSeconds &&
                expansionSupportScore <= ExpansionHoldWeakSupportScore &&
                expansionGivebackTicks >= ExpansionHoldMinGivebackTicksForStaleRelease;

            bool expansionMaterialFailure =
                expansionHardMomentumFailure ||
                expansionOppositeMicroFailure ||
                expansionStaleFailure;

            // V1.6.89 - Global breathing room applies to every managed trade,
            // not only Expansion Hold trades. It defers aggressive lock/trail
            // layers until the trade has developed ~20 points of peak MFE,
            // unless a hard opposite reversal is confirmed. Intraday floating
            // floors below can still override this and protect meaningful PnL.
            bool globalBreathingRoomActive =
                peakFavorableTicks < TradeBreathingRoomPeakTicks &&
                !expansionHardMomentumFailure &&
                !expansionOppositeMicroFailure;

            bool expansionHoldActive =
                expansionHoldQualified &&
                peakFavorableTicks < ExpansionHoldObjectiveTicks &&
                !expansionMaterialFailure;

            if (
                expansionHoldActive != lastExpansionHoldActive ||
                (
                    expansionHoldActive &&
                    expansionSupportScore != lastExpansionHoldSupportScore
                )
            )
            {
                bool activeStateChanged =
                    expansionHoldActive != lastExpansionHoldActive;

                lastExpansionHoldActive =
                    expansionHoldActive;

                lastExpansionHoldSupportScore =
                    expansionSupportScore;

                if (activeStateChanged)
                {
                    PrintBotMessage(
                        expansionHoldActive
                            ? (
                                "EXPANSION HOLD ACTIVE"
                                + " | Mode: " + expansionHoldQualificationMode
                                + " | Side: " + localMarketPosition
                                + " | R20: " + sideMomentumScore + "/5"
                                + " | Opp: " + oppositeMomentumScoreForHold + "/5"
                                + " | Support: " + expansionSupportScore + "/4"
                                + " | L2Persist Same/Opp: "
                                + expansionSameSidePersistence + "/"
                                + expansionOppositePersistence
                                + " | Tape: " + expansionSignedTapeDelta.ToString("0")
                                + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                                + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                                + " | Management: BE ONLY / RETENTION DEFERRED"
                              )
                            : (
                                "EXPANSION HOLD RELEASED"
                                + " | Mode: " + expansionHoldQualificationMode
                                + " | Side: " + localMarketPosition
                                + " | R20: " + sideMomentumScore + "/5"
                                + " | Opp: " + oppositeMomentumScoreForHold + "/5"
                                + " | Support: " + expansionSupportScore + "/4"
                                + " | ConfirmAge: "
                                + expansionConfirmationAgeSeconds.ToString("0.0") + "s"
                                + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                                + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                                + " | Reason: "
                                + (
                                    peakFavorableTicks >= ExpansionHoldObjectiveTicks
                                        ? "20PT OBJECTIVE REACHED"
                                        : expansionHardMomentumFailure
                                            ? "HARD MOMENTUM REVERSAL"
                                            : expansionOppositeMicroFailure
                                                ? "OPPOSITE MICROSTRUCTURE CONFIRMED"
                                                : expansionStaleFailure
                                                    ? "CONFIRMATION STALE + GIVEBACK"
                                                    : "NO LONGER QUALIFIED"
                                  )
                                + " | Action: NORMAL MANAGEMENT RESUMED"
                              )
                    );
                }
                else
                {
                    PrintBotMessage(
                        "EXPANSION HOLD CONFIRMATION"
                        + " | Mode: " + expansionHoldQualificationMode
                        + " | Side: " + localMarketPosition
                        + " | Support: " + expansionSupportScore + "/4"
                        + " | R20: " + sideMomentumScore + "/5"
                        + " | Breakout: " + localSideBreakout
                        + " | Volume x" + localRangeVolumeRatio.ToString("0.00")
                        + " | L2: " + (expansionL2Support ? "SUPPORT" : "MIXED")
                        + " | Peak: " + peakFavorableTicks.ToString("0") + "t"
                        + " | Giveback: " + expansionGivebackTicks.ToString("0") + "t"
                    );
                }
            }

            bool missionM5Aligned =
                localMarketPosition == MarketPosition.Long
                    ? (localM5BullishTrend && localM5AboveVwap)
                    : (localM5BearishTrend && localM5BelowVwap);

            int missionHtfScore =
                localMarketPosition == MarketPosition.Long
                    ? localHtfLongScore
                    : localHtfShortScore;

            TryUpdateMissionModeTarget(
                currentPrice,
                localMarketPosition,
                localEntryFillPrice,
                localEntryQuantity,
                sideMomentumScore,
                missionHtfScore,
                missionM5Aligned,
                localSideBreakout,
                localRangeVolumeRatio,
                expansionL2Ready,
                expansionOppositePersistence,
                expansionSignedTapeDelta
            );

            // =====================================================
            // V1.6.95 - CENTRAL STOP ARBITER
            // =====================================================
            // Stop-management routes no longer fight over one mutable
            // desiredStop. Each family proposes its own stop:
            //
            // 1) TRADE PROTECTION  -> BE / LOCK / LOCK2 / TRAILING
            // 2) PROFIT PROTECTION -> RETENTION / GIVEBACK / FLOATING FLOOR
            // 3) DAILY CAPITAL     -> progressive Daily Target protection
            // 4) DEVELOPMENT       -> Expansion/Breathing may cap ONLY normal
            //                         Trade/Profit proposals while capital is
            //                         still in development.
            // 5) SAFETY            -> NeverWorsen + live-market validation.
            //
            // Hard Risk (initial SL / Daily Loss / Risk Flatten) remains
            // outside this arbiter and keeps its existing higher authority.
            double tradeProtectionStop =
                localActiveStopPrice;

            double profitProtectionStop =
                localActiveStopPrice;

            double dailyCapitalProtectionStop =
                0;

            double desiredStop =
                localActiveStopPrice;

            string winningStopAuthority =
                "ACTIVE_STOP";

            int desiredStage =
                localMomentumStage;

            // Stage 1: Profit-protected break-even.
            // V1.6.66: trigger is +30t and the stop protects +18t.
            if (
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                tradeProtectionStop =
                    (expansionHoldActive || globalBreathingRoomActive)
                        ? localEntryFillPrice
                        : (
                            localMarketPosition ==
                                MarketPosition.Long
                                ? localEntryFillPrice
                                    + MomentumFirstProtectionProfitTicks
                                    * tickSize
                                : localEntryFillPrice
                                    - MomentumFirstProtectionProfitTicks
                                    * tickSize
                          );

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                tradeProtectionStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Second staged profit lock
            if (
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumLock2TriggerTicks
            )
            {
                tradeProtectionStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLock2ProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLock2ProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        3
                    );
            }

            // Stage 4: Dynamic trailing
            if (
                !expansionHoldActive &&
                !globalBreathingRoomActive &&
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    tradeProtectionStop =
                        Math.Max(
                            tradeProtectionStop,
                            trailCandidate
                        );
                }
                else
                {
                    tradeProtectionStop =
                        Math.Min(
                            tradeProtectionStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    4;
            }

            // V1.6.23 Phase 2 - Profit Retention Manager.
            // Once a trade has produced meaningful MFE, protect a fraction
            // of the PEAK open PnL. This complements the fixed-tick stages
            // and is especially useful when a dynamic target is below the
            // +180t trailing trigger. Never-worsen below guarantees this
            // layer cannot loosen an existing stop.
            int desiredRetentionStage =
                localProfitRetentionStage;

            double desiredRetentionFactor = 0;

            bool intradayDrawdownMode =
                string.Equals(
                    activeDrawdownMode,
                    "INTRADAY",
                    StringComparison.OrdinalIgnoreCase
                );

            double tradeAgeSeconds =
                localTradeEntryUtc != DateTime.MinValue
                    ? Math.Max(0, (DateTime.UtcNow - localTradeEntryUtc).TotalSeconds)
                    : double.MaxValue;

            // V1.6.84 - GLOBAL RETENTION AUTHORITY.
            // Stage 1/2/3 Profit Retention and Profit Giveback are not allowed
            // to manage the stop before BOTH conditions are true for any trade:
            // 1) age >= 45s, and 2) peak MFE >= 1.25R.
            // Fixed momentum PROTECT/LOCK/LOCK2/TRAIL logic above remains live.
            bool globalRetentionGraceComplete =
                tradeAgeSeconds >= GlobalProfitRetentionGraceSeconds;

            double retentionStage1TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage1TriggerR
                    : ProfitRetentionStage1TriggerR;
            double retentionStage1Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage1Factor
                    : ProfitRetentionStage1Factor;
            double retentionStage2TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage2TriggerR
                    : ProfitRetentionStage2TriggerR;
            double retentionStage2Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage2Factor
                    : ProfitRetentionStage2Factor;
            double retentionStage3TriggerR =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage3TriggerR
                    : ProfitRetentionStage3TriggerR;
            double retentionStage3Factor =
                intradayDrawdownMode
                    ? IntradayProfitRetentionStage3Factor
                    : ProfitRetentionStage3Factor;

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0
            )
            {
                double peakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                bool globalRetentionEligible =
                    !expansionHoldActive &&
                    !globalBreathingRoomActive &&
                    globalRetentionGraceComplete &&
                    peakR >= GlobalProfitRetentionMinPeakR;

                if (!globalRetentionEligible)
                {
                    string deferredKey =
                        Math.Floor(tradeAgeSeconds / 5.0).ToString("0")
                        + "|" + Math.Floor(peakR * 10.0).ToString("0");

                    if (
                        deferredKey != lastGlobalRetentionDeferredLogKey ||
                        (DateTime.UtcNow - lastGlobalRetentionDeferredLogUtc).TotalSeconds >= 5.0
                    )
                    {
                        lastGlobalRetentionDeferredLogKey = deferredKey;
                        lastGlobalRetentionDeferredLogUtc = DateTime.UtcNow;

                        PrintBotMessage(
                            "PROFIT RETENTION DEFERRED"
                            + " | Age: " + tradeAgeSeconds.ToString("0.0") + "s"
                            + " | PeakR: " + peakR.ToString("0.00")
                            + " | Need: "
                            + GlobalProfitRetentionGraceSeconds.ToString("0") + "s + "
                            + GlobalProfitRetentionMinPeakR.ToString("0.00") + "R"
                        );
                    }
                }

                if (globalRetentionEligible && peakR >= retentionStage3TriggerR)
                {
                    desiredRetentionStage = 3;
                    desiredRetentionFactor = retentionStage3Factor;
                }
                else if (globalRetentionEligible && peakR >= retentionStage2TriggerR)
                {
                    desiredRetentionStage = 2;
                    desiredRetentionFactor = retentionStage2Factor;
                }
                else if (globalRetentionEligible && peakR >= retentionStage1TriggerR)
                {
                    desiredRetentionStage = 1;
                    desiredRetentionFactor = retentionStage1Factor;
                }

                if (desiredRetentionFactor > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars *
                        desiredRetentionFactor;

                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double retentionStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        if (localMarketPosition == MarketPosition.Long)
                            profitProtectionStop = Math.Max(profitProtectionStop, retentionStop);
                        else
                            profitProtectionStop = Math.Min(profitProtectionStop, retentionStop);
                    }
                }
            }

            // =====================================================
            // V1.6.96 - NEAR-TARGET PROTECTION (PROFIT_PROTECTION FAMILY)
            // =====================================================
            // Uses PEAK progress toward the currently-live target so the
            // protection remains armed even if price starts rebounding.
            //
            // Example:
            // 64t TP -> activation at 60.8t peak (95%).
            // At activation, retain 90% of peak MFE.
            //
            // This bypasses normal Retention grace/breathing ONLY because
            // the trade has already completed almost the entire objective.
            // Final Stop Arbiter + NeverWorsen + live-price safety still apply.
            if (
                localActiveTargetPrice > 0 &&
                localPeakPnlDollars > 0 &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double liveTargetDistanceTicks =
                    Math.Abs(
                        localActiveTargetPrice -
                        localEntryFillPrice
                    ) / tickSize;

                if (
                    liveTargetDistanceTicks >= NearTargetMinTargetTicks &&
                    peakFavorableTicks >=
                        liveTargetDistanceTicks *
                        NearTargetActivationFactor
                )
                {
                    double nearTargetProtectedDollars =
                        localPeakPnlDollars *
                        NearTargetRetentionFactor;

                    double nearTargetProtectedPoints =
                        nearTargetProtectedDollars /
                        (
                            pointValueForTradeIntelligence *
                            localEntryQuantity
                        );

                    double nearTargetStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + nearTargetProtectedPoints
                            : localEntryFillPrice - nearTargetProtectedPoints;

                    nearTargetStop =
                        RoundToInstrumentTick(
                            nearTargetStop
                        );

                    if (localMarketPosition == MarketPosition.Long)
                        profitProtectionStop =
                            Math.Max(
                                profitProtectionStop,
                                nearTargetStop
                            );
                    else
                        profitProtectionStop =
                            Math.Min(
                                profitProtectionStop,
                                nearTargetStop
                            );

                    double targetProgress =
                        liveTargetDistanceTicks > 0
                            ? peakFavorableTicks /
                              liveTargetDistanceTicks
                            : 0;

                    string nearTargetLogKey =
                        localMarketPosition
                        + "|" + localActiveTargetPrice.ToString("0.00")
                        + "|" + Math.Floor(targetProgress * 100.0).ToString("0")
                        + "|" + nearTargetStop.ToString("0.00");

                    DateTime nearTargetNowUtc =
                        DateTime.UtcNow;

                    if (
                        !string.Equals(
                            nearTargetLogKey,
                            lastNearTargetProtectionLogKey,
                            StringComparison.Ordinal
                        ) ||
                        lastNearTargetProtectionLogUtc == DateTime.MinValue ||
                        (nearTargetNowUtc - lastNearTargetProtectionLogUtc)
                            .TotalMilliseconds >=
                                NearTargetProtectionLogThrottleMs
                    )
                    {
                        lastNearTargetProtectionLogKey =
                            nearTargetLogKey;

                        lastNearTargetProtectionLogUtc =
                            nearTargetNowUtc;

                        PrintBotMessage(
                            "NEAR TARGET PROTECTION"
                            + " | Progress: "
                            + (targetProgress * 100.0).ToString("0.0")
                            + "%"
                            + " | Peak: "
                            + localPeakPnlDollars.ToString("$0.00")
                            + " | Retain: "
                            + (NearTargetRetentionFactor * 100.0).ToString("0")
                            + "%"
                            + " | Target: "
                            + localActiveTargetPrice.ToString("0.00")
                            + " | StopProposal: "
                            + nearTargetStop.ToString("0.00")
                            + " | Authority: PROFIT_PROTECTION"
                        );
                    }
                }
            }

            // =====================================================
            // V1.6.94 - PROGRESSIVE DAILY CAPITAL AUTHORITY
            // =====================================================
            // One authority for meaningful DAILY progress. This replaces the
            // single 90% Pre-Secure threshold with progressive protection.
            //
            // IMPORTANT:
            // - Uses day PnL (realized + current open PnL), not trade MFE alone.
            // - Never loosens an existing stop.
            // - Hard DAILY TARGET flatten at 100% remains unchanged.
            // - This block intentionally runs before Giveback/Floating Floor;
            //   later layers may tighten MORE, but NeverWorsen prevents them
            //   from reducing this protected-day floor.
            if (
                localDailyTarget > 0 &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                currentTradePnlDollars > 0
            )
            {
                double currentDayTotal =
                    localBotDailyPnL +
                    currentTradePnlDollars;

                if (
                    currentDayTotal >= localDailyTarget * DailyCapitalStage1Progress &&
                    currentDayTotal < localDailyTarget
                )
                {
                    double dailyProgress =
                        currentDayTotal / localDailyTarget;

                    double protectedTargetFactor =
                        dailyProgress >= DailyCapitalStage4Progress
                            ? DailyCapitalStage4Floor
                            : dailyProgress >= DailyCapitalStage3Progress
                                ? DailyCapitalStage3Floor
                                : dailyProgress >= DailyCapitalStage2Progress
                                    ? DailyCapitalStage2Floor
                                    : DailyCapitalStage1Floor;

                    double desiredProtectedDay =
                        localDailyTarget * protectedTargetFactor;

                    double requiredOpenProfit =
                        Math.Max(
                            0,
                            desiredProtectedDay -
                            localBotDailyPnL
                        );

                    if (requiredOpenProfit > 0)
                    {
                        double protectedPoints =
                            requiredOpenProfit /
                            (
                                pointValueForTradeIntelligence *
                                localEntryQuantity
                            );

                        double dailyCapitalStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        dailyCapitalStop =
                            RoundToInstrumentTick(dailyCapitalStop);

                        dailyCapitalProtectionStop =
                            dailyCapitalStop;

                        PrintBotMessage(
                            "DAILY CAPITAL AUTHORITY"
                            + " | Progress: "
                            + (dailyProgress * 100.0).ToString("0")
                            + "%"
                            + " | DayTotal: "
                            + currentDayTotal.ToString("$0.00")
                            + " | Target: "
                            + localDailyTarget.ToString("$0.00")
                            + " | ProtectedDay: "
                            + desiredProtectedDay.ToString("$0.00")
                            + " | RequiredOpen: "
                            + requiredOpenProfit.ToString("$0.00")
                            + " | Stop: "
                            + dailyCapitalStop.ToString("0.00")
                        );
                    }
                }
            }

            // =====================================================
            // V1.6.23 Phase 9 - PROFIT GIVEBACK GUARD
            // =====================================================
            // Profit Retention tiers protect progressively larger peaks.
            // This extra layer reacts to the PATH of the trade: if a trade
            // already produced useful MFE but starts returning too much of
            // that peak, protect a conservative fraction before a full
            // reversal develops. It never loosens an existing stop.
            bool givebackGuardApplied = false;
            double givebackPercent = 0;
            double givebackPeakR = 0;
            double adaptiveGivebackTrigger =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardTriggerPercent
                    : ProfitGivebackGuardTriggerPercent;
            double adaptiveGivebackRetention =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardRetentionFactor
                    : ProfitGivebackGuardRetentionFactor;
            double activeGivebackMinPeakR =
                intradayDrawdownMode
                    ? IntradayProfitGivebackGuardMinPeakR
                    : ProfitGivebackGuardMinPeakR;
            string adaptiveGivebackMode = "BASE";

            // Snapshot Level 2 once for this management pass.
            // Same-side flow gets more breathing room; opposite flow tightens
            // protection sooner. L2 never loosens an already protected stop.
            bool l2ReadySnapshot = false;
            int sameSidePersistenceSnapshot = 0;
            int oppositePersistenceSnapshot = 0;
            double tapeDeltaSnapshot = 0;
            string absorptionSnapshot = "NONE";

            lock (level2Sync)
            {
                l2ReadySnapshot =
                    level2ObserveActive &&
                    level2BookReady;

                tapeDeltaSnapshot =
                    level2TapeDelta;

                absorptionSnapshot =
                    level2Absorption;

                if (localMarketPosition == MarketPosition.Long)
                {
                    sameSidePersistenceSnapshot = level2LongPersistence;
                    oppositePersistenceSnapshot = level2ShortPersistence;
                }
                else
                {
                    sameSidePersistenceSnapshot = level2ShortPersistence;
                    oppositePersistenceSnapshot = level2LongPersistence;
                }
            }

            if (l2ReadySnapshot)
            {
                double signedTapeDelta =
                    localMarketPosition == MarketPosition.Long
                        ? tapeDeltaSnapshot
                        : -tapeDeltaSnapshot;

                bool sameSideAbsorptionRisk =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool oppositeAbsorptionSignal =
                    localMarketPosition == MarketPosition.Long
                        ? string.Equals(
                            absorptionSnapshot,
                            "BUY ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          )
                        : string.Equals(
                            absorptionSnapshot,
                            "SELL ABSORB CANDIDATE",
                            StringComparison.OrdinalIgnoreCase
                          );

                bool strongSameSideL2 =
                    sameSidePersistenceSnapshot >=
                        ProfitGivebackL2SupportPersistence &&
                    signedTapeDelta >=
                        ProfitGivebackL2MinDelta &&
                    !sameSideAbsorptionRisk;

                bool strongOppositeL2 =
                    oppositePersistenceSnapshot >=
                        ProfitGivebackL2OppositePersistence ||
                    signedTapeDelta <=
                        -ProfitGivebackL2MinDelta ||
                    oppositeAbsorptionSignal;

                bool counterTrendContext =
                    localMarketPosition == MarketPosition.Long
                        ? (
                            localM5BearishTrend &&
                            localHtfShortScore > localHtfLongScore
                          )
                        : (
                            localM5BullishTrend &&
                            localHtfLongScore > localHtfShortScore
                          );

                if (strongOppositeL2)
                {
                    adaptiveGivebackMode = "L2 OPPOSITE";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2OppositeTriggerPercent
                            : ProfitGivebackL2OppositeTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2OppositeRetentionFactor
                            : ProfitGivebackL2OppositeRetentionFactor;
                }
                else if (counterTrendContext)
                {
                    adaptiveGivebackMode = "COUNTERTREND DEFENSE";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayCounterTrendGivebackTriggerPercent
                            : CounterTrendGivebackTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayCounterTrendGivebackRetentionFactor
                            : CounterTrendGivebackRetentionFactor;
                }
                else if (strongSameSideL2)
                {
                    adaptiveGivebackMode = "L2 SUPPORT";
                    adaptiveGivebackTrigger =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2SupportTriggerPercent
                            : ProfitGivebackL2SupportTriggerPercent;
                    adaptiveGivebackRetention =
                        intradayDrawdownMode
                            ? IntradayProfitGivebackL2SupportRetentionFactor
                            : ProfitGivebackL2SupportRetentionFactor;
                }
            }

            if (
                localInitialRiskDollars > 0 &&
                localPeakPnlDollars > 0 &&
                currentTradePnlDollars > 0
            )
            {
                givebackPeakR =
                    localPeakPnlDollars /
                    localInitialRiskDollars;

                double givebackDollars =
                    Math.Max(
                        0,
                        localPeakPnlDollars -
                        currentTradePnlDollars
                    );

                givebackPercent =
                    localPeakPnlDollars > 0
                        ? givebackDollars / localPeakPnlDollars
                        : 0;

                bool globalGivebackEligible =
                    !expansionHoldActive &&
                    !globalBreathingRoomActive &&
                    globalRetentionGraceComplete &&
                    givebackPeakR >= GlobalProfitRetentionMinPeakR;

                if (
                    globalGivebackEligible &&
                    givebackPeakR >= activeGivebackMinPeakR &&
                    givebackPercent >= adaptiveGivebackTrigger
                )
                {
                    double pointValue =
                        instrument.MasterInstrument.PointValue;

                    if (pointValue > 0 && localEntryQuantity > 0)
                    {
                        double protectedDollars =
                            localPeakPnlDollars *
                            adaptiveGivebackRetention;

                        double protectedPoints =
                            protectedDollars /
                            (pointValue * localEntryQuantity);

                        double givebackStop =
                            localMarketPosition == MarketPosition.Long
                                ? localEntryFillPrice + protectedPoints
                                : localEntryFillPrice - protectedPoints;

                        // Keep StopMarket on the valid side of current market.
                        if (localMarketPosition == MarketPosition.Long)
                            givebackStop = Math.Min(givebackStop, currentPrice - tickSize);
                        else
                            givebackStop = Math.Max(givebackStop, currentPrice + tickSize);

                        givebackStop =
                            RoundToInstrumentTick(givebackStop);

                        bool improvesCurrentStop =
                            localMarketPosition == MarketPosition.Long
                                ? givebackStop > localActiveStopPrice
                                : givebackStop < localActiveStopPrice;

                        if (improvesCurrentStop)
                        {
                            if (localMarketPosition == MarketPosition.Long)
                                profitProtectionStop = Math.Max(profitProtectionStop, givebackStop);
                            else
                                profitProtectionStop = Math.Min(profitProtectionStop, givebackStop);

                            givebackGuardApplied = true;
                        }
                    }
                }
            }

            // =====================================================
            // V1.6.92 - FLOATING PROFIT FLOOR / POST-SCALE FLOOR
            // =====================================================
            // INTRADAY: preserve the staged peak-PnL floor, with at least 65%
            // retained after Smart Scale-In once peak PnL reaches $120.
            // EOD: keep normal breathing room, but after Smart Scale-In do not
            // allow the enlarged position to surrender the entire favorable
            // excursion; preserve at least 60% of peak once peak >= $120.
            if (
                localPeakPnlDollars >= IntradayFloorStage1PeakDollars &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0
            )
            {
                double activeFloatingFloorFactor = 0;

                if (intradayDrawdownMode)
                {
                    activeFloatingFloorFactor =
                        localPeakPnlDollars >= IntradayFloorStage5PeakDollars
                            ? IntradayFloorStage5Factor
                            : localPeakPnlDollars >= IntradayFloorStage4PeakDollars
                                ? IntradayFloorStage4Factor
                                : localPeakPnlDollars >= IntradayFloorStage3PeakDollars
                                    ? IntradayFloorStage3Factor
                                    : localPeakPnlDollars >= IntradayFloorStage2PeakDollars
                                        ? IntradayFloorStage2Factor
                                        : IntradayFloorStage1Factor;

                    if (localSmartScaleInUsed)
                        activeFloatingFloorFactor = Math.Max(activeFloatingFloorFactor, PostScaleMinimumFloorFactor);
                }
                else if (localSmartScaleInUsed)
                {
                    activeFloatingFloorFactor = EodPostScaleMinimumFloorFactor;
                }

                if (activeFloatingFloorFactor > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars * activeFloatingFloorFactor;

                    double protectedPoints =
                        protectedDollars /
                        (pointValueForTradeIntelligence * localEntryQuantity);

                    double floatingFloorStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + protectedPoints
                            : localEntryFillPrice - protectedPoints;

                    if (localMarketPosition == MarketPosition.Long)
                        floatingFloorStop = Math.Min(floatingFloorStop, currentPrice - tickSize);
                    else
                        floatingFloorStop = Math.Max(floatingFloorStop, currentPrice + tickSize);

                    floatingFloorStop = RoundToInstrumentTick(floatingFloorStop);

                    if (localMarketPosition == MarketPosition.Long)
                        profitProtectionStop = Math.Max(profitProtectionStop, floatingFloorStop);
                    else
                        profitProtectionStop = Math.Min(profitProtectionStop, floatingFloorStop);
                }
            }

            // =====================================================
            // V1.6.92 - SESSION-ADAPTIVE POST-SCALE BREATHING ROOM
            // =====================================================
            // This is management-only. It does not grant Scale-In eligibility,
            // alter entries or increase risk. It only prevents NEW post-scale
            // stop improvements from becoming too close to live price because
            // a dollar/percentage floor compresses when quantity is large.
            //
            // Daily Target Pre-Secure and material opposite reversal retain
            // authority and may tighten more aggressively. Never-worsen below
            // guarantees this layer never moves an already-protected stop back.
            if (
                localSmartScaleInUsed &&
                pointValueForTradeIntelligence > 0 &&
                localEntryQuantity > 0 &&
                currentTradePnlDollars > 0
            )
            {
                bool m5ContinuationAligned =
                    localMarketPosition == MarketPosition.Long
                        ? (localM5BullishTrend && localM5AboveVwap)
                        : (localM5BearishTrend && localM5BelowVwap);

                int currentHtfScore =
                    localMarketPosition == MarketPosition.Long
                        ? localHtfLongScore
                        : localHtfShortScore;

                bool strongContinuation =
                    sideMomentumScore >= 4 &&
                    currentHtfScore >= 1 &&
                    m5ContinuationAligned &&
                    (
                        localSideBreakout ||
                        localRangeVolumeRatio >= MissionModeMinVolumeRatio
                    ) &&
                    !expansionHardMomentumFailure &&
                    !expansionOppositeMicroFailure;

                bool exceptionalContinuation =
                    strongContinuation &&
                    localSideBreakout &&
                    localRangeVolumeRatio >= 1.50 &&
                    expansionL2Support;

                bool weakContinuation =
                    sideMomentumScore <= 2 ||
                    !m5ContinuationAligned ||
                    expansionSupportScore <= 1;

                string adaptiveSessionName;
                double adaptiveRoomPoints =
                    GetSessionAdaptivePostScaleBreathingRoomPoints(
                        strongContinuation,
                        exceptionalContinuation,
                        weakContinuation,
                        out adaptiveSessionName
                    );

                double currentDayTotalForAdaptive =
                    localBotDailyPnL + currentTradePnlDollars;

                bool dailyPreSecureOwns =
                    localDailyTarget > 0 &&
                    currentDayTotalForAdaptive >=
                        localDailyTarget * DailyCapitalStage1Progress;

                bool materialReversalOwns =
                    expansionHardMomentumFailure ||
                    expansionOppositeMicroFailure;

                if (!dailyPreSecureOwns && !materialReversalOwns)
                {
                    double adaptiveBoundary =
                        localMarketPosition == MarketPosition.Long
                            ? currentPrice - adaptiveRoomPoints
                            : currentPrice + adaptiveRoomPoints;

                    adaptiveBoundary =
                        RoundToInstrumentTick(adaptiveBoundary);

                    // DEVELOPMENT authority may give normal management
                    // more room, but it can NEVER loosen Daily Capital.
                    if (localMarketPosition == MarketPosition.Long)
                    {
                        tradeProtectionStop =
                            Math.Min(
                                tradeProtectionStop,
                                adaptiveBoundary
                            );

                        profitProtectionStop =
                            Math.Min(
                                profitProtectionStop,
                                adaptiveBoundary
                            );
                    }
                    else
                    {
                        tradeProtectionStop =
                            Math.Max(
                                tradeProtectionStop,
                                adaptiveBoundary
                            );

                        profitProtectionStop =
                            Math.Max(
                                profitProtectionStop,
                                adaptiveBoundary
                            );
                    }

                    string adaptiveLogKey =
                        adaptiveSessionName
                        + "|" + adaptiveRoomPoints.ToString("0.0")
                        + "|" + (strongContinuation ? "STRONG" : weakContinuation ? "WEAK" : "NORMAL")
                        + "|" + localEntryQuantity
                        + "|" + Math.Floor(currentTradePnlDollars / 25.0).ToString("0");

                    DateTime adaptiveNowUtc = DateTime.UtcNow;

                    if (
                        !string.Equals(
                            adaptiveLogKey,
                            lastAdaptiveBreathingLogKey,
                            StringComparison.Ordinal
                        ) ||
                        lastAdaptiveBreathingLogUtc == DateTime.MinValue ||
                        (adaptiveNowUtc - lastAdaptiveBreathingLogUtc).TotalSeconds >= 10.0
                    )
                    {
                        lastAdaptiveBreathingLogKey = adaptiveLogKey;
                        lastAdaptiveBreathingLogUtc = adaptiveNowUtc;

                        PrintBotMessage(
                            "SESSION ADAPTIVE BREATHING"
                            + " | Session: " + adaptiveSessionName
                            + " | Room: " + adaptiveRoomPoints.ToString("0.0") + "pt"
                            + " | Continuation: "
                            + (exceptionalContinuation ? "EXCEPTIONAL"
                                : strongContinuation ? "STRONG"
                                : weakContinuation ? "WEAK"
                                : "NORMAL")
                            + " | Qty: " + localEntryQuantity
                            + " | Peak: " + localPeakPnlDollars.ToString("$0.00")
                            + " | Open: " + currentTradePnlDollars.ToString("$0.00")
                            + " | Boundary: " + adaptiveBoundary.ToString("0.00")
                        );
                    }
                }
            }

            // =====================================================
            // V1.6.23 Phase 3 - ACTIVE TRADE REVERSAL GUARD
            // =====================================================
            // This is protection, not a reversal-entry engine. A trade must
            // first have meaningful positive MFE. Then a multi-factor opposite
            // context (structure/trend/VWAP/momentum) may tighten the stop to
            // retain part of peak open profit. NeverWorsen + market-side cap
            // ensure the stop cannot move backwards or cross the market.
            // V1.6.64 - Explosion Mode: M5/VWAP/Structure are no longer
            // management authority. Profit Retention + L2 Profit Giveback remain
            // active and are the fast exit/protection layers. Legacy reversal
            // context is computed below for diagnostics only and cannot tighten
            // the stop.
            bool reversalGuardApplied = false;
            bool legacyContextReversalAuthorityEnabled = false;
            int reversalContextScore = 0;
            int oppositeMomentumScore = 0;
            int sameSideMomentumScore = 0;

            if (localMarketPosition == MarketPosition.Long)
            {
                if (localM5BearishStructure) reversalContextScore += 2;
                if (localM5BearishTrend) reversalContextScore += 1;
                if (localM5BelowVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeShortScore;
                sameSideMomentumScore = localRangeLongScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }
            else if (localMarketPosition == MarketPosition.Short)
            {
                if (localM5BullishStructure) reversalContextScore += 2;
                if (localM5BullishTrend) reversalContextScore += 1;
                if (localM5AboveVwap) reversalContextScore += 1;

                oppositeMomentumScore = localRangeLongScore;
                sameSideMomentumScore = localRangeShortScore;

                if (
                    oppositeMomentumScore >= ReversalGuardMinOppositeMomentumScore &&
                    oppositeMomentumScore >= sameSideMomentumScore + 2
                )
                {
                    reversalContextScore += 2;
                }
            }

            double peakRForReversal =
                localInitialRiskDollars > 0
                    ? localPeakPnlDollars / localInitialRiskDollars
                    : 0;

            if (
                legacyContextReversalAuthorityEnabled &&
                favorableTicks >= ReversalGuardMinFavorableTicks &&
                peakRForReversal >= ReversalGuardMinPeakR &&
                reversalContextScore >= ReversalGuardMinContextScore &&
                localPeakPnlDollars > 0
            )
            {
                double pointValue = instrument.MasterInstrument.PointValue;

                if (pointValue > 0 && localEntryQuantity > 0)
                {
                    double protectedDollars =
                        localPeakPnlDollars * ReversalGuardPeakRetentionFactor;

                    double protectedPoints =
                        protectedDollars / (pointValue * localEntryQuantity);

                    double reversalStop =
                        localMarketPosition == MarketPosition.Long
                            ? localEntryFillPrice + protectedPoints
                            : localEntryFillPrice - protectedPoints;

                    // A StopMarket must remain on the valid side of market.
                    if (localMarketPosition == MarketPosition.Long)
                        reversalStop = Math.Min(reversalStop, currentPrice - tickSize);
                    else
                        reversalStop = Math.Max(reversalStop, currentPrice + tickSize);

                    reversalStop = RoundToInstrumentTick(reversalStop);

                    bool improvesCurrentStop =
                        localMarketPosition == MarketPosition.Long
                            ? reversalStop > localActiveStopPrice
                            : reversalStop < localActiveStopPrice;

                    if (improvesCurrentStop)
                    {
                        if (localMarketPosition == MarketPosition.Long)
                            profitProtectionStop = Math.Max(profitProtectionStop, reversalStop);
                        else
                            profitProtectionStop = Math.Min(profitProtectionStop, reversalStop);

                        reversalGuardApplied = true;
                    }
                }
            }

            // =====================================================
            // V1.6.95 - SINGLE FINAL STOP DECISION
            // =====================================================
            // Select the most protective VALID proposal. No management family
            // can loosen another family here. Daily Capital bypasses Breathing,
            // while Trade/Profit may still propose a tighter stop.
            desiredStop =
                localActiveStopPrice;

            if (localMarketPosition == MarketPosition.Long)
            {
                if (tradeProtectionStop > desiredStop)
                {
                    desiredStop = tradeProtectionStop;
                    winningStopAuthority = "TRADE_PROTECTION";
                }

                if (profitProtectionStop > desiredStop)
                {
                    desiredStop = profitProtectionStop;
                    winningStopAuthority = "PROFIT_PROTECTION";
                }

                if (
                    dailyCapitalProtectionStop > 0 &&
                    dailyCapitalProtectionStop > desiredStop
                )
                {
                    desiredStop = dailyCapitalProtectionStop;
                    winningStopAuthority = "DAILY_CAPITAL";
                }
            }
            else
            {
                if (tradeProtectionStop < desiredStop)
                {
                    desiredStop = tradeProtectionStop;
                    winningStopAuthority = "TRADE_PROTECTION";
                }

                if (profitProtectionStop < desiredStop)
                {
                    desiredStop = profitProtectionStop;
                    winningStopAuthority = "PROFIT_PROTECTION";
                }

                if (
                    dailyCapitalProtectionStop > 0 &&
                    dailyCapitalProtectionStop < desiredStop
                )
                {
                    desiredStop = dailyCapitalProtectionStop;
                    winningStopAuthority = "DAILY_CAPITAL";
                }
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // V1.6.23 Phase 12 - FINAL UNIVERSAL STOP SAFETY.
            // Every protection layer (BE, locks, trailing, Profit Retention,
            // Giveback Guard, Reversal Guard) merges into desiredStop.
            // Validate the FINAL value immediately before Account.Change().
            double safeBoundary =
                localMarketPosition == MarketPosition.Long
                    ? currentPrice - tickSize
                    : currentPrice + tickSize;

            safeBoundary =
                RoundToInstrumentTick(
                    safeBoundary
                );

            if (localMarketPosition == MarketPosition.Long)
            {
                desiredStop =
                    Math.Min(
                        desiredStop,
                        safeBoundary
                    );
            }
            else
            {
                desiredStop =
                    Math.Max(
                        desiredStop,
                        safeBoundary
                    );
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // V1.6.73 - Revalidate against the freshest live bid/ask.
            // The prior currentPrice safety clamp can become stale by the time
            // Account.Change() is submitted during a fast move.
            double stopBeforeLivePriceSafety =
                desiredStop;

            bool liveStopAdjusted;
            bool liveStopUsedLevel2;
            double liveStopReferencePrice;

            desiredStop =
                ClampProtectiveStopToLiveMarket(
                    localMarketPosition,
                    desiredStop,
                    currentPrice,
                    tickSize,
                    out liveStopAdjusted,
                    out liveStopUsedLevel2,
                    out liveStopReferencePrice
                );

            if (liveStopAdjusted)
            {
                string protectiveSafetyLogKey =
                    localMarketPosition
                    + "|" + stopBeforeLivePriceSafety.ToString("0.00")
                    + "|" + desiredStop.ToString("0.00")
                    + "|" + liveStopReferencePrice.ToString("0.00")
                    + "|" + (liveStopUsedLevel2 ? "L2" : "LAST");

                DateTime protectiveSafetyNowUtc = DateTime.UtcNow;

                if (
                    !string.Equals(
                        protectiveSafetyLogKey,
                        lastProtectiveStopSafetyLogKey,
                        StringComparison.Ordinal
                    ) ||
                    lastProtectiveStopSafetyLogUtc == DateTime.MinValue ||
                    (protectiveSafetyNowUtc - lastProtectiveStopSafetyLogUtc)
                        .TotalMilliseconds >= ProtectiveStopSafetyLogThrottleMs
                )
                {
                    lastProtectiveStopSafetyLogKey = protectiveSafetyLogKey;
                    lastProtectiveStopSafetyLogUtc = protectiveSafetyNowUtc;

                    PrintBotMessage(
                        "PROTECTIVE STOP PRICE SAFETY"
                        + " | Side: " + localMarketPosition
                        + " | Requested: "
                        + stopBeforeLivePriceSafety.ToString("0.00")
                        + " | Adjusted: "
                        + desiredStop.ToString("0.00")
                        + " | Ref: "
                        + liveStopReferencePrice.ToString("0.00")
                        + " | Source: "
                        + (liveStopUsedLevel2 ? "LEVEL2" : "LAST_PRICE")
                        + " | Buffer: 2t"
                    );
                }
            }

            // The safety clamp may remove the improvement if price moved
            // through the requested stop while the calculation was running.
            bool finalStopStillImproves =
                localMarketPosition == MarketPosition.Long
                    ? desiredStop > localActiveStopPrice
                    : desiredStop < localActiveStopPrice;

            if (!finalStopStillImproves)
                return;

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                // V8:
                // Reserve the improved stop immediately. This closes the
                // race where OrderUpdate/OCO Sync could still see the old
                // activeStopPrice and restore the original protective SL.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                PrintBotMessage(
                    "STOP ARBITER"
                    + " | Authority: " + winningStopAuthority
                    + " | Trade: " + tradeProtectionStop.ToString("0.00")
                    + " | Profit: " + profitProtectionStop.ToString("0.00")
                    + " | Daily: "
                    + (dailyCapitalProtectionStop > 0
                        ? dailyCapitalProtectionStop.ToString("0.00")
                        : "NONE")
                    + " | Final: " + desiredStop.ToString("0.00")
                );

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                if (givebackGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeGivebackGuardArmed;
                            activeGivebackGuardArmed = true;
                        }
                    }

                    string givebackKey =
                        localMarketPosition.ToString()
                        + "|" + Math.Round(givebackPercent * 100.0).ToString("0")
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || givebackKey != lastGivebackGuardLogKey)
                    {
                        lastGivebackGuardLogKey = givebackKey;

                        PrintBotMessage(
                            "PROFIT GIVEBACK GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | PeakR: " + givebackPeakR.ToString("0.00")
                            + " | Giveback: " + (givebackPercent * 100.0).ToString("0") + "%"
                            + " | Mode: " + adaptiveGivebackMode
                            + " | RetainPeak: "
                            + (adaptiveGivebackRetention * 100.0).ToString("0") + "%"
                            + " | Trigger: "
                            + (adaptiveGivebackTrigger * 100.0).ToString("0") + "%"
                            + " | L2 Same/Opp: "
                            + sameSidePersistenceSnapshot + "/"
                            + oppositePersistenceSnapshot
                            + " | TapeDelta: "
                            + tapeDeltaSnapshot.ToString("0")
                            + " | Abs: " + absorptionSnapshot
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                if (reversalGuardApplied)
                {
                    bool firstArm = false;

                    lock (executionStateLock)
                    {
                        if (ReferenceEquals(stopOrder, localStopOrder))
                        {
                            firstArm = !activeReversalGuardArmed;
                            activeReversalGuardArmed = true;
                        }
                    }

                    string reversalKey =
                        localMarketPosition.ToString()
                        + "|" + reversalContextScore
                        + "|" + desiredStop.ToString("0.00");

                    if (firstArm || reversalKey != lastReversalGuardLogKey)
                    {
                        lastReversalGuardLogKey = reversalKey;

                        PrintBotMessage(
                            "REVERSAL GUARD ARMED"
                            + " | Trade: " + localMarketPosition
                            + " | ContextScore: " + reversalContextScore
                            + " | OppMomentum: " + oppositeMomentumScore + "/5"
                            + " | PeakR: " + peakRForReversal.ToString("0.00")
                            + " | RetainPeak: "
                            + (ReversalGuardPeakRetentionFactor * 100.0).ToString("0") + "%"
                            + " | New SL: " + desiredStop.ToString("0.00")
                        );
                    }
                }

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                bool retentionAdvanced = false;
                double retentionFactorApplied = 0;
                double retentionPeakPnl = 0;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(stopOrder, localStopOrder) &&
                        desiredRetentionStage > activeProfitRetentionStage
                    )
                    {
                        activeProfitRetentionStage = desiredRetentionStage;
                        activeProfitRetentionFactor = desiredRetentionFactor;
                        retentionAdvanced = true;
                        retentionFactorApplied = desiredRetentionFactor;
                        retentionPeakPnl = activeTradePeakPnlDollars;
                    }
                }

                if (retentionAdvanced)
                {
                    PrintBotMessage(
                        "PROFIT RETENTION STAGE "
                        + desiredRetentionStage
                        + " | Peak: "
                        + retentionPeakPnl.ToString("$0.00")
                        + " | Retain: "
                        + (retentionFactorApplied * 100.0).ToString("0")
                        + "%"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? (
                                (expansionHoldActive || globalBreathingRoomActive)
                                    ? "BREATHING ROOM BE"
                                    : localStrongMomentumProtection
                                        ? "ADAPTIVE BREAK EVEN"
                                        : "PROFIT PROTECT"
                              )
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : desiredStage == 3
                                    ? "LOCK PROFIT 2"
                                    : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private bool CanOpeningScaleIn(
            double favorableTicks,
            int currentQty,
            out string reason)
        {
            reason = "NOT FAST OPEN";
            if (!activeTradeIsOpening)
                return true; // Existing non-opening Smart Scale-In behavior is preserved.

            if (!string.Equals(
                activeTradeEntryRoute,
                "FAST_OPEN",
                StringComparison.OrdinalIgnoreCase))
            {
                reason = "OPENING ROUTE IS NOT FAST_OPEN";
                return false;
            }

            if (favorableTicks <= 0)
            {
                reason = "POSITION NOT FAVORABLE";
                return false;
            }

            int maxContracts = Math.Max(1, Math.Min(MaxContractsAllowed, openingScaleInMaxContracts));
            if (currentQty >= maxContracts)
            {
                reason = "USER/RISK MAX CONTRACTS REACHED";
                return false;
            }

            if (dailyTargetProtectionArmed)
            {
                reason = "DAILY TARGET PROTECTION ACTIVE";
                return false;
            }

            reason = "FAVORABLE OPENING CONTINUATION ELIGIBLE";
            return true;
        }

        private int GetSmartScaleInRequiredTicks(
            int baseQty,
            int currentQty)
        {
            int addsCompleted =
                Math.Max(0, currentQty - baseQty);

            switch (addsCompleted)
            {
                case 0:
                    return SmartScaleInTriggerTicks;
                case 1:
                    return SmartScaleInTrigger2Ticks;
                case 2:
                    return SmartScaleInTrigger3Ticks;
                case 3:
                    return SmartScaleInTrigger4Ticks;
                default:
                    return SmartScaleInTrigger5Ticks;
            }
        }

        private void TrySmartScaleIn(
            double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                !smartScaleInEnabled ||
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            MarketPosition side;
            double entryPrice;
            double stopPrice;
            int currentQty;
            int baseQty;
            double initialRisk;
            bool manualTrade;
            bool scalePending;
            bool targetProtection;
            bool entryIsPending;
            bool openingTrade;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                entryPrice = entryFillPrice;
                stopPrice = activeStopPrice;

                currentQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                baseQty = initialTradeQuantity;
                initialRisk = initialTradeRiskDollars;
                manualTrade = activeTradeIsManualTest;
                scalePending = smartScaleInPending;
                targetProtection = dailyTargetProtectionArmed;
                entryIsPending = entryPending;
                openingTrade = activeTradeIsOpening;
            }

            if (
                side == MarketPosition.Flat ||
                entryPrice <= 0 ||
                stopPrice <= 0 ||
                currentQty <= 0 ||
                baseQty <= 0 ||
                initialRisk <= 0 ||
                manualTrade ||
                scalePending ||
                targetProtection ||
                entryIsPending
            )
            {
                return;
            }

            int configuredMaxContracts =
                Math.Max(
                    baseQty,
                    Math.Min(
                        MaxContractsAllowed,
                        openingScaleInMaxContracts
                    )
                );

            if (
                currentQty + SmartScaleInContracts >
                    configuredMaxContracts
            )
            {
                return;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double scaleAnchorPrice =
                smartScaleInAnchorEntryPrice > 0
                    ? smartScaleInAnchorEntryPrice
                    : entryPrice;

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - scaleAnchorPrice) / tickSize
                    : (scaleAnchorPrice - currentPrice) / tickSize;

            string openingScaleReason;
            if (!CanOpeningScaleIn(favorableTicks, currentQty, out openingScaleReason))
                return;

            double requiredScaleInTicks =
                GetSmartScaleInRequiredTicks(
                    baseQty,
                    currentQty
                );

            if (favorableTicks < requiredScaleInTicks)
            {
                return;
            }

            // V1.6.23 Phase 6 audit fix - the +70t scale trigger must be
            // reachable before the fixed +100t / +30t profit-lock stage.
            // Require BREAK-EVEN OR BETTER here, then let the existing atomic
            // worst-case risk calculation prove that adding size cannot exceed
            // the original trade risk / Dollar Risk Cap.
            double lockStop = entryPrice;

            bool stopProtected =
                side == MarketPosition.Long
                    ? stopPrice >=
                        lockStop - tickSize * 0.5
                    : stopPrice <=
                        lockStop + tickSize * 0.5;

            if (!stopProtected)
            {
                return;
            }

            int momentumScore;
            int oppositeMomentumScore;
            int htfScore;
            bool m5Aligned;

            lock (marketContextLock)
            {
                momentumScore =
                    side == MarketPosition.Long
                        ? latestRangeLongScore
                        : latestRangeShortScore;

                oppositeMomentumScore =
                    side == MarketPosition.Long
                        ? latestRangeShortScore
                        : latestRangeLongScore;

                htfScore =
                    side == MarketPosition.Long
                        ? latestHtfLongScore
                        : latestHtfShortScore;

                m5Aligned =
                    side == MarketPosition.Long
                        ? (latestM5BullishTrend && latestM5AboveVwap)
                        : (latestM5BearishTrend && latestM5BelowVwap);
            }

            if (
                momentumScore <
                    SmartScaleInMinMomentumScore ||
                htfScore <
                    SmartScaleInMinHtfScore
            )
            {
                return;
            }

            // V1.6.23 Phase 5 - CONTINUATION-ONLY SCALE-IN.
            // Adding size is more selective than the original entry:
            // 1) never add during RANGE,
            // 2) regime/pressure cannot point against the open trade,
            // 3) opposite R20 momentum must be quiet,
            // 4) M5 trend + VWAP must still support the trade.
            int pressureLongScore;
            int pressureShortScore;
            string pressure = EvaluateDirectionalPressure(
                out pressureLongScore,
                out pressureShortScore
            );

            string regimeDirection;
            string regimeReason;
            string regime = EvaluateMarketRegime(
                out regimeDirection,
                out regimeReason
            );

            string sideText =
                side == MarketPosition.Long ? "LONG" : "SHORT";

            bool pressureAgainst =
                (side == MarketPosition.Long && pressure == "SHORT") ||
                (side == MarketPosition.Short && pressure == "LONG");

            bool regimeAgainst =
                (side == MarketPosition.Long && regimeDirection == "SHORT") ||
                (side == MarketPosition.Short && regimeDirection == "LONG");

            bool contextBlocked =
                regime == "RANGE" ||
                pressureAgainst ||
                regimeAgainst ||
                !m5Aligned ||
                oppositeMomentumScore > SmartScaleInMaxOppMomentumScore;

            if (contextBlocked)
            {
                string blockKey =
                    sideText + "|" + regime + "|" + regimeDirection + "|" +
                    pressure + "|" + momentumScore + "|" + oppositeMomentumScore + "|" +
                    (m5Aligned ? "M5OK" : "M5NO");

                if (!string.Equals(
                    lastSmartScaleInContextBlockKey,
                    blockKey,
                    StringComparison.Ordinal))
                {
                    lastSmartScaleInContextBlockKey = blockKey;
                    PrintBotMessage(
                        "SMART SCALE-IN WAIT - CONTINUATION NOT CONFIRMED"
                        + " | Side: " + sideText
                        + " | Regime: " + regime + "/" + regimeDirection
                        + " | Pressure: " + pressure
                        + " | Momentum: " + momentumScore + "/5"
                        + " | Opp: " + oppositeMomentumScore + "/5"
                        + " | M5Aligned: " + m5Aligned
                    );
                }

                return;
            }

            lastSmartScaleInContextBlockKey = string.Empty;

            // Estimated worst-case PnL if the new contract fills
            // around currentPrice and the EXISTING stop is hit.
            double existingWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        entryPrice
                      )
                      * pointValue
                      * currentQty
                    : (
                        entryPrice -
                        stopPrice
                      )
                      * pointValue
                      * currentQty;

            double addedWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        currentPrice
                      )
                      * pointValue
                      * SmartScaleInContracts
                    : (
                        currentPrice -
                        stopPrice
                      )
                      * pointValue
                      * SmartScaleInContracts;

            double combinedWorstCase =
                existingWorstCase +
                addedWorstCase;

            double scaleInRiskLimit =
                Math.Min(
                    initialRisk,
                    activeDollarRiskCap > 0
                        ? activeDollarRiskCap
                        : initialRisk
                );

            if (
                combinedWorstCase <
                    -scaleInRiskLimit
            )
            {
                PrintBotMessage(
                    "SMART SCALE-IN BLOCKED - RISK CAP"
                    + " | WorstCase: "
                    + combinedWorstCase.ToString("$0.00")
                    + " | Limit: -"
                    + scaleInRiskLimit.ToString("$0.00")
                );

                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            // V1.6.12 - FINAL atomic revalidation immediately before
            // reserving the scale-in. The earlier snapshot is only a fast
            // eligibility check; fills/trailing may have changed quantity
            // or stop while momentum context was being evaluated.
            lock (executionStateLock)
            {
                if (
                    smartScaleInPending ||
                    entryPending ||
                    entryMarketPosition != side ||
                    activeTradeIsManualTest ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                int refreshedQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                double refreshedEntryPrice =
                    entryFillPrice;

                double refreshedStopPrice =
                    activeStopPrice;

                double refreshedInitialRisk =
                    initialTradeRiskDollars;

                if (
                    refreshedQty <= 0 ||
                    (refreshedQty != initialTradeQuantity && !activeTradeIsOpening) ||
                    refreshedEntryPrice <= 0 ||
                    refreshedStopPrice <= 0 ||
                    refreshedInitialRisk <= 0
                )
                {
                    return;
                }

                // Atomic revalidation uses the same BE-or-better rule.
                // The risk-cap computation below remains the final authority.
                double refreshedLockStop = refreshedEntryPrice;

                bool refreshedStopProtected =
                    side == MarketPosition.Long
                        ? refreshedStopPrice >=
                            refreshedLockStop - tickSize * 0.5
                        : refreshedStopPrice <=
                            refreshedLockStop + tickSize * 0.5;

                if (!refreshedStopProtected)
                {
                    return;
                }

                double refreshedExistingWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            refreshedEntryPrice
                          )
                          * pointValue
                          * refreshedQty
                        : (
                            refreshedEntryPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * refreshedQty;

                double refreshedAddedWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            currentPrice
                          )
                          * pointValue
                          * SmartScaleInContracts
                        : (
                            currentPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * SmartScaleInContracts;

                double refreshedCombinedWorstCase =
                    refreshedExistingWorstCase +
                    refreshedAddedWorstCase;

                double refreshedRiskLimit =
                    Math.Min(
                        refreshedInitialRisk,
                        activeDollarRiskCap > 0
                            ? activeDollarRiskCap
                            : refreshedInitialRisk
                    );

                if (
                    refreshedCombinedWorstCase <
                        -refreshedRiskLimit
                )
                {
                    return;
                }

                if (
                    lastSmartScaleInAttemptUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSmartScaleInAttemptUtc
                    ).TotalMilliseconds <
                        SmartScaleInAttemptThrottleMs
                )
                {
                    return;
                }

                if (
                    refreshedQty + SmartScaleInContracts >
                        configuredMaxContracts
                )
                {
                    return;
                }

                // Keep the values used by the submission/log consistent
                // with the final validated execution snapshot.
                entryPrice = refreshedEntryPrice;
                stopPrice = refreshedStopPrice;
                currentQty = refreshedQty;
                initialRisk = refreshedInitialRisk;

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = nowUtc;
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        SmartScaleInContracts,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (
                            entryMarketPosition != side
                    )
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(
                    new[]
                    {
                        scaleOrder
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN SUBMITTED"
                    + " | Side: "
                    + (
                        side == MarketPosition.Long
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Add: "
                    + SmartScaleInContracts
                    + " | Profit: "
                    + favorableTicks.ToString("0")
                    + " ticks"
                    + " | Momentum: "
                    + momentumScore
                    + "/5"
                    + " | HTF: "
                    + htfScore
                    + "/2"
                    + " | Regime: " + regime + "/" + regimeDirection
                    + " | Pressure: " + pressure
                    + " | OppMomentum: " + oppositeMomentumScore + "/5"
                    + " | InitialRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage(
                    "SMART SCALE-IN ERROR: "
                    + ex.Message
                );
            }
        }
        private void EnforceSmartScaleInRiskCap()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            Order localStop;
            MarketPosition side;
            double averageEntry;
            double currentStop;
            double currentMarketPrice;
            int openQty;
            double initialRisk;

            lock (executionStateLock)
            {
                if (
                    !smartScaleInUsed ||
                    entryMarketPosition ==
                        MarketPosition.Flat ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    initialTradeRiskDollars <= 0
                )
                {
                    return;
                }

                localStop = stopOrder;
                side = entryMarketPosition;
                averageEntry = entryFillPrice;
                currentStop = activeStopPrice;
                currentMarketPrice = activeTradeCurrentPrice;

                openQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                initialRisk =
                    initialTradeRiskDollars;
            }

            if (
                localStop == null ||
                openQty <= 0 ||
                currentStop <= 0
            )
            {
                return;
            }

            if (
                localStop.OrderState !=
                    OrderState.Working &&
                localStop.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (pointValue <= 0)
            {
                return;
            }

            double riskCapStop =
                side == MarketPosition.Long
                    ? averageEntry
                        - initialRisk
                        / (
                            pointValue
                            * openQty
                        )
                    : averageEntry
                        + initialRisk
                        / (
                            pointValue
                            * openQty
                        );

            riskCapStop =
                RoundToInstrumentTick(
                    riskCapStop
                );

            double desiredStop =
                side == MarketPosition.Long
                    ? Math.Max(
                        currentStop,
                        riskCapStop
                      )
                    : Math.Min(
                        currentStop,
                        riskCapStop
                      );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            // Phase 12 FIX: last-mile StopMarket validation for scale-in
            // risk cap using the active-trade market snapshot available in
            // this method.
            double scaleInTickSize =
                instrument.MasterInstrument.TickSize;

            if (
                currentMarketPrice > 0 &&
                scaleInTickSize > 0
            )
            {
                double scaleInSafeBoundary =
                    side == MarketPosition.Long
                        ? currentMarketPrice - scaleInTickSize
                        : currentMarketPrice + scaleInTickSize;

                scaleInSafeBoundary =
                    RoundToInstrumentTick(
                        scaleInSafeBoundary
                    );

                if (side == MarketPosition.Long)
                    desiredStop = Math.Min(desiredStop, scaleInSafeBoundary);
                else
                    desiredStop = Math.Max(desiredStop, scaleInSafeBoundary);

                desiredStop =
                    RoundToInstrumentTick(
                        desiredStop
                    );
            }

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > currentStop
                    : desiredStop < currentStop;

            if (!improves)
            {
                return;
            }

            long token;

            if (
                !TryBeginProtectiveChange(
                    "SMART_SCALE_IN_RISK",
                    out token
                )
            )
            {
                return;
            }

            try
            {
                lock (executionStateLock)
                {
                    if (
                        !ReferenceEquals(
                            stopOrder,
                            localStop
                        ) ||
                        entryMarketPosition != side
                    )
                    {
                        return;
                    }

                    activeStopPrice = desiredStop;
                    localStop.StopPriceChanged = desiredStop;
                }

                account.Change(
                    new[]
                    {
                        localStop
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP"
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                    + " | MaxRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    token
                );
            }
        }

    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT TRADE MANAGEMENT
    // Stage 10 structural extraction only.
    //
    // Existing target adaptation, protective bracket syncing,
    // partial-exit resize, never-worsen stop, momentum trailing,
    // Smart Scale-In and Scale-In risk-cap behavior are unchanged.
    //
    // No thresholds, prices, quantities, timing, OCO rules,
    // trailing rules, or risk calculations were modified.
    // =========================================================
    public partial class JJBotWindow
    {
        private int GetDynamicTargetTicks(
            MarketPosition marketPosition)
        {
            if (activeTargetTicks <= 0)
                return 1;

            int momentumScore = 0;
            int htfScore = 0;
            bool breakout = false;
            double volumeRatio = 0;

            lock (marketContextLock)
            {
                if (
                    marketPosition ==
                        MarketPosition.Long
                )
                {
                    momentumScore =
                        latestRangeLongScore;

                    htfScore =
                        latestHtfLongScore;

                    breakout =
                        latestRangeHighBreakout;
                }
                else
                {
                    momentumScore =
                        latestRangeShortScore;

                    htfScore =
                        latestHtfShortScore;

                    breakout =
                        latestRangeLowBreakout;
                }

                volumeRatio =
                    latestRangeVolumeRatio;
            }

            int minimumTicks =
                Math.Min(
                    DynamicTargetMinTicks,
                    activeTargetTicks
                );

            int targetTicks;

            if (
                momentumScore >= 4 &&
                breakout &&
                htfScore >= 1
            )
            {
                // Strong move: allow the full configured target.
                targetTicks =
                    activeTargetTicks;
            }
            else if (
                momentumScore >= 3 &&
                (
                    breakout ||
                    volumeRatio >=
                        MomentumVolumeExpansion
                )
            )
            {
                // Medium move: reduce target to 80%.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetMediumFactor
                    );
            }
            else
            {
                // Weak/slow move: take profit sooner.
                targetTicks =
                    (int)Math.Round(
                        activeTargetTicks *
                        DynamicTargetWeakFactor
                    );
            }

            targetTicks =
                Math.Max(
                    minimumTicks,
                    Math.Min(
                        activeTargetTicks,
                        targetTicks
                    )
                );

            PrintBotMessage(
                "DYNAMIC TARGET"
                + " | Momentum: "
                + momentumScore
                + "/5"
                + " | HTF: "
                + htfScore
                + "/2"
                + " | Breakout: "
                + breakout
                + " | Volume x"
                + volumeRatio.ToString("0.00")
                + " | TP: "
                + targetTicks
                + " ticks"
                + " | MaxCfg: "
                + activeTargetTicks
                + " ticks"
            );

            return targetTicks;
        }
        private void SyncProtectiveBracketToEntry(
            double averageEntryPrice,
            int openQuantity,
            MarketPosition marketPosition)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                !IsSimulationAccount(
                    account
                ) ||
                averageEntryPrice <= 0 ||
                openQuantity <= 0 ||
                marketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;
            int localEffectiveTargetTicks;

            lock (executionStateLock)
            {
                // Prevent recursive bracket creation caused by synchronous
                // OrderUpdate callbacks during Account.CreateOrder/Submit.
                if (protectiveBracketBuildInProgress)
                {
                    return;
                }

                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;

                localEffectiveTargetTicks =
                    activeEffectiveTargetTicks;
            }

            if (
                localStop == null ||
                localTarget == null
            )
            {
                SubmitProtectiveBracket(
                    averageEntryPrice,
                    openQuantity,
                    marketPosition
                );

                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            if (localEffectiveTargetTicks <= 0)
            {
                localEffectiveTargetTicks =
                    activeTargetTicks;
            }

            double desiredStop;
            double desiredTarget;

            if (
                marketPosition ==
                    MarketPosition.Long
            )
            {
                desiredStop =
                    averageEntryPrice
                    - activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    + localEffectiveTargetTicks
                    * tickSize;
            }
            else
            {
                desiredStop =
                    averageEntryPrice
                    + activeStopTicks
                    * tickSize;

                desiredTarget =
                    averageEntryPrice
                    - localEffectiveTargetTicks
                    * tickSize;
            }

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            desiredTarget =
                RoundToInstrumentTick(
                    desiredTarget
                );

            // =====================================================
            // V8 - NEVER-WORSEN PROTECTIVE STOP GUARD
            // =====================================================
            // OCO Sync may resize/synchronize the bracket, but it must
            // NEVER move an already-improved stop backwards.
            //
            // LONG  -> higher stop is better.
            // SHORT -> lower stop is better.
            //
            // activeStopPrice is reserved immediately by BE / Lock /
            // Trailing / Daily Target protection before Account.Change(),
            // so synchronous OrderUpdate callbacks cannot reconstruct the
            // original SL while NinjaTrader is processing the change.
            double protectedStopPrice;

            lock (executionStateLock)
            {
                protectedStopPrice =
                    activeStopPrice;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    marketPosition,
                    protectedStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            List<Order> changes =
                new List<Order>();

            if (
                IsOrderChangeable(
                    localStop
                )
            )
            {
                int desiredStopTotalQty =
                    Math.Max(
                        localStop.Filled +
                            openQuantity,
                        localStop.Filled
                    );

                bool quantityChanged =
                    localStop.Quantity !=
                        desiredStopTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localStop.StopPrice -
                        desiredStop
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localStop.QuantityChanged =
                        desiredStopTotalQty;

                    localStop.StopPriceChanged =
                        desiredStop;

                    changes.Add(
                        localStop
                    );
                }
            }

            if (
                IsOrderChangeable(
                    localTarget
                )
            )
            {
                int desiredTargetTotalQty =
                    Math.Max(
                        localTarget.Filled +
                            openQuantity,
                        localTarget.Filled
                    );

                bool quantityChanged =
                    localTarget.Quantity !=
                        desiredTargetTotalQty;

                bool priceChanged =
                    Math.Abs(
                        localTarget.LimitPrice -
                        desiredTarget
                    ) >=
                        tickSize * 0.5;

                if (
                    quantityChanged ||
                    priceChanged
                )
                {
                    localTarget.QuantityChanged =
                        desiredTargetTotalQty;

                    localTarget.LimitPriceChanged =
                        desiredTarget;

                    changes.Add(
                        localTarget
                    );
                }
            }

            if (changes.Count <= 0)
                return;

            lock (executionStateLock)
            {
                activeStopPrice =
                    desiredStop;

                activeTargetPrice =
                    desiredTarget;

                executionStatus =
                    "UPDATING OCO";
            }

            UpdateExecutionMonitor();

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_SYNC",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO SYNC"
                    + " | Open Qty: "
                    + openQuantity
                    + " | Avg: "
                    + averageEntryPrice.ToString("0.00")
                    + " | SL: "
                    + desiredStop.ToString("0.00")
                    + " | TP: "
                    + desiredTarget.ToString("0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO SYNC ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void ResizeProtectiveOrdersAfterPartialExit(
            string filledOrderName,
            int remainingPositionQty)
        {
            if (remainingPositionQty <= 0)
                return;

            Account account =
                selectedAccount;

            if (
                account == null ||
                !IsSimulationAccount(
                    account
                )
            )
            {
                return;
            }

            Order localStop;
            Order localTarget;

            lock (executionStateLock)
            {
                localStop =
                    stopOrder;

                localTarget =
                    targetOrder;
            }

            List<Order> changes =
                new List<Order>();

            Action<Order> resize =
                delegate(
                    Order order)
                {
                    if (
                        !IsOrderChangeable(
                            order
                        )
                    )
                    {
                        return;
                    }

                    int desiredTotalQty =
                        Math.Max(
                            order.Filled +
                                remainingPositionQty,
                            order.Filled
                        );

                    if (
                        order.Quantity ==
                            desiredTotalQty
                    )
                    {
                        return;
                    }

                    order.QuantityChanged =
                        desiredTotalQty;

                    changes.Add(
                        order
                    );
                };

            if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_TARGET"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localStop
                );
            }
            else if (
                string.Equals(
                    filledOrderName,
                    GetProfileOrderName("JJ_STOP"),
                    StringComparison.Ordinal
                )
            )
            {
                resize(
                    localTarget
                );
            }
            else
            {
                resize(
                    localStop
                );

                resize(
                    localTarget
                );
            }

            if (changes.Count <= 0)
                return;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "OCO_RESIZE",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
                // API call stays outside executionStateLock.
                account.Change(
                    changes.ToArray()
                );

                PrintBotMessage(
                    "OCO RESIZED"
                    + " | Remaining Position: "
                    + remainingPositionQty
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "OCO RESIZE ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private double EnforceNeverWorsenStop(
            MarketPosition side,
            double currentProtectedStop,
            double requestedStop)
        {
            if (requestedStop <= 0)
                return currentProtectedStop;

            if (currentProtectedStop <= 0)
                return requestedStop;

            if (side == MarketPosition.Long)
            {
                return Math.Max(
                    currentProtectedStop,
                    requestedStop
                );
            }

            if (side == MarketPosition.Short)
            {
                return Math.Min(
                    currentProtectedStop,
                    requestedStop
                );
            }

            return currentProtectedStop;
        }
        private void UpdateMomentumTrailingStop(
            double currentPrice)
        {
            Account account =
                selectedAccount;

            Instrument instrument =
                selectedInstrument;

            Order localStopOrder;
            double localEntryFillPrice;
            double localActiveStopPrice;
            int localEntryQuantity;
            MarketPosition localMarketPosition;
            int localMomentumStage;
            int localBreakEvenTriggerTicks;
            bool localStrongMomentumProtection;
            bool localTrailingActive;
            bool localDailyProtectionArmed;

            lock (executionStateLock)
            {
                localStopOrder =
                    stopOrder;

                localEntryFillPrice =
                    entryFillPrice;

                localActiveStopPrice =
                    activeStopPrice;

                localEntryQuantity =
                    entryQuantity;

                localMarketPosition =
                    entryMarketPosition;

                localMomentumStage =
                    momentumTrailingStage;

                localBreakEvenTriggerTicks =
                    activeBreakEvenTriggerTicks > 0
                        ? activeBreakEvenTriggerTicks
                        : MomentumBreakEvenTriggerTicks;

                localStrongMomentumProtection =
                    activeStrongMomentumProtection;

                localTrailingActive =
                    activeEntryUsesMomentumTrailing;

                localDailyProtectionArmed =
                    dailyTargetProtectionArmed;
            }

            // Daily-target protection owns the stop once armed.
            if (localDailyProtectionArmed)
                return;

            if (
                !localTrailingActive ||
                account == null ||
                instrument == null ||
                localStopOrder == null ||
                localEntryFillPrice <= 0 ||
                localEntryQuantity <= 0 ||
                localMarketPosition ==
                    MarketPosition.Flat
            )
            {
                return;
            }

            if (
                localStopOrder.OrderState !=
                    OrderState.Working &&
                localStopOrder.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double tickSize =
                instrument
                    .MasterInstrument
                    .TickSize;

            if (tickSize <= 0)
                return;

            double favorableTicks;

            if (
                localMarketPosition ==
                    MarketPosition.Long
            )
            {
                favorableTicks =
                    (
                        currentPrice -
                        localEntryFillPrice
                    )
                    / tickSize;
            }
            else
            {
                favorableTicks =
                    (
                        localEntryFillPrice -
                        currentPrice
                    )
                    / tickSize;
            }

            if (
                favorableTicks <
                    localBreakEvenTriggerTicks
            )
            {
                return;
            }

            double desiredStop =
                localActiveStopPrice;

            int desiredStage =
                localMomentumStage;

            // Stage 1: Break Even
            if (
                favorableTicks >=
                    MomentumBreakEvenTriggerTicks
            )
            {
                desiredStop =
                    localEntryFillPrice;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        1
                    );
            }

            // Stage 2: Lock profit
            if (
                favorableTicks >=
                    MomentumLockTriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        2
                    );
            }

            // Stage 3: Second staged profit lock
            if (
                favorableTicks >=
                    MomentumLock2TriggerTicks
            )
            {
                desiredStop =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? localEntryFillPrice
                            + MomentumLock2ProfitTicks
                            * tickSize
                        : localEntryFillPrice
                            - MomentumLock2ProfitTicks
                            * tickSize;

                desiredStage =
                    Math.Max(
                        desiredStage,
                        3
                    );
            }

            // Stage 4: Dynamic trailing
            if (
                favorableTicks >=
                    MomentumTrailTriggerTicks
            )
            {
                double trailCandidate =
                    localMarketPosition ==
                        MarketPosition.Long
                        ? currentPrice
                            - MomentumTrailDistanceTicks
                            * tickSize
                        : currentPrice
                            + MomentumTrailDistanceTicks
                            * tickSize;

                if (
                    localMarketPosition ==
                        MarketPosition.Long
                )
                {
                    desiredStop =
                        Math.Max(
                            desiredStop,
                            trailCandidate
                        );
                }
                else
                {
                    desiredStop =
                        Math.Min(
                            desiredStop,
                            trailCandidate
                        );
                }

                desiredStage =
                    4;
            }

            desiredStop =
                EnforceNeverWorsenStop(
                    localMarketPosition,
                    localActiveStopPrice,
                    desiredStop
                );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            DateTime reservationTimeUtc =
                DateTime.UtcNow;

            long protectiveToken;

            if (
                !TryBeginProtectiveChange(
                    "MOMENTUM_TRAILING",
                    out protectiveToken
                )
            )
            {
                return;
            }

            try
            {
            // Validate the snapshot again and reserve this change.
            lock (executionStateLock)
            {
                if (
                    !ReferenceEquals(
                        stopOrder,
                        localStopOrder
                    ) ||
                    entryMarketPosition !=
                        localMarketPosition ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    !activeEntryUsesMomentumTrailing ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                bool improvesLatestStop =
                    entryMarketPosition ==
                        MarketPosition.Long
                        ? desiredStop >
                            activeStopPrice
                        : desiredStop <
                            activeStopPrice;

                if (!improvesLatestStop)
                    return;

                if (
                    lastMomentumTrailingChangeUtc !=
                        DateTime.MinValue &&
                    (
                        reservationTimeUtc -
                        lastMomentumTrailingChangeUtc
                    ).TotalMilliseconds <
                        ProtectiveOrderChangeThrottleMs
                )
                {
                    return;
                }

                if (
                    lastMomentumTrailingStopPrice > 0 &&
                    Math.Abs(
                        desiredStop -
                        lastMomentumTrailingStopPrice
                    ) <
                        tickSize * 0.5
                )
                {
                    return;
                }

                // Reserve before Account.Change so another callback
                // cannot submit the same change concurrently.
                lastMomentumTrailingChangeUtc =
                    reservationTimeUtc;

                lastMomentumTrailingStopPrice =
                    desiredStop;

                // V8:
                // Reserve the improved stop immediately. This closes the
                // race where OrderUpdate/OCO Sync could still see the old
                // activeStopPrice and restore the original protective SL.
                activeStopPrice =
                    desiredStop;

                localStopOrder.StopPriceChanged =
                    desiredStop;
            }

                // NinjaTrader API call MUST stay outside executionStateLock.
                account.Change(
                    new[]
                    {
                        localStopOrder
                    }
                );

                bool stageAdvanced =
                    false;

                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        desiredStage >
                            momentumTrailingStage
                    )
                    {
                        momentumTrailingStage =
                            desiredStage;

                        stageAdvanced =
                            true;
                    }
                }

                if (stageAdvanced)
                {
                    string stageName =
                        desiredStage == 1
                            ? (
                                localStrongMomentumProtection
                                    ? "ADAPTIVE BREAK EVEN"
                                    : "BREAK EVEN"
                              )
                            : desiredStage == 2
                                ? "LOCK PROFIT"
                                : desiredStage == 3
                                    ? "LOCK PROFIT 2"
                                    : "TRAILING";

                    PrintBotMessage(
                        "MOMENTUM TRAILING "
                        + stageName
                        + " | Profit: "
                        + favorableTicks.ToString("0")
                        + " ticks"
                        + " | New SL: "
                        + desiredStop.ToString("0.00")
                    );
                }
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    if (
                        ReferenceEquals(
                            stopOrder,
                            localStopOrder
                        ) &&
                        Math.Abs(
                            lastMomentumTrailingStopPrice -
                            desiredStop
                        ) <
                            tickSize * 0.5
                    )
                    {
                        lastMomentumTrailingChangeUtc =
                            DateTime.MinValue;

                        lastMomentumTrailingStopPrice =
                            0;
                    }
                }

                PrintBotMessage(
                    "MOMENTUM TRAILING ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    protectiveToken
                );
            }
        }
        private void TrySmartScaleIn(
            double currentPrice)
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null ||
                currentPrice <= 0
            )
            {
                return;
            }

            MarketPosition side;
            double entryPrice;
            double stopPrice;
            int currentQty;
            int baseQty;
            double initialRisk;
            bool manualTrade;
            bool scaleUsed;
            bool scalePending;
            bool targetProtection;
            bool entryIsPending;

            lock (executionStateLock)
            {
                side = entryMarketPosition;
                entryPrice = entryFillPrice;
                stopPrice = activeStopPrice;

                currentQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                baseQty = initialTradeQuantity;
                initialRisk = initialTradeRiskDollars;
                manualTrade = activeTradeIsManualTest;
                scaleUsed = smartScaleInUsed;
                scalePending = smartScaleInPending;
                targetProtection = dailyTargetProtectionArmed;
                entryIsPending = entryPending;
            }

            if (
                side == MarketPosition.Flat ||
                entryPrice <= 0 ||
                stopPrice <= 0 ||
                currentQty <= 0 ||
                baseQty <= 0 ||
                initialRisk <= 0 ||
                manualTrade ||
                scaleUsed ||
                scalePending ||
                targetProtection ||
                entryIsPending
            )
            {
                return;
            }

            // No scale-in after a partial exit.
            if (currentQty != baseQty)
            {
                return;
            }

            double tickSize =
                instrument.MasterInstrument.TickSize;

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (
                tickSize <= 0 ||
                pointValue <= 0
            )
            {
                return;
            }

            double favorableTicks =
                side == MarketPosition.Long
                    ? (currentPrice - entryPrice) / tickSize
                    : (entryPrice - currentPrice) / tickSize;

            if (
                favorableTicks <
                    SmartScaleInTriggerTicks
            )
            {
                return;
            }

            // The stop must already have locked +30 ticks before
            // the bot is allowed to add a contract.
            double lockStop =
                side == MarketPosition.Long
                    ? entryPrice
                        + MomentumLockProfitTicks
                        * tickSize
                    : entryPrice
                        - MomentumLockProfitTicks
                        * tickSize;

            bool stopProtected =
                side == MarketPosition.Long
                    ? stopPrice >=
                        lockStop - tickSize * 0.5
                    : stopPrice <=
                        lockStop + tickSize * 0.5;

            if (!stopProtected)
            {
                return;
            }

            int momentumScore;
            int htfScore;

            lock (marketContextLock)
            {
                momentumScore =
                    side == MarketPosition.Long
                        ? latestRangeLongScore
                        : latestRangeShortScore;

                htfScore =
                    side == MarketPosition.Long
                        ? latestHtfLongScore
                        : latestHtfShortScore;
            }

            if (
                momentumScore <
                    SmartScaleInMinMomentumScore ||
                htfScore <
                    SmartScaleInMinHtfScore
            )
            {
                return;
            }

            // Estimated worst-case PnL if the new contract fills
            // around currentPrice and the EXISTING stop is hit.
            double existingWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        entryPrice
                      )
                      * pointValue
                      * currentQty
                    : (
                        entryPrice -
                        stopPrice
                      )
                      * pointValue
                      * currentQty;

            double addedWorstCase =
                side == MarketPosition.Long
                    ? (
                        stopPrice -
                        currentPrice
                      )
                      * pointValue
                      * SmartScaleInContracts
                    : (
                        currentPrice -
                        stopPrice
                      )
                      * pointValue
                      * SmartScaleInContracts;

            double combinedWorstCase =
                existingWorstCase +
                addedWorstCase;

            double scaleInRiskLimit =
                Math.Min(
                    initialRisk,
                    activeDollarRiskCap > 0
                        ? activeDollarRiskCap
                        : initialRisk
                );

            if (
                combinedWorstCase <
                    -scaleInRiskLimit
            )
            {
                PrintBotMessage(
                    "SMART SCALE-IN BLOCKED - RISK CAP"
                    + " | WorstCase: "
                    + combinedWorstCase.ToString("$0.00")
                    + " | Limit: -"
                    + scaleInRiskLimit.ToString("$0.00")
                );

                return;
            }

            DateTime nowUtc =
                DateTime.UtcNow;

            // V1.6.12 - FINAL atomic revalidation immediately before
            // reserving the scale-in. The earlier snapshot is only a fast
            // eligibility check; fills/trailing may have changed quantity
            // or stop while momentum context was being evaluated.
            lock (executionStateLock)
            {
                if (
                    smartScaleInUsed ||
                    smartScaleInPending ||
                    entryPending ||
                    entryMarketPosition != side ||
                    activeTradeIsManualTest ||
                    dailyTargetProtectionArmed
                )
                {
                    return;
                }

                int refreshedQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                double refreshedEntryPrice =
                    entryFillPrice;

                double refreshedStopPrice =
                    activeStopPrice;

                double refreshedInitialRisk =
                    initialTradeRiskDollars;

                if (
                    refreshedQty <= 0 ||
                    refreshedQty != initialTradeQuantity ||
                    refreshedEntryPrice <= 0 ||
                    refreshedStopPrice <= 0 ||
                    refreshedInitialRisk <= 0
                )
                {
                    return;
                }

                double refreshedLockStop =
                    side == MarketPosition.Long
                        ? refreshedEntryPrice
                            + MomentumLockProfitTicks
                            * tickSize
                        : refreshedEntryPrice
                            - MomentumLockProfitTicks
                            * tickSize;

                bool refreshedStopProtected =
                    side == MarketPosition.Long
                        ? refreshedStopPrice >=
                            refreshedLockStop - tickSize * 0.5
                        : refreshedStopPrice <=
                            refreshedLockStop + tickSize * 0.5;

                if (!refreshedStopProtected)
                {
                    return;
                }

                double refreshedExistingWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            refreshedEntryPrice
                          )
                          * pointValue
                          * refreshedQty
                        : (
                            refreshedEntryPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * refreshedQty;

                double refreshedAddedWorstCase =
                    side == MarketPosition.Long
                        ? (
                            refreshedStopPrice -
                            currentPrice
                          )
                          * pointValue
                          * SmartScaleInContracts
                        : (
                            currentPrice -
                            refreshedStopPrice
                          )
                          * pointValue
                          * SmartScaleInContracts;

                double refreshedCombinedWorstCase =
                    refreshedExistingWorstCase +
                    refreshedAddedWorstCase;

                double refreshedRiskLimit =
                    Math.Min(
                        refreshedInitialRisk,
                        activeDollarRiskCap > 0
                            ? activeDollarRiskCap
                            : refreshedInitialRisk
                    );

                if (
                    refreshedCombinedWorstCase <
                        -refreshedRiskLimit
                )
                {
                    return;
                }

                if (
                    lastSmartScaleInAttemptUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSmartScaleInAttemptUtc
                    ).TotalMilliseconds <
                        SmartScaleInAttemptThrottleMs
                )
                {
                    return;
                }

                // Keep the values used by the submission/log consistent
                // with the final validated execution snapshot.
                entryPrice = refreshedEntryPrice;
                stopPrice = refreshedStopPrice;
                currentQty = refreshedQty;
                initialRisk = refreshedInitialRisk;

                smartScaleInPending = true;
                lastSmartScaleInAttemptUtc = nowUtc;
            }

            try
            {
                OrderAction action =
                    side == MarketPosition.Long
                        ? OrderAction.Buy
                        : OrderAction.SellShort;

                string orderName =
                    side == MarketPosition.Long
                        ? GetProfileOrderName("JJ_SCALE_IN_LONG")
                        : GetProfileOrderName("JJ_SCALE_IN_SHORT");

                Order scaleOrder =
                    account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        SmartScaleInContracts,
                        0,
                        0,
                        string.Empty,
                        orderName,
                        NinjaTrader.Core.Globals.MaxDate,
                        null
                    );

                lock (executionStateLock)
                {
                    if (
                        smartScaleInUsed ||
                        entryMarketPosition != side
                    )
                    {
                        smartScaleInPending = false;
                        return;
                    }

                    smartScaleInOrder = scaleOrder;
                }

                account.Submit(
                    new[]
                    {
                        scaleOrder
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN SUBMITTED"
                    + " | Side: "
                    + (
                        side == MarketPosition.Long
                            ? "LONG"
                            : "SHORT"
                    )
                    + " | Add: "
                    + SmartScaleInContracts
                    + " | Profit: "
                    + favorableTicks.ToString("0")
                    + " ticks"
                    + " | Momentum: "
                    + momentumScore
                    + "/5"
                    + " | HTF: "
                    + htfScore
                    + "/2"
                    + " | InitialRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                lock (executionStateLock)
                {
                    smartScaleInPending = false;
                    smartScaleInOrder = null;
                }

                PrintBotMessage(
                    "SMART SCALE-IN ERROR: "
                    + ex.Message
                );
            }
        }
        private void EnforceSmartScaleInRiskCap()
        {
            Account account = selectedAccount;
            Instrument instrument = selectedInstrument;

            if (
                account == null ||
                instrument == null
            )
            {
                return;
            }

            Order localStop;
            MarketPosition side;
            double averageEntry;
            double currentStop;
            int openQty;
            double initialRisk;

            lock (executionStateLock)
            {
                if (
                    !smartScaleInUsed ||
                    entryMarketPosition ==
                        MarketPosition.Flat ||
                    entryFillPrice <= 0 ||
                    entryQuantity <= 0 ||
                    initialTradeRiskDollars <= 0
                )
                {
                    return;
                }

                localStop = stopOrder;
                side = entryMarketPosition;
                averageEntry = entryFillPrice;
                currentStop = activeStopPrice;

                openQty =
                    Math.Max(
                        0,
                        entryQuantity -
                        activeExitQuantity
                    );

                initialRisk =
                    initialTradeRiskDollars;
            }

            if (
                localStop == null ||
                openQty <= 0 ||
                currentStop <= 0
            )
            {
                return;
            }

            if (
                localStop.OrderState !=
                    OrderState.Working &&
                localStop.OrderState !=
                    OrderState.Accepted
            )
            {
                return;
            }

            double pointValue =
                instrument.MasterInstrument.PointValue;

            if (pointValue <= 0)
            {
                return;
            }

            double riskCapStop =
                side == MarketPosition.Long
                    ? averageEntry
                        - initialRisk
                        / (
                            pointValue
                            * openQty
                        )
                    : averageEntry
                        + initialRisk
                        / (
                            pointValue
                            * openQty
                        );

            riskCapStop =
                RoundToInstrumentTick(
                    riskCapStop
                );

            double desiredStop =
                side == MarketPosition.Long
                    ? Math.Max(
                        currentStop,
                        riskCapStop
                      )
                    : Math.Min(
                        currentStop,
                        riskCapStop
                      );

            desiredStop =
                RoundToInstrumentTick(
                    desiredStop
                );

            bool improves =
                side == MarketPosition.Long
                    ? desiredStop > currentStop
                    : desiredStop < currentStop;

            if (!improves)
            {
                return;
            }

            long token;

            if (
                !TryBeginProtectiveChange(
                    "SMART_SCALE_IN_RISK",
                    out token
                )
            )
            {
                return;
            }

            try
            {
                lock (executionStateLock)
                {
                    if (
                        !ReferenceEquals(
                            stopOrder,
                            localStop
                        ) ||
                        entryMarketPosition != side
                    )
                    {
                        return;
                    }

                    activeStopPrice = desiredStop;
                    localStop.StopPriceChanged = desiredStop;
                }

                account.Change(
                    new[]
                    {
                        localStop
                    }
                );

                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP"
                    + " | New SL: "
                    + desiredStop.ToString("0.00")
                    + " | MaxRisk: "
                    + initialRisk.ToString("$0.00")
                );
            }
            catch (Exception ex)
            {
                PrintBotMessage(
                    "SMART SCALE-IN RISK CAP ERROR: "
                    + ex.Message
                );
            }
            finally
            {
                EndProtectiveChange(
                    token
                );
            }
        }

    }
}

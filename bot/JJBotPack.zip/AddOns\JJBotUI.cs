#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT UI / VISUAL LAYER
    // Stage 17 structural extraction only.
    //
    // Existing WPF layout construction, visual status updates,
    // execution display, validation display and visual log
    // helpers are moved exactly as-is.
    //
    // Start/Stop, account/instrument selection, command routing
    // and all trading logic remain outside this module.
    // =========================================================
    public partial class JJBotWindow
    {
        private UIElement BuildInterface()
        {
            ScrollViewer scroll = new ScrollViewer();

            scroll.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            Border mainBorder = new Border();

            mainBorder.Padding =
                new Thickness(22);

            mainBorder.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        12,
                        17,
                        24
                    )
                );

            StackPanel mainPanel =
                new StackPanel();

            mainBorder.Child = mainPanel;
            scroll.Content = mainBorder;

            // =================================================
            // HEADER
            // =================================================
            TextBlock title = new TextBlock();

            title.Text =
                "J&J NY TRADING BOT";

            title.FontSize = 24;

            title.FontWeight =
                FontWeights.Bold;

            title.Foreground =
                Brushes.White;

            title.HorizontalAlignment =
                HorizontalAlignment.Center;

            title.Margin =
                new Thickness(
                    0,
                    5,
                    0,
                    3
                );

            mainPanel.Children.Add(title);

            TextBlock subtitle =
                new TextBlock();

            subtitle.Text =
                "AUTOMATED FUTURES ENGINE";

            subtitle.FontSize = 11;

            subtitle.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            subtitle.HorizontalAlignment =
                HorizontalAlignment.Center;

            subtitle.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    20
                );

            mainPanel.Children.Add(subtitle);

            // =================================================
            // TRADING CONNECTION
            // =================================================
            Border connectionCard =
                CreateCard();

            StackPanel connectionPanel =
                new StackPanel();

            connectionCard.Child =
                connectionPanel;

            connectionPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING CONNECTION"
                )
            );

            // ACCOUNT SELECTOR
            accountSelector =
                new AccountSelector();

            accountSelector.Width = 230;
            accountSelector.Height = 30;

            accountSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            accountSelector.SelectionChanged +=
                AccountSelectorChanged;

            AddRow(
                connectionPanel,
                "Account",
                accountSelector
            );

            // INSTRUMENT SELECTOR
            instrumentSelector =
                new InstrumentSelector();

            instrumentSelector.Width = 230;
            instrumentSelector.Height = 30;

            instrumentSelector.HorizontalAlignment =
                HorizontalAlignment.Right;

            instrumentSelector.InstrumentChanged +=
                InstrumentSelectorChanged;

            AddRow(
                connectionPanel,
                "Instrument",
                instrumentSelector
            );

            accountStatusText =
                CreateSmallStatusText(
                    "No account selected"
                );

            connectionPanel.Children.Add(
                accountStatusText
            );

            instrumentStatusText =
                CreateSmallStatusText(
                    "No instrument selected"
                );

            connectionPanel.Children.Add(
                instrumentStatusText
            );

            mainPanel.Children.Add(
                connectionCard
            );

            // =================================================
            // BOT STATUS
            // =================================================
            Border statusCard =
                CreateCard();

            StackPanel statusPanel =
                new StackPanel();

            statusCard.Child =
                statusPanel;

            statusPanel.Children.Add(
                CreateSectionTitle(
                    "BOT STATUS"
                )
            );

            statusText =
                new TextBlock();

            statusText.Text =
                "● STOPPED";

            statusText.FontSize = 20;

            statusText.FontWeight =
                FontWeights.Bold;

            statusText.Foreground =
                Brushes.OrangeRed;

            statusText.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    2
                );

            statusPanel.Children.Add(
                statusText
            );

            mainPanel.Children.Add(
                statusCard
            );

            // =================================================
            // PROP NEWS COMPLIANCE - V1.6.49 COMPAT
            // =================================================
            Border newsCard =
                CreateCard();

            StackPanel newsPanel =
                new StackPanel();

            newsCard.Child =
                newsPanel;

            newsPanel.Children.Add(
                CreateSectionTitle(
                    "PROP NEWS COMPLIANCE"
                )
            );

            newsNextText =
                CreateValueText(
                    "LOADING"
                );

            AddInfoRow(
                newsPanel,
                "Next News",
                newsNextText
            );

            newsImpactText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                newsPanel,
                "Impact",
                newsImpactText
            );

            newsEventTimeText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                newsPanel,
                "Event Time ET",
                newsEventTimeText
            );

            newsGuardWindowText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                newsPanel,
                "Guard Window",
                newsGuardWindowText
            );

            newsGuardStatusText =
                CreateValueText(
                    "CALENDAR LOADING"
                );

            AddInfoRow(
                newsPanel,
                "Status",
                newsGuardStatusText
            );

            mainPanel.Children.Add(
                newsCard
            );

            TextBlock executionModeText =
                new TextBlock();

            executionModeText.Text =
                "EXECUTION MODE  •  ALL ACCOUNTS";

            executionModeText.Foreground =
                Brushes.Goldenrod;

            executionModeText.FontWeight =
                FontWeights.Bold;

            executionModeText.FontSize = 11;

            executionModeText.HorizontalAlignment =
                HorizontalAlignment.Center;

            executionModeText.Margin =
                new Thickness(
                    0,
                    -4,
                    0,
                    12
                );

            mainPanel.Children.Add(
                executionModeText
            );

            // =================================================
            // TRADING SETTINGS
            // =================================================
            Border settingsCard =
                CreateCard();

            StackPanel settingsPanel =
                new StackPanel();

            settingsCard.Child =
                settingsPanel;

            settingsPanel.Children.Add(
                CreateSectionTitle(
                    "TRADING SETTINGS"
                )
            );

            directionCombo =
                new ComboBox();

            directionCombo.Items.Add(
                "BOTH"
            );

            directionCombo.Items.Add(
                "AUTO"
            );

            directionCombo.Items.Add(
                "LONG ONLY"
            );

            directionCombo.Items.Add(
                "SHORT ONLY"
            );

            directionCombo.SelectedIndex = 0;

            directionCombo.Width = 150;
            directionCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Direction",
                directionCombo
            );

            strategyCombo =
                new ComboBox();

            strategyCombo.Items.Add(
                "STRUCTURE"
            );

            strategyCombo.Items.Add(
                "MOMENTUM SCALP"
            );

            strategyCombo.Items.Add(
                "OPENING"
            );

            strategyCombo.Items.Add(
                "HYBRID"
            );

            strategyCombo.SelectedIndex = 3;
            strategyCombo.Width = 150;
            strategyCombo.Height = 28;

            AddRow(
                settingsPanel,
                "Strategy",
                strategyCombo
            );

            contractsBox =
                CreateTextBox("1");

            AddRow(
                settingsPanel,
                "Contracts",
                contractsBox
            );

            stopBox =
                CreateTextBox("100");

            AddRow(
                settingsPanel,
                "Stop Loss (ticks)",
                stopBox
            );

            targetBox =
                CreateTextBox("150");

            AddRow(
                settingsPanel,
                "Profit Target (ticks)",
                targetBox
            );

            maxTradesBox =
                CreateTextBox("2");

            AddRow(
                settingsPanel,
                "Max Trades / Session",
                maxTradesBox
            );

            mainPanel.Children.Add(
                settingsCard
            );

            // =================================================
            // RISK MANAGEMENT
            // =================================================
            Border riskCard =
                CreateCard();

            StackPanel riskPanel =
                new StackPanel();

            riskCard.Child =
                riskPanel;

            riskPanel.Children.Add(
                CreateSectionTitle(
                    "RISK MANAGEMENT"
                )
            );

            dailyTargetBox =
                CreateTextBox("300");

            AddRow(
                riskPanel,
                "Daily Target $",
                dailyTargetBox
            );

            dailyLossBox =
                CreateTextBox("200");

            AddRow(
                riskPanel,
                "Daily Loss $",
                dailyLossBox
            );

            dollarRiskCapBox =
                CreateTextBox("100");

            AddRow(
                riskPanel,
                "Dollar Risk Cap $",
                dollarRiskCapBox
            );

            mainPanel.Children.Add(
                riskCard
            );

            // =================================================
            // SIGNAL ENGINE
            // =================================================
            Border signalCard =
                CreateCard();

            StackPanel signalPanel =
                new StackPanel();

            signalCard.Child =
                signalPanel;

            signalPanel.Children.Add(
                CreateSectionTitle(
                    "SIGNAL ENGINE - 5 MINUTE"
                )
            );

            lastPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Last Price",
                lastPriceText
            );

            emaFastText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 9",
                emaFastText
            );

            emaSlowText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "EMA 50",
                emaSlowText
            );

            vwapText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Session VWAP",
                vwapText
            );

            trendText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "Trend",
                trendText
            );

            nySessionText =
                CreateValueText(
                    "CLOSED"
                );

            AddInfoRow(
                signalPanel,
                "NY Session",
                nySessionText
            );

            liquidityText =
                CreateValueText(
                    "NONE"
                );

            AddInfoRow(
                signalPanel,
                "Liquidity Sweep",
                liquidityText
            );

            structureText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Structure",
                structureText
            );

            momentumText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Momentum",
                momentumText
            );

            confirmationText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Confirmation",
                confirmationText
            );

            setupText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                signalPanel,
                "Setup",
                setupText
            );

            barTimeText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                signalPanel,
                "5m Bar",
                barTimeText
            );

            mainPanel.Children.Add(
                signalCard
            );

            // =================================================
            // EXECUTION MONITOR
            // =================================================
            Border executionCard =
                CreateCard();

            StackPanel executionPanel =
                new StackPanel();

            executionCard.Child =
                executionPanel;

            executionPanel.Children.Add(
                CreateSectionTitle(
                    "EXECUTION MONITOR"
                )
            );

            positionText =
                CreateValueText(
                    "FLAT"
                );

            AddInfoRow(
                executionPanel,
                "Position",
                positionText
            );

            positionQtyText =
                CreateValueText(
                    "0"
                );

            AddInfoRow(
                executionPanel,
                "Position Qty",
                positionQtyText
            );

            entryPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Entry Price",
                entryPriceText
            );

            stopPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Stop Loss",
                stopPriceText
            );

            targetPriceText =
                CreateValueText(
                    "--"
                );

            AddInfoRow(
                executionPanel,
                "Profit Target",
                targetPriceText
            );

            riskRewardText =
                CreateValueText(
                    "1 : 1.50"
                );

            AddInfoRow(
                executionPanel,
                "Risk / Reward",
                riskRewardText
            );

            orderStatusText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                executionPanel,
                "Order Status",
                orderStatusText
            );

            mainPanel.Children.Add(
                executionCard
            );

            // =================================================
            // LIVE SESSION
            // =================================================
            Border infoCard =
                CreateCard();

            StackPanel infoPanel =
                new StackPanel();

            infoCard.Child =
                infoPanel;

            infoPanel.Children.Add(
                CreateSectionTitle(
                    "LIVE SESSION"
                )
            );

            grossPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Gross PnL",
                grossPnlText
            );

            feesPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Commissions / Fees",
                feesPnlText
            );

            pnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Net Realized PnL",
                pnlText
            );

            unrealizedPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Unrealized PnL",
                unrealizedPnlText
            );

            totalPnlText =
                CreateValueText(
                    "$0.00"
                );

            AddInfoRow(
                infoPanel,
                "Total PnL",
                totalPnlText
            );

            tradesText =
                CreateValueText(
                    "0 / 2"
                );

            AddInfoRow(
                infoPanel,
                "Trades",
                tradesText
            );

            signalText =
                CreateValueText(
                    "WAITING"
                );

            AddInfoRow(
                infoPanel,
                "Signal",
                signalText
            );

            mainPanel.Children.Add(
                infoCard
            );

            // =================================================
            // BOT ACTIVITY LOG
            // =================================================
            Border logCard =
                CreateCard();

            StackPanel logPanel =
                new StackPanel();

            logCard.Child =
                logPanel;

            Grid logHeader =
                new Grid();

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            logHeader.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        GridLength.Auto
                }
            );

            TextBlock logTitle =
                CreateSectionTitle(
                    "BOT ACTIVITY LOG"
                );

            Grid.SetColumn(
                logTitle,
                0
            );

            logHeader.Children.Add(
                logTitle
            );

            clearLogButton =
                new Button();

            clearLogButton.Content =
                "CLEAR";

            clearLogButton.Width =
                65;

            clearLogButton.Height =
                24;

            clearLogButton.FontSize =
                10;

            clearLogButton.Margin =
                new Thickness(
                    8,
                    0,
                    0,
                    0
                );

            clearLogButton.Click +=
                ClearVisualLogClicked;

            Grid.SetColumn(
                clearLogButton,
                1
            );

            logHeader.Children.Add(
                clearLogButton
            );

            logPanel.Children.Add(
                logHeader
            );

            visualLogBox =
                new TextBox();

            visualLogBox.IsReadOnly =
                true;

            visualLogBox.AcceptsReturn =
                true;

            visualLogBox.TextWrapping =
                TextWrapping.Wrap;

            visualLogBox.VerticalScrollBarVisibility =
                ScrollBarVisibility.Auto;

            visualLogBox.HorizontalScrollBarVisibility =
                ScrollBarVisibility.Disabled;

            visualLogBox.Height =
                190;

            visualLogBox.Margin =
                new Thickness(
                    0,
                    10,
                    0,
                    0
                );

            visualLogBox.Padding =
                new Thickness(8);

            visualLogBox.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        10,
                        15,
                        22
                    )
                );

            visualLogBox.Foreground =
                Brushes.LightGray;

            visualLogBox.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            visualLogBox.BorderThickness =
                new Thickness(1);

            visualLogBox.FontFamily =
                new FontFamily(
                    "Consolas"
                );

            visualLogBox.FontSize =
                11;

            logPanel.Children.Add(
                visualLogBox
            );

            mainPanel.Children.Add(
                logCard
            );

            AppendVisualLog(
                "Visual log ready."
            );

            // =================================================
            // TEST EXECUTION
            // ALL ACCOUNT TYPES ENABLED
            // =================================================
            Border testCard =
                CreateCard();

            StackPanel testPanel =
                new StackPanel();

            testCard.Child =
                testPanel;

            testPanel.Children.Add(
                CreateSectionTitle(
                    "TEST EXECUTION - ALL ACCOUNTS"
                )
            );

            TextBlock testHelp =
                new TextBlock();

            testHelp.Text =
                "Use only to verify Entry → SL/TP → OCO → Monitor.";

            testHelp.TextWrapping =
                TextWrapping.Wrap;

            testHelp.Foreground =
                Brushes.Gray;

            testHelp.FontSize = 10;

            testHelp.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    10
                );

            testPanel.Children.Add(
                testHelp
            );

            Grid testGrid =
                new Grid();

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            testLongButton =
                CreateButton(
                    "TEST LONG"
                );

            testLongButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            testLongButton.Click +=
                TestLongClicked;

            Grid.SetColumn(
                testLongButton,
                0
            );

            testGrid.Children.Add(
                testLongButton
            );

            testShortButton =
                CreateButton(
                    "TEST SHORT"
                );

            testShortButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            testShortButton.Click +=
                TestShortClicked;

            Grid.SetColumn(
                testShortButton,
                1
            );

            testGrid.Children.Add(
                testShortButton
            );

            testPanel.Children.Add(
                testGrid
            );

            mainPanel.Children.Add(
                testCard
            );

            // =================================================
            // START / STOP
            // =================================================
            Grid buttonGrid =
                new Grid();

            buttonGrid.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    10
                );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            buttonGrid.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            startButton =
                CreateButton(
                    "▶ START BOT"
                );

            startButton.Margin =
                new Thickness(
                    0,
                    0,
                    5,
                    0
                );

            startButton.Click +=
                StartBotClicked;

            Grid.SetColumn(
                startButton,
                0
            );

            buttonGrid.Children.Add(
                startButton
            );

            stopButton =
                CreateButton(
                    "■ STOP BOT"
                );

            stopButton.Margin =
                new Thickness(
                    5,
                    0,
                    0,
                    0
                );

            stopButton.IsEnabled =
                false;

            stopButton.Click +=
                StopBotClicked;

            Grid.SetColumn(
                stopButton,
                1
            );

            buttonGrid.Children.Add(
                stopButton
            );

            mainPanel.Children.Add(
                buttonGrid
            );

            // =================================================
            // CLOSE ALL
            // TEST MODE ONLY
            // =================================================
            closeAllButton =
                CreateButton(
                    "⚠ CLOSE ALL"
                );

            closeAllButton.FontSize = 15;

            closeAllButton.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    15
                );

            closeAllButton.Click +=
                CloseAllClicked;

            mainPanel.Children.Add(
                closeAllButton
            );

            TextBlock warning =
                new TextBlock();

            warning.Text =
                "SIM EXECUTION • PERSISTENCE V5 • VISUAL LOG ACTIVE • orders ONLY to accounts containing Sim.";

            warning.TextWrapping =
                TextWrapping.Wrap;

            warning.HorizontalAlignment =
                HorizontalAlignment.Center;

            warning.TextAlignment =
                TextAlignment.Center;

            warning.Foreground =
                Brushes.Goldenrod;

            warning.FontSize = 10;

            warning.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    8
                );

            mainPanel.Children.Add(
                warning
            );

            TextBlock footer =
                new TextBlock();

            footer.Text =
                "NY • OPENING 09:35-10:00 • AM • MIDDAY STRICT 12:00-14:00 • PM • TRAILING + LEARNING";

            footer.HorizontalAlignment =
                HorizontalAlignment.Center;

            footer.Foreground =
                Brushes.Gray;

            footer.FontSize = 11;

            mainPanel.Children.Add(
                footer
            );

            return scroll;
        }
        private void UpdateExecutionUi()
        {
            UpdatePnlDisplay();

            double localRealizedPnL;
            double localUnrealizedPnL;
            int localAmTrades;
            int localPmTrades;
            bool localDailyLocked;

            lock (executionStateLock)
            {
                localRealizedPnL =
                    botDailyPnL;

                localUnrealizedPnL =
                    botUnrealizedPnL;

                localAmTrades =
                    amTradesToday;

                localPmTrades =
                    pmTradesToday;

                localDailyLocked =
                    persistentDailyLocked;
            }

            double localTotalPnL =
                localRealizedPnL +
                localUnrealizedPnL;

            Dispatcher.InvokeAsync(
                new Action(() =>
                {
                    if (pnlText != null)
                    {
                        pnlText.Text =
                            localRealizedPnL.ToString(
                                "$0.00"
                            );
                    }

                    if (tradesText != null)
                    {
                        int uiAmLimit =
                            GetSessionTradeLimit("AM");

                        tradesText.Text =
                            "AM "
                            + localAmTrades
                            + "/"
                            + uiAmLimit
                            + (uiAmLimit > activeMaxTrades ? " (+1 PRE)" : string.Empty)
                            + " | PM "
                            + localPmTrades
                            + "/"
                            + activeMaxTrades;
                    }

                    if (
                        localDailyLocked ||
                        localTotalPnL >=
                            activeDailyTarget ||
                        localTotalPnL <=
                            -activeDailyLoss
                    )
                    {
                        if (signalText != null)
                        {
                            signalText.Text =
                                "DAILY RISK LOCK";

                            signalText.Foreground =
                                Brushes.OrangeRed;
                        }
                    }
                })
            );
        }
        private void ResetSignalDisplay()
        {
            if (lastPriceText != null)
                lastPriceText.Text = "--";

            if (emaFastText != null)
                emaFastText.Text = "--";

            if (emaSlowText != null)
                emaSlowText.Text = "--";

            if (barTimeText != null)
                barTimeText.Text = "--";

            if (vwapText != null)
                vwapText.Text = "--";

            if (trendText != null)
                trendText.Text = "--";

            if (nySessionText != null)
            {
                nySessionText.Text = "CLOSED";
                nySessionText.Foreground = Brushes.Gray;
            }

            if (setupText != null)
            {
                setupText.Text = "WAITING";
                setupText.Foreground = Brushes.White;
            }

            if (liquidityText != null)
            {
                liquidityText.Text = "NONE";
                liquidityText.Foreground = Brushes.Gray;
            }

            if (structureText != null)
            {
                structureText.Text = "WAITING";
                structureText.Foreground = Brushes.Goldenrod;
            }

            if (momentumText != null)
            {
                momentumText.Text = "WAITING";
                momentumText.Foreground = Brushes.Goldenrod;
            }

            if (confirmationText != null)
            {
                confirmationText.Text = "WAITING";
                confirmationText.Foreground = Brushes.Gray;
            }

            if (
                signalText != null &&
                !botRunning
            )
            {
                signalText.Text =
                    "WAITING";

                signalText.Foreground =
                    Brushes.White;
            }
        }
        private void ShowInvalidValue(
            string message)
        {
            MessageBox.Show(
                message,
                "J&J Trading Bot",
                MessageBoxButton.OK,
                MessageBoxImage.Warning
            );
        }
        private string FormatPrice(
            double price)
        {
            if (
                selectedInstrument != null &&
                selectedInstrument.MasterInstrument != null
            )
            {
                try
                {
                    return selectedInstrument
                        .MasterInstrument
                        .FormatPrice(
                            price
                        );
                }
                catch
                {
                }
            }

            return price.ToString(
                "0.00"
            );
        }
        private void AppendVisualLog(
            string message)
        {
            if (
                string.IsNullOrWhiteSpace(
                    message
                )
            )
            {
                return;
            }

            Action appendAction =
                new Action(() =>
                {
                    if (
                        visualLogLines == null
                    )
                    {
                        visualLogLines =
                            new Queue<string>();
                    }

                    string timeStamp;
                    DateTime nyTime;

                    try
                    {
                        nyTime =
                            GetCurrentNewYorkTime();

                        timeStamp =
                            nyTime.ToString(
                                "HH:mm:ss"
                            );
                    }
                    catch
                    {
                        nyTime = DateTime.Now;

                        timeStamp =
                            nyTime.ToString(
                                "HH:mm:ss"
                            );
                    }

                    string persistentLine =
                        "["
                        + timeStamp
                        + "] "
                        + message;

                    visualLogLines.Enqueue(
                        persistentLine
                    );

                    // V1.6.59 - FULL DAILY BOT LOG.
                    // Keep the UI/telemetry tail lightweight, but persist every
                    // visual log line to disk before the in-memory queue trims it.
                    AppendPersistentBotLog(
                        persistentLine,
                        nyTime
                    );

                    while (
                        visualLogLines.Count >
                            MaxVisualLogLines
                    )
                    {
                        visualLogLines.Dequeue();
                    }

                    if (
                        visualLogBox != null
                    )
                    {
                        visualLogBox.Text =
                            string.Join(
                                Environment.NewLine,
                                visualLogLines.ToArray()
                            );

                        visualLogBox.CaretIndex =
                            visualLogBox.Text.Length;

                        visualLogBox.ScrollToEnd();
                    }
                });

            if (Dispatcher.CheckAccess())
            {
                appendAction();
            }
            else
            {
                Dispatcher.BeginInvoke(
                    appendAction
                );
            }
        }

        private string SanitizePersistentLogPart(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "UNKNOWN";

            StringBuilder builder =
                new StringBuilder();

            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];

                if (
                    char.IsLetterOrDigit(c) ||
                    c == '_' ||
                    c == '-' ||
                    c == '.'
                )
                {
                    builder.Append(c);
                }
                else
                {
                    builder.Append('_');
                }
            }

            return builder.Length > 0
                ? builder.ToString()
                : "UNKNOWN";
        }

        private void AppendPersistentBotLog(
            string line,
            DateTime nyTime)
        {
            if (string.IsNullOrWhiteSpace(line))
                return;

            try
            {
                string root = stateFolderPath;

                if (string.IsNullOrWhiteSpace(root))
                {
                    root = System.IO.Path.Combine(
                        Environment.GetFolderPath(
                            Environment.SpecialFolder.MyDocuments
                        ),
                        "NinjaTrader 8",
                        "JJBotData"
                    );
                }

                string folder =
                    System.IO.Path.Combine(
                        root,
                        "logs"
                    );

                System.IO.Directory.CreateDirectory(
                    folder
                );

                string accountName =
                    selectedAccount != null
                        ? selectedAccount.Name
                        : "NO_ACCOUNT";

                string instrumentName =
                    selectedInstrument != null
                        ? selectedInstrument.FullName
                        : "NO_INSTRUMENT";

                string profileName =
                    !string.IsNullOrWhiteSpace(platformProfileId)
                        ? platformProfileId
                        : "profile";

                string fileName =
                    "botlog_"
                    + nyTime.ToString("yyyy-MM-dd")
                    + "_"
                    + SanitizePersistentLogPart(profileName)
                    + "_"
                    + SanitizePersistentLogPart(accountName)
                    + "_"
                    + SanitizePersistentLogPart(instrumentName)
                    + ".txt";

                string filePath =
                    System.IO.Path.Combine(
                        folder,
                        fileName
                    );

                System.IO.File.AppendAllText(
                    filePath,
                    line + Environment.NewLine,
                    Encoding.UTF8
                );
            }
            catch
            {
                // Logging must never interfere with trading or create a
                // recursive visual-log failure path.
            }
        }

        private void ClearVisualLogClicked(
            object sender,
            RoutedEventArgs e)
        {
            if (
                visualLogLines != null
            )
            {
                visualLogLines.Clear();
            }

            if (
                visualLogBox != null
            )
            {
                visualLogBox.Clear();
            }

            AppendVisualLog(
                "Log cleared."
            );
        }
        private Border CreateCard()
        {
            Border card =
                new Border();

            card.Background =
                new SolidColorBrush(
                    Color.FromRgb(
                        20,
                        27,
                        37
                    )
                );

            card.BorderBrush =
                new SolidColorBrush(
                    Color.FromRgb(
                        45,
                        60,
                        75
                    )
                );

            card.BorderThickness =
                new Thickness(1);

            card.CornerRadius =
                new CornerRadius(8);

            card.Padding =
                new Thickness(15);

            card.Margin =
                new Thickness(
                    0,
                    0,
                    0,
                    12
                );

            return card;
        }
        private TextBlock CreateSectionTitle(
            string text)
        {
            TextBlock block =
                new TextBlock();

            block.Text = text;

            block.Foreground =
                new SolidColorBrush(
                    Color.FromRgb(
                        80,
                        180,
                        255
                    )
                );

            block.FontWeight =
                FontWeights.Bold;

            block.FontSize = 12;

            return block;
        }
        private TextBlock CreateSmallStatusText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.Gray;

            block.FontSize = 10;

            block.Margin =
                new Thickness(
                    0,
                    6,
                    0,
                    0
                );

            return block;
        }
        private TextBox CreateTextBox(
            string value)
        {
            TextBox box =
                new TextBox();

            box.Text = value;

            box.Width = 110;
            box.Height = 28;

            box.TextAlignment =
                TextAlignment.Right;

            box.VerticalContentAlignment =
                VerticalAlignment.Center;

            return box;
        }
        private void AddRow(
            StackPanel panel,
            string label,
            Control control)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition
                {
                    Width =
                        new GridLength(250)
                }
            );

            TextBlock text =
                new TextBlock();

            text.Text = label;

            text.Foreground =
                Brushes.WhiteSmoke;

            text.VerticalAlignment =
                VerticalAlignment.Center;

            Grid.SetColumn(
                text,
                0
            );

            row.Children.Add(
                text
            );

            control.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                control,
                1
            );

            row.Children.Add(
                control
            );

            panel.Children.Add(
                row
            );
        }
        private TextBlock CreateValueText(
            string value)
        {
            TextBlock block =
                new TextBlock();

            block.Text = value;

            block.Foreground =
                Brushes.White;

            block.FontWeight =
                FontWeights.Bold;

            return block;
        }
        private void AddInfoRow(
            StackPanel panel,
            string label,
            TextBlock value)
        {
            Grid row =
                new Grid();

            row.Margin =
                new Thickness(
                    0,
                    8,
                    0,
                    0
                );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            row.ColumnDefinitions.Add(
                new ColumnDefinition()
            );

            TextBlock labelBlock =
                new TextBlock();

            labelBlock.Text =
                label;

            labelBlock.Foreground =
                Brushes.LightGray;

            Grid.SetColumn(
                labelBlock,
                0
            );

            row.Children.Add(
                labelBlock
            );

            value.HorizontalAlignment =
                HorizontalAlignment.Right;

            Grid.SetColumn(
                value,
                1
            );

            row.Children.Add(
                value
            );

            panel.Children.Add(
                row
            );
        }
        private Button CreateButton(
            string text)
        {
            Button button =
                new Button();

            button.Content = text;

            button.Height = 42;

            button.FontWeight =
                FontWeights.Bold;

            button.Cursor =
                System.Windows.Input.Cursors.Hand;

            return button;
        }

    }
}

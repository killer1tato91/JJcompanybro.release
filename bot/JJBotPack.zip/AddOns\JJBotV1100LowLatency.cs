#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Threading;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.100 - LOW LATENCY (25-oct-2026)
    // 1) Bot log written to disk in batches from a background thread (250 ms),
    //    one append per file instead of open/write/close per line on the UI thread.
    // 2) The on-screen log box is redrawn at most every 500 ms and shows the last 300 lines
    //    (the 2,000-line memory tail for the platform telemetry is unchanged).
    // 3) Late / out-of-order trades that V1.7.84 drops for price and clock are still
    //    counted as VOLUME in the L2 tape and the CORE20 delta (buy/sell side from the
    //    bid/ask the exchange attached to that trade). Their price and time are never used.
    // Nothing here sends, changes or cancels orders.
    // =========================================================
    public static class JJBotLogWriter
    {
        private static readonly ConcurrentQueue<KeyValuePair<string, string>> queue =
            new ConcurrentQueue<KeyValuePair<string, string>>();

        private static readonly object initLock = new object();
        private static System.Threading.Timer timer;
        private static int busy;

        public static void Enqueue(string path, string line)
        {
            if (string.IsNullOrEmpty(path) || line == null)
                return;

            queue.Enqueue(new KeyValuePair<string, string>(path, line));

            if (timer == null)
            {
                lock (initLock)
                {
                    if (timer == null)
                        timer = new System.Threading.Timer(_ => Flush(), null, 250, 250);
                }
            }
        }

        public static void Flush()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1)
                return;

            try
            {
                Dictionary<string, StringBuilder> groups =
                    new Dictionary<string, StringBuilder>(StringComparer.OrdinalIgnoreCase);

                KeyValuePair<string, string> item;
                int count = 0;

                while (count < 50000 && queue.TryDequeue(out item))
                {
                    StringBuilder sb;

                    if (!groups.TryGetValue(item.Key, out sb))
                    {
                        sb = new StringBuilder();
                        groups[item.Key] = sb;
                    }

                    sb.Append(item.Value).Append(Environment.NewLine);
                    count++;
                }

                foreach (KeyValuePair<string, StringBuilder> g in groups)
                {
                    try
                    {
                        string dir = Path.GetDirectoryName(g.Key);

                        if (!string.IsNullOrEmpty(dir))
                            Directory.CreateDirectory(dir);

                        File.AppendAllText(g.Key, g.Value.ToString(), Encoding.UTF8);
                    }
                    catch
                    {
                        // logging must never interfere with trading
                    }
                }
            }
            catch
            {
            }
            finally
            {
                Interlocked.Exchange(ref busy, 0);
            }
        }
    }

    public partial class JJBotWindow
    {
        private const bool V1100LateTradesInTapeEnabled = true;
        private const int V1100VisibleLogLines = 300;
        private const int V1100UiRenderMs = 500;

        private readonly ConcurrentQueue<string> v1100PendingUi = new ConcurrentQueue<string>();
        private int v1100UiFlushScheduled;
        private DateTime v1100LastRenderUtc = DateTime.MinValue;
        private DispatcherTimer v1100RenderTimer;
        private bool v1100Dirty;

        // ---------------------------------------------------------
        // On-screen log (UI thread only touches the box, throttled)
        // ---------------------------------------------------------
        private void V1100QueueUiLogLine(string line)
        {
            v1100PendingUi.Enqueue(line);

            if (Interlocked.CompareExchange(ref v1100UiFlushScheduled, 1, 0) != 0)
                return;

            try
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(V1100FlushUiLog));
            }
            catch
            {
                Interlocked.Exchange(ref v1100UiFlushScheduled, 0);
            }
        }

        private void V1100FlushUiLog()
        {
            Interlocked.Exchange(ref v1100UiFlushScheduled, 0);

            try
            {
                if (visualLogLines == null)
                    visualLogLines = new Queue<string>();

                string line;
                int added = 0;

                while (v1100PendingUi.TryDequeue(out line))
                {
                    visualLogLines.Enqueue(line);
                    added++;
                }

                while (visualLogLines.Count > MaxVisualLogLines)
                    visualLogLines.Dequeue();

                if (added > 0)
                    v1100Dirty = true;

                V1100RenderIfDue();
            }
            catch
            {
            }
        }

        private void V1100RenderIfDue()
        {
            try
            {
                if (!v1100Dirty || visualLogBox == null || visualLogLines == null)
                    return;

                double sinceMs = (DateTime.UtcNow - v1100LastRenderUtc).TotalMilliseconds;

                if (sinceMs < V1100UiRenderMs)
                {
                    if (v1100RenderTimer == null)
                    {
                        v1100RenderTimer = new DispatcherTimer(DispatcherPriority.Background, Dispatcher);
                        v1100RenderTimer.Tick += (s, a) =>
                        {
                            v1100RenderTimer.Stop();
                            V1100RenderIfDue();
                        };
                    }

                    if (!v1100RenderTimer.IsEnabled)
                    {
                        v1100RenderTimer.Interval =
                            TimeSpan.FromMilliseconds(Math.Max(20, V1100UiRenderMs - sinceMs + 10));
                        v1100RenderTimer.Start();
                    }

                    return;
                }

                v1100LastRenderUtc = DateTime.UtcNow;
                v1100Dirty = false;

                string[] all = visualLogLines.ToArray();
                int start = Math.Max(0, all.Length - V1100VisibleLogLines);

                visualLogBox.Text = string.Join(Environment.NewLine, all, start, all.Length - start);
                visualLogBox.CaretIndex = visualLogBox.Text.Length;
                visualLogBox.ScrollToEnd();
            }
            catch
            {
            }
        }

        // ---------------------------------------------------------
        // Late trades -> volume only
        // ---------------------------------------------------------
        private void V1100CountLateTradeInTape(MarketDataEventArgs e)
        {
            if (!V1100LateTradesInTapeEnabled || e == null)
                return;

            try
            {
                // followers take the tape from the L2 brain
                if (V185IsL2Follower())
                    return;

                double volume = Math.Max(0, e.Volume);

                if (volume <= 0)
                    return;

                double ask = e.Ask;
                double bid = e.Bid;

                lock (level2Sync)
                {
                    level2TapeTrades++;

                    if (ask > 0 && e.Price >= ask)
                        level2AggBuy += volume;
                    else if (bid > 0 && e.Price <= bid)
                        level2AggSell += volume;
                }
            }
            catch
            {
            }
        }

        private void V1100CountLateTradeInCore20Tape(MarketDataEventArgs e)
        {
            if (!V1100LateTradesInTapeEnabled || e == null)
                return;

            try
            {
                double ask = e.Ask;
                double bid = e.Bid;
                double signedVolume = 0;

                if (ask > 0 && e.Price >= ask)
                    signedVolume = e.Volume;
                else if (bid > 0 && e.Price <= bid)
                    signedVolume = -e.Volume;

                if (signedVolume == 0)
                    return;

                lock (core20Sync)
                {
                    core20Tape.Enqueue(new KeyValuePair<DateTime, double>(e.Time, signedVolume));
                }
            }
            catch
            {
            }
        }
    }
}

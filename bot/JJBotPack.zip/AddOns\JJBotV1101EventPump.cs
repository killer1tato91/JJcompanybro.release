#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Threading;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.101 - EVENT PUMP + HEALTH MONITOR (26-oct-2026)
    // Problem (26-oct 09:35): NinjaTrader used ~10% CPU = ONE core at 100% while the PC was at 29%.
    // Every Level 2 depth event (~2,400/s at the open) and every trade for 4 bot windows was
    // processed inside NinjaTrader's market-data thread, so that one thread fell behind:
    // range bars 96 s late, ticks up to 94 s late.
    // Now each bot window copies the event (≈0.1 µs), puts it in its own queue and returns at once.
    // A dedicated background thread per window processes the queue IN ORDER with the exact same
    // code as before. NinjaTrader's thread stays free and the windows run in parallel on other cores.
    // The monitor writes one line per minute:
    //   "V1.7.101 HEALTH | Queue max .. | Wait max .. ms | Depth n avg/max ms | L2 data .. | CORE20 .. | CPU ..% | RAM .. MB | GC2 .."
    // Nothing here sends, changes or cancels orders. Switch off: V1101PumpEnabled = false.
    // =========================================================
    internal static class JJEventClone
    {
        private static readonly Func<object, object> clone = Create();

        private static Func<object, object> Create()
        {
            try
            {
                MethodInfo mi = typeof(object).GetMethod("MemberwiseClone", BindingFlags.Instance | BindingFlags.NonPublic);
                return (Func<object, object>)Delegate.CreateDelegate(typeof(Func<object, object>), mi);
            }
            catch
            {
                return null;
            }
        }

        // Shallow copy of the event args: NinjaTrader may recycle the original object.
        public static T Copy<T>(T args) where T : class
        {
            if (args == null || clone == null)
                return args;

            try { return (T)clone(args); }
            catch { return args; }
        }

        public static bool Available { get { return clone != null; } }
    }

    public partial class JJBotWindow
    {
        private const bool V1101PumpEnabled = true;
        private const int V1101IdleExitMs = 60000;       // worker thread ends after 60 s without events
        private const int V1101HealthLogSeconds = 60;

        private struct V1101Item
        {
            public byte Kind;          // 1 = depth, 2 = L2 market data, 3 = CORE20 market data
            public object Sender;
            public EventArgs Args;
            public long EnqueuedTs;
        }

        private readonly ConcurrentQueue<V1101Item> v1101Queue = new ConcurrentQueue<V1101Item>();
        private readonly SemaphoreSlim v1101Signal = new SemaphoreSlim(0, int.MaxValue);
        private int v1101WorkerRunning;
        private int v1101QueueCount;

        // health counters (worker thread only, except the queue max)
        private int v1101QueueMax;
        private long v1101WaitMaxTicks;
        private long v1101DepthN, v1101DepthTicks, v1101DepthMaxTicks;
        private long v1101DataN, v1101DataTicks, v1101DataMaxTicks;
        private long v1101C20N, v1101C20Ticks, v1101C20MaxTicks;
        private long v1101Errors;
        private DateTime v1101LastHealthUtc = DateTime.MinValue;
        private TimeSpan v1101LastCpu = TimeSpan.Zero;
        private DateTime v1101LastCpuUtc = DateTime.MinValue;

        // ---------------------------------------------------------
        // NinjaTrader event handlers (same names as before, so the existing
        // += / -= subscriptions keep working). The old bodies are now the V1101Core* methods.
        // ---------------------------------------------------------
        private void OnLevel2DepthUpdate(object sender, MarketDepthEventArgs e)
        {
            if (!V1101PumpEnabled || !JJEventClone.Available)
            {
                V1102MarkData();
                V1101CoreLevel2Depth(sender, e);
                return;
            }

            // a follower never builds its own book: skip before copying
            if (e == null || !level2ObserveActive || V185IsL2Follower())
                return;

            V1101Enqueue(1, sender, JJEventClone.Copy(e));
        }

        private void OnLevel2MarketDataUpdate(object sender, MarketDataEventArgs e)
        {
            if (!V1101PumpEnabled || !JJEventClone.Available)
            {
                V1102MarkData();
                V1101CoreLevel2MarketData(sender, e);
                return;
            }

            if (e == null || !level2ObserveActive)
                return;

            V1101Enqueue(2, sender, JJEventClone.Copy(e));
        }

        private void OnCore20MarketData(object sender, MarketDataEventArgs e)
        {
            if (!V1101PumpEnabled || !JJEventClone.Available)
            {
                V1102MarkData();
                V1101CoreCore20MarketData(sender, e);
                return;
            }

            if (e == null)
                return;

            V1101Enqueue(3, sender, JJEventClone.Copy(e));
        }

        // ---------------------------------------------------------
        // Queue + worker
        // ---------------------------------------------------------
        private void V1101Enqueue(byte kind, object sender, EventArgs args)
        {
            // V1.7.102 - the session guard needs to know the feed is alive
            V1102MarkData();

            v1101Queue.Enqueue(new V1101Item
            {
                Kind = kind,
                Sender = sender,
                Args = args,
                EnqueuedTs = Stopwatch.GetTimestamp()
            });

            int count = Interlocked.Increment(ref v1101QueueCount);

            if (count > v1101QueueMax)
                v1101QueueMax = count;

            v1101Signal.Release();

            if (Interlocked.CompareExchange(ref v1101WorkerRunning, 1, 0) == 0)
            {
                try
                {
                    Thread worker = new Thread(V1101WorkerLoop)
                    {
                        IsBackground = true,
                        Name = "JJBot event pump " + (platformProfileId ?? "profile"),
                        Priority = ThreadPriority.AboveNormal
                    };
                    worker.Start();
                }
                catch
                {
                    Interlocked.Exchange(ref v1101WorkerRunning, 0);
                }
            }
        }

        private void V1101WorkerLoop()
        {
            try
            {
                while (true)
                {
                    if (!v1101Signal.Wait(V1101IdleExitMs))
                    {
                        // idle: leave, a new event starts a new worker
                        Interlocked.Exchange(ref v1101WorkerRunning, 0);

                        // race: an event arrived between the timeout and the flag reset
                        if (v1101Queue.IsEmpty || Interlocked.CompareExchange(ref v1101WorkerRunning, 1, 0) != 0)
                            return;

                        continue;
                    }

                    V1101Item item;

                    if (!v1101Queue.TryDequeue(out item))
                        continue;

                    Interlocked.Decrement(ref v1101QueueCount);

                    long start = Stopwatch.GetTimestamp();
                    long wait = start - item.EnqueuedTs;

                    if (wait > v1101WaitMaxTicks)
                        v1101WaitMaxTicks = wait;

                    try
                    {
                        switch (item.Kind)
                        {
                            case 1:
                                V1101CoreLevel2Depth(item.Sender, (MarketDepthEventArgs)item.Args);
                                break;
                            case 2:
                                V1101CoreLevel2MarketData(item.Sender, (MarketDataEventArgs)item.Args);
                                break;
                            case 3:
                                V1101CoreCore20MarketData(item.Sender, (MarketDataEventArgs)item.Args);
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        v1101Errors++;

                        if (v1101Errors <= 5)
                        {
                            try { PrintBotMessage("V1.7.101 PUMP ERROR | Kind " + item.Kind + " | " + ex.GetType().Name + ": " + ex.Message); }
                            catch { }
                        }
                    }

                    long took = Stopwatch.GetTimestamp() - start;

                    switch (item.Kind)
                    {
                        case 1: v1101DepthN++; v1101DepthTicks += took; if (took > v1101DepthMaxTicks) v1101DepthMaxTicks = took; break;
                        case 2: v1101DataN++; v1101DataTicks += took; if (took > v1101DataMaxTicks) v1101DataMaxTicks = took; break;
                        case 3: v1101C20N++; v1101C20Ticks += took; if (took > v1101C20MaxTicks) v1101C20MaxTicks = took; break;
                    }

                    V1101HealthLogIfDue();
                }
            }
            catch
            {
                Interlocked.Exchange(ref v1101WorkerRunning, 0);
            }
        }

        // ---------------------------------------------------------
        // Health monitor (one line per minute per window)
        // ---------------------------------------------------------
        private static double V1101Ms(long ticks)
        {
            return ticks * 1000.0 / Stopwatch.Frequency;
        }

        private static string V1101Fmt(long n, long totalTicks, long maxTicks)
        {
            if (n <= 0)
                return "0";

            return n.ToString(CultureInfo.InvariantCulture)
                + " avg " + V1101Ms(totalTicks / n).ToString("0.000", CultureInfo.InvariantCulture)
                + " max " + V1101Ms(maxTicks).ToString("0.0", CultureInfo.InvariantCulture) + " ms";
        }

        private void V1101HealthLogIfDue()
        {
            DateTime nowUtc = DateTime.UtcNow;

            if (v1101LastHealthUtc == DateTime.MinValue)
            {
                v1101LastHealthUtc = nowUtc;
                return;
            }

            if ((nowUtc - v1101LastHealthUtc).TotalSeconds < V1101HealthLogSeconds)
                return;

            v1101LastHealthUtc = nowUtc;

            string cpu = "?";
            string ram = "?";

            try
            {
                Process p = Process.GetCurrentProcess();
                TimeSpan total = p.TotalProcessorTime;

                if (v1101LastCpuUtc != DateTime.MinValue)
                {
                    double wallMs = (nowUtc - v1101LastCpuUtc).TotalMilliseconds;
                    double cpuMs = (total - v1101LastCpu).TotalMilliseconds;
                    double pct = wallMs > 0 ? cpuMs / (wallMs * Environment.ProcessorCount) * 100.0 : 0;
                    double cores = wallMs > 0 ? cpuMs / wallMs : 0;
                    cpu = pct.ToString("0.0", CultureInfo.InvariantCulture) + "% (" + cores.ToString("0.00", CultureInfo.InvariantCulture)
                        + " of " + Environment.ProcessorCount + " cores)";
                }

                v1101LastCpu = total;
                v1101LastCpuUtc = nowUtc;
                ram = (p.WorkingSet64 / (1024 * 1024)).ToString(CultureInfo.InvariantCulture) + " MB";
            }
            catch
            {
            }

            string line =
                "V1.7.101 HEALTH | Queue now " + Math.Max(0, v1101QueueCount) + " max " + v1101QueueMax
                + " | Wait max " + V1101Ms(v1101WaitMaxTicks).ToString("0.0", CultureInfo.InvariantCulture) + " ms"
                + " | Depth " + V1101Fmt(v1101DepthN, v1101DepthTicks, v1101DepthMaxTicks)
                + " | L2 data " + V1101Fmt(v1101DataN, v1101DataTicks, v1101DataMaxTicks)
                + " | CORE20 " + V1101Fmt(v1101C20N, v1101C20Ticks, v1101C20MaxTicks)
                + " | Errors " + v1101Errors
                + " | CPU " + cpu
                + " | RAM " + ram
                + " | GC2 " + GC.CollectionCount(2);

            v1101QueueMax = 0;
            v1101WaitMaxTicks = 0;
            v1101DepthN = v1101DepthTicks = v1101DepthMaxTicks = 0;
            v1101DataN = v1101DataTicks = v1101DataMaxTicks = 0;
            v1101C20N = v1101C20Ticks = v1101C20MaxTicks = 0;

            try { PrintBotMessage(line); }
            catch { }
        }
    }
}

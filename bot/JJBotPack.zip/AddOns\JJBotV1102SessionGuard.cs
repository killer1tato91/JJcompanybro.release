#region Using declarations
using System;
using System.Threading;
using System.Windows.Threading;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.102 - SESSION GUARD (26-oct-2026)
    // Problem: after the 16:25 FORCE FLAT the daily lock stayed on the next session and the bot
    // had to be stopped/started by hand (bad on a VPS). Cause, seen on 19-oct: at the 17:00 CME
    // pause the market-data / bars subscriptions went silent and did NOT come back at the 18:00
    // reopen. The new-session reset (EnsureTradingDay) only ran from bar updates, so it never ran.
    // Fix (a 10-second clock timer per bot window, independent of the data):
    //   1) SESSION RESET BY CLOCK: at 18:00 ET the new session starts even without data
    //      (counters, FORCE FLAT lock and daily locks of the old day are released exactly like a
    //      normal rollover; after 18:00 the bot is in ASIA OBSERVE, as always).
    //   2) FEED REVIVAL: while the market is open, if no market event arrived for 120 s the data
    //      engine is restarted (same as the data part of STOP/START). Orders and positions are not
    //      touched. At most once every 5 minutes.
    // Switch off: V1102SessionGuardEnabled = false.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1102SessionGuardEnabled = true;
        private const int V1102TickSeconds = 10;
        private const int V1102NoDataSeconds = 120;
        private const int V1102ReviveEverySeconds = 300;

        private DispatcherTimer v1102Timer;
        private int v1102TimerRequested;
        private long v1102LastDataUtcTicks;
        private DateTime v1102LastReviveUtc = DateTime.MinValue;
        private DateTime v1102LastSessionDate = DateTime.MinValue;

        // called from the event pump on every market event (cheap)
        private void V1102MarkData()
        {
            Interlocked.Exchange(ref v1102LastDataUtcTicks, DateTime.UtcNow.Ticks);

            if (Interlocked.CompareExchange(ref v1102TimerRequested, 1, 0) == 0)
            {
                try { Dispatcher.InvokeAsync(new Action(V1102EnsureTimer)); }
                catch { Interlocked.Exchange(ref v1102TimerRequested, 0); }
            }
        }

        private void V1102EnsureTimer()
        {
            // V1.7.106 - orphan order guard (1 s timer) starts here too.
            V1106EnsureOrphanTimer();

            // V1.7.111 - hard protection watchdog (250 ms) starts here too.
            V1111EnsureHardProtectionWatchdog();

            if (!V1102SessionGuardEnabled || v1102Timer != null)
                return;

            try
            {
                v1102Timer = new DispatcherTimer(DispatcherPriority.Background, Dispatcher);
                v1102Timer.Interval = TimeSpan.FromSeconds(V1102TickSeconds);
                v1102Timer.Tick += V1102TimerTick;
                v1102Timer.Start();
            }
            catch
            {
            }
        }

        // CME index futures: open Sun 18:00 -> Fri 17:00 ET, daily pause 17:00-18:00 ET.
        private static bool V1102MarketOpen(DateTime ny)
        {
            TimeSpan t = ny.TimeOfDay;

            switch (ny.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    return false;
                case DayOfWeek.Sunday:
                    return t >= new TimeSpan(18, 0, 0);
                case DayOfWeek.Friday:
                    return t < new TimeSpan(17, 0, 0);
                default:
                    return t < new TimeSpan(17, 0, 0) || t >= new TimeSpan(18, 0, 0);
            }
        }

        private void V1102TimerTick(object sender, EventArgs e)
        {
            if (!V1102SessionGuardEnabled || !botRunning)
                return;

            try
            {
                if (IsPlaybackStrategyClockActive())
                    return;

                DateTime nowNy = GetCurrentNewYorkTime();
                DateTime nowUtc = DateTime.UtcNow;

                // 1) session reset by the clock (does nothing if the session did not change)
                DateTime sessionDate = GetTradingSessionDate(nowNy);

                if (sessionDate != v1102LastSessionDate)
                {
                    bool wasLocked = persistentDailyLocked;
                    string oldReason = persistentDailyLockReason;
                    DateTime before = activeTradingDate;

                    EnsureTradingDay(nowNy);

                    if (before != DateTime.MinValue && activeTradingDate != before)
                    {
                        PrintBotMessage(
                            "V1.7.102 SESSION RESET BY CLOCK | New session " + activeTradingDate.ToString("yyyy-MM-dd")
                            + " | " + nowNy.ToString("HH:mm:ss") + " ET"
                            + (wasLocked ? " | Released lock: " + (string.IsNullOrEmpty(oldReason) ? "-" : oldReason) : string.Empty));
                    }

                    v1102LastSessionDate = sessionDate;
                }

                // V1.7.107 - a FORCE FLAT lock never survives outside its own window
                // (force-flat time -> 18:00 ET on weekdays). Clears within 10 s.
                V1107ClearStaleForceFlatLock(nowNy);

                // 2) feed revival
                if (!V1102MarketOpen(nowNy))
                    return;

                // give the reopen 2 minutes before judging the feed
                TimeSpan t = nowNy.TimeOfDay;
                if (t >= new TimeSpan(18, 0, 0) && t < new TimeSpan(18, 2, 0))
                    return;

                long lastTicks = Interlocked.Read(ref v1102LastDataUtcTicks);
                if (lastTicks == 0)
                    return;

                double silentSec = (nowUtc - new DateTime(lastTicks, DateTimeKind.Utc)).TotalSeconds;

                if (silentSec < V1102NoDataSeconds)
                    return;

                if (v1102LastReviveUtc != DateTime.MinValue
                    && (nowUtc - v1102LastReviveUtc).TotalSeconds < V1102ReviveEverySeconds)
                    return;

                v1102LastReviveUtc = nowUtc;

                PrintBotMessage(
                    "V1.7.102 FEED REVIVAL | No market data for " + silentSec.ToString("0") + " s with the market open"
                    + " | Restarting the data engine (orders and positions untouched)");

                // count the restart as data so the next check waits for real silence again
                Interlocked.Exchange(ref v1102LastDataUtcTicks, nowUtc.Ticks);

                StartBarsEngine();
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("V1.7.102 SESSION GUARD ERROR: " + ex.Message); }
                catch { }
            }
        }
    }
}

#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Threading;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.103 - SHADOW WORKER (26-oct-2026)
    // The V1.7.98 HVN-absorption and V1.7.99 delta shadows are LOG-ONLY, but they ran inside the
    // Level 2 leader's tick handler on every trade: up to 1-3 ms per trade at the open
    // (10-minute leg max/min + sorting a 1,080-item list each trade). 26-oct 10:00-10:12 the L2
    // brain's queue reached 144,000 events / 48 s wait and the bot entered on stale context.
    // Now the tick handler only copies 10 numbers into a queue; a low-priority background thread
    // runs both shadows. If the shadows ever fall behind they lag alone (cap 300,000, then they
    // drop rows) - the bot never waits for them. Results/CSV files are the same.
    // Switch off the worker (back to inline): V1103ShadowWorkerEnabled = false.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1103ShadowWorkerEnabled = true;
        private const int V1103MaxQueue = 300000;

        private struct V1103Trade
        {
            public DateTime Time;
            public double Price, Volume, Bid, Ask, Tick, BestBidVol, BestAskVol;
            public string Tape, Confluence;
        }

        private readonly ConcurrentQueue<V1103Trade> v1103Queue = new ConcurrentQueue<V1103Trade>();
        private readonly SemaphoreSlim v1103Signal = new SemaphoreSlim(0, int.MaxValue);
        private int v1103Count;
        private int v1103Running;
        private long v1103Dropped;

        // Called from the L2 tick handler (leader only) while level2Sync is held - same name and
        // arguments as before, so the existing call in JJBotOrderFlowEngine.cs is unchanged.
        private void V198AbsorptionOnTrade(DateTime marketTime, double price, double volume, double bid, double ask, double tick)
        {
            double bestBidVol = level2BidRows.Count > 0 ? level2BidRows[0].Volume : -1;
            double bestAskVol = level2AskRows.Count > 0 ? level2AskRows[0].Volume : -1;

            if (!V1103ShadowWorkerEnabled)
            {
                V1103ShadowProcess(marketTime, price, volume, bid, ask, tick, bestBidVol, bestAskVol, level2TapeBias, level2Confluence);
                return;
            }

            if (Interlocked.Increment(ref v1103Count) > V1103MaxQueue)
            {
                Interlocked.Decrement(ref v1103Count);
                v1103Dropped++;
                return;
            }

            v1103Queue.Enqueue(new V1103Trade
            {
                Time = marketTime,
                Price = price,
                Volume = volume,
                Bid = bid,
                Ask = ask,
                Tick = tick,
                BestBidVol = bestBidVol,
                BestAskVol = bestAskVol,
                Tape = level2TapeBias,
                Confluence = level2Confluence
            });

            v1103Signal.Release();

            if (Interlocked.CompareExchange(ref v1103Running, 1, 0) == 0)
            {
                try
                {
                    Thread t = new Thread(V1103Loop)
                    {
                        IsBackground = true,
                        Name = "JJBot shadow worker",
                        Priority = ThreadPriority.BelowNormal
                    };
                    t.Start();
                }
                catch
                {
                    Interlocked.Exchange(ref v1103Running, 0);
                }
            }
        }

        private void V1103Loop()
        {
            try
            {
                while (true)
                {
                    if (!v1103Signal.Wait(60000))
                    {
                        Interlocked.Exchange(ref v1103Running, 0);
                        if (v1103Queue.IsEmpty || Interlocked.CompareExchange(ref v1103Running, 1, 0) != 0)
                            return;
                        continue;
                    }

                    V1103Trade x;
                    if (!v1103Queue.TryDequeue(out x))
                        continue;

                    Interlocked.Decrement(ref v1103Count);

                    try
                    {
                        V1103ShadowProcess(x.Time, x.Price, x.Volume, x.Bid, x.Ask, x.Tick, x.BestBidVol, x.BestAskVol, x.Tape, x.Confluence);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
                Interlocked.Exchange(ref v1103Running, 0);
            }
        }
    }
}

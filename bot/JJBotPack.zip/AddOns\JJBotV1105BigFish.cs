#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.105 - BIG FISH (26-oct-2026)
    // STAGE 1 (ACTIVE, JJBotExecutionEngine.cs): HYBRID does not enter AGAINST a confirmed absorption
    //   of the last 60 s until price breaks that level by 8 ticks, nor against the order-book bias.
    // STAGE 2 (THIS FILE, LOG ONLY): "follow the big fish". After a HEAVY ABSORPTION CONFIRMED, if
    //   price moves 5 ticks away from the absorbed level in the absorber's direction within 60 s, a
    //   virtual trade is opened WITH the absorber: entry 1 tick worse, SL 4 ticks beyond the absorbed
    //   level (min 8 ticks), TP 80 ticks (20 pts), exit at market after 30 min.
    //   Runs on the shadow worker thread of the Level 2 leader only. Never sends orders.
    //   File: JJBotData\Learning\hybrid_bigfish_shadow.csv   Log: "BIG FISH SHADOW | START/DONE"
    // Switches: V1105BigFishGateEnabled, V1105BookGateEnabled (stage 1), V1105BigFishShadowEnabled.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1105BigFishGateEnabled = true;
        private const bool V1105BookGateEnabled = true;
        private const double V1105BigFishHoldSeconds = 60.0;
        private const int V1105BigFishBreakTicks = 8;

        private const bool V1105BigFishShadowEnabled = true;
        private const int V1105FollowTicks = 5;
        private const int V1105StopBeyondTicks = 4;
        private const int V1105MinStopTicks = 8;
        private const int V1105TpTicks = 80;
        private const double V1105MaxHoldSec = 1800;
        private const double V1105ArmSeconds = 60;

        private sealed class V1105Virt
        {
            public string Id;
            public int Side;
            public DateTime Start;
            public DateTime EventUtc;
            public double Level;
            public double Entry;
            public int SlTicks;
            public double Mfe, Mae;
            public string How;
            public double Ticks;
            public double ExitSec;
        }

        private readonly List<V1105Virt> v1105Open = new List<V1105Virt>();
        private DateTime v1105ArmedEventUtc = DateTime.MinValue;
        private string v1105ArmedSide = "NONE";
        private double v1105ArmedLevel;
        private DateTime v1105ArmedMarketTime = DateTime.MinValue;
        private bool v1105ArmedUsed;
        private DateTime v1105LastSeenEventUtc = DateTime.MinValue;
        private static readonly object v1105CsvSync = new object();

        // shadow worker thread (L2 leader)
        private void V1105BigFishOnTrade(DateTime marketTime, double price, double tick)
        {
            if (!V1105BigFishShadowEnabled || price <= 0)
                return;

            try
            {
                if (tick <= 0) tick = 0.25;

                string side;
                DateTime evUtc;
                double level;

                lock (level2Sync)
                {
                    side = level2LastConfirmedAbsorptionMemorySide ?? "NONE";
                    evUtc = level2LastConfirmedAbsorptionMemoryUtc;
                    level = level2LastConfirmedAbsorptionMemoryExtremePrice;
                }

                // a new confirmed absorption arms the follower
                if (evUtc != DateTime.MinValue && evUtc != v1105LastSeenEventUtc && level > 0
                    && (string.Equals(side, "BUY", StringComparison.OrdinalIgnoreCase) || string.Equals(side, "SELL", StringComparison.OrdinalIgnoreCase)))
                {
                    v1105LastSeenEventUtc = evUtc;
                    v1105ArmedEventUtc = evUtc;
                    v1105ArmedSide = side.ToUpperInvariant();
                    v1105ArmedLevel = level;
                    v1105ArmedMarketTime = marketTime;
                    v1105ArmedUsed = false;
                }

                // trigger: price leaves the absorbed level in the absorber's direction
                if (!v1105ArmedUsed && v1105ArmedEventUtc != DateTime.MinValue
                    && (marketTime - v1105ArmedMarketTime).TotalSeconds <= V1105ArmSeconds)
                {
                    TimeSpan tod = ConvertToNewYorkTime(marketTime).TimeOfDay;
                    bool rth = tod >= new TimeSpan(9, 30, 0) && tod < new TimeSpan(15, 55, 0);

                    int sideNum = v1105ArmedSide == "BUY" ? 1 : -1;   // BUY control -> follow LONG
                    double away = (price - v1105ArmedLevel) * sideNum / tick;

                    if (rth && away >= V1105FollowTicks)
                    {
                        v1105ArmedUsed = true;

                        double entry = price + sideNum * tick;
                        double stopPrice = v1105ArmedLevel - sideNum * V1105StopBeyondTicks * tick;
                        int sl = (int)Math.Max(V1105MinStopTicks, Math.Round((entry - stopPrice) * sideNum / tick));
                        DateTime ny = ConvertToNewYorkTime(marketTime);

                        V1105Virt v = new V1105Virt
                        {
                            Id = ny.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + (sideNum > 0 ? "_L" : "_S"),
                            Side = sideNum,
                            Start = marketTime,
                            EventUtc = v1105ArmedEventUtc,
                            Level = v1105ArmedLevel,
                            Entry = entry,
                            SlTicks = sl
                        };

                        v1105Open.Add(v);

                        PrintBotMessage("BIG FISH SHADOW | START | " + v.Id + " | " + (sideNum > 0 ? "LONG" : "SHORT")
                            + " @ " + entry.ToString("0.00", CultureInfo.InvariantCulture)
                            + " | Absorbed level " + v.Level.ToString("0.00", CultureInfo.InvariantCulture)
                            + " (" + v1105ArmedSide + " control) | SL " + sl + "t TP " + V1105TpTicks + "t | LOG ONLY");
                    }
                }

                // follow open virtual trades
                if (v1105Open.Count == 0)
                    return;

                List<V1105Virt> done = null;

                foreach (V1105Virt v in v1105Open)
                {
                    double move = (price - v.Entry) * v.Side / tick;
                    double sec = (marketTime - v.Start).TotalSeconds;
                    if (move > v.Mfe) v.Mfe = move;
                    if (move < v.Mae) v.Mae = move;

                    if (move <= -v.SlTicks) { v.How = "SL"; v.Ticks = -v.SlTicks - 1; }
                    else if (move >= V1105TpTicks) { v.How = "TP"; v.Ticks = V1105TpTicks; }
                    else if (sec >= V1105MaxHoldSec) { v.How = "TIME"; v.Ticks = move; }
                    else continue;

                    v.ExitSec = sec;
                    if (done == null) done = new List<V1105Virt>();
                    done.Add(v);
                }

                if (done == null)
                    return;

                foreach (V1105Virt v in done)
                {
                    v1105Open.Remove(v);

                    PrintBotMessage("BIG FISH SHADOW | DONE | " + v.Id + " | " + v.How + " "
                        + v.Ticks.ToString("0", CultureInfo.InvariantCulture) + "t | MFE "
                        + v.Mfe.ToString("0", CultureInfo.InvariantCulture) + "t MAE "
                        + v.Mae.ToString("0", CultureInfo.InvariantCulture) + "t | "
                        + v.ExitSec.ToString("0", CultureInfo.InvariantCulture) + "s");

                    V1105WriteCsv(v);
                }
            }
            catch
            {
            }
        }

        private void V1105WriteCsv(V1105Virt v)
        {
            try
            {
                string root = stateFolderPath;
                if (string.IsNullOrWhiteSpace(root))
                    root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData");

                string folder = Path.Combine(root, "Learning");
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, "hybrid_bigfish_shadow.csv");

                StringBuilder sb = new StringBuilder();
                lock (v1105CsvSync)
                {
                    if (!File.Exists(path))
                        sb.AppendLine("Id,Side,EntryNy,Level,Entry,SlTicks,Exit,Ticks,MfeTicks,MaeTicks,Seconds");

                    sb.AppendLine(string.Join(",", new[]
                    {
                        v.Id,
                        v.Side > 0 ? "LONG" : "SHORT",
                        ConvertToNewYorkTime(v.Start).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        v.Level.ToString("0.00", CultureInfo.InvariantCulture),
                        v.Entry.ToString("0.00", CultureInfo.InvariantCulture),
                        v.SlTicks.ToString(CultureInfo.InvariantCulture),
                        v.How,
                        v.Ticks.ToString("0", CultureInfo.InvariantCulture),
                        v.Mfe.ToString("0", CultureInfo.InvariantCulture),
                        v.Mae.ToString("0", CultureInfo.InvariantCulture),
                        v.ExitSec.ToString("0", CultureInfo.InvariantCulture)
                    }));

                    File.AppendAllText(path, sb.ToString());
                }
            }
            catch
            {
            }
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Threading;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.106 - EXIT GUARD (26-oct-2026)
    // Incident 26-oct 14:47:22 (account 022): HYBRID TIME EXIT sent a Flatten. Flatten first
    // cancels the SL/TP, and each "Cancelled" callback arrived while the position was still
    // open, so the bracket repair (V1.7.93 "cancelled order is not protection") built a NEW
    // OCO bracket - twice - just before the market Close filled. Result: the account was flat
    // with 2 sell stops + 2 sell limits (4 MNQ each) working for 8 s. Any touch of 29483.25 or
    // 29518.25 would have opened an unprotected SHORT of up to 8 contracts.
    // Fix: no SL/TP is built during the first seconds after a close/flatten was sent.
    // If the position is somehow still open after that window, the normal repair runs again.
    // Nothing else changes. Switch off: V1106ExitGuardEnabled = false.
    //
    // ORPHAN ORDER GUARD (same incident: the orders stayed until Killer cancelled them by hand).
    // Every second: if the REAL position of this account/instrument is FLAT, no entry is pending
    // and THIS profile's own protective orders (Pn_JJ_STOP / Pn_JJ_TARGET / Pn_JJ_PARTIAL_TP1/2)
    // are still working for 2 s, they are cancelled. Manual orders and other profiles' orders
    // are never touched. Log: "V1.7.106 ORPHAN ORDERS CANCELLED".
    // Switch off: V1106OrphanGuardEnabled = false.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1106ExitGuardEnabled = true;
        private const double V1106ReArmBlockSeconds = 6.0;
        private DateTime v1106LastSkipLogUtc = DateTime.MinValue;

        private bool V1106FlattenInFlight()
        {
            if (!V1106ExitGuardEnabled)
                return false;

            DateTime sent = lastAnyFlattenSentUtc;

            if (sent == DateTime.MinValue)
                return false;

            double sec = (DateTime.UtcNow - sent).TotalSeconds;

            if (sec < 0 || sec >= V1106ReArmBlockSeconds)
                return false;

            if ((DateTime.UtcNow - v1106LastSkipLogUtc).TotalSeconds >= 2)
            {
                v1106LastSkipLogUtc = DateTime.UtcNow;

                try
                {
                    PrintBotMessage(
                        "V1.7.106 BRACKET RE-ARM SKIPPED | Close/flatten sent "
                        + sec.ToString("0.0", CultureInfo.InvariantCulture)
                        + "s ago | No new SL/TP while the position is being closed");
                }
                catch
                {
                }
            }

            return true;
        }
        // ---------------------------------------------------------
        // ORPHAN ORDER GUARD
        // ---------------------------------------------------------
        private const bool V1106OrphanGuardEnabled = true;
        private const double V1106OrphanGraceSeconds = 2.0;
        private DispatcherTimer v1106OrphanTimer;
        private DateTime v1106OrphanSinceUtc = DateTime.MinValue;
        private DateTime v1106OrphanLastCancelUtc = DateTime.MinValue;
        private DateTime v1106OrphanLastErrorLogUtc = DateTime.MinValue;

        // UI thread (started together with the V1.7.102 session guard timer)
        private void V1106EnsureOrphanTimer()
        {
            if (!V1106OrphanGuardEnabled || v1106OrphanTimer != null)
                return;

            try
            {
                v1106OrphanTimer = new DispatcherTimer(DispatcherPriority.Background, Dispatcher);
                v1106OrphanTimer.Interval = TimeSpan.FromSeconds(1);
                v1106OrphanTimer.Tick += V1106OrphanTick;
                v1106OrphanTimer.Start();
            }
            catch
            {
            }
        }

        private static bool V1106IsLiveOrderState(OrderState state)
        {
            return state == OrderState.Working
                || state == OrderState.Accepted
                || state == OrderState.Submitted
                || state == OrderState.TriggerPending
                || state == OrderState.ChangePending
                || state == OrderState.ChangeSubmitted;
        }

        private void V1106OrphanTick(object sender, EventArgs e)
        {
            // V1.7.107 - phone alerts (protected / near TP) share this 1 s timer
            V1107TradeAlertTick();

            try
            {
                if (v186IsDedicatedBrain)
                    return;

                Account account = selectedAccount;
                Instrument instrument = selectedInstrument;

                if (account == null || instrument == null)
                {
                    v1106OrphanSinceUtc = DateTime.MinValue;
                    return;
                }

                bool pending;
                lock (executionStateLock)
                {
                    pending = entryPending;
                }

                MarketPosition side;
                int qty;
                double avg;
                bool flat = TryGetSelectedInstrumentPosition(out side, out qty, out avg);

                if (!flat || pending)
                {
                    v1106OrphanSinceUtc = DateTime.MinValue;
                    return;
                }

                string[] names =
                {
                    GetProfileOrderName("JJ_STOP"),
                    GetProfileOrderName("JJ_TARGET"),
                    GetProfileOrderName("JJ_PARTIAL_TP1"),
                    GetProfileOrderName("JJ_PARTIAL_TP2")
                };

                List<Order> orphans = new List<Order>();

                lock (account.Orders)
                {
                    foreach (Order o in account.Orders)
                    {
                        if (o == null || o.Instrument == null)
                            continue;

                        if (o.Instrument.FullName != instrument.FullName)
                            continue;

                        if (!V1106IsLiveOrderState(o.OrderState))
                            continue;

                        if (Array.IndexOf(names, o.Name) < 0)
                            continue;

                        orphans.Add(o);
                    }
                }

                if (orphans.Count == 0)
                {
                    v1106OrphanSinceUtc = DateTime.MinValue;
                    return;
                }

                DateTime nowUtc = DateTime.UtcNow;

                if (v1106OrphanSinceUtc == DateTime.MinValue)
                {
                    v1106OrphanSinceUtc = nowUtc;
                    return;
                }

                if ((nowUtc - v1106OrphanSinceUtc).TotalSeconds < V1106OrphanGraceSeconds)
                    return;

                if (v1106OrphanLastCancelUtc != DateTime.MinValue && (nowUtc - v1106OrphanLastCancelUtc).TotalSeconds < 2)
                    return;

                v1106OrphanLastCancelUtc = nowUtc;

                List<string> desc = new List<string>();
                foreach (Order o in orphans)
                {
                    double px = o.StopPrice > 0 ? o.StopPrice : o.LimitPrice;
                    desc.Add(o.Name + " " + o.OrderAction + " " + o.Quantity + " @ " + px.ToString("0.00", CultureInfo.InvariantCulture));
                }

                account.Cancel(orphans);

                PrintBotMessage(
                    "V1.7.106 ORPHAN ORDERS CANCELLED | Position FLAT | " + orphans.Count + " order(s): "
                    + string.Join(", ", desc)
                    + " | They could have opened a position without protection");
            }
            catch (Exception ex)
            {
                if ((DateTime.UtcNow - v1106OrphanLastErrorLogUtc).TotalSeconds >= 30)
                {
                    v1106OrphanLastErrorLogUtc = DateTime.UtcNow;
                    try { PrintBotMessage("V1.7.106 ORPHAN GUARD ERROR: " + ex.Message); }
                    catch { }
                }
            }
        }
    }
}

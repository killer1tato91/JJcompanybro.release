#region Using declarations
using System;
using System.Globalization;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.107 - FORCE FLAT 16:01 + LOCK RELEASE (26-oct-2026)
    // 1) Force flat moved from 16:25 to 16:01 ET (MFFU closes positions itself at 16:10 ET).
    //    Constant: ForceFlatTimeNy in JJBotControl.cs. Lock reason now follows the constant
    //    ("FORCE FLAT 16:01 ET"); old saved "FORCE FLAT 16:25 ET" locks are still recognised.
    // 2) 26-oct 17:59:59 the new session (27-oct) started from a market timestamp ~1 s ahead
    //    of the PC clock; the force-flat check (PC clock 17:59:59, "inside" 16:25-18:00) then
    //    locked the NEW session -> bot stuck in "FORCE FLAT" until a manual STOP/START.
    //    a) JJBotRiskManager: the lock is only set for the session that is closing.
    //    b) V1.7.102 session timer (every 10 s): a FORCE FLAT lock outside its own window
    //       (force-flat time -> 18:00 ET, weekdays) is released. Log: "V1.7.107 FORCE FLAT LOCK RELEASED".
    // =========================================================
    public partial class JJBotWindow
    {
        private string V1107ForceFlatReason()
        {
            int hh = ForceFlatTimeNy / 10000;
            int mm = (ForceFlatTimeNy / 100) % 100;
            return "FORCE FLAT " + hh.ToString("00", CultureInfo.InvariantCulture) + ":" + mm.ToString("00", CultureInfo.InvariantCulture) + " ET";
        }

        private static bool V1107IsForceFlatReason(string reason)
        {
            return !string.IsNullOrWhiteSpace(reason)
                && reason.Trim().StartsWith("FORCE FLAT", StringComparison.OrdinalIgnoreCase);
        }

        // UI thread (V1.7.102 session timer)
        private void V1107ClearStaleForceFlatLock(DateTime nowNy)
        {
            if (!persistentDailyLocked || !V1107IsForceFlatReason(persistentDailyLockReason))
                return;

            int t = ToTimeInt(nowNy);

            bool windowActive =
                nowNy.DayOfWeek != DayOfWeek.Saturday &&
                nowNy.DayOfWeek != DayOfWeek.Sunday &&
                t >= ForceFlatTimeNy &&
                t < TradingSessionResetTimeNy;

            // Still inside the closing window of the SAME session: the lock is valid.
            if (windowActive && (activeTradingDate == DateTime.MinValue || GetTradingSessionDate(nowNy) == activeTradingDate))
                return;

            // Market closed for the weekend: nothing can trade anyway, keep it simple and wait
            // for the Sunday 18:00 reopen.
            if (!V1102MarketOpen(nowNy))
                return;

            string old = persistentDailyLockReason;

            persistentDailyLocked = false;
            persistentDailyLockReason = string.Empty;
            forceFlatSentToday = false;
            forceFlatDateNy = DateTime.MinValue;
            riskFlattenSent = false;
            riskFlattenStage = 0;
            riskFlattenLastActionUtc = DateTime.MinValue;
            riskFlattenOrder = null;

            SavePersistentDailyState();

            PrintBotMessage(
                "V1.7.107 FORCE FLAT LOCK RELEASED | " + nowNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + " ET"
                + " | Session " + activeTradingDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                + " | Old lock: " + old);
        }
    }
}

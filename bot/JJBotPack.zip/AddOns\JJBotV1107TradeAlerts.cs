#region Using declarations
using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.107 - TRADE ALERTS TO THE PHONE (26-oct-2026)
    // The cloud server only receives executions, so it could not know when the bot moved the
    // stop into profit or when price was about to hit the TP. Every second (V1.7.106 guard
    // timer) the bot checks its own open trade and posts to
    // https://jjtradingtools.ddns.net/api/trades/bot-alert:
    //   PROTECTED   - the SL is now beyond the entry: "Trade protegido +$X" (again each time
    //                 the locked amount grows)
    //   NEAR_TARGET - price is 2 points (8 ticks) or less from the TP (once per trade)
    // Fire-and-forget on a background task: never blocks or changes orders.
    // Switch off: V1107TradeAlertsEnabled = false.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1107TradeAlertsEnabled = true;
        private const string V1107CloudUrl = "https://jjtradingtools.ddns.net/api/trades/bot-alert";
        private const double V1107NearTargetPoints = 2.0;

        private string v1107TradeKey = string.Empty;
        private int v1107LastLockedTicks = 0;
        private bool v1107NearSent;
        private string v1107ApiKey;
        private DateTime v1107ApiKeyLoadedUtc = DateTime.MinValue;

        // UI thread, called every second from the V1.7.106 timer
        private void V1107TradeAlertTick()
        {
            if (!V1107TradeAlertsEnabled || v186IsDedicatedBrain)
                return;

            try
            {
                Account account = selectedAccount;
                Instrument instrument = selectedInstrument;

                if (account == null || instrument == null || instrument.MasterInstrument == null)
                    return;

                MarketPosition side;
                double entry, stop, target;
                int qty;
                DateTime entryUtc;

                lock (executionStateLock)
                {
                    side = entryMarketPosition;
                    entry = entryFillPrice;
                    stop = activeStopPrice;
                    target = activeTargetPrice;
                    qty = Math.Max(0, entryQuantity - activeExitQuantity);
                    entryUtc = activeTradeEntryUtc;
                }

                if (side == MarketPosition.Flat || qty <= 0 || entry <= 0 || entryUtc == DateTime.MinValue)
                {
                    v1107TradeKey = string.Empty;
                    return;
                }

                string key = account.Name + "_" + entryUtc.Ticks.ToString(CultureInfo.InvariantCulture);

                if (key != v1107TradeKey)
                {
                    v1107TradeKey = key;
                    v1107LastLockedTicks = 0;
                    v1107NearSent = false;
                }

                double tick = instrument.MasterInstrument.TickSize > 0 ? instrument.MasterInstrument.TickSize : 0.25;
                double pv = instrument.MasterInstrument.PointValue > 0 ? instrument.MasterInstrument.PointValue : 2.0;
                int dir = side == MarketPosition.Long ? 1 : -1;
                string sideText = dir > 0 ? "LONG" : "SHORT";

                // 1) protected
                if (stop > 0)
                {
                    int locked = (int)Math.Round((stop - entry) * dir / tick);

                    if (locked >= 1 && locked > v1107LastLockedTicks)
                    {
                        v1107LastLockedTicks = locked;
                        double lockedUsd = locked * tick * pv * qty;

                        V1107Post(
                            "\"kind\":\"PROTECTED\""
                            + ",\"lockedTicks\":" + locked.ToString(CultureInfo.InvariantCulture)
                            + ",\"lockedUsd\":" + lockedUsd.ToString("0.00", CultureInfo.InvariantCulture)
                            + ",\"stopPrice\":" + stop.ToString("0.00", CultureInfo.InvariantCulture),
                            account.Name, instrument.FullName, sideText, key);
                    }
                }

                // 2) near target
                if (!v1107NearSent && target > 0)
                {
                    double price;
                    lock (level2Sync)
                    {
                        price = level2LastTradePrice;
                    }

                    if (price > 0)
                    {
                        double pts = (target - price) * dir;

                        if (pts > 0 && pts <= V1107NearTargetPoints)
                        {
                            v1107NearSent = true;
                            double openUsd = (price - entry) * dir * pv * qty;

                            V1107Post(
                                "\"kind\":\"NEAR_TARGET\""
                                + ",\"pointsToTarget\":" + pts.ToString("0.00", CultureInfo.InvariantCulture)
                                + ",\"price\":" + price.ToString("0.00", CultureInfo.InvariantCulture)
                                + ",\"targetPrice\":" + target.ToString("0.00", CultureInfo.InvariantCulture)
                                + ",\"unrealizedUsd\":" + openUsd.ToString("0.00", CultureInfo.InvariantCulture),
                                account.Name, instrument.FullName, sideText, key);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void V1107Post(string fields, string account, string symbol, string side, string tradeKey)
        {
            string apiKey = V1107GetApiKey();

            if (string.IsNullOrWhiteSpace(apiKey))
                return;

            string json =
                "{\"apiKey\":\"" + V1107Esc(apiKey) + "\""
                + ",\"account\":\"" + V1107Esc(account) + "\""
                + ",\"symbol\":\"" + V1107Esc(symbol) + "\""
                + ",\"side\":\"" + side + "\""
                + ",\"tradeKey\":\"" + V1107Esc(tradeKey) + "\","
                + fields + "}";

            string logKind = fields.Contains("PROTECTED") ? "PROTECTED" : "NEAR TP";

            Task.Run(() =>
            {
                try
                {
                    using (WebClient client = new WebClient())
                    {
                        client.Encoding = Encoding.UTF8;
                        client.Headers[HttpRequestHeader.ContentType] = "application/json";
                        client.UploadString(V1107CloudUrl, "POST", json);
                    }

                    try { PrintBotMessage("V1.7.107 PHONE ALERT SENT | " + logKind + " | " + account); } catch { }
                }
                catch (Exception ex)
                {
                    try { PrintBotMessage("V1.7.107 PHONE ALERT ERROR | " + logKind + " | " + ex.Message); } catch { }
                }
            });
        }

        private string V1107GetApiKey()
        {
            if (!string.IsNullOrWhiteSpace(v1107ApiKey) && (DateTime.UtcNow - v1107ApiKeyLoadedUtc).TotalMinutes < 10)
                return v1107ApiKey;

            string found = string.Empty;

            try
            {
                string documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string[] candidates =
                {
                    Path.Combine(documents, "J&J Company Bro", "config.json"),
                    Path.Combine(documents, "JJ Trading Tools", "config.json")
                };

                foreach (string file in candidates)
                {
                    if (!File.Exists(file))
                        continue;

                    Match m = Regex.Match(File.ReadAllText(file), "\"apiKey\"\\s*:\\s*\"([^\"]+)\"", RegexOptions.IgnoreCase);

                    if (m.Success)
                    {
                        found = m.Groups[1].Value;
                        break;
                    }
                }
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(found))
                found = platformApiKey ?? string.Empty;

            v1107ApiKey = found;
            v1107ApiKeyLoadedUtc = DateTime.UtcNow;
            return found;
        }

        private static string V1107Esc(string v)
        {
            return (v ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}

// =====================================================================
// JJ BOT V1.7.108 - ACCOUNT LINK AGENT (add / connect broker connections
// requested from the APK). Independent AddOn: works even if no bot window
// is open.
//
// Flow (same as a person):
//   ADD     -> Connections dropdown -> "configure" -> Available item
//              ("NinjaTrader" for Tradovate, "Rithmic for NinjaTrader Brokerage"
//              for Rithmic) -> add -> fill name / user / password /
//              account type / connect on start up -> OK
//   CONNECT -> Connection.Connect(<options by name>)
//
// Safety:
//   - one job at a time, Config.xml copied to JJBotData\ConfigBackups first
//   - only fills a NEW entry (Connection name must start with "My ")
//   - any unexpected state -> presses Cancel, nothing is saved
//   - never touches an existing connection with the same name
// Log: Documents\NinjaTrader 8\JJBotData\account_link.log
//
// JJ_CONNECTION_DELETE_V1 (2026-10-31): DELETE a connection requested from the APK
// (long-press). Request arrives through the desktop as JJBotData\conn_delete.txt
// ("requestId|connection name"); result goes to JJBotData\conn_delete_result.json.
//   - refuses if any account of that connection has an open position
//   - disconnects it first, then Connections -> configure -> select -> remove -> OK
//   - Config.xml backed up first (same as ADD); built-in connections are never removed
// =====================================================================
#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJAccountLinkAgent : NinjaTrader.NinjaScript.AddOnBase
    {
        private const string BaseUrl = "https://jjtradingtools.ddns.net/api/accounts/link";
        private static int started;
        private static int busy;
        private static System.Threading.Timer pollTimer;

        private class Job
        {
            
            public string Id, Phase, ConnectionType, ConnectionName, Username, Password, AccountType, RithmicSystem;
            public bool ConnectOnStartup;
        }

        private static string DataDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData"); }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJAccountLinkAgent";
                Description = "JJ V1.7.108 - add/connect broker connections requested from the APK";
            }
            else if (State == State.Active)
            {
                if (Interlocked.Exchange(ref started, 1) == 1) return;
                pollTimer = new System.Threading.Timer(_ => Poll(), null, TimeSpan.FromSeconds(20), TimeSpan.FromSeconds(6));
                LinkLog("V1.7.108 ACCOUNT LINK AGENT STARTED");
            }
            else if (State == State.Terminated)
            {
                if (pollTimer != null) { pollTimer.Dispose(); pollTimer = null; }
                Interlocked.Exchange(ref started, 0);
            }
        }

        // ------------------------------------------------------------------ log
        private static readonly object logLock = new object();
        private static void LinkLog(string line)
        {
            string text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + line;
            try
            {
                lock (logLock)
                {
                    Directory.CreateDirectory(DataDir);
                    File.AppendAllText(Path.Combine(DataDir, "account_link.log"), text + Environment.NewLine);
                }
            }
            catch { }
            try { NinjaTrader.Code.Output.Process(text, PrintTo.OutputTab1); } catch { }
        }

        // ------------------------------------------------------------------ http
        private static string ApiKey()
        {
            try
            {
                string documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string[] files =
                {
                    Path.Combine(documents, "J&J Company Bro", "config.json"),
                    Path.Combine(documents, "JJ Trading Tools", "config.json")
                };
                foreach (string f in files)
                {
                    if (!File.Exists(f)) continue;
                    string v = JsonStr(File.ReadAllText(f), "apiKey");
                    if (!string.IsNullOrWhiteSpace(v)) return v;
                }
            }
            catch { }
            return "";
        }

        private static string Http(string method, string url, string body)
        {
            using (WebClient c = new WebClient())
            {
                c.Encoding = Encoding.UTF8;
                c.Headers["X-JJ-API-Key"] = ApiKey();
                c.Headers[HttpRequestHeader.CacheControl] = "no-cache";
                if (method == "GET") return c.DownloadString(url + (url.Contains("?") ? "&" : "?") + "_t=" + DateTime.UtcNow.Ticks);
                c.Headers[HttpRequestHeader.ContentType] = "application/json";
                return c.UploadString(url, method, body ?? "{}");
            }
        }

        private static void Report(Job job, bool ok, string message)
        {
            LinkLog("RESULT " + job.Phase + " | " + job.ConnectionName + " | ok=" + ok + " | " + message);
            try
            {
                if (job.Phase == "DELETE")
                {
                    // JJ_CONNECTION_DELETE_V1: answer goes back through the desktop (file), not the cloud queue
                    string result = "{\"requestId\":\"" + Esc(job.Id) + "\",\"name\":\"" + Esc(job.ConnectionName) +
                        "\",\"ok\":" + (ok ? "true" : "false") + ",\"message\":\"" + Esc(message) +
                        "\",\"at\":\"" + DateTime.UtcNow.ToString("o") + "\"}";
                    Directory.CreateDirectory(DataDir);
                    string target = Path.Combine(DataDir, "conn_delete_result.json");
                    File.WriteAllText(target + ".tmp", result, Encoding.UTF8);
                    if (File.Exists(target)) File.Delete(target);
                    File.Move(target + ".tmp", target);
                    return;
                }
                string json = "{\"phase\":\"" + job.Phase + "\",\"ok\":" + (ok ? "true" : "false") + ",\"message\":\"" + Esc(message) + "\"}";
                Http("POST", BaseUrl + "/" + Uri.EscapeDataString(job.Id) + "/agent-result", json);
            }
            catch (Exception ex) { LinkLog("REPORT ERROR " + ex.Message); }
            finally
            {
                job.Password = null;
                Interlocked.Exchange(ref busy, 0);
            }
        }

        private static string Esc(string v)
        {
            return (v ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        // Minimal JSON string reader with escape handling.
        private static string JsonStr(string json, string key)
        {
            if (string.IsNullOrEmpty(json)) return null;
            string pat = "\"" + key + "\"";
            int i = json.IndexOf(pat, StringComparison.Ordinal);
            if (i < 0) return null;
            i = json.IndexOf(':', i + pat.Length);
            if (i < 0) return null;
            i++;
            while (i < json.Length && char.IsWhiteSpace(json[i])) i++;
            if (i >= json.Length) return null;
            if (json[i] != '"')
            {
                int end = i;
                while (end < json.Length && json[end] != ',' && json[end] != '}') end++;
                return json.Substring(i, end - i).Trim();
            }
            StringBuilder sb = new StringBuilder();
            for (i = i + 1; i < json.Length; i++)
            {
                char ch = json[i];
                if (ch == '"') break;
                if (ch == '\\' && i + 1 < json.Length)
                {
                    char n = json[++i];
                    if (n == 'n') sb.Append('\n');
                    else if (n == 't') sb.Append('\t');
                    else if (n == 'r') sb.Append('\r');
                    else if (n == 'b') sb.Append('\b');
                    else if (n == 'f') sb.Append('\f');
                    else if (n == 'u' && i + 4 < json.Length)
                    {
                        sb.Append((char)Convert.ToInt32(json.Substring(i + 1, 4), 16));
                        i += 4;
                    }
                    else sb.Append(n);
                }
                else sb.Append(ch);
            }
            return sb.ToString();
        }

        // ------------------------------------------------------------------ poll
        private static void Poll()
        {
            if (Interlocked.CompareExchange(ref busy, 1, 0) != 0) return;
            Job job = null;

            // JJ_CONNECTION_DELETE_V1: a delete request written by the desktop has priority
            try
            {
                string deleteFile = Path.Combine(DataDir, "conn_delete.txt");
                if (File.Exists(deleteFile))
                {
                    string line = (File.ReadAllText(deleteFile) ?? "").Trim();
                    File.Delete(deleteFile);
                    int bar = line.IndexOf('|');
                    if (bar > 0 && bar < line.Length - 1)
                    {
                        Job del = new Job { Id = line.Substring(0, bar).Trim(), Phase = "DELETE", ConnectionName = line.Substring(bar + 1).Trim() };
                        LinkLog("JOB DELETE | " + del.ConnectionName);
                        try { RunDelete(del); }
                        catch (Exception ex) { Report(del, false, "Error interno: " + ex.Message); }
                        return;
                    }
                }
            }
            catch (Exception ex) { LinkLog("DELETE REQUEST ERROR " + ex.Message); }

            try
            {
                if (string.IsNullOrWhiteSpace(ApiKey())) { Interlocked.Exchange(ref busy, 0); return; }
                string resp = Http("GET", BaseUrl + "/agent", null);
                int jobAt = resp.IndexOf("\"job\":{", StringComparison.Ordinal);
                if (jobAt < 0) { Interlocked.Exchange(ref busy, 0); return; }
                string j = resp.Substring(jobAt);
                job = new Job
                {
                    Id = JsonStr(j, "id"),
                    Phase = JsonStr(j, "phase"),
                    ConnectionType = JsonStr(j, "connectionType"),
                    ConnectionName = JsonStr(j, "connectionName"),
                    Username = JsonStr(j, "username"),
                    Password = JsonStr(j, "password"),
                    AccountType = JsonStr(j, "accountType"),
                    RithmicSystem = JsonStr(j, "rithmicSystem"),
                    ConnectOnStartup = JsonStr(j, "connectOnStartup") == "true"
                };
            }
            catch (Exception ex)
            {
                Interlocked.Exchange(ref busy, 0);
                if (!(ex is WebException)) LinkLog("POLL ERROR " + ex.Message);
                return;
            }

            LinkLog("JOB " + job.Phase + " | " + job.ConnectionType + " | " + job.ConnectionName);
            try
            {
                if (job.Phase == "CONNECT") RunConnect(job);
                else if (job.Phase == "ADD" || job.Phase == "UPDATE") RunAdd(job);
                else Report(job, false, "Fase no admitida");
            }
            catch (Exception ex) { Report(job, false, "Error interno: " + ex.Message); }
        }

        // ------------------------------------------------------------------ helpers
        private static List<Window> NtWindows()
        {
            List<Window> result = new List<Window>();
            object raw = NinjaTrader.Core.Globals.AllWindows;
            IEnumerable list = raw as IEnumerable;
            if (list == null) return result;
            object[] arr;
            lock (raw) { arr = list.Cast<object>().ToArray(); }
            foreach (object o in arr) { Window w = o as Window; if (w != null) result.Add(w); }
            return result;
        }

        private static List<NinjaTrader.Cbi.Connection> ConnectionsSnapshot()
        {
            List<NinjaTrader.Cbi.Connection> list = new List<NinjaTrader.Cbi.Connection>();
            lock (NinjaTrader.Cbi.Connection.Connections)
            {
                foreach (NinjaTrader.Cbi.Connection c in NinjaTrader.Cbi.Connection.Connections) list.Add(c);
            }
            return list;
        }

        private static ConnectOptions FindOptions(string name)
        {
            IEnumerable list = NinjaTrader.Core.Globals.ConnectOptions as IEnumerable;
            if (list == null) return null;
            foreach (object o in list.Cast<object>().ToArray())
            {
                ConnectOptions c = o as ConnectOptions;
                if (c != null && string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase)) return c;
            }
            return null;
        }

        private static List<DependencyObject> Flatten(DependencyObject root)
        {
            List<DependencyObject> list = new List<DependencyObject>();
            Stack<DependencyObject> stack = new Stack<DependencyObject>();
            if (root == null) return list;
            stack.Push(root);
            HashSet<DependencyObject> seen = new HashSet<DependencyObject>();
            while (stack.Count > 0 && list.Count < 20000)
            {
                DependencyObject d = stack.Pop();
                if (!seen.Add(d)) continue;
                list.Add(d);
                FrameworkElement element = d as FrameworkElement;
                if (element != null) element.ApplyTemplate();
                Popup popup = d as Popup;
                if (popup != null && popup.Child != null) stack.Push(popup.Child);
                try
                {
                    foreach (object child in LogicalTreeHelper.GetChildren(d))
                    { DependencyObject obj = child as DependencyObject; if (obj != null) stack.Push(obj); }
                }
                catch { }
                int n = 0;
                try { n = d is Visual ? VisualTreeHelper.GetChildrenCount(d) : 0; } catch { n = 0; }
                for (int i = n - 1; i >= 0; i--) { DependencyObject c = VisualTreeHelper.GetChild(d, i); if (c != null) stack.Push(c); }
            }
            return list;
        }

        private static string FirstText(DependencyObject d)
        {
            foreach (DependencyObject c in Flatten(d))
            {
                TextBlock tb = c as TextBlock;
                if (tb != null && !string.IsNullOrWhiteSpace(tb.Text)) return tb.Text;
            }
            return "";
        }

        private static string HeaderText(object header)
        {
            if (header == null) return "";
            string s = header as string;
            if (s != null) return s;
            DependencyObject d = header as DependencyObject;
            if (d != null) { string t = FirstText(d); if (t.Length > 0) return t; }
            return header.ToString();
        }

        private static void Click(ButtonBase b)
        {
            System.Reflection.MethodInfo onClick = typeof(ButtonBase).GetMethod("OnClick", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (onClick != null) onClick.Invoke(b, null);
            else b.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent, b));
        }

        private static ButtonBase FindButton(DependencyObject root, string text)
        {
            foreach (DependencyObject d in Flatten(root))
            {
                ButtonBase b = d as ButtonBase;
                if (b == null) continue;
                string t = b.Content as string ?? FirstText(b);
                if ((t ?? "").Trim().Equals(text, StringComparison.OrdinalIgnoreCase)) return b;
            }
            return null;
        }

        private static void After(Dispatcher disp, double seconds, Action action, Job job)
        {
            DispatcherTimer t = null;
            t = new DispatcherTimer(DispatcherPriority.Normal, disp);
            t.Interval = TimeSpan.FromSeconds(seconds);
            t.Tick += (s, e) =>
            {
                t.Stop();
                try { action(); }
                catch (Exception ex) { Report(job, false, "Error interno: " + ex.Message); }
            };
            t.Start();
        }

        private static void BackupConfig()
        {
            try
            {
                string src = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "Config.xml");
                string dir = Path.Combine(DataDir, "ConfigBackups");
                Directory.CreateDirectory(dir);
                File.Copy(src, Path.Combine(dir, "Config_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xml"), true);
                foreach (FileInfo old in new DirectoryInfo(dir).GetFiles("Config_*.xml").OrderByDescending(f => f.Name).Skip(10)) old.Delete();
            }
            catch (Exception ex) { LinkLog("BACKUP WARNING " + ex.Message); }
        }

        // ------------------------------------------------------------------ CONNECT
        private static void RunConnect(Job job)
        {
            ConnectOptions options = FindOptions(job.ConnectionName);
            if (options == null) { Report(job, false, "No existe la conexión en NinjaTrader"); return; }

            foreach (NinjaTrader.Cbi.Connection existing in ConnectionsSnapshot())
            {
                if (existing.Options != null && string.Equals(existing.Options.Name, options.Name, StringComparison.OrdinalIgnoreCase)
                    && existing.Status == NinjaTrader.Cbi.ConnectionStatus.Connected)
                { Report(job, true, "Ya estaba conectada"); return; }
            }

            NinjaTrader.Cbi.Connection.Connect(options);
            Task.Run(() =>
            {
                for (int i = 0; i < 30; i++)
                {
                    Thread.Sleep(1000);
                    foreach (NinjaTrader.Cbi.Connection c in ConnectionsSnapshot())
                    {
                        if (c.Options == null || !string.Equals(c.Options.Name, options.Name, StringComparison.OrdinalIgnoreCase)) continue;
                        if (c.Status == NinjaTrader.Cbi.ConnectionStatus.Connected) { Report(job, true, "Conectada"); return; }
                    }
                }
                Report(job, false, "NinjaTrader no confirmó la conexión en 30 s (revisa usuario/contraseña)");
            });
        }

        // ------------------------------------------------------------------ ADD
        private static void RunAdd(Job job)
        {
            if (job.ConnectionType == "RITHMIC" && string.IsNullOrWhiteSpace(job.RithmicSystem))
            { Report(job, false, "Falta System de Rithmic; actualiza la APK y escribe el indicado por tu firma"); return; }
            if (string.IsNullOrEmpty(job.Password)) { Report(job, false, "Solicitud sin contraseña (expirada)"); return; }
            bool editing = job.Phase == "UPDATE";
            if (editing)
            {
                if (FindOptions(job.ConnectionName) == null) { Report(job, false, "No existe la conexion; agregala primero"); return; }
                if (!CanEdit(job.ConnectionName)) { Report(job, false, "Desconecta la conexion en NinjaTrader antes de editar credenciales"); return; }
            }
            else if (FindOptions(job.ConnectionName) != null) { Report(job, false, "Ya existe una conexión con ese nombre en NinjaTrader"); return; }

            Window cc = NtWindows().FirstOrDefault(w => w.GetType().Name.IndexOf("ControlCenter", StringComparison.OrdinalIgnoreCase) >= 0);
            if (cc == null) { Report(job, false, "Control Center no encontrado"); return; }

            cc.Dispatcher.InvokeAsync(() =>
            {
                try
                {
                    if (editing) DismissCredentialError(job, cc, 0);
                    else AddOpenDropdown(job, cc);
                }
                catch (Exception ex) { Report(job, false, "Error abriendo Connections: " + ex.Message); }
            });
        }

        private static bool IsCredentialError(string title, string message, string name)
        {
            if (!string.Equals((title ?? "").Trim(), "Error", StringComparison.OrdinalIgnoreCase)
                || string.IsNullOrWhiteSpace(name)) return false;
            string text = (message ?? "").Trim();
            // Exact connection name boundary; never acknowledge order errors or other accounts.
            if (!text.StartsWith(name + ":", StringComparison.OrdinalIgnoreCase)) return false;
            return text.IndexOf("Logon failed", StringComparison.OrdinalIgnoreCase) >= 0
                || text.IndexOf("Incorrect username or password", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void DismissCredentialError(Job job, Window cc, int dismissed)
        {
            if (dismissed >= 4) { Report(job, false, "Demasiados avisos de conexion; revisa NinjaTrader"); return; }
            var windows = NtWindows();
            foreach (Window owned in cc.OwnedWindows) if (!windows.Contains(owned)) windows.Add(owned);
            if (Application.Current != null && Application.Current.Dispatcher.CheckAccess())
                foreach (Window appWindow in Application.Current.Windows)
                    if (!windows.Contains(appWindow)) windows.Add(appWindow);
            CheckCredentialWindow(job, cc, windows, 0, dismissed);
        }

        private static void CheckCredentialWindow(Job job, Window cc, List<Window> windows, int index, int dismissed)
        {
            if (index >= windows.Count)
            {
                cc.Dispatcher.InvokeAsync(() =>
                {
                    try { AddOpenDropdown(job, cc); }
                    catch (Exception ex) { Report(job, false, "Error abriendo Connections: " + ex.Message); }
                });
                return;
            }
            Window win = windows[index];
            win.Dispatcher.InvokeAsync(() =>
            {
                try
                {
                    if (win.IsVisible && string.Equals(win.Title, "Error", StringComparison.OrdinalIgnoreCase))
                    {
                        string message = string.Join(" ", Flatten(win).OfType<TextBlock>().Select(t => t.Text).Where(t => !string.IsNullOrWhiteSpace(t)));
                        if (IsCredentialError(win.Title, message, job.ConnectionName))
                        {
                            ButtonBase ok = FindButton(win, "OK");
                            if (ok == null || !ok.IsEnabled) { Report(job, false, "Aviso de credenciales encontrado, pero no se pudo pulsar OK"); return; }
                            Click(ok);
                            LinkLog("LOGIN ERROR ACKNOWLEDGED | " + job.ConnectionName);
                            After(cc.Dispatcher, 0.5, () => DismissCredentialError(job, cc, dismissed + 1), job);
                            return;
                        }
                    }
                    CheckCredentialWindow(job, cc, windows, index + 1, dismissed);
                }
                catch (Exception ex) { Report(job, false, "Error revisando aviso de conexion: " + ex.Message); }
            });
        }

        private static void AddOpenDropdown(Job job, Window cc)
        {
            if (FindConnectionsWindow() != null) { Report(job, false, "La ventana Connections ya está abierta en la VPS; ciérrala y reintenta"); return; }

            MenuItem conn = null;
            foreach (DependencyObject d in Flatten(cc))
            {
                MenuItem mi = d as MenuItem;
                if (mi != null && mi.GetType().Name == "ConnectionMenuItem" && HeaderText(mi.Header).Trim() == "Connections") { conn = mi; break; }
            }
            if (conn == null) { Report(job, false, "Menú Connections no encontrado"); return; }

            BackupConfig();
            conn.IsSubmenuOpen = true;
            After(cc.Dispatcher, 1.0, () => AddClickConfigure(job, cc, conn), job);
        }

        private static void AddClickConfigure(Job job, Window cc, MenuItem conn)
        {
            AddClickConfigureRetry(job, cc, conn, 0);
        }

        private static string NormalizeAction(string value)
        {
            return (value ?? "").Replace("_", "").Replace("&", "").Trim().TrimEnd('.', '\u2026').Trim().ToLowerInvariant();
        }

        private static Action FindConfigureAction(DependencyObject root)
        {
            foreach (DependencyObject node in Flatten(root))
            {
                ButtonBase button = node as ButtonBase;
                if (button != null && button.IsEnabled && NormalizeAction(button.Content as string ?? FirstText(button)) == "configure")
                    return () => Click(button);
                MenuItem item = node as MenuItem;
                if (item != null && item.IsEnabled && NormalizeAction(HeaderText(item.Header)) == "configure")
                    return () =>
                    {
                        var peer = new System.Windows.Automation.Peers.MenuItemAutomationPeer(item);
                        var invoke = peer.GetPattern(System.Windows.Automation.Peers.PatternInterface.Invoke) as System.Windows.Automation.Provider.IInvokeProvider;
                        if (invoke == null) throw new InvalidOperationException("Configure no admite invocacion");
                        invoke.Invoke();
                    };
                Hyperlink link = node as Hyperlink;
                if (link != null && link.IsEnabled && NormalizeAction(new TextRange(link.ContentStart, link.ContentEnd).Text) == "configure")
                    return () => link.DoClick();
            }
            return null;
        }

        private static void AddClickConfigureRetry(Job job, Window cc, MenuItem conn, int attempt)
        {
            Popup popup = null;
            conn.ApplyTemplate();
            try { popup = conn.Template.FindName("PART_Popup", conn) as Popup; } catch { }
            Action configure = popup != null && popup.Child != null ? FindConfigureAction(popup.Child) : null;
            if (configure == null) configure = FindConfigureAction(conn);
            if (configure == null)
            {
                if (attempt < 4)
                { After(cc.Dispatcher, 0.5, () => AddClickConfigureRetry(job, cc, conn, attempt + 1), job); return; }
                LinkLog("CONFIGURE SEARCH | menu=" + conn.GetType().Name + " | popup=" + (popup == null ? "not PART_Popup" : "found")
                    + " | descendants=" + Flatten(conn).Count);
                conn.IsSubmenuOpen = false;
                Report(job, false, "Control configure no encontrado en el pie del menu; consulta CONFIGURE SEARCH en account_link.log");
                return;
            }

            WaitWindow(job, cc.Dispatcher, 0);
            LinkLog("CONFIGURE FOUND | invoking footer action");
            configure();
        }

        private static Window FindConnectionsWindow()
        {
            foreach (Window w in NtWindows())
            {
                if (w.GetType().Name != "ObjectDialog") continue;
                string title = "";
                try { title = (string)w.Dispatcher.Invoke(new Func<string>(() => w.Title)); } catch { }
                if ((title ?? "").Trim().Equals("Connections", StringComparison.OrdinalIgnoreCase)) return w;
            }
            return null;
        }

        private static void WaitWindow(Job job, Dispatcher disp, int tries)
        {
            After(disp, 1.0, () =>
            {
                Window win = FindConnectionsWindow();
                if (win == null)
                {
                    if (tries < 12) { WaitWindow(job, disp, tries + 1); return; }
                    Report(job, false, "La ventana Connections no se abrió");
                    return;
                }
                win.Dispatcher.InvokeAsync(() =>
                {
                    try { AddSelectAndAdd(job, win); }
                    catch (Exception ex) { Cancel(win); Report(job, false, "Error en Connections: " + ex.Message); }
                });
            }, job);
        }

        private static void Cancel(Window win)
        {
            try
            {
                ButtonBase cancel = FindButton(win, "Cancel");
                if (cancel != null) Click(cancel); else win.Close();
            }
            catch { }
        }

        private static void AddSelectAndAdd(Job job, Window win)
        {
            if (job.Phase == "UPDATE") { SelectExisting(job, win); return; }
            if (job.Phase == "DELETE") { SelectAndRemove(job, win); return; }
            string wanted = job.ConnectionType == "RITHMIC" ? "Rithmic for NinjaTrader Brokerage" : "NinjaTrader";
            Selector available = null;
            object item = null;
            foreach (DependencyObject d in Flatten(win))
            {
                Selector sel = d as Selector;
                if (sel == null) continue;
                foreach (object it in sel.Items)
                {
                    string text = it == null ? "" : it.ToString();
                    DependencyObject cont = sel.ItemContainerGenerator.ContainerFromItem(it) as DependencyObject;
                    if (cont != null) { string ft = FirstText(cont); if (ft.Length > 0) text = ft; }
                    if (text.Trim().Equals(wanted, StringComparison.OrdinalIgnoreCase)) { available = sel; item = it; break; }
                }
                if (available != null) break;
            }
            if (available == null) { Cancel(win); Report(job, false, "Tipo '" + wanted + "' no encontrado en Available"); return; }

            available.SelectedItem = item;
            ButtonBase add = FindButton(win, "add");
            if (add == null) { Cancel(win); Report(job, false, "Botón add no encontrado"); return; }
            Click(add);
            After(win.Dispatcher, 1.5, () => AddFillAndSave(job, win), job);
        }

        // ------------------------------------------------------------------ DELETE
        private static readonly string[] ProtectedConnections = { "Playback Connection", "Simulated Data Feed", "Sim101" };

        private static void RunDelete(Job job)
        {
            if (string.IsNullOrWhiteSpace(job.ConnectionName)) { Report(job, false, "Falta el nombre de la conexion"); return; }
            if (ProtectedConnections.Any(p => string.Equals(p, job.ConnectionName, StringComparison.OrdinalIgnoreCase)))
            { Report(job, false, "Esa conexion es de NinjaTrader y no se puede eliminar"); return; }
            if (FindOptions(job.ConnectionName) == null) { Report(job, true, "Ya no existia en NinjaTrader"); return; }
            if (FindConnectionsWindow() != null) { Report(job, false, "La ventana Connections esta abierta en la PC; cierrala y reintenta"); return; }

            // never pull the plug on open positions
            foreach (NinjaTrader.Cbi.Connection c in ConnectionsSnapshot())
            {
                if (c.Options == null || !string.Equals(c.Options.Name, job.ConnectionName, StringComparison.OrdinalIgnoreCase)) continue;
                List<Account> accounts = new List<Account>();
                lock (Account.All) { foreach (Account a in Account.All) if (a != null && a.Connection == c) accounts.Add(a); }
                foreach (Account a in accounts)
                {
                    foreach (Position p in a.Positions)
                    {
                        if (p != null && p.MarketPosition != MarketPosition.Flat)
                        { Report(job, false, "La cuenta " + a.Name + " tiene una posicion abierta; cierrala antes de eliminar la conexion"); return; }
                    }
                }
            }

            if (!CanEdit(job.ConnectionName))
            {
                foreach (NinjaTrader.Cbi.Connection c in ConnectionsSnapshot())
                {
                    if (c.Options != null && string.Equals(c.Options.Name, job.ConnectionName, StringComparison.OrdinalIgnoreCase))
                    {
                        LinkLog("DELETE | disconnecting " + job.ConnectionName);
                        try { c.Disconnect(); } catch (Exception ex) { LinkLog("DISCONNECT WARNING " + ex.Message); }
                    }
                }
            }

            Task.Run(() =>
            {
                for (int i = 0; i < 25 && !CanEdit(job.ConnectionName); i++) Thread.Sleep(1000);
                if (!CanEdit(job.ConnectionName)) { Report(job, false, "NinjaTrader no desconecto la conexion en 25 s"); return; }

                Window cc = NtWindows().FirstOrDefault(w => w.GetType().Name.IndexOf("ControlCenter", StringComparison.OrdinalIgnoreCase) >= 0);
                if (cc == null) { Report(job, false, "Control Center no encontrado"); return; }
                cc.Dispatcher.InvokeAsync(() =>
                {
                    try { AddOpenDropdown(job, cc); }
                    catch (Exception ex) { Report(job, false, "Error abriendo Connections: " + ex.Message); }
                });
            });
        }

        private static void SelectAndRemove(Job job, Window win)
        {
            foreach (DependencyObject node in Flatten(win))
            {
                Selector selector = node as Selector;
                if (selector == null || selector is ComboBox) continue;
                foreach (object item in selector.Items)
                {
                    ConnectOptions option = item as ConnectOptions;
                    string name = option == null ? (item == null ? "" : item.ToString()) : option.Name;
                    DependencyObject container = selector.ItemContainerGenerator.ContainerFromItem(item) as DependencyObject;
                    if (container != null && option == null)
                    { string text = FirstText(container); if (!string.IsNullOrEmpty(text)) name = text; }
                    if (!string.Equals(name.Trim(), job.ConnectionName, StringComparison.OrdinalIgnoreCase)) continue;

                    selector.SelectedItem = item;
                    After(win.Dispatcher, 1, () =>
                    {
                        // safety: the selected entry must still be the requested one
                        object selected = selector.SelectedItem;
                        ConnectOptions selOption = selected as ConnectOptions;
                        string selName = selOption != null ? selOption.Name : name;
                        if (!string.Equals((selName ?? "").Trim(), job.ConnectionName, StringComparison.OrdinalIgnoreCase))
                        { Cancel(win); Report(job, false, "Seguridad: la seleccion cambio, no se elimino nada"); return; }

                        ButtonBase remove = FindButton(win, "remove");
                        if (remove == null || !remove.IsEnabled) { Cancel(win); Report(job, false, "Boton remove no encontrado o desactivado"); return; }
                        LinkLog("DELETE | pressing remove on " + job.ConnectionName);
                        Click(remove);
                        After(win.Dispatcher, 1.0, () => ConfirmAndSave(job, win, 0), job);
                    }, job);
                    return;
                }
            }
            Cancel(win); Report(job, false, "No se encontro la conexion en Configured");
        }

        private static void ConfirmAndSave(Job job, Window win, int attempt)
        {
            // NinjaTrader may ask "are you sure?" - press Yes on that dialog only
            if (Application.Current != null)
            {
                foreach (Window w in Application.Current.Windows)
                {
                    if (w == null || w == win || !w.IsVisible) continue;
                    ButtonBase yes = FindButton(w, "Yes");
                    if (yes != null && yes.IsEnabled)
                    {
                        LinkLog("DELETE | confirm dialog '" + w.Title + "' -> Yes");
                        Click(yes);
                        After(win.Dispatcher, 0.8, () => ConfirmAndSave(job, win, attempt + 1), job);
                        return;
                    }
                }
            }

            ButtonBase ok = FindButton(win, "OK");
            if (ok == null) { Cancel(win); Report(job, false, "Boton OK no encontrado"); return; }
            Click(ok);
            After(win.Dispatcher, 2.0, () =>
            {
                if (FindOptions(job.ConnectionName) == null) { Report(job, true, "Eliminada de NinjaTrader"); return; }
                Window still = FindConnectionsWindow();
                if (still != null) Cancel(still);
                Report(job, false, "NinjaTrader no elimino la conexion");
            }, job);
        }

        private static bool CanEdit(string name)
        {
            return !ConnectionsSnapshot().Any(c => c.Options != null &&
                string.Equals(c.Options.Name, name, StringComparison.OrdinalIgnoreCase) &&
                (c.Status != ConnectionStatus.Disconnected || c.PriceStatus != ConnectionStatus.Disconnected));
        }

        private static void SelectExisting(Job job, Window win)
        {
            foreach (DependencyObject node in Flatten(win))
            {
                Selector selector = node as Selector;
                if (selector == null || selector is ComboBox) continue;
                foreach (object item in selector.Items)
                {
                    ConnectOptions option = item as ConnectOptions;
                    string name = option == null ? (item == null ? "" : item.ToString()) : option.Name;
                    DependencyObject container = selector.ItemContainerGenerator.ContainerFromItem(item) as DependencyObject;
                    if (container != null && option == null)
                    { string text = FirstText(container); if (!string.IsNullOrEmpty(text)) name = text; }
                    if (!string.Equals(name.Trim(), job.ConnectionName, StringComparison.OrdinalIgnoreCase)) continue;
                    selector.SelectedItem = item;
                    After(win.Dispatcher, 1, () => AddFillAndSave(job, win), job);
                    return;
                }
            }
            Cancel(win); Report(job, false, "No se encontro la conexion existente en Configured");
        }

        private static readonly string[] Labels = { "Connection name", "Connect on start up", "User name", "Password", "Ask password on connect", "Sign in with Google", "Sign in with Apple", "Account type", "System", "Server" };

        private static bool IsLabel(string text)
        {
            string t = (text ?? "").Trim();
            return Labels.Any(l => t.StartsWith(l, StringComparison.OrdinalIgnoreCase));
        }

        private static T EditorAfter<T>(List<DependencyObject> all, string label) where T : DependencyObject
        {
            int idx = -1;
            for (int i = 0; i < all.Count; i++)
            {
                TextBlock tb = all[i] as TextBlock;
                if (tb != null && (tb.Text ?? "").Trim().Equals(label, StringComparison.OrdinalIgnoreCase)) { idx = i; break; }
            }
            if (idx < 0) return null;
            for (int i = idx + 1; i < all.Count && i < idx + 400; i++)
            {
                TextBlock other = all[i] as TextBlock;
                if (other != null && i > idx + 1 && IsLabel(other.Text)) break;
                T found = all[i] as T;
                if (found != null)
                {
                    TextBox tbx = found as TextBox;
                    if (tbx != null && (!tbx.IsEnabled || tbx.IsReadOnly)) continue;
                    return found;
                }
            }
            return null;
        }

        private static void AddFillAndSave(Job job, Window win)
        {
            List<DependencyObject> all = Flatten(win);

            TextBox nameBox = EditorAfter<TextBox>(all, "Connection name");
            TextBox userBox = EditorAfter<TextBox>(all, "User name");
            PasswordBox passBox = EditorAfter<PasswordBox>(all, "Password");

            if (nameBox == null || userBox == null || passBox == null)
            { Cancel(win); Report(job, false, "Campos no encontrados en Properties"); return; }

            // Safety: must be the NEW entry ("My NinjaTrader", "My Rithmic ...").
            bool editing = job.Phase == "UPDATE";
            if (editing && (!string.Equals(nameBox.Text, job.ConnectionName, StringComparison.OrdinalIgnoreCase) || !CanEdit(job.ConnectionName)))
            { Cancel(win); Report(job, false, "Seguridad: seleccion incorrecta o conexion activa"); return; }
            if (!editing && !(nameBox.Text ?? "").StartsWith("My ", StringComparison.OrdinalIgnoreCase))
            { Cancel(win); Report(job, false, "Seguridad: el panel no mostraba una conexión nueva (" + nameBox.Text + ")"); return; }

            if (!editing) SetText(nameBox, job.ConnectionName);
            SetText(userBox, job.Username);
            passBox.Password = job.Password;
            // Commit editors that update their source on focus loss before OK.
            nameBox.Focus();

            CheckBox startup = EditorAfter<CheckBox>(all, "Connect on start up");
            if (!editing && startup != null) startup.IsChecked = job.ConnectOnStartup;

            ComboBox accountType = EditorAfter<ComboBox>(all, "Account type");
            if (!editing && accountType != null)
            {
                foreach (object it in accountType.Items)
                {
                    if ((it == null ? "" : it.ToString()).Trim().Equals(job.AccountType ?? "Simulation", StringComparison.OrdinalIgnoreCase))
                    { accountType.SelectedItem = it; break; }
                }
            }

            if (job.ConnectionType == "RITHMIC")
            {
                ComboBox systemBox = EditorAfter<ComboBox>(all, "System");
                if (systemBox == null)
                { Cancel(win); Report(job, false, "Campo System de Rithmic no encontrado"); return; }
                object selected = null;
                foreach (object item in systemBox.Items)
                {
                    ComboBoxItem comboItem = item as ComboBoxItem;
                    string text = comboItem == null ? Convert.ToString(item) : HeaderText(comboItem.Content);
                    if (string.Equals((text ?? "").Trim(), job.RithmicSystem.Trim(), StringComparison.OrdinalIgnoreCase))
                    { selected = item; break; }
                }
                if (selected == null)
                { Cancel(win); Report(job, false, "El System solicitado no existe en NinjaTrader; revisa el nombre exacto"); return; }
                systemBox.SelectedItem = selected;
                var binding = systemBox.GetBindingExpression(Selector.SelectedItemProperty);
                if (binding != null) binding.UpdateSource();
                nameBox.Focus();
            }

            ButtonBase ok = FindButton(win, "OK");
            if (ok == null) { Cancel(win); Report(job, false, "Botón OK no encontrado"); return; }

            LinkLog("FILLED " + job.ConnectionName + " | pressing OK");
            Click(ok);

            After(win.Dispatcher, 2.0, () =>
            {
                ConnectOptions created = FindOptions(job.ConnectionName);
                if (created == null)
                {
                    if (FindConnectionsWindow() != null) Cancel(FindConnectionsWindow());
                    Report(job, false, "NinjaTrader no guardó la conexión");
                    return;
                }
                bool userOk = string.Equals(created.User, job.Username, StringComparison.Ordinal);
                Report(job, userOk, userOk ? (editing ? "Credenciales actualizadas; ya puedes conectar" : "Agregada") : "El usuario guardado no coincide; revisa la configuracion");
                // Creation/update and broker authentication are separate results.
                // Some adapters do not expose the saved username through ConnectOptions.User.
                if (!userOk) LinkLog("SAVED USER NOT VERIFIED | " + job.ConnectionName + " | broker authentication deferred to CONNECT");
                Report(job, true, editing ? "Configuracion guardada; ya puedes conectar" : "Agregada");
            }, job);
        }

        private static void SetText(TextBox box, string value)
        {
            box.Focus();
            box.Text = value ?? "";
            var be = box.GetBindingExpression(TextBox.TextProperty);
            if (be != null) be.UpdateSource();
        }
    }
}
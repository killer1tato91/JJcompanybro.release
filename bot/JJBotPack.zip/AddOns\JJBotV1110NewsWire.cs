#region Using declarations
using System;
using System.Collections.Generic;
using System.Windows.Threading;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.110 - NEWS GUARD RE-WIRED (2026-10-31)
    // JJBotNewsGuard.cs (calendar download/cache/parse) existed but NOTHING called it:
    // no calendar was loaded, no entry was ever blocked and nothing was flattened.
    // This file connects it:
    //  * a 1 s timer on every profile window (not on the hidden market brain);
    //  * HIGH impact USD events only (CPI, NFP, FOMC, PPI, GDP, retail sales...);
    //  * new entries blocked from T-2 min to T+2 min of the event;
    //  * an open position is flattened once inside that window (prop rule safe);
    //  * if the calendar cannot be loaded the bot keeps trading (fail-open) and logs a warning
    //    every 30 min - the old "fail closed" would block Open Bell whenever the feed is down;
    //  * a daily log line with today's high impact events and whether it is an FOMC day
    //    (used by the Open Bell FOMC shadow).
    // Switch off: V1110NewsWireEnabled = false.
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V1110NewsWireEnabled = true;
        private const int V1110NewsMinutesBefore = 2;
        private const int V1110NewsMinutesAfter = 2;

        private DispatcherTimer v1110NewsTimer;
        private DateTime v1110LastDayLog = DateTime.MinValue;
        private DateTime v1110LastWarnUtc = DateTime.MinValue;
        private string v1110LastWindowKey = string.Empty;
        private string v1110LastFlattenKey = string.Empty;
        private string v1110LastBlockLogKey = string.Empty;
        private int v1110UiCounter;

        private void V1110StartNewsWire()
        {
            if (!V1110NewsWireEnabled)
                return;

            try
            {
                V1110StopNewsWire();
                TryLoadNewsCalendarCache();
                EnsureNewsCalendarRefresh();

                v1110NewsTimer = new DispatcherTimer(DispatcherPriority.Background, Dispatcher);
                v1110NewsTimer.Interval = TimeSpan.FromSeconds(1);
                v1110NewsTimer.Tick += V1110NewsTimerTick;
                v1110NewsTimer.Start();

                PrintBotMessage("NEWS GUARD V1.7.110 | ARMED | HIGH impact USD | entries blocked and position flat from T-"
                    + V1110NewsMinutesBefore + "m to T+" + V1110NewsMinutesAfter + "m");
            }
            catch (Exception ex)
            {
                PrintBotMessage("NEWS GUARD V1.7.110 | START ERROR: " + ex.Message);
            }
        }

        private void V1110StopNewsWire()
        {
            DispatcherTimer timer = v1110NewsTimer;
            v1110NewsTimer = null;

            if (timer == null)
                return;

            try
            {
                timer.Stop();
                timer.Tick -= V1110NewsTimerTick;
            }
            catch
            {
            }
        }

        private List<JJNewsEvent> V1110HighEventsSnapshot(out bool usable)
        {
            List<JJNewsEvent> list = new List<JJNewsEvent>();
            usable = false;

            lock (newsGuardLock)
            {
                usable =
                    newsCalendarLoaded &&
                    newsCalendarLastSuccessUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - newsCalendarLastSuccessUtc).TotalHours <= NewsCalendarMaxCacheHours;

                if (usable)
                {
                    foreach (JJNewsEvent ev in propNewsEvents)
                    {
                        if (ev != null && string.Equals((ev.Impact ?? string.Empty).Trim(), "High", StringComparison.OrdinalIgnoreCase))
                            list.Add(ev);
                    }
                }
            }

            return list;
        }

        // Active HIGH impact window right now (T-2m .. T+2m).
        private bool V1110TryGetHighNewsWindow(DateTime nowNy, out JJNewsEvent active, out bool calendarUsable)
        {
            active = null;
            List<JJNewsEvent> events = V1110HighEventsSnapshot(out calendarUsable);

            foreach (JJNewsEvent ev in events)
            {
                if (ev.TimeNy.TimeOfDay == TimeSpan.Zero)
                    continue; // all-day items (holidays) have no time

                if (nowNy >= ev.TimeNy.AddMinutes(-V1110NewsMinutesBefore) &&
                    nowNy <= ev.TimeNy.AddMinutes(V1110NewsMinutesAfter))
                {
                    active = ev;
                    return true;
                }
            }

            return false;
        }

        // FOMC day = the calendar has an FOMC / Federal Funds Rate event today.
        internal bool V1110IsFomcDay(DateTime nyDate, out string title)
        {
            title = string.Empty;
            bool usable;
            foreach (JJNewsEvent ev in V1110HighEventsSnapshot(out usable))
            {
                string t = ev.Title ?? string.Empty;
                if (ev.TimeNy.Date == nyDate.Date &&
                    (t.IndexOf("FOMC", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     t.IndexOf("Federal Funds Rate", StringComparison.OrdinalIgnoreCase) >= 0))
                {
                    title = t + " " + ev.TimeNy.ToString("HH:mm");
                    return true;
                }
            }
            return false;
        }

        // Called from TrySubmitEntry: true = do not open a new trade now.
        private bool V1110IsEntryBlockedByNews(out string reason)
        {
            reason = string.Empty;

            if (!V1110NewsWireEnabled)
                return false;

            try
            {
                DateTime nowNy = GetCurrentNewYorkTime();
                JJNewsEvent active;
                bool usable;

                if (V1110TryGetHighNewsWindow(nowNy, out active, out usable) && active != null)
                {
                    reason = "USD HIGH | " + (active.Title ?? "NEWS") + " | Event " + active.TimeNy.ToString("HH:mm")
                        + " | window " + active.TimeNy.AddMinutes(-V1110NewsMinutesBefore).ToString("HH:mm")
                        + "-" + active.TimeNy.AddMinutes(V1110NewsMinutesAfter).ToString("HH:mm") + " NY";
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private void V1110NewsTimerTick(object sender, EventArgs e)
        {
            try
            {
                if (v186IsDedicatedBrain)
                    return;

                EnsureNewsCalendarRefresh();

                DateTime nowNy = GetCurrentNewYorkTime();
                JJNewsEvent active;
                bool usable;
                bool inWindow = V1110TryGetHighNewsWindow(nowNy, out active, out usable);

                // calendar health
                if (!usable)
                {
                    if ((DateTime.UtcNow - v1110LastWarnUtc).TotalMinutes >= 30)
                    {
                        v1110LastWarnUtc = DateTime.UtcNow;
                        string err;
                        lock (newsGuardLock) err = newsCalendarLastError;
                        PrintBotMessage("NEWS GUARD V1.7.110 | WARNING - calendar not loaded"
                            + (string.IsNullOrWhiteSpace(err) ? string.Empty : " (" + err + ")")
                            + " | trading continues (fail-open)");
                    }
                }
                else if (v1110LastDayLog.Date != nowNy.Date)
                {
                    v1110LastDayLog = nowNy;
                    bool u2;
                    List<string> today = new List<string>();
                    foreach (JJNewsEvent ev in V1110HighEventsSnapshot(out u2))
                        if (ev.TimeNy.Date == nowNy.Date)
                            today.Add(ev.TimeNy.ToString("HH:mm") + " " + ev.Title);
                    string fomc;
                    bool isFomc = V1110IsFomcDay(nowNy, out fomc);
                    PrintBotMessage("NEWS GUARD V1.7.110 | TODAY " + nowNy.ToString("yyyy-MM-dd") + " | HIGH USD: "
                        + (today.Count == 0 ? "none" : string.Join(" ; ", today.ToArray()))
                        + " | FOMC day: " + (isFomc ? "YES (" + fomc + ")" : "no"));
                }

                if (inWindow && active != null)
                {
                    string key = active.TimeNy.ToString("yyyyMMdd-HHmm") + "|" + (active.Title ?? string.Empty);

                    if (v1110LastWindowKey != key)
                    {
                        v1110LastWindowKey = key;
                        PrintBotMessage("NEWS GUARD V1.7.110 | WINDOW ACTIVE | USD HIGH | " + active.Title
                            + " | " + active.TimeNy.ToString("HH:mm") + " NY | no new entries, open position goes flat");
                    }

                    if (selectedAccount != null && selectedInstrument != null && v1110LastFlattenKey != key)
                    {
                        MarketPosition side;
                        int qty;
                        double avg;
                        bool flat = TryGetSelectedInstrumentPosition(out side, out qty, out avg);

                        if (!flat)
                        {
                            v1110LastFlattenKey = key;
                            activeForcedExitReason = "NEWS_COMPLIANCE";
                            PrintBotMessage("NEWS GUARD V1.7.110 | FORCE FLAT | " + active.Title + " " + active.TimeNy.ToString("HH:mm")
                                + " | Position " + side + " " + qty);
                            try
                            {
                                FlattenExecutionAccount(selectedAccount, selectedInstrument);
                            }
                            catch (Exception ex)
                            {
                                v1110LastFlattenKey = string.Empty; // retry next second
                                PrintBotMessage("NEWS GUARD V1.7.110 | FLATTEN ERROR: " + ex.Message);
                            }
                        }
                    }
                }

                if (++v1110UiCounter >= 5)
                {
                    v1110UiCounter = 0;
                    try { UpdateNewsGuardDisplay(); } catch { }
                }
            }
            catch (Exception ex)
            {
                if ((DateTime.UtcNow - v1110LastWarnUtc).TotalMinutes >= 30)
                {
                    v1110LastWarnUtc = DateTime.UtcNow;
                    PrintBotMessage("NEWS GUARD V1.7.110 | TICK ERROR (ignored): " + ex.Message);
                }
            }
        }

        private void V1110LogNewsBlockOnce(string reason)
        {
            string key = DateTime.UtcNow.ToString("yyyyMMddHHmm") + reason;
            if (key == v1110LastBlockLogKey)
                return;
            v1110LastBlockLogKey = key;
            PrintBotMessage("ENTRY BLOCKED - NEWS GUARD V1.7.110 | " + reason);
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.116 - "NO TRADE TODAY" NOTICE (11-nov-2026)
    // 11-nov: the Open Bell LONG was skipped by the V1.7.109 premarket filter, but the skip
    // reason was only written in the market brain's log. Every account only said
    // "evaluated by the market brain" and the user could not tell why the bot did not enter.
    //
    // When the Open Bell ends the day WITHOUT a trade (skip / no trade), the market brain now:
    //   1) writes "CORE20 OPEN BELL | NO TRADE TODAY | <reason> | <detail>" in its own log
    //      AND in the log of every account (profile) that follows it;
    //   2) keeps the reason as the day's Lock Reason (app / APK) until the next session;
    //   3) sends ONE phone notice to the APK: POST /api/trades/bot-skip (kind BOT_SKIP).
    // When the brain decides ENTRY but an account blocks it with its own risk rules within
    // 90 s, that account writes "OPEN BELL BLOCKED ON THIS ACCOUNT" and sends its own notice.
    //
    // Display / notice only: it never changes a decision, an order or a risk rule.
    // Switch off: V1116SkipNoticeEnabled = false.
    // =========================================================
    internal static class JJBotDayNotice
    {
        private sealed class Notice
        {
            public DateTime DateNy;
            public string Text = string.Empty;
            public bool BrainEntry;
            public DateTime EntryNy = DateTime.MinValue;
        }

        private static readonly object sync = new object();
        private static readonly Dictionary<string, Notice> notices = new Dictionary<string, Notice>(StringComparer.OrdinalIgnoreCase);

        private static Notice Get(string instrument, DateTime dateNy)
        {
            Notice n;
            if (!notices.TryGetValue(instrument, out n) || n.DateNy != dateNy.Date)
            {
                n = new Notice { DateNy = dateNy.Date };
                notices[instrument] = n;
            }
            return n;
        }

        // Returns false when this day already has a notice (only the first one is sent).
        public static bool SetNoTrade(string instrument, DateTime dateNy, string text)
        {
            if (string.IsNullOrEmpty(instrument)) return false;
            lock (sync)
            {
                Notice n = Get(instrument, dateNy);
                if (n.Text.Length > 0) return false;
                n.Text = text ?? string.Empty;
                return true;
            }
        }

        public static void SetEntry(string instrument, DateTime ny)
        {
            if (string.IsNullOrEmpty(instrument)) return;
            lock (sync)
            {
                Notice n = Get(instrument, ny);
                n.BrainEntry = true;
                n.EntryNy = ny;
            }
        }

        public static string GetNoTrade(string instrument, DateTime dateNy)
        {
            if (string.IsNullOrEmpty(instrument)) return null;
            lock (sync)
            {
                Notice n;
                if (notices.TryGetValue(instrument, out n) && n.DateNy == dateNy.Date && n.Text.Length > 0)
                    return n.Text;
                return null;
            }
        }

        public static bool BrainEnteredRecently(string instrument, DateTime ny, double seconds)
        {
            if (string.IsNullOrEmpty(instrument)) return false;
            lock (sync)
            {
                Notice n;
                return notices.TryGetValue(instrument, out n)
                    && n.DateNy == ny.Date
                    && n.BrainEntry
                    && (ny - n.EntryNy).TotalSeconds >= -2
                    && (ny - n.EntryNy).TotalSeconds <= seconds;
            }
        }
    }

    public partial class JJBotWindow
    {
        private const bool V1116SkipNoticeEnabled = true;
        private const string V1116CloudUrl = "https://jjtradingtools.ddns.net/api/trades/bot-skip";
        private const double V1116AccountBlockWindowSec = 90.0;

        private DateTime v1116AccountBlockSentDate = DateTime.MinValue;
        private double v1116PremarketPts;
        private volatile bool v1116MissedWindow;

        private bool V1116IsCore20Brain()
        {
            try
            {
                string fam = V185SignalFamilyKey(Core20StrategyName);
                return fam == null || !V185IsSignalFollower(fam);
            }
            catch
            {
                return true;
            }
        }

        private string V1116InstrumentKey()
        {
            try { return selectedInstrument != null ? selectedInstrument.FullName : string.Empty; }
            catch { return string.Empty; }
        }

        // Called by the Open Bell code when the day ends WITHOUT a trade.
        // code: short reason code (PREMARKET_FILTER, DATA_LATE, MISSED_WINDOW, RANGE_DATA,
        //       TAPE_VETO, L2_CONTRARY, SHORT_ONLY, DIRECTION). detail: English log detail.
        private void V1116NoTrade(string code, string detail)
        {
            if (!V1116SkipNoticeEnabled)
                return;

            try
            {
                if (!V1116IsCore20Brain())
                    return;

                string inst = V1116InstrumentKey();
                DateTime nowNy = GetCurrentNewYorkTime();
                string text = "NO TRADE TODAY - OPEN BELL " + code.Replace('_', ' ');

                if (!JJBotDayNotice.SetNoTrade(inst, nowNy, text))
                    return;

                string line = "CORE20 OPEN BELL | NO TRADE TODAY | " + code + " | " + (detail ?? string.Empty);
                PrintBotMessage(line);

                List<JJBotWindow> members = new List<JJBotWindow>();
                try
                {
                    string fam = V185SignalFamilyKey(Core20StrategyName);
                    if (fam != null)
                        members = JJMarketBrainHub.MembersOf(fam);
                }
                catch
                {
                }

                List<string> accounts = new List<string>();
                foreach (JJBotWindow w in members)
                {
                    if (w == null || ReferenceEquals(w, this))
                        continue;
                    try
                    {
                        w.PrintBotMessage(line + " | decided by the market brain " + V185ProfileName());
                        if (w.selectedAccount != null)
                            accounts.Add(w.selectedAccount.Name);
                    }
                    catch
                    {
                    }
                }

                if (selectedAccount != null && !accounts.Contains(selectedAccount.Name))
                    accounts.Add(selectedAccount.Name);

                V1116Post(code, detail, accounts.Count > 0 ? string.Join(", ", accounts) : "ALL", inst, nowNy, "BRAIN");
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("V1.7.116 NO TRADE NOTICE ERROR: " + ex.Message); } catch { }
            }
        }

        // Called on the brain when the Open Bell (or its rescue) decides ENTRY.
        private void V1116MarkEntry()
        {
            try
            {
                if (V1116IsCore20Brain())
                    JJBotDayNotice.SetEntry(V1116InstrumentKey(), GetCurrentNewYorkTime());
            }
            catch
            {
            }
        }

        // Called from CaptureEntryBlockReason ("ENTRY BLOCKED - ..." / account block lines).
        private void V1116OnEntryBlocked(string title)
        {
            if (!V1116SkipNoticeEnabled)
                return;

            try
            {
                if (selectedAccount == null)
                    return;

                // This account already entered today (or is in a trade): a later block
                // (e.g. DAILY TARGET after the TP) is not an Open Bell skip.
                if (tradesToday > 0 || entryMarketPosition != NinjaTrader.Cbi.MarketPosition.Flat)
                    return;

                DateTime nowNy = GetCurrentNewYorkTime();
                if (v1116AccountBlockSentDate == nowNy.Date)
                    return;

                if (!JJBotDayNotice.BrainEnteredRecently(V1116InstrumentKey(), nowNy, V1116AccountBlockWindowSec))
                    return;

                v1116AccountBlockSentDate = nowNy.Date;
                string account = selectedAccount.Name;

                Task.Run(() =>
                {
                    try { PrintBotMessage("CORE20 OPEN BELL | BLOCKED ON THIS ACCOUNT | " + title + " | the market brain decided ENTRY"); } catch { }
                });

                V1116Post("ACCOUNT_BLOCK", title, account, V1116InstrumentKey(), nowNy, "ACCOUNT");
            }
            catch
            {
            }
        }

        // Lock Reason fallback for the rest of the day (see GetEntryBlockReasonForTelemetry).
        private string V1116DayNoticeForTelemetry()
        {
            try
            {
                return JJBotDayNotice.GetNoTrade(V1116InstrumentKey(), GetCurrentNewYorkTime());
            }
            catch
            {
                return null;
            }
        }

        private void V1116Post(string code, string detail, string accounts, string symbol, DateTime nowNy, string source)
        {
            // Playback / Market Replay tests never send phone notices
            try { if (IsPlaybackStrategyClockActive()) return; } catch { }

            string apiKey = V1107GetApiKey();
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                try { PrintBotMessage("V1.7.116 PHONE NOTICE SKIPPED | no API key found"); } catch { }
                return;
            }

            string json =
                "{\"apiKey\":\"" + V1107Esc(apiKey) + "\""
                + ",\"kind\":\"BOT_SKIP\""
                + ",\"module\":\"OPEN_BELL\""
                + ",\"source\":\"" + V1107Esc(source) + "\""
                + ",\"code\":\"" + V1107Esc(code) + "\""
                + ",\"detail\":\"" + V1107Esc(detail) + "\""
                + ",\"accounts\":\"" + V1107Esc(accounts) + "\""
                + ",\"symbol\":\"" + V1107Esc(symbol) + "\""
                + ",\"dateNy\":\"" + nowNy.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + "\""
                + ",\"timeNy\":\"" + nowNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "\"}";

            Task.Run(() =>
            {
                try
                {
                    using (WebClient client = new WebClient())
                    {
                        client.Encoding = Encoding.UTF8;
                        client.Headers[HttpRequestHeader.ContentType] = "application/json";
                        client.UploadString(V1116CloudUrl, "POST", json);
                    }
                    try { PrintBotMessage("V1.7.116 PHONE NOTICE SENT | " + code + " | " + accounts); } catch { }
                }
                catch (Exception ex)
                {
                    try { PrintBotMessage("V1.7.116 PHONE NOTICE ERROR | " + code + " | " + ex.Message); } catch { }
                }
            });
        }
    }
}

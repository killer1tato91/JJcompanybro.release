#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using NinjaTrader.Data;
#endregion

// V1.7.118 - ADAPTIVE SIDE SELECTOR (LOG ONLY - never places, blocks or flips an order)
//
// At 09:29:58 (inside Core20TryOpenBell, only on the brain that evaluates the Open Bell) it computes
// 10 pre-open features and, if the model file exists, the probability that a LONG and a SHORT with the
// Open Bell rules (SL 33.5 / TP 30.5 / ladder +20 -> +17) end positive. It logs what it WOULD do:
//   "CORE20 SELECTOR | V1.7.118 LOG ONLY | ... | Would trade LONG/SHORT/NO TRADE | OB side ..."
// Then it follows both virtual trades tick by tick until 10:00 and appends one row per day to
//   Documents\NinjaTrader 8\JJBotData\Selector\selector_days.csv
// That file is the live record (to compare with the backtest) and new training data.
// The model is retrained on the PC with jj_selector_train.py, which writes
//   Documents\NinjaTrader 8\JJBotData\Selector\jj_selector_model.txt
// Without the model file it still logs features and outcomes ("model N/A").
// Turn off: V1118SelectorLogEnabled = false.

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private static readonly bool V1118SelectorLogEnabled = true;
        private const double V1118SlPts = 33.5, V1118TpPts = 30.5, V1118LadderPts = 20.0, V1118LadderLockPts = 17.0;
        private const double V1118EntrySlip = 0.25, V1118StopSlip = 2.0, V1118LadderExitPts = 15.0;
        private static readonly TimeSpan V1118EndTime = new TimeSpan(10, 0, 0);
        private static readonly object v1118FileLock = new object();

        private readonly object v1118Sync = new object();
        private bool v1118Active;
        private DateTime v1118Date = DateTime.MinValue;
        private string v1118RowPrefix;
        private double v1118Px;
        private readonly double[] v1118Res = new double[2];   // [0] LONG, [1] SHORT (points, NaN while open)
        private readonly bool[] v1118Laddered = new bool[2];

        private static string V1118Dir()
        {
            return Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "JJBotData", "Selector");
        }

        private sealed class V1118Model
        {
            public string TrainedThrough = "";
            public double Threshold = 0.6;
            public string[] Feats = new string[0];
            public double[] Mean, Std, CoefL, CoefS;
            public double InterceptL, InterceptS;
            public List<string> HistDates = new List<string>();
            public List<double> HistRng = new List<double>();
            public List<double> HistV5 = new List<double>();
        }

        private static double[] V1118Nums(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return new double[0];
            return s.Split(',').Select(x => double.Parse(x.Trim(), CultureInfo.InvariantCulture)).ToArray();
        }

        private static V1118Model V1118LoadModel(out string err)
        {
            err = null;
            string path = Path.Combine(V1118Dir(), "jj_selector_model.txt");
            if (!File.Exists(path)) { err = "no model file"; return null; }
            var kv = new Dictionary<string, string>();
            foreach (string line in File.ReadAllLines(path))
            {
                int i = line.IndexOf('=');
                if (i > 0) kv[line.Substring(0, i).Trim()] = line.Substring(i + 1).Trim();
            }
            var m = new V1118Model();
            m.TrainedThrough = kv.ContainsKey("trained_through") ? kv["trained_through"] : "";
            if (kv.ContainsKey("threshold")) m.Threshold = double.Parse(kv["threshold"], CultureInfo.InvariantCulture);
            m.Feats = kv["feats"].Split(',').Select(x => x.Trim()).ToArray();
            m.Mean = V1118Nums(kv["mean"]); m.Std = V1118Nums(kv["std"]);
            m.CoefL = V1118Nums(kv["coefL"]); m.CoefS = V1118Nums(kv["coefS"]);
            m.InterceptL = double.Parse(kv["interceptL"], CultureInfo.InvariantCulture);
            m.InterceptS = double.Parse(kv["interceptS"], CultureInfo.InvariantCulture);
            m.HistDates = kv["hist_dates"].Split(',').Select(x => x.Trim()).ToList();
            m.HistRng = V1118Nums(kv["hist_rng"]).ToList();
            m.HistV5 = V1118Nums(kv["hist_v5"]).ToList();
            int n = m.Feats.Length;
            if (m.Mean.Length != n || m.Std.Length != n || m.CoefL.Length != n || m.CoefS.Length != n
                || m.HistDates.Count != m.HistRng.Count || m.HistDates.Count != m.HistV5.Count)
            { err = "model file inconsistent"; return null; }
            return m;
        }

        // Days already logged by the bot after the model's training date (keeps the 20-day stats current between retrains)
        private static void V1118AppendBotHistory(V1118Model m, DateTime today)
        {
            string path = Path.Combine(V1118Dir(), "selector_days.csv");
            if (!File.Exists(path)) return;
            string[] lines;
            lock (v1118FileLock) lines = File.ReadAllLines(path);
            if (lines.Length < 2) return;
            string[] head = lines[0].Split(',');
            int iD = Array.IndexOf(head, "date"), iH = Array.IndexOf(head, "hi"), iL = Array.IndexOf(head, "lo"), iV = Array.IndexOf(head, "v5");
            if (iD < 0 || iH < 0 || iL < 0 || iV < 0) return;
            string last = m.HistDates.Count > 0 ? m.HistDates[m.HistDates.Count - 1] : "";
            string todayS = today.ToString("yyyy-MM-dd");
            foreach (string l in lines.Skip(1))
            {
                string[] c = l.Split(',');
                if (c.Length <= Math.Max(Math.Max(iD, iH), Math.Max(iL, iV))) continue;
                if (string.CompareOrdinal(c[iD], last) <= 0 || string.CompareOrdinal(c[iD], todayS) >= 0) continue;
                double h, lo, v;
                if (!double.TryParse(c[iH], NumberStyles.Float, CultureInfo.InvariantCulture, out h)
                    || !double.TryParse(c[iL], NumberStyles.Float, CultureInfo.InvariantCulture, out lo)
                    || !double.TryParse(c[iV], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) continue;
                m.HistDates.Add(c[iD]); m.HistRng.Add(h - lo); m.HistV5.Add(v);
                last = c[iD];
            }
        }

        private static double V1118Median(List<double> x)
        {
            if (x.Count == 0) return double.NaN;
            var s = x.OrderBy(v => v).ToList();
            int n = s.Count;
            return n % 2 == 1 ? s[n / 2] : 0.5 * (s[n / 2 - 1] + s[n / 2]);
        }

        // Close of the last 1m bar stamped <= target (NY) on the given date; NaN if none.
        private double V1118BarCloseAt(Bars bars, DateTime date, TimeSpan target, bool previousSession)
        {
            if (bars == null) return double.NaN;
            for (int i = bars.Count - 1; i >= 0; i--)
            {
                DateTime b = ConvertToNewYorkTime(bars.GetTime(i));
                if (!previousSession)
                {
                    if (b.Date < date) break;
                    if (b.Date == date && b.TimeOfDay <= target) return bars.GetClose(i);
                }
                else
                {
                    if (b.Date >= date) continue;
                    if ((date - b.Date).TotalDays > 4) break;
                    if (b.TimeOfDay == target) return bars.GetClose(i);   // the 16:00 bar of the last session
                    if (b.TimeOfDay < target && b.TimeOfDay >= target.Subtract(TimeSpan.FromMinutes(1))) return bars.GetClose(i);
                }
            }
            return double.NaN;
        }

        private void V1118SelectorEvaluate(Bars bars, DateTime ny, double hi, double lo, double px, double o900, bool obIsLong)
        {
            if (!V1118SelectorLogEnabled) return;
            try
            {
                double d30, d5, v5; int s30, s5;
                lock (level2Sync)
                {
                    d30 = obTape30mDelta; s30 = obTape30mSnaps;
                    d5 = obTape5mDelta; s5 = obTape5mSnaps; v5 = obTape5mVol;
                }
                double prevClose = V1118BarCloseAt(bars, ny.Date, new TimeSpan(16, 0, 0), true);
                double p300 = V1118BarCloseAt(bars, ny.Date, new TimeSpan(3, 0, 0), false);
                double rng = hi - lo;
                if (o900 <= 0) o900 = double.NaN;

                string decision = "N/A";
                string probs = "model N/A";
                double pL = double.NaN, pS = double.NaN;
                string err;
                V1118Model m = null;
                try { m = V1118LoadModel(out err); } catch (Exception ex) { err = "model read error " + ex.Message; }
                bool tapeOk = s30 >= Core20OpenBellDirtyMin30Snaps && s5 >= Core20OpenBellLongTapeMinSnaps;

                if (m == null)
                    probs = "model N/A (" + err + ")";
                else if (!tapeOk)
                    probs = "tape N/A (30m " + s30 + " / 5m " + s5 + " snaps)";
                else
                {
                    V1118AppendBotHistory(m, ny.Date);
                    int n = m.HistRng.Count;
                    var prevRng = m.HistRng.Skip(Math.Max(0, n - 20)).ToList();
                    var prevV5 = m.HistV5.Skip(Math.Max(0, n - 20)).ToList();
                    double med = V1118Median(prevRng);
                    double v5prevMean = prevV5.Count > 0 ? prevV5.Average() : double.NaN;
                    var v5Incl = prevV5.Skip(Math.Max(0, prevV5.Count - 19)).ToList(); v5Incl.Add(v5);
                    double v5InclMean = v5Incl.Average();

                    var f = new Dictionary<string, double>();
                    f["f_rng"] = rng / px;
                    f["f_rngrel"] = rng / Math.Max(double.IsNaN(med) ? 1 : med, 1);
                    f["f_med"] = double.IsNaN(med) ? 0 : med / px;
                    f["f_d30n"] = v5InclMean > 0 ? d30 / v5InclMean : 0;
                    f["f_d5n"] = v5InclMean > 0 ? d5 / v5InclMean : 0;
                    f["f_v5rel"] = (!double.IsNaN(v5prevMean) && v5prevMean > 0) ? v5 / v5prevMean : 0;
                    f["f_pos"] = (px - lo) / Math.Max(rng, 0.25);
                    f["f_mv30"] = double.IsNaN(o900) ? 0 : (px - o900) / px;
                    f["f_gap"] = double.IsNaN(prevClose) ? 0 : (px - prevClose) / px;
                    f["f_lon"] = double.IsNaN(p300) ? 0 : (px - p300) / px;

                    double zL = m.InterceptL, zS = m.InterceptS;
                    for (int i = 0; i < m.Feats.Length; i++)
                    {
                        double x;
                        if (!f.TryGetValue(m.Feats[i], out x)) x = m.Mean[i];
                        double z = (x - m.Mean[i]) / (m.Std[i] > 0 ? m.Std[i] : 1.0);
                        zL += m.CoefL[i] * z; zS += m.CoefS[i] * z;
                    }
                    pL = 1.0 / (1.0 + Math.Exp(-zL));
                    pS = 1.0 / (1.0 + Math.Exp(-zS));
                    if (pL >= pS && pL >= m.Threshold) decision = "LONG";
                    else if (pS > pL && pS >= m.Threshold) decision = "SHORT";
                    else decision = "NO TRADE";
                    probs = "pLONG " + pL.ToString("0.00", CultureInfo.InvariantCulture) + " | pSHORT " + pS.ToString("0.00", CultureInfo.InvariantCulture)
                        + " | th " + m.Threshold.ToString("0.00", CultureInfo.InvariantCulture) + " | model " + m.TrainedThrough
                        + " | rngrel " + f["f_rngrel"].ToString("0.00", CultureInfo.InvariantCulture)
                        + " | gap " + (f["f_gap"] * 100).ToString("+0.00;-0.00", CultureInfo.InvariantCulture) + "%"
                        + " | lon " + (f["f_lon"] * 100).ToString("+0.00;-0.00", CultureInfo.InvariantCulture) + "%";
                }

                string obSide = obIsLong ? "LONG" : "SHORT";
                string agree = (decision == "LONG" || decision == "SHORT") ? (decision == obSide ? "SAME AS OB" : "OPPOSITE TO OB") : "-";
                PrintBotMessage("CORE20 SELECTOR | V1.7.118 LOG ONLY | Would trade " + decision + " | OB side " + obSide + " | " + agree + " | " + probs);

                Func<double, string> F = v => double.IsNaN(v) ? "" : v.ToString("0.#####", CultureInfo.InvariantCulture);
                string prefix = string.Join(",", new[] {
                    ny.ToString("yyyy-MM-dd"), F(px), F(o900), F(hi), F(lo), F(d30), F(d5), F(v5),
                    s30.ToString(CultureInfo.InvariantCulture), s5.ToString(CultureInfo.InvariantCulture),
                    F(prevClose), F(p300), F(pL), F(pS), decision, obSide });

                lock (v1118Sync)
                {
                    v1118Active = true;
                    v1118Date = ny.Date;
                    v1118RowPrefix = prefix;
                    v1118Px = px;
                    v1118Res[0] = double.NaN; v1118Res[1] = double.NaN;
                    v1118Laddered[0] = false; v1118Laddered[1] = false;
                }
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("CORE20 SELECTOR | V1.7.118 LOG ONLY | ERROR " + ex.Message + " (no effect on trading)"); } catch { }
            }
        }

        // Called from every Core20 tick. Cheap when inactive.
        private void V1118SelectorOnTick(DateTime ny, double price)
        {
            if (!V1118SelectorLogEnabled || !v1118Active) return;
            try
            {
                string row = null;
                lock (v1118Sync)
                {
                    if (!v1118Active) return;
                    if (ny.Date != v1118Date) { v1118Active = false; return; }   // day changed without a 10:00 tick
                    bool end = ny.TimeOfDay >= V1118EndTime;
                    for (int k = 0; k < 2; k++)
                    {
                        if (!double.IsNaN(v1118Res[k])) continue;
                        double s = k == 0 ? 1.0 : -1.0;
                        double ep = v1118Px + s * V1118EntrySlip;
                        double fav = s * (price - ep);
                        if (!v1118Laddered[k])
                        {
                            if (-fav >= V1118SlPts) v1118Res[k] = -V1118SlPts - V1118StopSlip;
                            else if (fav >= V1118TpPts) v1118Res[k] = V1118TpPts;
                            else if (fav >= V1118LadderPts) v1118Laddered[k] = true;
                        }
                        else
                        {
                            if (fav >= V1118TpPts) v1118Res[k] = V1118TpPts;
                            else if (fav <= V1118LadderLockPts) v1118Res[k] = V1118LadderExitPts;
                        }
                        if (double.IsNaN(v1118Res[k]) && end) v1118Res[k] = fav;
                    }
                    if (!double.IsNaN(v1118Res[0]) && !double.IsNaN(v1118Res[1]))
                    {
                        v1118Active = false;
                        row = v1118RowPrefix + "," + v1118Res[0].ToString("0.##", CultureInfo.InvariantCulture)
                            + "," + v1118Res[1].ToString("0.##", CultureInfo.InvariantCulture);
                    }
                }
                if (row == null) return;

                string[] c = row.Split(',');
                PrintBotMessage("CORE20 SELECTOR | V1.7.118 LOG ONLY | RESULT " + c[0] + " | virtual LONG " + c[16] + " pts | virtual SHORT " + c[17]
                    + " pts | selector said " + c[14] + " | OB side " + c[15]);

                lock (v1118FileLock)
                {
                    Directory.CreateDirectory(V1118Dir());
                    string path = Path.Combine(V1118Dir(), "selector_days.csv");
                    bool exists = File.Exists(path);
                    if (exists && File.ReadAllLines(path).Any(l => l.StartsWith(c[0] + ",", StringComparison.Ordinal)))
                        return;   // one row per day (several bot windows / restarts)
                    if (!exists)
                        File.AppendAllText(path, "date,px,o900,hi,lo,d30,d5,v5,s30,s5,prevclose,p300,pL,pS,selector,ob_side,L_pts,S_pts" + Environment.NewLine);
                    File.AppendAllText(path, row + Environment.NewLine);
                }
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("CORE20 SELECTOR | V1.7.118 LOG ONLY | ERROR " + ex.Message + " (no effect on trading)"); } catch { }
            }
        }
    }
}

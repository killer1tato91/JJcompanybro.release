#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using NinjaTrader.Data;
#endregion

// V1.7.120 - OPEN BELL DAY LEVEL (A+ / NORMAL / DEBIL) - LOG ONLY
//
// Backtest 2026 (219 days, 1 s tape, OpenBell_Backtest_2026_Volumen_Tape.md):
//   A+     = PreVol >= 1.1 x median of the last 20 sessions AND tape 09:00-09:29:58 in favor of the side
//            -> 48 days, 85% win, PF 4.0, $30/contract/day
//   DEBIL  = LONG with price in the bottom 20% of the range OR price more than 20 pts below the 09:00 open
//            -> 31 days, PF 0.88
//   NORMAL = the rest -> 140 days, PF 1.48
// Plan to validate (25K): A+ 6 / NORMAL 3 / DEBIL 1 contracts.
//
// NEVER places, blocks, resizes or flips an order. It only writes:
//   log:  "CORE20 OPEN BELL LEVEL | V1.7.120 LOG ONLY | Level A+ | ..."
//   file: Documents\NinjaTrader 8\JJBotData\OpenBellLevel\level_days.csv (one row per day)
// PreVol history (date,prevol = 1m volume 09:00:00-09:28:59) lives in
//   Documents\NinjaTrader 8\JJBotData\OpenBellLevel\prevol_history.csv
// The bot appends each day; the file was seeded with sep-nov 2026 from the backtest data.
// Tape: Level 1 bid/ask of the normal feed (Lucid alone is enough); Level 2 snapshots only as fallback.
// Turn off: V1120LevelLogEnabled = false.

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJBotWindow
    {
        private static readonly bool V1120LevelLogEnabled = true;
        private const double V1120RelVolMin = 1.1;
        private const double V1120WeakPosMax = 0.2;
        private const double V1120WeakMovePts = -20.0;
        private const int V1120MedianDays = 20;
        private const int V1120MinHistDays = 5;
        private static readonly object v1120FileLock = new object();

        // V1.7.120 - Level 1 tape (bid/ask of the normal feed, same classification as the CORE20 delta).
        // Fed from V1101CoreCore20MarketData inside core20Sync. Works with the Lucid feed alone (no Level 2).
        private DateTime v1120TapeDate = DateTime.MinValue;
        private double v1120TapeDelta, v1120TapeVol;
        private int v1120TapeTrades;

        private void V1120TapeAdd(DateTime time, double signedVolume, double volume)
        {
            try
            {
                DateTime ny = ConvertToNewYorkTime(time);
                TimeSpan tod = ny.TimeOfDay;
                if (ny.Date != v1120TapeDate || tod < new TimeSpan(9, 0, 0))
                {
                    v1120TapeDate = ny.Date; v1120TapeDelta = 0; v1120TapeVol = 0; v1120TapeTrades = 0;
                }
                if (tod >= new TimeSpan(9, 0, 0) && tod < new TimeSpan(9, 29, 58))
                {
                    v1120TapeDelta += signedVolume;
                    v1120TapeVol += Math.Max(0, volume);
                    v1120TapeTrades++;
                }
            }
            catch { }
        }

        private static string V1120Dir()
        {
            return Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "JJBotData", "OpenBellLevel");
        }

        // Reads date,prevol rows strictly before 'today'; returns the last N values ordered by date.
        private static List<double> V1120LoadHistory(DateTime today, out int total)
        {
            total = 0;
            var rows = new SortedDictionary<string, double>(StringComparer.Ordinal);
            string path = Path.Combine(V1120Dir(), "prevol_history.csv");
            if (!File.Exists(path)) return new List<double>();
            string[] lines;
            lock (v1120FileLock) lines = File.ReadAllLines(path);
            string todayS = today.ToString("yyyy-MM-dd");
            foreach (string l in lines.Skip(1))
            {
                string[] c = l.Split(',');
                if (c.Length < 2) continue;
                double v;
                if (string.CompareOrdinal(c[0].Trim(), todayS) >= 0) continue;
                if (!double.TryParse(c[1], NumberStyles.Float, CultureInfo.InvariantCulture, out v) || v <= 0) continue;
                rows[c[0].Trim()] = v;
            }
            total = rows.Count;
            return rows.Values.Skip(Math.Max(0, rows.Count - V1120MedianDays)).ToList();
        }

        private static void V1120SaveToday(DateTime today, double preVol)
        {
            string dir = V1120Dir();
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, "prevol_history.csv");
            string todayS = today.ToString("yyyy-MM-dd");
            lock (v1120FileLock)
            {
                if (File.Exists(path) && File.ReadAllLines(path).Any(l => l.StartsWith(todayS + ",", StringComparison.Ordinal)))
                    return;
                if (!File.Exists(path)) File.WriteAllText(path, "date,prevol" + Environment.NewLine);
                File.AppendAllText(path, todayS + "," + preVol.ToString("0", CultureInfo.InvariantCulture) + Environment.NewLine);
            }
        }

        // Called from Core20TryOpenBell at 09:29:58 (only on the brain that evaluates the Open Bell).
        private void V1120OpenBellLevelLog(Bars bars, DateTime ny, double hi, double lo, double px, double o900, bool isLong)
        {
            if (!V1120LevelLogEnabled) return;
            try
            {
                // PreVol = 1m bars stamped 09:01..09:29 (09:00:00-09:28:59), same window as the history file
                double preVol = 0; int nBars = 0;
                if (bars != null)
                {
                    for (int i = bars.Count - 1; i >= 0; i--)
                    {
                        DateTime b = ConvertToNewYorkTime(bars.GetTime(i));
                        if (b.Date < ny.Date) break;
                        if (b.Date == ny.Date && b.TimeOfDay > Core20OpenBellRangeStart && b.TimeOfDay <= new TimeSpan(9, 29, 0))
                        { preVol += bars.GetVolume(i); nBars++; }
                    }
                }
                bool volOk = nBars >= 25 && preVol > 0;

                int histTotal;
                List<double> hist = V1120LoadHistory(ny.Date, out histTotal);
                double med = hist.Count >= V1120MinHistDays ? V1118Median(hist) : double.NaN;
                double relVol = (volOk && !double.IsNaN(med) && med > 0) ? preVol / med : double.NaN;
                if (volOk && !IsPlaybackStrategyClockActive())
                    V1120SaveToday(ny.Date, preVol);

                // Tape: Level 1 (normal feed) first; Level 2 snapshots only as a fallback
                double d30, l1Vol; int l1Trades, s30; string tapeSrc;
                lock (core20Sync)
                {
                    bool sameDay = v1120TapeDate == ny.Date;
                    d30 = sameDay ? v1120TapeDelta : 0; l1Vol = sameDay ? v1120TapeVol : 0; l1Trades = sameDay ? v1120TapeTrades : 0;
                }
                bool tapeOk = l1Trades >= 500 && l1Vol > 0;
                s30 = l1Trades; tapeSrc = "L1";
                if (!tapeOk)
                {
                    double d2; int s2;
                    lock (level2Sync) { d2 = obTape30mDelta; s2 = obTape30mSnaps; }
                    if (s2 >= Core20OpenBellDirtyMin30Snaps) { d30 = d2; s30 = s2; tapeOk = true; tapeSrc = "L2"; }
                }
                double sideSign = isLong ? 1.0 : -1.0;
                bool tapeFavor = tapeOk && d30 * sideSign > 0;
                double tapeBase = (tapeSrc == "L1" && l1Vol > 0) ? l1Vol : preVol;
                double tapePct = (tapeOk && tapeBase > 0) ? d30 * sideSign / tapeBase * 100.0 : double.NaN;

                double rng = hi - lo;
                double pos = rng > 0 ? (px - lo) / rng : 0.5;
                double movePre = o900 > 0 ? (px - o900) * sideSign : double.NaN;

                string level, why;
                if (!double.IsNaN(relVol) && relVol >= V1120RelVolMin && tapeFavor)
                { level = "A+"; why = "volume high + tape in favor"; }
                else if (isLong && (pos < V1120WeakPosMax || (!double.IsNaN(movePre) && movePre < V1120WeakMovePts)))
                { level = "DEBIL"; why = pos < V1120WeakPosMax ? "LONG at the bottom of the range" : "LONG after a drop > 20 pts since 09:00"; }
                else
                {
                    level = "NORMAL";
                    why = double.IsNaN(relVol) ? "RelVol N/A" : (!tapeOk ? "tape N/A" : (relVol < V1120RelVolMin ? "volume not high" : "tape against"));
                }

                Func<double, string, string> F = (v, fmt) => double.IsNaN(v) ? "N/A" : v.ToString(fmt, CultureInfo.InvariantCulture);
                PrintBotMessage("CORE20 OPEN BELL LEVEL | V1.7.120 LOG ONLY | Level " + level + " (" + why + ")"
                    + " | Side " + (isLong ? "LONG" : "SHORT")
                    + " | RelVol " + F(relVol, "0.00") + " (PreVol " + preVol.ToString("0") + " / med" + hist.Count + " " + F(med, "0") + ")"
                    + " | Tape30 " + d30.ToString("+0;-0;0") + " " + tapeSrc + " " + (tapeOk ? (tapeFavor ? "FAVOR" : "AGAINST") : "N/A (" + s30 + " trades)")
                    + " " + F(tapePct, "+0.0;-0.0") + "%"
                    + " | Pos " + pos.ToString("0.00", CultureInfo.InvariantCulture)
                    + " | Pre09:00 " + F(movePre, "+0.00;-0.00") + " pts"
                    + " | Plan 25K would size A+ 6 / NORMAL 3 / DEBIL 1 - NOT APPLIED, trade uses profile contracts");

                string dir = V1120Dir();
                Directory.CreateDirectory(dir);
                string path = Path.Combine(dir, "level_days.csv");
                string row = string.Join(",", new[] {
                    ny.ToString("yyyy-MM-dd"), isLong ? "LONG" : "SHORT", level, F(rng, "0.00"), F(px, "0.00"),
                    preVol.ToString("0"), F(med, "0"), F(relVol, "0.000"), d30.ToString("0"), tapeSrc + ":" + s30.ToString(),
                    F(tapePct, "0.00"), pos.ToString("0.000", CultureInfo.InvariantCulture), F(movePre, "0.00"),
                    IsPlaybackStrategyClockActive() ? "PLAYBACK" : "LIVE" });
                lock (v1120FileLock)
                {
                    if (!File.Exists(path))
                        File.WriteAllText(path, "date,side,level,range,price,prevol,med20,relvol,tape30,tape30_n,tape30_pct,pos,move_pre,mode" + Environment.NewLine);
                    File.AppendAllText(path, row + Environment.NewLine);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("CORE20 OPEN BELL LEVEL | V1.7.120 ERROR (log only, trade not affected): " + ex.Message);
            }
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.84 - FIXES FROM THE 12-16 OCT 2026 WEEK REVIEW
    //
    //  1) Open Bell LONG tape veto is now ONE verdict for every profile
    //     (JJBotOpenBellSharedVerdict). If any profile sees a non-buyer tape the
    //     LONG is vetoed for all accounts, and every account re-checks it before
    //     executing a central decision (before: profile 2 said "LONG TAPE VETO"
    //     and still entered because another profile proposed the trade).
    //  2) Stale / out-of-order ticks are dropped in LIVE (they made the CORE20
    //     clock "rewind" hundreds of times, re-firing Gerard/Open Bell and feeding
    //     prices 40 pts away from the market). The rewind reset is Playback-only.
    //  3) Unrealized PnL / MFE / trailing use the freshest live trade price instead
    //     of the last close of a BarsRequest that can lag behind the market.
    //  4) Repetitive per-tick log lines are throttled (2 s per message type).
    // =========================================================

    internal static class JJBotOpenBellSharedVerdict
    {
        private sealed class Verdict
        {
            public DateTime DateNy;
            public bool LongVetoed;
            public double WorstDelta;
            public string Source;
        }

        private static readonly object sync = new object();
        private static readonly Dictionary<string, Verdict> verdicts = new Dictionary<string, Verdict>();

        // Any profile that sees a non-buyer tape vetoes the Open Bell LONG for the whole day.
        public static void Report(string instrument, DateTime dateNy, bool longVetoed, double delta, string source)
        {
            if (string.IsNullOrEmpty(instrument))
                return;

            lock (sync)
            {
                Verdict v;
                if (!verdicts.TryGetValue(instrument, out v) || v.DateNy != dateNy.Date)
                {
                    v = new Verdict { DateNy = dateNy.Date, LongVetoed = false, WorstDelta = double.MaxValue, Source = string.Empty };
                    verdicts[instrument] = v;
                }

                if (delta < v.WorstDelta)
                    v.WorstDelta = delta;

                if (longVetoed && !v.LongVetoed)
                {
                    v.LongVetoed = true;
                    v.Source = source ?? string.Empty;
                }
            }
        }

        public static bool IsLongVetoed(string instrument, DateTime dateNy, out double worstDelta, out string source)
        {
            worstDelta = 0;
            source = string.Empty;

            if (string.IsNullOrEmpty(instrument))
                return false;

            lock (sync)
            {
                Verdict v;
                if (!verdicts.TryGetValue(instrument, out v) || v.DateNy != dateNy.Date)
                    return false;

                worstDelta = v.WorstDelta == double.MaxValue ? 0 : v.WorstDelta;
                source = v.Source;
                return v.LongVetoed;
            }
        }
    }

    public partial class JJBotWindow
    {
        // ---------------------------------------------------------
        // (1) Open Bell LONG tape threshold
        // ---------------------------------------------------------
        // V1.7.83 used "delta >= 0", which let a flat tape through (16-oct: +6 / +7 / +13
        // out of ~1,190 trades -> 3 LONG stop-outs, -$822). The LONG now needs a clear
        // buyer tape. Live evidence so far: winners +805 (07-oct) and +1,555 (14-oct);
        // losers -663, -157 and ~0 (16-oct). Only 6 days of real L2 - re-check with more data.
        private const double Core20OpenBellLongTapeMinDelta = 100.0;

        // ---------------------------------------------------------
        // (2) Monotonic tick guard
        // ---------------------------------------------------------
        // In LIVE a tick more than this many seconds older than the newest tick already
        // seen is dropped. If ticks keep being dropped for longer than the resync time the
        // newest-time anchor itself is assumed wrong and is re-anchored (never blind).
        private const double V184StaleTickToleranceSec = 2.0;
        private const double V184StaleResyncSec = 10.0;

        private sealed class V184TickClock
        {
            public DateTime Newest = DateTime.MinValue;
            public DateTime FirstDropUtc = DateTime.MinValue;
            public long Dropped;
            public long DroppedSinceLog;
            public double WorstAgeSec;
            public DateTime LastLogUtc = DateTime.MinValue;
        }

        private readonly V184TickClock v184Core20Clock = new V184TickClock();
        private readonly V184TickClock v184Level2Clock = new V184TickClock();

        // Returns false when the tick must be ignored. Never throws.
        // logLine is filled (at most once every 30 s) with a summary to print OUTSIDE any lock.
        private bool V184AcceptTick(V184TickClock clock, DateTime tickTime, bool playback, out string logLine)
        {
            logLine = null;

            try
            {
                if (clock.Newest == DateTime.MinValue || tickTime >= clock.Newest)
                {
                    clock.Newest = tickTime;
                    clock.FirstDropUtc = DateTime.MinValue;
                    return true;
                }

                double ageSec = (clock.Newest - tickTime).TotalSeconds;

                if (ageSec <= V184StaleTickToleranceSec)
                    return true; // normal tiny out-of-order

                if (playback)
                {
                    // Market Replay rewind: accept and re-anchor.
                    clock.Newest = tickTime;
                    clock.FirstDropUtc = DateTime.MinValue;
                    return true;
                }

                DateTime nowUtc = DateTime.UtcNow;

                if (clock.FirstDropUtc == DateTime.MinValue)
                    clock.FirstDropUtc = nowUtc;

                if ((nowUtc - clock.FirstDropUtc).TotalSeconds > V184StaleResyncSec)
                {
                    logLine =
                        "V1.7.84 TICK CLOCK RESYNC | Ticks kept arriving "
                        + ageSec.ToString("0.0") + "s older than the anchor for "
                        + V184StaleResyncSec.ToString("0") + "s | Anchor "
                        + clock.Newest.ToString("HH:mm:ss.fff") + " -> " + tickTime.ToString("HH:mm:ss.fff");
                    clock.Newest = tickTime;
                    clock.FirstDropUtc = DateTime.MinValue;
                    return true;
                }

                clock.Dropped++;
                clock.DroppedSinceLog++;
                if (ageSec > clock.WorstAgeSec)
                    clock.WorstAgeSec = ageSec;

                if (clock.LastLogUtc == DateTime.MinValue || (nowUtc - clock.LastLogUtc).TotalSeconds >= 30)
                {
                    logLine =
                        "V1.7.84 STALE TICKS DROPPED | Last 30s: " + clock.DroppedSinceLog
                        + " | Total: " + clock.Dropped
                        + " | Worst age: " + clock.WorstAgeSec.ToString("0.0") + "s"
                        + " | Newest tick " + clock.Newest.ToString("HH:mm:ss.fff")
                        + " | Dropped tick " + tickTime.ToString("HH:mm:ss.fff");
                    clock.LastLogUtc = nowUtc;
                    clock.DroppedSinceLog = 0;
                    clock.WorstAgeSec = 0;
                }

                return false;
            }
            catch
            {
                return true;
            }
        }

        // ---------------------------------------------------------
        // (3) Freshest live trade price
        // ---------------------------------------------------------
        // level2LastTradePrice comes straight from MarketData (Last) and is now protected
        // by the monotonic guard. If it is fresh (<= 3 s) it is used for unrealized PnL,
        // MFE/MAE, trailing and daily-target protection; otherwise the bar close is used.
        private DateTime v184LastTradeUtc = DateTime.MinValue;

        private double V184FreshLivePrice(double fallbackPrice)
        {
            try
            {
                double price;
                DateTime stampUtc;

                lock (level2Sync)
                {
                    price = level2LastTradePrice;
                    stampUtc = v184LastTradeUtc;
                }

                if (price > 0 &&
                    stampUtc != DateTime.MinValue &&
                    (DateTime.UtcNow - stampUtc).TotalSeconds <= 3.0)
                    return price;
            }
            catch
            {
            }

            return fallbackPrice;
        }

        // ---------------------------------------------------------
        // (5) Late data: lag monitor, late-signal guard, tick-driven protection
        // ---------------------------------------------------------
        // 16-oct the Range bars (HYBRID signals AND trade management) ran 45-70 s behind
        // the clock at the open: the 10:04:37 short was built on a 10:03:52 bar.
        private const double V184MaxSignalBarLagSec = 8.0;      // HYBRID entry blocked above this
        private const double V184BarLagLogSec = 5.0;            // log "MARKET DATA LAG" above this
        private const double V184TickProtectionEveryMs = 500.0; // tick-driven protection cadence

        private readonly object v184MgmtLock = new object();
        private DateTime v184LastMgmtUtc = DateTime.MinValue;
        private DateTime v184LastTickMgmtUtc = DateTime.MinValue;
        private DateTime v184LastLagLogUtc = DateTime.MinValue;
        private double v184LastBarLagSec;

        // "Now" for lag checks: wall clock in live (the PC clock must be synced), the replay
        // clock in Playback.
        private DateTime V184ReferenceNowNy()
        {
            return IsPlaybackStrategyClockActive() ? GetCentralClockNy() : GetCurrentNewYorkTime();
        }

        private void V184ReportBarLag(DateTime barNy)
        {
            try
            {
                if (barNy == DateTime.MinValue)
                    return;

                double lag = (V184ReferenceNowNy() - barNy).TotalSeconds;
                v184LastBarLagSec = lag;

                if (lag < V184BarLagLogSec)
                    return;

                DateTime nowUtc = DateTime.UtcNow;
                if (v184LastLagLogUtc != DateTime.MinValue && (nowUtc - v184LastLagLogUtc).TotalSeconds < 15)
                    return;

                v184LastLagLogUtc = nowUtc;

                PrintBotMessage(
                    "MARKET DATA LAG | Range bars " + lag.ToString("0.0") + "s behind the clock"
                    + " | Bar " + barNy.ToString("HH:mm:ss")
                    + " | HYBRID entries blocked above " + V184MaxSignalBarLagSec.ToString("0") + "s"
                    + " | Trade protection also runs from live ticks");
            }
            catch
            {
            }
        }

        // Account-side guard (TrySubmitCentralBrainAccountEntry): a HYBRID signal built on a bar
        // older than V184MaxSignalBarLagSec is not executed.
        private bool V184SignalIsLate(DateTime signalBarTime, out string reason)
        {
            reason = string.Empty;

            try
            {
                if (signalBarTime == DateTime.MinValue)
                    return false;

                DateTime barNy = ConvertToNewYorkTime(signalBarTime);
                double lag = (V184ReferenceNowNy() - barNy).TotalSeconds;

                if (lag > V184MaxSignalBarLagSec)
                {
                    reason = "SIGNAL LATE | Signal bar " + barNy.ToString("HH:mm:ss")
                        + " is " + lag.ToString("0.0") + "s behind the market (max "
                        + V184MaxSignalBarLagSec.ToString("0") + "s)";
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        // Called from the Level 2 MarketData handler (outside its lock) on every accepted trade.
        // While a position is open and the Range-bar management has not run for 500 ms, run the
        // same management (unrealized, daily-target protection, trailing/ladders) with the live
        // price, so protection never waits for late bars. Scale-in is NOT run from here.
        private void V184TickDrivenProtection(double livePrice)
        {
            try
            {
                // V1.7.114 - a manual TEST trade is also managed (MFE/MAE, stop map, trailing) even
                // while the automatic engine is STOPPED. Before, the test only had the static OCO.
                bool v1114ManualTestOpen;
                lock (executionStateLock)
                {
                    v1114ManualTestOpen = activeTradeIsManualTest;
                }

                if (livePrice <= 0 || (!botRunning && !v1114ManualTestOpen))
                    return;

                DateTime nowUtc = DateTime.UtcNow;

                if (v184LastTickMgmtUtc != DateTime.MinValue &&
                    (nowUtc - v184LastTickMgmtUtc).TotalMilliseconds < V184TickProtectionEveryMs)
                    return;

                bool open;
                lock (executionStateLock)
                {
                    open = entryMarketPosition != NinjaTrader.Cbi.MarketPosition.Flat &&
                           Math.Max(0, entryQuantity - activeExitQuantity) > 0;
                }

                if (!open)
                    return;

                if (v184LastMgmtUtc != DateTime.MinValue &&
                    (nowUtc - v184LastMgmtUtc).TotalMilliseconds < V184TickProtectionEveryMs)
                    return;

                v184LastTickMgmtUtc = nowUtc;

                // Never block the market-data thread waiting for the bars thread.
                if (!System.Threading.Monitor.TryEnter(v184MgmtLock))
                    return;

                try
                {
                    v184LastMgmtUtc = nowUtc;
                    UpdateUnrealizedPnL(livePrice);
                    UpdateDailyTargetProtection(livePrice);
                    UpdateMomentumTrailingStop(livePrice);
                }
                finally
                {
                    System.Threading.Monitor.Exit(v184MgmtLock);
                }

                CheckDailyLossEmergency();
            }
            catch (Exception ex)
            {
                try { PrintBotMessage("V1.7.84 TICK PROTECTION ERROR: " + ex.Message); } catch { }
            }
        }

        // ---------------------------------------------------------
        // (4) Log throttle
        // ---------------------------------------------------------
        private const double V184LogThrottleSec = 2.0;

        private static readonly string[] V184ThrottledPrefixes = new string[]
        {
            "LEVEL2 CONTEXT",
            "HEAVY ABSORPTION CONFIRMED",
            "ENTRY BLOCKED - ",
            "JJ AI CORE ACCOUNT BLOCK",
            "EXCEPTIONAL MICROSTRUCTURE AUTHORITY",
            "EXCEPTIONAL COMMITMENT HOLD",
            "DEGRADED MOMENTUM ENTRY BLOCKED",
            "ABSORPTION REVERSAL ENTRY WINDOW",
            "DUPLICATE SIGNAL EVALUATION SKIPPED",
            "CORE20 OPEN BELL | SKIP - MISSED",
            "CORE20 GERARD | SKIP",
            "CORE20 GERARD | RANGE FROM 1m BARS"
        };

        private sealed class V184LogSlot
        {
            public DateTime LastUtc;
            public int Suppressed;
        }

        private readonly object v184LogSync = new object();
        private readonly Dictionary<string, V184LogSlot> v184LogSlots = new Dictionary<string, V184LogSlot>();

        private bool V184ShouldPrint(string message, out string printable)
        {
            printable = message;

            try
            {
                if (string.IsNullOrEmpty(message))
                    return true;

                // V1.7.85 - Market Brain follower: the engines' evaluation lines are the brain's
                // job; a follower does not write duplicates (journal / lock reason still get them).
                if (V185IsFollowerEngineNoise(message))
                    return false;

                string prefix = null;
                for (int i = 0; i < V184ThrottledPrefixes.Length; i++)
                {
                    if (message.StartsWith(V184ThrottledPrefixes[i], StringComparison.Ordinal))
                    {
                        prefix = V184ThrottledPrefixes[i];
                        break;
                    }
                }

                if (prefix == null)
                    return true;

                // Key = message type (text up to the 1st " | "), so different block
                // reasons are throttled separately.
                int cut = message.IndexOf(" | ", StringComparison.Ordinal);
                string key = cut > 0 ? message.Substring(0, cut) : message;

                // "JJ AI CORE ACCOUNT BLOCK | Reason: X" -> keep the reason in the key.
                if (prefix == "JJ AI CORE ACCOUNT BLOCK" && cut > 0)
                {
                    int cut2 = message.IndexOf(" | ", cut + 3, StringComparison.Ordinal);
                    key = cut2 > 0 ? message.Substring(0, cut2) : message;
                }

                DateTime nowUtc = DateTime.UtcNow;

                lock (v184LogSync)
                {
                    V184LogSlot slot;
                    if (!v184LogSlots.TryGetValue(key, out slot))
                    {
                        slot = new V184LogSlot { LastUtc = nowUtc, Suppressed = 0 };
                        v184LogSlots[key] = slot;
                        return true;
                    }

                    if ((nowUtc - slot.LastUtc).TotalSeconds < V184LogThrottleSec)
                    {
                        slot.Suppressed++;
                        return false;
                    }

                    if (slot.Suppressed > 0)
                        printable = message + " | (+" + slot.Suppressed + " similar in " + V184LogThrottleSec.ToString("0") + "s, not logged)";

                    slot.LastUtc = nowUtc;
                    slot.Suppressed = 0;

                    if (v184LogSlots.Count > 500)
                        v184LogSlots.Clear();
                }
            }
            catch
            {
            }

            return true;
        }
    }
}

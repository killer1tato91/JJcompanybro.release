#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =====================================================================
    // V1.7.85 - MARKET BRAIN (one reader of the market, the profiles execute)
    //
    // Before: every profile subscribed to Level 2 (~10 M depth events/day each),
    // built its own book, tape, absorption and signals, and proposed trades.
    // 5 profiles = 5 x the same work and 5 slightly different readings
    // (16-oct: tape -3 / -1 / +6 / +7 / +13 at the same second).
    //
    // Now, per instrument:
    //   L2 brain      : ONE profile subscribes to MarketDepth and computes the L2
    //                   context. It publishes a snapshot every calculation (250 ms).
    //                   The other profiles do NOT subscribe to depth; they copy the
    //                   snapshot (same book, tape, absorption, Open Bell tape).
    //   Signal brain  : ONE profile per family (HYBRID, CORE20) evaluates and proposes
    //                   signals, ignoring its own account state (position, limits,
    //                   sizing). Every account - the brain's own included - applies
    //                   its own account rules when it executes the central decision.
    //
    // Failover: if the brain profile stops, the next running profile takes over at
    // once; if the brain stops publishing for 5 s, a follower takes over.
    // Kill switches: V185SharedL2Enabled / V185SharedSignalsEnabled (false = old behaviour).
    // =====================================================================

    internal sealed class JJGerardPlan
    {
        public DateTime DateNy;
        public int StopTicks;
        public int TargetTicks;
        public int Contracts;
        public string Source;
    }

    internal sealed class JJBrainL2Snapshot
    {
        public long Seq;
        public DateTime PublishedUtc;
        public string LeaderId;
        public object[] Values;          // aligned with JJBotWindow.V185MirrorFields
        public string ContextLine;       // last "LEVEL2 CONTEXT ..." line of the leader
        public long ContextSeq;
    }

    internal static class JJMarketBrainHub
    {
        private sealed class Role
        {
            public readonly List<JJBotWindow> Members = new List<JJBotWindow>();
            public JJBotWindow Leader;
            public DateTime LeaderSinceUtc = DateTime.MinValue;
            public DateTime LastPublishUtc = DateTime.MinValue;
            public DateTime LastAliveUtc = DateTime.MinValue;      // V1.7.86 dedicated brain heartbeat (timer)
            public volatile JJBrainL2Snapshot Snapshot;
        }


        private static readonly object sync = new object();
        private static readonly Dictionary<string, Role> roles = new Dictionary<string, Role>(StringComparer.OrdinalIgnoreCase);

        // key examples: "L2|MNQ 12-26", "SIG-HYBRID|MNQ 12-26", "SIG-CORE20|MNQ 12-26"
        private static Role Get(string key)
        {
            Role r;
            if (!roles.TryGetValue(key, out r))
            {
                r = new Role();
                roles[key] = r;
            }
            return r;
        }

        // Returns true when the window is (now) the leader of that role.
        public static bool Register(string key, JJBotWindow w)
        {
            if (string.IsNullOrEmpty(key) || w == null) return false;
            lock (sync)
            {
                Role r = Get(key);
                if (!r.Members.Contains(w)) r.Members.Add(w);
                // V1.7.86 - a profile that is covering keeps the role until the (re)started
                // market brain is warm; the brain takes it back from its 1-second timer.
                if (r.Leader == null || !r.Members.Contains(r.Leader))
                {
                    if (w.V186IsDedicatedBrain) r.LastAliveUtc = DateTime.UtcNow;
                    r.Leader = w;
                    r.LeaderSinceUtc = DateTime.UtcNow;
                    r.LastPublishUtc = DateTime.UtcNow;
                }
                return ReferenceEquals(r.Leader, w);
            }
        }

        // Removes the window. If it was the leader, returns the new leader (may be null).
        public static JJBotWindow Unregister(string key, JJBotWindow w, out bool wasLeader)
        {
            wasLeader = false;
            if (string.IsNullOrEmpty(key) || w == null) return null;
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r)) return null;
                r.Members.Remove(w);
                if (!ReferenceEquals(r.Leader, w)) return null;
                wasLeader = true;
                // V1.7.86 - prefer a WARM dedicated brain, else the first profile
                JJBotWindow nextBrain = r.Members.FirstOrDefault(m => m != null && m.V186IsDedicatedBrain && m.V186BrainWarm);
                r.Leader = nextBrain ?? (r.Members.Count > 0 ? r.Members[0] : null);
                r.LeaderSinceUtc = DateTime.UtcNow;
                r.LastPublishUtc = DateTime.UtcNow;
                return r.Leader;
            }
        }

        // V1.7.116 - every profile/brain registered in a role (for the NO TRADE TODAY notice)
        public static List<JJBotWindow> MembersOf(string key)
        {
            if (string.IsNullOrEmpty(key)) return new List<JJBotWindow>();
            lock (sync)
            {
                Role r;
                return roles.TryGetValue(key, out r) ? r.Members.ToList() : new List<JJBotWindow>();
            }
        }

        public static bool IsLeader(string key, JJBotWindow w)
        {
            if (string.IsNullOrEmpty(key) || w == null) return false;
            lock (sync)
            {
                Role r;
                return roles.TryGetValue(key, out r) && ReferenceEquals(r.Leader, w);
            }
        }

        public static bool HasLeader(string key)
        {
            lock (sync)
            {
                Role r;
                return roles.TryGetValue(key, out r) && r.Leader != null;
            }
        }

        public static string LeaderName(string key)
        {
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r) || r.Leader == null) return "NONE";
                return r.Leader.V185ProfileName();
            }
        }

        public static int MemberCount(string key)
        {
            lock (sync)
            {
                Role r;
                return roles.TryGetValue(key, out r) ? r.Members.Count : 0;
            }
        }

        // Heartbeat for roles that do not publish snapshots (signal brains).
        public static void Heartbeat(string key, JJBotWindow w)
        {
            lock (sync)
            {
                Role r;
                if (roles.TryGetValue(key, out r) && ReferenceEquals(r.Leader, w))
                    r.LastPublishUtc = DateTime.UtcNow;
            }
        }

        // Only the leader may publish. Returns false if the caller is no longer the leader.
        public static bool Publish(string key, JJBotWindow w, JJBrainL2Snapshot s)
        {
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r) || !ReferenceEquals(r.Leader, w)) return false;
                s.Seq = (r.Snapshot != null ? r.Snapshot.Seq : 0) + 1;
                s.PublishedUtc = DateTime.UtcNow;
                r.Snapshot = s;
                r.LastPublishUtc = s.PublishedUtc;
                return true;
            }
        }

        public static JJBrainL2Snapshot GetSnapshot(string key)
        {
            lock (sync)
            {
                Role r;
                return roles.TryGetValue(key, out r) ? r.Snapshot : null;
            }
        }

        // Returns the role holder once; callers keep it and read .Snapshot without locking.
        internal static object GetRoleHandle(string key)
        {
            lock (sync) { return Get(key); }
        }

        internal static JJBrainL2Snapshot ReadSnapshot(object handle)
        {
            Role r = handle as Role;
            return r != null ? r.Snapshot : null;
        }

        // V1.7.93 - the L2 brain can look "alive" (1-second timer / signal heartbeats) while it has
        // stopped publishing snapshots (depth feed stopped, replay jump, broken subscription).
        // Followers then kept a frozen tape/book for as long as the session lasted.  A member that
        // is receiving market data itself and sees the newest snapshot older than maxAgeSeconds
        // takes the L2 role over.  Returns true if the caller became the leader.
        public static bool TryTakeOverIfSnapshotFrozen(string key, JJBotWindow w, double maxAgeSeconds, out JJBotWindow oldLeader, out double ageSeconds)
        {
            oldLeader = null;
            ageSeconds = -1;
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r) || !r.Members.Contains(w)) return false;
                if (ReferenceEquals(r.Leader, w)) return false;
                DateTime last = r.Snapshot != null ? r.Snapshot.PublishedUtc : r.LeaderSinceUtc;
                if (last == DateTime.MinValue) return false;
                ageSeconds = (DateTime.UtcNow - last).TotalSeconds;
                if (ageSeconds <= maxAgeSeconds) return false;
                oldLeader = r.Leader;
                r.Leader = w;
                r.LeaderSinceUtc = DateTime.UtcNow;
                r.LastPublishUtc = DateTime.UtcNow;
                return true;
            }
        }

        // A member that sees the leader silent for longer than staleSeconds takes over.
        // Returns true if the caller became the leader.
        public static bool TryTakeOverIfStale(string key, JJBotWindow w, double staleSeconds, out JJBotWindow oldLeader)
        {
            oldLeader = null;
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r) || !r.Members.Contains(w)) return false;
                if (ReferenceEquals(r.Leader, w)) return false;
                // V1.7.86 - a dedicated brain is "silent" only when its 1-second timer stops
                // (a quiet market with no depth / trades is not a frozen brain).
                DateTime lastSign = r.Leader != null && r.Leader.V186IsDedicatedBrain
                    ? (r.LastAliveUtc > r.LastPublishUtc ? r.LastAliveUtc : r.LastPublishUtc)
                    : r.LastPublishUtc;
                if (r.Leader != null && (DateTime.UtcNow - lastSign).TotalSeconds <= staleSeconds) return false;
                // a dedicated brain never steals from a dedicated brain through staleness
                if (w.V186IsDedicatedBrain && r.Leader != null && r.Leader.V186IsDedicatedBrain
                    && (DateTime.UtcNow - lastSign).TotalSeconds <= staleSeconds * 2) return false;
                oldLeader = r.Leader;
                r.Leader = w;
                r.LeaderSinceUtc = DateTime.UtcNow;
                r.LastPublishUtc = DateTime.UtcNow;
                return true;
            }
        }

        // V1.7.86 - dedicated brain heartbeat (1 s timer), independent of market activity.
        public static void Alive(string key, JJBotWindow w)
        {
            lock (sync)
            {
                Role r;
                if (roles.TryGetValue(key, out r) && ReferenceEquals(r.Leader, w))
                    r.LastAliveUtc = DateTime.UtcNow;
            }
        }

        // V1.7.86 - the dedicated brain takes the role back from a profile that covered for it.
        // Returns true if the caller became the leader now.
        public static bool Reclaim(string key, JJBotWindow w)
        {
            if (w == null || !w.V186IsDedicatedBrain) return false;
            lock (sync)
            {
                Role r;
                if (!roles.TryGetValue(key, out r) || !r.Members.Contains(w)) return false;
                if (ReferenceEquals(r.Leader, w)) return false;
                if (r.Leader != null && r.Leader.V186IsDedicatedBrain) return false;
                r.Leader = w;
                r.LeaderSinceUtc = DateTime.UtcNow;
                r.LastPublishUtc = DateTime.UtcNow;
                r.LastAliveUtc = DateTime.UtcNow;
                return true;
            }
        }

        // Small shared "plans" a brain computes at signal time and every account needs at
        // execution time (e.g. the Gerard stop / target / size).
        private static readonly Dictionary<string, object> plans = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        public static void PutPlan(string key, object plan)
        {
            lock (sync) { plans[key] = plan; }
        }

        public static object GetPlan(string key)
        {
            lock (sync)
            {
                object p;
                return plans.TryGetValue(key, out p) ? p : null;
            }
        }

        public static void ResetAllForTests()
        {
            lock (sync) { roles.Clear(); plans.Clear(); }
            JJMarketBrainService.ResetForTests();
        }
    }

    public partial class JJBotWindow
    {
        // ---------------------------------------------------------------
        // Switches (static, not const, so they can be turned off quickly)
        // ---------------------------------------------------------------
        internal static bool V185SharedL2Enabled = true;
        internal static bool V185SharedSignalsEnabled = true;
        private const double V185LeaderStaleSeconds = 5.0;
        // V1.7.93 - a snapshot older than this while this profile itself receives trades = frozen L2 brain.
        private const double V193FrozenSnapshotSeconds = 20.0;
        // V1.7.93 - the L2 leader publishes at least this often from trades even with no depth events.
        private const double V193TapePublishMs = 1000.0;
        private DateTime v193LastTapePublishUtc = DateTime.MinValue;

        // V1.7.85 - New York time zone looked up ONCE (it was looked up on every tick in
        // several places: GetCurrentNewYorkTime / ConvertToNewYorkTime).
        private static TimeZoneInfo v185NyZone;

        private static TimeZoneInfo V185NyZone()
        {
            TimeZoneInfo z = v185NyZone;
            if (z == null)
            {
                z = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                v185NyZone = z;
            }
            return z;
        }

        // V1.7.85 - Playback and live never share a brain (same instrument name, different data).
        private string V185EnvTag()
        {
            bool playback = false;
            try { playback = IsPlaybackStrategyClockActive(); } catch { }
            return playback ? "PLAYBACK" : "LIVE";
        }

        private string V185Key(string role, Instrument instrument)
        {
            return role + "|" + (instrument != null ? instrument.FullName : "?") + "|" + V185EnvTag();
        }

        // V1.7.86 - signal roles are per strategy mode too (a HYBRID profile and a COMBINED
        // profile do not read the same signals before 10:00).
        private string V186SigKey(string role)
        {
            return V185Key(role, selectedInstrument) + "|" + JJMarketBrainService.NormalizeMode(activeStrategyMode);
        }

        internal string V185ProfileName()
        {
            string acc = null;
            try { acc = selectedAccount != null ? selectedAccount.Name : null; } catch { }
            return (platformProfileId ?? "profile-?") + (string.IsNullOrEmpty(acc) ? string.Empty : " (" + acc + ")");
        }

        // ===============================================================
        // PHASE 1 - SHARED LEVEL 2
        // ===============================================================
        private string v185L2Key;
        private volatile bool v185L2Leader = true;     // true = behaves exactly like before
        private bool v185L2Registered;
        private bool v185DepthSubscribed;
        private long v185AppliedSeq;
        private long v185AppliedContextSeq;
        private string v185LastContextLine;
        private long v185ContextSeq;
        private DateTime v185LastStaleCheckUtc = DateTime.MinValue;
        private object v185L2Handle;

        // Fields copied from the L2 brain to the followers: every instance field whose name
        // starts with "level2" plus the Open Bell 5-minute tape, EXCEPT the ones each profile
        // keeps for itself (own lock, own subscription, own last bid/ask/trade from ticks).
        private static readonly HashSet<string> V185MirrorExclude = new HashSet<string>(StringComparer.Ordinal)
        {
            "level2Sync", "level2ObservedInstrument", "level2ObserveActive", "level2LastLogUtc",
            "level2LastTradePrice", "level2LastBidPrice", "level2LastAskPrice"
        };

        private static FieldInfo[] v185MirrorFields;
        private static readonly object v185MirrorInitSync = new object();

        internal static FieldInfo[] V185MirrorFields
        {
            get
            {
                if (v185MirrorFields != null) return v185MirrorFields;
                lock (v185MirrorInitSync)
                {
                    if (v185MirrorFields != null) return v185MirrorFields;
                    v185MirrorFields = typeof(JJBotWindow)
                        .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)
                        .Where(f => !f.IsLiteral
                            && (f.Name.StartsWith("level2", StringComparison.Ordinal) || f.Name == "obTape5mDelta" || f.Name == "obTape5mSnaps")
                            && !V185MirrorExclude.Contains(f.Name))
                        .OrderBy(f => f.Name, StringComparer.Ordinal)
                        .ToArray();
                    return v185MirrorFields;
                }
            }
        }

        private static readonly MethodInfo V185MemberwiseClone =
            typeof(object).GetMethod("MemberwiseClone", BindingFlags.Instance | BindingFlags.NonPublic);

        private static bool V185IsPlainElement(Type listType)
        {
            Type[] ga = listType.IsGenericType ? listType.GetGenericArguments() : null;
            return ga != null && ga.Length == 1 && (ga[0].IsValueType || ga[0] == typeof(string));
        }

        private static object V185CloneValue(object value)
        {
            if (value == null) return null;
            Type t = value.GetType();
            if (t.IsValueType || value is string) return value;

            System.Collections.IList list = value as System.Collections.IList;
            if (list != null && t.IsGenericType)
            {
                // value-type elements (e.g. the 35-min price history): typed bulk copy, no boxing
                if (V185IsPlainElement(t))
                    return Activator.CreateInstance(t, value);

                System.Collections.IList copy = (System.Collections.IList)Activator.CreateInstance(t);
                foreach (object item in list)
                    copy.Add(item == null || item is string ? item : V185MemberwiseClone.Invoke(item, null));
                return copy;
            }

            // Any other reference type: shallow clone.
            return V185MemberwiseClone.Invoke(value, null);
        }

        private static void V185AssignValue(FieldInfo f, object target, object value)
        {
            object current = f.GetValue(target);
            System.Collections.IList dst = current as System.Collections.IList;
            System.Collections.IList src = value as System.Collections.IList;

            if (dst != null && src != null && f.IsInitOnly)
            {
                // readonly lists: replace the contents in place
                dst.Clear();
                Type lt = dst.GetType();
                if (V185IsPlainElement(lt))
                {
                    MethodInfo addRange = lt.GetMethod("AddRange");
                    if (addRange != null) { addRange.Invoke(dst, new object[] { src }); return; }
                }
                foreach (object item in src)
                    dst.Add(item == null || item.GetType().IsValueType || item is string ? item : V185MemberwiseClone.Invoke(item, null));
                return;
            }

            f.SetValue(target, V185CloneValue(value));
        }

        // Called from StartLevel2Observe (after the instrument is set). Returns true if this
        // profile must subscribe to MarketDepth (leader or shared L2 disabled).
        private bool V185RegisterL2(Instrument instrument)
        {
            v185AppliedSeq = 0;
            v185AppliedContextSeq = 0;

            if (!V185SharedL2Enabled || instrument == null)
            {
                v185L2Leader = true;
                v185L2Registered = false;
                return true;
            }

            v185L2Key = V185Key("L2", instrument);
            v185L2Leader = JJMarketBrainHub.Register(v185L2Key, this);
            v185L2Handle = JJMarketBrainHub.GetRoleHandle(v185L2Key);
            v185L2Registered = true;

            PrintBotMessage(
                "MARKET BRAIN L2 | " + (v185L2Leader ? (v186IsDedicatedBrain ? "THE MARKET BRAIN READS LEVEL 2 FOR ALL" : "THIS PROFILE READS LEVEL 2 FOR ALL") : "FOLLOWER - uses the Level 2 of " + JJMarketBrainHub.LeaderName(v185L2Key))
                + " | Profiles on " + instrument.FullName + ": " + JJMarketBrainHub.MemberCount(v185L2Key));

            return v185L2Leader;
        }

        // Called from StopLevel2Observe.
        private void V185UnregisterL2()
        {
            if (!v185L2Registered) return;
            v185L2Registered = false;

            bool wasLeader;
            JJBotWindow next = JJMarketBrainHub.Unregister(v185L2Key, this, out wasLeader);

            if (wasLeader && next != null)
            {
                try { next.V185PromoteToL2Leader("previous L2 brain " + V185ProfileName() + " stopped"); } catch { }
            }

            v185L2Leader = true;
        }

        internal void V185PromoteToL2Leader(string why)
        {
            if (!level2ObserveActive) return;
            v185L2Leader = true;
            V185SubscribeDepth(true);
            PrintBotMessage("MARKET BRAIN L2 | THIS PROFILE TAKES OVER LEVEL 2 | " + why);
        }

        internal void V185DemoteFromL2Leader(string why)
        {
            v185L2Leader = false;
            V185SubscribeDepth(false);
            PrintBotMessage("MARKET BRAIN L2 | FOLLOWER AGAIN | " + why);
        }

        private void V185SubscribeDepth(bool subscribe)
        {
            Instrument inst = level2ObservedInstrument;
            if (inst == null) return;

            inst.Dispatcher.BeginInvoke(
                new Action(() =>
                {
                    try
                    {
                        if (subscribe)
                        {
                            if (!v185DepthSubscribed && level2ObserveActive && level2ObservedInstrument != null)
                            {
                                level2ObservedInstrument.MarketDepth.Update += OnLevel2DepthUpdate;
                                v185DepthSubscribed = true;
                            }
                        }
                        else if (v185DepthSubscribed)
                        {
                            inst.MarketDepth.Update -= OnLevel2DepthUpdate;
                            v185DepthSubscribed = false;
                        }
                    }
                    catch
                    {
                    }
                }));
        }

        // Leader: build and publish a snapshot (called right after CalculateLevel2Context /
        // LogLevel2Context, outside level2Sync).
        private void V185PublishL2()
        {
            if (!V185SharedL2Enabled || !v185L2Registered || !v185L2Leader) return;

            try
            {
                FieldInfo[] fields = V185MirrorFields;
                object[] values = new object[fields.Length];

                lock (level2Sync)
                {
                    for (int i = 0; i < fields.Length; i++)
                        values[i] = V185CloneValue(fields[i].GetValue(this));
                }

                JJBrainL2Snapshot s = new JJBrainL2Snapshot
                {
                    LeaderId = V185ProfileName(),
                    Values = values,
                    ContextLine = v185LastContextLine,
                    ContextSeq = v185ContextSeq
                };

                if (!JJMarketBrainHub.Publish(v185L2Key, this, s))
                    V185DemoteFromL2Leader("another profile is the L2 brain now");
            }
            catch (Exception ex)
            {
                PrintBotMessage("MARKET BRAIN L2 PUBLISH ERROR: " + ex.Message);
            }
        }

        // V1.7.93 - leader: publish from trades too (at most once a second) when no depth event
        // published recently, so the tape counters reach the followers even without depth.
        private void V193PublishFromTapeIfLeader()
        {
            if (!V185SharedL2Enabled || !v185L2Registered || !v185L2Leader) return;
            DateTime nowUtc = DateTime.UtcNow;
            if ((nowUtc - v193LastTapePublishUtc).TotalMilliseconds < V193TapePublishMs) return;
            if ((nowUtc - level2LastCalcUtc).TotalMilliseconds < V193TapePublishMs) return;   // depth is publishing
            v193LastTapePublishUtc = nowUtc;
            V185PublishL2();
        }

        // Follower: copy the newest snapshot (called on every MarketData event, outside level2Sync).
        private void V185ApplyL2IfFollower()
        {
            if (!V185SharedL2Enabled || !v185L2Registered || v185L2Leader) return;

            try
            {
                JJBrainL2Snapshot s = v185L2Handle != null
                    ? JJMarketBrainHub.ReadSnapshot(v185L2Handle)
                    : JJMarketBrainHub.GetSnapshot(v185L2Key);

                // stale leader -> take over (checked at most once a second)
                DateTime nowUtc = DateTime.UtcNow;
                if ((nowUtc - v185LastStaleCheckUtc).TotalSeconds >= 1.0)
                {
                    v185LastStaleCheckUtc = nowUtc;
                    JJBotWindow old;
                    if (JJMarketBrainHub.TryTakeOverIfStale(v185L2Key, this, V185LeaderStaleSeconds, out old))
                    {
                        V185PromoteToL2Leader("L2 brain " + (old != null ? old.V185ProfileName() : "NONE")
                            + " silent > " + V185LeaderStaleSeconds.ToString("0") + "s");
                        return;
                    }

                    // V1.7.93 - alive but not publishing: take over instead of following a frozen tape
                    double frozenAge;
                    if (JJMarketBrainHub.TryTakeOverIfSnapshotFrozen(v185L2Key, this, V193FrozenSnapshotSeconds, out old, out frozenAge))
                    {
                        V185PromoteToL2Leader("L2 brain " + (old != null ? old.V185ProfileName() : "NONE")
                            + " frozen: last snapshot " + frozenAge.ToString("0") + "s old");
                        return;
                    }
                }

                if (s == null || s.Seq == v185AppliedSeq) return;

                FieldInfo[] fields = V185MirrorFields;
                if (s.Values == null || s.Values.Length != fields.Length) return;

                lock (level2Sync)
                {
                    for (int i = 0; i < fields.Length; i++)
                        V185AssignValue(fields[i], this, s.Values[i]);
                }

                v185AppliedSeq = s.Seq;

                if (s.ContextSeq != v185AppliedContextSeq && !string.IsNullOrEmpty(s.ContextLine))
                {
                    v185AppliedContextSeq = s.ContextSeq;
                    // same line the brain logged, so each account's log/journal keeps its L2 context
                    PrintBotMessage(s.ContextLine);
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("MARKET BRAIN L2 APPLY ERROR: " + ex.Message);
            }
        }

        // Called from PrintBotMessage: remember the leader's context line for the snapshot.
        private void V185CaptureContextLine(string message)
        {
            if (v185L2Leader && message != null && message.StartsWith("LEVEL2 CONTEXT", StringComparison.Ordinal))
            {
                v185LastContextLine = message;
                v185ContextSeq++;
            }
        }

        // ===============================================================
        // PHASE 2 - ONE SIGNAL BRAIN PER FAMILY (HYBRID, CORE20)
        // ===============================================================
        private string v185LastProposalKey = string.Empty;
        private DateTime v185LastProposalUtc = DateTime.MinValue;
        private readonly HashSet<string> v185SignalFamilies = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly object v185SignalSync = new object();
        private DateTime v185LastSignalCheckUtc = DateTime.MinValue;
        private readonly Dictionary<string, DateTime> v185FollowerLogUtc = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        // Family of a signal, or null for legacy strategies (they keep the old behaviour:
        // every profile evaluates and proposes).
        private string V185SignalFamilyKey(string entryStrategy)
        {
            if (!V185SharedSignalsEnabled || selectedInstrument == null)
                return null;

            if (IsCore20Strategy(entryStrategy))
                return IsCore20EngineMode() ? V186SigKey("SIG-CORE20") : null;

            if (IsHybridSelectedForFixedBracket())
                return V186SigKey("SIG-HYBRID");

            return null;
        }

        private void V185RegisterSignalFamily(string key)
        {
            if (string.IsNullOrEmpty(key)) return;

            bool added;
            lock (v185SignalSync) { added = v185SignalFamilies.Add(key); }

            bool leader = JJMarketBrainHub.Register(key, this);

            if (added)
                PrintBotMessage(
                    "MARKET BRAIN " + key.Split('|')[0] + " | "
                    + (leader ? (v186IsDedicatedBrain ? "THE MARKET BRAIN EVALUATES THE SIGNALS FOR ALL" : "THIS PROFILE EVALUATES THE SIGNALS FOR ALL") : "FOLLOWER - executes the signals of " + JJMarketBrainHub.LeaderName(key)));
        }

        // Called when the bars engine starts.
        private void V185RegisterSignalFamilies()
        {
            if (!V185SharedSignalsEnabled || selectedInstrument == null) return;

            if (IsCore20EngineMode())
                V185RegisterSignalFamily(V186SigKey("SIG-CORE20"));

            if (IsHybridSelectedForFixedBracket())
                V185RegisterSignalFamily(V186SigKey("SIG-HYBRID"));
        }

        // Called when the bars engine stops: hands the signal role to the next profile.
        private void V185UnregisterSignalFamilies()
        {
            List<string> keys;
            lock (v185SignalSync)
            {
                keys = v185SignalFamilies.ToList();
                v185SignalFamilies.Clear();
            }

            foreach (string k in keys)
            {
                bool wasLeader;
                JJBotWindow next = JJMarketBrainHub.Unregister(k, this, out wasLeader);

                if (wasLeader && next != null)
                {
                    try
                    {
                        next.PrintBotMessage("MARKET BRAIN " + k.Split('|')[0] + " | THIS PROFILE TAKES OVER THE SIGNALS | previous brain " + V185ProfileName() + " stopped");
                    }
                    catch { }
                }
            }
        }

        // True = this profile must NOT evaluate / propose this family's signal.
        private bool V185IsSignalFollower(string familyKey)
        {
            if (string.IsNullOrEmpty(familyKey)) return false;

            bool member;
            lock (v185SignalSync) { member = v185SignalFamilies.Contains(familyKey); }
            if (!member) V185RegisterSignalFamily(familyKey);

            if (JJMarketBrainHub.IsLeader(familyKey, this))
            {
                JJMarketBrainHub.Heartbeat(familyKey, this);
                return false;
            }

            return true;
        }

        // ===============================================================
        // PHASE 3 - HOT STANDBY + LESS DUPLICATE WORK
        // Followers keep their engines warm (bars, indicators, CORE20 tick tracking) so any
        // of them can take over instantly, but they no longer write the engines' evaluation
        // lines to the log / UI: the brain's log has them once. (Journal, Lock Reason and all
        // trade / order / risk lines are unchanged.)
        // ===============================================================
        private volatile bool v185SignalFollowerCached;

        private static readonly string[] V185FollowerQuietPrefixes = new string[]
        {
            "MOVE PHASE", "EXPLOSION EDGE EXECUTION", "EXPLOSION DIRECTION COMMITMENT", "SETUP QUALITY",
            "RANGE MOMENTUM", "SMART RETEST", "DECISION |", "BUY SCORE", "SELL SCORE", "AGGRESSIVE EXPANSION",
            "ABSORPTION REVERSAL ENTRY WINDOW", "EXCEPTIONAL MICROSTRUCTURE", "EXCEPTIONAL COMMITMENT",
            "DEGRADED MOMENTUM", "WAIT PULLBACK", "SKIP STRUCTURE", "ENTRY LOCATION", "HTF CONTEXT",
            "HEAVY ABSORPTION CONFIRMED", "OB SHADOW", "CORE20 GERARD | RANGE"
        };

        // Used by the log throttle: true = do not write this line (follower duplicate).
        private bool V185IsFollowerEngineNoise(string message)
        {
            if (!V185SharedSignalsEnabled || !v185SignalFollowerCached || string.IsNullOrEmpty(message))
                return false;

            for (int i = 0; i < V185FollowerQuietPrefixes.Length; i++)
                if (message.StartsWith(V185FollowerQuietPrefixes[i], StringComparison.Ordinal))
                    return true;

            return false;
        }

        // Heartbeat / stale take-over. Called on market events (Range bars update, CORE20 ticks).
        private DateTime v185LastBrainTickUtc = DateTime.MinValue;

        private void V185SignalBrainTick()
        {
            if (!V185SharedSignalsEnabled) return;

            DateTime tickUtc = DateTime.UtcNow;
            if ((tickUtc - v185LastBrainTickUtc).TotalMilliseconds < 250) return;
            v185LastBrainTickUtc = tickUtc;

            List<string> keys;
            lock (v185SignalSync)
            {
                if (v185SignalFamilies.Count == 0) return;
                keys = v185SignalFamilies.ToList();
            }

            DateTime nowUtc = DateTime.UtcNow;
            bool doStaleCheck = (nowUtc - v185LastSignalCheckUtc).TotalSeconds >= 1.0;
            if (doStaleCheck) v185LastSignalCheckUtc = nowUtc;

            bool followerOfAny = false;

            foreach (string k in keys)
            {
                if (JJMarketBrainHub.IsLeader(k, this))
                {
                    JJMarketBrainHub.Heartbeat(k, this);
                    continue;
                }

                followerOfAny = true;

                if (!doStaleCheck) continue;

                JJBotWindow old;
                if (JJMarketBrainHub.TryTakeOverIfStale(k, this, V185LeaderStaleSeconds, out old))
                    PrintBotMessage("MARKET BRAIN " + k.Split('|')[0] + " | THIS PROFILE TAKES OVER THE SIGNALS | brain "
                        + (old != null ? old.V185ProfileName() : "NONE") + " silent > " + V185LeaderStaleSeconds.ToString("0") + "s");
            }

            v185SignalFollowerCached = followerOfAny;
        }

        // One log line per family every 60 s on followers (instead of the full evaluation).
        private void V185LogFollowerSkip(string familyKey, string what)
        {
            try
            {
                DateTime nowUtc = DateTime.UtcNow;
                DateTime last;
                lock (v185SignalSync)
                {
                    if (v185FollowerLogUtc.TryGetValue(familyKey, out last) && (nowUtc - last).TotalSeconds < 60)
                        return;
                    v185FollowerLogUtc[familyKey] = nowUtc;
                }

                PrintBotMessage("MARKET BRAIN " + familyKey.Split('|')[0] + " | " + what + " evaluated by " + JJMarketBrainHub.LeaderName(familyKey)
                    + " | this account executes its decisions with its own risk rules");
            }
            catch
            {
            }
        }

        // Status line (once a minute from the range-bar handler).
        private DateTime v185LastStatusUtc = DateTime.MinValue;

        private void V185LogBrainStatus()
        {
            if (!V185SharedL2Enabled && !V185SharedSignalsEnabled) return;
            if (v186IsDedicatedBrain) return;   // V1.7.86 - the brain writes its own ALIVE line

            try
            {
                DateTime nowUtc = DateTime.UtcNow;
                if ((nowUtc - v185LastStatusUtc).TotalSeconds < 60) return;
                v185LastStatusUtc = nowUtc;

                if (selectedInstrument == null) return;
                string l2 = V185Key("L2", selectedInstrument);
                JJBrainL2Snapshot s = JJMarketBrainHub.GetSnapshot(l2);
                double age = s == null ? -1 : (nowUtc - s.PublishedUtc).TotalSeconds;

                PrintBotMessage(
                    "MARKET BRAIN STATUS | " + V185EnvTag() + " | L2: " + JJMarketBrainHub.LeaderName(l2)
                    + (V185IsL2Follower() ? " (snapshot age " + (age < 0 ? "N/A" : age.ToString("0.0") + "s") + ")" : " (this profile)")
                    + " | HYBRID signals: " + JJMarketBrainHub.LeaderName(V186SigKey("SIG-HYBRID"))
                    + " | CORE20 signals: " + JJMarketBrainHub.LeaderName(V186SigKey("SIG-CORE20"))
                    + " | Profiles: " + JJMarketBrainHub.MemberCount(l2));
            }
            catch
            {
            }
        }

        // True when this profile must NOT do its own tape (aggressor) counting: the counts
        // come from the brain's snapshot.
        private bool V185IsL2Follower()
        {
            return V185SharedL2Enabled && v185L2Registered && !v185L2Leader;
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =====================================================================
    // V1.7.86 - MARKET BRAIN SERVICE (the brains no longer live inside a profile)
    //
    // V1.7.85: the L2 and the signals were read by ONE PROFILE (the first one started).
    // If that profile stopped, another profile took over, and with every profile
    // stopped there was no L2 / no context at all (tape, absorption, persistence,
    // Open Bell tape started empty when a profile was started).
    //
    // V1.7.86: a dedicated, hidden engine per instrument (and strategy mode) - the
    // MARKET BRAIN - is created by the AddOn. It has NO account and never trades:
    //   - it subscribes to Level 2 + trades and keeps the book / tape / absorption ready,
    //   - it runs the bars and the signal engines (HYBRID + CORE20) and proposes,
    //   - it keeps running when the profiles are stopped (it only stops with NinjaTrader).
    // The profiles only manage their accounts: they take the brain's L2 and execute the
    // brain's decisions with their own risk rules.
    //
    // Start: at NinjaTrader start (instruments saved from the last session, as soon as a
    // live connection is connected) and whenever a profile is started (if not running).
    // Safety net: the profiles keep a warm standby copy; if the brain freezes for 5 s
    // a profile covers until the brain is back (the brain then takes the role back).
    // Switch: JJMarketBrainService.Enabled = false -> V1.7.85 behaviour.
    // =====================================================================
    internal static class JJMarketBrainService
    {
        internal static bool Enabled = true;

        internal const string BrainIdPrefix = "market-brain";

        private static readonly object sync = new object();
        private static readonly Dictionary<string, JJBotWindow> brains =
            new Dictionary<string, JJBotWindow>(StringComparer.OrdinalIgnoreCase);
        private static int brainCounter;

        private static DispatcherTimer autoStartTimer;
        private static Dispatcher uiDispatcher;
        private static bool shuttingDown;

        internal static bool IsBrainId(string profileId)
        {
            return !string.IsNullOrEmpty(profileId)
                && profileId.StartsWith(BrainIdPrefix, StringComparison.OrdinalIgnoreCase);
        }

        internal static string NormalizeMode(string mode)
        {
            return string.IsNullOrWhiteSpace(mode) ? "HYBRID" : mode.Trim().ToUpperInvariant();
        }

        private static string BrainKey(string instrumentName, bool playback, string mode)
        {
            return (instrumentName ?? "?") + "|" + (playback ? "PLAYBACK" : "LIVE") + "|" + NormalizeMode(mode);
        }

        // Creates (or returns) the brain for instrument + environment + strategy mode.
        // Must be called on a UI dispatcher thread (it creates a hidden NinjaTrader window).
        internal static JJBotWindow Ensure(Instrument instrument, bool playback, string mode, string reason)
        {
            if (!Enabled || shuttingDown || instrument == null)
                return null;

            string key = BrainKey(instrument.FullName, playback, mode);
            JJBotWindow brain;
            List<JJBotWindow> retired = new List<JJBotWindow>();

            lock (sync)
            {
                if (brains.TryGetValue(key, out brain) && brain != null && brain.V186BrainRunning)
                    return brain;

                // contract roll: a brain on an older expiry of the same instrument is retired
                string master = MasterName(instrument);
                foreach (KeyValuePair<string, JJBotWindow> p in brains.ToArray())
                {
                    if (p.Value == null || p.Key == key) continue;
                    string[] parts = p.Key.Split('|');
                    if (parts.Length == 3 && parts[1] == (playback ? "PLAYBACK" : "LIVE")
                        && !string.Equals(parts[0], instrument.FullName, StringComparison.OrdinalIgnoreCase)
                        && string.Equals(MasterName(p.Value.V186BrainInstrument), master, StringComparison.OrdinalIgnoreCase))
                    {
                        retired.Add(p.Value);
                        brains.Remove(p.Key);
                    }
                }

                brainCounter++;
                brain = new JJBotWindow(BrainIdPrefix + "-" + brainCounter, false);
                brains[key] = brain;
            }

            foreach (JJBotWindow old in retired)
            {
                try { old.V186StopBrainRuntime("contract roll -> " + instrument.FullName); } catch { }
                try { old.V186CloseBrainWindow(); } catch { }
            }

            try
            {
                brain.V186StartBrainRuntime(instrument, playback, NormalizeMode(mode), reason);
            }
            catch (Exception ex)
            {
                try { NinjaTrader.Code.Output.Process("J&J BOT | MARKET BRAIN START ERROR: " + ex.Message, PrintTo.OutputTab1); } catch { }
            }

            if (!playback)
                SaveAutoStart(instrument.FullName, NormalizeMode(mode));

            return brain;
        }

        private static string MasterName(Instrument instrument)
        {
            try
            {
                return instrument != null && instrument.MasterInstrument != null
                    ? instrument.MasterInstrument.Name
                    : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        internal static List<string> Describe()
        {
            lock (sync)
            {
                return brains.Where(p => p.Value != null && p.Value.V186BrainRunning)
                    .Select(p => p.Value.V185ProfileName() + " " + p.Key).ToList();
            }
        }

        // ---------------------------------------------------------------
        // NinjaTrader start: bring the live brains back (instrument + mode of the last session)
        // ---------------------------------------------------------------
        internal static void StartAutoStart(Dispatcher dispatcher)
        {
            if (!Enabled || dispatcher == null) return;

            dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    uiDispatcher = dispatcher;
                    if (autoStartTimer != null) return;

                    autoStartTimer = new DispatcherTimer(DispatcherPriority.Background, dispatcher);
                    autoStartTimer.Interval = TimeSpan.FromSeconds(15);
                    autoStartTimer.Tick += (s, e) => AutoStartTick();
                    autoStartTimer.Start();
                }
                catch
                {
                }
            }));
        }

        private static void AutoStartTick()
        {
            if (!Enabled || shuttingDown) return;

            try
            {
                if (!IsLiveConnectionConnected())
                    return;

                foreach (string line in LoadAutoStart())
                {
                    string[] p = line.Split('|');
                    if (p.Length < 2) continue;

                    string key = BrainKey(p[0], false, p[1]);
                    JJBotWindow existing;
                    lock (sync)
                    {
                        if (brains.TryGetValue(key, out existing) && existing != null && existing.V186BrainRunning)
                            continue;
                    }

                    Instrument inst = null;
                    try { inst = Instrument.GetInstrument(p[0]); } catch { }
                    if (inst == null) continue;

                    Ensure(inst, false, p[1], "NinjaTrader started (saved from the last session)");
                }
            }
            catch
            {
            }
        }

        // A non-Playback connection is connected (the live brain must not read Playback data).
        private static bool IsLiveConnectionConnected()
        {
            try
            {
                lock (Connection.Connections)
                {
                    foreach (Connection c in Connection.Connections)
                    {
                        if (c == null || c.Status != ConnectionStatus.Connected) continue;
                        string name = c.Options != null ? (c.Options.Name ?? string.Empty) : string.Empty;
                        if (name.IndexOf("Playback", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private static string AutoStartFile()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "NinjaTrader 8", "JJBotData", "market_brain_autostart.txt");
        }

        private static List<string> LoadAutoStart()
        {
            try
            {
                string f = AutoStartFile();
                if (!File.Exists(f)) return new List<string>();
                return File.ReadAllLines(f).Where(l => !string.IsNullOrWhiteSpace(l)).Select(l => l.Trim()).Distinct().ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        // Keeps the last 4 instrument|mode pairs; an older expiry of the same root is replaced.
        private static void SaveAutoStart(string instrumentName, string mode)
        {
            try
            {
                string root = (instrumentName ?? string.Empty).Split(' ')[0];
                List<string> lines = LoadAutoStart()
                    .Where(l => !(l.Split('|')[0].Split(' ')[0].Equals(root, StringComparison.OrdinalIgnoreCase)
                                  && !l.Split('|')[0].Equals(instrumentName, StringComparison.OrdinalIgnoreCase)))
                    .ToList();

                string entry = instrumentName + "|" + mode;
                lines.RemoveAll(l => l.Equals(entry, StringComparison.OrdinalIgnoreCase));
                lines.Insert(0, entry);
                if (lines.Count > 4) lines = lines.Take(4).ToList();

                string f = AutoStartFile();
                Directory.CreateDirectory(Path.GetDirectoryName(f));
                File.WriteAllLines(f, lines);
            }
            catch
            {
            }
        }

        // NinjaTrader is closing.
        internal static void ShutdownAll()
        {
            List<JJBotWindow> all;
            lock (sync)
            {
                shuttingDown = true;
                all = brains.Values.Where(b => b != null).ToList();
                brains.Clear();
            }

            try { if (autoStartTimer != null) autoStartTimer.Stop(); } catch { }
            autoStartTimer = null;

            foreach (JJBotWindow b in all)
            {
                try { b.V186StopBrainRuntime("NinjaTrader closing"); } catch { }
                try { b.V186CloseBrainWindow(); } catch { }
            }
        }

        internal static void ResetForTests()
        {
            List<JJBotWindow> all;
            lock (sync)
            {
                all = brains.Values.Where(b => b != null).ToList();
                brains.Clear();
                brainCounter = 0;
                shuttingDown = false;
            }

            foreach (JJBotWindow b in all)
            {
                try { b.V186StopBrainRuntime("test reset"); } catch { }
            }
        }
    }

    public partial class JJBotWindow
    {
        // True for the hidden market-brain engine (no account, never trades).
        private bool v186IsDedicatedBrain;
        private bool v186BrainPlayback;
        private volatile bool v186BrainRunning;
        private DateTime v186BrainStartedUtc = DateTime.MinValue;
        private DispatcherTimer v186BrainTimer;
        private DateTime v186BrainLastRestartUtc = DateTime.MinValue;
        private DateTime v186BrainLastStatusUtc = DateTime.MinValue;
        private long v186BrainDepthEventsAtCheck;
        private DateTime v186BrainDepthCheckUtc = DateTime.MinValue;

        internal bool V186IsDedicatedBrain { get { return v186IsDedicatedBrain; } }
        internal bool V186BrainRunning { get { return v186IsDedicatedBrain && v186BrainRunning; } }
        internal Instrument V186BrainInstrument { get { return selectedInstrument; } }

        // A (re)started brain needs some minutes of market before it takes the roles from a
        // profile that is covering (path-dependent states: explosion commitment, retest
        // arms, CORE20 09:00 range coverage...). Meanwhile it follows like a profile.
        private const double V186BrainWarmupSeconds = 600.0;

        internal bool V186BrainWarm
        {
            get
            {
                return v186IsDedicatedBrain && v186BrainRunning
                    && (DateTime.UtcNow - v186BrainStartedUtc).TotalSeconds >= V186BrainWarmupSeconds;
            }
        }

        // Never change hands during the open (09:20-10:05 NY: Open Bell, Gerard, CORE20 window).
        private bool V186CanReclaimNow()
        {
            if (!V186BrainWarm) return false;
            TimeSpan t = GetCurrentNewYorkTime().TimeOfDay;
            return !(t >= new TimeSpan(9, 20, 0) && t < new TimeSpan(10, 5, 0));
        }

        private DateTime v186LastWarmLogUtc = DateTime.MinValue;

        internal void V186StartBrainRuntime(Instrument instrument, bool playback, string mode, string reason)
        {
            v186IsDedicatedBrain = true;
            v186BrainPlayback = playback;

            selectedAccount = null;
            selectedInstrument = instrument;

            activeStrategyMode = mode;
            try { if (strategyCombo != null) strategyCombo.SelectedItem = mode; } catch { }

            activeDirection = "BOTH";
            try { if (directionCombo != null) directionCombo.SelectedItem = "BOTH"; } catch { }

            activeContracts = 1;
            activeStopTicks = HybridFixedStopTicks;
            activeTargetTicks = HybridFixedTargetTicks;
            activeMaxTrades = MaxTradesPerSessionAllowed;
            activeDailyTarget = MaxDailyTargetAllowed;
            activeDailyLoss = MaxDailyLossAllowed;
            activeDollarRiskCap = MaxDollarRiskCapAllowed;

            entryPending = false;
            entryMarketPosition = MarketPosition.Flat;
            executionStatus = "MARKET BRAIN";

            botRunning = true;
            v186BrainRunning = true;
            v186BrainStartedUtc = DateTime.UtcNow;
            v186BrainLastRestartUtc = DateTime.UtcNow;

            automaticEntryWarmupUntilNy = GetCurrentNewYorkTime().AddSeconds(StartupEntryWarmupSeconds);
            lastStartupWarmupBlockLogKey = string.Empty;

            try { LoadLearningMemory(); } catch { }

            PrintBotMessage(
                "MARKET BRAIN SERVICE | STARTED | " + V185ProfileName()
                + " | Instrument: " + (instrument != null ? instrument.FullName : "?")
                + " | " + (playback ? "PLAYBACK" : "LIVE")
                + " | Strategy: " + mode
                + " | No account - reads Level 2 + market and proposes signals; the profiles execute"
                + " | Reason: " + (reason ?? "-"));

            StartBarsEngine();

            try
            {
                if (v186BrainTimer == null)
                {
                    v186BrainTimer = new DispatcherTimer(DispatcherPriority.Background, Dispatcher);
                    v186BrainTimer.Interval = TimeSpan.FromSeconds(1);
                    v186BrainTimer.Tick += V186BrainTimerTick;
                }
                v186BrainTimer.Start();
            }
            catch
            {
            }
        }

        internal void V186StopBrainRuntime(string why)
        {
            if (!v186IsDedicatedBrain) return;

            v186BrainRunning = false;
            botRunning = false;

            try { if (v186BrainTimer != null) v186BrainTimer.Stop(); } catch { }

            try { StopBarsEngine(); } catch { }

            PrintBotMessage("MARKET BRAIN SERVICE | STOPPED | " + (why ?? "-"));
        }

        internal void V186CloseBrainWindow()
        {
            try { RequestPermanentClose(); } catch { }
        }

        // Market events also prove the brain is alive (at most every 250 ms): the first tick
        // after a pause in the feed must not look like a frozen brain to the profiles.
        private DateTime v186LastDataAliveUtc = DateTime.MinValue;

        private void V186BrainAliveFromData()
        {
            if (!v186IsDedicatedBrain || !v186BrainRunning) return;

            DateTime nowUtc = DateTime.UtcNow;
            if ((nowUtc - v186LastDataAliveUtc).TotalMilliseconds < 250) return;
            v186LastDataAliveUtc = nowUtc;

            try
            {
                if (!string.IsNullOrEmpty(v185L2Key)) JJMarketBrainHub.Alive(v185L2Key, this);

                List<string> keys;
                lock (v185SignalSync) { keys = v185SignalFamilies.ToList(); }
                foreach (string k in keys) JJMarketBrainHub.Alive(k, this);
            }
            catch
            {
            }
        }

        // Every second: alive + keep the roles, watchdog of the data.
        private void V186BrainTimerTick(object sender, EventArgs e)
        {
            if (!v186IsDedicatedBrain || !v186BrainRunning) return;

            try
            {
                DateTime nowUtc = DateTime.UtcNow;

                // 1) alive + take the roles back if a profile covered for us
                bool canReclaim = V186CanReclaimNow();

                if (V185SharedL2Enabled && v185L2Registered && !string.IsNullOrEmpty(v185L2Key))
                {
                    JJMarketBrainHub.Alive(v185L2Key, this);
                    if (!v185L2Leader && canReclaim && JJMarketBrainHub.Reclaim(v185L2Key, this))
                        V185PromoteToL2Leader("the market brain is warm - takes Level 2 back");
                }

                List<string> keys;
                lock (v185SignalSync) { keys = v185SignalFamilies.ToList(); }
                bool coveredByProfile = V185SharedL2Enabled && v185L2Registered && !v185L2Leader;
                foreach (string k in keys)
                {
                    JJMarketBrainHub.Alive(k, this);
                    if (canReclaim && JJMarketBrainHub.Reclaim(k, this))
                        PrintBotMessage("MARKET BRAIN " + k.Split('|')[0] + " | the market brain is warm - takes the signals back");
                    if (!JJMarketBrainHub.IsLeader(k, this)) coveredByProfile = true;
                    JJMarketBrainHub.Heartbeat(k, this);
                }

                if (coveredByProfile && (nowUtc - v186LastWarmLogUtc).TotalSeconds >= 60)
                {
                    v186LastWarmLogUtc = nowUtc;
                    PrintBotMessage(JJRangeFeedDiagnostics.RoleStatus(V186BrainWarm, canReclaim,
                        (int)Math.Max(0, V186BrainWarmupSeconds - (nowUtc - v186BrainStartedUtc).TotalSeconds),
                        JJMarketBrainHub.LeaderName(v185L2Key ?? "L2")));
                }

                ReportRangeFeedDiagnostic(nowUtc);

                // Independent of BarsRequest.Update: also runs when Range freezes.
                RangeRecoveryWatchdog(nowUtc);

                // 2) M5 startup watchdog. Range (including failed reloads) has its own
                // recovery above; do not restart all feeds while Range is reloading.
                bool ready = barsReady;
                if (!ready
                    && (nowUtc - v186BrainStartedUtc).TotalSeconds > 90
                    && (nowUtc - v186BrainLastRestartUtc).TotalSeconds > 120)
                {
                    v186BrainLastRestartUtc = nowUtc;
                    PrintBotMessage("MARKET BRAIN SERVICE | DATA NOT READY (5m " + (barsReady ? "OK" : "WAIT")
                        + " / range " + (rangeBarsReady ? "OK" : "WAIT") + ") - restarting the data engine");
                    StartBarsEngine();
                    return;
                }

                // 3) depth watchdog: trades arrive but no depth event for 60 s -> resubscribe
                if (v185L2Leader && level2ObserveActive)
                {
                    if (v186BrainDepthCheckUtc == DateTime.MinValue) v186BrainDepthCheckUtc = nowUtc;
                    if ((nowUtc - v186BrainDepthCheckUtc).TotalSeconds >= 60)
                    {
                        long ev = System.Threading.Interlocked.Read(ref level2DepthEvents);
                        bool tradesFlowing = (nowUtc - v184LastTradeUtc).TotalSeconds < 10;
                        if (ev == v186BrainDepthEventsAtCheck && tradesFlowing)
                        {
                            PrintBotMessage("MARKET BRAIN L2 | NO DEPTH EVENTS FOR 60 s WHILE TRADES ARRIVE - resubscribing Level 2");
                            V185SubscribeDepth(false);
                            V185SubscribeDepth(true);
                        }
                        v186BrainDepthEventsAtCheck = ev;
                        v186BrainDepthCheckUtc = nowUtc;
                    }
                }

                // 4) status line once a minute
                if ((nowUtc - v186BrainLastStatusUtc).TotalSeconds >= 60)
                {
                    v186BrainLastStatusUtc = nowUtc;
                    string l2 = !string.IsNullOrEmpty(v185L2Key) ? v185L2Key : "L2";
                    PrintBotMessage("MARKET BRAIN SERVICE | ALIVE | " + (v186BrainPlayback ? "PLAYBACK" : "LIVE")
                        + " | Data: " + (ready ? "LOADED" : "LOADING")
                        + " | Range feed: " + rangeFeedDiagnostic.State(nowUtc, rangeBarsReady)
                        + " | L2: " + (v185L2Leader ? "THIS BRAIN" : JJMarketBrainHub.LeaderName(l2))
                        + " | Profiles connected: " + Math.Max(0, JJMarketBrainHub.MemberCount(l2) - 1)
                        + " | Signals: " + string.Join(", ", keys.Select(k => k.Split('|')[0] + "=" + JJMarketBrainHub.LeaderName(k))));
                }
            }
            catch (Exception ex)
            {
                PrintBotMessage("MARKET BRAIN SERVICE TIMER ERROR: " + ex.Message);
            }
        }

        // ---------------------------------------------------------------
        // V1.7.86 - ACCOUNT RE-ENTRY RULES AT EXECUTION
        // The re-entry rules depend on the ACCOUNT's own last automatic exit (time, side,
        // loss/BE, price, range bar). The signal brain has no trades, so every account
        // applies them here with its own history (before, the history of whichever profile
        // proposed the signal was used for everybody). Same rules / constants as the
        // signal path in TrySubmitEntry. HYBRID (non-CORE20) signals only.
        // ---------------------------------------------------------------
        private bool V186AccountReentryBlocked(JJCentralMarketDecision signal, bool isLong, out string reason)
        {
            reason = string.Empty;

            if (signal == null || !signal.V186HasContext)
                return false;

            if (lastAutomaticTradeExitNy == DateTime.MinValue)
                return false;   // no automatic exit yet on this account (today)

            string side = isLong ? "LONG" : "SHORT";
            bool sameSide = string.Equals(lastAutomaticTradeExitSide, side, StringComparison.OrdinalIgnoreCase);
            bool unified = signal.V186UnifiedAuthority;
            bool openingEntry = signal.OpeningEntry;
            bool momentumEntry = !openingEntry && string.IsNullOrWhiteSpace(signal.StructureSetupKey);

            DateTime signalNy = ConvertToNewYorkTime(signal.SignalBarTime);
            int signalTimeInt = ToTimeInt(signalNy);

            string m5Structure;
            DateTime m5DecisionNy;
            lock (marketContextLock)
            {
                m5Structure = latestM5StructureState;
                m5DecisionNy = latestM5DecisionNyTime;
            }

            bool freshM5AfterExit = m5DecisionNy != DateTime.MinValue && m5DecisionNy > lastAutomaticTradeExitNy;
            bool alignedStructure = IsStructureAlignedForSetup(isLong, m5Structure);

            // 1) opening window: same-side LOSS needs fresh aligned M5 structure
            if (lastAutomaticTradeExitWasLoss && sameSide && !unified
                && signalTimeInt >= OpeningRangeStart && signalTimeInt <= OpeningSameSideLossStructureRearmEnd
                && (!alignedStructure || !freshM5AfterExit))
            {
                reason = "SAME-SETUP LOSS REARM (this account) | Side: " + side
                    + " | Structure: " + (string.IsNullOrWhiteSpace(m5Structure) ? "WAITING" : m5Structure)
                    + " | FreshM5AfterExit: " + freshM5AfterExit;
                return true;
            }

            // 2) 60 s rearm / same-side loss / new range bar
            string rearm;
            if (IsAutomaticReentryBlocked(isLong, signal.SignalBarTime, momentumEntry, signal.V186HighConviction, out rearm))
            {
                reason = "REENTRY REARM (this account) | " + rearm + " | Side: " + side
                    + " | LastExit: " + lastAutomaticTradeExitNy.ToString("HH:mm:ss") + " ET";
                return true;
            }

            if (sameSide && !unified)
            {
                // 3) same-side reset: fresh M5 after the exit + aligned BOS/CHOCH
                if (!freshM5AfterExit || !alignedStructure)
                {
                    reason = "SAME-SIDE REENTRY RESET (this account) | Side: " + side
                        + " | FreshM5AfterExit: " + freshM5AfterExit
                        + " | Structure: " + (string.IsNullOrWhiteSpace(m5Structure) ? "WAITING" : m5Structure);
                    return true;
                }

                // 4) Level 2 same-side re-entry veto
                bool bookReady;
                int oppPersistence;
                string tapeBias;
                lock (level2Sync)
                {
                    bookReady = level2BookReady;
                    oppPersistence = isLong ? level2ShortPersistence : level2LongPersistence;
                    tapeBias = level2TapeBias ?? string.Empty;
                }

                if (bookReady && oppPersistence >= 5
                    && string.Equals(tapeBias, isLong ? "SHORT" : "LONG", StringComparison.OrdinalIgnoreCase))
                {
                    reason = "REENTRY LEVEL2 VETO (this account) | Side: " + side
                        + " | TapeBias: " + tapeBias + " | OppPersistence: " + oppPersistence + "/6";
                    return true;
                }
            }

            // 5) same-side re-entry needs more room to the next structure (1.25R instead of the initial R)
            if (sameSide && !openingEntry && signal.V186LocHasBarrier && !signal.V186LocExceptional)
            {
                double minRoom = Math.Max(EntryLocationMinRoomTicks, activeStopTicks * ReentryMinimumStructuralR);
                if (signal.V186LocRoomTicks < minRoom)
                {
                    reason = "STRUCTURE LOCATION - REENTRY (this account) | Side: " + side
                        + " | Room: " + signal.V186LocRoomTicks.ToString("0") + "t < " + minRoom.ToString("0") + "t";
                    return true;
                }
            }

            // 6) re-entry chase cooldown (momentum entries)
            if (ReentryChaseCooldownEnabled && momentumEntry && sameSide && lastAutomaticTradeExitPrice > 0)
            {
                double chasePrice = GetEntryLocationPriceProxy(isLong);
                double extension = isLong ? chasePrice - lastAutomaticTradeExitPrice : lastAutomaticTradeExitPrice - chasePrice;
                double minutes = (GetCurrentNewYorkTime() - lastAutomaticTradeExitNy).TotalMinutes;

                if (chasePrice > 0 && minutes >= 0.0 && minutes < ReentryChaseCooldownMinutes && extension > ReentryChaseMinPoints)
                {
                    reason = "REENTRY CHASE COOLDOWN (this account) | Side: " + side
                        + " | LastExit: " + lastAutomaticTradeExitPrice.ToString("0.00")
                        + " | Price: " + chasePrice.ToString("0.00")
                        + " | Extension: " + extension.ToString("0.0") + "pts";
                    return true;
                }
            }

            return false;
        }

        // Profile side: make sure the market brain exists before this profile starts its engine.
        private void V186EnsureMarketBrainForProfile()
        {
            if (v186IsDedicatedBrain || !JJMarketBrainService.Enabled) return;
            if (!V185SharedL2Enabled && !V185SharedSignalsEnabled) return;
            if (selectedInstrument == null) return;

            try
            {
                JJBotWindow brain = JJMarketBrainService.Ensure(
                    selectedInstrument,
                    IsPlaybackStrategyClockActive(),
                    activeStrategyMode,
                    "profile " + V185ProfileName() + " started");

                if (brain != null)
                    PrintBotMessage("MARKET BRAIN SERVICE | this profile only manages its account | brain: "
                        + brain.V185ProfileName() + " (" + activeStrategyMode + ", " + V185EnvTag() + ")");
            }
            catch (Exception ex)
            {
                PrintBotMessage("MARKET BRAIN SERVICE | ENSURE ERROR: " + ex.Message + " | this profile uses the V1.7.85 fallback");
            }
        }
    }
}

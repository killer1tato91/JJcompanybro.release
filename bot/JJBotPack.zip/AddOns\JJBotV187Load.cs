#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =====================================================================
    // V1.7.87 - LESS LOAD ON THE NINJATRADER UI THREAD
    //
    // The bot windows are hidden (the app shows the bot through telemetry), but every
    // price / bar update still queued a text refresh of the hidden window on the
    // NinjaTrader UI thread: ~426,000 refreshes per 09:00-10:30 session with 5 profiles +
    // the market brain (replay count; more ticks live). Same thread that draws charts.
    // Now a hidden window refreshes its text at most every 5 s; an open window refreshes
    // on every update as before. Trading logic, telemetry and logs are unchanged.
    // =====================================================================
    public partial class JJBotWindow
    {
        internal static bool V187HiddenUiThrottleEnabled = true;
        private const double V187HiddenUiRefreshSeconds = 5.0;

        private volatile bool v187UiVisible;
        private readonly DateTime[] v187UiLastPostUtc = new DateTime[8];

        private bool V187ShouldPostUi(int slot)
        {
            if (!V187HiddenUiThrottleEnabled || v187UiVisible)
                return true;

            if (slot < 0 || slot >= v187UiLastPostUtc.Length)
                return true;

            DateTime nowUtc = DateTime.UtcNow;
            if ((nowUtc - v187UiLastPostUtc[slot]).TotalSeconds < V187HiddenUiRefreshSeconds)
                return false;

            v187UiLastPostUtc[slot] = nowUtc;
            return true;
        }
    }
}

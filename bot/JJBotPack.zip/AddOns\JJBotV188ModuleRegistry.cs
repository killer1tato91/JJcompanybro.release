// JJ BOT V1.7.88 - module of every bot entry (Open Bell / Gerard / Hybrid / CORE20 15:30)
// The bot records the route of each entry it submits; the JJ Company Bro AddOn reads it when
// the trade closes and sends "module" to the Journal, so the app shows P&L per strategy
// exactly (before, the AddOn could only guess from the entry time).
using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class JJBotEntryModuleRegistry
    {
        private static readonly object sync = new object();
        private static readonly Dictionary<string, KeyValuePair<DateTime, string>> lastEntry =
            new Dictionary<string, KeyValuePair<DateTime, string>>(StringComparer.OrdinalIgnoreCase);

        internal static string ModuleFromRoute(string route)
        {
            string r = (route ?? string.Empty).Trim().ToUpperInvariant();
            if (r == "CORE20_OPENBELL") return "OPEN_BELL";
            if (r == "CORE20_GERARD") return "GERARD";
            if (r == "CORE20_PM1530") return "CORE20_1530";
            if (r.StartsWith("CORE20_", StringComparison.Ordinal)) return "CORE20";
            return "HYBRID";
        }

        internal static void Record(string accountName, string route)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return;
            lock (sync)
                lastEntry[accountName.Trim()] = new KeyValuePair<DateTime, string>(DateTime.UtcNow, ModuleFromRoute(route));
        }

        // Module of the entry submitted for this account in the last <seconds> seconds ("" if none).
        internal static string Lookup(string accountName, double seconds = 120)
        {
            if (string.IsNullOrWhiteSpace(accountName)) return string.Empty;
            lock (sync)
            {
                KeyValuePair<DateTime, string> v;
                if (lastEntry.TryGetValue(accountName.Trim(), out v) && (DateTime.UtcNow - v.Key).TotalSeconds <= seconds)
                    return v.Value;
            }
            return string.Empty;
        }
    }
}

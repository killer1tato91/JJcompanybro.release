#region Using declarations
using System;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.89 - ENTRY GUARD (from a review of a client's logs, 01-16 Oct 2026)
    //
    //  1) DOUBLE ENTRY GUARD
    //     Two central decisions arrived 144 ms apart (08-oct 10:22:52) and the
    //     account entered 8 MNQ instead of 4: the first market order filled and
    //     cleared entryPending, but the broker had not updated the account
    //     position yet, so IsSelectedInstrumentFlat() still said FLAT.
    //     Now a new entry is refused while
    //       - another entry was sent less than 5 s ago (market clock, so
    //         Playback at any speed behaves like live), or
    //       - the bot's own fill state says LONG/SHORT (for 120 s after the
    //         last entry, then the real account position decides again).
    //     Log: "ENTRY BLOCKED - DOUBLE ENTRY GUARD | ..."
    //
    //  2) REJECTED ENTRIES ARE VISIBLE + PAUSE
    //     A blocked / failed / passed prop account rejects every order. Before,
    //     the rejection was cleared silently and the bot kept sending entries
    //     all day (35-45 "ENTRY SUBMITTED" with no fill in the client logs).
    //     Now every rejection is logged ("ENTRY REJECTED | ...") and after 3
    //     rejections in a row the profile stops sending entries for the rest of
    //     the NY day: "ACCOUNT REJECTING ORDERS - NEW ENTRIES PAUSED".
    //     Status in the app/panel: "ACCOUNT REJECTING ORDERS".
    //     Cleared by: a filled entry, pressing START again, or a new NY day.
    //
    //  Signals, sizing, protection and trade management are NOT changed.
    //  Switch off: V189EntryGuardEnabled = false;
    // =========================================================
    public partial class JJBotWindow
    {
        private const bool V189EntryGuardEnabled = true;
        private const double V189DoubleEntryWindowSeconds = 5.0;
        private const double V189OwnPositionTrustSeconds = 120.0;
        private const int V189RejectPauseCount = 3;

        private DateTime v189LastEntrySubmitNy = DateTime.MinValue;   // strategy clock (Playback-aware)
        private int v189ConsecutiveRejects;
        private DateTime v189RejectPauseDayNy = DateTime.MinValue;
        private DateTime v189LastGuardLogUtc = DateTime.MinValue;

        private DateTime V189TodayNy()
        {
            try
            {
                return GetCurrentNewYorkTime().Date;
            }
            catch
            {
                return DateTime.UtcNow.Date;
            }
        }

        // Pure check (no logging). Safe to call inside executionStateLock.
        private bool V189EntryGuardHit(out string reason)
        {
            reason = string.Empty;

            if (!V189EntryGuardEnabled)
                return false;

            if (v189RejectPauseDayNy != DateTime.MinValue)
            {
                if (v189RejectPauseDayNy == V189TodayNy())
                {
                    reason = "ACCOUNT REJECTING ORDERS (" + v189ConsecutiveRejects + " rejected in a row) - press START to retry";
                    return true;
                }

                // new NY day -> clear the pause
                v189RejectPauseDayNy = DateTime.MinValue;
                v189ConsecutiveRejects = 0;
            }

            if (v189LastEntrySubmitNy == DateTime.MinValue)
                return false;

            DateTime nowNy;
            try { nowNy = GetCurrentNewYorkTime(); }
            catch { return false; }

            double sinceLast = (nowNy - v189LastEntrySubmitNy).TotalSeconds;

            if (sinceLast >= 0 && sinceLast < V189DoubleEntryWindowSeconds)
            {
                reason = "another entry was sent " + sinceLast.ToString("0.0") + "s ago";
                return true;
            }

            if (
                sinceLast >= 0 &&
                sinceLast < V189OwnPositionTrustSeconds &&
                entryMarketPosition != MarketPosition.Flat
            )
            {
                reason = "bot fill state is " + entryMarketPosition + " (account position not updated yet)";
                return true;
            }

            return false;
        }

        private bool V189EntryGuardHit()
        {
            string ignored;
            return V189EntryGuardHit(out ignored);
        }

        // Check + throttled log. Call OUTSIDE executionStateLock, before submitting.
        private bool V189CheckEntryGuard(string side)
        {
            string reason;
            bool hit;

            lock (executionStateLock)
            {
                hit = V189EntryGuardHit(out reason);
            }

            if (!hit)
                return false;

            if ((DateTime.UtcNow - v189LastGuardLogUtc).TotalSeconds >= 2.0)
            {
                v189LastGuardLogUtc = DateTime.UtcNow;
                PrintBotMessage(
                    (v189RejectPauseDayNy != DateTime.MinValue
                        ? "ENTRY BLOCKED - ACCOUNT REJECTING ORDERS"
                        : "ENTRY BLOCKED - DOUBLE ENTRY GUARD")
                    + " | Side: " + side
                    + " | " + reason);
            }

            return true;
        }

        // Call inside executionStateLock right after entryPending = true.
        private void V189MarkEntrySubmittedLocked()
        {
            try { v189LastEntrySubmitNy = GetCurrentNewYorkTime(); }
            catch { v189LastEntrySubmitNy = DateTime.MinValue; }
        }

        private void V189OnEntryRejected(OrderEventArgs e)
        {
            if (!V189EntryGuardEnabled || e == null)
                return;

            int count;
            bool pausedNow = false;

            lock (executionStateLock)
            {
                v189ConsecutiveRejects++;
                count = v189ConsecutiveRejects;

                // a rejected entry never filled: do not keep the 5 s / 120 s window
                v189LastEntrySubmitNy = DateTime.MinValue;

                if (count >= V189RejectPauseCount && v189RejectPauseDayNy == DateTime.MinValue)
                {
                    v189RejectPauseDayNy = V189TodayNy();
                    pausedNow = true;
                    executionStatus = "ACCOUNT REJECTING ORDERS";
                }
            }

            PrintBotMessage(
                "ENTRY REJECTED"
                + " | Order: " + (e.Order != null ? e.Order.Name : "?")
                + " | Account: " + (selectedAccount != null ? selectedAccount.Name : "?")
                + " | State: " + (e.Order != null ? e.Order.OrderState.ToString() : "?")
                + " | Error: " + e.Error
                + " | Comment: " + e.Comment
                + " | In a row: " + count + "/" + V189RejectPauseCount);

            if (pausedNow)
            {
                currentSetupState = "ACCOUNT REJECTING ORDERS";

                PrintBotMessage(
                    "ACCOUNT REJECTING ORDERS - NEW ENTRIES PAUSED"
                    + " | Account: " + (selectedAccount != null ? selectedAccount.Name : "?")
                    + " | " + count + " entries rejected in a row (account blocked, failed, passed or disconnected?)"
                    + " | Check the account in NinjaTrader / the prop firm, then press START to retry. Clears on a new NY day.");

                try { PublishSharedState(); } catch { }
            }
        }

        private void V189OnEntryFilled()
        {
            lock (executionStateLock)
            {
                v189ConsecutiveRejects = 0;
                v189RejectPauseDayNy = DateTime.MinValue;
            }
        }

        // Pressing START clears a pause (the user checked the account).
        private void V189ResetOnStart()
        {
            lock (executionStateLock)
            {
                v189ConsecutiveRejects = 0;
                v189RejectPauseDayNy = DateTime.MinValue;
                v189LastEntrySubmitNy = DateTime.MinValue;
            }
        }
    }
}

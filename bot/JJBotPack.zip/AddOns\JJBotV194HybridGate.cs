#region Using declarations
using System;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.94 - HYBRID ENTRY GATE (analisis 2026-10-18: 62 trades reales 10-sep..16-oct + backtest 214 dias)
    //
    //  1) HYBRID NO OPERA LA APERTURA (09:30 - 10:15 NY)
    //     Real: antes de 10:15 -19.4 t/trade (42% win); despues de 10:15 +16.3 t/trade (67% win).
    //     Backtest: 10:00-10:10 -12.9 t/trade, 10:10-10:20 -5.8, 10:20-10:30 +2.4.
    //     La apertura queda para CORE20 (que ahi gana). Fuera de esa ventana no cambia nada.
    //
    //  2) HYBRID NO ENTRA CON TIMING "EARLY" (antes de confirmar)
    //     Real: EARLY -11.7 t/trade (16) vs resto +11.5. Backtest: EARLY -12.5 (29) vs resto -5.1.
    //
    //  CORE20 y las pruebas manuales NO se tocan. El candado de ganancia ya existe desde V1.7.91
    //  (+40t -> stop +15, +50 -> +25, +60 -> +38, +70 -> +50).
    //  Apagar: V194HybridGateEnabled = false (o cada regla por separado).
    // =========================================================
    public partial class JJBotWindow
    {
        internal static bool V194HybridGateEnabled = true;
        internal static bool V194BlockOpeningWindow = true;
        internal static bool V194BlockEarlyTiming = true;
        private static readonly TimeSpan V194OpenBlockFromNy = new TimeSpan(9, 30, 0);
        private static readonly TimeSpan V194OpenBlockToNy = new TimeSpan(10, 15, 0);

        private string v194LastGateLogKey = string.Empty;

        // true = la entrada HYBRID se bloquea (y lo deja escrito en el log una vez por barra/razon)
        private bool V194HybridGateBlocks(bool isLong, DateTime signalNyTime, string entryStrategy, bool manualTest)
        {
            if (!V194HybridGateEnabled || manualTest)
                return false;

            if (IsCore20Strategy(entryStrategy))
                return false;

            string reason = null;
            TimeSpan tod = signalNyTime.TimeOfDay;

            if (V194BlockOpeningWindow && tod >= V194OpenBlockFromNy && tod < V194OpenBlockToNy)
                reason = "OPENING WINDOW 09:30-10:15 (HYBRID waits, CORE20 owns the open)";
            else if (V194BlockEarlyTiming &&
                     string.Equals((latestSetupTiming ?? string.Empty).Trim(), "EARLY", StringComparison.OrdinalIgnoreCase))
                reason = "TIMING EARLY (wait for confirmation / retest)";

            if (reason == null)
                return false;

            string key = (isLong ? "L|" : "S|") + signalNyTime.ToString("yyyyMMddHHmm") + "|" + reason;
            if (key != v194LastGateLogKey)
            {
                v194LastGateLogKey = key;
                PrintBotMessage(
                    "ENTRY BLOCKED - V1.7.94 HYBRID GATE"
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | Strategy: " + (entryStrategy ?? string.Empty)
                    + " | NY: " + signalNyTime.ToString("HH:mm:ss")
                    + " | Reason: " + reason);
            }

            return true;
        }
    }
}

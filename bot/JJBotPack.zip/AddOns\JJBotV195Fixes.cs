#region Using declarations
using System;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.95 - FIXES FROM THE 19-23 OCT 2026 WEEK REVIEW
    //
    //  1) OPEN BELL LADDER vs TP RACE (22-oct and 23-oct)
    //     The ladder moved the stop in the same second the TP filled. On 23-oct
    //     (LFE...022) the cancel arrived late, the moved stop FILLED after the TP and
    //     opened a new 4 MNQ position that the bot did not see. The GUARDIAN (23-oct)
    //     already closes that position if it happens; this rule avoids creating it:
    //       - the stop is only moved when stop and target are live (Working/Accepted),
    //       - not during the first 1.5 s after the bracket is live,
    //       - not within 1.0 s of the previous ladder change,
    //       - not when price is within V195LadderNoMoveNearTpTicks of the target.
    //
    //  2) HYBRID L2 GATE (was LOG ONLY since V1.7.84)
    //     19-23 oct: the 3 HYBRID entries flagged "L2 OPPOSED WOULD BLOCK" all went
    //     straight to SL (21-oct 11:01, 22-oct 10:34, 23-oct 10:34).
    //     L2 recorder 02-23 oct, 10:15-11:00 window: L2 supportive 17 trades 71% win
    //     +14.8 t/trade; L2 neutral 9 trades 33% win -14.1 t/trade.
    //       - Any time: HYBRID does not enter against a LEAN/STRONG L2 confluence.
    //       - 10:15-11:00 NY: HYBRID needs L2 confluence IN FAVOR (LEAN/STRONG same side).
    //
    //  3) HYBRID WARM-UP AFTER START (central brain decisions)
    //     22-oct: START 10:33:16 -> SHORT 10:34:45 straight to SL. The 30 s warm-up
    //     only covered local entries. Now the account also waits V195HybridWarmupSeconds
    //     after START before executing HYBRID decisions of the market brain.
    //
    //  CORE20 (Open Bell / Gerard) entries are NOT touched by 2) and 3).
    //  To turn off: V195Enabled = false, or each rule separately below.
    // =========================================================
    public partial class JJBotWindow
    {
        internal static bool V195Enabled = true;

        internal static bool V195LadderGuardEnabled = true;
        internal static int V195LadderBracketSettleMs = 1500;
        internal static int V195LadderMinIntervalMs = 1000;
        internal static int V195LadderNoMoveNearTpTicks = 8;

        internal static bool V195BlockL2Opposed = true;
        internal static bool V195RequireL2InFavorWindow = true;
        private static readonly TimeSpan V195FavorWindowFromNy = new TimeSpan(10, 15, 0);
        private static readonly TimeSpan V195FavorWindowToNy = new TimeSpan(11, 0, 0);

        internal static bool V195HybridWarmupEnabled = true;
        internal static int V195HybridWarmupSeconds = 180;

        private DateTime v195StartedUtc = DateTime.MinValue;
        private Order v195LadderStopRef;
        private DateTime v195LadderStopSeenUtc = DateTime.MinValue;
        private DateTime v195LastLadderChangeUtc = DateTime.MinValue;
        private string v195LastGateLogKey = string.Empty;
        private DateTime v195LastLadderSkipLogUtc = DateTime.MinValue;

        // Called once per START (JJBotRuntimeControl, next to V189ResetOnStart).
        private void V195OnStart()
        {
            v195StartedUtc = DateTime.UtcNow;
            v195LadderStopRef = null;
            v195LadderStopSeenUtc = DateTime.MinValue;
            v195LastLadderChangeUtc = DateTime.MinValue;
            v195LastGateLogKey = string.Empty;
        }

        private void V195NoteStopChange()
        {
            v195LastLadderChangeUtc = DateTime.UtcNow;
        }

        // true = do NOT send the ladder stop change now (it is retried on the next tick).
        private bool V195LadderChangeUnsafe(MarketPosition side, Order localStopOrder, double currentPrice, double tickSize, string tag)
        {
            if (!V195Enabled || !V195LadderGuardEnabled || localStopOrder == null)
                return false;

            try
            {
                DateTime nowUtc = DateTime.UtcNow;
                string reason = null;

                if (!ReferenceEquals(v195LadderStopRef, localStopOrder))
                {
                    v195LadderStopRef = localStopOrder;
                    v195LadderStopSeenUtc = nowUtc;
                }

                Order localTarget;
                double localTargetPrice;
                lock (executionStateLock)
                {
                    localTarget = targetOrder;
                    localTargetPrice = activeTargetPrice;
                }

                bool stopLive =
                    localStopOrder.OrderState == OrderState.Working ||
                    localStopOrder.OrderState == OrderState.Accepted;

                bool targetLive =
                    localTarget == null ||
                    localTarget.OrderState == OrderState.Working ||
                    localTarget.OrderState == OrderState.Accepted;

                if (!stopLive)
                    reason = "STOP NOT LIVE (" + localStopOrder.OrderState + ")";
                else if (!targetLive)
                    reason = "TARGET NOT LIVE (" + localTarget.OrderState + ")";
                else if ((nowUtc - v195LadderStopSeenUtc).TotalMilliseconds < V195LadderBracketSettleMs)
                    reason = "BRACKET SETTLING";
                else if (v195LastLadderChangeUtc != DateTime.MinValue &&
                         (nowUtc - v195LastLadderChangeUtc).TotalMilliseconds < V195LadderMinIntervalMs)
                    reason = "PREVIOUS CHANGE <" + V195LadderMinIntervalMs + "ms";
                else if (localTargetPrice > 0 && tickSize > 0 && currentPrice > 0)
                {
                    double ticksToTp =
                        side == MarketPosition.Long
                            ? (localTargetPrice - currentPrice) / tickSize
                            : (currentPrice - localTargetPrice) / tickSize;

                    if (ticksToTp <= V195LadderNoMoveNearTpTicks)
                        reason = "TP " + ticksToTp.ToString("0") + "t AWAY (fill imminent)";
                }

                if (reason == null)
                    return false;

                if ((nowUtc - v195LastLadderSkipLogUtc).TotalMilliseconds >= 1000)
                {
                    v195LastLadderSkipLogUtc = nowUtc;
                    PrintBotMessage("V1.7.95 LADDER HOLD | " + (tag ?? string.Empty) + " | Reason: " + reason
                        + " | Stop kept, retry next tick");
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        // ---------------------------------------------------------
        //  4) OPEN BELL FLIP (LONG range + seller tape -> SHORT)
        //     06-23 oct with real ticks (OB SHADOW), LONG days (range < 61):
        //       tape >= 100 -> LONG 4/4 TP
        //       tape <  100 -> LONG 1/6 TP (5 SL) ; immediate SHORT 5/6 TP = +118.75 pts (+$237/MNQ)
        //     Same entry, SL 134t / TP 122t / ladder as the normal Open Bell, but the size is
        //     V195ObFlipSizePct of the normal Open Bell size until there are more live days.
        //     Off: V195ObFlipShortOnTapeVeto = false (then it only logs, like before).
        // ---------------------------------------------------------
        internal static bool V195ObFlipShortOnTapeVeto = true;
        internal static double V195ObFlipSizePct = 0.50;

        private bool V195ObFlipEnabled()
        {
            return V195Enabled && V195ObFlipShortOnTapeVeto;
        }

        private void V195ApplyOpenBellFlipSize(ref int requestedContracts, bool isLong, Instrument instrument)
        {
            try
            {
                if (!V195ObFlipEnabled() || isLong || instrument == null || requestedContracts <= 1)
                    return;

                double worst;
                string src;

                if (!JJBotOpenBellSharedVerdict.IsLongVetoed(instrument.FullName, GetCurrentNewYorkTime(), out worst, out src))
                    return;

                int reduced = Math.Max(1, (int)Math.Floor(requestedContracts * V195ObFlipSizePct));

                if (reduced >= requestedContracts)
                    return;

                PrintBotMessage("CORE20 OPEN BELL FLIP SIZING | Contracts " + requestedContracts + " -> " + reduced
                    + " (" + (V195ObFlipSizePct * 100).ToString("0") + "% while the flip builds live history)"
                    + " | Tape veto " + worst.ToString("0") + " by " + (src ?? string.Empty));

                requestedContracts = reduced;
            }
            catch
            {
            }
        }

        // Account side, central brain HYBRID decisions only. true = blocked (already logged).
        private bool V195HybridAccountGateBlocks(bool isLong, string decisionId)
        {
            if (!V195Enabled)
                return false;

            string reason = null;

            try
            {
                if (V195HybridWarmupEnabled && v195StartedUtc != DateTime.MinValue)
                {
                    double since = (DateTime.UtcNow - v195StartedUtc).TotalSeconds;
                    if (since < V195HybridWarmupSeconds)
                        reason = "WARM-UP AFTER START " + since.ToString("0") + "/" + V195HybridWarmupSeconds + "s (L2/tape history rebuilding)";
                }

                if (reason == null)
                {
                    string conf;
                    lock (level2Sync)
                    {
                        conf = level2Confluence ?? string.Empty;
                    }

                    bool directional =
                        conf.StartsWith("LEAN ", StringComparison.OrdinalIgnoreCase) ||
                        conf.StartsWith("STRONG ", StringComparison.OrdinalIgnoreCase);

                    bool inFavor =
                        directional &&
                        conf.EndsWith(isLong ? "LONG" : "SHORT", StringComparison.OrdinalIgnoreCase);

                    bool opposed = directional && !inFavor;

                    TimeSpan tod = GetCurrentNewYorkTime().TimeOfDay;
                    bool favorWindow = tod >= V195FavorWindowFromNy && tod < V195FavorWindowToNy;

                    if (V195BlockL2Opposed && opposed)
                        reason = "L2 OPPOSED (" + conf + ")";
                    else if (V195RequireL2InFavorWindow && favorWindow && !inFavor)
                        reason = "10:15-11:00 NEEDS L2 IN FAVOR (now " + (conf.Length > 0 ? conf : "N/A") + ")";
                }
            }
            catch
            {
                return false;
            }

            if (reason == null)
                return false;

            string key = (isLong ? "L|" : "S|") + reason.Split('(')[0] + "|" + DateTime.UtcNow.ToString("yyyyMMddHHmm");
            if (key != v195LastGateLogKey)
            {
                v195LastGateLogKey = key;
                PrintBotMessage(
                    "JJ AI CORE ACCOUNT BLOCK"
                    + " | Reason: V1.7.95 HYBRID GATE - " + reason
                    + " | Side: " + (isLong ? "LONG" : "SHORT")
                    + " | Decision: " + (decisionId ?? string.Empty));
            }

            return true;
        }
    }
}

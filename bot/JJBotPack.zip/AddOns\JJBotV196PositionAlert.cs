#region Using declarations
using System;
using System.Globalization;
using NinjaTrader.Cbi;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.96 - UNEXPECTED POSITION ALERT FOR THE APK (read only, never trades)
    //
    // 23-oct (LFE...022): the Open Bell TP filled, then the old stop filled too and
    // reopened 4 MNQ. The bot thought it was flat and nobody was told.
    // Every telemetry beat now carries the REAL account position and a flag:
    //   positionAlert = GUARDIAN_EMERGENCY  -> the GUARDIAN detected a late protective
    //                                          fill and the position is still open
    //                   UNEXPECTED_POSITION -> the account has a position the bot is not
    //                                          tracking (bot flat, other side or more
    //                                          contracts) for 3 s or more
    //                   NONE                -> all good
    // The APK shows a red alert with "Cerrar todo" (existing CLOSE_ALL command).
    // Only while the bot is running, so manual trades with the bot stopped do not alert.
    // =========================================================
    public partial class JJBotWindow
    {
        private const double V196MismatchSeconds = 3.0;
        private DateTime v196MismatchSinceUtc = DateTime.MinValue;

        private void V196GetPositionAlert(out string side, out int quantity, out string alert, out string text)
        {
            side = "FLAT";
            quantity = 0;
            alert = "NONE";
            text = string.Empty;

            try
            {
                if (v186IsDedicatedBrain || selectedAccount == null || selectedInstrument == null)
                    return;

                MarketPosition accountSide;
                int accountQty;
                double accountAvg;
                bool flat = TryGetSelectedInstrumentPosition(out accountSide, out accountQty, out accountAvg);

                if (!flat && accountQty > 0)
                {
                    side = accountSide == MarketPosition.Long ? "LONG" : "SHORT";
                    quantity = accountQty;
                }

                if (!botRunning)
                {
                    v196MismatchSinceUtc = DateTime.MinValue;
                    return;
                }

                MarketPosition trackedSide;
                int trackedQty;
                bool pending;

                lock (executionStateLock)
                {
                    trackedSide = entryMarketPosition;
                    trackedQty = Math.Max(0, entryQuantity - activeExitQuantity);
                    pending = entryPending;
                }

                bool mismatch =
                    quantity > 0 &&
                    !pending &&
                    (
                        trackedSide == MarketPosition.Flat ||
                        trackedQty <= 0 ||
                        trackedSide != accountSide ||
                        quantity > trackedQty
                    );

                DateTime nowUtc = DateTime.UtcNow;

                if (mismatch)
                {
                    if (v196MismatchSinceUtc == DateTime.MinValue)
                        v196MismatchSinceUtc = nowUtc;
                }
                else
                {
                    v196MismatchSinceUtc = DateTime.MinValue;
                }

                bool sustained =
                    mismatch &&
                    (nowUtc - v196MismatchSinceUtc).TotalSeconds >= V196MismatchSeconds;

                if (quantity > 0 && lateProtectiveFillEmergencyPending)
                    alert = "GUARDIAN_EMERGENCY";
                else if (sustained)
                    alert = "UNEXPECTED_POSITION";

                if (alert != "NONE")
                {
                    text =
                        side + " " + quantity + " " + selectedInstrument.FullName
                        + " @ " + accountAvg.ToString("0.00", CultureInfo.InvariantCulture)
                        + " | " + selectedAccount.Name
                        + (alert == "GUARDIAN_EMERGENCY"
                            ? " | GUARDIAN cerrando la posicion"
                            : " | Posicion que el bot no abrio (bot: "
                              + (trackedSide == MarketPosition.Flat ? "FLAT" : trackedSide.ToString().ToUpperInvariant() + " " + trackedQty)
                              + ")");
                }
            }
            catch
            {
                alert = "NONE";
                text = string.Empty;
            }
        }
    }
}

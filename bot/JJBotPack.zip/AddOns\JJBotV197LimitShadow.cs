#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.97 - HYBRID LIMIT-ON-RETRACE SHADOW (LOG + CSV ONLY, never sends orders)
    //
    // 24-oct: 3,123 HYBRID candidates (19-23 oct) showed that entering EARLIER is worse
    // (EARLY 46% / -5.6 t at 60 s) and only CONFIRMED RETEST was positive. Question:
    // after a real HYBRID market entry, would a LIMIT order a bit behind price have
    // filled, and would it have made more?
    //
    // For every real HYBRID entry it opens 5 virtual entries with the SAME stop / target
    // distance (ticks) as the real trade:
    //   MKT  : the real market fill price (reference)
    //   L4/L8/L12 : limit 4 / 8 / 12 ticks behind the market fill
    //   WALL : limit 1 tick in front of the nearest resting-volume wall behind price
    //          (LONG: bids below, SHORT: asks above; wall = volume >= max(20, 3x median)
    //          within 20 ticks - same wall rule as the L2 trade recorder)
    // A limit counts as filled only if price trades 1 tick THROUGH it (queue-safe) within
    // 120 s. Filled legs exit on TP / SL (+1 tick stop slippage) or at market after 30 min.
    // The real trade's ladder / partials are NOT simulated: compare MKT vs limits.
    // One row per real entry in JJBotData\Learning\hybrid_limit_shadow.csv.
    // Turn off: V197LimitShadowEnabled = false.
    // =========================================================
    internal sealed class JJHybridLimitShadow
    {
        internal const int FillWindowSec = 120;
        internal const int MaxHoldSec = 1800;

        private sealed class Leg
        {
            public string Name;
            public double Limit;
            public bool IsMarket;
            public bool Filled;
            public double Fill;
            public double FillSec;
            public bool Done;
            public string How = "MISS";
            public double Ticks;
            public double Mfe;
            public double Mae;
        }

        private sealed class Rec
        {
            public string Id;
            public DateTime EntryNy;
            public DateTime StartTime;
            public int Side;
            public double MarketEntry;
            public int SlTicks;
            public int TpTicks;
            public double Tick;
            public double WallTicks;
            public double WallVol;
            public string Tape;
            public List<Leg> Legs = new List<Leg>();
        }

        private readonly object sync = new object();
        private readonly List<Rec> open = new List<Rec>();

        public Action<string> Log;
        public Func<string> RootFolder;

        private static string F(double v)
        {
            return v.ToString("0.00", CultureInfo.InvariantCulture);
        }

        public void Start(DateTime entryNy, DateTime marketTime, bool isLong, double marketEntry,
            int slTicks, int tpTicks, double tick, double wallTicks, double wallVol, string tape)
        {
            if (tick <= 0 || slTicks <= 0 || tpTicks <= 0 || marketEntry <= 0)
                return;

            int side = isLong ? 1 : -1;
            Rec r = new Rec
            {
                Id = entryNy.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + "_" + (isLong ? "L" : "S"),
                EntryNy = entryNy,
                StartTime = marketTime,
                Side = side,
                MarketEntry = marketEntry,
                SlTicks = slTicks,
                TpTicks = tpTicks,
                Tick = tick,
                WallTicks = wallTicks,
                WallVol = wallVol,
                Tape = tape ?? string.Empty
            };

            r.Legs.Add(new Leg { Name = "MKT", IsMarket = true, Limit = marketEntry, Filled = true, Fill = marketEntry });
            foreach (int off in new[] { 4, 8, 12 })
                r.Legs.Add(new Leg { Name = "L" + off, Limit = marketEntry - side * off * tick });

            if (wallTicks > 0)
                r.Legs.Add(new Leg { Name = "WALL", Limit = marketEntry - side * (wallTicks - 1) * tick });
            else
                r.Legs.Add(new Leg { Name = "WALL", Done = true, How = "NOWALL" });

            lock (sync)
            {
                open.Add(r);
            }

            Write("START | " + r.Id + " | " + (isLong ? "LONG" : "SHORT") + " @ " + F(marketEntry)
                + " | SL " + slTicks + "t / TP " + tpTicks + "t"
                + " | Wall " + (wallTicks > 0 ? wallTicks.ToString("0") + "t (" + wallVol.ToString("0") + ")" : "none")
                + " | Tape " + r.Tape);
        }

        public void OnTick(DateTime marketTime, double price)
        {
            List<Rec> finished = null;

            lock (sync)
            {
                if (open.Count == 0)
                    return;

                foreach (Rec r in open)
                {
                    double sec = (marketTime - r.StartTime).TotalSeconds;
                    bool allDone = true;

                    foreach (Leg l in r.Legs)
                    {
                        if (l.Done)
                            continue;

                        if (!l.Filled)
                        {
                            bool through = r.Side > 0 ? price <= l.Limit - r.Tick : price >= l.Limit + r.Tick;
                            if (through && sec <= FillWindowSec)
                            {
                                l.Filled = true;
                                l.Fill = l.Limit;
                                l.FillSec = Math.Max(0, sec);
                            }
                            else if (sec > FillWindowSec)
                            {
                                l.Done = true;
                                l.How = "MISS";
                                continue;
                            }
                            else
                            {
                                allDone = false;
                                continue;
                            }
                        }

                        double move = (price - l.Fill) * r.Side / r.Tick;
                        if (move > l.Mfe) l.Mfe = move;
                        if (move < l.Mae) l.Mae = move;

                        if (move <= -r.SlTicks)
                        {
                            l.Done = true; l.How = "SL"; l.Ticks = -r.SlTicks - 1;
                        }
                        else if (move >= r.TpTicks)
                        {
                            l.Done = true; l.How = "TP"; l.Ticks = r.TpTicks;
                        }
                        else if (sec - l.FillSec >= MaxHoldSec)
                        {
                            l.Done = true; l.How = "TIME"; l.Ticks = move;
                        }
                        else
                        {
                            allDone = false;
                        }
                    }

                    if (allDone)
                    {
                        if (finished == null) finished = new List<Rec>();
                        finished.Add(r);
                    }
                }

                if (finished != null)
                    foreach (Rec r in finished)
                        open.Remove(r);
            }

            if (finished != null)
                foreach (Rec r in finished)
                    Finish(r);
        }

        private void Finish(Rec r)
        {
            StringBuilder msg = new StringBuilder("DONE | " + r.Id);
            foreach (Leg l in r.Legs)
                msg.Append(" | " + l.Name + " " + l.How + (l.Filled ? " " + l.Ticks.ToString("0") + "t" : string.Empty));
            Write(msg.ToString());

            try
            {
                Func<string> rootFn = RootFolder;
                string root = rootFn != null ? rootFn() : null;

                if (string.IsNullOrWhiteSpace(root))
                    root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData");

                string folder = Path.Combine(root, "Learning");
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, "hybrid_limit_shadow.csv");
                bool exists = File.Exists(path);

                using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
                {
                    if (!exists)
                    {
                        StringBuilder h = new StringBuilder("Id,Date,EntryNy,Side,MarketEntry,SlTicks,TpTicks,WallTicks,WallVol,Tape");
                        foreach (Leg l in r.Legs)
                            h.Append("," + l.Name + "Result," + l.Name + "Ticks," + l.Name + "FillSec," + l.Name + "Mfe," + l.Name + "Mae");
                        sw.WriteLine(h.ToString());
                    }

                    StringBuilder line = new StringBuilder();
                    line.Append(r.Id);
                    line.Append("," + r.EntryNy.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                    line.Append("," + r.EntryNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture));
                    line.Append("," + (r.Side > 0 ? "LONG" : "SHORT"));
                    line.Append("," + F(r.MarketEntry) + "," + r.SlTicks + "," + r.TpTicks);
                    line.Append("," + r.WallTicks.ToString("0", CultureInfo.InvariantCulture) + "," + r.WallVol.ToString("0", CultureInfo.InvariantCulture));
                    line.Append("," + r.Tape.Replace(',', ' '));
                    foreach (Leg l in r.Legs)
                        line.Append("," + l.How + "," + l.Ticks.ToString("0", CultureInfo.InvariantCulture)
                            + "," + l.FillSec.ToString("0", CultureInfo.InvariantCulture)
                            + "," + l.Mfe.ToString("0", CultureInfo.InvariantCulture)
                            + "," + l.Mae.ToString("0", CultureInfo.InvariantCulture));
                    sw.WriteLine(line.ToString());
                }
            }
            catch (Exception ex)
            {
                Write("CSV ERROR | " + ex.Message);
            }
        }

        private void Write(string message)
        {
            Action<string> log = Log;
            if (log != null)
                log("HYBRID LIMIT SHADOW | " + message);
        }
    }

    public partial class JJBotWindow
    {
        internal static bool V197LimitShadowEnabled = true;
        private const int V197WallSearchTicks = 20;

        private readonly JJHybridLimitShadow v197LimitShadow = new JJHybridLimitShadow();

        // Called on every real entry fill. Only HYBRID entries (no CORE20 module active) are shadowed.
        private void V197LimitShadowOnEntry(bool isLong, double entryPrice, bool manualTest)
        {
            try
            {
                if (!V197LimitShadowEnabled || manualTest)
                    return;

                if (core20ObTradeActive || core20GdTradeActive || core20PmTradeActive || core20AmTradeActive)
                    return;

                if (v197LimitShadow.Log == null)
                    v197LimitShadow.Log = delegate (string m) { PrintBotMessage(m); };

                if (v197LimitShadow.RootFolder == null)
                    v197LimitShadow.RootFolder = delegate { return stateFolderPath; };

                double tick = (selectedInstrument != null && selectedInstrument.MasterInstrument != null)
                    ? selectedInstrument.MasterInstrument.TickSize : 0.25;

                double wallTicks = 0;
                double wallVol = 0;
                string tape;
                DateTime marketTime;

                lock (level2Sync)
                {
                    tape = level2TapeBias ?? string.Empty;
                    marketTime = v197LastTickTime != DateTime.MinValue ? v197LastTickTime : DateTime.Now;

                    // Rows BEHIND price: bids under a LONG, asks over a SHORT.
                    List<JJLevel2Row> behind = new List<JJLevel2Row>(isLong ? level2BidRows : level2AskRows);

                    if (behind.Count > 0)
                    {
                        List<long> vols = behind.Select(x => x.Volume).OrderBy(v => v).ToList();
                        double threshold = Math.Max(20.0, 3.0 * vols[vols.Count / 2]);
                        double best = double.MaxValue;

                        foreach (JJLevel2Row row in behind)
                        {
                            double dist = isLong ? (entryPrice - row.Price) / tick : (row.Price - entryPrice) / tick;

                            if (dist < 2 || dist > V197WallSearchTicks || row.Volume < threshold)
                                continue;

                            if (dist < best)
                            {
                                best = dist;
                                wallTicks = Math.Round(dist);
                                wallVol = row.Volume;
                            }
                        }
                    }
                }

                v197LimitShadow.Start(GetCurrentNewYorkTime(), marketTime, isLong, entryPrice,
                    activeStopTicks, activeTargetTicks, tick, wallTicks, wallVol, tape);
            }
            catch
            {
            }
        }

        private DateTime v197LastTickTime = DateTime.MinValue;

        // Called from the L2 market-data handler with every accepted Last tick.
        private void V197LimitShadowOnTick(DateTime marketTime, double price)
        {
            try
            {
                v197LastTickTime = marketTime;

                if (V197LimitShadowEnabled)
                    v197LimitShadow.OnTick(marketTime, price);
            }
            catch
            {
            }
        }
    }
}

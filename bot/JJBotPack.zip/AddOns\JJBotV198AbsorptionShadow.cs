#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.98 - HVN ABSORPTION SHADOW (LOG + CSV ONLY, never sends orders)
    //
    // Idea (Orderflow Sniper video, 24-oct): price drops into a High Volume Node (HVN)
    // of the session volume profile, sellers hit the bid hard but price stops falling
    // (a big passive buyer absorbs them) -> LONG. Mirror for SHORT at an HVN above.
    //
    // This shadow records EVERY test of an HVN (price arriving at the node after a leg
    // of >= LegTicks) with the absorption measures, then follows a virtual trade:
    //   entry = 1 tick worse than the last trade, SL = AbsStopBeyondTicks behind the HVN,
    //   TP = 80 ticks (20 pts), exit at market after 30 min.
    // "Signal" = the test also passed the absorption rule below. The CSV keeps the
    // non-signals too, so the thresholds can be tuned later with real data.
    //
    // Absorption rule (last AbsWindowSec seconds, LONG; SHORT is the mirror):
    //   - aggressive SELL volume >= AbsAggMult x the session's median volume per window
    //   - aggressive SELL >= 60% of the aggressive volume in the window
    //   - price did not extend more than AbsMaxExtendTicks below the window's first low
    //   - the last trade is >= 1 tick above the window low (it is holding)
    // Bid refill (best-bid size now vs window start) is recorded, not required.
    //
    // Volume profile: from 18:00 NY (Globex session), at tick resolution, smoothed +-4 ticks.
    // HVN = local maximum >= 1.5x the mean smoothed volume, nodes >= 20 ticks apart (top 8).
    // Records only 09:30-15:55 NY. One test per HVN per side every 5 minutes.
    // File: JJBotData\Learning\hybrid_absorption_shadow.csv   Log: "HVN ABSORPTION SHADOW | ..."
    // Turn off: V198AbsorptionShadowEnabled = false (this file).
    // =========================================================
    internal sealed class JJHvnAbsorptionShadow
    {
        internal const int AbsWindowSec = 20;
        internal const double AbsAggMult = 3.0;
        internal const int AbsMaxExtendTicks = 2;
        internal const int TouchTicks = 4;           // price within 4 ticks of the HVN = test
        internal const int LegTicks = 30;            // it must arrive after a 30-tick leg (last 10 min)
        internal const int AbsStopBeyondTicks = 12;  // SL 12 ticks behind the HVN
        internal const int TpTicks = 80;             // 20 points
        internal const int MaxHoldSec = 1800;
        internal const int CooldownSec = 300;
        internal const int SmoothTicks = 4;
        internal const double HvnMult = 1.5;
        internal const int HvnMinGapTicks = 20;
        internal const int HvnMax = 8;

        private sealed class Trade
        {
            public DateTime Time;
            public double Price;
            public double Volume;
            public int Aggressor;   // +1 buy at ask, -1 sell at bid, 0 unknown
        }

        private sealed class Virt
        {
            public string Id;
            public DateTime StartTime;
            public DateTime EntryNy;
            public int Side;
            public double Entry;
            public double Hvn;
            public double HvnRatio;
            public int SlTicks;
            public bool Signal;
            public double AggVol;
            public double AggRatio;
            public double AggShare;
            public double ExtendTicks;
            public double HoldTicks;
            public double BidRefill;
            public string Tape;
            public string Confluence;
            public double Mfe;
            public double Mae;
            public bool Hit40;
            public string How = "OPEN";
            public double Ticks;
            public double ExitSec;
        }

        private readonly object sync = new object();
        private readonly Dictionary<long, double> profile = new Dictionary<long, double>();
        private readonly LinkedList<Trade> window = new LinkedList<Trade>();
        private readonly LinkedList<Trade> legWindow = new LinkedList<Trade>();
        private readonly List<double> windowVolumes = new List<double>();
        // V1.7.103 - caches (were recomputed on every trade near an HVN)
        private double v1103Median;
        private bool v1103MedianDirty = true;
        private double v1103LegHigh, v1103LegLow;
        private DateTime v1103LegCalcTime = DateTime.MinValue;
        private readonly List<Virt> open = new List<Virt>();
        private readonly Dictionary<string, DateTime> lastTest = new Dictionary<string, DateTime>();
        private List<double> hvns = new List<double>();
        private List<double> hvnRatios = new List<double>();
        private DateTime sessionStartNy = DateTime.MinValue;
        private DateTime lastHvnCalc = DateTime.MinValue;
        private DateTime bucketStart = DateTime.MinValue;
        private double bucketVol;
        private double windowStartBestBidVol = -1;
        private double windowStartBestAskVol = -1;

        public Action<string> Log;
        public Func<string> RootFolder;

        private static string F(double v)
        {
            return v.ToString("0.00", CultureInfo.InvariantCulture);
        }

        private static string I(double v)
        {
            return v.ToString("0", CultureInfo.InvariantCulture);
        }

        private static DateTime SessionStart(DateTime ny)
        {
            DateTime s = ny.Date.AddHours(18);
            return ny >= s ? s : s.AddDays(-1);
        }

        // Called for every accepted Last trade (L2 leader only), already inside level2Sync.
        public void OnTrade(DateTime marketTime, DateTime ny, double price, double volume, double bid, double ask,
            double tick, double bestBidVol, double bestAskVol, string tape, string confluence)
        {
            if (tick <= 0 || price <= 0)
                return;

            List<Virt> finished = null;

            lock (sync)
            {
                // ---- new Globex session: reset the profile
                DateTime ss = SessionStart(ny);
                if (ss != sessionStartNy)
                {
                    sessionStartNy = ss;
                    profile.Clear();
                    hvns = new List<double>();
                    hvnRatios = new List<double>();
                    windowVolumes.Clear();
                    v1103MedianDirty = true;
                    v1103LegCalcTime = DateTime.MinValue;
                    lastTest.Clear();
                }

                long key = (long)Math.Round(price / tick);
                double cur;
                profile.TryGetValue(key, out cur);
                profile[key] = cur + volume;

                // ---- aggressor (same rule as the L2 engine)
                double eps = tick * 0.25;
                int aggr = 0;
                if (ask > 0 && price >= ask - eps) aggr = 1;
                else if (bid > 0 && price <= bid + eps) aggr = -1;
                else if (bid > 0 && ask > 0)
                {
                    double db = Math.Abs(price - bid), da = Math.Abs(ask - price);
                    aggr = da < db ? 1 : (db < da ? -1 : 0);
                }

                Trade t = new Trade { Time = marketTime, Price = price, Volume = volume, Aggressor = aggr };
                window.AddLast(t);
                legWindow.AddLast(t);
                while (window.Count > 0 && (marketTime - window.First.Value.Time).TotalSeconds > AbsWindowSec)
                    window.RemoveFirst();
                while (legWindow.Count > 0 && (marketTime - legWindow.First.Value.Time).TotalSeconds > 600)
                    legWindow.RemoveFirst();

                // ---- median volume per window (fixed buckets of AbsWindowSec)
                if (bucketStart == DateTime.MinValue)
                {
                    bucketStart = marketTime;
                    windowStartBestBidVol = bestBidVol;
                    windowStartBestAskVol = bestAskVol;
                }
                if ((marketTime - bucketStart).TotalSeconds >= AbsWindowSec)
                {
                    windowVolumes.Add(bucketVol);
                    if (windowVolumes.Count > 540) windowVolumes.RemoveAt(0); // ~3 h
                    v1103MedianDirty = true;
                    bucketVol = 0;
                    bucketStart = marketTime;
                    windowStartBestBidVol = bestBidVol;
                    windowStartBestAskVol = bestAskVol;
                }
                bucketVol += volume;

                // ---- HVNs every 60 s
                if ((marketTime - lastHvnCalc).TotalSeconds >= 60)
                {
                    lastHvnCalc = marketTime;
                    RecalcHvns(tick);
                }

                // ---- follow open virtual trades
                foreach (Virt v in open)
                {
                    double sec = (marketTime - v.StartTime).TotalSeconds;
                    double move = (price - v.Entry) * v.Side / tick;
                    if (move > v.Mfe) v.Mfe = move;
                    if (move < v.Mae) v.Mae = move;
                    if (move >= 40) v.Hit40 = true;

                    if (move <= -v.SlTicks) { v.How = "SL"; v.Ticks = -v.SlTicks - 1; }
                    else if (move >= TpTicks) { v.How = "TP"; v.Ticks = TpTicks; }
                    else if (sec >= MaxHoldSec) { v.How = "TIME"; v.Ticks = move; }
                    else continue;

                    v.ExitSec = sec;
                    if (finished == null) finished = new List<Virt>();
                    finished.Add(v);
                }
                if (finished != null)
                    foreach (Virt v in finished)
                        open.Remove(v);

                // ---- tests of an HVN
                TimeSpan tod = ny.TimeOfDay;
                if (tod >= new TimeSpan(9, 30, 0) && tod < new TimeSpan(15, 55, 0) && hvns.Count > 0 && window.Count > 0)
                {
                    for (int i = 0; i < hvns.Count; i++)
                    {
                        double h = hvns[i];
                        if (Math.Abs(price - h) / tick > TouchTicks)
                            continue;

                        // V1.7.103 - the 10-minute leg high/low: at most once per second
                        if (v1103LegCalcTime == DateTime.MinValue || (marketTime - v1103LegCalcTime).TotalSeconds >= 1.0
                            || price > v1103LegHigh || price < v1103LegLow)
                        {
                            v1103LegHigh = legWindow.Max(x => x.Price);
                            v1103LegLow = legWindow.Min(x => x.Price);
                            v1103LegCalcTime = marketTime;
                        }
                        double legHigh = v1103LegHigh;
                        double legLow = v1103LegLow;
                        int side = 0;
                        if ((legHigh - h) / tick >= LegTicks && price <= legHigh) side = 1;      // came down into it: support
                        else if ((h - legLow) / tick >= LegTicks && price >= legLow) side = -1; // came up into it: resistance
                        if (side == 0)
                            continue;

                        // TEST = first touch (baseline "just trade the HVN"); SIGNAL = absorption seen while
                        // price is still at the node. Each has its own 5-minute cooldown per node and side.
                        string k = I(h / tick) + (side > 0 ? "L" : "S");
                        Virt v = Evaluate(marketTime, ny, side, price, h, hvnRatios[i], tick, bestBidVol, bestAskVol, tape, confluence);
                        string kind = v.Signal ? k + "|SIG" : k + "|TEST";
                        DateTime last;
                        if (lastTest.TryGetValue(kind, out last) && (marketTime - last).TotalSeconds < CooldownSec)
                            continue;
                        lastTest[kind] = marketTime;
                        open.Add(v);
                        Write((v.Signal ? "SIGNAL" : "TEST") + " | " + v.Id + " | " + (side > 0 ? "LONG" : "SHORT")
                            + " @ " + F(v.Entry) + " | HVN " + F(h) + " (x" + F(v.HvnRatio) + ")"
                            + " | Agg " + I(v.AggVol) + " (x" + F(v.AggRatio) + ", " + I(v.AggShare * 100) + "%)"
                            + " | Hold " + I(v.HoldTicks) + "t ext " + I(v.ExtendTicks) + "t | SL " + v.SlTicks + "t TP " + TpTicks + "t");
                        break;
                    }
                }
            }

            if (finished != null)
            {
                List<Virt> done = finished;
                System.Threading.ThreadPool.QueueUserWorkItem(delegate
                {
                    lock (csvSync)
                    {
                        foreach (Virt v in done)
                            Finish(v);
                    }
                });
            }
        }

        private static readonly object csvSync = new object();

        private Virt Evaluate(DateTime marketTime, DateTime ny, int side, double price, double h, double ratio, double tick,
            double bestBidVol, double bestAskVol, string tape, string confluence)
        {
            double buy = 0, sell = 0;
            foreach (Trade t in window)
            {
                if (t.Aggressor > 0) buy += t.Volume;
                else if (t.Aggressor < 0) sell += t.Volume;
            }

            double against = side > 0 ? sell : buy;      // the side being absorbed
            double total = buy + sell;
            double median = 0;
            if (windowVolumes.Count >= 15)
            {
                if (v1103MedianDirty)
                {
                    List<double> s = windowVolumes.OrderBy(x => x).ToList();
                    v1103Median = s[s.Count / 2];
                    v1103MedianDirty = false;
                }
                median = v1103Median;
            }

            Trade first = window.First.Value;
            double winLow = window.Min(x => x.Price), winHigh = window.Max(x => x.Price);
            double extend = side > 0 ? (first.Price - winLow) / tick : (winHigh - first.Price) / tick;
            double hold = side > 0 ? (price - winLow) / tick : (winHigh - price) / tick;
            double startVol = side > 0 ? windowStartBestBidVol : windowStartBestAskVol;
            double nowVol = side > 0 ? bestBidVol : bestAskVol;

            Virt v = new Virt();
            v.Side = side;
            v.StartTime = marketTime;
            v.EntryNy = ny;
            v.Entry = price + side * tick;               // 1 tick worse
            v.Hvn = h;
            v.HvnRatio = ratio;
            double stopPrice = h - side * AbsStopBeyondTicks * tick;
            v.SlTicks = (int)Math.Max(8, Math.Round((v.Entry - stopPrice) * side / tick));
            v.AggVol = against;
            v.AggRatio = median > 0 ? against / median : 0;
            v.AggShare = total > 0 ? against / total : 0;
            v.ExtendTicks = Math.Max(0, extend);
            v.HoldTicks = Math.Max(0, hold);
            v.BidRefill = startVol > 0 && nowVol >= 0 ? nowVol / startVol : 0;
            v.Tape = tape ?? string.Empty;
            v.Confluence = confluence ?? string.Empty;
            v.Signal = median > 0 && v.AggRatio >= AbsAggMult && v.AggShare >= 0.60
                && v.ExtendTicks <= AbsMaxExtendTicks && v.HoldTicks >= 1;
            v.Id = ny.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + "_" + (side > 0 ? "L" : "S") + (v.Signal ? "_SIG" : "_TEST");
            return v;
        }

        private void RecalcHvns(double tick)
        {
            List<double> found = new List<double>();
            List<double> ratios = new List<double>();
            if (profile.Count < 20)
            {
                hvns = found; hvnRatios = ratios;
                return;
            }

            long lo = profile.Keys.Min(), hi = profile.Keys.Max();
            int n = (int)(hi - lo + 1);
            if (n <= 0 || n > 20000)
                return;

            double[] raw = new double[n];
            foreach (KeyValuePair<long, double> kv in profile)
                raw[kv.Key - lo] = kv.Value;

            double[] sm = new double[n];
            for (int i = 0; i < n; i++)
            {
                double s = 0;
                for (int j = Math.Max(0, i - SmoothTicks); j <= Math.Min(n - 1, i + SmoothTicks); j++)
                    s += raw[j];
                sm[i] = s;
            }

            double mean = sm.Where(x => x > 0).DefaultIfEmpty(0).Average();
            if (mean <= 0)
                return;

            List<int> peaks = new List<int>();
            for (int i = 1; i < n - 1; i++)
                if (sm[i] >= sm[i - 1] && sm[i] > sm[i + 1] && sm[i] >= HvnMult * mean)
                    peaks.Add(i);

            foreach (int p in peaks.OrderByDescending(i => sm[i]))
            {
                if (found.Count >= HvnMax)
                    break;
                double price = (lo + p) * tick;
                if (found.Any(x => Math.Abs(x - price) / tick < HvnMinGapTicks))
                    continue;
                found.Add(price);
                ratios.Add(sm[p] / mean);
            }

            hvns = found;
            hvnRatios = ratios;
        }

        private void Finish(Virt v)
        {
            Write("DONE | " + v.Id + " | " + (v.Signal ? "SIGNAL" : "TEST") + " | " + v.How + " " + I(v.Ticks) + "t"
                + " | MFE " + I(v.Mfe) + "t MAE " + I(v.Mae) + "t");
            try
            {
                Func<string> rootFn = RootFolder;
                string root = rootFn != null ? rootFn() : null;
                if (string.IsNullOrWhiteSpace(root))
                    root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData");

                string folder = Path.Combine(root, "Learning");
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, "hybrid_absorption_shadow.csv");
                bool exists = File.Exists(path);

                using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
                {
                    if (!exists)
                        sw.WriteLine("Id,Date,TimeNy,Side,Signal,Entry,Hvn,HvnRatio,SlTicks,TpTicks,AggVol,AggRatio,AggShare,"
                            + "ExtendTicks,HoldTicks,Refill,Tape,Confluence,Result,Ticks,Mfe,Mae,Hit40,ExitSec");

                    sw.WriteLine(string.Join(",", new[]
                    {
                        v.Id,
                        v.EntryNy.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        v.EntryNy.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                        v.Side > 0 ? "LONG" : "SHORT",
                        v.Signal ? "1" : "0",
                        F(v.Entry), F(v.Hvn), F(v.HvnRatio),
                        v.SlTicks.ToString(CultureInfo.InvariantCulture), TpTicks.ToString(CultureInfo.InvariantCulture),
                        I(v.AggVol), F(v.AggRatio), F(v.AggShare), I(v.ExtendTicks), I(v.HoldTicks), F(v.BidRefill),
                        v.Tape.Replace(',', ' '), v.Confluence.Replace(',', ' '),
                        v.How, I(v.Ticks), I(v.Mfe), I(v.Mae), v.Hit40 ? "1" : "0", I(v.ExitSec)
                    }));
                }
            }
            catch (Exception ex)
            {
                Write("CSV ERROR | " + ex.Message);
            }
        }

        // The caller holds level2Sync: log on the thread pool so the UI is never waited on from here.
        private void Write(string message)
        {
            Action<string> log = Log;
            if (log == null)
                return;
            string m = "HVN ABSORPTION SHADOW | " + message;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate { try { log(m); } catch { } });
        }
    }

    public partial class JJBotWindow
    {
        internal static bool V198AbsorptionShadowEnabled = true;

        private readonly JJHvnAbsorptionShadow v198Absorption = new JJHvnAbsorptionShadow();

        // Called from OnLevel2MarketDataUpdate for every accepted Last trade, L2 leader only,
        // while level2Sync is held. Never throws, never touches orders.
        // V1.7.103 - called by the shadow worker thread (JJBotV1103ShadowWorker.cs), never on the market thread
        private void V1103ShadowProcess(DateTime marketTime, double price, double volume, double bid, double ask, double tick,
            double bestBidVol, double bestAskVol, string tapeBias, string confluence)
        {
            // V1.7.105 - "follow the big fish" shadow (JJBotV1105BigFish.cs), log only
            V1105BigFishOnTrade(marketTime, price, tick);

            // V1.7.99 - the delta-trigger shadow uses the same leader tape (JJBotV199DeltaShadow.cs)
            V199DeltaOnTrade(marketTime, price, volume, bid, ask, tick);

            try
            {
                if (!V198AbsorptionShadowEnabled)
                    return;

                if (v198Absorption.Log == null)
                    v198Absorption.Log = delegate (string m) { PrintBotMessage(m); };

                if (v198Absorption.RootFolder == null)
                    v198Absorption.RootFolder = delegate { return stateFolderPath; };

                v198Absorption.OnTrade(marketTime, ConvertToNewYorkTime(marketTime), price, volume, bid, ask,
                    tick > 0 ? tick : 0.25, bestBidVol, bestAskVol, tapeBias, confluence);
            }
            catch
            {
            }
        }
    }
}

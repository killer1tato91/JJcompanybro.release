#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // V1.7.99 - DELTA TRIGGER SHADOW (LOG + CSV ONLY, never sends orders)
    //
    // Question (25-oct): would a DELTA trigger give HYBRID a better entry time than the R20 bar?
    // Caution from V1.7.97: on 3,123 HYBRID candidates entering EARLIER was worse
    // (EARLY 46% / -5.6 t at 60 s). This shadow measures it before anything changes.
    //
    // 1) DELTA SIGNAL (L2 leader tape, 09:30-15:55 NY):
    //      delta of the last DeltaWindowSec seconds >= DeltaMult x the session median |delta|
    //      per window (and >= DeltaMinAbs), with >= 65% of the aggressive volume on that side.
    //      One signal per side every CooldownSec. Each signal follows a virtual trade:
    //      entry 1 tick worse, SL 100 t, TP 80 t (20 pts), market exit after 30 min.
    //      -> JJBotData\Learning\hybrid_delta_shadow.csv
    // 2) REAL HYBRID ENTRY vs DELTA: on every real HYBRID entry, the last same-side delta
    //      signal of the previous 10 minutes: seconds earlier and price difference
    //      (+ = the delta entry was better).
    //      -> JJBotData\Learning\hybrid_delta_vs_real.csv
    // Turn off: V199DeltaShadowEnabled = false (this file).
    // =========================================================
    internal sealed class JJDeltaShadow
    {
        internal const int DeltaWindowSec = 10;
        internal const double DeltaMult = 3.0;
        internal const double DeltaMinAbs = 40;
        internal const double SideShare = 0.65;
        internal const int CooldownSec = 60;
        internal const int SlTicks = 100;
        internal const int TpTicks = 80;
        internal const int MaxHoldSec = 1800;
        internal const int LinkWindowSec = 600;

        private static readonly Dictionary<string, JJDeltaShadow> byInstrument = new Dictionary<string, JJDeltaShadow>();
        private static readonly object staticSync = new object();
        private static readonly object csvSync = new object();

        internal static JJDeltaShadow For(string instrument)
        {
            lock (staticSync)
            {
                JJDeltaShadow s;
                if (!byInstrument.TryGetValue(instrument ?? string.Empty, out s))
                {
                    s = new JJDeltaShadow();
                    byInstrument[instrument ?? string.Empty] = s;
                }
                return s;
            }
        }

        private sealed class Tr
        {
            public DateTime Time;
            public double Vol;
            public int Aggr;
        }

        private sealed class Sig
        {
            public string Id;
            public DateTime Time;
            public DateTime Ny;
            public int Side;
            public double Entry;
            public double Delta;
            public double Ratio;
            public double Share;
            public double Tick;
            public double Mfe, Mae;
            public bool Hit40;
            public string How = "OPEN";
            public double Ticks;
            public double ExitSec;
            public bool Done;
        }

        private readonly object sync = new object();
        private readonly LinkedList<Tr> window = new LinkedList<Tr>();
        private readonly List<double> absDeltas = new List<double>();
        // V1.7.103 - median cached; recomputed only when absDeltas changes (was a sort on EVERY trade)
        private double v1103CachedMedian = 1;
        private bool v1103MedianDirty = true;
        private readonly List<Sig> open = new List<Sig>();
        private readonly List<Sig> recent = new List<Sig>();
        private DateTime bucketStart = DateTime.MinValue;
        private double bucketDelta;
        private DateTime lastLong = DateTime.MinValue, lastShort = DateTime.MinValue;
        private DateTime lastMarketTime = DateTime.MinValue;

        public Action<string> Log;
        public Func<string> RootFolder;

        private static string F(double v) { return v.ToString("0.00", CultureInfo.InvariantCulture); }
        private static string I(double v) { return v.ToString("0", CultureInfo.InvariantCulture); }

        // L2 leader only, inside level2Sync.
        public void OnTrade(DateTime marketTime, DateTime ny, double price, double volume, double bid, double ask, double tick)
        {
            if (tick <= 0 || price <= 0)
                return;

            List<Sig> finished = null;
            lock (sync)
            {
                lastMarketTime = marketTime;
                double eps = tick * 0.25;
                int aggr = 0;
                if (ask > 0 && price >= ask - eps) aggr = 1;
                else if (bid > 0 && price <= bid + eps) aggr = -1;

                window.AddLast(new Tr { Time = marketTime, Vol = volume, Aggr = aggr });
                while (window.Count > 0 && (marketTime - window.First.Value.Time).TotalSeconds > DeltaWindowSec)
                    window.RemoveFirst();

                if (bucketStart == DateTime.MinValue) bucketStart = marketTime;
                if ((marketTime - bucketStart).TotalSeconds >= DeltaWindowSec)
                {
                    absDeltas.Add(Math.Abs(bucketDelta));
                    if (absDeltas.Count > 1080) absDeltas.RemoveAt(0);   // ~3 h
                    v1103MedianDirty = true;
                    bucketDelta = 0;
                    bucketStart = marketTime;
                }
                bucketDelta += aggr * volume;

                // follow virtual trades
                foreach (Sig s in open)
                {
                    double sec = (marketTime - s.Time).TotalSeconds;
                    double move = (price - s.Entry) * s.Side / tick;
                    if (move > s.Mfe) s.Mfe = move;
                    if (move < s.Mae) s.Mae = move;
                    if (move >= 40) s.Hit40 = true;
                    if (move <= -SlTicks) { s.How = "SL"; s.Ticks = -SlTicks - 1; }
                    else if (move >= TpTicks) { s.How = "TP"; s.Ticks = TpTicks; }
                    else if (sec >= MaxHoldSec) { s.How = "TIME"; s.Ticks = move; }
                    else continue;
                    s.ExitSec = sec;
                    s.Done = true;
                    if (finished == null) finished = new List<Sig>();
                    finished.Add(s);
                }
                if (finished != null)
                    foreach (Sig s in finished) open.Remove(s);
                recent.RemoveAll(x => (marketTime - x.Time).TotalSeconds > LinkWindowSec + 60);

                // new signal?
                TimeSpan tod = ny.TimeOfDay;
                if (tod >= new TimeSpan(9, 30, 0) && tod < new TimeSpan(15, 55, 0) && absDeltas.Count >= 30)
                {
                    double buy = 0, sell = 0;
                    foreach (Tr t in window)
                    {
                        if (t.Aggr > 0) buy += t.Vol;
                        else if (t.Aggr < 0) sell += t.Vol;
                    }
                    double delta = buy - sell, tot = buy + sell;
                    if (v1103MedianDirty)
                    {
                        List<double> sorted = absDeltas.OrderBy(x => x).ToList();
                        v1103CachedMedian = Math.Max(1, sorted[sorted.Count / 2]);
                        v1103MedianDirty = false;
                    }
                    double median = v1103CachedMedian;
                    double need = Math.Max(DeltaMinAbs, DeltaMult * median);
                    int side = 0;
                    if (delta >= need && tot > 0 && buy / tot >= SideShare && (marketTime - lastLong).TotalSeconds >= CooldownSec) side = 1;
                    else if (-delta >= need && tot > 0 && sell / tot >= SideShare && (marketTime - lastShort).TotalSeconds >= CooldownSec) side = -1;

                    if (side != 0)
                    {
                        if (side > 0) lastLong = marketTime; else lastShort = marketTime;
                        Sig s = new Sig
                        {
                            Time = marketTime, Ny = ny, Side = side, Entry = price + side * tick, Delta = delta,
                            Ratio = Math.Abs(delta) / median, Share = side > 0 ? buy / tot : sell / tot, Tick = tick,
                            Id = ny.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + (side > 0 ? "_L" : "_S")
                        };
                        open.Add(s);
                        recent.Add(s);
                        Write("SIGNAL | " + s.Id + " | " + (side > 0 ? "LONG" : "SHORT") + " @ " + F(s.Entry)
                            + " | Delta " + I(delta) + " in " + DeltaWindowSec + "s (x" + F(s.Ratio) + ", " + I(s.Share * 100) + "%)");
                    }
                }
            }

            if (finished != null)
            {
                List<Sig> done = finished;
                System.Threading.ThreadPool.QueueUserWorkItem(delegate { foreach (Sig s in done) WriteSignal(s); });
            }
        }

        // Any profile window, on a real HYBRID entry fill.
        public void OnRealEntry(DateTime ny, bool isLong, double entryPrice)
        {
            Sig best = null;
            DateTime now;
            lock (sync)
            {
                now = lastMarketTime;
                int side = isLong ? 1 : -1;
                foreach (Sig s in recent)
                    if (s.Side == side && (now - s.Time).TotalSeconds <= LinkWindowSec && (best == null || s.Time > best.Time))
                        best = s;
            }

            double lead = best != null ? (now - best.Time).TotalSeconds : -1;
            double adv = best != null && best.Tick > 0 ? (entryPrice - best.Entry) * (isLong ? 1 : -1) / best.Tick : 0;
            Write("REAL HYBRID " + (isLong ? "LONG" : "SHORT") + " @ " + F(entryPrice) + " | "
                + (best == null ? "no delta signal in the last 10 min"
                   : "delta signal " + I(lead) + " s earlier @ " + F(best.Entry) + " (" + I(adv) + " t better for delta)"));

            Sig b = best;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                Append("hybrid_delta_vs_real.csv",
                    "Date,TimeNy,Side,RealEntry,DeltaSignalId,LeadSec,DeltaEntry,DeltaBetterTicks,DeltaResult,DeltaTicks",
                    string.Join(",", new[]
                    {
                        ny.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), ny.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                        isLong ? "LONG" : "SHORT", F(entryPrice),
                        b != null ? b.Id : "NONE", I(lead), b != null ? F(b.Entry) : "", b != null ? I(adv) : "",
                        b != null ? (b.Done ? b.How : "OPEN") : "", b != null && b.Done ? I(b.Ticks) : ""
                    }));
            });
        }

        private void WriteSignal(Sig s)
        {
            Write("DONE | " + s.Id + " | " + s.How + " " + I(s.Ticks) + "t | MFE " + I(s.Mfe) + "t MAE " + I(s.Mae) + "t");
            Append("hybrid_delta_shadow.csv",
                "Id,Date,TimeNy,Side,Entry,Delta,DeltaRatio,SideShare,SlTicks,TpTicks,Result,Ticks,Mfe,Mae,Hit40,ExitSec",
                string.Join(",", new[]
                {
                    s.Id, s.Ny.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), s.Ny.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
                    s.Side > 0 ? "LONG" : "SHORT", F(s.Entry), I(s.Delta), F(s.Ratio), F(s.Share),
                    SlTicks.ToString(CultureInfo.InvariantCulture), TpTicks.ToString(CultureInfo.InvariantCulture),
                    s.How, I(s.Ticks), I(s.Mfe), I(s.Mae), s.Hit40 ? "1" : "0", I(s.ExitSec)
                }));
        }

        private void Append(string file, string header, string line)
        {
            try
            {
                lock (csvSync)
                {
                    Func<string> rootFn = RootFolder;
                    string root = rootFn != null ? rootFn() : null;
                    if (string.IsNullOrWhiteSpace(root))
                        root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "JJBotData");
                    string folder = Path.Combine(root, "Learning");
                    Directory.CreateDirectory(folder);
                    string path = Path.Combine(folder, file);
                    bool exists = File.Exists(path);
                    using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    using (StreamWriter sw = new StreamWriter(fs, new UTF8Encoding(false)))
                    {
                        if (!exists) sw.WriteLine(header);
                        sw.WriteLine(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Write("CSV ERROR | " + ex.Message);
            }
        }

        private void Write(string message)
        {
            Action<string> log = Log;
            if (log == null)
                return;
            string m = "HYBRID DELTA SHADOW | " + message;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate { try { log(m); } catch { } });
        }
    }

    public partial class JJBotWindow
    {
        internal static bool V199DeltaShadowEnabled = true;

        private JJDeltaShadow V199Shadow()
        {
            JJDeltaShadow s = JJDeltaShadow.For(selectedInstrument != null ? selectedInstrument.FullName : string.Empty);
            if (s.Log == null)
                s.Log = delegate (string m) { PrintBotMessage(m); };
            if (s.RootFolder == null)
                s.RootFolder = delegate { return stateFolderPath; };
            return s;
        }

        // Fed from V198AbsorptionOnTrade (L2 leader tape, level2Sync held).
        private void V199DeltaOnTrade(DateTime marketTime, double price, double volume, double bid, double ask, double tick)
        {
            try
            {
                if (V199DeltaShadowEnabled)
                    V199Shadow().OnTrade(marketTime, ConvertToNewYorkTime(marketTime), price, volume, bid, ask, tick > 0 ? tick : 0.25);
            }
            catch
            {
            }
        }

        // Called on every real entry fill; only HYBRID entries (no CORE20 module active) are compared.
        private void V199DeltaShadowOnEntry(bool isLong, double entryPrice, bool manualTest)
        {
            try
            {
                if (!V199DeltaShadowEnabled || manualTest)
                    return;
                if (core20ObTradeActive || core20GdTradeActive || core20PmTradeActive || core20AmTradeActive)
                    return;
                V199Shadow().OnRealEntry(GetCurrentNewYorkTime(), isLong, entryPrice);
            }
            catch
            {
            }
        }
    }
}

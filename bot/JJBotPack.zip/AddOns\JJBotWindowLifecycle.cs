#region Using declarations
using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================
    // JJ BOT WINDOW / ADDON LIFECYCLE
    // Stage 20 structural extraction only.
    //
    // Existing close, shutdown and permanent-close handling
    // are moved exactly as-is.
    //
    // No timer cleanup, subscription cleanup, stop behavior,
    // persistence, runtime lease handling or trading logic changed.
    // =========================================================
    public partial class JJBotWindow
    {
        private void OnBotWindowClosing(
            object sender,
            CancelEventArgs e)
        {
            if (allowPermanentClose)
            {
                return;
            }

            e.Cancel = true;

            Hide();

            PrintBotMessage(
                "CONTROL PANEL HIDDEN"
                + " | Bot engine remains active in background."
            );

            PublishPlatformTelemetry();
        }
        public void RequestPermanentClose()
        {
            if (!engineWindowAlive)
            {
                return;
            }

            allowPermanentClose = true;

            try
            {
                if (Dispatcher.CheckAccess())
                {
                    Close();
                }
                else
                {
                    Dispatcher.Invoke(
                        new Action(() =>
                        {
                            Close();
                        })
                    );
                }
            }
            catch
            {
            }
        }
       private void OnBotWindowClosed(
    object sender,
    EventArgs e)
{
            engineWindowAlive = false;

            StopPlatformTelemetry();
            StopPlatformCommandPolling();

    botRunning = false;

    ReleaseRuntimeLease();

    currentSignalState =
        "WINDOW CLOSED";

    currentSetupState =
        "STOPPED";

    // Save persistent counters BEFORE destroying
    // the Account + Instrument bridge.
    SavePersistentDailyState();

    // Remove the exact shared snapshot instead of
    // leaving a permanent STOPPED bot on the chart.
    if (
        selectedAccount != null &&
        selectedInstrument != null
    )
    {
        JJBotSharedState.RemoveSnapshot(
            selectedAccount.Name,
            selectedInstrument.FullName
        );
    }

    StopBarsEngine();
    UnsubscribeExecutionAccount();

            if (accountSelector != null)
            {
                accountSelector.SelectionChanged -=
                    AccountSelectorChanged;

                accountSelector.Cleanup();
                accountSelector = null;
            }

            if (instrumentSelector != null)
            {
                instrumentSelector.InstrumentChanged -=
                    InstrumentSelectorChanged;

                instrumentSelector.Cleanup();
                instrumentSelector = null;
            }

            if (startButton != null)
            {
                startButton.Click -=
                    StartBotClicked;
            }

            if (stopButton != null)
            {
                stopButton.Click -=
                    StopBotClicked;
            }

            if (closeAllButton != null)
            {
                closeAllButton.Click -=
                    CloseAllClicked;
            }

            if (testLongButton != null)
            {
                testLongButton.Click -=
                    TestLongClicked;
            }

            if (testShortButton != null)
            {
                testShortButton.Click -=
                    TestShortClicked;
            }

            if (clearLogButton != null)
            {
                clearLogButton.Click -=
                    ClearVisualLogClicked;
            }

            Closing -=
                OnBotWindowClosing;

            Closed -=
                OnBotWindowClosed;
        }

    }
}

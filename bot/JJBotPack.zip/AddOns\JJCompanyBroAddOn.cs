
#region Using declarations
using System;
using System.Text;
using System.Net;
using System.Collections.Generic;
using System.Globalization;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using NinjaTrader.Gui.Tools;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJCompanyBroAddon : AddOnBase
    {
        private System.Timers.Timer accountTimer;
        private System.Timers.Timer commandTimer;
        private System.Timers.Timer licenseTimer;
        private int commandCheckInProgress = 0;
        private const int MaxCommandsPerPollCycle = 64;
        private Dictionary<string, double> entryPrices = new Dictionary<string, double>();
        private Dictionary<string, int> entryQuantities = new Dictionary<string, int>();
        private Dictionary<string, double> tradeStartRealizedPnL = new Dictionary<string, double>();
        private Dictionary<string, double> lastRealizedPnL = new Dictionary<string, double>();
        private HashSet<string> sentExecutions = new HashSet<string>();
        private HashSet<string> sentClosedTradeIds = new HashSet<string>();
		private Dictionary<string, DateTime> recentCloseTimes = new Dictionary<string, DateTime>();

        // ============================================================
        // V1.1.35 - REAL MFE / MAE TRACKING
        // ============================================================
        private sealed class TradeExcursionState
        {
            public string TradeKey;
            public string Symbol;
            public double EntryPrice;
            public int Quantity;
            public MarketPosition Direction;
            public double Mfe;
            public double Mae;
        }

        private readonly object excursionSync = new object();

        private Dictionary<string, TradeExcursionState> tradeExcursions =
            new Dictionary<string, TradeExcursionState>();

        private Dictionary<string, Instrument> marketDataInstruments =
            new Dictionary<string, Instrument>(
                StringComparer.OrdinalIgnoreCase
            );

        // Journal safety: ExecutionUpdate may fire before Account.Positions
        // reflects the fill. Debounce exit executions and confirm FLAT later.
        private readonly object journalCloseSync = new object();
        private Dictionary<string, int> journalCloseProbeVersions =
            new Dictionary<string, int>();

        // Copier safety: reserve exit quantity while Market exit orders are in-flight.
        // This prevents several rapid SL/TP fill commands from over-closing a slave
        // and accidentally reversing it (e.g. LONG -> SHORT).
        private readonly object copyExitSync = new object();
        private Dictionary<string, int> pendingCopyExitQuantities = new Dictionary<string, int>();
        private Dictionary<string, DateTime> pendingCopyExitTimes = new Dictionary<string, DateTime>();

        // ============================================================
        // COPY CLOSE FENCE V1.1.36
        // ============================================================
        // When a copied exit is flattening a slave, hold a short local fence so a
        // stale SYNC_POSITION target cannot reopen/reverse the slave after it reaches Flat.
        // An explicit COPY_TRADE entry (BUY / SELLSHORT) clears the fence immediately,
        // so a real new master entry/reversal is still allowed.
        private Dictionary<string, DateTime> copyFlatFenceUntil =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private const int CopyFlatFenceMilliseconds = 2500;

        // ============================================================
        // COPY SYNC V2 - SAFE COALESCED POSITION TARGETS
        // ============================================================
        // One worker per slave+instrument. New targets replace older targets.
        // Never submit a second correction while the previous order is in-flight.
        private readonly object copySyncLock = new object();

        private Dictionary<string, int> copyDesiredTargets =
            new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        private Dictionary<string, long> copyTargetVersions =
            new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);

        private HashSet<string> copySyncWorkers =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private string cloudBaseUrl = "https://jjtradingtools.ddns.net";
private string localBaseUrl = "http://localhost:3001";

// Cloud runtime license state.
// Orders/copy commands remain on localhost; only authorization uses Linux.
private bool licenseValid = false;
private bool copyTradingLicensed = false;
private DateTime licenseExpiresUtc = DateTime.MinValue;
private DateTime licenseLastSuccessUtc = DateTime.MinValue;

private string apiKey = "";
		private NTWindow loginWindow;
private TextBox usernameBox;
private PasswordBox passwordBox;
		private string connectedUser = "";
private string connectedEmail = "";
private string configFile = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
    "J&J Company Bro",
    "config.json"
);
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJCompanyBroAddon";
                Description = "J&J Company Bro AddOn - Accounts, Trades and Copier Sync";
            }
            else if (State == State.Active)
            {
                StartAddon();
            }
            else if (State == State.Terminated)
            {
                StopAddon();
            }
        }

 private void StartAddon()
{
    try
    {
        LoadConfig();

        if (string.IsNullOrEmpty(apiKey))
        {
            ShowLoginWindow();
            return;
        }

        if (!RefreshCloudLicense())
        {
            Print(
                "JJ LICENSE LOCKED: cloud authorization required."
            );

            MessageBox.Show(
                "JJ Trading Tools requires server authorization.\n\n"
                + "Connect to the internet and validate your account.",
                "JJ Trading Tools - License Required",
                MessageBoxButton.OK,
                MessageBoxImage.Warning
            );

            return;
        }

        foreach (Account account in Account.All)
            account.ExecutionUpdate += OnAccountExecutionUpdate;

        // Recover any already-open NinjaTrader positions so a restart,
        // recompile or late AddOn start does not lose entry price / MFE / MAE.
        RecoverOpenPositionsForExcursions();

        licenseTimer = new System.Timers.Timer();
        licenseTimer.Interval = 5 * 60 * 1000;
        licenseTimer.AutoReset = true;
        licenseTimer.Elapsed += (s, e) => RefreshCloudLicense();
        licenseTimer.Start();

        accountTimer = new System.Timers.Timer();
        accountTimer.Interval = 5000;
        accountTimer.Elapsed += (s, e) => SendAccounts();
        accountTimer.Start();

        commandTimer = new System.Timers.Timer();
        // Low-latency copier: first pickup <= ~100 ms, then drain the entire
        // pending copy queue in this same timer cycle.
        commandTimer.Interval = 100;
        commandTimer.AutoReset = true;
        commandTimer.Elapsed += (s, e) => CheckCommands();
        commandTimer.Start();

        Print("JJCompanyBroAddon iniciado correctamente");
        SendAccounts();
    }
    catch (Exception ex)
    {
        Print("JJCompanyBroAddon Start error: " + ex.Message);
    }
}

        private void StopAddon()
        {
            try
            {
                foreach (Account account in Account.All)
                    account.ExecutionUpdate -= OnAccountExecutionUpdate;

                if (accountTimer != null)
                {
                    accountTimer.Stop();
                    accountTimer.Dispose();
                    accountTimer = null;
                }

                if (commandTimer != null)
                {
                    commandTimer.Stop();
                    commandTimer.Dispose();
                    commandTimer = null;
                }

                if (licenseTimer != null)
                {
                    licenseTimer.Stop();
                    licenseTimer.Dispose();
                    licenseTimer = null;
                }

                StopAllMarketDataSubscriptions();

                lock (copySyncLock)
                {
                    copyDesiredTargets.Clear();
                    copyTargetVersions.Clear();
                    copySyncWorkers.Clear();
                    copyFlatFenceUntil.Clear();
                }

                licenseValid = false;
                copyTradingLicensed = false;
                licenseExpiresUtc = DateTime.MinValue;

                Print("JJCompanyBroAddon detenido");
            }
            catch (Exception ex)
            {
                Print("JJCompanyBroAddon Stop error: " + ex.Message);
            }
        }

        private bool HasValidCloudLicense()
        {
            return
                licenseValid &&
                DateTime.UtcNow <
                    licenseExpiresUtc;
        }

        private bool RefreshCloudLicense()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(apiKey))
                {
                    licenseValid = false;
                    copyTradingLicensed = false;
                    return false;
                }

                using (WebClient client = new WebClient())
                {
                    client.Headers[
                        HttpRequestHeader.ContentType
                    ] = "application/json";

                    client.Headers[
                        "X-JJ-API-Key"
                    ] = apiKey;

                    string response =
                        client.UploadString(
                            cloudBaseUrl.TrimEnd('/')
                            + "/api/license/lease",
                            "POST",
                            "{\"product\":\"ADDON\"}"
                        );

                    bool authorized =
                        Regex.IsMatch(
                            response,
                            "\"authorized\"\\s*:\\s*true",
                            RegexOptions.IgnoreCase
                        );

                    copyTradingLicensed =
                        Regex.IsMatch(
                            response,
                            "\"copyTrading\"\\s*:\\s*true",
                            RegexOptions.IgnoreCase
                        );

                    Match expiryMatch =
                        Regex.Match(
                            response,
                            "\"expiresAt\"\\s*:\\s*\"([^\"]+)\"",
                            RegexOptions.IgnoreCase
                        );

                    DateTime parsedExpiry;

                    if (
                        expiryMatch.Success &&
                        DateTime.TryParse(
                            expiryMatch.Groups[1].Value,
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.AdjustToUniversal |
                            DateTimeStyles.AssumeUniversal,
                            out parsedExpiry
                        )
                    )
                    {
                        licenseExpiresUtc =
                            parsedExpiry.ToUniversalTime();
                    }
                    else
                    {
                        licenseExpiresUtc =
                            DateTime.UtcNow.AddMinutes(5);
                    }

                    licenseValid =
                        authorized;

                    if (licenseValid)
                    {
                        licenseLastSuccessUtc =
                            DateTime.UtcNow;

                        Print(
                            "JJ LICENSE OK"
                            + " | COPY="
                            + (
                                copyTradingLicensed
                                    ? "YES"
                                    : "NO"
                              )
                            + " | Expires UTC="
                            + licenseExpiresUtc.ToString("HH:mm:ss")
                        );
                    }
                    else
                    {
                        Print(
                            "JJ LICENSE DENIED"
                        );
                    }

                    return licenseValid;
                }
            }
            catch (WebException ex)
            {
                HttpWebResponse errorResponse =
                    ex.Response as HttpWebResponse;

                if (
                    errorResponse != null &&
                    (
                        errorResponse.StatusCode ==
                            HttpStatusCode.Unauthorized ||
                        errorResponse.StatusCode ==
                            HttpStatusCode.Forbidden
                    )
                )
                {
                    // Explicit plan/license denial revokes immediately.
                    licenseValid = false;
                    copyTradingLicensed = false;
                    licenseExpiresUtc =
                        DateTime.MinValue;

                    Print(
                        "JJ LICENSE DENIED BY SERVER"
                        + " | HTTP "
                        + ((int)errorResponse.StatusCode)
                    );

                    return false;
                }

                // Only a genuine connectivity failure can use
                // the remaining time of an already valid lease.
                bool stillValid =
                    HasValidCloudLicense();

                if (!stillValid)
                {
                    licenseValid = false;
                    copyTradingLicensed = false;

                    Print(
                        "JJ LICENSE OFFLINE / EXPIRED: "
                        + ex.Message
                    );
                }

                return stillValid;
            }
            catch (Exception ex)
            {
                bool stillValid =
                    HasValidCloudLicense();

                if (!stillValid)
                {
                    licenseValid = false;
                    copyTradingLicensed = false;

                    Print(
                        "JJ LICENSE ERROR: "
                        + ex.Message
                    );
                }

                return stillValid;
            }
        }

	private void LoadConfig()
{
    try
    {
        string configDir = Path.GetDirectoryName(configFile);

        if (!Directory.Exists(configDir))
            Directory.CreateDirectory(configDir);

        Print("BUSCANDO CONFIG EN: " + configFile);

        if (!File.Exists(configFile))
        {
            Print("JJ Config no encontrada. Addon pendiente de login.");
            return;
        }

        string json = File.ReadAllText(configFile);
Match userMatch = Regex.Match(
    json,
    "\"username\"\\s*:\\s*\"([^\"]+)\""
);

if (userMatch.Success)
    connectedUser = userMatch.Groups[1].Value;

        Match emailMatch = Regex.Match(
            json,
            "\\\"email\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""
        );

        if (emailMatch.Success)
            connectedEmail = emailMatch.Groups[1].Value;

        Match match = Regex.Match(
            json,
            "\"apiKey\"\\s*:\\s*\"([^\"]+)\""
        );

        if (match.Success)
        {
            apiKey = match.Groups[1].Value;
            Print("JJ API Key cargada correctamente");
			Print("JJ Conectado como: " + connectedUser);
        }
        else
        {
            Print("JJ Config encontrada pero sin apiKey");
        }
    }
    catch (Exception ex)
    {
        Print("JJ LoadConfig error: " + ex.Message);
    }
}

private void SaveConfig(
    string newApiKey,
    string username,
    string email)
{
    try
    {
        string configDir = Path.GetDirectoryName(configFile);

        if (!Directory.Exists(configDir))
            Directory.CreateDirectory(configDir);

        string json =
            "{" +
            "\"apiKey\":\"" + EscapeJson(newApiKey) + "\"," +
            "\"username\":\"" + EscapeJson(username) + "\"," +
            "\"email\":\"" + EscapeJson(email) + "\"," +
            "\"serverUrl\":\"" + EscapeJson(cloudBaseUrl) + "\"" +
            "}";

        File.WriteAllText(configFile, json);

        apiKey = newApiKey;
        connectedUser = username;
        connectedEmail = email;

        Print("JJ Config guardada correctamente");
    }
    catch (Exception ex)
    {
        Print("JJ SaveConfig error: " + ex.Message);
    }
}
private void LoginAddon(string username, string password)
{
    try
    {
        string json =
            "{" +
            "\"username\":\"" + EscapeJson(username) + "\"," +
            "\"password\":\"" + EscapeJson(password) + "\"" +
            "}";

        using (WebClient client = new WebClient())
        {
            client.Headers[HttpRequestHeader.ContentType] = "application/json";

            string response = client.UploadString(
                cloudBaseUrl + "/api/addon/login",
                "POST",
                json
            );
Match userMatch = Regex.Match(
    response,
    "\"username\"\\s*:\\s*\"([^\"]+)\""
);
Match emailMatch = Regex.Match(
    response,
    "\"email\"\\s*:\\s*\"([^\"]*)\""
);
            Match match = Regex.Match(
                response,
                "\"apiKey\"\\s*:\\s*\"([^\"]+)\""
            );

            if (match.Success)
            {
                string newApiKey = match.Groups[1].Value;
               string loggedUser =
    userMatch.Success
        ? userMatch.Groups[1].Value
        : username;

string loggedEmail =
    emailMatch.Success
        ? emailMatch.Groups[1].Value
        : (
            username.IndexOf("@", StringComparison.Ordinal) >= 0
                ? username
                : ""
          );

SaveConfig(
    newApiKey,
    loggedUser,
    loggedEmail
);
              Print("JJ Addon conectado correctamente");
StartAddon();
            }
            else
            {
                Print("JJ Login error: no se encontró apiKey en respuesta");
            }
        }
    }
    catch (Exception ex)
    {
        Print("JJ LoginAddon error: " + ex.Message);
    }
}
private void LogoutAddon()
{
    try
    {
        if (File.Exists(configFile))
            File.Delete(configFile);

        apiKey = "";
        connectedUser = "";
        connectedEmail = "";

        Print("JJ Sesión cerrada");

        ShowLoginWindow();
    }
    catch (Exception ex)
    {
        Print("JJ Logout error: " + ex.Message);
    }
}
        private void SendAccounts()
        {
            try
            {
                if (!HasValidCloudLicense())
                {
                    Print(
                        "JJ ACCOUNTS BLOCKED - LICENSE REQUIRED"
                    );
                    return;
                }

				if (string.IsNullOrEmpty(apiKey))
{
    Print("JJ Addon no vinculado. Falta apiKey.");
    return;
}
                // Keep excursion state synchronized with any open positions
                // that exist even if their original entry execution was missed.
                RecoverOpenPositionsForExcursions();

                StringBuilder json = new StringBuilder();
                json.Append("{");
json.Append("\"apiKey\":\"" + apiKey + "\",");
json.Append("\"accounts\":[");

                bool first = true;

                foreach (Account account in Account.All)
                {
                    if (account == null)
                        continue;

                    string accountName = account.Name;

                    if (
                        accountName == "Backtest" ||
                        accountName == "Playback101"
                    )
                        continue;

                    int totalContracts = 0;
                    string positions = "";

                    foreach (Position pos in account.Positions)
                    {
                        if (pos == null || pos.MarketPosition == MarketPosition.Flat)
                            continue;

                        totalContracts += pos.Quantity;

                        positions += EscapeJson(pos.Instrument.FullName) + " " +
                                     pos.MarketPosition.ToString() + " x" +
                                     pos.Quantity.ToString() + " | ";
                    }

                    string broker = DetectBroker(accountName);

                    bool balanceReadOk = false;
                    double balance = SafeGetWithStatus(
                        account,
                        AccountItem.CashValue,
                        out balanceReadOk
                    );
                    double realizedPnL = SafeGet(account, AccountItem.RealizedProfitLoss);

                    if (!lastRealizedPnL.ContainsKey(accountName))
                        lastRealizedPnL[accountName] = realizedPnL;

                    double unrealizedPnL = SafeGet(account, AccountItem.UnrealizedProfitLoss);
                    double trailingMaxDrawdown = SafeGet(account, AccountItem.TrailingMaxDrawdown);

                    if (!first)
                        json.Append(",");

                    first = false;

                    json.Append("{");
                    json.Append("\"name\":\"" + EscapeJson(accountName) + "\",");
                    json.Append("\"broker\":\"" + EscapeJson(broker) + "\",");
                    json.Append("\"balance\":" + ToInvariant(balance) + ",");
                    json.Append("\"balanceReadOk\":" + (balanceReadOk ? "true" : "false") + ",");
                    json.Append("\"pnl\":" + ToInvariant(realizedPnL) + ",");
                    json.Append("\"unrealizedPnl\":" + ToInvariant(unrealizedPnL) + ",");
                    json.Append("\"remainingDrawdown\":" + ToInvariant(trailingMaxDrawdown) + ",");
                    json.Append("\"contracts\":" + totalContracts + ",");
                    json.Append("\"positions\":\"" + EscapeJson(positions) + "\",");
                    json.Append("\"connected\":true,");
                    json.Append("\"type\":\"slave\"");
                    json.Append("}");
                }

                json.Append("]}");

                // Keep the local Windows runtime synchronized for low-latency
                // Copy Trading, while also preserving the cloud account sync.
                // Local failure must not prevent the cloud sync.
                TryPostJson(
                    localBaseUrl + "/api/accounts/detect",
                    json.ToString()
                );

                PostJson(
                    cloudBaseUrl + "/api/accounts/detect",
                    json.ToString()
                );

                Print("JJ Accounts sincronizadas | LOCAL + CLOUD");
            }
            catch (Exception ex)
            {
                Print("JJ SendAccounts error: " + ex.Message);
            }
        }

        private void OnAccountExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            try
            {
                Account account = sender as Account;

                if (
                    account == null ||
                    e == null ||
                    e.Execution == null ||
                    e.Execution.Order == null ||
                    e.Execution.Instrument == null
                )
                    return;

                /*
                  Las órdenes creadas por el copiador se registran en la
                  cuenta master antes de ser copiadas. Las ejecuciones
                  JJ_COPY pertenecen a las cuentas slave y no deben
                  volver a generar una copia ni duplicar el Journal.
                */
             string rawOrderName =
    e.Execution.Order.Name == null
        ? ""
        : e.Execution.Order.Name;

/*
    Las ejecuciones JJ_COPY pertenecen a cuentas slave.

    IMPORTANTE:
    NO debemos ignorarlas porque también forman parte
    del rendimiento real de la cuenta y deben aparecer
    en Journal, Advanced Metrics y estadísticas.

    Lo único que debemos impedir es que una ejecución
    copiada vuelva a activar el copiador.
*/
bool isJjCopyExecution =
    rawOrderName.IndexOf(
        "JJ_COPY",
        StringComparison.OrdinalIgnoreCase
    ) >= 0;

                string executionId =
                    e.Execution.ExecutionId == null
                        ? ""
                        : e.Execution.ExecutionId;

                if (
                    !string.IsNullOrWhiteSpace(executionId) &&
                    sentExecutions.Contains(executionId)
                )
                    return;

                if (!string.IsNullOrWhiteSpace(executionId))
                    sentExecutions.Add(executionId);

                string symbol = e.Execution.Instrument.FullName;
                int executionQuantity = Math.Max(
                    1,
                    e.Execution.Quantity
                );
                double executionPrice = e.Execution.Price;
                DateTime executionTime = e.Execution.Time;

                string tradeKey =
                    account.Name + "|" + symbol;

                string orderAction =
                    e.Execution.Order.OrderAction
                        .ToString()
                        .ToUpperInvariant();

                Position currentPos = null;

                foreach (Position position in account.Positions)
                {
                    if (
                        position != null &&
                        position.Instrument != null &&
                        position.Instrument.FullName == symbol
                    )
                    {
                        currentPos = position;
                        break;
                    }
                }

                bool isFlatAfterExecution =
                    currentPos == null ||
                    currentPos.MarketPosition ==
                        MarketPosition.Flat ||
                    currentPos.Quantity == 0;

                bool isEntryAction =
                    orderAction == "BUY" ||
                    orderAction == "SELLSHORT";

                bool isExitAction =
                    orderAction == "SELL" ||
                    orderAction == "BUYTOCOVER";

                /*
                  Registrar la ejecución normal para el estado en vivo.
                  Una salida parcial sigue siendo SELL/BUYTOCOVER.
                  Solo la salida que deja la posición Flat se registra
                  como CLOSE en el Journal.
                */
                string actionForRecord =
                    isExitAction && isFlatAfterExecution
                        ? "CLOSE"
                        : orderAction;

                /*
                  Cuando una salida JJ_COPY se ejecuta, liberar la cantidad
                  que estaba reservada como "in-flight". Si quedó Flat,
                  limpiar toda la reserva de esa cuenta+instrumento.
                */
                if (isJjCopyExecution && isExitAction)
                {
                    ReleaseCopyExitReservation(
                        account.Name,
                        symbol,
                        executionQuantity,
                        isFlatAfterExecution
                    );

                    if (isFlatAfterExecution)
                    {
                        ArmCopyFlatFence(
                            account.Name,
                            symbol
                        );
                    }
                }

                if (isEntryAction)
                {
                    int previousQuantity =
                        entryQuantities.ContainsKey(tradeKey)
                            ? entryQuantities[tradeKey]
                            : 0;

                    double previousAverage =
                        entryPrices.ContainsKey(tradeKey)
                            ? entryPrices[tradeKey]
                            : 0;

                    int newQuantity =
                        previousQuantity + executionQuantity;

                    double newAverage =
                        newQuantity > 0
                            ? (
                                previousAverage *
                                    previousQuantity +
                                executionPrice *
                                    executionQuantity
                              ) / newQuantity
                            : executionPrice;

                    entryQuantities[tradeKey] = newQuantity;
                    entryPrices[tradeKey] = newAverage;

                    TrackOpenTradeExcursion(
                        tradeKey,
                        symbol,
                        newAverage,
                        newQuantity,
                        orderAction == "BUY"
                            ? MarketPosition.Long
                            : MarketPosition.Short,
                        e.Execution.Instrument
                    );

                    /*
                      Guardar el PnL realizado de la cuenta al inicio de
                      esta posición. Luego, al quedar Flat, la diferencia
                      será el PnL real completo del trade.
                    */
                    if (
                        !tradeStartRealizedPnL.ContainsKey(
                            tradeKey
                        )
                    )
                    {
                        tradeStartRealizedPnL[tradeKey] =
                            SafeGet(
                                account,
                                AccountItem.RealizedProfitLoss
                            );
                    }
                }

         /*
    Solo las ejecuciones originales pueden entrar
    al motor de copy trading.

    Las JJ_COPY sí se siguen procesando para Journal,
    pero NO se vuelven a enviar a /api/trades/record.
*/
if (!isJjCopyExecution)
{
    /*
      /api/trades/record alimenta el COPY TRADING.
      Debe recibir la acción REAL de cada execution (SELL/BUYTOCOVER)
      y su cantidad exacta. Convertir el último partial fill a CLOSE
      hacía que el slave intentara cerrar toda la posición otra vez.
      El Journal de trades cerrados se maneja por SendClosedTrade().
    */
    Account copyMasterAccount = account;
    string copyMasterSymbol = symbol;
    string copyMasterAction = orderAction;
    int copyMasterExecutionQuantity = executionQuantity;
    double copyMasterExecutionPrice = executionPrice;
    DateTime copyMasterExecutionTime = executionTime;

    /*
      COPY POSITION SETTLE GUARD

      NinjaTrader puede lanzar ExecutionUpdate antes de que Account.Positions
      refleje el fill. Eso es especialmente peligroso al cerrar:
      BUYTOCOVER/SELL podía leer todavía la posición anterior y mandar
      SYNC_POSITION con TARGET=-1/+1, dejando o reabriendo la slave.

      Para una salida esperamos a que la posición cambie. Si NinjaTrader
      tarda demasiado, calculamos un fallback seguro que NUNCA cruza Flat.
    */
    int copyPositionAtEvent =
        GetSignedPositionQuantity(
            copyMasterAccount,
            copyMasterSymbol
        );

    Task.Run(() =>
    {
        try
        {
            bool copyIsExit =
                copyMasterAction == "SELL" ||
                copyMasterAction == "BUYTOCOVER";

            int signedMasterPosition =
                copyPositionAtEvent;

            if (copyIsExit)
            {
                bool positionSettled = false;

                for (int attempt = 0; attempt < 20; attempt++)
                {
                    Thread.Sleep(50);

                    int candidate =
                        GetSignedPositionQuantity(
                            copyMasterAccount,
                            copyMasterSymbol
                        );

                    /*
                      En una salida válida esperamos:
                      - Flat (0), o
                      - una reducción real de magnitud manteniendo el lado.
                    */
                    if (
                        candidate == 0 ||
                        (
                            Math.Sign(candidate) ==
                                Math.Sign(copyPositionAtEvent) &&
                            Math.Abs(candidate) <
                                Math.Abs(copyPositionAtEvent)
                        )
                    )
                    {
                        signedMasterPosition = candidate;
                        positionSettled = true;
                        break;
                    }
                }

                if (!positionSettled)
                {
                    /*
                      Fallback anti-reversal:
                      una orden de SALIDA nunca puede crear una nueva posición
                      al otro lado. Reducimos la posición observada y clamp a 0.
                    */
                    if (
                        copyMasterAction == "SELL" &&
                        copyPositionAtEvent > 0
                    )
                    {
                        signedMasterPosition =
                            Math.Max(
                                0,
                                copyPositionAtEvent -
                                copyMasterExecutionQuantity
                            );
                    }
                    else if (
                        copyMasterAction == "BUYTOCOVER" &&
                        copyPositionAtEvent < 0
                    )
                    {
                        signedMasterPosition =
                            Math.Min(
                                0,
                                copyPositionAtEvent +
                                copyMasterExecutionQuantity
                            );
                    }
                    else
                    {
                        signedMasterPosition =
                            GetSignedPositionQuantity(
                                copyMasterAccount,
                                copyMasterSymbol
                            );
                    }

                    Print(
                        "COPY EXIT SETTLE FALLBACK: " +
                        copyMasterAccount.Name + " " +
                        copyMasterSymbol +
                        " | ACTION=" +
                        copyMasterAction +
                        " | EVENT_POS=" +
                        copyPositionAtEvent +
                        " | TARGET=" +
                        signedMasterPosition
                    );
                }
            }
            else
            {
                /*
                  Entradas: mantener baja latencia, pero dar una ventana corta
                  para que Account.Positions publique el nuevo target.
                */
                Thread.Sleep(80);

                signedMasterPosition =
                    GetSignedPositionQuantity(
                        copyMasterAccount,
                        copyMasterSymbol
                    );
            }

            SendTrade(
                copyMasterAccount.Name,
                copyMasterSymbol,
                copyMasterAction,
                copyMasterExecutionQuantity,
                copyMasterExecutionPrice,
                copyMasterExecutionTime,
                signedMasterPosition
            );
        }
        catch (Exception copyEx)
        {
            Print("COPY SNAPSHOT ERROR: " + copyEx.Message);
        }
    });
}

                /*
                  JOURNAL CLOSED-TRADE FIX

                  NinjaTrader puede disparar ExecutionUpdate antes de que
                  Account.Positions refleje el fill. Por eso ya no exigimos
                  FLAT inmediatamente aquí.

                  Toda salida agenda una comprobación diferida. Las parciales
                  se descartan si la posición sigue abierta; la última salida
                  que realmente deja FLAT crea el trade cerrado.
                */
                if (!isExitAction)
                    return;

                QueueClosedTradeProbe(
                    account,
                    tradeKey,
                    symbol,
                    executionQuantity,
                    executionPrice,
                    executionId,
                    executionTime
                );
            }
            catch (Exception ex)
            {
                Print(
                    "JJ Trade listener error: " +
                    ex.Message
                );
            }
        }


        private bool IsAccountInstrumentFlat(
            Account account,
            string symbol)
        {
            try
            {
                if (account == null)
                    return true;

                foreach (Position position in account.Positions)
                {
                    if (
                        position != null &&
                        position.Instrument != null &&
                        string.Equals(
                            position.Instrument.FullName,
                            symbol,
                            StringComparison.OrdinalIgnoreCase
                        )
                    )
                    {
                        return
                            position.MarketPosition ==
                                MarketPosition.Flat ||
                            position.Quantity == 0;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void QueueClosedTradeProbe(
            Account account,
            string tradeKey,
            string symbol,
            int executionQuantity,
            double executionPrice,
            string executionId,
            DateTime executionTime)
        {
            if (account == null)
                return;

            int probeVersion;

            lock (journalCloseSync)
            {
                int currentVersion = 0;

                journalCloseProbeVersions.TryGetValue(
                    tradeKey,
                    out currentVersion
                );

                probeVersion =
                    currentVersion + 1;

                journalCloseProbeVersions[
                    tradeKey
                ] = probeVersion;
            }

            // Last-chance recovery:
            // if the AddOn did not see the original entry execution,
            // recover the live NinjaTrader position before the close probe
            // snapshots entry price and quantity.
            if (
                !entryPrices.ContainsKey(tradeKey) ||
                entryPrices[tradeKey] <= 0
            )
            {
                RecoverSingleOpenPosition(
                    account,
                    symbol
                );
            }

            double entryPrice =
                entryPrices.ContainsKey(tradeKey)
                    ? entryPrices[tradeKey]
                    : 0;

            int closedQuantity =
                entryQuantities.ContainsKey(tradeKey)
                    ? entryQuantities[tradeKey]
                    : executionQuantity;

            double startRealized =
                tradeStartRealizedPnL.ContainsKey(tradeKey)
                    ? tradeStartRealizedPnL[tradeKey]
                    : (
                        lastRealizedPnL.ContainsKey(account.Name)
                            ? lastRealizedPnL[account.Name]
                            : SafeGet(
                                account,
                                AccountItem.RealizedProfitLoss
                              )
                      );

            double exitPrice = executionPrice;

            string closedTradeId =
                account.Name + "|" +
                symbol + "|" +
                (
                    string.IsNullOrWhiteSpace(executionId)
                        ? executionTime.Ticks.ToString()
                        : executionId
                );

            Task.Run(() =>
            {
                try
                {
                    bool confirmedFlat = false;

                    for (
                        int attempt = 0;
                        attempt < 8;
                        attempt++
                    )
                    {
                        Thread.Sleep(500);

                        lock (journalCloseSync)
                        {
                            int latestVersion = 0;

                            journalCloseProbeVersions.TryGetValue(
                                tradeKey,
                                out latestVersion
                            );

                            if (latestVersion != probeVersion)
                                return;
                        }

                        if (
                            IsAccountInstrumentFlat(
                                account,
                                symbol
                            )
                        )
                        {
                            confirmedFlat = true;
                            break;
                        }
                    }

                    if (!confirmedFlat)
                    {
                        Print(
                            "JJ JOURNAL: salida parcial / posición aún abierta: " +
                            account.Name + " " + symbol
                        );
                        return;
                    }

                    double currentRealized = 0;
                    double tradePnL = 0;

                    for (
                        int pnlAttempt = 0;
                        pnlAttempt < 6;
                        pnlAttempt++
                    )
                    {
                        Thread.Sleep(
                            pnlAttempt == 0
                                ? 700
                                : 400
                        );

                        currentRealized =
                            SafeGet(
                                account,
                                AccountItem.RealizedProfitLoss
                            );

                        tradePnL =
                            currentRealized -
                            startRealized;

                        if (
                            Math.Abs(tradePnL) >=
                            0.0000001
                        )
                            break;
                    }

                    if (
                        Math.Abs(tradePnL) <
                        0.0000001
                    )
                    {
                        Print(
                            "JJ JOURNAL: FLAT confirmado pero PnL realizado aún no cambió: " +
                            account.Name + " " + symbol
                        );
                        return;
                    }

                    string closeLockKey =
                        tradeKey +
                        "|CLOSE_LOCK";

                    lock (journalCloseSync)
                    {
                        int latestVersion = 0;

                        journalCloseProbeVersions.TryGetValue(
                            tradeKey,
                            out latestVersion
                        );

                        if (latestVersion != probeVersion)
                            return;

                        DateTime recentClose;

                        if (
                            recentCloseTimes.TryGetValue(
                                closeLockKey,
                                out recentClose
                            ) &&
                            (
                                DateTime.Now -
                                recentClose
                            ).TotalSeconds <= 10
                        )
                        {
                            Print(
                                "Cierre Flat repetido bloqueado: " +
                                account.Name + " " + symbol
                            );
                            return;
                        }

                        if (
                            sentClosedTradeIds.Contains(
                                closedTradeId
                            )
                        )
                            return;

                        recentCloseTimes[
                            closeLockKey
                        ] = DateTime.Now;

                        sentClosedTradeIds.Add(
                            closedTradeId
                        );
                    }

                    lastRealizedPnL[
                        account.Name
                    ] = currentRealized;

                    double tradeMfe = 0;
                    double tradeMae = 0;

                    GetTradeExcursionSnapshot(
                        tradeKey,
                        out tradeMfe,
                        out tradeMae
                    );

                    SendClosedTrade(
                        account.Name,
                        symbol,
                        "CLOSE",
                        closedQuantity,
                        tradePnL,
                        entryPrice,
                        exitPrice,
                        tradeMfe,
                        tradeMae,
                        closedTradeId,
                        executionTime
                    );

                    entryPrices.Remove(tradeKey);
                    entryQuantities.Remove(tradeKey);
                    tradeStartRealizedPnL.Remove(tradeKey);

                    RemoveTradeExcursion(
                        tradeKey,
                        symbol
                    );

                    lock (journalCloseSync)
                    {
                        journalCloseProbeVersions.Remove(
                            tradeKey
                        );
                    }

                    Print(
                        "JJ JOURNAL CLOSED OK: " +
                        account.Name + " " +
                        symbol + " PnL=" +
                        tradePnL
                    );
                }
                catch (Exception ex)
                {
                    Print(
                        "ERROR Journal closed probe: " +
                        ex.Message
                    );
                }
            });
        }

        // ============================================================
        // OPEN POSITION RECOVERY
        // ============================================================
        private void RecoverOpenPositionsForExcursions()
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    if (account == null)
                        continue;

                    foreach (Position position in account.Positions)
                    {
                        if (
                            position == null ||
                            position.Instrument == null ||
                            position.MarketPosition == MarketPosition.Flat ||
                            position.Quantity <= 0 ||
                            position.AveragePrice <= 0
                        )
                            continue;

                        RecoverPositionSnapshot(
                            account,
                            position
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                Print(
                    "JJ MFE/MAE recovery error: " +
                    ex.Message
                );
            }
        }

        private void RecoverSingleOpenPosition(
            Account account,
            string symbol)
        {
            try
            {
                if (
                    account == null ||
                    string.IsNullOrWhiteSpace(symbol)
                )
                    return;

                foreach (Position position in account.Positions)
                {
                    if (
                        position == null ||
                        position.Instrument == null ||
                        !string.Equals(
                            position.Instrument.FullName,
                            symbol,
                            StringComparison.OrdinalIgnoreCase
                        ) ||
                        position.MarketPosition == MarketPosition.Flat ||
                        position.Quantity <= 0 ||
                        position.AveragePrice <= 0
                    )
                        continue;

                    RecoverPositionSnapshot(
                        account,
                        position
                    );

                    return;
                }
            }
            catch (Exception ex)
            {
                Print(
                    "JJ MFE/MAE single recovery error: " +
                    ex.Message
                );
            }
        }

        private void RecoverPositionSnapshot(
            Account account,
            Position position)
        {
            if (
                account == null ||
                position == null ||
                position.Instrument == null ||
                position.MarketPosition == MarketPosition.Flat ||
                position.Quantity <= 0 ||
                position.AveragePrice <= 0
            )
                return;

            string symbol =
                position.Instrument.FullName;

            string tradeKey =
                account.Name + "|" + symbol;

            bool hadEntry =
                entryPrices.ContainsKey(tradeKey) &&
                entryPrices[tradeKey] > 0;

            entryPrices[tradeKey] =
                position.AveragePrice;

            entryQuantities[tradeKey] =
                position.Quantity;

            if (
                !tradeStartRealizedPnL.ContainsKey(
                    tradeKey
                )
            )
            {
                tradeStartRealizedPnL[tradeKey] =
                    SafeGet(
                        account,
                        AccountItem.RealizedProfitLoss
                    );
            }

            TrackOpenTradeExcursion(
                tradeKey,
                symbol,
                position.AveragePrice,
                position.Quantity,
                position.MarketPosition,
                position.Instrument
            );

            if (!hadEntry)
            {
                Print(
                    "JJ MFE/MAE RECOVERED: " +
                    account.Name + " " +
                    symbol +
                    " | Avg=" +
                    position.AveragePrice +
                    " | Qty=" +
                    position.Quantity +
                    " | " +
                    position.MarketPosition
                );
            }
        }

        // ============================================================
        // REAL MFE / MAE HELPERS
        // ============================================================
        private void TrackOpenTradeExcursion(
            string tradeKey,
            string symbol,
            double entryPrice,
            int quantity,
            MarketPosition direction,
            Instrument instrument)
        {
            if (
                string.IsNullOrWhiteSpace(tradeKey) ||
                string.IsNullOrWhiteSpace(symbol) ||
                instrument == null ||
                entryPrice <= 0 ||
                quantity <= 0
            )
                return;

            lock (excursionSync)
            {
                TradeExcursionState state;

                if (!tradeExcursions.TryGetValue(tradeKey, out state))
                {
                    state = new TradeExcursionState
                    {
                        TradeKey = tradeKey,
                        Symbol = symbol,
                        EntryPrice = entryPrice,
                        Quantity = quantity,
                        Direction = direction,
                        Mfe = 0,
                        Mae = 0
                    };

                    tradeExcursions[tradeKey] = state;
                }
                else
                {
                    state.Symbol = symbol;
                    state.EntryPrice = entryPrice;
                    state.Quantity = quantity;
                    state.Direction = direction;
                }
            }

            EnsureMarketDataSubscription(instrument);
        }

        private void EnsureMarketDataSubscription(
            Instrument instrument)
        {
            if (instrument == null)
                return;

            string symbol = instrument.FullName ?? "";

            if (string.IsNullOrWhiteSpace(symbol))
                return;

            lock (excursionSync)
            {
                if (marketDataInstruments.ContainsKey(symbol))
                    return;

                marketDataInstruments[symbol] = instrument;
            }

            try
            {
                if (
                    instrument.Dispatcher != null &&
                    !instrument.Dispatcher.HasShutdownStarted
                )
                {
                    instrument.Dispatcher.InvokeAsync(
                        () =>
                        {
                            try
                            {
                                instrument.MarketData.Update +=
                                    OnTrackedMarketData;
                            }
                            catch (Exception ex)
                            {
                                Print(
                                    "JJ MFE/MAE subscription error: " +
                                    ex.Message
                                );
                            }
                        }
                    );
                }
            }
            catch (Exception ex)
            {
                Print(
                    "JJ MFE/MAE dispatcher error: " +
                    ex.Message
                );
            }
        }

        private void OnTrackedMarketData(
            object sender,
            MarketDataEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Instrument == null ||
                    e.MarketDataType != MarketDataType.Last ||
                    e.Price <= 0
                )
                    return;

                string symbol = e.Instrument.FullName ?? "";

                if (string.IsNullOrWhiteSpace(symbol))
                    return;

                double pointValue =
                    e.Instrument.MasterInstrument != null
                        ? e.Instrument.MasterInstrument.PointValue
                        : 0;

                if (pointValue <= 0)
                    return;

                lock (excursionSync)
                {
                    foreach (TradeExcursionState state in tradeExcursions.Values)
                    {
                        if (
                            state == null ||
                            !string.Equals(
                                state.Symbol,
                                symbol,
                                StringComparison.OrdinalIgnoreCase
                            ) ||
                            state.EntryPrice <= 0 ||
                            state.Quantity <= 0
                        )
                            continue;

                        double openPnl;

                        if (state.Direction == MarketPosition.Long)
                        {
                            openPnl =
                                (e.Price - state.EntryPrice) *
                                pointValue *
                                state.Quantity;
                        }
                        else if (state.Direction == MarketPosition.Short)
                        {
                            openPnl =
                                (state.EntryPrice - e.Price) *
                                pointValue *
                                state.Quantity;
                        }
                        else
                        {
                            continue;
                        }

                        if (openPnl > state.Mfe)
                            state.Mfe = openPnl;

                        if (openPnl < state.Mae)
                            state.Mae = openPnl;
                    }
                }
            }
            catch (Exception ex)
            {
                Print(
                    "JJ MFE/MAE update error: " +
                    ex.Message
                );
            }
        }

        private void GetTradeExcursionSnapshot(
            string tradeKey,
            out double mfe,
            out double mae)
        {
            mfe = 0;
            mae = 0;

            lock (excursionSync)
            {
                TradeExcursionState state;

                if (
                    tradeExcursions.TryGetValue(
                        tradeKey,
                        out state
                    ) &&
                    state != null
                )
                {
                    mfe = state.Mfe;
                    mae = state.Mae;
                }
            }
        }

        private void RemoveTradeExcursion(
            string tradeKey,
            string symbol)
        {
            Instrument instrumentToUnsubscribe = null;

            lock (excursionSync)
            {
                tradeExcursions.Remove(tradeKey);

                bool symbolStillInUse = false;

                foreach (TradeExcursionState state in tradeExcursions.Values)
                {
                    if (
                        state != null &&
                        string.Equals(
                            state.Symbol,
                            symbol,
                            StringComparison.OrdinalIgnoreCase
                        )
                    )
                    {
                        symbolStillInUse = true;
                        break;
                    }
                }

                if (!symbolStillInUse)
                {
                    marketDataInstruments.TryGetValue(
                        symbol,
                        out instrumentToUnsubscribe
                    );

                    marketDataInstruments.Remove(symbol);
                }
            }

            if (instrumentToUnsubscribe == null)
                return;

            try
            {
                Instrument instrument = instrumentToUnsubscribe;

                if (
                    instrument.Dispatcher != null &&
                    !instrument.Dispatcher.HasShutdownStarted
                )
                {
                    instrument.Dispatcher.InvokeAsync(
                        () =>
                        {
                            try
                            {
                                instrument.MarketData.Update -=
                                    OnTrackedMarketData;
                            }
                            catch
                            {
                            }
                        }
                    );
                }
            }
            catch
            {
            }
        }

        private void StopAllMarketDataSubscriptions()
        {
            List<Instrument> instruments =
                new List<Instrument>();

            lock (excursionSync)
            {
                instruments.AddRange(
                    marketDataInstruments.Values
                );

                marketDataInstruments.Clear();
                tradeExcursions.Clear();
            }

            foreach (Instrument instrument in instruments)
            {
                if (instrument == null)
                    continue;

                try
                {
                    if (
                        instrument.Dispatcher != null &&
                        !instrument.Dispatcher.HasShutdownStarted
                    )
                    {
                        instrument.Dispatcher.InvokeAsync(
                            () =>
                            {
                                try
                                {
                                    instrument.MarketData.Update -=
                                        OnTrackedMarketData;
                                }
                                catch
                                {
                                }
                            }
                        );
                    }
                }
                catch
                {
                }
            }
        }

		private void ShowLoginWindow()
{
    try
    {
		if (!string.IsNullOrEmpty(apiKey))
{
    MessageBox.Show(
        "Conectado como: " + connectedUser,
        "J&J Company Bro"
    );
    return;
}
        if (loginWindow != null)
            return;

        loginWindow = new NTWindow();
        loginWindow.Caption = "J&J Company Bro Login";
        loginWindow.Width = 360;
        loginWindow.Height = 260;
        loginWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;

        StackPanel panel = new StackPanel();
        panel.Margin = new Thickness(20);

        TextBlock title = new TextBlock();
        title.Text = "Conectar Addon";
        title.FontSize = 20;
        title.Margin = new Thickness(0, 0, 0, 15);

        usernameBox = new TextBox();
        usernameBox.Height = 32;
        usernameBox.Margin = new Thickness(0, 0, 0, 10);
        usernameBox.Text = "";

        passwordBox = new PasswordBox();
        passwordBox.Height = 32;
        passwordBox.Margin = new Thickness(0, 0, 0, 15);

        Button loginButton = new Button();
        loginButton.Content = "Conectar";
        loginButton.Height = 36;

        loginButton.Click += (s, e) =>
        {
            string username = usernameBox.Text;
            string password = passwordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                Print("JJ Login: usuario y contraseña requeridos");
                return;
            }

            LoginAddon(username, password);

            if (!string.IsNullOrEmpty(apiKey))
            {
                loginWindow.Close();
                loginWindow = null;
            }
        };
		Button logoutButton = new Button();
logoutButton.Content = "Cambiar Cuenta";
logoutButton.Height = 36;
logoutButton.Margin = new Thickness(0, 10, 0, 0);

logoutButton.Click += (s, e) =>
{
    LogoutAddon();
};

        panel.Children.Add(title);

        panel.Children.Add(new TextBlock { Text = "Usuario o Email" });
        panel.Children.Add(usernameBox);

        panel.Children.Add(new TextBlock { Text = "Contraseña" });
        panel.Children.Add(passwordBox);

        panel.Children.Add(loginButton);
panel.Children.Add(logoutButton);
        loginWindow.Content = panel;
        loginWindow.Show();
    }
    catch (Exception ex)
    {
        Print("JJ ShowLoginWindow error: " + ex.Message);
    }
}

       private void SendTrade(string accountName, string symbol, string action, int quantity, double price, DateTime time, int positionQuantity)
{
    if (!HasValidCloudLicense())
    {
        Print("JJ Trade blocked. Cloud license required.");
        return;
    }

    if (!copyTradingLicensed)
    {
        // FREE may sync accounts/Journal, but cannot feed Copy Trading.
        return;
    }

    try
    {
		if (string.IsNullOrEmpty(apiKey))
{
    Print("JJ Trade no enviado. Falta apiKey.");
    return;
}
     string json =
    "{" +
    "\"apiKey\":\"" + apiKey + "\"," +
            "\"account\":\"" + EscapeJson(accountName) + "\"," +
            "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
            "\"action\":\"" + EscapeJson(action) + "\"," +
            "\"quantity\":" + quantity + "," +
            "\"price\":" + ToInvariant(price) + "," +
            "\"positionQuantity\":" + positionQuantity + "," +
            "\"time\":\"" + time.ToString("o") + "\"" +
            "}";

        // Copy Trading stays LOCAL for minimum latency. Do not print a false
        // success when localhost rejected the API key or the route.
        string localCopyUrl =
            localBaseUrl.TrimEnd('/') + "/api/trades/record";

        using (WebClient client = new WebClient())
        {
            client.Headers[HttpRequestHeader.ContentType] =
                "application/json";

            string response = client.UploadString(
                localCopyUrl,
                "POST",
                json
            );

            Print(
                "COPY INPUT OK: " +
                accountName + " " +
                symbol + " " +
                action + " x" +
                quantity +
                " | BACKEND=" +
                response
            );
        }
    }
    catch (Exception ex)
    {
        Print("JJ SendTrade error: " + ex.Message);
    }
}

     private void SendClosedTrade(
    string accountName,
    string symbol,
    string side,
    int quantity,
    double pnl,
    double entryPrice,
    double exitPrice,
    double mfe,
    double mae,
    string tradeId,
    DateTime closedAt
)
        {
            try
            {
                if (string.IsNullOrEmpty(apiKey))
                {
                    Print(
                        "JJ ClosedTrade no enviado. Falta apiKey."
                    );
                    return;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" +
                        EscapeJson(apiKey) + "\"," +
                    "\"tradeId\":\"" +
                        EscapeJson(tradeId) + "\"," +
                    "\"account\":\"" +
                        EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" +
                        EscapeJson(symbol) + "\"," +
                    "\"side\":\"" +
                        EscapeJson(side) + "\"," +
                    "\"quantity\":" +
                        quantity + "," +
                    "\"entryPrice\":" +
                        ToInvariant(entryPrice) + "," +
                 "\"exitPrice\":" +
    ToInvariant(exitPrice) + "," +
"\"pnl\":" +
    ToInvariant(pnl) + "," +
"\"mfe\":" +
    ToInvariant(mfe) + "," +
"\"mae\":" +
    ToInvariant(mae) + "," +
"\"closedAt\":\"" +
    closedAt.ToString("o") + "\"" +
"}";

                // ============================================================
                // CLOSED TRADE DUAL ROUTE
                // ============================================================
                // Journal / Daily History are local-authority data, while the
                // cloud also needs the same closed trade for session summaries,
                // email and remote history. Each route is isolated so failure
                // of one destination can never block the other.
                bool localSaved = false;
                bool cloudSaved = false;

                try
                {
                    PostJson(
                        localBaseUrl.TrimEnd('/') +
                            "/api/trades/closed/send",
                        json
                    );

                    localSaved = true;

                    Print(
                        "JJ CLOSED TRADE LOCAL OK: " +
                        accountName + " " +
                        symbol + " PnL=" +
                        pnl +
                        " ID=" +
                        tradeId
                    );
                }
                catch (Exception localEx)
                {
                    Print(
                        "JJ CLOSED TRADE LOCAL ERROR: " +
                        localEx.Message
                    );
                }

                try
                {
                    PostJson(
                        cloudBaseUrl.TrimEnd('/') +
                            "/api/trades/closed/send",
                        json
                    );

                    cloudSaved = true;

                    Print(
                        "JJ CLOSED TRADE CLOUD OK: " +
                        accountName + " " +
                        symbol + " PnL=" +
                        pnl +
                        " ID=" +
                        tradeId
                    );
                }
                catch (Exception cloudEx)
                {
                    Print(
                        "JJ CLOSED TRADE CLOUD ERROR: " +
                        cloudEx.Message
                    );
                }

                Print(
                    "TRADE CERRADO ROUTING: " +
                    symbol +
                    " PnL=" +
                    pnl +
                    " MFE=" +
                    mfe +
                    " MAE=" +
                    mae +
                    " ENTRY=" +
                    entryPrice +
                    " ID=" +
                    tradeId +
                    " | LOCAL=" +
                    (localSaved ? "OK" : "FAIL") +
                    " | CLOUD=" +
                    (cloudSaved ? "OK" : "FAIL")
                );
            }
            catch (Exception ex)
            {
                Print(
                    "ERROR ENVIANDO TRADE CERRADO: " +
                    ex.Message
                );
            }
        }

        private void CheckCommands()
        {
            if (Interlocked.Exchange(ref commandCheckInProgress, 1) == 1)
                return;

            try
            {
                if (!HasValidCloudLicense())
                {
                    return;
                }

                if (string.IsNullOrWhiteSpace(apiKey))
                {
                    Print("JJ comandos no consultados. Falta apiKey.");
                    return;
                }

                string commandsUrl =
                    localBaseUrl.TrimEnd('/') +
                    "/api/ninja/commands?apiKey=" +
                    Uri.EscapeDataString(apiKey);

                // The backend returns one queued command per GET. Drain every
                // available command now so slaves do not wait for another tick.
                for (int i = 0; i < MaxCommandsPerPollCycle; i++)
                {
                    string json;

                    using (WebClient client = new WebClient())
                    {
                        json = client.DownloadString(commandsUrl);
                    }

                    if (string.IsNullOrWhiteSpace(json) || json.Trim() == "[]")
                        break;

                    if (json.Contains("SYNC_POSITION"))
                    {
                        if (!copyTradingLicensed)
                        {
                            Print("SYNC_POSITION BLOCKED - PRO OR ELITE REQUIRED");
                            continue;
                        }

                        string targetAccount =
                            ExtractValue(json, "\"account\":\"");
                        string symbol =
                            ExtractValue(json, "\"symbol\":\"");
                        int targetPosition =
                            ExtractInt(json, "\"targetPosition\":");

                        QueueSyncPositionTarget(
                            targetAccount,
                            symbol,
                            targetPosition
                        );
                        continue;
                    }

                    if (json.Contains("COPY_TRADE"))
                    {
                        if (!copyTradingLicensed)
                        {
                            Print(
                                "COPY_TRADE BLOCKED - PRO OR ELITE REQUIRED"
                            );
                            continue;
                        }

                        string targetAccount = ExtractValue(json, "\"account\":\"");
                        string symbol = ExtractValue(json, "\"symbol\":\"");
                        string actionText = ExtractValue(json, "\"action\":\"").ToUpperInvariant();
                        int quantity = ExtractInt(json, "\"quantity\":");

                        Print(
                            "COPY COMMAND RECEIVED: " +
                            targetAccount + " " +
                            symbol + " " +
                            actionText + " x" +
                            quantity
                        );

                        ExecuteCopyTrade(targetAccount, symbol, actionText, quantity);
                        continue;
                    }

                    if (json.Contains("PANIC_CLOSE_ACCOUNT"))
                    {
                        string targetAccount = ExtractValue(json, "\"account\":\"");
                        ExecutePanicCloseAccount(targetAccount);
                        continue;
                    }

                    if (json.Contains("PANIC_CLOSE"))
                    {
                        ExecutePanicClose(json);
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Print("Error leyendo comandos J&J: " + ex.Message);
            }
            finally
            {
                Interlocked.Exchange(ref commandCheckInProgress, 0);
            }
        }

        private int ReserveCopyExitQuantity(
            string accountName,
            string symbol,
            int requestedQuantity,
            int currentPositionQuantity
        )
        {
            string key = accountName + "|" + symbol;

            lock (copyExitSync)
            {
                DateTime lastUpdate;
                if (
                    pendingCopyExitTimes.TryGetValue(key, out lastUpdate) &&
                    (DateTime.UtcNow - lastUpdate).TotalSeconds > 10
                )
                {
                    // Market exits should resolve quickly. Clear a stale reservation
                    // so a rejected/disconnected order cannot block future protection.
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                }

                int pending = 0;
                pendingCopyExitQuantities.TryGetValue(key, out pending);

                int available = Math.Max(
                    0,
                    currentPositionQuantity - pending
                );

                int requested = Math.Max(0, requestedQuantity);
                int reserved = Math.Min(requested, available);

                if (reserved <= 0)
                    return 0;

                pendingCopyExitQuantities[key] = pending + reserved;
                pendingCopyExitTimes[key] = DateTime.UtcNow;

                return reserved;
            }
        }

        private void ReleaseCopyExitReservation(
            string accountName,
            string symbol,
            int executedQuantity,
            bool isFlat
        )
        {
            string key = accountName + "|" + symbol;

            lock (copyExitSync)
            {
                if (isFlat)
                {
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                    return;
                }

                int pending = 0;
                if (!pendingCopyExitQuantities.TryGetValue(key, out pending))
                    return;

                pending = Math.Max(
                    0,
                    pending - Math.Max(0, executedQuantity)
                );

                if (pending <= 0)
                {
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                }
                else
                {
                    pendingCopyExitQuantities[key] = pending;
                    pendingCopyExitTimes[key] = DateTime.UtcNow;
                }
            }
        }

        private void ArmCopyFlatFence(
            string accountName,
            string symbol)
        {
            string key = GetCopySyncKey(accountName, symbol);

            lock (copySyncLock)
            {
                copyFlatFenceUntil[key] =
                    DateTime.UtcNow.AddMilliseconds(
                        CopyFlatFenceMilliseconds
                    );
            }
        }

        private void ClearCopyFlatFence(
            string accountName,
            string symbol)
        {
            string key = GetCopySyncKey(accountName, symbol);

            lock (copySyncLock)
            {
                copyFlatFenceUntil.Remove(key);
            }
        }

        private bool IsCopyFlatFenceActive(
            string accountName,
            string symbol)
        {
            string key = GetCopySyncKey(accountName, symbol);

            lock (copySyncLock)
            {
                DateTime until;

                if (!copyFlatFenceUntil.TryGetValue(key, out until))
                    return false;

                if (DateTime.UtcNow >= until)
                {
                    copyFlatFenceUntil.Remove(key);
                    return false;
                }

                return true;
            }
        }

        private bool DropCopySyncTargetIfVersionMatches(
            string key,
            long version)
        {
            lock (copySyncLock)
            {
                long latestVersion = 0;

                if (
                    !copyTargetVersions.TryGetValue(
                        key,
                        out latestVersion
                    ) ||
                    latestVersion != version
                )
                    return false;

                copyDesiredTargets.Remove(key);
                copyTargetVersions.Remove(key);
                return true;
            }
        }

        private int GetSignedPositionQuantity(
            Account account,
            string symbol)
        {
            if (account == null)
                return 0;

            foreach (Position p in account.Positions)
            {
                if (
                    p == null ||
                    p.Instrument == null ||
                    !string.Equals(
                        p.Instrument.FullName,
                        symbol,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                    continue;

                if (
                    p.MarketPosition == MarketPosition.Flat ||
                    p.Quantity == 0
                )
                    return 0;

                return
                    p.MarketPosition == MarketPosition.Long
                        ? Math.Abs(p.Quantity)
                        : -Math.Abs(p.Quantity);
            }

            return 0;
        }

        private void SubmitCopyMarketOrder(
            Account account,
            Instrument instrument,
            OrderAction action,
            int quantity,
            string tag)
        {
            Order order = account.CreateOrder(
                instrument,
                action,
                OrderType.Market,
                OrderEntry.Automated,
                TimeInForce.Day,
                Math.Max(1, quantity),
                0,
                0,
                "",
                tag + "_" + DateTime.Now.Ticks,
                DateTime.MaxValue,
                null
            );

            account.Submit(new[] { order });
        }

        private string GetCopySyncKey(
            string accountName,
            string symbol)
        {
            string accountKey =
                CanonicalAddonAccountIdentity(accountName);

            if (string.IsNullOrWhiteSpace(accountKey))
            {
                accountKey =
                    NormalizeAddonAccountIdentity(accountName);
            }

            return
                accountKey +
                "|" +
                (symbol ?? "").Trim().ToUpperInvariant();
        }

        private string NormalizeAddonAccountIdentity(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            StringBuilder builder = new StringBuilder();

            foreach (char c in value.Trim().ToUpperInvariant())
            {
                if (char.IsLetterOrDigit(c))
                    builder.Append(c);
            }

            return builder.ToString();
        }

        private int CountAddonAccountDigits(
            string value)
        {
            int count = 0;

            if (string.IsNullOrEmpty(value))
                return count;

            foreach (char c in value)
            {
                if (char.IsDigit(c))
                    count++;
            }

            return count;
        }

        private string CanonicalAddonAccountIdentity(
            string value)
        {
            string key =
                NormalizeAddonAccountIdentity(value);

            if (string.IsNullOrWhiteSpace(key))
                return string.Empty;

            string[] providerSuffixes =
            {
                "APEXTRADERFUNDING",
                "NINJATRADER",
                "TRADOVATE",
                "RITHMIC",
                "APEX"
            };

            foreach (string suffix in providerSuffixes)
            {
                if (
                    key.Length > suffix.Length &&
                    key.EndsWith(
                        suffix,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    string stripped =
                        key.Substring(
                            0,
                            key.Length - suffix.Length
                        );

                    if (
                        stripped.Length >= 8 &&
                        CountAddonAccountDigits(stripped) >= 6
                    )
                    {
                        return stripped;
                    }
                }
            }

            return key;
        }

        private void PrintAddonAccountResolutionFailure(
            string requested,
            List<Account> available)
        {
            try
            {
                string names =
                    available == null || available.Count == 0
                        ? "<none>"
                        : string.Join(
                            " || ",
                            available.ConvertAll(
                                account =>
                                    account.Name
                                    + " [Norm="
                                    + NormalizeAddonAccountIdentity(account.Name)
                                    + "; Canon="
                                    + CanonicalAddonAccountIdentity(account.Name)
                                    + "]"
                            ).ToArray()
                        );

                Print(
                    "ACCOUNT RESOLUTION FAILED | Requested: "
                    + requested
                    + " | RequestedNorm: "
                    + NormalizeAddonAccountIdentity(requested)
                    + " | RequestedCanon: "
                    + CanonicalAddonAccountIdentity(requested)
                    + " | NinjaAccounts: "
                    + names
                );
            }
            catch
            {
            }
        }

        private Account ResolveAddonAccountByName(
            string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
                return null;

            string requested = accountName.Trim();
            List<Account> available = new List<Account>();

            foreach (Account account in Account.All)
            {
                if (
                    account != null &&
                    !string.IsNullOrWhiteSpace(account.Name)
                )
                {
                    available.Add(account);
                }
            }

            Account exact =
                available.Find(
                    account =>
                        string.Equals(
                            account.Name.Trim(),
                            requested,
                            StringComparison.OrdinalIgnoreCase
                        )
                );

            if (exact != null)
                return exact;

            string requestedKey =
                NormalizeAddonAccountIdentity(requested);

            List<Account> canonicalMatches =
                available.FindAll(
                    account =>
                        string.Equals(
                            NormalizeAddonAccountIdentity(account.Name),
                            requestedKey,
                            StringComparison.OrdinalIgnoreCase
                        )
                );

            if (canonicalMatches.Count == 1)
            {
                Print(
                    "ACCOUNT RESOLUTION | Requested: "
                    + requested
                    + " | NinjaMatch: "
                    + canonicalMatches[0].Name
                    + " | Method: NORMALIZED_EXACT"
                );

                return canonicalMatches[0];
            }

            if (canonicalMatches.Count > 1)
            {
                Print(
                    "ACCOUNT RESOLUTION BLOCKED | Requested: "
                    + requested
                    + " | Reason: AMBIGUOUS NORMALIZED MATCH"
                );
                return null;
            }

            string requestedCanonical =
                CanonicalAddonAccountIdentity(requested);

            List<Account> providerCanonicalMatches =
                available.FindAll(
                    account =>
                        string.Equals(
                            CanonicalAddonAccountIdentity(account.Name),
                            requestedCanonical,
                            StringComparison.OrdinalIgnoreCase
                        )
                );

            if (providerCanonicalMatches.Count == 1)
            {
                Print(
                    "ACCOUNT RESOLUTION | Requested: "
                    + requested
                    + " | NinjaMatch: "
                    + providerCanonicalMatches[0].Name
                    + " | Method: PROVIDER_SUFFIX_CANONICAL"
                );

                return providerCanonicalMatches[0];
            }

            if (providerCanonicalMatches.Count > 1)
            {
                Print(
                    "ACCOUNT RESOLUTION BLOCKED | Requested: "
                    + requested
                    + " | Reason: AMBIGUOUS PROVIDER SUFFIX MATCH"
                );
                return null;
            }

            if (
                requestedKey.Length >= 8 &&
                CountAddonAccountDigits(requestedKey) >= 6
            )
            {
                List<Account> prefixMatches =
                    available.FindAll(
                        account =>
                        {
                            string candidateKey =
                                NormalizeAddonAccountIdentity(account.Name);

                            if (
                                candidateKey.Length < 8 ||
                                CountAddonAccountDigits(candidateKey) < 6
                            )
                            {
                                return false;
                            }

                            return
                                candidateKey.StartsWith(
                                    requestedKey,
                                    StringComparison.OrdinalIgnoreCase
                                ) ||
                                requestedKey.StartsWith(
                                    candidateKey,
                                    StringComparison.OrdinalIgnoreCase
                                );
                        }
                    );

                if (prefixMatches.Count == 1)
                {
                    Print(
                        "ACCOUNT RESOLUTION | Requested: "
                        + requested
                        + " | NinjaMatch: "
                        + prefixMatches[0].Name
                        + " | Method: UNIQUE_PREFIX"
                    );

                    return prefixMatches[0];
                }

                if (prefixMatches.Count > 1)
                {
                    Print(
                        "ACCOUNT RESOLUTION BLOCKED | Requested: "
                        + requested
                        + " | Reason: AMBIGUOUS PREFIX MATCH"
                    );
                }
            }

            PrintAddonAccountResolutionFailure(
                requested,
                available
            );

            return null;
        }

        private Account FindCopyAccount(
            string accountName)
        {
            return ResolveAddonAccountByName(accountName);
        }

        private void QueueSyncPositionTarget(
            string targetAccount,
            string symbol,
            int targetPosition)
        {
            if (
                string.IsNullOrWhiteSpace(targetAccount) ||
                string.IsNullOrWhiteSpace(symbol)
            )
                return;

            string key =
                GetCopySyncKey(
                    targetAccount,
                    symbol
                );

            // TARGET 0 is a close authority signal. Arm the fence before the worker
            // starts so an older non-zero target cannot reopen the slave after Flat.
            if (targetPosition == 0)
            {
                ArmCopyFlatFence(
                    targetAccount,
                    symbol
                );
            }

            bool shouldStart = false;

            lock (copySyncLock)
            {
                copyDesiredTargets[key] =
                    targetPosition;

                long version = 0;

                copyTargetVersions.TryGetValue(
                    key,
                    out version
                );

                copyTargetVersions[key] =
                    version + 1;

                if (!copySyncWorkers.Contains(key))
                {
                    copySyncWorkers.Add(key);
                    shouldStart = true;
                }
            }

            // Duplicate/intermediate targets stay quiet and are coalesced.
            if (!shouldStart)
                return;

            Task.Run(
                () =>
                    RunCopySyncWorker(
                        targetAccount,
                        symbol,
                        key
                    )
            );
        }

        private bool GetLatestCopyTarget(
            string key,
            out int target,
            out long version)
        {
            lock (copySyncLock)
            {
                if (
                    !copyDesiredTargets.TryGetValue(
                        key,
                        out target
                    )
                )
                {
                    version = 0;
                    return false;
                }

                copyTargetVersions.TryGetValue(
                    key,
                    out version
                );

                return true;
            }
        }

        private bool WaitForCopyPositionChange(
            Account account,
            string symbol,
            int previousPosition,
            int maxMilliseconds)
        {
            int waited = 0;

            while (waited < maxMilliseconds)
            {
                Thread.Sleep(50);
                waited += 50;

                int current =
                    GetSignedPositionQuantity(
                        account,
                        symbol
                    );

                if (current != previousPosition)
                    return true;
            }

            return false;
        }

        private void RunCopySyncWorker(
            string targetAccount,
            string symbol,
            string key)
        {
            try
            {
                Account account =
                    FindCopyAccount(
                        targetAccount
                    );

                Instrument instrument =
                    Instrument.GetInstrument(symbol);

                if (account == null || instrument == null)
                {
                    Print(
                        "SYNC ERROR: " +
                        targetAccount + " " +
                        symbol
                    );
                    return;
                }

                for (int safety = 0; safety < 200; safety++)
                {
                    int desired;
                    long desiredVersion;

                    if (
                        !GetLatestCopyTarget(
                            key,
                            out desired,
                            out desiredVersion
                        )
                    )
                        return;

                    int current =
                        GetSignedPositionQuantity(
                            account,
                            symbol
                        );

                    if (current == desired)
                    {
                        // Debounce clustered partial fills from the master.
                        Thread.Sleep(150);

                        int confirmDesired;
                        long confirmVersion;

                        if (
                            !GetLatestCopyTarget(
                                key,
                                out confirmDesired,
                                out confirmVersion
                            )
                        )
                            return;

                        int confirmedCurrent =
                            GetSignedPositionQuantity(
                                account,
                                symbol
                            );

                        if (
                            confirmVersion == desiredVersion &&
                            confirmDesired == confirmedCurrent
                        )
                        {
                            lock (copySyncLock)
                            {
                                long latestVersion = 0;
                                int latestDesired = 0;

                                copyTargetVersions.TryGetValue(
                                    key,
                                    out latestVersion
                                );

                                copyDesiredTargets.TryGetValue(
                                    key,
                                    out latestDesired
                                );

                                if (
                                    latestVersion == confirmVersion &&
                                    latestDesired == confirmedCurrent
                                )
                                {
                                    copyDesiredTargets.Remove(key);
                                    copyTargetVersions.Remove(key);
                                    copySyncWorkers.Remove(key);
                                }
                                else
                                {
                                    continue;
                                }
                            }

                            Print(
                                "SYNC OK: " +
                                account.Name + " " +
                                symbol +
                                " | POSITION=" +
                                confirmedCurrent
                            );

                            return;
                        }

                        continue;
                    }

                    /*
                      COPY FLAT FENCE:
                      If the slave is already Flat immediately after a copied close,
                      a delayed/non-zero SYNC_POSITION target is stale unless a real
                      COPY_TRADE entry explicitly cleared the fence. Never let that
                      stale target create the opposite position.
                    */
                    if (
                        current == 0 &&
                        desired != 0 &&
                        IsCopyFlatFenceActive(
                            account.Name,
                            symbol
                        )
                    )
                    {
                        bool dropped =
                            DropCopySyncTargetIfVersionMatches(
                                key,
                                desiredVersion
                            );

                        Print(
                            "COPY FLAT FENCE BLOCKED STALE SYNC: " +
                            account.Name + " " + symbol +
                            " | DESIRED=" + desired +
                            " | VERSION=" + desiredVersion +
                            " | DROPPED=" +
                            (dropped ? "YES" : "NO")
                        );

                        // If a newer target arrived while we were checking, loop and
                        // evaluate it. Otherwise this worker can safely finish.
                        if (dropped)
                            return;

                        continue;
                    }

                    /*
                      TARGET 0 is always handled first.
                      No delayed reversal-entry task is allowed to survive it.
                    */
                    if (desired == 0)
                    {
                        Print(
                            "SYNC FLAT: " +
                            account.Name + " " +
                            symbol +
                            " | CURRENT=" +
                            current
                        );

                        account.Flatten(
                            new Instrument[] { instrument }
                        );

                        bool changed =
                            WaitForCopyPositionChange(
                                account,
                                symbol,
                                current,
                                5000
                            );

                        if (!changed)
                        {
                            int after =
                                GetSignedPositionQuantity(
                                    account,
                                    symbol
                                );

                            if (after != 0)
                            {
                                Print(
                                    "SYNC FLAT TIMEOUT: " +
                                    account.Name +
                                    " | CURRENT=" +
                                    after
                                );

                                return;
                            }
                        }

                        continue;
                    }

                    /*
                      Opposite side: flatten and wait. After Flat, loop back and
                      use ONLY the newest target. No parallel reversal Task.Run.
                    */
                    if (
                        current != 0 &&
                        Math.Sign(current) != Math.Sign(desired)
                    )
                    {
                        Print(
                            "SYNC REVERSAL FLAT: " +
                            account.Name +
                            " | FROM=" +
                            current +
                            " | DESIRED=" +
                            desired
                        );

                        account.Flatten(
                            new Instrument[] { instrument }
                        );

                        if (
                            !WaitForCopyPositionChange(
                                account,
                                symbol,
                                current,
                                5000
                            )
                        )
                        {
                            Print(
                                "SYNC REVERSAL TIMEOUT: " +
                                account.Name
                            );
                            return;
                        }

                        continue;
                    }

                    int delta =
                        desired - current;

                    if (delta == 0)
                        continue;

                    OrderAction action;

                    if (current > 0)
                    {
                        action =
                            delta > 0
                                ? OrderAction.Buy
                                : OrderAction.Sell;
                    }
                    else if (current < 0)
                    {
                        action =
                            delta < 0
                                ? OrderAction.SellShort
                                : OrderAction.BuyToCover;
                    }
                    else
                    {
                        action =
                            delta > 0
                                ? OrderAction.Buy
                                : OrderAction.SellShort;
                    }

                    int quantity =
                        Math.Abs(delta);

                    Print(
                        "SYNC ORDER: " +
                        account.Name + " " +
                        action + " x" +
                        quantity + " " +
                        symbol +
                        " | CURRENT=" +
                        current +
                        " | DESIRED=" +
                        desired
                    );

                    SubmitCopyMarketOrder(
                        account,
                        instrument,
                        action,
                        quantity,
                        "JJ_COPY_SYNC_V2"
                    );

                    /*
                      ONE ORDER IN-FLIGHT.
                      We do not calculate/send another delta until NinjaTrader
                      reports an actual position change from this order.
                    */
                    if (
                        !WaitForCopyPositionChange(
                            account,
                            symbol,
                            current,
                            5000
                        )
                    )
                    {
                        int after =
                            GetSignedPositionQuantity(
                                account,
                                symbol
                            );

                        Print(
                            "SYNC ORDER TIMEOUT: " +
                            account.Name + " " +
                            symbol +
                            " | CURRENT=" +
                            after
                        );

                        // Never blindly re-submit the same delta.
                        return;
                    }
                }

                Print(
                    "SYNC SAFETY STOP: " +
                    targetAccount + " " +
                    symbol
                );
            }
            catch (Exception ex)
            {
                Print(
                    "ERROR RunCopySyncWorker: " +
                    ex.Message
                );
            }
            finally
            {
                lock (copySyncLock)
                {
                    copySyncWorkers.Remove(key);
                }
            }
        }

        private void ExecuteCopyTrade(string targetAccount, string symbol, string actionText, int quantity)
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    if (!string.Equals(
                            account.Name,
                            targetAccount,
                            StringComparison.OrdinalIgnoreCase
                        ))
                        continue;

                    Instrument instrument = Instrument.GetInstrument(symbol);

                    if (instrument == null)
                    {
                        Print("Instrumento no encontrado: " + symbol);
                        return;
                    }

                    Position currentPos = null;

                    foreach (Position p in account.Positions)
                    {
                        if (p != null && p.Instrument.FullName == symbol)
                        {
                            currentPos = p;
                            break;
                        }
                    }

                    MarketPosition currentPosition = currentPos == null
                        ? MarketPosition.Flat
                        : currentPos.MarketPosition;

                    int currentQty = currentPos == null ? 0 : currentPos.Quantity;
                    actionText = (actionText ?? "").ToUpperInvariant();

                    /*
                      EXIT SAFETY:
                      SELL / BUYTOCOVER from the master are execution-sized exits.
                      Never replace their quantity with the slave's full position.
                      Also reserve in-flight quantity so rapid partial fills cannot
                      over-close and reverse the slave before Ninja updates Position.
                    */
                    if (
                        actionText == "CLOSE" ||
                        actionText == "SELL" ||
                        actionText == "BUYTOCOVER"
                    )
                    {
                        if (currentPosition == MarketPosition.Flat || currentQty <= 0)
                        {
                            // A late copied exit reached a slave that is already Flat.
                            // Keep the close fence armed so a stale SYNC target cannot
                            // turn this harmless duplicate close into a reverse entry.
                            ArmCopyFlatFence(
                                account.Name,
                                symbol
                            );

                            Print(
                                "EXIT ignorado: " +
                                account.Name + " ya esta Flat en " + symbol
                            );
                            SendPositionUpdateAsync(
                                account.Name,
                                symbol,
                                "FLAT",
                                0
                            );
                            return;
                        }

                        OrderAction exitAction;
                        int requestedExitQty;

                        if (actionText == "CLOSE")
                        {
                            exitAction =
                                currentPosition == MarketPosition.Long
                                    ? OrderAction.Sell
                                    : OrderAction.BuyToCover;

                            requestedExitQty = currentQty;
                        }
                        else if (actionText == "SELL")
                        {
                            if (currentPosition != MarketPosition.Long)
                            {
                                Print(
                                    "SELL ignorado: no hay Long para cerrar en " +
                                    account.Name + " " + symbol
                                );
                                return;
                            }

                            exitAction = OrderAction.Sell;
                            requestedExitQty = Math.Max(1, quantity);
                        }
                        else
                        {
                            if (currentPosition != MarketPosition.Short)
                            {
                                Print(
                                    "BUYTOCOVER ignorado: no hay Short para cerrar en " +
                                    account.Name + " " + symbol
                                );
                                return;
                            }

                            exitAction = OrderAction.BuyToCover;
                            requestedExitQty = Math.Max(1, quantity);
                        }

                        int safeExitQty = ReserveCopyExitQuantity(
                            account.Name,
                            symbol,
                            requestedExitQty,
                            currentQty
                        );

                        if (safeExitQty <= 0)
                        {
                            Print(
                                "EXIT BLOQUEADO - cantidad ya en vuelo: " +
                                account.Name + " " + symbol +
                                " | Requested=" + requestedExitQty +
                                " | Position=" + currentQty
                            );
                            return;
                        }

                        // Only arm the flat fence when this exit can flatten the
                        // currently observed slave position. Partial exits keep normal
                        // copy synchronization behavior.
                        if (
                            actionText == "CLOSE" ||
                            requestedExitQty >= currentQty
                        )
                        {
                            ArmCopyFlatFence(
                                account.Name,
                                symbol
                            );
                        }

                        try
                        {
                            Order exitOrder = account.CreateOrder(
                                instrument,
                                exitAction,
                                OrderType.Market,
                                OrderEntry.Automated,
                                TimeInForce.Day,
                                safeExitQty,
                                0,
                                0,
                                "",
                                "JJ_COPY_EXIT_" + DateTime.Now.Ticks,
                                DateTime.MaxValue,
                                null
                            );

                            account.Submit(new[] { exitOrder });
                        }
                        catch
                        {
                            // Submission failed before an execution could release it.
                            ReleaseCopyExitReservation(
                                account.Name,
                                symbol,
                                safeExitQty,
                                false
                            );
                            throw;
                        }

                        SendPositionUpdateAsync(
                            account.Name,
                            symbol,
                            "CLOSE",
                            safeExitQty
                        );

                        Print(
                            "EXIT ENVIADO A SLAVE: " +
                            account.Name + " " +
                            exitAction + " x" +
                            safeExitQty + " " + symbol
                        );
                        return;
                    }

                    OrderAction action;

                    if (actionText == "BUY")
                    {
                        action = OrderAction.Buy;
                    }
                    else if (actionText == "SELLSHORT")
                    {
                        action = OrderAction.SellShort;
                    }
                    else
                    {
                        Print("Accion no reconocida: " + actionText);
                        return;
                    }

                    // Explicit BUY / SELLSHORT is a genuine new master entry. It is
                    // the only event allowed to clear a recent close fence immediately.
                    ClearCopyFlatFence(
                        account.Name,
                        symbol
                    );

                    int finalQuantity = quantity <= 0 ? 1 : quantity;

                    Order order = account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        finalQuantity,
                        0,
                        0,
                        "",
                        "JJ_COPY_" + DateTime.Now.Ticks,
                        DateTime.MaxValue,
                        null
                    );

                    account.Submit(new[] { order });

                    SendPositionUpdateAsync(
                        account.Name,
                        symbol,
                        actionText,
                        finalQuantity
                    );

                    Print(
                        "ORDEN ENVIADA A SLAVE: " +
                        account.Name + " " +
                        action + " x" +
                        finalQuantity + " " + symbol
                    );
                    return;
                }

                Print("Cuenta destino no encontrada: " + targetAccount);
            }
            catch (Exception ex)
            {
                Print("ERROR ExecuteCopyTrade: " + ex.Message);
            }
        }

        private void ExecutePanicCloseAccount(string targetAccount)
        {
            try
            {
                Account account =
                    ResolveAddonAccountByName(targetAccount);

                if (account != null)
                {
                    foreach (Position p in account.Positions)
                    {
                        if (p != null && p.Instrument != null && p.MarketPosition != MarketPosition.Flat)
                        {
                            account.Flatten(new Instrument[] { p.Instrument });
                            SendPositionUpdateAsync(account.Name, p.Instrument.FullName, "CLOSE", p.Quantity);
                        }
                    }

                    Print("PANIC CLOSE ACCOUNT ejecutado: " + account.Name);
                    return;
                }

                Print("PANIC CLOSE ACCOUNT no encontró cuenta: " + targetAccount);
            }
            catch (Exception ex)
            {
                Print("PANIC CLOSE ACCOUNT error: " + ex.Message);
            }
        }

        private void ExecutePanicClose(string json)
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    foreach (Position p in account.Positions)
                    {
                        if (p.MarketPosition != MarketPosition.Flat)
                        {
                            account.Flatten(new Instrument[] { p.Instrument });
                            SendPositionUpdate(account.Name, p.Instrument.FullName, "CLOSE", p.Quantity);
                        }
                    }
                }

                Print("PANIC CLOSE ejecutado");
            }
            catch (Exception ex)
            {
                Print("PANIC CLOSE error: " + ex.Message);
            }
        }

        private void SendPositionUpdateAsync(string accountName, string symbol, string action, int quantity)
        {
            // Bookkeeping HTTP must not stall submission of the next slave.
            Task.Run(() => SendPositionUpdate(accountName, symbol, action, quantity));
        }

        private void SendPositionUpdate(string accountName, string symbol, string action, int quantity)
        {
            try
            {
                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"account\":\"" + EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
                    "\"action\":\"" + EscapeJson(action) + "\"," +
                    "\"quantity\":" + quantity +
                    "}";

                PostJson(
                    cloudBaseUrl + "/api/accounts/position-update",
                    json
                );
            }
            catch (Exception ex)
            {
                Print("Error enviando POSITION UPDATE: " + ex.Message);
            }
        }

        private void PostJson(string url, string json)
        {
            using (WebClient client = new WebClient())
            {
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                client.UploadString(url, "POST", json);
            }
        }

        private void TryPostJson(string url, string json)
        {
            try
            {
                PostJson(url, json);
            }
            catch (Exception ex)
            {
                Print("Ruta no disponible: " + url + " / " + ex.Message);
            }
        }

        private double SafeGetWithStatus(
            Account account,
            AccountItem item,
            out bool readOk)
        {
            readOk = false;

            try
            {
                double value = account.Get(
                    item,
                    Currency.UsDollar
                );

                readOk = true;
                return value;
            }
            catch
            {
                return 0;
            }
        }

        private double SafeGet(Account account, AccountItem item)
        {
            bool ignored;
            return SafeGetWithStatus(
                account,
                item,
                out ignored
            );
        }

        private string DetectBroker(string accountName)
        {
            if (accountName.Contains("APEX"))
                return "Apex";

            if (accountName.Contains("MFFU"))
                return "MyFundedFutures";

            if (accountName.Contains("TDFY") || accountName.Contains("TDFYSL") || accountName.Contains("GCUPTDFY"))
                return "Tradefy";

            if (accountName.Contains("LFE") || accountName.Contains("LTE") || accountName.Contains("LFF"))
                return "Lucid";

            return "NinjaTrader";
        }

        private string EscapeJson(string value)
        {
            if (value == null)
                return "";

            return value.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private string ToInvariant(double value)
        {
            return value.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        private string ExtractValue(string json, string marker)
        {
            int start = json.IndexOf(marker);

            if (start < 0)
                return "";

            start += marker.Length;
            int end = json.IndexOf("\"", start);

            if (end < 0)
                return "";

            return json.Substring(start, end - start);
        }

        private int ExtractInt(string json, string marker)
        {
            int start = json.IndexOf(marker);

            if (start < 0)
                return 1;

            start += marker.Length;
            int end = json.IndexOfAny(new char[] { ',', '}' }, start);

            if (end < 0)
                return 1;

            string value = json.Substring(start, end - start).Trim();
            int result;

            if (int.TryParse(value, out result))
                return result;

            return 1;
        }
    }
}

#region Using declarations
using System;
using System.Text;
using System.Net;
using System.Collections.Generic;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using NinjaTrader.Gui.Tools;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class JJManualJournalPnl
    {
        public static double Resolve(bool completeFills, double fillNet, double currentRealized, double startRealized)
        {
            return completeFills ? fillNet : currentRealized - startRealized;
        }
    }

    public class JJCompanyBroAddon : AddOnBase
    {
        private System.Timers.Timer accountTimer;
        private System.Timers.Timer commandTimer;
        private int commandCheckInProgress = 0;
        private const int MaxCommandsPerPollCycle = 64;
        // Position-local execution accounting, independent of profile and account PnL.
        private class BotPerformancePosition
        {
            public int OpenQuantity;
            public double Average;
            public int Direction;
            public double Gross;
            public double Fees;
            public bool ExclusiveBot = true;
            public bool CompleteFromFlat = true;
            public DateTime EntryTime = DateTime.MinValue; // V1.0.33 - module per trade (Open Bell / Gerard / Hybrid)
            public void Entry(int quantity, double price, double commission, int direction, bool botEntry, bool startsFlat)
            {
                if (OpenQuantity == 0) CompleteFromFlat = CompleteFromFlat && startsFlat;
                else if (Direction != direction) CompleteFromFlat = false;
                if (OpenQuantity == 0) { Direction = direction; ExclusiveBot = ExclusiveBot && startsFlat; }
                ExclusiveBot = ExclusiveBot && botEntry && Direction == direction;
                int total = OpenQuantity + quantity;
                Average = (Average * OpenQuantity + price * quantity) / total;
                OpenQuantity = total;
                Fees += Math.Max(0, commission);
            }
            public void Exit(int quantity, double price, double commission, double pointValue)
            {
                if (quantity > OpenQuantity) { ExclusiveBot = false; CompleteFromFlat = false; }
                Gross += (price - Average) * Direction * Math.Min(quantity,OpenQuantity) * pointValue;
                Fees += Math.Max(0,commission);
                OpenQuantity = Math.Max(0,OpenQuantity - quantity);
            }
        }
        private Dictionary<string, BotPerformancePosition> botPerformancePositions = new Dictionary<string, BotPerformancePosition>();
        private Dictionary<string, double> entryPrices = new Dictionary<string, double>();
        private Dictionary<string, DateTime> lastEntryTimes = new Dictionary<string, DateTime>();
        private Dictionary<string, int> lastEntryDirections = new Dictionary<string, int>();
        private Dictionary<string, string> lastEntryModules = new Dictionary<string, string>();
        private Dictionary<string, int> entryQuantities = new Dictionary<string, int>();
        private Dictionary<string, double> tradeStartRealizedPnL = new Dictionary<string, double>();
        private Dictionary<string, double> lastRealizedPnL = new Dictionary<string, double>();
        private HashSet<string> sentExecutions = new HashSet<string>();

        // V1.7.87 JOURNAL FIX
        //  1) accounts that connect AFTER NinjaTrader started (2nd connection, reconnect) were never
        //     subscribed -> their trades never reached the Journal / the bot table.
        //  2) "flat after this fill" was read from account.Positions, which the broker often
        //     updates AFTER the execution event -> the closing fill was not seen as a close.
        //     The position is now tracked from the fills themselves.
        //  3) 5 bot accounts fill at the same instant on different threads; the shared
        //     dictionaries were not thread-safe -> one handler under a lock.
        //  4) if the broker updates Realized PnL later than 1.5 s, the trade was dropped as
        //     "sin cambio de PnL" -> the PnL computed from the fills is used instead.
        private readonly object journalSync = new object();
        private readonly HashSet<Account> subscribedAccounts = new HashSet<Account>();
        private readonly Dictionary<string, int> trackedPositions = new Dictionary<string, int>();
        private readonly Dictionary<string, DateTime> trackedLastExecUtc = new Dictionary<string, DateTime>();

        // V1.7.87 - same commission rule as the bot (JJBotCommissionEngine): NinjaTrader's
        // commission when it reports one, otherwise the firm/route/instrument rate. Many prop
        // connections report $0 commission, so the Journal / bot table showed GROSS PnL
        // while the bot and the broker show NET.
        private double JournalExecutionFee(Account account, Instrument instrument, double reported, int quantity)
        {
            double fee = Math.Abs(reported);
            if (fee > 0.0000001 || quantity <= 0 || account == null || instrument == null)
                return fee;

            try
            {
                string fullName = (instrument.FullName ?? string.Empty).Trim();
                int space = fullName.IndexOf(' ');
                string root = (space > 0 ? fullName.Substring(0, space) : fullName).ToUpperInvariant();

                string model;
                double roundTurn;
                if (JJBotWindow.TryGetRoundTurnFee(account.Name, JournalConnectionText(account), root, out model, out roundTurn))
                    return roundTurn / 2.0 * quantity;
            }
            catch
            {
            }

            return 0;
        }

        private static string JournalConnectionText(Account account)
        {
            try
            {
                object connection = JournalProperty(account, "Connection");
                object options = JournalProperty(connection, "Options");
                return Convert.ToString(connection) + " " + Convert.ToString(options) + " "
                    + Convert.ToString(JournalProperty(connection, "Name")) + " "
                    + Convert.ToString(JournalProperty(options, "Name")) + " "
                    + Convert.ToString(JournalProperty(options, "Provider"));
            }
            catch
            {
                return string.Empty;
            }
        }

        private static object JournalProperty(object source, string name)
        {
            try
            {
                if (source == null) return null;
                var p = source.GetType().GetProperty(name);
                return p != null ? p.GetValue(source, null) : null;
            }
            catch
            {
                return null;
            }
        }

        private void EnsureAccountSubscriptions()
        {
            try
            {
                List<Account> all;
                lock (Account.All) all = new List<Account>(Account.All);

                foreach (Account account in all)
                {
                    if (account == null) continue;

                    lock (journalSync)
                    {
                        if (!subscribedAccounts.Contains(account))
                        {
                            subscribedAccounts.Add(account);
                            SeedTrackedPositions(account, true);
                            account.ExecutionUpdate += OnAccountExecutionUpdate;
                            Print("JJ Journal: escuchando trades de " + account.Name);
                        }
                        else
                        {
                            SeedTrackedPositions(account, false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Print("JJ Journal subscribe error: " + ex.Message);
            }
        }

        // force = new account: copy its positions. Otherwise only heal a key that has been
        // quiet for 15 s and disagrees with the broker (a missed fill would block the next close).
        private void SeedTrackedPositions(Account account, bool force)
        {
            try
            {
                Dictionary<string, int> broker = new Dictionary<string, int>();
                lock (account.Positions)
                {
                    foreach (Position p in account.Positions)
                    {
                        if (p == null || p.Instrument == null) continue;
                        int s = p.MarketPosition == MarketPosition.Long ? Math.Abs(p.Quantity)
                            : p.MarketPosition == MarketPosition.Short ? -Math.Abs(p.Quantity) : 0;
                        broker[account.Name + "|" + p.Instrument.FullName] = s;
                    }
                }

                foreach (KeyValuePair<string, int> kv in broker)
                {
                    int tracked;
                    DateTime last;
                    bool has = trackedPositions.TryGetValue(kv.Key, out tracked);
                    bool quiet = !trackedLastExecUtc.TryGetValue(kv.Key, out last) || (DateTime.UtcNow - last).TotalSeconds > 15;
                    if (force || !has || (quiet && tracked != kv.Value))
                        trackedPositions[kv.Key] = kv.Value;
                }

                // keys of this account that the broker no longer lists are flat
                string prefix = account.Name + "|";
                foreach (string k in new List<string>(trackedPositions.Keys))
                {
                    if (!k.StartsWith(prefix, StringComparison.Ordinal) || broker.ContainsKey(k)) continue;
                    DateTime last;
                    bool quiet = !trackedLastExecUtc.TryGetValue(k, out last) || (DateTime.UtcNow - last).TotalSeconds > 15;
                    if (force || quiet) trackedPositions[k] = 0;
                }
            }
            catch
            {
            }
        }
        private readonly object closedTradeOutboxLock = new object();
        private readonly string closedTradeOutboxDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "JJCompanyBro", "closed-trade-outbox-v1");
        private int closedTradeFlushInProgress = 0;
        private HashSet<string> sentClosedTradeIds = new HashSet<string>();
		private Dictionary<string, DateTime> recentCloseTimes = new Dictionary<string, DateTime>();

        // Copier safety: reserve exit quantity while Market exit orders are in-flight.
        // This prevents several rapid SL/TP fill commands from over-closing a slave
        // and accidentally reversing it (e.g. LONG -> SHORT).
        private readonly object copyExitSync = new object();
        private Dictionary<string, int> pendingCopyExitQuantities = new Dictionary<string, int>();
        private Dictionary<string, DateTime> pendingCopyExitTimes = new Dictionary<string, DateTime>();
        private string cloudBaseUrl = "https://jjtradingtools.ddns.net";
private string localBaseUrl = "http://localhost:3001";
private string apiKey = "";
		private NTWindow loginWindow;
private TextBox usernameBox;
private PasswordBox passwordBox;
		private string connectedUser = "";
private string connectedEmail = "";
private string configFile = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
    "J&J Company Bro",
    "config.json"
);
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJCompanyBroAddon";
                Description = "J&J Company Bro AddOn - Accounts, Trades and Copier Sync";
            }
            else if (State == State.Active)
            {
                StartAddon();
            }
            else if (State == State.Terminated)
            {
                StopAddon();
            }
        }

 private void StartAddon()
{
    try
    {
        LoadConfig();

        if (string.IsNullOrEmpty(apiKey))
        {
            ShowLoginWindow();
            return;
        }

        // V1.7.87 - also accounts that connect later (checked every 5 s)
        EnsureAccountSubscriptions();

        accountTimer = new System.Timers.Timer();
        accountTimer.Interval = 5000;
        accountTimer.Elapsed += (s, e) => { EnsureAccountSubscriptions(); SendAccounts(); FlushClosedTradeOutbox(); };
        accountTimer.Start();

        commandTimer = new System.Timers.Timer();
        // Low-latency copier: first pickup <= ~100 ms, then drain the entire
        // pending copy queue in this same timer cycle.
        commandTimer.Interval = 100;
        commandTimer.AutoReset = true;
        commandTimer.Elapsed += (s, e) => CheckCommands();
        commandTimer.Start();

        Print("JJCompanyBroAddon iniciado correctamente");
        SendAccounts();
        Task.Run(() => FlushClosedTradeOutbox());
    }
    catch (Exception ex)
    {
        Print("JJCompanyBroAddon Start error: " + ex.Message);
    }
}

        private void StopAddon()
        {
            try
            {
                lock (journalSync)
                {
                    foreach (Account account in subscribedAccounts)
                        account.ExecutionUpdate -= OnAccountExecutionUpdate;
                    subscribedAccounts.Clear();
                }

                if (accountTimer != null)
                {
                    accountTimer.Stop();
                    accountTimer.Dispose();
                    accountTimer = null;
                }

                if (commandTimer != null)
                {
                    commandTimer.Stop();
                    commandTimer.Dispose();
                    commandTimer = null;
                }

                Print("JJCompanyBroAddon detenido");
            }
            catch (Exception ex)
            {
                Print("JJCompanyBroAddon Stop error: " + ex.Message);
            }
        }

	private void LoadConfig()
{
    try
    {
        string configDir = Path.GetDirectoryName(configFile);

        if (!Directory.Exists(configDir))
            Directory.CreateDirectory(configDir);

        Print("BUSCANDO CONFIG EN: " + configFile);

        if (!File.Exists(configFile))
        {
            Print("JJ Config no encontrada. Addon pendiente de login.");
            return;
        }

        string json = File.ReadAllText(configFile);
Match userMatch = Regex.Match(
    json,
    "\"username\"\\s*:\\s*\"([^\"]+)\""
);

if (userMatch.Success)
    connectedUser = userMatch.Groups[1].Value;

        Match emailMatch = Regex.Match(
            json,
            "\\\"email\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""
        );

        if (emailMatch.Success)
            connectedEmail = emailMatch.Groups[1].Value;

        Match match = Regex.Match(
            json,
            "\"apiKey\"\\s*:\\s*\"([^\"]+)\""
        );

        if (match.Success)
        {
            apiKey = match.Groups[1].Value;
            Print("JJ API Key cargada correctamente");
			Print("JJ Conectado como: " + connectedUser);
        }
        else
        {
            Print("JJ Config encontrada pero sin apiKey");
        }
    }
    catch (Exception ex)
    {
        Print("JJ LoadConfig error: " + ex.Message);
    }
}

private void SaveConfig(
    string newApiKey,
    string username,
    string email)
{
    try
    {
        string configDir = Path.GetDirectoryName(configFile);

        if (!Directory.Exists(configDir))
            Directory.CreateDirectory(configDir);

        string json =
            "{" +
            "\"apiKey\":\"" + EscapeJson(newApiKey) + "\"," +
            "\"username\":\"" + EscapeJson(username) + "\"," +
            "\"email\":\"" + EscapeJson(email) + "\"," +
            "\"serverUrl\":\"" + EscapeJson(cloudBaseUrl) + "\"" +
            "}";

        File.WriteAllText(configFile, json);

        apiKey = newApiKey;
        connectedUser = username;
        connectedEmail = email;

        Print("JJ Config guardada correctamente");
    }
    catch (Exception ex)
    {
        Print("JJ SaveConfig error: " + ex.Message);
    }
}
private void LoginAddon(string username, string password)
{
    try
    {
        string json =
            "{" +
            "\"username\":\"" + EscapeJson(username) + "\"," +
            "\"password\":\"" + EscapeJson(password) + "\"" +
            "}";

        using (WebClient client = new WebClient())
        {
            client.Headers[HttpRequestHeader.ContentType] = "application/json";

            string response = client.UploadString(
                cloudBaseUrl + "/api/addon/login",
                "POST",
                json
            );
Match userMatch = Regex.Match(
    response,
    "\"username\"\\s*:\\s*\"([^\"]+)\""
);
Match emailMatch = Regex.Match(
    response,
    "\"email\"\\s*:\\s*\"([^\"]*)\""
);
            Match match = Regex.Match(
                response,
                "\"apiKey\"\\s*:\\s*\"([^\"]+)\""
            );

            if (match.Success)
            {
                string newApiKey = match.Groups[1].Value;
               string loggedUser =
    userMatch.Success
        ? userMatch.Groups[1].Value
        : username;

string loggedEmail =
    emailMatch.Success
        ? emailMatch.Groups[1].Value
        : (
            username.IndexOf("@", StringComparison.Ordinal) >= 0
                ? username
                : ""
          );

SaveConfig(
    newApiKey,
    loggedUser,
    loggedEmail
);
              Print("JJ Addon conectado correctamente");
StartAddon();
            }
            else
            {
                Print("JJ Login error: no se encontró apiKey en respuesta");
            }
        }
    }
    catch (Exception ex)
    {
        Print("JJ LoginAddon error: " + ex.Message);
    }
}
private void LogoutAddon()
{
    try
    {
        if (File.Exists(configFile))
            File.Delete(configFile);

        apiKey = "";
        connectedUser = "";
        connectedEmail = "";

        Print("JJ Sesión cerrada");

        ShowLoginWindow();
    }
    catch (Exception ex)
    {
        Print("JJ Logout error: " + ex.Message);
    }
}
        private void SendAccounts()
        {
            try
            {
				if (string.IsNullOrEmpty(apiKey))
{
    Print("JJ Addon no vinculado. Falta apiKey.");
    return;
}
                StringBuilder json = new StringBuilder();
                json.Append("{");
json.Append("\"apiKey\":\"" + apiKey + "\",");
json.Append("\"accounts\":[");

                bool first = true;

                foreach (Account account in Account.All)
                {
                    if (account == null)
                        continue;

                    string accountName = account.Name;

                    if (
                        accountName == "Backtest" ||
                        accountName == "Playback101" ||
                        accountName == "Sim101" ||
                        accountName == "SimAccount1"
                    )
                        continue;

                    int totalContracts = 0;
                    string positions = "";

                    foreach (Position pos in account.Positions)
                    {
                        if (pos == null || pos.MarketPosition == MarketPosition.Flat)
                            continue;

                        totalContracts += pos.Quantity;

                        positions += EscapeJson(pos.Instrument.FullName) + " " +
                                     pos.MarketPosition.ToString() + " x" +
                                     pos.Quantity.ToString() + " | ";
                    }

                    string broker = DetectBroker(accountName);

                    double balance = SafeGet(account, AccountItem.CashValue);
                    double realizedPnL = SafeGet(account, AccountItem.RealizedProfitLoss);

                    lock (journalSync)
                    {
                        if (!lastRealizedPnL.ContainsKey(accountName))
                            lastRealizedPnL[accountName] = realizedPnL;
                    }

                    double unrealizedPnL = SafeGet(account, AccountItem.UnrealizedProfitLoss);
                    double trailingMaxDrawdown = SafeGet(account, AccountItem.TrailingMaxDrawdown);

                    if (!first)
                        json.Append(",");

                    first = false;

                    json.Append("{");
                    json.Append("\"name\":\"" + EscapeJson(accountName) + "\",");
                    json.Append("\"broker\":\"" + EscapeJson(broker) + "\",");
                    json.Append("\"balance\":" + ToInvariant(balance) + ",");
                    json.Append("\"pnl\":" + ToInvariant(realizedPnL) + ",");
                    json.Append("\"unrealizedPnl\":" + ToInvariant(unrealizedPnL) + ",");
                    json.Append("\"remainingDrawdown\":" + ToInvariant(trailingMaxDrawdown) + ",");
                    json.Append("\"contracts\":" + totalContracts + ",");
                    json.Append("\"positions\":\"" + EscapeJson(positions) + "\",");
                    json.Append("\"connected\":true,");
                    json.Append("\"type\":\"slave\"");
                    json.Append("}");
                }

                json.Append("]}");

                PostJson(cloudBaseUrl + "/api/accounts/detect", json.ToString());
                Print("JJ Accounts sincronizadas");
            }
            catch (Exception ex)
            {
                Print("JJ SendAccounts error: " + ex.Message);
            }
        }

        private void OnAccountExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            // V1.7.87 - one execution at a time (several accounts fill at the same instant)
            lock (journalSync)
            {
                OnAccountExecutionUpdateCore(sender, e);
            }
        }

        private void OnAccountExecutionUpdateCore(object sender, ExecutionEventArgs e)
        {
            try
            {
                Account account = sender as Account;

                if (
                    account == null ||
                    e == null ||
                    e.Execution == null ||
                    e.Execution.Order == null ||
                    e.Execution.Instrument == null
                )
                    return;

                /*
                  Las órdenes creadas por el copiador se registran en la
                  cuenta master antes de ser copiadas. Las ejecuciones
                  JJ_COPY pertenecen a las cuentas slave y no deben
                  volver a generar una copia ni duplicar el Journal.
                */
             string rawOrderName =
    e.Execution.Order.Name == null
        ? ""
        : e.Execution.Order.Name;

/*
    Las ejecuciones JJ_COPY pertenecen a cuentas slave.

    IMPORTANTE:
    NO debemos ignorarlas porque también forman parte
    del rendimiento real de la cuenta y deben aparecer
    en Journal, Advanced Metrics y estadísticas.

    Lo único que debemos impedir es que una ejecución
    copiada vuelva a activar el copiador.
*/
bool isJjCopyExecution =
    rawOrderName.IndexOf(
        "JJ_COPY",
        StringComparison.OrdinalIgnoreCase
    ) >= 0;

                string executionId =
                    e.Execution.ExecutionId == null
                        ? ""
                        : e.Execution.ExecutionId;

                if (
                    !string.IsNullOrWhiteSpace(executionId) &&
                    sentExecutions.Contains(executionId)
                )
                    return;

                if (!string.IsNullOrWhiteSpace(executionId))
                    sentExecutions.Add(executionId);

                string symbol = e.Execution.Instrument.FullName;
                int executionQuantity = Math.Max(
                    1,
                    e.Execution.Quantity
                );
                double executionPrice = e.Execution.Price;
                DateTime executionTime = e.Execution.Time;

                string tradeKey =
                    account.Name + "|" + symbol;

                string orderAction =
                    e.Execution.Order.OrderAction
                        .ToString()
                        .ToUpperInvariant();

                Position currentPos = null;

                foreach (Position position in account.Positions)
                {
                    if (
                        position != null &&
                        position.Instrument != null &&
                        position.Instrument.FullName == symbol
                    )
                    {
                        currentPos = position;
                        break;
                    }
                }

                // V1.7.87 - position tracked from the fills (the broker position can still show
                // the old size when the execution event arrives).
                int trackedBefore;
                if (!trackedPositions.TryGetValue(tradeKey, out trackedBefore))
                    trackedBefore = 0;

                int trackedAfter =
                    trackedBefore +
                    (orderAction == "BUY" || orderAction == "BUYTOCOVER"
                        ? executionQuantity
                        : -executionQuantity);

                trackedPositions[tradeKey] = trackedAfter;
                trackedLastExecUtc[tradeKey] = DateTime.UtcNow;

                bool isFlatAfterExecution =
                    trackedAfter == 0;

                bool isEntryAction =
                    orderAction == "BUY" ||
                    orderAction == "SELLSHORT";

                bool isExitAction =
                    orderAction == "SELL" ||
                    orderAction == "BUYTOCOVER";

                /*
                  Registrar la ejecución normal para el estado en vivo.
                  Una salida parcial sigue siendo SELL/BUYTOCOVER.
                  Solo la salida que deja la posición Flat se registra
                  como CLOSE en el Journal.
                */
                string actionForRecord =
                    isExitAction && isFlatAfterExecution
                        ? "CLOSE"
                        : orderAction;

                /*
                  Cuando una salida JJ_COPY se ejecuta, liberar la cantidad
                  que estaba reservada como "in-flight". Si quedó Flat,
                  limpiar toda la reserva de esa cuenta+instrumento.
                */
                if (isJjCopyExecution && isExitAction)
                {
                    ReleaseCopyExitReservation(
                        account.Name,
                        symbol,
                        executionQuantity,
                        isFlatAfterExecution
                    );
                }

                BotPerformancePosition performancePosition;
                botPerformancePositions.TryGetValue(tradeKey, out performancePosition);
                if (isEntryAction)
                {
                    if (performancePosition == null)
                    {
                        performancePosition = new BotPerformancePosition();
                        performancePosition.Direction = orderAction == "BUY" ? 1 : -1;
                        // If the listener started in an existing position, ownership is incomplete.
                        performancePosition.ExclusiveBot = trackedBefore == 0;
                        botPerformancePositions[tradeKey] = performancePosition;
                    }
                    bool botEntry = System.Text.RegularExpressions.Regex.IsMatch(rawOrderName,
                        @"^P[1-5]_JJ_(ENTRY|SCALE_IN)_(LONG|SHORT)$",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    if (performancePosition.EntryTime == DateTime.MinValue) performancePosition.EntryTime = executionTime;
                    lastEntryTimes[tradeKey] = lastEntryTimes.ContainsKey(tradeKey) && trackedBefore != 0 ? lastEntryTimes[tradeKey] : executionTime;
                    lastEntryDirections[tradeKey] = orderAction == "BUY" ? 1 : -1;
                    if (trackedBefore == 0 || !lastEntryModules.ContainsKey(tradeKey))
                        lastEntryModules[tradeKey] = botEntry ? JJBotEntryModuleRegistry.Lookup(account.Name) : string.Empty;
                    performancePosition.Entry(executionQuantity, executionPrice, JournalExecutionFee(account, e.Execution.Instrument, e.Execution.Commission, executionQuantity),
                        orderAction == "BUY" ? 1 : -1, botEntry,
                        trackedBefore == 0);
                }
                else if (isExitAction && performancePosition != null)
                {
                    performancePosition.Exit(executionQuantity, executionPrice, JournalExecutionFee(account, e.Execution.Instrument, e.Execution.Commission, executionQuantity),
                        e.Execution.Instrument.MasterInstrument.PointValue);
                }

                if (isEntryAction)
                {
                    int previousQuantity =
                        entryQuantities.ContainsKey(tradeKey)
                            ? entryQuantities[tradeKey]
                            : 0;

                    double previousAverage =
                        entryPrices.ContainsKey(tradeKey)
                            ? entryPrices[tradeKey]
                            : 0;

                    int newQuantity =
                        previousQuantity + executionQuantity;

                    double newAverage =
                        newQuantity > 0
                            ? (
                                previousAverage *
                                    previousQuantity +
                                executionPrice *
                                    executionQuantity
                              ) / newQuantity
                            : executionPrice;

                    entryQuantities[tradeKey] = newQuantity;
                    entryPrices[tradeKey] = newAverage;

                    /*
                      Guardar el PnL realizado de la cuenta al inicio de
                      esta posición. Luego, al quedar Flat, la diferencia
                      será el PnL real completo del trade.
                    */
                    if (
                        !tradeStartRealizedPnL.ContainsKey(
                            tradeKey
                        )
                    )
                    {
                        tradeStartRealizedPnL[tradeKey] =
                            SafeGet(
                                account,
                                AccountItem.RealizedProfitLoss
                            );
                    }
                }

         /*
    Solo las ejecuciones originales pueden entrar
    al motor de copy trading.

    Las JJ_COPY sí se siguen procesando para Journal,
    pero NO se vuelven a enviar a /api/trades/record.
*/
if (!isJjCopyExecution)
{
    /*
      /api/trades/record alimenta el COPY TRADING.
      Debe recibir la acción REAL de cada execution (SELL/BUYTOCOVER)
      y su cantidad exacta. Convertir el último partial fill a CLOSE
      hacía que el slave intentara cerrar toda la posición otra vez.
      El Journal de trades cerrados se maneja por SendClosedTrade().
    */
    SendTrade(
        account.Name,
        symbol,
        orderAction,
        executionQuantity,
        executionPrice,
        executionTime
    );
}

                /*
                  No enviar closed trade en salidas parciales.
                  Esperar hasta que la posición completa quede Flat.
                */
                if (!isExitAction || !isFlatAfterExecution)
                    return;

                // Persist exact bot close BEFORE the legacy manual-PnL delay/time lock.
                // Final exchange execution identity deduplicates rapid distinct roundtrips.
                bool completeBotClose = performancePosition != null && performancePosition.ExclusiveBot &&
                    performancePosition.OpenQuantity == 0;
                if (completeBotClose)
                {
                    string botCloseId = account.Name + "|" + symbol + "|" +
                        (string.IsNullOrWhiteSpace(executionId) ? executionTime.Ticks.ToString() : executionId);
                    if (!sentClosedTradeIds.Contains(botCloseId))
                    {
                        SendClosedTrade(account.Name, symbol, "CLOSE",
                            entryQuantities.ContainsKey(tradeKey) ? entryQuantities[tradeKey] : executionQuantity,
                            performancePosition.Gross - performancePosition.Fees,
                            entryPrices.ContainsKey(tradeKey) ? entryPrices[tradeKey] : 0,
                            executionPrice, botCloseId, executionTime, true,
                            performancePosition.Gross, performancePosition.Fees,
                            performancePosition.EntryTime, performancePosition.Direction,
                            lastEntryModules.ContainsKey(tradeKey) ? lastEntryModules[tradeKey] : string.Empty);
                        // SendClosedTrade returns only after the payload is safely queued.
                        sentClosedTradeIds.Add(botCloseId);
                    }
                    botPerformancePositions.Remove(tradeKey);
                    entryPrices.Remove(tradeKey);
                    entryQuantities.Remove(tradeKey);
                    tradeStartRealizedPnL.Remove(tradeKey);
                    return;
                }

                botPerformancePositions.Remove(tradeKey);
                string closeLockKey =
                    tradeKey + "|CLOSE_LOCK";

                if (
                    recentCloseTimes.ContainsKey(closeLockKey) &&
                    (
                        DateTime.Now -
                        recentCloseTimes[closeLockKey]
                    ).TotalSeconds <= 10
                )
                {
                    Print(
                        "Cierre Flat repetido bloqueado: " +
                        account.Name + " " + symbol
                    );
                    return;
                }

                recentCloseTimes[closeLockKey] = DateTime.Now;

                double entryPrice =
                    entryPrices.ContainsKey(tradeKey)
                        ? entryPrices[tradeKey]
                        : 0;

                int closedQuantity =
                    entryQuantities.ContainsKey(tradeKey)
                        ? entryQuantities[tradeKey]
                        : executionQuantity;

                double startRealized =
                    tradeStartRealizedPnL.ContainsKey(tradeKey)
                        ? tradeStartRealizedPnL[tradeKey]
                        : (
                            lastRealizedPnL.ContainsKey(
                                account.Name
                            )
                                ? lastRealizedPnL[
                                    account.Name
                                  ]
                                : SafeGet(
                                    account,
                                    AccountItem.RealizedProfitLoss
                                  )
                          );

                double exitPrice = executionPrice;

                string closedTradeId =
                    account.Name + "|" +
                    symbol + "|" +
                    (
                        string.IsNullOrWhiteSpace(executionId)
                            ? executionTime.Ticks.ToString()
                            : executionId
                    );

                bool attributedBot = performancePosition != null && performancePosition.ExclusiveBot &&
                    performancePosition.OpenQuantity == 0;
                double botGross = attributedBot ? performancePosition.Gross : 0;
                double botFees = attributedBot ? performancePosition.Fees : 0;

                // V1.7.87 - PnL of this round trip from its own fills (fallback when the broker
                // updates Realized PnL late).
                bool haveFillPnl = performancePosition != null && performancePosition.CompleteFromFlat && performancePosition.OpenQuantity == 0;
                double fillNetPnl = haveFillPnl ? performancePosition.Gross - performancePosition.Fees : 0;
                DateTime closeEntryTime = lastEntryTimes.ContainsKey(tradeKey) ? lastEntryTimes[tradeKey] : DateTime.MinValue;
                int closeDirection = lastEntryDirections.ContainsKey(tradeKey) ? lastEntryDirections[tradeKey] : 0;
                string closeModule = lastEntryModules.ContainsKey(tradeKey) ? lastEntryModules[tradeKey] : string.Empty;
                botPerformancePositions.Remove(tradeKey);

                Task.Delay(1500).ContinueWith(task =>
                {
                    lock (journalSync)
                    try
                    {
                        if (
                            sentClosedTradeIds.Contains(
                                closedTradeId
                            )
                        )
                            return;

                        double currentRealized =
                            SafeGet(
                                account,
                                AccountItem.RealizedProfitLoss
                            );

                        // Prefer this round trip's executions even when the result is zero.
                        // Account-wide realized PnL can include earlier trades or other instruments.
                        double tradePnL = JJManualJournalPnl.Resolve(
                            haveFillPnl, fillNetPnl, currentRealized, startRealized);

                        lastRealizedPnL[account.Name] =
                            currentRealized;

                        if (!attributedBot && !haveFillPnl && Math.Abs(tradePnL) < 0.0000001)
                        {
                            Print(
                                "Trade cerrado sin cambio de PnL: " +
                                account.Name + " " + symbol
                            );
                            return;
                        }

                        sentClosedTradeIds.Add(closedTradeId);

               SendClosedTrade(
    account.Name,
    symbol,
    "CLOSE",
    closedQuantity,
    tradePnL,
    entryPrice,
    exitPrice,
    closedTradeId,
    executionTime,
    attributedBot, botGross, botFees,
    closeEntryTime, closeDirection, closeModule
);

                        entryPrices.Remove(tradeKey);
                        entryQuantities.Remove(tradeKey);
                        tradeStartRealizedPnL.Remove(tradeKey);
                    }
                    catch (Exception ex)
                    {
                        Print(
                            "ERROR delay closed trade: " +
                            ex.Message
                        );
                    }
                });
            }
            catch (Exception ex)
            {
                Print(
                    "JJ Trade listener error: " +
                    ex.Message
                );
            }
        }

		private void ShowLoginWindow()
{
    try
    {
		if (!string.IsNullOrEmpty(apiKey))
{
    MessageBox.Show(
        "Conectado como: " + connectedUser,
        "J&J Company Bro"
    );
    return;
}
        if (loginWindow != null)
            return;

        loginWindow = new NTWindow();
        loginWindow.Caption = "J&J Company Bro Login";
        loginWindow.Width = 360;
        loginWindow.Height = 260;
        loginWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;

        StackPanel panel = new StackPanel();
        panel.Margin = new Thickness(20);

        TextBlock title = new TextBlock();
        title.Text = "Conectar Addon";
        title.FontSize = 20;
        title.Margin = new Thickness(0, 0, 0, 15);

        usernameBox = new TextBox();
        usernameBox.Height = 32;
        usernameBox.Margin = new Thickness(0, 0, 0, 10);
        usernameBox.Text = "";

        passwordBox = new PasswordBox();
        passwordBox.Height = 32;
        passwordBox.Margin = new Thickness(0, 0, 0, 15);

        Button loginButton = new Button();
        loginButton.Content = "Conectar";
        loginButton.Height = 36;

        loginButton.Click += (s, e) =>
        {
            string username = usernameBox.Text;
            string password = passwordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                Print("JJ Login: usuario y contraseña requeridos");
                return;
            }

            LoginAddon(username, password);

            if (!string.IsNullOrEmpty(apiKey))
            {
                loginWindow.Close();
                loginWindow = null;
            }
        };
		Button logoutButton = new Button();
logoutButton.Content = "Cambiar Cuenta";
logoutButton.Height = 36;
logoutButton.Margin = new Thickness(0, 10, 0, 0);

logoutButton.Click += (s, e) =>
{
    LogoutAddon();
};

        panel.Children.Add(title);

        panel.Children.Add(new TextBlock { Text = "Usuario o Email" });
        panel.Children.Add(usernameBox);

        panel.Children.Add(new TextBlock { Text = "Contraseña" });
        panel.Children.Add(passwordBox);

        panel.Children.Add(loginButton);
panel.Children.Add(logoutButton);
        loginWindow.Content = panel;
        loginWindow.Show();
    }
    catch (Exception ex)
    {
        Print("JJ ShowLoginWindow error: " + ex.Message);
    }
}

       private void SendTrade(string accountName, string symbol, string action, int quantity, double price, DateTime time)
{
    try
    {
		if (string.IsNullOrEmpty(apiKey))
{
    Print("JJ Trade no enviado. Falta apiKey.");
    return;
}
     string json =
    "{" +
    "\"apiKey\":\"" + apiKey + "\"," +
            "\"account\":\"" + EscapeJson(accountName) + "\"," +
            "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
            "\"action\":\"" + EscapeJson(action) + "\"," +
            "\"quantity\":" + quantity + "," +
            "\"price\":" + ToInvariant(price) + "," +
            "\"time\":\"" + time.ToString("o") + "\"" +
            "}";

        // Ya no enviamos las ejecuciones reales a /api/copier/execute.
        // Esa ruta es para comandos del backend hacia Ninja, no para registrar trades.
        TryPostJson(localBaseUrl + "/api/trades/record", json);

        Print("Trade enviado a J&J: " + accountName + " " + symbol + " " + action + " x" + quantity + " @" + price);
    }
    catch (Exception ex)
    {
        Print("JJ SendTrade error: " + ex.Message);
    }
}

     private void SendClosedTrade(
    string accountName,
    string symbol,
    string side,
    int quantity,
    double pnl,
    double entryPrice,
    double exitPrice,
    string tradeId,
    DateTime closedAt,
    bool attributedBot, double botGross, double botFees,
    DateTime entryTime = default(DateTime), int direction = 0, string module = null
)
        {
            try
            {
                if (string.IsNullOrEmpty(apiKey))
                {
                    Print(
                        "JJ ClosedTrade no enviado. Falta apiKey."
                    );
                    return;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" +
                        EscapeJson(apiKey) + "\"," +
                    "\"tradeId\":\"" +
                        EscapeJson(tradeId) + "\"," +
                    "\"account\":\"" +
                        EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" +
                        EscapeJson(symbol) + "\"," +
                    "\"side\":\"" +
                        EscapeJson(side) + "\"," +
                    "\"quantity\":" +
                        quantity + "," +
                    "\"entryPrice\":" +
                        ToInvariant(entryPrice) + "," +
                 "\"exitPrice\":" +
    ToInvariant(exitPrice) + "," +
"\"pnl\":" +
    ToInvariant(pnl) + "," +
"\"closedAt\":\"" +
    closedAt.ToString("o") + "\"," +
"\"botAttribution\":\"" + (attributedBot ? "JJ_BOT_ENTRY_EXECUTIONS_V1" : "UNATTRIBUTED") + "\"," +
"\"botGrossPnl\":" + ToInvariant(botGross) + "," +
"\"botFees\":" + ToInvariant(botFees) + "," +
"\"botNetPnl\":" + ToInvariant(botGross - botFees) + "," +
"\"entryTime\":\"" + (entryTime == default(DateTime) ? "" : entryTime.ToString("o")) + "\"," +
"\"direction\":\"" + (direction > 0 ? "LONG" : direction < 0 ? "SHORT" : "") + "\"," +
"\"module\":\"" + (!string.IsNullOrEmpty(module) ? module : JournalModuleFor(entryTime == default(DateTime) ? closedAt : entryTime)) + "\"" +
"}";

                QueueClosedTrade(tradeId, json);
                Task.Run(() => FlushClosedTradeOutbox());

                Print(
                    "TRADE CERRADO ENVIADO: " +
                    symbol +
                    " PnL=" +
                    pnl +
                    " ID=" +
                    tradeId
                );
            }
            catch (Exception ex)
            {
                Print(
                    "ERROR ENVIANDO TRADE CERRADO: " +
                    ex.Message
                );
                throw;
            }
        }

        // V1.0.33 - which bot module opened the trade, by NinjaTrader (New York) entry time,
        // same windows as the bot in COMBINED: Open Bell 09:29:58 entry, Gerard evaluates
        // 09:35-09:40 (both managed to 10:00), Hybrid from 10:00.
        private static string JournalModuleFor(DateTime when)
        {
            if (when == default(DateTime)) return "";
            TimeSpan t = when.TimeOfDay;
            if (t >= new TimeSpan(9, 29, 0) && t < new TimeSpan(9, 35, 0)) return "OPEN_BELL";
            if (t >= new TimeSpan(9, 35, 0) && t < new TimeSpan(10, 0, 0)) return "GERARD";
            return "HYBRID";
        }

        private void QueueClosedTrade(string tradeId, string json)
        {
            lock (closedTradeOutboxLock)
            {
                Directory.CreateDirectory(closedTradeOutboxDirectory);
                string digest;
                using (var sha = System.Security.Cryptography.SHA256.Create())
                    digest = BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(apiKey + "|" + tradeId))).Replace("-", "");
                string destination = Path.Combine(closedTradeOutboxDirectory,digest + ".json");
                if (File.Exists(destination)) return;
                string temporary = destination + ".tmp";
                // Flush to disk before acknowledging this close or clearing the position tracker.
                using (var stream = new FileStream(temporary,FileMode.Create,FileAccess.Write,FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(json);
                    stream.Write(bytes,0,bytes.Length);
                    stream.Flush(true);
                }
                File.Move(temporary,destination);
            }
        }

        private bool PostClosedTradeAcknowledged(string baseUrl, string json)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string response = client.UploadString(baseUrl + "/api/trades/closed/send","POST",json);
                    return Regex.IsMatch(response, @"""success""\s*:\s*true",RegexOptions.IgnoreCase);
                }
            }
            catch { return false; }
        }

        private void FlushClosedTradeOutbox()
        {
            if (Interlocked.Exchange(ref closedTradeFlushInProgress,1) == 1) return;
            try
            {
                if (!Directory.Exists(closedTradeOutboxDirectory)) return;
                foreach (string pending in Directory.GetFiles(closedTradeOutboxDirectory,"*.json"))
                {
                    string json = File.ReadAllText(pending);
                    string localAck = pending + ".local-ack";
                    string cloudAck = pending + ".cloud-ack";
                    bool localSaved = File.Exists(localAck);
                    bool cloudSaved = File.Exists(cloudAck);
                    if (!localSaved && PostClosedTradeAcknowledged(localBaseUrl,json))
                    { File.WriteAllText(localAck,"ack"); localSaved = true; }
                    if (!cloudSaved && PostClosedTradeAcknowledged(cloudBaseUrl,json))
                    { File.WriteAllText(cloudAck,"ack"); cloudSaved = true; }
                    if (localSaved && cloudSaved)
                    { File.Delete(pending); File.Delete(localAck); File.Delete(cloudAck); }
                }
            }
            catch (Exception ex) { Print("Closed trade outbox retained for retry: " + ex.Message); }
            finally { Interlocked.Exchange(ref closedTradeFlushInProgress,0); }
        }

        private void CheckCommands()
        {
            if (Interlocked.Exchange(ref commandCheckInProgress, 1) == 1)
                return;

            try
            {
                if (string.IsNullOrWhiteSpace(apiKey))
                {
                    Print("JJ comandos no consultados. Falta apiKey.");
                    return;
                }

                string commandsUrl =
                    localBaseUrl.TrimEnd('/') +
                    "/api/ninja/commands?apiKey=" +
                    Uri.EscapeDataString(apiKey);

                // The backend returns one queued command per GET. Drain every
                // available command now so slaves do not wait for another tick.
                for (int i = 0; i < MaxCommandsPerPollCycle; i++)
                {
                    string json;

                    using (WebClient client = new WebClient())
                    {
                        json = client.DownloadString(commandsUrl);
                    }

                    if (string.IsNullOrWhiteSpace(json) || json.Trim() == "[]")
                        break;

                    if (json.Contains("COPY_TRADE"))
                    {
                        string targetAccount = ExtractValue(json, "\"account\":\"");
                        string symbol = ExtractValue(json, "\"symbol\":\"");
                        string actionText = ExtractValue(json, "\"action\":\"").ToUpperInvariant();
                        int quantity = ExtractInt(json, "\"quantity\":");

                        ExecuteCopyTrade(targetAccount, symbol, actionText, quantity);
                        continue;
                    }

                    if (json.Contains("PANIC_CLOSE_ACCOUNT"))
                    {
                        string targetAccount = ExtractValue(json, "\"account\":\"");
                        ExecutePanicCloseAccount(targetAccount);
                        continue;
                    }

                    if (json.Contains("PANIC_CLOSE"))
                    {
                        ExecutePanicClose(json);
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Print("Error leyendo comandos J&J: " + ex.Message);
            }
            finally
            {
                Interlocked.Exchange(ref commandCheckInProgress, 0);
            }
        }

        private int ReserveCopyExitQuantity(
            string accountName,
            string symbol,
            int requestedQuantity,
            int currentPositionQuantity
        )
        {
            string key = accountName + "|" + symbol;

            lock (copyExitSync)
            {
                DateTime lastUpdate;
                if (
                    pendingCopyExitTimes.TryGetValue(key, out lastUpdate) &&
                    (DateTime.UtcNow - lastUpdate).TotalSeconds > 10
                )
                {
                    // Market exits should resolve quickly. Clear a stale reservation
                    // so a rejected/disconnected order cannot block future protection.
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                }

                int pending = 0;
                pendingCopyExitQuantities.TryGetValue(key, out pending);

                int available = Math.Max(
                    0,
                    currentPositionQuantity - pending
                );

                int requested = Math.Max(0, requestedQuantity);
                int reserved = Math.Min(requested, available);

                if (reserved <= 0)
                    return 0;

                pendingCopyExitQuantities[key] = pending + reserved;
                pendingCopyExitTimes[key] = DateTime.UtcNow;

                return reserved;
            }
        }

        private void ReleaseCopyExitReservation(
            string accountName,
            string symbol,
            int executedQuantity,
            bool isFlat
        )
        {
            string key = accountName + "|" + symbol;

            lock (copyExitSync)
            {
                if (isFlat)
                {
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                    return;
                }

                int pending = 0;
                if (!pendingCopyExitQuantities.TryGetValue(key, out pending))
                    return;

                pending = Math.Max(
                    0,
                    pending - Math.Max(0, executedQuantity)
                );

                if (pending <= 0)
                {
                    pendingCopyExitQuantities.Remove(key);
                    pendingCopyExitTimes.Remove(key);
                }
                else
                {
                    pendingCopyExitQuantities[key] = pending;
                    pendingCopyExitTimes[key] = DateTime.UtcNow;
                }
            }
        }

        private void ExecuteCopyTrade(string targetAccount, string symbol, string actionText, int quantity)
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    if (account.Name != targetAccount)
                        continue;

                    Instrument instrument = Instrument.GetInstrument(symbol);

                    if (instrument == null)
                    {
                        Print("Instrumento no encontrado: " + symbol);
                        return;
                    }

                    Position currentPos = null;

                    foreach (Position p in account.Positions)
                    {
                        if (p != null && p.Instrument.FullName == symbol)
                        {
                            currentPos = p;
                            break;
                        }
                    }

                    MarketPosition currentPosition = currentPos == null
                        ? MarketPosition.Flat
                        : currentPos.MarketPosition;

                    int currentQty = currentPos == null ? 0 : currentPos.Quantity;
                    actionText = (actionText ?? "").ToUpperInvariant();

                    /*
                      EXIT SAFETY:
                      SELL / BUYTOCOVER from the master are execution-sized exits.
                      Never replace their quantity with the slave's full position.
                      Also reserve in-flight quantity so rapid partial fills cannot
                      over-close and reverse the slave before Ninja updates Position.
                    */
                    if (
                        actionText == "CLOSE" ||
                        actionText == "SELL" ||
                        actionText == "BUYTOCOVER"
                    )
                    {
                        if (currentPosition == MarketPosition.Flat || currentQty <= 0)
                        {
                            Print(
                                "EXIT ignorado: " +
                                account.Name + " ya esta Flat en " + symbol
                            );
                            SendPositionUpdateAsync(
                                account.Name,
                                symbol,
                                "FLAT",
                                0
                            );
                            return;
                        }

                        OrderAction exitAction;
                        int requestedExitQty;

                        if (actionText == "CLOSE")
                        {
                            exitAction =
                                currentPosition == MarketPosition.Long
                                    ? OrderAction.Sell
                                    : OrderAction.BuyToCover;

                            requestedExitQty = currentQty;
                        }
                        else if (actionText == "SELL")
                        {
                            if (currentPosition != MarketPosition.Long)
                            {
                                Print(
                                    "SELL ignorado: no hay Long para cerrar en " +
                                    account.Name + " " + symbol
                                );
                                return;
                            }

                            exitAction = OrderAction.Sell;
                            requestedExitQty = Math.Max(1, quantity);
                        }
                        else
                        {
                            if (currentPosition != MarketPosition.Short)
                            {
                                Print(
                                    "BUYTOCOVER ignorado: no hay Short para cerrar en " +
                                    account.Name + " " + symbol
                                );
                                return;
                            }

                            exitAction = OrderAction.BuyToCover;
                            requestedExitQty = Math.Max(1, quantity);
                        }

                        int safeExitQty = ReserveCopyExitQuantity(
                            account.Name,
                            symbol,
                            requestedExitQty,
                            currentQty
                        );

                        if (safeExitQty <= 0)
                        {
                            Print(
                                "EXIT BLOQUEADO - cantidad ya en vuelo: " +
                                account.Name + " " + symbol +
                                " | Requested=" + requestedExitQty +
                                " | Position=" + currentQty
                            );
                            return;
                        }

                        try
                        {
                            Order exitOrder = account.CreateOrder(
                                instrument,
                                exitAction,
                                OrderType.Market,
                                OrderEntry.Automated,
                                TimeInForce.Day,
                                safeExitQty,
                                0,
                                0,
                                "",
                                "JJ_COPY_EXIT_" + DateTime.Now.Ticks,
                                DateTime.MaxValue,
                                null
                            );

                            account.Submit(new[] { exitOrder });
                        }
                        catch
                        {
                            // Submission failed before an execution could release it.
                            ReleaseCopyExitReservation(
                                account.Name,
                                symbol,
                                safeExitQty,
                                false
                            );
                            throw;
                        }

                        SendPositionUpdateAsync(
                            account.Name,
                            symbol,
                            "CLOSE",
                            safeExitQty
                        );

                        Print(
                            "EXIT ENVIADO A SLAVE: " +
                            account.Name + " " +
                            exitAction + " x" +
                            safeExitQty + " " + symbol
                        );
                        return;
                    }

                    OrderAction action;

                    if (actionText == "BUY")
                    {
                        action = OrderAction.Buy;
                    }
                    else if (actionText == "SELLSHORT")
                    {
                        action = OrderAction.SellShort;
                    }
                    else
                    {
                        Print("Accion no reconocida: " + actionText);
                        return;
                    }

                    int finalQuantity = quantity <= 0 ? 1 : quantity;

                    Order order = account.CreateOrder(
                        instrument,
                        action,
                        OrderType.Market,
                        OrderEntry.Automated,
                        TimeInForce.Day,
                        finalQuantity,
                        0,
                        0,
                        "",
                        "JJ_COPY_" + DateTime.Now.Ticks,
                        DateTime.MaxValue,
                        null
                    );

                    account.Submit(new[] { order });

                    SendPositionUpdateAsync(
                        account.Name,
                        symbol,
                        actionText,
                        finalQuantity
                    );

                    Print(
                        "ORDEN ENVIADA A SLAVE: " +
                        account.Name + " " +
                        action + " x" +
                        finalQuantity + " " + symbol
                    );
                    return;
                }

                Print("Cuenta destino no encontrada: " + targetAccount);
            }
            catch (Exception ex)
            {
                Print("ERROR ExecuteCopyTrade: " + ex.Message);
            }
        }

        private void ExecutePanicCloseAccount(string targetAccount)
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    if (account == null || !string.Equals(account.Name, targetAccount, StringComparison.OrdinalIgnoreCase))
                        continue;

                    foreach (Position p in account.Positions)
                    {
                        if (p != null && p.Instrument != null && p.MarketPosition != MarketPosition.Flat)
                        {
                            account.Flatten(new Instrument[] { p.Instrument });
                            SendPositionUpdateAsync(account.Name, p.Instrument.FullName, "CLOSE", p.Quantity);
                        }
                    }

                    Print("PANIC CLOSE ACCOUNT ejecutado: " + targetAccount);
                    return;
                }

                Print("PANIC CLOSE ACCOUNT no encontró cuenta: " + targetAccount);
            }
            catch (Exception ex)
            {
                Print("PANIC CLOSE ACCOUNT error: " + ex.Message);
            }
        }

        private void ExecutePanicClose(string json)
        {
            try
            {
                foreach (Account account in Account.All)
                {
                    foreach (Position p in account.Positions)
                    {
                        if (p.MarketPosition != MarketPosition.Flat)
                        {
                            account.Flatten(new Instrument[] { p.Instrument });
                            SendPositionUpdate(account.Name, p.Instrument.FullName, "CLOSE", p.Quantity);
                        }
                    }
                }

                Print("PANIC CLOSE ejecutado");
            }
            catch (Exception ex)
            {
                Print("PANIC CLOSE error: " + ex.Message);
            }
        }

        private void SendPositionUpdateAsync(string accountName, string symbol, string action, int quantity)
        {
            // Bookkeeping HTTP must not stall submission of the next slave.
            Task.Run(() => SendPositionUpdate(accountName, symbol, action, quantity));
        }

        private void SendPositionUpdate(string accountName, string symbol, string action, int quantity)
        {
            try
            {
                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"account\":\"" + EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
                    "\"action\":\"" + EscapeJson(action) + "\"," +
                    "\"quantity\":" + quantity +
                    "}";

                PostJson(
                    cloudBaseUrl + "/api/accounts/position-update",
                    json
                );
            }
            catch (Exception ex)
            {
                Print("Error enviando POSITION UPDATE: " + ex.Message);
            }
        }

        private void PostJson(string url, string json)
        {
            using (WebClient client = new WebClient())
            {
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                client.UploadString(url, "POST", json);
            }
        }

        private void TryPostJson(string url, string json)
        {
            try
            {
                PostJson(url, json);
            }
            catch (Exception ex)
            {
                Print("Ruta no disponible: " + url + " / " + ex.Message);
            }
        }

        private double SafeGet(Account account, AccountItem item)
        {
            try
            {
                return account.Get(item, Currency.UsDollar);
            }
            catch
            {
                return 0;
            }
        }

        private string DetectBroker(string accountName)
        {
            if (accountName.Contains("APEX"))
                return "Apex";

            if (accountName.Contains("MFFU"))
                return "MyFundedFutures";

            if (accountName.Contains("TDFY") || accountName.Contains("TDFYSL") || accountName.Contains("GCUPTDFY"))
                return "Tradefy";

            if (accountName.Contains("LFE") || accountName.Contains("LTE") || accountName.Contains("LFF"))
                return "Lucid";

            return "NinjaTrader";
        }

        private string EscapeJson(string value)
        {
            if (value == null)
                return "";

            return value.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private string ToInvariant(double value)
        {
            return value.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        private string ExtractValue(string json, string marker)
        {
            int start = json.IndexOf(marker);

            if (start < 0)
                return "";

            start += marker.Length;
            int end = json.IndexOf("\"", start);

            if (end < 0)
                return "";

            return json.Substring(start, end - start);
        }

        private int ExtractInt(string json, string marker)
        {
            int start = json.IndexOf(marker);

            if (start < 0)
                return 1;

            start += marker.Length;
            int end = json.IndexOfAny(new char[] { ',', '}' }, start);

            if (end < 0)
                return 1;

            string value = json.Substring(start, end - start).Trim();
            int result;

            if (int.TryParse(value, out result))
                return result;

            return 1;
        }
    }
}

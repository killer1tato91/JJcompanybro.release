// JJ_COPY_SYNC_GUARD_V1 (2026-10-31)
// Copy trading safety net, like Tradecopia / CrossTrade "drift protection":
//   1) the master is FLAT but a slave still holds a copied position -> flatten the slave
//      (a lost / rejected copy exit no longer leaves an orphan position on a funded account);
//   2) a slave holds a copied position in the OPPOSITE direction of its master (taking
//      "reverse copy" into account) -> flatten the slave; the next master trade copies again.
// Only positions OPENED BY THE COPIER (JJ_COPY fills) are touched, never a position the bot
// or the user opened on that account. It acts only while the copier is ON, the group and the
// slave are enabled and the slave copies exits. A mismatch must last 3 s (copies in flight
// settle in < 1 s) before anything is closed. Groups come from the local backend
// (/api/copier/sync-map, plain text) every 3 s.
// V2 (same day):
//   3) OVER-SIZE: a copied slave bigger than it should be is trimmed (never enlarged):
//      - above its "max contracts" (any mode), or
//      - "same size" mode and bigger than the master.
//   4) Micro slaves (NQ->MNQ, ES->MES...) are compared with the master's mini contract.
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJCompanyBroAddon
    {
        private const double CopySyncGraceSeconds = 3.0;
        private const double CopySyncMapRefreshSeconds = 3.0;

        private System.Timers.Timer copySyncTimer;
        private int copySyncInProgress = 0;

        // account|instrument -> last JJ_COPY fill (position was opened/changed by the copier)
        private readonly ConcurrentDictionary<string, DateTime> copyOwnedPositions =
            new ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        // account|instrument -> first time the mismatch was seen
        private readonly ConcurrentDictionary<string, DateTime> copySyncMismatchSince =
            new ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        private class CopySyncRoute
        {
            public string Master;
            public string Slave;
            public bool Reverse;
            public string Mode = "SAME";
            public int MaxContracts = 0;
            public bool Micro = false;
        }

        // micro -> mini root (the master trades the mini, the slave the micro)
        private static readonly Dictionary<string, string> CopySyncMicroToMini =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "MNQ", "NQ" }, { "MES", "ES" }, { "MYM", "YM" },
                { "M2K", "RTY" }, { "MGC", "GC" }, { "MCL", "CL" }
            };

        private static string CopySyncMasterInstrumentFor(string slaveInstrument, bool micro)
        {
            if (!micro || string.IsNullOrWhiteSpace(slaveInstrument)) return slaveInstrument;
            int space = slaveInstrument.IndexOf(' ');
            string root = space > 0 ? slaveInstrument.Substring(0, space) : slaveInstrument;
            string rest = space > 0 ? slaveInstrument.Substring(space) : "";
            string mini;
            return CopySyncMicroToMini.TryGetValue(root, out mini) ? mini + rest : slaveInstrument;
        }

        private List<CopySyncRoute> copySyncRoutes = new List<CopySyncRoute>();
        private bool copySyncCopierEnabled = false;
        private DateTime copySyncMapLoadedUtc = DateTime.MinValue;

        private void MarkCopyOwnedPosition(string accountName, string instrumentFullName)
        {
            if (string.IsNullOrWhiteSpace(accountName) || string.IsNullOrWhiteSpace(instrumentFullName))
                return;
            copyOwnedPositions[accountName + "|" + instrumentFullName] = DateTime.UtcNow;
        }

        private void StartCopySyncGuard()
        {
            try
            {
                if (copySyncTimer != null) return;
                copySyncTimer = new System.Timers.Timer(1000);
                copySyncTimer.AutoReset = true;
                copySyncTimer.Elapsed += (s, e) => RunCopySyncGuard();
                copySyncTimer.Start();
                Print("JJ COPY SYNC GUARD iniciado (cierra posiciones copiadas huerfanas o contrarias a la master)");
            }
            catch (Exception ex)
            {
                Print("JJ COPY SYNC GUARD start error: " + ex.Message);
            }
        }

        private void StopCopySyncGuard()
        {
            try
            {
                if (copySyncTimer == null) return;
                copySyncTimer.Stop();
                copySyncTimer.Dispose();
                copySyncTimer = null;
            }
            catch { }
        }

        private void RefreshCopySyncMap()
        {
            if ((DateTime.UtcNow - copySyncMapLoadedUtc).TotalSeconds < CopySyncMapRefreshSeconds)
                return;
            copySyncMapLoadedUtc = DateTime.UtcNow;

            if (string.IsNullOrWhiteSpace(apiKey))
                return;

            string text;
            using (WebClient client = new WebClient())
            {
                client.Encoding = System.Text.Encoding.UTF8;
                text = client.DownloadString(
                    localBaseUrl.TrimEnd('/') + "/api/copier/sync-map?apiKey=" + Uri.EscapeDataString(apiKey));
            }

            bool enabled = false;
            List<CopySyncRoute> routes = new List<CopySyncRoute>();

            foreach (string rawLine in (text ?? "").Split('\n'))
            {
                string line = rawLine.Trim('\r', ' ');
                if (line.Length == 0) continue;
                if (line.StartsWith("ENABLED=", StringComparison.OrdinalIgnoreCase))
                {
                    enabled = line.EndsWith("1");
                    continue;
                }
                string[] parts = line.Split('\t');
                if (parts.Length < 3) continue;
                if (string.IsNullOrWhiteSpace(parts[0]) || string.IsNullOrWhiteSpace(parts[1])) continue;
                int maxContracts = 0;
                if (parts.Length > 4) int.TryParse(parts[4].Trim(), out maxContracts);
                routes.Add(new CopySyncRoute
                {
                    Master = parts[0].Trim(),
                    Slave = parts[1].Trim(),
                    Reverse = parts[2].Trim() == "1",
                    Mode = parts.Length > 3 && parts[3].Trim().Length > 0 ? parts[3].Trim().ToUpperInvariant() : "SAME",
                    MaxContracts = Math.Max(0, maxContracts),
                    Micro = parts.Length > 5 && parts[5].Trim() == "1"
                });
            }

            copySyncCopierEnabled = enabled;
            copySyncRoutes = routes;
        }

        private static Account FindAccountByName(string name)
        {
            lock (Account.All)
            {
                foreach (Account account in Account.All)
                {
                    if (account != null && string.Equals(account.Name, name, StringComparison.OrdinalIgnoreCase))
                        return account;
                }
            }
            return null;
        }

        private static Position FindPosition(Account account, string instrumentFullName)
        {
            if (account == null) return null;
            foreach (Position position in account.Positions)
            {
                if (position != null && position.Instrument != null &&
                    position.Instrument.FullName == instrumentFullName)
                    return position;
            }
            return null;
        }

        private void RunCopySyncGuard()
        {
            if (Interlocked.Exchange(ref copySyncInProgress, 1) == 1)
                return;

            try
            {
                try { RefreshCopySyncMap(); }
                catch (Exception ex)
                {
                    // backend not reachable: keep the last known map, never act on guesses
                    if ((DateTime.UtcNow - copySyncMapLoadedUtc).TotalSeconds < 2)
                        Print("JJ COPY SYNC map no disponible: " + ex.Message);
                }

                if (!copySyncCopierEnabled || copySyncRoutes.Count == 0)
                {
                    copySyncMismatchSince.Clear();
                    return;
                }

                HashSet<string> stillMismatched = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                foreach (CopySyncRoute route in copySyncRoutes)
                {
                    Account slave = FindAccountByName(route.Slave);
                    Account master = FindAccountByName(route.Master);
                    if (slave == null || master == null)
                        continue;
                    if (master.ConnectionStatus != ConnectionStatus.Connected ||
                        slave.ConnectionStatus != ConnectionStatus.Connected)
                        continue; // never act while a side is disconnected

                    List<Position> slavePositions = new List<Position>();
                    foreach (Position p in slave.Positions)
                        if (p != null && p.Instrument != null) slavePositions.Add(p);

                    foreach (Position slavePos in slavePositions)
                    {
                        string instrumentName = slavePos.Instrument.FullName;
                        string key = slave.Name + "|" + instrumentName;

                        if (slavePos.MarketPosition == MarketPosition.Flat)
                        {
                            DateTime ignored;
                            copyOwnedPositions.TryRemove(key, out ignored);
                            continue;
                        }

                        if (!copyOwnedPositions.ContainsKey(key))
                            continue; // opened by the bot or by hand: not ours

                        Position masterPos = FindPosition(master, CopySyncMasterInstrumentFor(instrumentName, route.Micro));
                        MarketPosition masterSide =
                            masterPos == null ? MarketPosition.Flat : masterPos.MarketPosition;

                        MarketPosition expected = masterSide;
                        if (route.Reverse && masterSide != MarketPosition.Flat)
                            expected = masterSide == MarketPosition.Long ? MarketPosition.Short : MarketPosition.Long;

                        bool mismatch = expected == MarketPosition.Flat || slavePos.MarketPosition != expected;
                        if (!mismatch)
                        {
                            // 3) OVER-SIZE (same direction): trim the excess, never add
                            int allowed = int.MaxValue;
                            if (route.MaxContracts > 0) allowed = route.MaxContracts;
                            if (route.Mode == "SAME" && masterPos != null)
                                allowed = Math.Min(allowed, Math.Max(0, masterPos.Quantity));
                            int excess = allowed == int.MaxValue ? 0 : slavePos.Quantity - allowed;
                            string sizeKey = key + "|SIZE";
                            if (excess <= 0)
                                continue;

                            stillMismatched.Add(sizeKey);
                            DateTime sizeSince = copySyncMismatchSince.GetOrAdd(sizeKey, DateTime.UtcNow);
                            if ((DateTime.UtcNow - sizeSince).TotalSeconds < CopySyncGraceSeconds)
                                continue;

                            DateTime removedSize;
                            copySyncMismatchSince.TryRemove(sizeKey, out removedSize);
                            Print(
                                "JJ COPY SYNC: slave con mas contratos de los debidos | Slave: " + slave.Name +
                                " | " + instrumentName + " " + slavePos.MarketPosition + " x" + slavePos.Quantity +
                                " | Permitido: " + allowed + " | Reduce: " + excess +
                                " | Master: " + master.Name + (masterPos != null ? " x" + masterPos.Quantity : ""));
                            ExecuteCopyTrade(
                                slave.Name,
                                instrumentName,
                                slavePos.MarketPosition == MarketPosition.Long ? "SELL" : "BUYTOCOVER",
                                excess);
                            continue;
                        }

                        stillMismatched.Add(key);
                        DateTime since = copySyncMismatchSince.GetOrAdd(key, DateTime.UtcNow);
                        if ((DateTime.UtcNow - since).TotalSeconds < CopySyncGraceSeconds)
                            continue;

                        string reason = masterSide == MarketPosition.Flat
                            ? "master FLAT"
                            : "slave " + slavePos.MarketPosition + " vs master " + masterSide + (route.Reverse ? " (reverse)" : "");

                        int qty = slavePos.Quantity;
                        slave.Flatten(new Instrument[] { slavePos.Instrument });
                        SendPositionUpdateAsync(slave.Name, instrumentName, "CLOSE", qty);

                        DateTime removed;
                        copySyncMismatchSince.TryRemove(key, out removed);
                        copyOwnedPositions.TryRemove(key, out removed);

                        Print(
                            "JJ COPY SYNC: cerrada posicion copiada huerfana | Slave: " + slave.Name +
                            " | " + instrumentName + " " + slavePos.MarketPosition + " x" + qty +
                            " | Master: " + master.Name + " | Motivo: " + reason);
                    }
                }

                foreach (string key in new List<string>(copySyncMismatchSince.Keys))
                {
                    if (!stillMismatched.Contains(key))
                    {
                        DateTime removed;
                        copySyncMismatchSince.TryRemove(key, out removed);
                    }
                }
            }
            catch (Exception ex)
            {
                Print("JJ COPY SYNC error: " + ex.Message);
            }
            finally
            {
                Interlocked.Exchange(ref copySyncInProgress, 0);
            }
        }
    }
}

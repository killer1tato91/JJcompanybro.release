#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJTradeEventTelemetry : AddOnBase
    {
        private const string CloudBaseUrl = "https://jjtradingtools.ddns.net";
        private readonly object sync = new object();

        private readonly Dictionary<string, int> signedPositions =
            new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        private readonly HashSet<string> sentExecutionIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private string apiKey = "";

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJTradeEventTelemetry";
                Description = "JJ Trading Tools - read-only trade event telemetry";
            }
            else if (State == State.Active)
            {
                StartTelemetry();
            }
            else if (State == State.Terminated)
            {
                StopTelemetry();
            }
        }

        private void StartTelemetry()
        {
            apiKey = LoadApiKey();

            foreach (Account account in Account.All)
            {
                if (account == null)
                    continue;

                SnapshotPositions(account);
                account.ExecutionUpdate += OnExecutionUpdate;
            }

            Print("JJ TRADE TELEMETRY READY | API=" +
                (!string.IsNullOrWhiteSpace(apiKey) ? "OK" : "MISSING"));
        }

        private void StopTelemetry()
        {
            foreach (Account account in Account.All)
            {
                if (account != null)
                    account.ExecutionUpdate -= OnExecutionUpdate;
            }
        }

        private void SnapshotPositions(Account account)
        {
            lock (sync)
            {
                foreach (Position position in account.Positions)
                {
                    if (position == null || position.Instrument == null)
                        continue;

                    int signed = 0;

                    if (position.MarketPosition == MarketPosition.Long)
                        signed = Math.Abs(position.Quantity);
                    else if (position.MarketPosition == MarketPosition.Short)
                        signed = -Math.Abs(position.Quantity);

                    signedPositions[
                        MakeKey(account.Name, position.Instrument.FullName)
                    ] = signed;
                }
            }
        }

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Execution == null ||
                    e.Execution.Account == null ||
                    e.Execution.Instrument == null ||
                    e.Execution.Order == null ||
                    string.IsNullOrWhiteSpace(apiKey)
                )
                    return;

                string executionId = e.Execution.ExecutionId ?? "";

                lock (sync)
                {
                    if (
                        !string.IsNullOrWhiteSpace(executionId) &&
                        sentExecutionIds.Contains(executionId)
                    )
                        return;

                    if (!string.IsNullOrWhiteSpace(executionId))
                        sentExecutionIds.Add(executionId);

                    if (sentExecutionIds.Count > 2000)
                        sentExecutionIds.Clear();
                }

                Account account = e.Execution.Account;
                Order order = e.Execution.Order;

                string accountName = account.Name ?? "";
                string symbol = e.Execution.Instrument.FullName ?? "";
                int fillQuantity = Math.Abs(e.Execution.Quantity);
                int orderQuantity = Math.Abs(order.Quantity);
                double fillPrice = e.Execution.Price;

                int previousPosition;
                int currentPosition;
                string key = MakeKey(accountName, symbol);

                lock (sync)
                {
                    if (!signedPositions.TryGetValue(key, out previousPosition))
                        previousPosition = ReadSignedPosition(account, symbol);

                    currentPosition =
                        previousPosition +
                        GetSignedDelta(order.OrderAction, fillQuantity);

                    signedPositions[key] = currentPosition;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"executionId\":\"" + EscapeJson(executionId) + "\"," +
                    "\"orderId\":\"" + EscapeJson(order.OrderId ?? "") + "\"," +
                    "\"orderName\":\"" + EscapeJson(order.Name ?? "") + "\"," +
                    "\"orderType\":\"" + EscapeJson(order.OrderType.ToString()) + "\"," +
                    "\"account\":\"" + EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
                    "\"action\":\"" + EscapeJson(order.OrderAction.ToString()) + "\"," +
                    "\"quantity\":" + fillQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"orderQuantity\":" + orderQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"price\":" + fillPrice.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"previousPosition\":" + previousPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"currentPosition\":" + currentPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"time\":\"" + e.Execution.Time.ToString("o") + "\"" +
                    "}";

                Task.Run(() => PostEvent(json));
            }
            catch (Exception ex)
            {
                Print("JJ TRADE TELEMETRY EVENT ERROR: " + ex.Message);
            }
        }

        private int ReadSignedPosition(Account account, string symbol)
        {
            foreach (Position position in account.Positions)
            {
                if (
                    position == null ||
                    position.Instrument == null ||
                    !string.Equals(
                        position.Instrument.FullName,
                        symbol,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                    continue;

                if (position.MarketPosition == MarketPosition.Long)
                    return Math.Abs(position.Quantity);

                if (position.MarketPosition == MarketPosition.Short)
                    return -Math.Abs(position.Quantity);
            }

            return 0;
        }

        private int GetSignedDelta(OrderAction action, int quantity)
        {
            switch (action)
            {
                case OrderAction.Buy:
                case OrderAction.BuyToCover:
                    return quantity;
                case OrderAction.Sell:
                case OrderAction.SellShort:
                    return -quantity;
                default:
                    return 0;
            }
        }

        private void PostEvent(string json)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string response = client.UploadString(
                        CloudBaseUrl + "/api/trades/execution-event",
                        "POST",
                        json
                    );
                    Print("JJ TRADE TELEMETRY SENT | " + response);
                }
            }
            catch (Exception ex)
            {
                Print("JJ TRADE TELEMETRY CLOUD ERROR: " + ex.Message);
            }
        }

        private string LoadApiKey()
        {
            string documents =
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            string[] candidates =
            {
                Path.Combine(documents, "J&J Company Bro", "config.json"),
                Path.Combine(documents, "JJ Trading Tools", "config.json")
            };

            foreach (string file in candidates)
            {
                try
                {
                    if (!File.Exists(file))
                        continue;

                    Match match = Regex.Match(
                        File.ReadAllText(file),
                        "\"apiKey\"\\s*:\\s*\"([^\"]+)\"",
                        RegexOptions.IgnoreCase
                    );

                    if (match.Success)
                        return match.Groups[1].Value;
                }
                catch { }
            }

            return "";
        }

        private string MakeKey(string account, string symbol)
        {
            return (account ?? "") + "|" + (symbol ?? "");
        }

        private string EscapeJson(string value)
        {
            return (value ?? "")
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n");
        }
    }
}

#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class JJTradeEventTelemetry : AddOnBase
    {
        private const string CloudBaseUrl = "https://jjtradingtools.ddns.net";
        private const string LocalBaseUrl = "http://127.0.0.1:3001";

        // Compliance telemetry is additive/read-only. It never submits,
        // changes, cancels or blocks any NinjaTrader order.
        private readonly Dictionary<string, DateTime> lastAccountItemTelemetry =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        private const int AccountItemTelemetryThrottleMs = 500;
        private readonly object sync = new object();

        private readonly Dictionary<string, int> signedPositions =
            new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        private readonly HashSet<string> sentExecutionIds =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private string apiKey = "";

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "JJTradeEventTelemetry";
                Description = "JJ Trading Tools - read-only trade event telemetry";
            }
            else if (State == State.Active)
            {
                StartTelemetry();
            }
            else if (State == State.Terminated)
            {
                StopTelemetry();
            }
        }

        private void StartTelemetry()
        {
            apiKey = LoadApiKey();

            foreach (Account account in Account.All)
            {
                if (account == null)
                    continue;

                SnapshotPositions(account);

                // Existing execution telemetry.
                account.ExecutionUpdate += OnExecutionUpdate;

                // Additive compliance listeners. Read-only only.
                account.PositionUpdate += OnPositionUpdate;
                account.OrderUpdate += OnOrderUpdate;
                account.AccountItemUpdate += OnAccountItemUpdate;
            }

            Print("JJ TRADE TELEMETRY READY | API=" +
                (!string.IsNullOrWhiteSpace(apiKey) ? "OK" : "MISSING"));
        }

        private void StopTelemetry()
        {
            foreach (Account account in Account.All)
            {
                if (account != null)
                {
                    account.ExecutionUpdate -= OnExecutionUpdate;
                    account.PositionUpdate -= OnPositionUpdate;
                    account.OrderUpdate -= OnOrderUpdate;
                    account.AccountItemUpdate -= OnAccountItemUpdate;
                }
            }
        }

        private void SnapshotPositions(Account account)
        {
            lock (sync)
            {
                foreach (Position position in account.Positions)
                {
                    if (position == null || position.Instrument == null)
                        continue;

                    int signed = 0;

                    if (position.MarketPosition == MarketPosition.Long)
                        signed = Math.Abs(position.Quantity);
                    else if (position.MarketPosition == MarketPosition.Short)
                        signed = -Math.Abs(position.Quantity);

                    signedPositions[
                        MakeKey(account.Name, position.Instrument.FullName)
                    ] = signed;
                }
            }
        }

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Execution == null ||
                    e.Execution.Account == null ||
                    e.Execution.Instrument == null ||
                    e.Execution.Order == null ||
                    string.IsNullOrWhiteSpace(apiKey)
                )
                    return;

                string executionId = e.Execution.ExecutionId ?? "";

                lock (sync)
                {
                    if (
                        !string.IsNullOrWhiteSpace(executionId) &&
                        sentExecutionIds.Contains(executionId)
                    )
                        return;

                    if (!string.IsNullOrWhiteSpace(executionId))
                        sentExecutionIds.Add(executionId);

                    if (sentExecutionIds.Count > 2000)
                        sentExecutionIds.Clear();
                }

                Account account = e.Execution.Account;
                Order order = e.Execution.Order;

                string accountName = account.Name ?? "";
                string symbol = e.Execution.Instrument.FullName ?? "";
                int fillQuantity = Math.Abs(e.Execution.Quantity);
                int orderQuantity = Math.Abs(order.Quantity);
                double fillPrice = e.Execution.Price;

                int previousPosition;
                int currentPosition;
                string key = MakeKey(accountName, symbol);

                lock (sync)
                {
                    if (!signedPositions.TryGetValue(key, out previousPosition))
                        previousPosition = ReadSignedPosition(account, symbol);

                    currentPosition =
                        previousPosition +
                        GetSignedDelta(order.OrderAction, fillQuantity);

                    signedPositions[key] = currentPosition;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"executionId\":\"" + EscapeJson(executionId) + "\"," +
                    "\"orderId\":\"" + EscapeJson(order.OrderId ?? "") + "\"," +
                    "\"orderName\":\"" + EscapeJson(order.Name ?? "") + "\"," +
                    "\"orderType\":\"" + EscapeJson(order.OrderType.ToString()) + "\"," +
                    "\"account\":\"" + EscapeJson(accountName) + "\"," +
                    "\"symbol\":\"" + EscapeJson(symbol) + "\"," +
                    "\"action\":\"" + EscapeJson(order.OrderAction.ToString()) + "\"," +
                    "\"quantity\":" + fillQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"orderQuantity\":" + orderQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"price\":" + fillPrice.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"previousPosition\":" + previousPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"currentPosition\":" + currentPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"time\":\"" + e.Execution.Time.ToString("o") + "\"" +
                    "}";

                // Preserve the existing /api/trades/execution-event route exactly.
                Task.Run(() => PostEvent(json));

                // Send the same fill context to the new local Compliance Engine.
                string complianceJson =
                    BuildComplianceExecutionJson(
                        account,
                        order,
                        executionId,
                        symbol,
                        fillQuantity,
                        fillPrice,
                        previousPosition,
                        currentPosition,
                        e.Execution.Time
                    );

                Task.Run(() => PostComplianceEvent(complianceJson));
            }
            catch (Exception ex)
            {
                Print("JJ TRADE TELEMETRY EVENT ERROR: " + ex.Message);
            }
        }

        // ============================================================
        // COMPLIANCE TELEMETRY V2 - READ ONLY
        // ============================================================

        private void OnPositionUpdate(object sender, PositionEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Position == null ||
                    e.Position.Account == null ||
                    e.Position.Instrument == null ||
                    string.IsNullOrWhiteSpace(apiKey)
                )
                    return;

                Account account = e.Position.Account;
                string symbol = e.Position.Instrument.FullName ?? "";

                int signedQuantity = 0;

                if (e.MarketPosition == MarketPosition.Long)
                    signedQuantity = Math.Abs(e.Quantity);
                else if (e.MarketPosition == MarketPosition.Short)
                    signedQuantity = -Math.Abs(e.Quantity);

                lock (sync)
                {
                    signedPositions[
                        MakeKey(account.Name, symbol)
                    ] = signedQuantity;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"account\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                    "\"event\":{" +
                        "\"eventType\":\"POSITION_UPDATE\"," +
                        "\"timestamp\":\"" + DateTime.Now.ToString("o") + "\"," +
                        "\"instrument\":\"" + EscapeJson(symbol) + "\"," +
                        "\"side\":\"" + EscapeJson(e.MarketPosition.ToString()) + "\"," +
                        "\"positionQuantity\":" + signedQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"averagePrice\":" + e.AveragePrice.ToString(CultureInfo.InvariantCulture) +
                    "}," +
                    "\"context\":{" +
                        "\"positionQuantity\":" + signedQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"workingOrderCount\":" + CountWorkingOrders(account).ToString(CultureInfo.InvariantCulture) + "," +
                        BuildAccountSnapshotContext(account) +
                    "}," +
                    "\"accountContext\":{" +
                        "\"name\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                        "\"broker\":\"" + EscapeJson(DetectBroker(account.Name ?? "")) + "\"" +
                    "}" +
                    "}";

                Task.Run(() => PostComplianceEvent(json));
            }
            catch (Exception ex)
            {
                Print("JJ COMPLIANCE POSITION ERROR: " + ex.Message);
            }
        }

        private void OnOrderUpdate(object sender, OrderEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Order == null ||
                    e.Order.Account == null ||
                    e.Order.Instrument == null ||
                    string.IsNullOrWhiteSpace(apiKey)
                )
                    return;

                Order order = e.Order;
                Account account = order.Account;
                string symbol = order.Instrument.FullName ?? "";

                int signedPosition = ReadSignedPosition(account, symbol);

                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"account\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                    "\"event\":{" +
                        "\"eventType\":\"ORDER_UPDATE\"," +
                        "\"timestamp\":\"" + DateTime.Now.ToString("o") + "\"," +
                        "\"instrument\":\"" + EscapeJson(symbol) + "\"," +
                        "\"orderId\":\"" + EscapeJson(order.OrderId ?? "") + "\"," +
                        "\"orderName\":\"" + EscapeJson(order.Name ?? "") + "\"," +
                        "\"orderState\":\"" + EscapeJson(order.OrderState.ToString()) + "\"," +
                        "\"orderType\":\"" + EscapeJson(order.OrderType.ToString()) + "\"," +
                        "\"action\":\"" + EscapeJson(order.OrderAction.ToString()) + "\"," +
                        "\"quantity\":" + Math.Abs(order.Quantity).ToString(CultureInfo.InvariantCulture) + "," +
                        "\"filled\":" + Math.Abs(order.Filled).ToString(CultureInfo.InvariantCulture) + "," +
                        "\"limitPrice\":" + order.LimitPrice.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"stopPrice\":" + order.StopPrice.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"positionQuantity\":" + signedPosition.ToString(CultureInfo.InvariantCulture) +
                    "}," +
                    "\"context\":{" +
                        "\"positionQuantity\":" + signedPosition.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"workingOrderCount\":" + CountWorkingOrders(account).ToString(CultureInfo.InvariantCulture) + "," +
                        BuildAccountSnapshotContext(account) +
                    "}," +
                    "\"accountContext\":{" +
                        "\"name\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                        "\"broker\":\"" + EscapeJson(DetectBroker(account.Name ?? "")) + "\"" +
                    "}" +
                    "}";

                Task.Run(() => PostComplianceEvent(json));
            }
            catch (Exception ex)
            {
                Print("JJ COMPLIANCE ORDER ERROR: " + ex.Message);
            }
        }

        private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
        {
            try
            {
                if (
                    e == null ||
                    e.Account == null ||
                    string.IsNullOrWhiteSpace(apiKey)
                )
                    return;

                if (!IsComplianceAccountItem(e.AccountItem))
                    return;

                string throttleKey =
                    (e.Account.Name ?? "") + "|" + e.AccountItem.ToString();

                lock (sync)
                {
                    DateTime last;

                    if (
                        lastAccountItemTelemetry.TryGetValue(throttleKey, out last) &&
                        (DateTime.UtcNow - last).TotalMilliseconds <
                            AccountItemTelemetryThrottleMs
                    )
                        return;

                    lastAccountItemTelemetry[throttleKey] = DateTime.UtcNow;
                }

                string json =
                    "{" +
                    "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                    "\"account\":\"" + EscapeJson(e.Account.Name ?? "") + "\"," +
                    "\"event\":{" +
                        "\"eventType\":\"ACCOUNT_ITEM_UPDATE\"," +
                        "\"timestamp\":\"" + e.Time.ToString("o") + "\"," +
                        "\"accountItem\":\"" + EscapeJson(e.AccountItem.ToString()) + "\"," +
                        "\"value\":" + e.Value.ToString(CultureInfo.InvariantCulture) +
                    "}," +
                    "\"context\":{" +
                        "\"accountItem\":\"" + EscapeJson(e.AccountItem.ToString()) + "\"," +
                        "\"accountItemValue\":" + e.Value.ToString(CultureInfo.InvariantCulture) + "," +
                        "\"workingOrderCount\":" + CountWorkingOrders(e.Account).ToString(CultureInfo.InvariantCulture) + "," +
                        BuildAccountSnapshotContext(e.Account) +
                    "}," +
                    "\"accountContext\":{" +
                        "\"name\":\"" + EscapeJson(e.Account.Name ?? "") + "\"," +
                        "\"broker\":\"" + EscapeJson(DetectBroker(e.Account.Name ?? "")) + "\"" +
                    "}" +
                    "}";

                Task.Run(() => PostComplianceEvent(json));
            }
            catch (Exception ex)
            {
                Print("JJ COMPLIANCE ACCOUNT ITEM ERROR: " + ex.Message);
            }
        }

        private string BuildComplianceExecutionJson(
            Account account,
            Order order,
            string executionId,
            string symbol,
            int fillQuantity,
            double fillPrice,
            int previousPosition,
            int currentPosition,
            DateTime executionTime)
        {
            return
                "{" +
                "\"apiKey\":\"" + EscapeJson(apiKey) + "\"," +
                "\"account\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                "\"event\":{" +
                    "\"eventType\":\"EXECUTION_UPDATE\"," +
                    "\"timestamp\":\"" + executionTime.ToString("o") + "\"," +
                    "\"instrument\":\"" + EscapeJson(symbol) + "\"," +
                    "\"executionId\":\"" + EscapeJson(executionId) + "\"," +
                    "\"orderId\":\"" + EscapeJson(order.OrderId ?? "") + "\"," +
                    "\"orderName\":\"" + EscapeJson(order.Name ?? "") + "\"," +
                    "\"orderType\":\"" + EscapeJson(order.OrderType.ToString()) + "\"," +
                    "\"action\":\"" + EscapeJson(order.OrderAction.ToString()) + "\"," +
                    "\"quantity\":" + fillQuantity.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"price\":" + fillPrice.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"positionQuantity\":" + currentPosition.ToString(CultureInfo.InvariantCulture) +
                "}," +
                "\"context\":{" +
                    "\"previousPosition\":" + previousPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"positionQuantity\":" + currentPosition.ToString(CultureInfo.InvariantCulture) + "," +
                    "\"workingOrderCount\":" + CountWorkingOrders(account).ToString(CultureInfo.InvariantCulture) + "," +
                    BuildAccountSnapshotContext(account) +
                "}," +
                "\"accountContext\":{" +
                    "\"name\":\"" + EscapeJson(account.Name ?? "") + "\"," +
                    "\"broker\":\"" + EscapeJson(DetectBroker(account.Name ?? "")) + "\"" +
                "}" +
                "}";
        }

        private string BuildAccountSnapshotContext(Account account)
        {
            double balance =
                SafeGet(account, AccountItem.CashValue);

            double realized =
                SafeGet(account, AccountItem.RealizedProfitLoss);

            double unrealized =
                SafeGet(account, AccountItem.UnrealizedProfitLoss);

            double trailingDrawdown =
                SafeGet(account, AccountItem.TrailingMaxDrawdown);

            return
                "\"balance\":" + balance.ToString(CultureInfo.InvariantCulture) + "," +
                "\"dailyNetPnl\":" + realized.ToString(CultureInfo.InvariantCulture) + "," +
                "\"openPnl\":" + unrealized.ToString(CultureInfo.InvariantCulture) + "," +
                "\"trailingMaxDrawdown\":" + trailingDrawdown.ToString(CultureInfo.InvariantCulture);
        }

        private double SafeGet(Account account, AccountItem item)
        {
            try
            {
                return account.Get(item, Currency.UsDollar);
            }
            catch
            {
                return 0;
            }
        }

        private bool IsComplianceAccountItem(AccountItem item)
        {
            return
                item == AccountItem.CashValue ||
                item == AccountItem.RealizedProfitLoss ||
                item == AccountItem.UnrealizedProfitLoss ||
                item == AccountItem.TrailingMaxDrawdown;
        }

        private int CountWorkingOrders(Account account)
        {
            int count = 0;

            try
            {
                foreach (Order order in account.Orders)
                {
                    if (order == null)
                        continue;

                    string state =
                        order.OrderState.ToString();

                    if (
                        state.Equals("Accepted", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("Submitted", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("Working", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("PartFilled", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("ChangePending", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("ChangeSubmitted", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("CancelPending", StringComparison.OrdinalIgnoreCase) ||
                        state.Equals("TriggerPending", StringComparison.OrdinalIgnoreCase)
                    )
                        count++;
                }
            }
            catch
            {
            }

            return count;
        }

        private string DetectBroker(string accountName)
        {
            string value =
                (accountName ?? "").ToUpperInvariant();

            if (value.Contains("APEX"))
                return "Apex";

            if (value.Contains("MFFU") || value.Contains("MYFUNDED"))
                return "MyFundedFutures";

            if (
                value.Contains("TDFY") ||
                value.Contains("TRADEIFY") ||
                value.Contains("TRADEFY")
            )
                return "Tradeify";

            if (
                value.Contains("LFE") ||
                value.Contains("LFF") ||
                value.Contains("LTE") ||
                value.Contains("LUCID")
            )
                return "Lucid";

            if (value.Contains("TOPSTEP"))
                return "Topstep";

            return "NinjaTrader";
        }

        private void PostComplianceEvent(string json)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] =
                        "application/json";

                    client.UploadString(
                        LocalBaseUrl + "/api/compliance/telemetry",
                        "POST",
                        json
                    );
                }
            }
            catch (Exception ex)
            {
                // Additive telemetry must NEVER affect the existing trade event
                // route or any live trading/copy logic.
                Print("JJ COMPLIANCE LOCAL OFFLINE: " + ex.Message);
            }
        }

        private int ReadSignedPosition(Account account, string symbol)
        {
            foreach (Position position in account.Positions)
            {
                if (
                    position == null ||
                    position.Instrument == null ||
                    !string.Equals(
                        position.Instrument.FullName,
                        symbol,
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                    continue;

                if (position.MarketPosition == MarketPosition.Long)
                    return Math.Abs(position.Quantity);

                if (position.MarketPosition == MarketPosition.Short)
                    return -Math.Abs(position.Quantity);
            }

            return 0;
        }

        private int GetSignedDelta(OrderAction action, int quantity)
        {
            switch (action)
            {
                case OrderAction.Buy:
                case OrderAction.BuyToCover:
                    return quantity;
                case OrderAction.Sell:
                case OrderAction.SellShort:
                    return -quantity;
                default:
                    return 0;
            }
        }

        private void PostEvent(string json)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string response = client.UploadString(
                        CloudBaseUrl + "/api/trades/execution-event",
                        "POST",
                        json
                    );
                    Print("JJ TRADE TELEMETRY SENT | " + response);
                }
            }
            catch (Exception ex)
            {
                Print("JJ TRADE TELEMETRY CLOUD ERROR: " + ex.Message);
            }
        }

        private string LoadApiKey()
        {
            string documents =
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            string[] candidates =
            {
                Path.Combine(documents, "J&J Company Bro", "config.json"),
                Path.Combine(documents, "JJ Trading Tools", "config.json")
            };

            foreach (string file in candidates)
            {
                try
                {
                    if (!File.Exists(file))
                        continue;

                    Match match = Regex.Match(
                        File.ReadAllText(file),
                        "\"apiKey\"\\s*:\\s*\"([^\"]+)\"",
                        RegexOptions.IgnoreCase
                    );

                    if (match.Success)
                        return match.Groups[1].Value;
                }
                catch { }
            }

            return "";
        }

        private string MakeKey(string account, string symbol)
        {
            return (account ?? "") + "|" + (symbol ?? "");
        }

        private string EscapeJson(string value)
        {
            return (value ?? "")
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n");
        }
    }
}

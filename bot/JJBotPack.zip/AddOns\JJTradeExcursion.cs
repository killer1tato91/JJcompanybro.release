// JJ_TRADE_EXCURSION_V1 (2026-10-31) - MFE / MAE for every closed trade in the Journal.
// While a position is open, its unrealized P&L (in $, all contracts) is sampled every 250 ms:
//   MFE = best unrealized profit reached (>= 0)
//   MAE = worst unrealized loss reached (<= 0)
// The final realized P&L is folded in, so MFE >= P&L >= MAE always holds.
// The values travel with the closed trade (fields "mfe" / "mae", already read by the
// backend, the desktop Journal and the APK trade detail).
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    public partial class JJCompanyBroAddon
    {
        private System.Timers.Timer excursionTimer;
        private int excursionInProgress = 0;

        // account|instrument -> [mfe, mae]
        private readonly ConcurrentDictionary<string, double[]> tradeExcursions =
            new ConcurrentDictionary<string, double[]>(StringComparer.OrdinalIgnoreCase);

        private void ResetTradeExcursion(string tradeKey)
        {
            if (string.IsNullOrWhiteSpace(tradeKey)) return;
            tradeExcursions[tradeKey] = new double[] { 0, 0 };
        }

        private void FoldExcursion(string tradeKey, double value)
        {
            if (double.IsNaN(value) || double.IsInfinity(value)) return;
            double[] ex = tradeExcursions.GetOrAdd(tradeKey, _ => new double[] { 0, 0 });
            lock (ex)
            {
                if (value > ex[0]) ex[0] = value;
                if (value < ex[1]) ex[1] = value;
            }
        }

        // Returns (mfe, mae) for the trade that just closed and forgets it.
        private void TakeTradeExcursion(string tradeKey, double finalPnl, out double mfe, out double mae)
        {
            FoldExcursion(tradeKey, finalPnl);
            double[] ex;
            if (tradeExcursions.TryRemove(tradeKey, out ex))
            {
                lock (ex) { mfe = Math.Max(0, ex[0]); mae = Math.Min(0, ex[1]); }
                return;
            }
            mfe = Math.Max(0, finalPnl);
            mae = Math.Min(0, finalPnl);
        }

        private void StartExcursionSampler()
        {
            try
            {
                if (excursionTimer != null) return;
                excursionTimer = new System.Timers.Timer(250);
                excursionTimer.AutoReset = true;
                excursionTimer.Elapsed += (s, e) => SampleExcursions();
                excursionTimer.Start();
            }
            catch (Exception ex) { Print("JJ MFE/MAE start error: " + ex.Message); }
        }

        private void StopExcursionSampler()
        {
            try
            {
                if (excursionTimer == null) return;
                excursionTimer.Stop();
                excursionTimer.Dispose();
                excursionTimer = null;
            }
            catch { }
        }

        private void SampleExcursions()
        {
            if (Interlocked.Exchange(ref excursionInProgress, 1) == 1) return;
            try
            {
                List<Account> accounts;
                lock (journalSync) accounts = new List<Account>(subscribedAccounts);
                foreach (Account account in accounts)
                {
                    if (account == null) continue;
                    List<Position> positions = new List<Position>();
                    try { foreach (Position p in account.Positions) if (p != null && p.Instrument != null) positions.Add(p); }
                    catch { continue; }
                    foreach (Position position in positions)
                    {
                        if (position.MarketPosition == MarketPosition.Flat) continue;
                        double unrealized;
                        try { unrealized = position.GetUnrealizedProfitLoss(PerformanceUnit.Currency); }
                        catch { continue; }
                        FoldExcursion(account.Name + "|" + position.Instrument.FullName, unrealized);
                    }
                }
            }
            catch { }
            finally { Interlocked.Exchange(ref excursionInProgress, 0); }
        }
    }
}

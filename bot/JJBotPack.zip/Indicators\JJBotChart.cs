#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;

using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.AddOns;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class JJBotChart : Indicator
    {
        private EMA emaFast;
        private EMA emaSlow;

        private DateTime vwapNyDate;
        private double cumulativePriceVolume;
        private double cumulativePriceSquaredVolume;
        private double cumulativeVolume;
        private double currentVwap;

        private double currentVwapStdDev;
        private double currentVwapUpper1;
        private double currentVwapUpper2;
        private double currentVwapLower1;
        private double currentVwapLower2;
        private double currentVwapZScore;
        private double currentVwapBandWidthRatio = 1.0;
        private string currentVwapLocation = "WAITING";
        private string currentVwapBandState = "WAITING";
        private string currentVwapSlope = "FLAT";
        private string currentVwapEntryContext = "NEUTRAL";
        private double previousVwapForSlope;
        private DateTime vwapWidthSessionDate = DateTime.MinValue;
        private readonly Queue<double> recentVwapBandWidths =
            new Queue<double>();

    

        // =====================================================
        // V1.7.35 - CORE20 ZONES (visual only)
        // =====================================================
        // Same definition as the bot: ONH/ONL = (18:00 prev day, 09:30] ET,
        // PDH/PDL = prior RTH (09:30, 16:00] ET. Computed from the chart for
        // history; for the live session the bot's own zones (JJCore20ZoneBus)
        // override them and every bot trigger (ENTRY / SKIP) is marked.
        private readonly Dictionary<DateTime, double[]> c20Overnight =
            new Dictionary<DateTime, double[]>();
        private readonly Dictionary<DateTime, double[]> c20Rth =
            new Dictionary<DateTime, double[]>();
        private readonly Dictionary<DateTime, string> c20DrawnKey =
            new Dictionary<DateTime, string>();
        private readonly List<DateTime> c20DrawnDates =
            new List<DateTime>();
        private readonly HashSet<string> c20Tags =
            new HashSet<string>();
        private bool c20BusSubscribed;
        private long c20LastBusVersion = -1;
        private const int Core20ZoneTicks = 8;

        // Real AddOn bridge state
        private JJBotSharedSnapshot sharedSnapshot;
        private long lastExecutionSequence;
        private bool sharedStateSubscribed;

        // Throttle fixed-panel redraws while still allowing execution
        // markers to render immediately.
        private DateTime lastSharedUiRefreshUtc;
        private const int SharedUiRefreshThrottleMs = 300;

        // =====================================================
        // LIQUIDITY MAP / LEVEL II (VISUAL ONLY)
        // =====================================================
        // This layer listens to real-time Market Depth + Last trades and
        // paints liquidity walls/zones on the chart. It NEVER submits orders
        // and it does not alter JJBotSharedState or the bot's entry logic.
        private sealed class LiquidityLevelInfo
        {
            public double Price;
            public long Volume;
            public DateTime UpdatedUtc;
        }

        private sealed class TradePrint
        {
            public double Price;
            public long Volume;
            public DateTime TimeUtc;
            public bool AggressiveBuy;
            public bool AggressiveSell;
        }

        private sealed class ConsumedLiquidityMarker
        {
            public double Price;
            public bool WasAsk;
            public DateTime ExpiresUtc;
        }

        private readonly object liquidityLock = new object();
        private readonly Dictionary<double, LiquidityLevelInfo> bidDepth =
            new Dictionary<double, LiquidityLevelInfo>();
        private readonly Dictionary<double, LiquidityLevelInfo> askDepth =
            new Dictionary<double, LiquidityLevelInfo>();
        private readonly Queue<TradePrint> recentTradePrints =
            new Queue<TradePrint>();
        private readonly Dictionary<double, ConsumedLiquidityMarker> consumedLiquidity =
            new Dictionary<double, ConsumedLiquidityMarker>();
        private readonly HashSet<double> previousBidWalls =
            new HashSet<double>();
        private readonly HashSet<double> previousAskWalls =
            new HashSet<double>();
        private readonly HashSet<string> liquidityDrawTags =
            new HashSet<string>();

        private DateTime lastLiquidityRenderUtc;
        private bool liquidityRenderPending;
        private double bestBidPrice;
        private double bestAskPrice;
        private double lastTradePrice;

        // =====================================================
        // LEVEL II MANUAL TRIGGER (VISUAL ONLY)
        // =====================================================
        // Uses only live Level II context: top-of-book pressure +
        // aggressive tape + short persistence. It NEVER submits orders.
        private readonly Queue<int> l2TriggerVotes =
            new Queue<int>();

        private DateTime lastL2TriggerEvalUtc =
            DateTime.MinValue;

        private DateTime lastL2ArrowUtc =
            DateTime.MinValue;

        private int lastL2ArrowDirection =
            0;

        private const int L2TriggerVoteWindow = 6;
        private const int L2TriggerPersistenceRequired = 5;
        private const int L2TriggerEvalMilliseconds = 1000;
        private const int L2TriggerCooldownSeconds = 15;
        private const int L2TriggerTapeWindowSeconds = 5;
        private const double L2TriggerBookShare = 0.56;
        private const double L2TriggerTapeRatio = 1.25;
        private const long L2TriggerMinTapeDelta = 75;
        private const double L2TriggerMaxSpreadTicks = 2.0;
        private const int L2TriggerArrowOffsetTicks = 8;

        private const int LiquidityUiThrottleMs = 200;
        private const int LiquidityHistoryBars = 80;
        private const int ConsumedMarkerSeconds = 12;

        private const int FastEmaPeriod = 9;
        private const int SlowEmaPeriod = 50;

      

        private const int VwapStartTime = 93000;

     

        // =====================================================
        // V1.7.100 - MULTI-PROFILE LINK
        // =====================================================
        // Before: the chart looked up the bot by instrument only, and
        // JJBotSharedState returns null when 2+ profiles publish the same
        // instrument -> "NO LINK". Now:
        //  - "Linked Account" set  -> show exactly that account's bot.
        //  - empty + 1 bot         -> that bot (same as before).
        //  - empty + 2+ bots       -> the one in a position, else the
        //    running one, else first by account name (stable, no flicker).
        private int linkedBotCount;

        private JJBotSharedSnapshot ResolveLinkedSnapshot()
        {
            List<JJBotSharedSnapshot> bots;

            try
            {
                bots = JJBotSharedState.GetSnapshotsForInstrument(Instrument.FullName);
            }
            catch
            {
                bots = new List<JJBotSharedSnapshot>();
            }

            linkedBotCount = bots.Count;

            if (bots.Count == 0)
                return null;

            string wanted = (LinkedAccount ?? string.Empty).Trim();

            if (wanted.Length > 0)
            {
                return bots.FirstOrDefault(b =>
                    string.Equals(
                        (b.AccountName ?? string.Empty).Trim(),
                        wanted,
                        StringComparison.OrdinalIgnoreCase));
            }

            if (bots.Count == 1)
                return bots[0];

            return bots
                .OrderByDescending(b => b.PositionQty != 0)
                .ThenByDescending(b => b.IsRunning)
                .ThenBy(b => b.AccountName ?? string.Empty, StringComparer.OrdinalIgnoreCase)
                .First();
        }

        // =====================================================
        // V1.7.100 - BOT PANEL INSIDE CHART TRADER
        // =====================================================
        // The "J&J AUTO BOT" panel is shown in the Chart Trader column
        // (right side, under Bid/Ask). If Chart Trader is hidden or not
        // available, it falls back to the old box at the chart's bottom-right.
        private System.Windows.Controls.Grid ctGrid;
        private System.Windows.Controls.Border ctPanel;
        private System.Windows.Controls.TextBlock ctText;
        private System.Windows.Controls.RowDefinition ctRow;
        private volatile bool ctPanelVisible;

        private void ShowLiveBotPanel(string text, Brush color)
        {
            if (PanelInChartTrader && ChartControl != null)
            {
                try
                {
                    ChartControl.Dispatcher.InvokeAsync(() =>
                    {
                        try
                        {
                            UpdateChartTraderBotPanel(text, color);
                        }
                        catch
                        {
                            ctPanelVisible = false;
                        }
                    });
                }
                catch
                {
                    ctPanelVisible = false;
                }

                if (ctPanelVisible)
                {
                    RemoveDrawObject("JJ_LIVE_ADDON_PANEL");
                    return;
                }
            }

            Draw.TextFixed(
                this,
                "JJ_LIVE_ADDON_PANEL",
                text,
                TextPosition.BottomRight,
                color,
                new SimpleFont("Consolas", 10),
                Brushes.DimGray,
                new SolidColorBrush(Color.FromArgb(225, 12, 17, 24)),
                90
            );
        }

        // UI thread only
        private void UpdateChartTraderBotPanel(string text, Brush color)
        {
            if (ctText == null)
            {
                NinjaTrader.Gui.Chart.Chart chartWindow =
                    System.Windows.Window.GetWindow(ChartControl.Parent) as NinjaTrader.Gui.Chart.Chart;

                if (chartWindow == null)
                {
                    ctPanelVisible = false;
                    return;
                }

                NinjaTrader.Gui.Chart.ChartTrader chartTrader =
                    chartWindow.FindFirst("ChartWindowChartTraderControl") as NinjaTrader.Gui.Chart.ChartTrader;

                ctGrid = chartTrader != null
                    ? chartTrader.Content as System.Windows.Controls.Grid
                    : null;

                if (ctGrid == null)
                {
                    ctPanelVisible = false;
                    return;
                }

                ctText = new System.Windows.Controls.TextBlock
                {
                    FontFamily = new FontFamily("Consolas"),
                    FontSize = 10,
                    TextWrapping = System.Windows.TextWrapping.Wrap,
                    Margin = new System.Windows.Thickness(0)
                };

                System.Windows.Controls.ScrollViewer scroller =
                    new System.Windows.Controls.ScrollViewer
                    {
                        VerticalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                        HorizontalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Disabled,
                        Content = ctText
                    };

                ctPanel = new System.Windows.Controls.Border
                {
                    Background = new SolidColorBrush(Color.FromArgb(235, 12, 17, 24)),
                    BorderBrush = Brushes.DimGray,
                    BorderThickness = new System.Windows.Thickness(1),
                    Padding = new System.Windows.Thickness(4),
                    Margin = new System.Windows.Thickness(0, 6, 0, 0),
                    Child = scroller
                };

                ctRow = new System.Windows.Controls.RowDefinition
                {
                    Height = new System.Windows.GridLength(1, System.Windows.GridUnitType.Star)
                };

                ctGrid.RowDefinitions.Add(ctRow);

                System.Windows.Controls.Grid.SetRow(ctPanel, ctGrid.RowDefinitions.Count - 1);
                System.Windows.Controls.Grid.SetColumnSpan(ctPanel, Math.Max(1, ctGrid.ColumnDefinitions.Count));

                ctGrid.Children.Add(ctPanel);
            }

            ctText.Text = text;
            ctText.Foreground = color;

            // Chart Trader hidden -> fall back to the on-chart box
            ctPanelVisible = ctGrid != null && ctGrid.IsVisible;
        }

        private void RemoveChartTraderBotPanel()
        {
            try
            {
                if (ChartControl == null || ctGrid == null)
                    return;

                ChartControl.Dispatcher.InvokeAsync(() =>
                {
                    try
                    {
                        if (ctPanel != null)
                            ctGrid.Children.Remove(ctPanel);

                        if (ctRow != null)
                            ctGrid.RowDefinitions.Remove(ctRow);
                    }
                    catch
                    {
                    }

                    ctPanel = null;
                    ctText = null;
                    ctRow = null;
                    ctGrid = null;
                    ctPanelVisible = false;
                });
            }
            catch
            {
            }
        }

        #region Properties

        [Display(
            Name = "Linked Account (empty = auto)",
            Description = "Account whose JJ Bot this chart shows. Empty = auto-pick when several profiles run the same instrument.",
            Order = 0,
            GroupName = "Bot Link")]
        public string LinkedAccount
        { get; set; }

        [Display(
            Name = "Bot panel in Chart Trader",
            Description = "Show the J&J AUTO BOT panel in the Chart Trader column (under Bid/Ask). Off = box at the bottom-right of the chart.",
            Order = 1,
            GroupName = "Bot Link")]
        public bool PanelInChartTrader
        { get; set; }


        [NinjaScriptProperty]
        [Display(
            Name = "Show EMA 9",
            Order = 1,
            GroupName = "Visual")]
        public bool ShowEmaFast
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show EMA 50",
            Order = 2,
            GroupName = "Visual")]
        public bool ShowEmaSlow
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Session VWAP",
            Order = 3,
            GroupName = "Visual")]
        public bool ShowVwap
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show VWAP Deviation Bands",
            Description = "Shows +/-1 sigma and +/-2 sigma around the 09:30 ET session VWAP.",
            Order = 4,
            GroupName = "Visual")]
        public bool ShowVwapBands
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Latest Sweep",
            Order = 4,
            GroupName = "Visual")]
        public bool ShowSweeps
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Latest BOS / CHOCH",
            Order = 5,
            GroupName = "Visual")]
        public bool ShowStructure
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Entry Arrows",
            Order = 6,
            GroupName = "Visual")]
        public bool ShowSignals
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Status Panel",
            Order = 7,
            GroupName = "Visual")]
        public bool ShowStatusPanel
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Liquidity Map",
            Order = 1,
            GroupName = "Liquidity Map")]
        public bool ShowLiquidityMap
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Liquidity Walls",
            Order = 2,
            GroupName = "Liquidity Map")]
        public bool ShowLiquidityWalls
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Liquidity Zones",
            Order = 3,
            GroupName = "Liquidity Map")]
        public bool ShowLiquidityZones
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Absorption",
            Order = 4,
            GroupName = "Liquidity Map")]
        public bool ShowAbsorption
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Consumed Liquidity",
            Order = 5,
            GroupName = "Liquidity Map")]
        public bool ShowConsumedLiquidity
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10000)]
        [Display(
            Name = "Minimum Wall Size",
            Description = "Absolute minimum displayed depth size before a level can become a wall.",
            Order = 6,
            GroupName = "Liquidity Map")]
        public int LiquidityMinWallSize
        { get; set; }

        [NinjaScriptProperty]
        [Range(1.0, 10.0)]
        [Display(
            Name = "Wall Strength Multiplier",
            Description = "Current size divided by average visible depth. Example: 1.5 means 1.5x average.",
            Order = 7,
            GroupName = "Liquidity Map")]
        public double LiquidityWallMultiplier
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(
            Name = "Max Walls Per Side",
            Order = 8,
            GroupName = "Liquidity Map")]
        public int LiquidityMaxWallsPerSide
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(
            Name = "Zone Cluster Ticks",
            Description = "Maximum tick distance between adjacent walls for them to be grouped into one zone.",
            Order = 9,
            GroupName = "Liquidity Map")]
        public int LiquidityZoneClusterTicks
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(
            Name = "Absorption Window Seconds",
            Order = 10,
            GroupName = "Liquidity Map")]
        public int LiquidityAbsorptionWindowSeconds
        { get; set; }

        [NinjaScriptProperty]
        [Range(0.25, 10.0)]
        [Display(
            Name = "Absorption Volume Multiplier",
            Description = "Aggressive traded volume required relative to the visible wall size.",
            Order = 11,
            GroupName = "Liquidity Map")]
        public double LiquidityAbsorptionMultiplier
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Large Pending Orders",
            Description = "Shows exact visible Level II size at large BID/ASK price levels.",
            Order = 12,
            GroupName = "Liquidity Map")]
        public bool ShowLargePendingOrders
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 100000)]
        [Display(
            Name = "Pending Order Min Size",
            Description = "Absolute minimum visible Level II size required for an exact pending-order marker.",
            Order = 13,
            GroupName = "Liquidity Map")]
        public int PendingOrderMinSize
        { get; set; }

        [NinjaScriptProperty]
        [Range(1.0, 20.0)]
        [Display(
            Name = "Pending Order Multiplier",
            Description = "Visible size divided by average depth. Example: 2.0 means at least 2x average.",
            Order = 14,
            GroupName = "Liquidity Map")]
        public double PendingOrderMultiplier
        { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(
            Name = "Max Pending Orders Per Side",
            Description = "Maximum exact BID and ASK pending-order markers shown at once.",
            Order = 15,
            GroupName = "Liquidity Map")]
        public int MaxPendingOrdersPerSide
        { get; set; }

        [Display(
            Name = "Show CORE20 Zones",
            Description = "ONH / ONL / PDH / PDL used by CORE20, with the 8-tick trigger band.",
            Order = 1,
            GroupName = "CORE20")]
        public bool ShowCore20Zones
        { get; set; }

        [Display(
            Name = "Show CORE20 Bot Triggers",
            Description = "Marks every SWEEP / BREAK the bot evaluated (ENTRY or SKIP + reason).",
            Order = 2,
            GroupName = "CORE20")]
        public bool ShowCore20Events
        { get; set; }

        [Range(1, 20)]
        [Display(
            Name = "CORE20 Days To Show",
            Order = 3,
            GroupName = "CORE20")]
        public int Core20DaysToShow
        { get; set; }

        #endregion

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                LinkedAccount = string.Empty;
                PanelInChartTrader = true;
                Description =
                    "Clean visual companion for J&J NY Trading Bot. "
                    + "Displays EMA 9/50, session VWAP, latest sweep, "
                    + "latest BOS/CHOCH, Range-20 momentum, learning, "
                    + "trailing state and real AddOn execution. "
                    + "This indicator does NOT submit orders.";

                Name =
                    "JJBotChart";

                Calculate =
                    Calculate.OnBarClose;

                IsOverlay =
                    true;

                DisplayInDataBox =
                    true;

                DrawOnPricePanel =
                    true;

                PaintPriceMarkers =
                    true;

                IsSuspendedWhileInactive =
                    true;

                BarsRequiredToPlot =
                    50;

                ShowEmaFast =
                    true;

                ShowEmaSlow =
                    true;

                ShowVwap =
                    true;

                ShowVwapBands =
                    true;

                ShowSweeps =
                    true;

                ShowStructure =
                    true;

                ShowSignals =
                    true;

                ShowStatusPanel =
                    true;

                ShowLiquidityMap =
                    true;

                ShowLiquidityWalls =
                    true;

                ShowLiquidityZones =
                    true;

                ShowAbsorption =
                    true;

                ShowConsumedLiquidity =
                    true;

                LiquidityMinWallSize =
                    15;

                LiquidityWallMultiplier =
                    1.50;

                // FIX2: keep the live chart clean.
                LiquidityMaxWallsPerSide =
                    3;

                LiquidityZoneClusterTicks =
                    4;

                LiquidityAbsorptionWindowSeconds =
                    3;

                LiquidityAbsorptionMultiplier =
                    1.00;

                ShowLargePendingOrders =
                    true;

                PendingOrderMinSize =
                    25;

                PendingOrderMultiplier =
                    2.00;

                MaxPendingOrdersPerSide =
                    5;

                ShowCore20Zones =
                    true;

                ShowCore20Events =
                    true;

                Core20DaysToShow =
                    3;

                AddPlot(
                    Brushes.DeepSkyBlue,
                    "EMA9"
                );

                AddPlot(
                    Brushes.Goldenrod,
                    "EMA50"
                );

                AddPlot(
                    Brushes.MediumPurple,
                    "SessionVWAP"
                );

                AddPlot(
                    Brushes.SlateBlue,
                    "VWAPUpper1"
                );

                AddPlot(
                    Brushes.DarkSlateBlue,
                    "VWAPUpper2"
                );

                AddPlot(
                    Brushes.SlateBlue,
                    "VWAPLower1"
                );

                AddPlot(
                    Brushes.DarkSlateBlue,
                    "VWAPLower2"
                );
            }
            else if (State == State.DataLoaded)
            {
                emaFast =
                    EMA(
                        FastEmaPeriod
                    );

                emaSlow =
                    EMA(
                        SlowEmaPeriod
                    );

                vwapNyDate =
                    DateTime.MinValue;

                cumulativePriceVolume =
                    0;

                cumulativePriceSquaredVolume =
                    0;

                cumulativeVolume =
                    0;

                currentVwap =
                    0;

                currentVwapStdDev = 0;
                currentVwapUpper1 = 0;
                currentVwapUpper2 = 0;
                currentVwapLower1 = 0;
                currentVwapLower2 = 0;
                currentVwapZScore = 0;
                currentVwapBandWidthRatio = 1.0;
                currentVwapLocation = "WAITING";
                currentVwapBandState = "WAITING";
                currentVwapSlope = "FLAT";
                currentVwapEntryContext = "NEUTRAL";
                previousVwapForSlope = 0;
                vwapWidthSessionDate = DateTime.MinValue;
                recentVwapBandWidths.Clear();

               

                sharedSnapshot =
                    ResolveLinkedSnapshot();

                lastExecutionSequence =
                    sharedSnapshot != null
                        ? sharedSnapshot.ExecutionSequence
                        : 0;

                lastSharedUiRefreshUtc =
                    DateTime.MinValue;

                lastLiquidityRenderUtc =
                    DateTime.MinValue;

                liquidityRenderPending =
                    false;

                bestBidPrice =
                    0;

                bestAskPrice =
                    0;

                lastTradePrice =
                    0;

                lock (liquidityLock)
                {
                    bidDepth.Clear();
                    askDepth.Clear();
                    recentTradePrints.Clear();
                    consumedLiquidity.Clear();
                    previousBidWalls.Clear();
                    previousAskWalls.Clear();
                }

                JJBotSharedState.StateChanged +=
                    OnSharedBotStateChanged;

                sharedStateSubscribed =
                    true;

                c20Overnight.Clear();
                c20Rth.Clear();
                c20DrawnKey.Clear();
                c20DrawnDates.Clear();
                c20Tags.Clear();
                c20LastBusVersion = -1;

                JJCore20ZoneBus.Changed +=
                    OnCore20ZoneBusChanged;

                c20BusSubscribed =
                    true;

              

                DrawSharedBotPanel();
            }
            else if (State == State.Terminated)
            {
                if (sharedStateSubscribed)
                {
                    JJBotSharedState.StateChanged -=
                        OnSharedBotStateChanged;

                    sharedStateSubscribed =
                        false;
                }

                if (c20BusSubscribed)
                {
                    JJCore20ZoneBus.Changed -=
                        OnCore20ZoneBusChanged;

                    c20BusSubscribed =
                        false;
                }

                ClearLiquidityDrawObjects();

                RemoveChartTraderBotPanel();
            }
        }

       protected override void OnBarUpdate()
{
    // =====================================================
    // REAL BOT STATE
    // =====================================================
    // JJBotChart NEVER decides entries.
    // It only reads the state published by JJBotWindow.
    sharedSnapshot =
        ResolveLinkedSnapshot();

    // Always refresh the real bot panel, even while
    // the chart is still loading enough bars for EMA.
    DrawSharedBotPanel();

    // V1.7.35 - CORE20 zones (visual only, every bar).
    UpdateCore20Zones();

    if (!ShowLiquidityMap)
    {
        ClearLiquidityDrawObjects();
    }

    if (
        CurrentBar <
            SlowEmaPeriod + 10
    )
    {
        if (ShowStatusPanel)
        {
            DrawBotStatusPanel(
                DateTime.MinValue,
                double.NaN,
                double.NaN
            );
        }

        return;
    }

    // =====================================================
    // VISUAL-ONLY CALCULATIONS
    // =====================================================
    // EMA and VWAP are calculated here ONLY so their lines
    // can be painted on the chart.
    //
    // They are NOT used for entry decisions.
    // The AddOn remains the only trading engine.
    double fast =
        emaFast[0];

    double slow =
        emaSlow[0];

    Values[0][0] =
        ShowEmaFast
            ? fast
            : double.NaN;

    Values[1][0] =
        ShowEmaSlow
            ? slow
            : double.NaN;

    DateTime nyTime =
        ConvertToNewYorkTime(
            Time[0]
        );

    int nyTimeInt =
        ToTimeInt(
            nyTime
        );

    UpdateSessionVwap(
        nyTime,
        nyTimeInt
    );

    Values[2][0] =
        ShowVwap &&
        currentVwap > 0
            ? currentVwap
            : double.NaN;

    Values[3][0] =
        ShowVwapBands && currentVwapUpper1 > 0
            ? currentVwapUpper1
            : double.NaN;

    Values[4][0] =
        ShowVwapBands && currentVwapUpper2 > 0
            ? currentVwapUpper2
            : double.NaN;

    Values[5][0] =
        ShowVwapBands && currentVwapLower1 > 0
            ? currentVwapLower1
            : double.NaN;

    Values[6][0] =
        ShowVwapBands && currentVwapLower2 > 0
            ? currentVwapLower2
            : double.NaN;

    UpdateVwapVisualContext(
        nyTime
    );

    // =====================================================
    // IMPORTANT
    // =====================================================
    // DO NOT call:
    //
    // DetectCurrentSweep()
    // UpdateStructureConfirmation()
    // DrawSignal()
    //
    // Sweep, structure, signal and setup now come ONLY
    // from JJBotWindow through JJBotSharedSnapshot.

    if (ShowStatusPanel)
    {
        DrawBotStatusPanel(
            nyTime,
            fast,
            slow
        );
    }
    else
    {
        RemoveDrawObject(
            "JJ_STATUS_PANEL"
        );
    }
}

        // =====================================================
        // REAL ADDON BRIDGE
        // =====================================================
        private void OnSharedBotStateChanged()
        {
            if (
                State == State.Terminated
            )
            {
                return;
            }

            try
            {
                JJBotSharedSnapshot latest =
                    ResolveLinkedSnapshot();

                // A real execution must never be hidden by the UI throttle.
                bool executionChanged =
                    latest != null &&
                    latest.ExecutionSequence !=
                        lastExecutionSequence;

                DateTime nowUtc =
                    DateTime.UtcNow;

                if (
                    !executionChanged &&
                    lastSharedUiRefreshUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSharedUiRefreshUtc
                    ).TotalMilliseconds <
                        SharedUiRefreshThrottleMs
                )
                {
                    return;
                }

                lastSharedUiRefreshUtc =
                    nowUtc;

                TriggerCustomEvent(
                    o =>
                    {
                        DrawSharedBotPanel();
                        DrawRealExecutionMarker();
                    },
                    null
                );
            }
            catch
            {
            }
        }

        private void DrawSharedBotPanel()
        {
            sharedSnapshot =
                ResolveLinkedSnapshot();

            if (sharedSnapshot == null)
            {
                // The AddOn snapshot was removed (window/account/instrument
                // lifecycle reset). Reset the execution sequence baseline so
                // a newly opened bot can start again from sequence 0/1.
                lastExecutionSequence =
                    0;

                // IMPORTANT V7.1:
                // Never leave the previous instrument's fixed panel on the
                // chart. If no bot snapshot exists for this exact instrument,
                // explicitly replace it with a NO LINK panel.
                string noLinkText =
                    "J&J AUTO BOT • NO LINK"
                    + "\n"
                    + "────────────────────────"
                    + "\n"
                    + "Chart: "
                    + Instrument.FullName
                    + "\n"
                    + "Waiting for matching bot window...";

                ShowLiveBotPanel(noLinkText, Brushes.Goldenrod);

                return;
            }

            bool sameInstrument =
                !string.IsNullOrWhiteSpace(
                    sharedSnapshot.InstrumentName
                ) &&
                string.Equals(
                    sharedSnapshot.InstrumentName,
                    Instrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                );

            string botState =
                sharedSnapshot.IsRunning
                    ? "ARMED"
                    : "STOPPED";

            string account =
                string.IsNullOrWhiteSpace(
                    sharedSnapshot.AccountName
                )
                    ? "--"
                    : sharedSnapshot.AccountName;

            string instrument =
                string.IsNullOrWhiteSpace(
                    sharedSnapshot.InstrumentName
                )
                    ? "--"
                    : sharedSnapshot.InstrumentName;

            string linkState =
                sameInstrument
                    ? (linkedBotCount > 1
                        ? "LINKED (" + linkedBotCount + " bots)"
                        : "LINKED")
                    : "NO LINK";

            string learningState =
                sharedSnapshot.LearningActive
                    ? "ACTIVE"
                    : "OFF";

            string text =
                "J&J AUTO BOT • "
                + botState
                + "\n"
                + "────────────────────────\n"
                + "Link: "
                + linkState
                + "\n"
                + "Account: "
                + account
                + "\n"
                + "Instrument: "
                + instrument
                + "\n"
                + "Strategy: "
                + sharedSnapshot.StrategyMode
                + "\n"
                + "Session: "
                + sharedSnapshot.SessionWindow
                + "\n"
                + "────────────────────────\n"
                + "4H Context: "
                + sharedSnapshot.H4Trend
                + "\n"
                + "1H Context: "
                + sharedSnapshot.H1Trend
                + "\n"
                + "HTF Score: "
                + sharedSnapshot.HtfContextBias
                + "\n"
                + "────────────────────────\n"
                + "M5: "
                + sharedSnapshot.M5Trend
                + " | "
                + sharedSnapshot.M5VwapSide
                + "\n"
                + "VWAP Loc: "
                + sharedSnapshot.M5VwapLocation
                + " | "
                + sharedSnapshot.M5VwapBandState
                + " | Z "
                + sharedSnapshot.M5VwapZScore.ToString("0.00")
                + "\n"
                + "VWAP Ctx: "
                + sharedSnapshot.M5VwapEntryContext
                + "\n"
                + "Sweep: "
                + sharedSnapshot.M5Liquidity
                + "\n"
                + "Structure: "
                + sharedSnapshot.M5Structure
                + "\n"
                + "R20 Momentum: "
                + sharedSnapshot.RangeMomentum
                + "\n"
                + "R20 Score: L "
                + sharedSnapshot.RangeLongScore
                + "/5 | S "
                + sharedSnapshot.RangeShortScore
                + "/5"
                + "\n"
                + "────────────────────────\n"
                + "Learning: "
                + learningState
                + " | "
                + sharedSnapshot.LearningTrades
                + " trades"
                + " | "
                + sharedSnapshot.LearningPatterns
                + " patterns"
                + "\n"
                + "Trailing: "
                + sharedSnapshot.TrailingState
                + "\n"
                + "────────────────────────\n"
                + "Trades AM: "
                + sharedSnapshot.AmTrades
                + " / "
                + sharedSnapshot.MaxTrades
                + "\n"
                + "Trades PM: "
                + sharedSnapshot.PmTrades
                + " / "
                + sharedSnapshot.MaxTrades
                + "\n"
                + "Trades Day: "
                + sharedSnapshot.TradesToday
                + "\n"
                + "Realized: "
                + sharedSnapshot.RealizedPnL.ToString("$0.00")
                + "\n"
                + "Unrealized: "
                + sharedSnapshot.UnrealizedPnL.ToString("$0.00")
                + "\n"
                + "Total: "
                + sharedSnapshot.TotalPnL.ToString("$0.00")
                + "\n"
                + "Position: "
                + sharedSnapshot.Position
                + " x"
                + sharedSnapshot.PositionQty
                + "\n"
                + "Order: "
                + sharedSnapshot.OrderStatus
                + "\n"
                + "Signal: "
                + sharedSnapshot.Signal
                + "\n"
                + "Setup: "
                + sharedSnapshot.Setup
                + "\n"
                + "Daily Lock: "
                + (
                    sharedSnapshot.DailyLocked
                        ? "YES"
                        : "NO"
                );

            Brush stateBrush =
                sharedSnapshot.DailyLocked
                    ? Brushes.OrangeRed
                    : sharedSnapshot.IsRunning
                        ? Brushes.LimeGreen
                        : Brushes.LightGray;

            ShowLiveBotPanel(text, stateBrush);
        }

        private void DrawRealExecutionMarker()
        {
            JJBotSharedSnapshot snapshot =
                ResolveLinkedSnapshot();

            if (snapshot == null)
            {
                lastExecutionSequence =
                    0;

                return;
            }

            // New AddOn lifecycle: execution sequence restarted.
            // Rebase instead of suppressing new execution markers until
            // the new sequence catches the previous window's value.
            if (
                snapshot.ExecutionSequence <
                    lastExecutionSequence
            )
            {
                lastExecutionSequence =
                    0;
            }

            if (
                snapshot.ExecutionSequence <=
                    lastExecutionSequence
            )
            {
                return;
            }

            lastExecutionSequence =
                snapshot.ExecutionSequence;

            if (
                string.IsNullOrWhiteSpace(
                    snapshot.InstrumentName
                ) ||
                !string.Equals(
                    snapshot.InstrumentName,
                    Instrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                ) ||
                snapshot.LastExecutionPrice <= 0
            )
            {
                return;
            }

            string tag =
                "JJ_REAL_EXEC_"
                + snapshot.ExecutionSequence;

            bool isBuy =
                string.Equals(
                    snapshot.LastExecutionSide,
                    "BUY",
                    StringComparison.OrdinalIgnoreCase
                );

            if (isBuy)
            {
                Draw.ArrowUp(
                    this,
                    tag,
                    false,
                    0,
                    snapshot.LastExecutionPrice
                        - 4 * TickSize,
                    Brushes.LimeGreen
                );

                Draw.Text(
                    this,
                    tag + "_TEXT",
                    "BUY EXECUTED",
                    0,
                    snapshot.LastExecutionPrice
                        - 12 * TickSize,
                    Brushes.LimeGreen
                );
            }
            else
            {
                Draw.ArrowDown(
                    this,
                    tag,
                    false,
                    0,
                    snapshot.LastExecutionPrice
                        + 4 * TickSize,
                    Brushes.OrangeRed
                );

                Draw.Text(
                    this,
                    tag + "_TEXT",
                    "SELL EXECUTED",
                    0,
                    snapshot.LastExecutionPrice
                        + 12 * TickSize,
                    Brushes.OrangeRed
                );
            }
        }

        // =====================================================
        // SESSION VWAP
        // =====================================================
        private void UpdateSessionVwap(
            DateTime nyTime,
            int nyTimeInt)
        {
            if (
                vwapNyDate !=
                    nyTime.Date
            )
            {
                vwapNyDate =
                    nyTime.Date;

                cumulativePriceVolume = 0;
                cumulativePriceSquaredVolume = 0;
                cumulativeVolume = 0;

                currentVwap = 0;
                currentVwapStdDev = 0;
                currentVwapUpper1 = 0;
                currentVwapUpper2 = 0;
                currentVwapLower1 = 0;
                currentVwapLower2 = 0;

                currentVwapZScore = 0;
                currentVwapBandWidthRatio = 1.0;
                currentVwapLocation = "WAITING";
                currentVwapBandState = "WAITING";
                currentVwapSlope = "FLAT";
                currentVwapEntryContext = "NEUTRAL";

                previousVwapForSlope = 0;
                vwapWidthSessionDate = nyTime.Date;
                recentVwapBandWidths.Clear();
            }

            if (
                nyTimeInt <
                    VwapStartTime
            )
            {
                currentVwap = 0;
                currentVwapStdDev = 0;
                currentVwapUpper1 = 0;
                currentVwapUpper2 = 0;
                currentVwapLower1 = 0;
                currentVwapLower2 = 0;
                return;
            }

            double barVolume =
                Volume[0];

            if (barVolume <= 0)
                return;

            double typicalPrice =
                (
                    High[0]
                    + Low[0]
                    + Close[0]
                )
                / 3.0;

            cumulativePriceVolume +=
                typicalPrice *
                barVolume;

            cumulativePriceSquaredVolume +=
                typicalPrice *
                typicalPrice *
                barVolume;

            cumulativeVolume +=
                barVolume;

            if (cumulativeVolume <= 0)
                return;

            currentVwap =
                cumulativePriceVolume /
                cumulativeVolume;

            double variance =
                (
                    cumulativePriceSquaredVolume /
                    cumulativeVolume
                )
                -
                (
                    currentVwap *
                    currentVwap
                );

            if (variance < 0)
                variance = 0;

            currentVwapStdDev =
                Math.Sqrt(
                    variance
                );

            currentVwapUpper1 =
                currentVwap +
                currentVwapStdDev;

            currentVwapUpper2 =
                currentVwap +
                (2.0 * currentVwapStdDev);

            currentVwapLower1 =
                currentVwap -
                currentVwapStdDev;

            currentVwapLower2 =
                currentVwap -
                (2.0 * currentVwapStdDev);
        }

        private void UpdateVwapVisualContext(
            DateTime nyTime)
        {
            if (
                currentVwap <= 0 ||
                currentVwapStdDev <= 0
            )
            {
                currentVwapZScore = 0;
                currentVwapBandWidthRatio = 1.0;
                currentVwapLocation = "WAITING";
                currentVwapBandState = "WAITING";
                currentVwapSlope = "FLAT";
                currentVwapEntryContext = "NEUTRAL";
                return;
            }

            currentVwapZScore =
                (Close[0] - currentVwap) /
                currentVwapStdDev;

            currentVwapLocation =
                currentVwapZScore >= 1.50
                    ? "UPPER EXTREME"
                    : currentVwapZScore >= 0.50
                        ? "UPPER 1"
                        : currentVwapZScore <= -1.50
                            ? "LOWER EXTREME"
                            : currentVwapZScore <= -0.50
                                ? "LOWER 1"
                                : "CENTER";

            if (previousVwapForSlope <= 0)
            {
                currentVwapSlope = "FLAT";
            }
            else
            {
                double delta =
                    currentVwap -
                    previousVwapForSlope;

                currentVwapSlope =
                    delta >= Math.Max(TickSize, 0.0000001)
                        ? "UP"
                        : delta <= -Math.Max(TickSize, 0.0000001)
                            ? "DOWN"
                            : "FLAT";
            }

            previousVwapForSlope =
                currentVwap;

            if (
                vwapWidthSessionDate !=
                    nyTime.Date
            )
            {
                vwapWidthSessionDate =
                    nyTime.Date;

                recentVwapBandWidths.Clear();
            }

            double bandWidth =
                currentVwapUpper2 -
                currentVwapLower2;

            double averageWidth =
                recentVwapBandWidths.Count > 0
                    ? recentVwapBandWidths.Average()
                    : 0;

            currentVwapBandWidthRatio =
                averageWidth > 0
                    ? bandWidth / averageWidth
                    : 1.0;

            currentVwapBandState =
                "NORMAL";

            if (
                recentVwapBandWidths.Count >= 4
            )
            {
                if (currentVwapBandWidthRatio <= 0.82)
                    currentVwapBandState = "COMPRESSION";
                else if (currentVwapBandWidthRatio >= 1.18)
                    currentVwapBandState = "EXPANSION";
            }

            if (bandWidth > 0)
            {
                recentVwapBandWidths.Enqueue(
                    bandWidth
                );

                while (
                    recentVwapBandWidths.Count > 12
                )
                {
                    recentVwapBandWidths.Dequeue();
                }
            }

            if (currentVwapLocation == "LOWER EXTREME")
            {
                currentVwapEntryContext =
                    currentVwapBandState == "COMPRESSION"
                        ? "FAVORABLE LONG / SQUEEZE"
                        : "FAVORABLE LONG";
            }
            else if (currentVwapLocation == "LOWER 1")
            {
                currentVwapEntryContext =
                    currentVwapSlope == "UP"
                        ? "GOOD LONG ZONE"
                        : "LONG LOCATION";
            }
            else if (currentVwapLocation == "UPPER EXTREME")
            {
                currentVwapEntryContext =
                    currentVwapBandState == "COMPRESSION"
                        ? "FAVORABLE SHORT / SQUEEZE"
                        : "FAVORABLE SHORT";
            }
            else if (currentVwapLocation == "UPPER 1")
            {
                currentVwapEntryContext =
                    currentVwapSlope == "DOWN"
                        ? "GOOD SHORT ZONE"
                        : "SHORT LOCATION";
            }
            else
            {
                currentVwapEntryContext =
                    currentVwapBandState == "COMPRESSION"
                        ? "CENTER / COMPRESSION"
                        : "NEUTRAL";
            }
        }


        // =====================================================
        // STATUS PANEL
        // =====================================================
      // =====================================================
// REAL BOT STATUS PANEL
// =====================================================
// All trading decisions shown here come from JJBotWindow.
//
// EMA9 / EMA50 / VWAP numeric values are local visual
// calculations only and DO NOT control entries.
private void DrawBotStatusPanel(
    DateTime nyTime,
    double fast,
    double slow)
{
    sharedSnapshot =
        ResolveLinkedSnapshot();

    // =====================================================
    // NO BOT LINK
    // =====================================================
    if (sharedSnapshot == null)
    {
        string noLinkText =
            "J&J NY BOT • VISUAL\n"
            + "────────────────────\n"
            + "Chart: "
            + Instrument.FullName
            + "\n"
            + "Bot: NO LINK\n"
            + "Waiting for JJBotWindow...";

        Draw.TextFixed(
            this,
            "JJ_STATUS_PANEL",
            noLinkText,
            TextPosition.TopRight,
            Brushes.Goldenrod,
            new SimpleFont(
                "Consolas",
                12
            ),
            Brushes.DimGray,
            new SolidColorBrush(
                Color.FromArgb(
                    220,
                    12,
                    17,
                    24
                )
            ),
            85
        );

        return;
    }

    // =====================================================
    // REAL ADDON VALUES
    // =====================================================
    string sessionText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.SessionWindow
        )
            ? "OUTSIDE"
            : sharedSnapshot.SessionWindow;

    string trendText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Trend
        )
            ? "WAITING"
            : sharedSnapshot.M5Trend;

    string vwapSideText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapSide
        )
            ? "WAITING"
            : sharedSnapshot.M5VwapSide;

    string liquidityTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Liquidity
        )
            ? "NONE"
            : sharedSnapshot.M5Liquidity;

    string structureTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Structure
        )
            ? "WAITING"
            : sharedSnapshot.M5Structure;

    string signalTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.Signal
        )
            ? "WAITING"
            : sharedSnapshot.Signal;

    string setupTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.Setup
        )
            ? "WAITING"
            : sharedSnapshot.Setup;

    string displayTime =
        nyTime == DateTime.MinValue
            ? "--:--"
            : nyTime.ToString(
                "HH:mm"
            );

    string fastText =
        double.IsNaN(fast)
            ? "--"
            : fast.ToString(
                "0.00"
            );

    string slowText =
        double.IsNaN(slow)
            ? "--"
            : slow.ToString(
                "0.00"
            );

    string vwapValueText =
        currentVwap > 0
            ? currentVwap.ToString(
                "0.00"
            )
            : "--";

    string vwapLocationText =
        !string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapLocation
        )
            ? sharedSnapshot.M5VwapLocation
            : currentVwapLocation;

    string vwapBandStateText =
        !string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapBandState
        )
            ? sharedSnapshot.M5VwapBandState
            : currentVwapBandState;

    string vwapSlopeText =
        !string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapSlope
        )
            ? sharedSnapshot.M5VwapSlope
            : currentVwapSlope;

    string vwapContextText =
        !string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapEntryContext
        )
            ? sharedSnapshot.M5VwapEntryContext
            : currentVwapEntryContext;

    double vwapZ =
        sharedSnapshot.M5VwapStdDev > 0
            ? sharedSnapshot.M5VwapZScore
            : currentVwapZScore;

    string botState =
        sharedSnapshot.IsRunning
            ? "ARMED"
            : "STOPPED";

    string text =
        "J&J NY BOT • "
        + botState
        + "\n"
        + "────────────────────\n"
        + "NY Time: "
        + displayTime
        + " ET\n"
        + "Session: "
        + sessionText
        + "\n"
        + "Trend: "
        + trendText
        + "\n"
        + "EMA9: "
        + fastText
        + "\n"
        + "EMA50: "
        + slowText
        + "\n"
        + "VWAP: "
        + vwapValueText
        + "\n"
        + "Price/VWAP: "
        + vwapSideText
        + "\n"
        + "VWAP Location: "
        + vwapLocationText
        + " | Z "
        + vwapZ.ToString("0.00")
        + "\n"
        + "VWAP Bands: "
        + vwapBandStateText
        + " | Slope "
        + vwapSlopeText
        + "\n"
        + "VWAP Context: "
        + vwapContextText
        + "\n"
        + "Liquidity: "
        + liquidityTextValue
        + "\n"
        + "Structure: "
        + structureTextValue
        + "\n"
        + "Signal: "
        + signalTextValue
        + "\n"
        + "Setup: "
        + setupTextValue;

    Brush textBrush =
        sharedSnapshot.DailyLocked
            ? Brushes.OrangeRed
            : setupTextValue.IndexOf(
                "LONG",
                StringComparison.OrdinalIgnoreCase
            ) >= 0
                ? Brushes.LimeGreen
                : setupTextValue.IndexOf(
                    "SHORT",
                    StringComparison.OrdinalIgnoreCase
                ) >= 0
                    ? Brushes.OrangeRed
                    : sharedSnapshot.IsRunning
                        ? Brushes.WhiteSmoke
                        : Brushes.Gray;

    Draw.TextFixed(
        this,
        "JJ_STATUS_PANEL",
        text,
        TextPosition.TopRight,
        textBrush,
        new SimpleFont(
            "Consolas",
            12
        ),
        Brushes.DimGray,
        new SolidColorBrush(
            Color.FromArgb(
                220,
                12,
                17,
                24
            )
        ),
        85
    );
}


        // =====================================================
        // REAL-TIME LEVEL II / LIQUIDITY MAP
        // =====================================================
        protected override void OnMarketDepth(
            MarketDepthEventArgs marketDepthUpdate)
        {
            if (
                marketDepthUpdate == null ||
                !ShowLiquidityMap
            )
            {
                return;
            }

            bool isBid =
                marketDepthUpdate.MarketDataType ==
                    MarketDataType.Bid;

            bool isAsk =
                marketDepthUpdate.MarketDataType ==
                    MarketDataType.Ask;

            if (!isBid && !isAsk)
            {
                return;
            }

            lock (liquidityLock)
            {
                Dictionary<double, LiquidityLevelInfo> book =
                    isBid
                        ? bidDepth
                        : askDepth;

                double price =
                    Instrument.MasterInstrument.RoundToTickSize(
                        marketDepthUpdate.Price
                    );

                if (
                    string.Equals(
                        marketDepthUpdate.Operation.ToString(),
                        "Remove",
                        StringComparison.OrdinalIgnoreCase
                    ) ||
                    marketDepthUpdate.Volume <= 0
                )
                {
                    book.Remove(
                        price
                    );
                }
                else
                {
                    LiquidityLevelInfo level;

                    if (
                        !book.TryGetValue(
                            price,
                            out level
                        )
                    )
                    {
                        level =
                            new LiquidityLevelInfo();

                        book[price] =
                            level;
                    }

                    level.Price =
                        price;

                    level.Volume =
                        marketDepthUpdate.Volume;

                    level.UpdatedUtc =
                        DateTime.UtcNow;
                }

                if (bidDepth.Count > 0)
                {
                    bestBidPrice =
                        bidDepth.Keys.Max();
                }
                else
                {
                    bestBidPrice =
                        0;
                }

                if (askDepth.Count > 0)
                {
                    bestAskPrice =
                        askDepth.Keys.Min();
                }
                else
                {
                    bestAskPrice =
                        0;
                }
            }

            RequestLiquidityRender();
        }

        protected override void OnMarketData(
            MarketDataEventArgs marketDataUpdate)
        {
            if (
                marketDataUpdate == null ||
                marketDataUpdate.MarketDataType !=
                    MarketDataType.Last ||
                marketDataUpdate.Price <= 0 ||
                marketDataUpdate.Volume <= 0
            )
            {
                return;
            }

            lock (liquidityLock)
            {
                double price =
                    Instrument.MasterInstrument.RoundToTickSize(
                        marketDataUpdate.Price
                    );

                lastTradePrice =
                    price;

                double referenceAsk =
                    marketDataUpdate.Ask > 0
                        ? marketDataUpdate.Ask
                        : bestAskPrice;

                double referenceBid =
                    marketDataUpdate.Bid > 0
                        ? marketDataUpdate.Bid
                        : bestBidPrice;

                bool aggressiveBuy =
                    referenceAsk > 0 &&
                    price >=
                        referenceAsk -
                        TickSize * 0.10;

                bool aggressiveSell =
                    referenceBid > 0 &&
                    price <=
                        referenceBid +
                        TickSize * 0.10;

                recentTradePrints.Enqueue(
                    new TradePrint
                    {
                        Price =
                            price,
                        Volume =
                            marketDataUpdate.Volume,
                        TimeUtc =
                            DateTime.UtcNow,
                        AggressiveBuy =
                            aggressiveBuy,
                        AggressiveSell =
                            aggressiveSell
                    }
                );

                TrimOldTradePrints(
                    DateTime.UtcNow
                );
            }

            EvaluateLevel2ManualTrigger();

            if (ShowLiquidityMap)
            {
                RequestLiquidityRender();
            }
        }

        private void EvaluateLevel2ManualTrigger()
        {
            if (
                State == State.Terminated ||
                CurrentBar < 1 ||
                !ShowSignals
            )
            {
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;

            lock (liquidityLock)
            {
                if (
                    lastL2TriggerEvalUtc != DateTime.MinValue &&
                    (
                        nowUtc -
                        lastL2TriggerEvalUtc
                    ).TotalMilliseconds <
                        L2TriggerEvalMilliseconds
                )
                {
                    return;
                }

                lastL2TriggerEvalUtc = nowUtc;
            }

            long topBidVolume = 0;
            long topAskVolume = 0;
            long aggressiveBuyVolume = 0;
            long aggressiveSellVolume = 0;
            double localBid = 0;
            double localAsk = 0;
            double localLast = 0;

            lock (liquidityLock)
            {
                topBidVolume =
                    bidDepth.Values
                        .Where(x => x != null && x.Volume > 0)
                        .OrderByDescending(x => x.Price)
                        .Take(10)
                        .Sum(x => x.Volume);

                topAskVolume =
                    askDepth.Values
                        .Where(x => x != null && x.Volume > 0)
                        .OrderBy(x => x.Price)
                        .Take(10)
                        .Sum(x => x.Volume);

                DateTime cutoff =
                    nowUtc.AddSeconds(
                        -L2TriggerTapeWindowSeconds
                    );

                foreach (
                    TradePrint trade in recentTradePrints
                )
                {
                    if (
                        trade == null ||
                        trade.TimeUtc < cutoff
                    )
                    {
                        continue;
                    }

                    if (trade.AggressiveBuy)
                    {
                        aggressiveBuyVolume +=
                            trade.Volume;
                    }

                    if (trade.AggressiveSell)
                    {
                        aggressiveSellVolume +=
                            trade.Volume;
                    }
                }

                localBid = bestBidPrice;
                localAsk = bestAskPrice;
                localLast = lastTradePrice;
            }

            long totalBook =
                topBidVolume +
                topAskVolume;

            if (
                totalBook <= 0 ||
                localBid <= 0 ||
                localAsk <= 0 ||
                localLast <= 0
            )
            {
                return;
            }

            double spreadTicks =
                TickSize > 0
                    ? (
                        localAsk -
                        localBid
                      ) / TickSize
                    : 999;

            if (
                spreadTicks <= 0 ||
                spreadTicks >
                    L2TriggerMaxSpreadTicks
            )
            {
                AddLevel2TriggerVote(0);
                return;
            }

            double bidShare =
                (double)topBidVolume /
                totalBook;

            long tapeDelta =
                aggressiveBuyVolume -
                aggressiveSellVolume;

            bool tapeLong =
                tapeDelta >=
                    L2TriggerMinTapeDelta &&
                aggressiveBuyVolume >=
                    Math.Max(
                        1.0,
                        aggressiveSellVolume *
                            L2TriggerTapeRatio
                    );

            bool tapeShort =
                tapeDelta <=
                    -L2TriggerMinTapeDelta &&
                aggressiveSellVolume >=
                    Math.Max(
                        1.0,
                        aggressiveBuyVolume *
                            L2TriggerTapeRatio
                    );

            bool bookLong =
                bidShare >=
                    L2TriggerBookShare;

            bool bookShort =
                bidShare <=
                    1.0 -
                    L2TriggerBookShare;

            int vote =
                bookLong && tapeLong
                    ? 1
                    : bookShort && tapeShort
                        ? -1
                        : 0;

            AddLevel2TriggerVote(vote);

            int longVotes;
            int shortVotes;
            int voteCount;

            lock (liquidityLock)
            {
                longVotes =
                    l2TriggerVotes.Count(x => x > 0);

                shortVotes =
                    l2TriggerVotes.Count(x => x < 0);

                voteCount =
                    l2TriggerVotes.Count;
            }

            if (
                voteCount <
                    L2TriggerVoteWindow
            )
            {
                return;
            }

            int confirmedDirection =
                vote > 0 &&
                longVotes >=
                    L2TriggerPersistenceRequired
                    ? 1
                    : vote < 0 &&
                      shortVotes >=
                        L2TriggerPersistenceRequired
                        ? -1
                        : 0;

            if (confirmedDirection == 0)
            {
                return;
            }

            bool sameDirection =
                confirmedDirection ==
                    lastL2ArrowDirection;

            bool cooldownActive =
                lastL2ArrowUtc != DateTime.MinValue &&
                (
                    nowUtc -
                    lastL2ArrowUtc
                ).TotalSeconds <
                    L2TriggerCooldownSeconds;

            if (
                sameDirection &&
                cooldownActive
            )
            {
                return;
            }

            lastL2ArrowDirection =
                confirmedDirection;

            lastL2ArrowUtc =
                nowUtc;

            string side =
                confirmedDirection > 0
                    ? "BUY"
                    : "SELL";

            string tagBase =
                "JJ_L2_TRIGGER_"
                + side
                + "_"
                + nowUtc.Ticks.ToString();

            double arrowPrice =
                confirmedDirection > 0
                    ? localLast -
                      TickSize *
                      L2TriggerArrowOffsetTicks
                    : localLast +
                      TickSize *
                      L2TriggerArrowOffsetTicks;

            string detail =
                "L2 "
                + side
                + " | Book "
                + Math.Round(
                    bidShare * 100.0,
                    0
                  )
                + "/"
                + Math.Round(
                    (1.0 - bidShare) * 100.0,
                    0
                  )
                + " | TapeDelta "
                + tapeDelta
                + " | Persist "
                + (
                    confirmedDirection > 0
                        ? longVotes
                        : shortVotes
                  )
                + "/"
                + L2TriggerVoteWindow;

            try
            {
                TriggerCustomEvent(
                    o =>
                    {
                        Brush brush =
                            confirmedDirection > 0
                                ? Brushes.LimeGreen
                                : Brushes.OrangeRed;

                        if (confirmedDirection > 0)
                        {
                            Draw.ArrowUp(
                                this,
                                tagBase + "_ARROW",
                                false,
                                0,
                                arrowPrice,
                                brush
                            );
                        }
                        else
                        {
                            Draw.ArrowDown(
                                this,
                                tagBase + "_ARROW",
                                false,
                                0,
                                arrowPrice,
                                brush
                            );
                        }

                        Draw.Text(
                            this,
                            tagBase + "_TEXT",
                            false,
                            side,
                            0,
                            arrowPrice +
                                (
                                    confirmedDirection > 0
                                        ? -TickSize * 5
                                        : TickSize * 5
                                ),
                            0,
                            brush,
                            new SimpleFont(
                                "Arial",
                                12
                            ),
                            System.Windows.TextAlignment.Center,
                            Brushes.Transparent,
                            Brushes.Transparent,
                            0
                        );

                        Draw.TextFixed(
                            this,
                            "JJ_L2_TRIGGER_STATUS",
                            detail,
                            TextPosition.BottomRight,
                            brush,
                            new SimpleFont(
                                "Consolas",
                                11
                            ),
                            Brushes.Transparent,
                            new SolidColorBrush(
                                Color.FromArgb(
                                    180,
                                    12,
                                    17,
                                    24
                                )
                            ),
                            70
                        );
                    },
                    null
                );
            }
            catch
            {
            }
        }

        private void AddLevel2TriggerVote(
            int vote)
        {
            lock (liquidityLock)
            {
                l2TriggerVotes.Enqueue(
                    vote
                );

                while (
                    l2TriggerVotes.Count >
                        L2TriggerVoteWindow
                )
                {
                    l2TriggerVotes.Dequeue();
                }
            }
        }

        private void RequestLiquidityRender()
        {
            DateTime nowUtc =
                DateTime.UtcNow;

            lock (liquidityLock)
            {
                if (liquidityRenderPending)
                {
                    return;
                }

                if (
                    lastLiquidityRenderUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastLiquidityRenderUtc
                    ).TotalMilliseconds <
                        LiquidityUiThrottleMs
                )
                {
                    return;
                }

                liquidityRenderPending =
                    true;
            }

            try
            {
                TriggerCustomEvent(
                    o =>
                    {
                        try
                        {
                            DrawLiquidityMap();
                        }
                        finally
                        {
                            lock (liquidityLock)
                            {
                                lastLiquidityRenderUtc =
                                    DateTime.UtcNow;

                                liquidityRenderPending =
                                    false;
                            }
                        }
                    },
                    null
                );
            }
            catch
            {
                lock (liquidityLock)
                {
                    liquidityRenderPending =
                        false;
                }
            }
        }

        private void DrawLiquidityMap()
        {
            if (
                State == State.Terminated ||
                !ShowLiquidityMap
            )
            {
                ClearLiquidityDrawObjects();
                return;
            }

            List<LiquidityLevelInfo> bids;
            List<LiquidityLevelInfo> asks;
            List<TradePrint> trades;
            double localLastTrade;

            lock (liquidityLock)
            {
                TrimOldTradePrints(
                    DateTime.UtcNow
                );

                bids =
                    bidDepth.Values
                        .Where(
                            x =>
                                x != null &&
                                x.Volume > 0
                        )
                        .Select(
                            x =>
                                new LiquidityLevelInfo
                                {
                                    Price = x.Price,
                                    Volume = x.Volume,
                                    UpdatedUtc = x.UpdatedUtc
                                }
                        )
                        .ToList();

                asks =
                    askDepth.Values
                        .Where(
                            x =>
                                x != null &&
                                x.Volume > 0
                        )
                        .Select(
                            x =>
                                new LiquidityLevelInfo
                                {
                                    Price = x.Price,
                                    Volume = x.Volume,
                                    UpdatedUtc = x.UpdatedUtc
                                }
                        )
                        .ToList();

                trades =
                    recentTradePrints
                        .Select(
                            x =>
                                new TradePrint
                                {
                                    Price = x.Price,
                                    Volume = x.Volume,
                                    TimeUtc = x.TimeUtc,
                                    AggressiveBuy = x.AggressiveBuy,
                                    AggressiveSell = x.AggressiveSell
                                }
                        )
                        .ToList();

                localLastTrade =
                    lastTradePrice;
            }

            ClearLiquidityDrawObjects();

            if (
                bids.Count == 0 &&
                asks.Count == 0
            )
            {
                return;
            }

            double bidAverage =
                bids.Count > 0
                    ? bids.Average(
                        x => (double)x.Volume
                      )
                    : 0;

            double askAverage =
                asks.Count > 0
                    ? asks.Average(
                        x => (double)x.Volume
                      )
                    : 0;

            List<LiquidityLevelInfo> bidWalls =
                SelectLiquidityWalls(
                    bids,
                    bidAverage,
                    false,
                    localLastTrade
                );

            List<LiquidityLevelInfo> askWalls =
                SelectLiquidityWalls(
                    asks,
                    askAverage,
                    true,
                    localLastTrade
                );

            UpdateConsumedLiquidity(
                bidWalls,
                askWalls,
                localLastTrade
            );

            // FIX2: clustered walls are represented by ONE zone label instead
            // of repeating multiple wall labels on top of each other.
            HashSet<double> bidClusteredPrices =
                new HashSet<double>();

            HashSet<double> askClusteredPrices =
                new HashSet<double>();

            if (ShowLiquidityZones)
            {
                bidClusteredPrices =
                    DrawLiquidityZones(
                        bidWalls,
                        bidAverage,
                        false
                    );

                askClusteredPrices =
                    DrawLiquidityZones(
                        askWalls,
                        askAverage,
                        true
                    );
            }

            if (ShowLiquidityWalls)
            {
                DrawLiquidityWalls(
                    bidWalls,
                    bidAverage,
                    false,
                    trades,
                    bidClusteredPrices
                );

                DrawLiquidityWalls(
                    askWalls,
                    askAverage,
                    true,
                    trades,
                    askClusteredPrices
                );
            }

            if (ShowLargePendingOrders)
            {
                DrawLargePendingOrders(
                    bids,
                    bidAverage,
                    false,
                    localLastTrade
                );

                DrawLargePendingOrders(
                    asks,
                    askAverage,
                    true,
                    localLastTrade
                );
            }

            if (ShowConsumedLiquidity)
            {
                DrawConsumedLiquidityMarkers();
            }

            DrawLiquidityBookPanel(
                bids,
                asks,
                bidAverage,
                askAverage,
                localLastTrade
            );
        }

        // =====================================================
        // FIX4: CLEAN LIQUIDITY BOOK PANEL
        // =====================================================
        private void DrawLiquidityBookPanel(
            List<LiquidityLevelInfo> bids,
            List<LiquidityLevelInfo> asks,
            double bidAverage,
            double askAverage,
            double referencePrice)
        {
            if (!ShowLiquidityMap)
            {
                RemoveDrawObject("JJ_LIQ_BOOK_PANEL");
                return;
            }

            Func<List<LiquidityLevelInfo>, double, bool, List<LiquidityLevelInfo>> select =
                (levels, average, isAsk) =>
                {
                    if (levels == null)
                        return new List<LiquidityLevelInfo>();

                    double relativeThreshold =
                        average > 0
                            ? average * Math.Max(1.0, PendingOrderMultiplier)
                            : 0;

                    double threshold =
                        Math.Max(PendingOrderMinSize, relativeThreshold);

                    return levels
                        .Where(
                            x =>
                                x != null &&
                                x.Volume >= threshold &&
                                (
                                    referencePrice <= 0 ||
                                    (
                                        isAsk
                                            ? x.Price >= referencePrice
                                            : x.Price <= referencePrice
                                    )
                                )
                        )
                        .OrderByDescending(x => x.Volume)
                        .Take(Math.Max(1, MaxPendingOrdersPerSide))
                        .ToList();
                };

            List<LiquidityLevelInfo> topAsks =
                ShowLargePendingOrders
                    ? select(asks, askAverage, true)
                    : new List<LiquidityLevelInfo>();

            List<LiquidityLevelInfo> topBids =
                ShowLargePendingOrders
                    ? select(bids, bidAverage, false)
                    : new List<LiquidityLevelInfo>();

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("JJ LEVEL II • LARGE VISIBLE ORDERS");
            sb.AppendLine("────────────────────────────");
            sb.AppendLine("ASK / SELL LIQUIDITY");

            if (topAsks.Count == 0)
            {
                sb.AppendLine("  none above filter");
            }
            else
            {
                foreach (LiquidityLevelInfo level in topAsks.OrderBy(x => x.Price))
                {
                    double strength =
                        askAverage > 0
                            ? level.Volume / askAverage
                            : 0;

                    sb.Append(strength >= 3.0 ? "  MAJOR " : "  ");
                    sb.Append(level.Volume);
                    sb.Append(" @ ");
                    sb.Append(level.Price.ToString("0.00"));
                    sb.Append(" | ");
                    sb.Append(strength.ToString("0.0"));
                    sb.AppendLine("x");
                }
            }

            sb.AppendLine("────────────────────────────");
            sb.AppendLine("BID / BUY LIQUIDITY");

            if (topBids.Count == 0)
            {
                sb.AppendLine("  none above filter");
            }
            else
            {
                foreach (LiquidityLevelInfo level in topBids.OrderByDescending(x => x.Price))
                {
                    double strength =
                        bidAverage > 0
                            ? level.Volume / bidAverage
                            : 0;

                    sb.Append(strength >= 3.0 ? "  MAJOR " : "  ");
                    sb.Append(level.Volume);
                    sb.Append(" @ ");
                    sb.Append(level.Price.ToString("0.00"));
                    sb.Append(" | ");
                    sb.Append(strength.ToString("0.0"));
                    sb.AppendLine("x");
                }
            }

            Draw.TextFixed(
                this,
                "JJ_LIQ_BOOK_PANEL",
                sb.ToString(),
                TextPosition.BottomLeft,
                Brushes.WhiteSmoke,
                new SimpleFont("Consolas", 10),
                Brushes.DimGray,
                new SolidColorBrush(
                    Color.FromArgb(
                        210,
                        12,
                        17,
                        24
                    )
                ),
                80
            );
        }

        // =====================================================
        // FIX3: EXACT LARGE VISIBLE PENDING ORDERS
        // =====================================================
        // IMPORTANT:
        // Level II exposes aggregate visible depth at a price level. Therefore
        // "BID 120 @ 29648.00" means 120 visible contracts resting at that
        // price in the current book. It does NOT prove this is one single
        // trader/order, and the liquidity can be changed or pulled at any time.
        private void DrawLargePendingOrders(
            List<LiquidityLevelInfo> levels,
            double average,
            bool isAsk,
            double referencePrice)
        {
            if (
                levels == null ||
                levels.Count == 0
            )
            {
                return;
            }

            double relativeThreshold =
                average > 0
                    ? average *
                        Math.Max(
                            1.0,
                            PendingOrderMultiplier
                        )
                    : 0;

            double threshold =
                Math.Max(
                    PendingOrderMinSize,
                    relativeThreshold
                );

            List<LiquidityLevelInfo> pending =
                levels
                    .Where(
                        x =>
                            x != null &&
                            x.Volume >= threshold &&
                            (
                                referencePrice <= 0 ||
                                (
                                    isAsk
                                        ? x.Price >= referencePrice
                                        : x.Price <= referencePrice
                                )
                            )
                    )
                    .OrderByDescending(
                        x => x.Volume
                    )
                    .Take(
                        Math.Max(
                            1,
                            MaxPendingOrdersPerSide
                        )
                    )
                    .OrderBy(
                        x => x.Price
                    )
                    .ToList();

            if (pending.Count == 0)
            {
                return;
            }

            Brush baseBrush =
                isAsk
                    ? Brushes.OrangeRed
                    : Brushes.LimeGreen;

            int index = 0;

            foreach (
                LiquidityLevelInfo level in
                    pending
            )
            {
                index++;

                double strength =
                    average > 0
                        ? level.Volume / average
                        : 0;

                bool major =
                    strength >= 3.0 ||
                    level.Volume >=
                        PendingOrderMinSize * 3L;

                string side =
                    isAsk
                        ? "ASK"
                        : "BID";

                string prefix =
                    major
                        ? "MAJOR VISIBLE " + side
                        : "VISIBLE " + side;

                string label =
                    prefix
                    + " "
                    + level.Volume
                    + " @ "
                    + level.Price.ToString("0.00")
                    + " | "
                    + strength.ToString("0.0")
                    + "x";

                string tag =
                    "JJ_PENDING_"
                    + side
                    + "_"
                    + index;

                Draw.HorizontalLine(
                    this,
                    tag,
                    level.Price,
                    baseBrush
                );

                TrackLiquidityTag(
                    tag
                );


            }
        }

        private List<LiquidityLevelInfo> SelectLiquidityWalls(
            List<LiquidityLevelInfo> levels,
            double average,
            bool isAsk,
            double referencePrice)
        {
            if (
                levels == null ||
                levels.Count == 0
            )
            {
                return
                    new List<LiquidityLevelInfo>();
            }

            double relativeThreshold =
                average > 0
                    ? average *
                        Math.Max(
                            1.0,
                            LiquidityWallMultiplier
                        )
                    : 0;

            double threshold =
                Math.Max(
                    LiquidityMinWallSize,
                    relativeThreshold
                );

            IEnumerable<LiquidityLevelInfo> query =
                levels.Where(
                    x =>
                        x.Volume >=
                            threshold &&
                        (
                            referencePrice <= 0 ||
                            (
                                isAsk
                                    ? x.Price >= referencePrice
                                    : x.Price <= referencePrice
                            )
                        )
                );

            // Keep the strongest levels, then restore price order so
            // clustering remains visually coherent.
            return query
                .OrderByDescending(
                    x => x.Volume
                )
                .Take(
                    Math.Max(
                        1,
                        LiquidityMaxWallsPerSide
                    )
                )
                .OrderBy(
                    x => x.Price
                )
                .ToList();
        }

        private void DrawLiquidityWalls(
            List<LiquidityLevelInfo> walls,
            double average,
            bool isAsk,
            List<TradePrint> trades,
            HashSet<double> clusteredPrices)
        {
            if (
                walls == null ||
                walls.Count == 0
            )
            {
                return;
            }

            Brush lineBrush =
                isAsk
                    ? Brushes.OrangeRed
                    : Brushes.LimeGreen;

            int index =
                0;

            foreach (
                LiquidityLevelInfo wall in
                    walls
            )
            {
                // A clustered wall is already represented by the liquidity zone.
                // Suppressing the individual line/text prevents label stacking.
                if (
                    clusteredPrices != null &&
                    clusteredPrices.Contains(
                        wall.Price
                    )
                )
                {
                    continue;
                }

                index++;

                double strength =
                    average > 0
                        ? wall.Volume /
                            average
                        : 0;

                bool absorption =
                    ShowAbsorption &&
                    IsAbsorptionAtWall(
                        wall,
                        isAsk,
                        trades
                    );

                bool majorWall =
                    strength >= 3.0;

                string prefix =
                    majorWall
                        ? (
                            isAsk
                                ? "MAJOR ASK WALL"
                                : "MAJOR BID WALL"
                          )
                        : (
                            isAsk
                                ? "ASK WALL"
                                : "BID WALL"
                          );

                string text =
                    prefix
                    + " "
                    + wall.Volume
                    + " | "
                    + strength.ToString("0.0")
                    + "x";

                if (absorption)
                {
                    text +=
                        isAsk
                            ? " | SELL ABSORPTION"
                            : " | BUY ABSORPTION";
                }

                string tagBase =
                    "JJ_LIQ_WALL_"
                    + (
                        isAsk
                            ? "ASK_"
                            : "BID_"
                      )
                    + index;

                Draw.HorizontalLine(
                    this,
                    tagBase,
                    wall.Price,
                    lineBrush
                );

                TrackLiquidityTag(
                    tagBase
                );


            }
        }

        private HashSet<double> DrawLiquidityZones(
            List<LiquidityLevelInfo> walls,
            double average,
            bool isAsk)
        {
            HashSet<double> clusteredPrices =
                new HashSet<double>();

            if (
                walls == null ||
                walls.Count < 2 ||
                CurrentBar < 1
            )
            {
                return clusteredPrices;
            }

            List<List<LiquidityLevelInfo>> clusters =
                new List<List<LiquidityLevelInfo>>();

            List<LiquidityLevelInfo> currentCluster =
                new List<LiquidityLevelInfo>();

            double maxGap =
                Math.Max(
                    TickSize,
                    LiquidityZoneClusterTicks *
                        TickSize
                );

            foreach (
                LiquidityLevelInfo wall in
                    walls.OrderBy(
                        x => x.Price
                    )
            )
            {
                if (currentCluster.Count == 0)
                {
                    currentCluster.Add(
                        wall
                    );
                    continue;
                }

                double gap =
                    wall.Price -
                    currentCluster[
                        currentCluster.Count - 1
                    ].Price;

                if (gap <= maxGap)
                {
                    currentCluster.Add(
                        wall
                    );
                }
                else
                {
                    if (currentCluster.Count >= 2)
                    {
                        clusters.Add(
                            currentCluster
                        );
                    }

                    currentCluster =
                        new List<LiquidityLevelInfo>
                        {
                            wall
                        };
                }
            }

            if (currentCluster.Count >= 2)
            {
                clusters.Add(
                    currentCluster
                );
            }

            int clusterIndex = 0;

            foreach (
                List<LiquidityLevelInfo> cluster in
                    clusters
            )
            {
                clusterIndex++;

                foreach (
                    LiquidityLevelInfo clusteredWall in
                        cluster
                )
                {
                    clusteredPrices.Add(
                        clusteredWall.Price
                    );
                }

                double low =
                    cluster.Min(
                        x => x.Price
                    ) -
                    TickSize * 0.35;

                double high =
                    cluster.Max(
                        x => x.Price
                    ) +
                    TickSize * 0.35;

                long total =
                    cluster.Sum(
                        x => x.Volume
                    );

                LiquidityLevelInfo strongest =
                    cluster
                        .OrderByDescending(
                            x => x.Volume
                        )
                        .First();

                double strongestStrength =
                    average > 0
                        ? strongest.Volume / average
                        : 0;

                bool majorZone =
                    strongestStrength >= 3.0;

                int barsAgo =
                    Math.Min(
                        LiquidityHistoryBars,
                        CurrentBar
                    );

                string tag =
                    "JJ_LIQ_ZONE_"
                    + (
                        isAsk
                            ? "ASK_"
                            : "BID_"
                      )
                    + clusterIndex;

                Brush zoneBrush =
                    isAsk
                        ? Brushes.IndianRed
                        : Brushes.SeaGreen;

                Draw.Rectangle(
                    this,
                    tag,
                    false,
                    barsAgo,
                    high,
                    0,
                    low,
                    zoneBrush,
                    zoneBrush,
                    12
                );

                TrackLiquidityTag(
                    tag
                );


            }

            return clusteredPrices;
        }

        private bool IsAbsorptionAtWall(
            LiquidityLevelInfo wall,
            bool isAsk,
            List<TradePrint> trades)
        {
            if (
                wall == null ||
                trades == null ||
                trades.Count == 0
            )
            {
                return false;
            }

            DateTime cutoff =
                DateTime.UtcNow.AddSeconds(
                    -Math.Max(
                        1,
                        LiquidityAbsorptionWindowSeconds
                    )
                );

            double tolerance =
                TickSize * 1.25;

            long aggressiveVolume =
                trades
                    .Where(
                        x =>
                            x.TimeUtc >=
                                cutoff &&
                            Math.Abs(
                                x.Price -
                                wall.Price
                            ) <=
                                tolerance &&
                            (
                                isAsk
                                    ? x.AggressiveBuy
                                    : x.AggressiveSell
                            )
                    )
                    .Sum(
                        x => x.Volume
                    );

            double requiredVolume =
                wall.Volume *
                Math.Max(
                    0.25,
                    LiquidityAbsorptionMultiplier
                );

            if (
                aggressiveVolume <
                    requiredVolume
            )
            {
                return false;
            }

            // Visual heuristic:
            // ASK absorption = aggressive buyers keep hitting the ask wall
            // but price has not accepted above it.
            // BID absorption = aggressive sellers keep hitting the bid wall
            // but price has not accepted below it.
            if (isAsk)
            {
                return
                    lastTradePrice <=
                        wall.Price +
                        TickSize * 0.25;
            }

            return
                lastTradePrice >=
                    wall.Price -
                    TickSize * 0.25;
        }

        private void UpdateConsumedLiquidity(
            List<LiquidityLevelInfo> bidWalls,
            List<LiquidityLevelInfo> askWalls,
            double localLastTrade)
        {
            HashSet<double> currentBidWalls =
                new HashSet<double>(
                    bidWalls.Select(
                        x => x.Price
                    )
                );

            HashSet<double> currentAskWalls =
                new HashSet<double>(
                    askWalls.Select(
                        x => x.Price
                    )
                );

            DateTime nowUtc =
                DateTime.UtcNow;

            lock (liquidityLock)
            {
                foreach (
                    double oldAsk in
                        previousAskWalls
                )
                {
                    if (
                        !currentAskWalls.Contains(
                            oldAsk
                        ) &&
                        localLastTrade >
                            oldAsk +
                            TickSize * 0.25
                    )
                    {
                        consumedLiquidity[oldAsk] =
                            new ConsumedLiquidityMarker
                            {
                                Price =
                                    oldAsk,
                                WasAsk =
                                    true,
                                ExpiresUtc =
                                    nowUtc.AddSeconds(
                                        ConsumedMarkerSeconds
                                    )
                            };
                    }
                }

                foreach (
                    double oldBid in
                        previousBidWalls
                )
                {
                    if (
                        !currentBidWalls.Contains(
                            oldBid
                        ) &&
                        localLastTrade <
                            oldBid -
                            TickSize * 0.25
                    )
                    {
                        consumedLiquidity[oldBid] =
                            new ConsumedLiquidityMarker
                            {
                                Price =
                                    oldBid,
                                WasAsk =
                                    false,
                                ExpiresUtc =
                                    nowUtc.AddSeconds(
                                        ConsumedMarkerSeconds
                                    )
                            };
                    }
                }

                previousBidWalls.Clear();
                previousAskWalls.Clear();

                foreach (
                    double price in
                        currentBidWalls
                )
                {
                    previousBidWalls.Add(
                        price
                    );
                }

                foreach (
                    double price in
                        currentAskWalls
                )
                {
                    previousAskWalls.Add(
                        price
                    );
                }

                List<double> expired =
                    consumedLiquidity
                        .Where(
                            x =>
                                x.Value == null ||
                                x.Value.ExpiresUtc <=
                                    nowUtc
                        )
                        .Select(
                            x => x.Key
                        )
                        .ToList();

                foreach (
                    double price in
                        expired
                )
                {
                    consumedLiquidity.Remove(
                        price
                    );
                }
            }
        }

        private void DrawConsumedLiquidityMarkers()
        {
            List<ConsumedLiquidityMarker> markers;

            lock (liquidityLock)
            {
                markers =
                    consumedLiquidity.Values
                        .Where(
                            x =>
                                x != null &&
                                x.ExpiresUtc >
                                    DateTime.UtcNow
                        )
                        .Select(
                            x =>
                                new ConsumedLiquidityMarker
                                {
                                    Price = x.Price,
                                    WasAsk = x.WasAsk,
                                    ExpiresUtc = x.ExpiresUtc
                                }
                        )
                        .ToList();
            }

            int index =
                0;

            foreach (
                ConsumedLiquidityMarker marker in
                    markers
            )
            {
                index++;

                string tag =
                    "JJ_LIQ_CONSUMED_"
                    + index;

                Draw.Text(
                    this,
                    tag,
                    marker.WasAsk
                        ? "ASK WALL CONSUMED ↑"
                        : "BID WALL CONSUMED ↓",
                    0,
                    marker.Price,
                    Brushes.Gold
                );

                TrackLiquidityTag(
                    tag
                );
            }
        }

        private void TrimOldTradePrints(
            DateTime nowUtc)
        {
            DateTime cutoff =
                nowUtc.AddSeconds(
                    -Math.Max(
                        2,
                        LiquidityAbsorptionWindowSeconds +
                            2
                    )
                );

            while (
                recentTradePrints.Count > 0 &&
                recentTradePrints.Peek().TimeUtc <
                    cutoff
            )
            {
                recentTradePrints.Dequeue();
            }
        }

        private void TrackLiquidityTag(
            string tag)
        {
            if (
                string.IsNullOrWhiteSpace(
                    tag
                )
            )
            {
                return;
            }

            liquidityDrawTags.Add(
                tag
            );
        }

        private void ClearLiquidityDrawObjects()
        {
            if (
                liquidityDrawTags.Count == 0
            )
            {
                return;
            }

            string[] tags =
                liquidityDrawTags.ToArray();

            liquidityDrawTags.Clear();

            foreach (
                string tag in
                    tags
            )
            {
                try
                {
                    RemoveDrawObject(
                        tag
                    );
                }
                catch
                {
                }
            }
        }



        // =====================================================
        // V1.7.35 - CORE20 ZONES (visual only)
        // =====================================================
        private static readonly TimeSpan C20RthOpen = new TimeSpan(9, 30, 0);
        private static readonly TimeSpan C20AmEnd = new TimeSpan(12, 0, 0);
        private static readonly TimeSpan C20RthEnd = new TimeSpan(16, 0, 0);
        private static readonly TimeSpan C20OvernightStart = new TimeSpan(18, 0, 0);

        private static void C20Accumulate(
            Dictionary<DateTime, double[]> map,
            DateTime date,
            double high,
            double low)
        {
            double[] hl;

            if (!map.TryGetValue(date, out hl))
            {
                map[date] = new double[] { high, low };
                return;
            }

            if (high > hl[0]) hl[0] = high;
            if (low < hl[1]) hl[1] = low;
        }

        private void UpdateCore20Zones()
        {
            if (
                !ShowCore20Zones ||
                CurrentBar < 1 ||
                BarsPeriod.BarsPeriodType == BarsPeriodType.Day ||
                BarsPeriod.BarsPeriodType == BarsPeriodType.Week ||
                BarsPeriod.BarsPeriodType == BarsPeriodType.Month ||
                BarsPeriod.BarsPeriodType == BarsPeriodType.Year
            )
                return;

            DateTime ny = ConvertToNewYorkTime(Time[0]);
            TimeSpan t = ny.TimeOfDay;

            // Bars are stamped with their CLOSE time (same rule as the bot).
            if (t > C20OvernightStart)
                C20Accumulate(c20Overnight, ny.Date.AddDays(1), High[0], Low[0]);
            else if (t <= C20RthOpen)
                C20Accumulate(c20Overnight, ny.Date, High[0], Low[0]);

            if (t > C20RthOpen && t <= C20RthEnd)
                C20Accumulate(c20Rth, ny.Date, High[0], Low[0]);

            DateTime session =
                t > C20OvernightStart
                    ? ny.Date.AddDays(1)
                    : ny.Date;

            DrawCore20Session(session, null);

            JJCore20ZoneSnapshot bus =
                JJCore20ZoneBus.GetSnapshot(Instrument.FullName);

            if (bus != null && bus.SessionDateNy == session && bus.Version != c20LastBusVersion)
                DrawCore20FromBus(bus);
        }

        private void DrawCore20Session(
            DateTime session,
            List<JJCore20ZoneInfo> botZones)
        {
            List<JJCore20ZoneInfo> zones = botZones;

            if (zones == null)
            {
                zones = new List<JJCore20ZoneInfo>();
                double[] on;

                if (c20Overnight.TryGetValue(session, out on))
                {
                    zones.Add(new JJCore20ZoneInfo { Name = "ONH", Price = on[0], IsHigh = true });
                    zones.Add(new JJCore20ZoneInfo { Name = "ONL", Price = on[1], IsHigh = false });
                }

                DateTime prior = DateTime.MinValue;

                foreach (DateTime d in c20Rth.Keys)
                {
                    if (d < session && d > prior)
                        prior = d;
                }

                double[] pd;

                if (prior != DateTime.MinValue && c20Rth.TryGetValue(prior, out pd))
                {
                    zones.Add(new JJCore20ZoneInfo { Name = "PDH", Price = pd[0], IsHigh = true });
                    zones.Add(new JJCore20ZoneInfo { Name = "PDL", Price = pd[1], IsHigh = false });
                }
            }

            if (zones.Count == 0)
                return;

            string key =
                (botZones != null ? "BOT|" : "CHART|")
                + string.Join("|", zones.Select(z => z.Name + z.Price.ToString("0.00") + (z.SweepUsed ? "s" : "") + (z.BreakUsed ? "b" : "")));

            string previousKey;

            // Bot values are authoritative: never overwrite them with the
            // chart's own calculation for the same session.
            if (c20DrawnKey.TryGetValue(session, out previousKey))
            {
                if (previousKey == key)
                    return;

                if (botZones == null && previousKey.StartsWith("BOT|"))
                    return;
            }

            c20DrawnKey[session] = key;

            if (!c20DrawnDates.Contains(session))
            {
                c20DrawnDates.Add(session);
                c20DrawnDates.Sort();

                while (c20DrawnDates.Count > Math.Max(1, Core20DaysToShow))
                {
                    RemoveCore20Session(c20DrawnDates[0]);
                    c20DrawnDates.RemoveAt(0);
                }
            }

            DateTime startLocal = ConvertFromNewYorkTime(session.Add(C20RthOpen));
            DateTime endLocal = ConvertFromNewYorkTime(session.Add(C20AmEnd));
            double band = Core20ZoneTicks * TickSize;
            string prefix = "C20_" + session.ToString("yyyyMMdd") + "_";
            bool fromBot = botZones != null;

            foreach (JJCore20ZoneInfo z in zones)
            {
                bool overnight = z.Name.StartsWith("ON");
                Brush lineBrush =
                    z.IsHigh
                        ? (overnight ? Brushes.OrangeRed : Brushes.Tomato)
                        : (overnight ? Brushes.LimeGreen : Brushes.MediumSeaGreen);

                bool used = z.SweepUsed && z.BreakUsed;

                string lineTag = prefix + z.Name + "_LINE";
                string bandTag = prefix + z.Name + "_BAND";
                string textTag = prefix + z.Name + "_TEXT";

                Draw.Line(
                    this,
                    lineTag,
                    false,
                    startLocal,
                    z.Price,
                    endLocal,
                    z.Price,
                    lineBrush,
                    overnight
                        ? NinjaTrader.Gui.DashStyleHelper.Solid
                        : NinjaTrader.Gui.DashStyleHelper.Dash,
                    used ? 1 : 2
                );

                // Trigger band: a SWEEP / BREAK needs price 8 ticks beyond.
                Draw.Rectangle(
                    this,
                    bandTag,
                    false,
                    startLocal,
                    z.Price,
                    endLocal,
                    z.IsHigh ? z.Price + band : z.Price - band,
                    Brushes.Transparent,
                    lineBrush,
                    12
                );

                string state =
                    z.SweepUsed && z.BreakUsed ? " · USED"
                    : z.SweepUsed ? " · SWEEP USED"
                    : z.BreakUsed ? " · BREAK USED"
                    : z.Swept ? " · SWEPT"
                    : string.Empty;

                Draw.Text(
                    this,
                    textTag,
                    false,
                    z.Name + " " + z.Price.ToString("0.00") + state + (fromBot ? " · BOT" : string.Empty),
                    startLocal,
                    z.Price,
                    z.IsHigh ? 10 : -10,
                    lineBrush,
                    new SimpleFont("Consolas", 10),
                    System.Windows.TextAlignment.Left,
                    Brushes.Transparent,
                    Brushes.Transparent,
                    0
                );

                c20Tags.Add(lineTag);
                c20Tags.Add(bandTag);
                c20Tags.Add(textTag);
            }
        }

        private void RemoveCore20Session(DateTime session)
        {
            string prefix = "C20_" + session.ToString("yyyyMMdd") + "_";

            foreach (string tag in c20Tags.Where(x => x.StartsWith(prefix)).ToList())
            {
                RemoveDrawObject(tag);
                c20Tags.Remove(tag);
            }

            c20DrawnKey.Remove(session);
        }

        private void OnCore20ZoneBusChanged(string instrumentName)
        {
            if (
                State == State.Terminated ||
                Instrument == null ||
                !string.Equals(instrumentName, Instrument.FullName, StringComparison.OrdinalIgnoreCase)
            )
            {
                return;
            }

            try
            {
                TriggerCustomEvent(
                    o =>
                    {
                        JJCore20ZoneSnapshot bus =
                            JJCore20ZoneBus.GetSnapshot(Instrument.FullName);

                        if (bus != null)
                            DrawCore20FromBus(bus);
                    },
                    null
                );
            }
            catch
            {
            }
        }

        private void DrawCore20FromBus(JJCore20ZoneSnapshot bus)
        {
            if (bus == null || !ShowCore20Zones)
                return;

            c20LastBusVersion = bus.Version;

            if (bus.Zones != null && bus.Zones.Count > 0)
                DrawCore20Session(bus.SessionDateNy, bus.Zones);

            if (!ShowCore20Events || bus.Events == null)
                return;

            string prefix = "C20_" + bus.SessionDateNy.ToString("yyyyMMdd") + "_EV_";

            foreach (JJCore20EventInfo ev in bus.Events)
            {
                string tag = prefix + ev.BarTime.Ticks + "_" + ev.Zone + "_" + ev.Trigger;
                bool entry = ev.Decision == "ENTRY";
                double offset = 6 * TickSize;

                Brush brush =
                    !entry
                        ? Brushes.Gray
                        : ev.IsLong
                            ? Brushes.Lime
                            : Brushes.Red;

                if (entry && ev.IsLong)
                    Draw.ArrowUp(this, tag, false, ev.BarTime, ev.Price - offset, brush);
                else if (entry)
                    Draw.ArrowDown(this, tag, false, ev.BarTime, ev.Price + offset, brush);
                else
                    Draw.Diamond(this, tag, false, ev.BarTime, ev.IsLong ? ev.Price - offset : ev.Price + offset, brush);

                Draw.Text(
                    this,
                    tag + "_T",
                    false,
                    ev.Trigger + " " + ev.Zone + "\n" + (entry ? "SIGNAL" : ev.Decision) + " · Δ" + ev.Delta.ToString("+0;-0;0"),
                    ev.BarTime,
                    ev.IsLong ? ev.Price - offset : ev.Price + offset,
                    ev.IsLong ? -22 : 22,
                    brush,
                    new SimpleFont("Consolas", 9),
                    System.Windows.TextAlignment.Center,
                    Brushes.Transparent,
                    Brushes.Transparent,
                    0
                );

                c20Tags.Add(tag);
                c20Tags.Add(tag + "_T");
            }
        }

        private DateTime ConvertFromNewYorkTime(
            DateTime newYorkTime)
        {
            try
            {
                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                return TimeZoneInfo.ConvertTime(
                    DateTime.SpecifyKind(newYorkTime, DateTimeKind.Unspecified),
                    newYorkTimeZone,
                    NinjaTrader.Core.Globals.GeneralOptions.TimeZoneInfo
                );
            }
            catch
            {
                return newYorkTime;
            }
        }

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                return time;
            }
        }

        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }

      
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private JJBotChart[] cacheJJBotChart;
		public JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			return JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showVwapBands, showSweeps, showStructure, showSignals, showStatusPanel, showLiquidityMap, showLiquidityWalls, showLiquidityZones, showAbsorption, showConsumedLiquidity, liquidityMinWallSize, liquidityWallMultiplier, liquidityMaxWallsPerSide, liquidityZoneClusterTicks, liquidityAbsorptionWindowSeconds, liquidityAbsorptionMultiplier, showLargePendingOrders, pendingOrderMinSize, pendingOrderMultiplier, maxPendingOrdersPerSide);
		}

		public JJBotChart JJBotChart(ISeries<double> input, bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			if (cacheJJBotChart != null)
				for (int idx = 0; idx < cacheJJBotChart.Length; idx++)
					if (cacheJJBotChart[idx] != null && cacheJJBotChart[idx].ShowEmaFast == showEmaFast && cacheJJBotChart[idx].ShowEmaSlow == showEmaSlow && cacheJJBotChart[idx].ShowVwap == showVwap && cacheJJBotChart[idx].ShowVwapBands == showVwapBands && cacheJJBotChart[idx].ShowSweeps == showSweeps && cacheJJBotChart[idx].ShowStructure == showStructure && cacheJJBotChart[idx].ShowSignals == showSignals && cacheJJBotChart[idx].ShowStatusPanel == showStatusPanel && cacheJJBotChart[idx].ShowLiquidityMap == showLiquidityMap && cacheJJBotChart[idx].ShowLiquidityWalls == showLiquidityWalls && cacheJJBotChart[idx].ShowLiquidityZones == showLiquidityZones && cacheJJBotChart[idx].ShowAbsorption == showAbsorption && cacheJJBotChart[idx].ShowConsumedLiquidity == showConsumedLiquidity && cacheJJBotChart[idx].LiquidityMinWallSize == liquidityMinWallSize && cacheJJBotChart[idx].LiquidityWallMultiplier == liquidityWallMultiplier && cacheJJBotChart[idx].LiquidityMaxWallsPerSide == liquidityMaxWallsPerSide && cacheJJBotChart[idx].LiquidityZoneClusterTicks == liquidityZoneClusterTicks && cacheJJBotChart[idx].LiquidityAbsorptionWindowSeconds == liquidityAbsorptionWindowSeconds && cacheJJBotChart[idx].LiquidityAbsorptionMultiplier == liquidityAbsorptionMultiplier && cacheJJBotChart[idx].ShowLargePendingOrders == showLargePendingOrders && cacheJJBotChart[idx].PendingOrderMinSize == pendingOrderMinSize && cacheJJBotChart[idx].PendingOrderMultiplier == pendingOrderMultiplier && cacheJJBotChart[idx].MaxPendingOrdersPerSide == maxPendingOrdersPerSide && cacheJJBotChart[idx].EqualsInput(input))
						return cacheJJBotChart[idx];
			return CacheIndicator<JJBotChart>(new JJBotChart(){ ShowEmaFast = showEmaFast, ShowEmaSlow = showEmaSlow, ShowVwap = showVwap, ShowVwapBands = showVwapBands, ShowSweeps = showSweeps, ShowStructure = showStructure, ShowSignals = showSignals, ShowStatusPanel = showStatusPanel, ShowLiquidityMap = showLiquidityMap, ShowLiquidityWalls = showLiquidityWalls, ShowLiquidityZones = showLiquidityZones, ShowAbsorption = showAbsorption, ShowConsumedLiquidity = showConsumedLiquidity, LiquidityMinWallSize = liquidityMinWallSize, LiquidityWallMultiplier = liquidityWallMultiplier, LiquidityMaxWallsPerSide = liquidityMaxWallsPerSide, LiquidityZoneClusterTicks = liquidityZoneClusterTicks, LiquidityAbsorptionWindowSeconds = liquidityAbsorptionWindowSeconds, LiquidityAbsorptionMultiplier = liquidityAbsorptionMultiplier, ShowLargePendingOrders = showLargePendingOrders, PendingOrderMinSize = pendingOrderMinSize, PendingOrderMultiplier = pendingOrderMultiplier, MaxPendingOrdersPerSide = maxPendingOrdersPerSide }, input, ref cacheJJBotChart);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			return indicator.JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showVwapBands, showSweeps, showStructure, showSignals, showStatusPanel, showLiquidityMap, showLiquidityWalls, showLiquidityZones, showAbsorption, showConsumedLiquidity, liquidityMinWallSize, liquidityWallMultiplier, liquidityMaxWallsPerSide, liquidityZoneClusterTicks, liquidityAbsorptionWindowSeconds, liquidityAbsorptionMultiplier, showLargePendingOrders, pendingOrderMinSize, pendingOrderMultiplier, maxPendingOrdersPerSide);
		}

		public Indicators.JJBotChart JJBotChart(ISeries<double> input , bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			return indicator.JJBotChart(input, showEmaFast, showEmaSlow, showVwap, showVwapBands, showSweeps, showStructure, showSignals, showStatusPanel, showLiquidityMap, showLiquidityWalls, showLiquidityZones, showAbsorption, showConsumedLiquidity, liquidityMinWallSize, liquidityWallMultiplier, liquidityMaxWallsPerSide, liquidityZoneClusterTicks, liquidityAbsorptionWindowSeconds, liquidityAbsorptionMultiplier, showLargePendingOrders, pendingOrderMinSize, pendingOrderMultiplier, maxPendingOrdersPerSide);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			return indicator.JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showVwapBands, showSweeps, showStructure, showSignals, showStatusPanel, showLiquidityMap, showLiquidityWalls, showLiquidityZones, showAbsorption, showConsumedLiquidity, liquidityMinWallSize, liquidityWallMultiplier, liquidityMaxWallsPerSide, liquidityZoneClusterTicks, liquidityAbsorptionWindowSeconds, liquidityAbsorptionMultiplier, showLargePendingOrders, pendingOrderMinSize, pendingOrderMultiplier, maxPendingOrdersPerSide);
		}

		public Indicators.JJBotChart JJBotChart(ISeries<double> input , bool showEmaFast, bool showEmaSlow, bool showVwap, bool showVwapBands, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel, bool showLiquidityMap, bool showLiquidityWalls, bool showLiquidityZones, bool showAbsorption, bool showConsumedLiquidity, int liquidityMinWallSize, double liquidityWallMultiplier, int liquidityMaxWallsPerSide, int liquidityZoneClusterTicks, int liquidityAbsorptionWindowSeconds, double liquidityAbsorptionMultiplier, bool showLargePendingOrders, int pendingOrderMinSize, double pendingOrderMultiplier, int maxPendingOrdersPerSide)
		{
			return indicator.JJBotChart(input, showEmaFast, showEmaSlow, showVwap, showVwapBands, showSweeps, showStructure, showSignals, showStatusPanel, showLiquidityMap, showLiquidityWalls, showLiquidityZones, showAbsorption, showConsumedLiquidity, liquidityMinWallSize, liquidityWallMultiplier, liquidityMaxWallsPerSide, liquidityZoneClusterTicks, liquidityAbsorptionWindowSeconds, liquidityAbsorptionMultiplier, showLargePendingOrders, pendingOrderMinSize, pendingOrderMultiplier, maxPendingOrdersPerSide);
		}
	}
}

#endregion

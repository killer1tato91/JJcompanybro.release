#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;

using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.AddOns;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class JJBotChart : Indicator
    {
        private EMA emaFast;
        private EMA emaSlow;

        private DateTime vwapNyDate;
        private double cumulativePriceVolume;
        private double cumulativeVolume;
        private double currentVwap;

    

        // Real AddOn bridge state
        private JJBotSharedSnapshot sharedSnapshot;
        private long lastExecutionSequence;
        private bool sharedStateSubscribed;

        // Throttle fixed-panel redraws while still allowing execution
        // markers to render immediately.
        private DateTime lastSharedUiRefreshUtc;
        private const int SharedUiRefreshThrottleMs = 300;

        private const int FastEmaPeriod = 9;
        private const int SlowEmaPeriod = 50;

      

        private const int VwapStartTime = 93000;

     

        #region Properties

        [NinjaScriptProperty]
        [Display(
            Name = "Show EMA 9",
            Order = 1,
            GroupName = "Visual")]
        public bool ShowEmaFast
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show EMA 50",
            Order = 2,
            GroupName = "Visual")]
        public bool ShowEmaSlow
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Session VWAP",
            Order = 3,
            GroupName = "Visual")]
        public bool ShowVwap
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Latest Sweep",
            Order = 4,
            GroupName = "Visual")]
        public bool ShowSweeps
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Latest BOS / CHOCH",
            Order = 5,
            GroupName = "Visual")]
        public bool ShowStructure
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Entry Arrows",
            Order = 6,
            GroupName = "Visual")]
        public bool ShowSignals
        { get; set; }

        [NinjaScriptProperty]
        [Display(
            Name = "Show Status Panel",
            Order = 7,
            GroupName = "Visual")]
        public bool ShowStatusPanel
        { get; set; }

        #endregion

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description =
                    "Clean visual companion for J&J NY Trading Bot. "
                    + "Displays EMA 9/50, session VWAP, latest sweep, "
                    + "latest BOS/CHOCH, Range-20 momentum, learning, "
                    + "trailing state and real AddOn execution. "
                    + "This indicator does NOT submit orders.";

                Name =
                    "JJBotChart";

                Calculate =
                    Calculate.OnBarClose;

                IsOverlay =
                    true;

                DisplayInDataBox =
                    true;

                DrawOnPricePanel =
                    true;

                PaintPriceMarkers =
                    true;

                IsSuspendedWhileInactive =
                    true;

                BarsRequiredToPlot =
                    50;

                ShowEmaFast =
                    true;

                ShowEmaSlow =
                    true;

                ShowVwap =
                    true;

                ShowSweeps =
                    true;

                ShowStructure =
                    true;

                ShowSignals =
                    true;

                ShowStatusPanel =
                    true;

                AddPlot(
                    Brushes.DeepSkyBlue,
                    "EMA9"
                );

                AddPlot(
                    Brushes.Goldenrod,
                    "EMA50"
                );

                AddPlot(
                    Brushes.MediumPurple,
                    "SessionVWAP"
                );
            }
            else if (State == State.DataLoaded)
            {
                emaFast =
                    EMA(
                        FastEmaPeriod
                    );

                emaSlow =
                    EMA(
                        SlowEmaPeriod
                    );

                vwapNyDate =
                    DateTime.MinValue;

                cumulativePriceVolume =
                    0;

                cumulativeVolume =
                    0;

                currentVwap =
                    0;

               

                sharedSnapshot =
                    JJBotSharedState.GetSnapshot(
                        Instrument.FullName
                    );

                lastExecutionSequence =
                    sharedSnapshot != null
                        ? sharedSnapshot.ExecutionSequence
                        : 0;

                lastSharedUiRefreshUtc =
                    DateTime.MinValue;

                JJBotSharedState.StateChanged +=
                    OnSharedBotStateChanged;

                sharedStateSubscribed =
                    true;

              

                DrawSharedBotPanel();
            }
            else if (State == State.Terminated)
            {
                if (sharedStateSubscribed)
                {
                    JJBotSharedState.StateChanged -=
                        OnSharedBotStateChanged;

                    sharedStateSubscribed =
                        false;
                }
            }
        }

       protected override void OnBarUpdate()
{
    // =====================================================
    // REAL BOT STATE
    // =====================================================
    // JJBotChart NEVER decides entries.
    // It only reads the state published by JJBotWindow.
    sharedSnapshot =
        JJBotSharedState.GetSnapshot(
            Instrument.FullName
        );

    // Always refresh the real bot panel, even while
    // the chart is still loading enough bars for EMA.
    DrawSharedBotPanel();

    if (
        CurrentBar <
            SlowEmaPeriod + 10
    )
    {
        if (ShowStatusPanel)
        {
            DrawBotStatusPanel(
                DateTime.MinValue,
                double.NaN,
                double.NaN
            );
        }

        return;
    }

    // =====================================================
    // VISUAL-ONLY CALCULATIONS
    // =====================================================
    // EMA and VWAP are calculated here ONLY so their lines
    // can be painted on the chart.
    //
    // They are NOT used for entry decisions.
    // The AddOn remains the only trading engine.
    double fast =
        emaFast[0];

    double slow =
        emaSlow[0];

    Values[0][0] =
        ShowEmaFast
            ? fast
            : double.NaN;

    Values[1][0] =
        ShowEmaSlow
            ? slow
            : double.NaN;

    DateTime nyTime =
        ConvertToNewYorkTime(
            Time[0]
        );

    int nyTimeInt =
        ToTimeInt(
            nyTime
        );

    UpdateSessionVwap(
        nyTime,
        nyTimeInt
    );

    Values[2][0] =
        ShowVwap &&
        currentVwap > 0
            ? currentVwap
            : double.NaN;

    // =====================================================
    // IMPORTANT
    // =====================================================
    // DO NOT call:
    //
    // DetectCurrentSweep()
    // UpdateStructureConfirmation()
    // DrawSignal()
    //
    // Sweep, structure, signal and setup now come ONLY
    // from JJBotWindow through JJBotSharedSnapshot.

    if (ShowStatusPanel)
    {
        DrawBotStatusPanel(
            nyTime,
            fast,
            slow
        );
    }
    else
    {
        RemoveDrawObject(
            "JJ_STATUS_PANEL"
        );
    }
}

        // =====================================================
        // REAL ADDON BRIDGE
        // =====================================================
        private void OnSharedBotStateChanged()
        {
            if (
                State == State.Terminated
            )
            {
                return;
            }

            try
            {
                JJBotSharedSnapshot latest =
                    JJBotSharedState.GetSnapshot(
                        Instrument.FullName
                    );

                // A real execution must never be hidden by the UI throttle.
                bool executionChanged =
                    latest != null &&
                    latest.ExecutionSequence !=
                        lastExecutionSequence;

                DateTime nowUtc =
                    DateTime.UtcNow;

                if (
                    !executionChanged &&
                    lastSharedUiRefreshUtc !=
                        DateTime.MinValue &&
                    (
                        nowUtc -
                        lastSharedUiRefreshUtc
                    ).TotalMilliseconds <
                        SharedUiRefreshThrottleMs
                )
                {
                    return;
                }

                lastSharedUiRefreshUtc =
                    nowUtc;

                TriggerCustomEvent(
                    o =>
                    {
                        DrawSharedBotPanel();
                        DrawRealExecutionMarker();
                    },
                    null
                );
            }
            catch
            {
            }
        }

        private void DrawSharedBotPanel()
        {
            sharedSnapshot =
                JJBotSharedState.GetSnapshot(
                        Instrument.FullName
                    );

            if (sharedSnapshot == null)
            {
                // The AddOn snapshot was removed (window/account/instrument
                // lifecycle reset). Reset the execution sequence baseline so
                // a newly opened bot can start again from sequence 0/1.
                lastExecutionSequence =
                    0;

                // IMPORTANT V7.1:
                // Never leave the previous instrument's fixed panel on the
                // chart. If no bot snapshot exists for this exact instrument,
                // explicitly replace it with a NO LINK panel.
                string noLinkText =
                    "J&J AUTO BOT • NO LINK"
                    + "\n"
                    + "────────────────────────"
                    + "\n"
                    + "Chart: "
                    + Instrument.FullName
                    + "\n"
                    + "Waiting for matching bot window...";

                Draw.TextFixed(
                    this,
                    "JJ_LIVE_ADDON_PANEL",
                    noLinkText,
                    TextPosition.BottomRight,
                    Brushes.Goldenrod,
                    new SimpleFont(
                        "Consolas",
                        10
                    ),
                    Brushes.DimGray,
                    new SolidColorBrush(
                        Color.FromArgb(
                            225,
                            12,
                            17,
                            24
                        )
                    ),
                    90
                );

                return;
            }

            bool sameInstrument =
                !string.IsNullOrWhiteSpace(
                    sharedSnapshot.InstrumentName
                ) &&
                string.Equals(
                    sharedSnapshot.InstrumentName,
                    Instrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                );

            string botState =
                sharedSnapshot.IsRunning
                    ? "ARMED"
                    : "STOPPED";

            string account =
                string.IsNullOrWhiteSpace(
                    sharedSnapshot.AccountName
                )
                    ? "--"
                    : sharedSnapshot.AccountName;

            string instrument =
                string.IsNullOrWhiteSpace(
                    sharedSnapshot.InstrumentName
                )
                    ? "--"
                    : sharedSnapshot.InstrumentName;

            string linkState =
                sameInstrument
                    ? "LINKED"
                    : "NO LINK";

            string learningState =
                sharedSnapshot.LearningActive
                    ? "ACTIVE"
                    : "OFF";

            string text =
                "J&J AUTO BOT • "
                + botState
                + "\n"
                + "────────────────────────\n"
                + "Link: "
                + linkState
                + "\n"
                + "Account: "
                + account
                + "\n"
                + "Instrument: "
                + instrument
                + "\n"
                + "Strategy: "
                + sharedSnapshot.StrategyMode
                + "\n"
                + "Session: "
                + sharedSnapshot.SessionWindow
                + "\n"
                + "────────────────────────\n"
                + "4H Context: "
                + sharedSnapshot.H4Trend
                + "\n"
                + "1H Context: "
                + sharedSnapshot.H1Trend
                + "\n"
                + "HTF Score: "
                + sharedSnapshot.HtfContextBias
                + "\n"
                + "────────────────────────\n"
                + "M5: "
                + sharedSnapshot.M5Trend
                + " | "
                + sharedSnapshot.M5VwapSide
                + "\n"
                + "Sweep: "
                + sharedSnapshot.M5Liquidity
                + "\n"
                + "Structure: "
                + sharedSnapshot.M5Structure
                + "\n"
                + "R20 Momentum: "
                + sharedSnapshot.RangeMomentum
                + "\n"
                + "R20 Score: L "
                + sharedSnapshot.RangeLongScore
                + "/5 | S "
                + sharedSnapshot.RangeShortScore
                + "/5"
                + "\n"
                + "────────────────────────\n"
                + "Learning: "
                + learningState
                + " | "
                + sharedSnapshot.LearningTrades
                + " trades"
                + " | "
                + sharedSnapshot.LearningPatterns
                + " patterns"
                + "\n"
                + "Trailing: "
                + sharedSnapshot.TrailingState
                + "\n"
                + "────────────────────────\n"
                + "Trades AM: "
                + sharedSnapshot.AmTrades
                + " / "
                + sharedSnapshot.MaxTrades
                + "\n"
                + "Trades PM: "
                + sharedSnapshot.PmTrades
                + " / "
                + sharedSnapshot.MaxTrades
                + "\n"
                + "Trades Day: "
                + sharedSnapshot.TradesToday
                + "\n"
                + "Realized: "
                + sharedSnapshot.RealizedPnL.ToString("$0.00")
                + "\n"
                + "Unrealized: "
                + sharedSnapshot.UnrealizedPnL.ToString("$0.00")
                + "\n"
                + "Total: "
                + sharedSnapshot.TotalPnL.ToString("$0.00")
                + "\n"
                + "Position: "
                + sharedSnapshot.Position
                + " x"
                + sharedSnapshot.PositionQty
                + "\n"
                + "Order: "
                + sharedSnapshot.OrderStatus
                + "\n"
                + "Signal: "
                + sharedSnapshot.Signal
                + "\n"
                + "Setup: "
                + sharedSnapshot.Setup
                + "\n"
                + "Daily Lock: "
                + (
                    sharedSnapshot.DailyLocked
                        ? "YES"
                        : "NO"
                );

            Brush stateBrush =
                sharedSnapshot.DailyLocked
                    ? Brushes.OrangeRed
                    : sharedSnapshot.IsRunning
                        ? Brushes.LimeGreen
                        : Brushes.LightGray;

            Draw.TextFixed(
                this,
                "JJ_LIVE_ADDON_PANEL",
                text,
                TextPosition.BottomRight,
                stateBrush,
                new SimpleFont(
                    "Consolas",
                    10
                ),
                Brushes.DimGray,
                new SolidColorBrush(
                    Color.FromArgb(
                        225,
                        12,
                        17,
                        24
                    )
                ),
                90
            );
        }

        private void DrawRealExecutionMarker()
        {
            JJBotSharedSnapshot snapshot =
                JJBotSharedState.GetSnapshot(
                        Instrument.FullName
                    );

            if (snapshot == null)
            {
                lastExecutionSequence =
                    0;

                return;
            }

            // New AddOn lifecycle: execution sequence restarted.
            // Rebase instead of suppressing new execution markers until
            // the new sequence catches the previous window's value.
            if (
                snapshot.ExecutionSequence <
                    lastExecutionSequence
            )
            {
                lastExecutionSequence =
                    0;
            }

            if (
                snapshot.ExecutionSequence <=
                    lastExecutionSequence
            )
            {
                return;
            }

            lastExecutionSequence =
                snapshot.ExecutionSequence;

            if (
                string.IsNullOrWhiteSpace(
                    snapshot.InstrumentName
                ) ||
                !string.Equals(
                    snapshot.InstrumentName,
                    Instrument.FullName,
                    StringComparison.OrdinalIgnoreCase
                ) ||
                snapshot.LastExecutionPrice <= 0
            )
            {
                return;
            }

            string tag =
                "JJ_REAL_EXEC_"
                + snapshot.ExecutionSequence;

            bool isBuy =
                string.Equals(
                    snapshot.LastExecutionSide,
                    "BUY",
                    StringComparison.OrdinalIgnoreCase
                );

            if (isBuy)
            {
                Draw.ArrowUp(
                    this,
                    tag,
                    false,
                    0,
                    snapshot.LastExecutionPrice
                        - 4 * TickSize,
                    Brushes.LimeGreen
                );

                Draw.Text(
                    this,
                    tag + "_TEXT",
                    "BUY EXECUTED",
                    0,
                    snapshot.LastExecutionPrice
                        - 12 * TickSize,
                    Brushes.LimeGreen
                );
            }
            else
            {
                Draw.ArrowDown(
                    this,
                    tag,
                    false,
                    0,
                    snapshot.LastExecutionPrice
                        + 4 * TickSize,
                    Brushes.OrangeRed
                );

                Draw.Text(
                    this,
                    tag + "_TEXT",
                    "SELL EXECUTED",
                    0,
                    snapshot.LastExecutionPrice
                        + 12 * TickSize,
                    Brushes.OrangeRed
                );
            }
        }

        // =====================================================
        // SESSION VWAP
        // =====================================================
        private void UpdateSessionVwap(
            DateTime nyTime,
            int nyTimeInt)
        {
           if (
    vwapNyDate !=
        nyTime.Date
)
{
    vwapNyDate =
        nyTime.Date;

    cumulativePriceVolume =
        0;

    cumulativeVolume =
        0;

    currentVwap =
        0;
}

            if (
                nyTimeInt <
                    VwapStartTime
            )
            {
                currentVwap =
                    0;

                return;
            }

            double barVolume =
                Volume[0];

            if (
                barVolume <= 0
            )
            {
                return;
            }

            double typicalPrice =
                (
                    High[0]
                    + Low[0]
                    + Close[0]
                )
                / 3.0;

            cumulativePriceVolume +=
                typicalPrice
                * barVolume;

            cumulativeVolume +=
                barVolume;

            if (
                cumulativeVolume > 0
            )
            {
                currentVwap =
                    cumulativePriceVolume
                    / cumulativeVolume;
            }
        }


        // =====================================================
        // STATUS PANEL
        // =====================================================
      // =====================================================
// REAL BOT STATUS PANEL
// =====================================================
// All trading decisions shown here come from JJBotWindow.
//
// EMA9 / EMA50 / VWAP numeric values are local visual
// calculations only and DO NOT control entries.
private void DrawBotStatusPanel(
    DateTime nyTime,
    double fast,
    double slow)
{
    sharedSnapshot =
        JJBotSharedState.GetSnapshot(
            Instrument.FullName
        );

    // =====================================================
    // NO BOT LINK
    // =====================================================
    if (sharedSnapshot == null)
    {
        string noLinkText =
            "J&J NY BOT • VISUAL\n"
            + "────────────────────\n"
            + "Chart: "
            + Instrument.FullName
            + "\n"
            + "Bot: NO LINK\n"
            + "Waiting for JJBotWindow...";

        Draw.TextFixed(
            this,
            "JJ_STATUS_PANEL",
            noLinkText,
            TextPosition.TopRight,
            Brushes.Goldenrod,
            new SimpleFont(
                "Consolas",
                12
            ),
            Brushes.DimGray,
            new SolidColorBrush(
                Color.FromArgb(
                    220,
                    12,
                    17,
                    24
                )
            ),
            85
        );

        return;
    }

    // =====================================================
    // REAL ADDON VALUES
    // =====================================================
    string sessionText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.SessionWindow
        )
            ? "OUTSIDE"
            : sharedSnapshot.SessionWindow;

    string trendText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Trend
        )
            ? "WAITING"
            : sharedSnapshot.M5Trend;

    string vwapSideText =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5VwapSide
        )
            ? "WAITING"
            : sharedSnapshot.M5VwapSide;

    string liquidityTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Liquidity
        )
            ? "NONE"
            : sharedSnapshot.M5Liquidity;

    string structureTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.M5Structure
        )
            ? "WAITING"
            : sharedSnapshot.M5Structure;

    string signalTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.Signal
        )
            ? "WAITING"
            : sharedSnapshot.Signal;

    string setupTextValue =
        string.IsNullOrWhiteSpace(
            sharedSnapshot.Setup
        )
            ? "WAITING"
            : sharedSnapshot.Setup;

    string displayTime =
        nyTime == DateTime.MinValue
            ? "--:--"
            : nyTime.ToString(
                "HH:mm"
            );

    string fastText =
        double.IsNaN(fast)
            ? "--"
            : fast.ToString(
                "0.00"
            );

    string slowText =
        double.IsNaN(slow)
            ? "--"
            : slow.ToString(
                "0.00"
            );

    string vwapValueText =
        currentVwap > 0
            ? currentVwap.ToString(
                "0.00"
            )
            : "--";

    string botState =
        sharedSnapshot.IsRunning
            ? "ARMED"
            : "STOPPED";

    string text =
        "J&J NY BOT • "
        + botState
        + "\n"
        + "────────────────────\n"
        + "NY Time: "
        + displayTime
        + " ET\n"
        + "Session: "
        + sessionText
        + "\n"
        + "Trend: "
        + trendText
        + "\n"
        + "EMA9: "
        + fastText
        + "\n"
        + "EMA50: "
        + slowText
        + "\n"
        + "VWAP: "
        + vwapValueText
        + "\n"
        + "Price/VWAP: "
        + vwapSideText
        + "\n"
        + "Liquidity: "
        + liquidityTextValue
        + "\n"
        + "Structure: "
        + structureTextValue
        + "\n"
        + "Signal: "
        + signalTextValue
        + "\n"
        + "Setup: "
        + setupTextValue;

    Brush textBrush =
        sharedSnapshot.DailyLocked
            ? Brushes.OrangeRed
            : setupTextValue.IndexOf(
                "LONG",
                StringComparison.OrdinalIgnoreCase
            ) >= 0
                ? Brushes.LimeGreen
                : setupTextValue.IndexOf(
                    "SHORT",
                    StringComparison.OrdinalIgnoreCase
                ) >= 0
                    ? Brushes.OrangeRed
                    : sharedSnapshot.IsRunning
                        ? Brushes.WhiteSmoke
                        : Brushes.Gray;

    Draw.TextFixed(
        this,
        "JJ_STATUS_PANEL",
        text,
        TextPosition.TopRight,
        textBrush,
        new SimpleFont(
            "Consolas",
            12
        ),
        Brushes.DimGray,
        new SolidColorBrush(
            Color.FromArgb(
                220,
                12,
                17,
                24
            )
        ),
        85
    );
}

     

        private DateTime ConvertToNewYorkTime(
            DateTime time)
        {
            try
            {
                TimeZoneInfo sourceTimeZone =
                    NinjaTrader.Core.Globals
                        .GeneralOptions
                        .TimeZoneInfo;

                TimeZoneInfo newYorkTimeZone =
                    TimeZoneInfo.FindSystemTimeZoneById(
                        "Eastern Standard Time"
                    );

                DateTime unspecifiedTime =
                    DateTime.SpecifyKind(
                        time,
                        DateTimeKind.Unspecified
                    );

                return TimeZoneInfo.ConvertTime(
                    unspecifiedTime,
                    sourceTimeZone,
                    newYorkTimeZone
                );
            }
            catch
            {
                return time;
            }
        }

        private int ToTimeInt(
            DateTime time)
        {
            return
                time.Hour * 10000
                + time.Minute * 100
                + time.Second;
        }

      
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private JJBotChart[] cacheJJBotChart;
		public JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			return JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showSweeps, showStructure, showSignals, showStatusPanel);
		}

		public JJBotChart JJBotChart(ISeries<double> input, bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			if (cacheJJBotChart != null)
				for (int idx = 0; idx < cacheJJBotChart.Length; idx++)
					if (cacheJJBotChart[idx] != null && cacheJJBotChart[idx].ShowEmaFast == showEmaFast && cacheJJBotChart[idx].ShowEmaSlow == showEmaSlow && cacheJJBotChart[idx].ShowVwap == showVwap && cacheJJBotChart[idx].ShowSweeps == showSweeps && cacheJJBotChart[idx].ShowStructure == showStructure && cacheJJBotChart[idx].ShowSignals == showSignals && cacheJJBotChart[idx].ShowStatusPanel == showStatusPanel && cacheJJBotChart[idx].EqualsInput(input))
						return cacheJJBotChart[idx];
			return CacheIndicator<JJBotChart>(new JJBotChart(){ ShowEmaFast = showEmaFast, ShowEmaSlow = showEmaSlow, ShowVwap = showVwap, ShowSweeps = showSweeps, ShowStructure = showStructure, ShowSignals = showSignals, ShowStatusPanel = showStatusPanel }, input, ref cacheJJBotChart);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			return indicator.JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showSweeps, showStructure, showSignals, showStatusPanel);
		}

		public Indicators.JJBotChart JJBotChart(ISeries<double> input , bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			return indicator.JJBotChart(input, showEmaFast, showEmaSlow, showVwap, showSweeps, showStructure, showSignals, showStatusPanel);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.JJBotChart JJBotChart(bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			return indicator.JJBotChart(Input, showEmaFast, showEmaSlow, showVwap, showSweeps, showStructure, showSignals, showStatusPanel);
		}

		public Indicators.JJBotChart JJBotChart(ISeries<double> input , bool showEmaFast, bool showEmaSlow, bool showVwap, bool showSweeps, bool showStructure, bool showSignals, bool showStatusPanel)
		{
			return indicator.JJBotChart(input, showEmaFast, showEmaSlow, showVwap, showSweeps, showStructure, showSignals, showStatusPanel);
		}
	}
}

#endregion
